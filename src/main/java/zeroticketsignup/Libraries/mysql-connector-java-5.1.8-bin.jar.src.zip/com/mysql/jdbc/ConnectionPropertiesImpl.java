/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.StandardLogger;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TreeMap;
/*      */ import javax.naming.RefAddr;
/*      */ import javax.naming.Reference;
/*      */ import javax.naming.StringRefAddr;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionPropertiesImpl
/*      */   implements Serializable, ConnectionProperties
/*      */ {
/*      */   private static final long serialVersionUID = 4257801713007640580L;
/*      */   
/*      */   class BooleanConnectionProperty
/*      */     extends ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 2540132501709159404L;
/*      */     private final ConnectionPropertiesImpl this$0;
/*      */     
/*      */     BooleanConnectionProperty(ConnectionPropertiesImpl this$0, String propertyNameToSet, boolean defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*   73 */       super(this$0, propertyNameToSet, Boolean.valueOf(defaultValueToSet), null, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */       this.this$0 = this$0;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   82 */     String[] getAllowableValues() { return new String[] { "true", "false", "yes", "no" }; }
/*      */ 
/*      */ 
/*      */     
/*   86 */     boolean getValueAsBoolean() { return ((Boolean)this.valueAsObject).booleanValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   93 */     boolean hasValueConstraints() { return true; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void initializeFrom(String extractedValue) throws SQLException {
/*  100 */       if (extractedValue != null) {
/*  101 */         validateStringValues(extractedValue);
/*      */         
/*  103 */         this.valueAsObject = Boolean.valueOf((extractedValue.equalsIgnoreCase("TRUE") || extractedValue.equalsIgnoreCase("YES")));
/*      */       }
/*      */       else {
/*      */         
/*  107 */         this.valueAsObject = this.defaultValue;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  115 */     boolean isRangeBased() { return false; }
/*      */ 
/*      */ 
/*      */     
/*  119 */     void setValue(boolean valueFlag) { this.valueAsObject = Boolean.valueOf(valueFlag); }
/*      */   }
/*      */ 
/*      */   
/*      */   abstract class ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     String[] allowableValues;
/*      */     
/*      */     String categoryName;
/*      */     
/*      */     Object defaultValue;
/*      */     
/*      */     int lowerBound;
/*      */     
/*      */     int order;
/*      */     
/*      */     String propertyName;
/*      */     
/*      */     String sinceVersion;
/*      */     
/*      */     int upperBound;
/*      */     Object valueAsObject;
/*      */     boolean required;
/*      */     String description;
/*      */     private final ConnectionPropertiesImpl this$0;
/*      */     
/*  146 */     public ConnectionProperty(ConnectionPropertiesImpl this$0) { this.this$0 = this$0; }
/*      */ 
/*      */ 
/*      */     
/*      */     ConnectionProperty(ConnectionPropertiesImpl this$0, String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*  151 */       this.this$0 = this$0;
/*      */       
/*  153 */       this.description = descriptionToSet;
/*  154 */       this.propertyName = propertyNameToSet;
/*  155 */       this.defaultValue = defaultValueToSet;
/*  156 */       this.valueAsObject = defaultValueToSet;
/*  157 */       this.allowableValues = allowableValuesToSet;
/*  158 */       this.lowerBound = lowerBoundToSet;
/*  159 */       this.upperBound = upperBoundToSet;
/*  160 */       this.required = false;
/*  161 */       this.sinceVersion = sinceVersionToSet;
/*  162 */       this.categoryName = category;
/*  163 */       this.order = orderInCategory;
/*      */     }
/*      */ 
/*      */     
/*  167 */     String[] getAllowableValues() { return this.allowableValues; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  174 */     String getCategoryName() { return this.categoryName; }
/*      */ 
/*      */ 
/*      */     
/*  178 */     Object getDefaultValue() { return this.defaultValue; }
/*      */ 
/*      */ 
/*      */     
/*  182 */     int getLowerBound() { return this.lowerBound; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     int getOrder() { return this.order; }
/*      */ 
/*      */ 
/*      */     
/*  193 */     String getPropertyName() { return this.propertyName; }
/*      */ 
/*      */ 
/*      */     
/*  197 */     int getUpperBound() { return this.upperBound; }
/*      */ 
/*      */ 
/*      */     
/*  201 */     Object getValueAsObject() { return this.valueAsObject; }
/*      */ 
/*      */     
/*      */     abstract boolean hasValueConstraints();
/*      */     
/*      */     void initializeFrom(Properties extractFrom) throws SQLException {
/*  207 */       String extractedValue = extractFrom.getProperty(getPropertyName());
/*  208 */       extractFrom.remove(getPropertyName());
/*  209 */       initializeFrom(extractedValue);
/*      */     }
/*      */     
/*      */     void initializeFrom(Reference ref) throws SQLException {
/*  213 */       RefAddr refAddr = ref.get(getPropertyName());
/*      */       
/*  215 */       if (refAddr != null) {
/*  216 */         String refContentAsString = (String)refAddr.getContent();
/*      */         
/*  218 */         initializeFrom(refContentAsString);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     abstract void initializeFrom(String param1String) throws SQLException;
/*      */ 
/*      */ 
/*      */     
/*      */     abstract boolean isRangeBased();
/*      */ 
/*      */     
/*  231 */     void setCategoryName(String categoryName) { this.categoryName = categoryName; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  239 */     void setOrder(int order) { this.order = order; }
/*      */ 
/*      */ 
/*      */     
/*  243 */     void setValueAsObject(Object obj) { this.valueAsObject = obj; }
/*      */ 
/*      */     
/*      */     void storeTo(Reference ref) {
/*  247 */       if (getValueAsObject() != null) {
/*  248 */         ref.add(new StringRefAddr(getPropertyName(), getValueAsObject().toString()));
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     DriverPropertyInfo getAsDriverPropertyInfo() {
/*  254 */       DriverPropertyInfo dpi = new DriverPropertyInfo(this.propertyName, null);
/*  255 */       dpi.choices = getAllowableValues();
/*  256 */       dpi.value = (this.valueAsObject != null) ? this.valueAsObject.toString() : null;
/*  257 */       dpi.required = this.required;
/*  258 */       dpi.description = this.description;
/*      */       
/*  260 */       return dpi;
/*      */     }
/*      */ 
/*      */     
/*      */     void validateStringValues(String valueToValidate) throws SQLException {
/*  265 */       String[] validateAgainst = getAllowableValues();
/*      */       
/*  267 */       if (valueToValidate == null) {
/*      */         return;
/*      */       }
/*      */       
/*  271 */       if (validateAgainst == null || validateAgainst.length == 0) {
/*      */         return;
/*      */       }
/*      */       
/*  275 */       for (int i = 0; i < validateAgainst.length; i++) {
/*  276 */         if (validateAgainst[i] != null && validateAgainst[i].equalsIgnoreCase(valueToValidate)) {
/*      */           return;
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*  282 */       StringBuffer errorMessageBuf = new StringBuffer();
/*      */       
/*  284 */       errorMessageBuf.append("The connection property '");
/*  285 */       errorMessageBuf.append(getPropertyName());
/*  286 */       errorMessageBuf.append("' only accepts values of the form: ");
/*      */       
/*  288 */       if (validateAgainst.length != 0) {
/*  289 */         errorMessageBuf.append("'");
/*  290 */         errorMessageBuf.append(validateAgainst[0]);
/*  291 */         errorMessageBuf.append("'");
/*      */         
/*  293 */         for (int i = 1; i < validateAgainst.length - 1; i++) {
/*  294 */           errorMessageBuf.append(", ");
/*  295 */           errorMessageBuf.append("'");
/*  296 */           errorMessageBuf.append(validateAgainst[i]);
/*  297 */           errorMessageBuf.append("'");
/*      */         } 
/*      */         
/*  300 */         errorMessageBuf.append(" or '");
/*  301 */         errorMessageBuf.append(validateAgainst[validateAgainst.length - 1]);
/*      */         
/*  303 */         errorMessageBuf.append("'");
/*      */       } 
/*      */       
/*  306 */       errorMessageBuf.append(". The value '");
/*  307 */       errorMessageBuf.append(valueToValidate);
/*  308 */       errorMessageBuf.append("' is not in this set.");
/*      */       
/*  310 */       throw SQLError.createSQLException(errorMessageBuf.toString(), "S1009", this.this$0.getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class IntegerConnectionProperty
/*      */     extends ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = -3004305481796850832L;
/*      */     int multiplier;
/*      */     private final ConnectionPropertiesImpl this$0;
/*      */     
/*      */     public IntegerConnectionProperty(ConnectionPropertiesImpl this$0, String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*  324 */       super(propertyNameToSet, defaultValueToSet, allowableValuesToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */ 
/*      */       
/*      */       ConnectionPropertiesImpl.this = ConnectionPropertiesImpl.this;
/*      */       
/*  329 */       this.multiplier = 1;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     IntegerConnectionProperty(ConnectionPropertiesImpl this$0, String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*  335 */       super(propertyNameToSet, new Integer(defaultValueToSet), null, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */       ConnectionPropertiesImpl.this = ConnectionPropertiesImpl.this;
/*      */       this.multiplier = 1;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  353 */     IntegerConnectionProperty(String propertyNameToSet, int defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) { this(propertyNameToSet, defaultValueToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  361 */     String[] getAllowableValues() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  368 */     int getLowerBound() { return this.lowerBound; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  375 */     int getUpperBound() { return this.upperBound; }
/*      */ 
/*      */ 
/*      */     
/*  379 */     int getValueAsInt() { return ((Integer)this.valueAsObject).intValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  386 */     boolean hasValueConstraints() { return false; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void initializeFrom(String extractedValue) throws SQLException {
/*  393 */       if (extractedValue != null) {
/*      */         
/*      */         try {
/*  396 */           int intValue = Double.valueOf(extractedValue).intValue();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  407 */           this.valueAsObject = new Integer(intValue * this.multiplier);
/*  408 */         } catch (NumberFormatException nfe) {
/*  409 */           throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts integer values. The value '" + extractedValue + "' can not be converted to an integer.", "S1009", ConnectionPropertiesImpl.this.getExceptionInterceptor());
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  417 */         this.valueAsObject = this.defaultValue;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  425 */     boolean isRangeBased() { return (getUpperBound() != getLowerBound()); }
/*      */ 
/*      */ 
/*      */     
/*  429 */     void setValue(int valueFlag) { this.valueAsObject = new Integer(valueFlag); }
/*      */   }
/*      */ 
/*      */   
/*      */   public class LongConnectionProperty
/*      */     extends IntegerConnectionProperty
/*      */   {
/*      */     private static final long serialVersionUID = 6068572984340480895L;
/*      */     
/*      */     private final ConnectionPropertiesImpl this$0;
/*      */     
/*      */     LongConnectionProperty(ConnectionPropertiesImpl this$0, String propertyNameToSet, long defaultValueToSet, long lowerBoundToSet, long upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*  441 */       super(propertyNameToSet, new Long(defaultValueToSet), null, (int)lowerBoundToSet, (int)upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */       ConnectionPropertiesImpl.this = ConnectionPropertiesImpl.this;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  450 */     LongConnectionProperty(String propertyNameToSet, long defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) { this(propertyNameToSet, defaultValueToSet, 0L, 0L, descriptionToSet, sinceVersionToSet, category, orderInCategory); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  457 */     void setValue(long value) { this.valueAsObject = new Long(value); }
/*      */ 
/*      */ 
/*      */     
/*  461 */     long getValueAsLong() { return ((Long)this.valueAsObject).longValue(); }
/*      */ 
/*      */     
/*      */     void initializeFrom(String extractedValue) throws SQLException {
/*  465 */       if (extractedValue != null) {
/*      */         
/*      */         try {
/*  468 */           long longValue = Double.valueOf(extractedValue).longValue();
/*      */           
/*  470 */           this.valueAsObject = new Long(longValue);
/*  471 */         } catch (NumberFormatException nfe) {
/*  472 */           throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts long integer values. The value '" + extractedValue + "' can not be converted to a long integer.", "S1009", ConnectionPropertiesImpl.this.getExceptionInterceptor());
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  480 */         this.valueAsObject = this.defaultValue;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   class MemorySizeConnectionProperty
/*      */     extends IntegerConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 7351065128998572656L;
/*      */     private String valueAsString;
/*      */     private final ConnectionPropertiesImpl this$0;
/*      */     
/*      */     MemorySizeConnectionProperty(ConnectionPropertiesImpl this$0, String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*  495 */       super(this$0, propertyNameToSet, defaultValueToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */       this.this$0 = this$0;
/*      */     }
/*      */ 
/*      */     
/*      */     void initializeFrom(String extractedValue) throws SQLException {
/*  501 */       this.valueAsString = extractedValue;
/*      */       
/*  503 */       if (extractedValue != null) {
/*  504 */         if (extractedValue.endsWith("k") || extractedValue.endsWith("K") || extractedValue.endsWith("kb") || extractedValue.endsWith("Kb") || extractedValue.endsWith("kB")) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  509 */           this.multiplier = 1024;
/*  510 */           int indexOfK = StringUtils.indexOfIgnoreCase(extractedValue, "k");
/*      */           
/*  512 */           extractedValue = extractedValue.substring(0, indexOfK);
/*  513 */         } else if (extractedValue.endsWith("m") || extractedValue.endsWith("M") || extractedValue.endsWith("G") || extractedValue.endsWith("mb") || extractedValue.endsWith("Mb") || extractedValue.endsWith("mB")) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  519 */           this.multiplier = 1048576;
/*  520 */           int indexOfM = StringUtils.indexOfIgnoreCase(extractedValue, "m");
/*      */           
/*  522 */           extractedValue = extractedValue.substring(0, indexOfM);
/*  523 */         } else if (extractedValue.endsWith("g") || extractedValue.endsWith("G") || extractedValue.endsWith("gb") || extractedValue.endsWith("Gb") || extractedValue.endsWith("gB")) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  528 */           this.multiplier = 1073741824;
/*  529 */           int indexOfG = StringUtils.indexOfIgnoreCase(extractedValue, "g");
/*      */           
/*  531 */           extractedValue = extractedValue.substring(0, indexOfG);
/*      */         } 
/*      */       }
/*      */       
/*  535 */       super.initializeFrom(extractedValue);
/*      */     }
/*      */ 
/*      */     
/*  539 */     void setValue(String value) throws SQLException { initializeFrom(value); }
/*      */ 
/*      */ 
/*      */     
/*  543 */     String getValueAsString() { return this.valueAsString; }
/*      */   }
/*      */ 
/*      */   
/*      */   class StringConnectionProperty
/*      */     extends ConnectionProperty
/*      */     implements Serializable
/*      */   {
/*      */     private static final long serialVersionUID = 5432127962785948272L;
/*      */     private final ConnectionPropertiesImpl this$0;
/*      */     
/*  554 */     StringConnectionProperty(String propertyNameToSet, String defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) { this(propertyNameToSet, defaultValueToSet, null, descriptionToSet, sinceVersionToSet, category, orderInCategory); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     StringConnectionProperty(String propertyNameToSet, String defaultValueToSet, String[] allowableValuesToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory) {
/*  572 */       super(propertyNameToSet, defaultValueToSet, allowableValuesToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*      */       ConnectionPropertiesImpl.this = ConnectionPropertiesImpl.this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  578 */     String getValueAsString() { return (String)this.valueAsObject; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  585 */     boolean hasValueConstraints() { return (this.allowableValues != null && this.allowableValues.length > 0); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void initializeFrom(String extractedValue) throws SQLException {
/*  593 */       if (extractedValue != null) {
/*  594 */         validateStringValues(extractedValue);
/*      */         
/*  596 */         this.valueAsObject = extractedValue;
/*      */       } else {
/*  598 */         this.valueAsObject = this.defaultValue;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  606 */     boolean isRangeBased() { return false; }
/*      */ 
/*      */ 
/*      */     
/*  610 */     void setValue(String valueFlag) { this.valueAsObject = valueFlag; }
/*      */   }
/*      */ 
/*      */   
/*  614 */   private static final String CONNECTION_AND_AUTH_CATEGORY = Messages.getString("ConnectionProperties.categoryConnectionAuthentication");
/*      */   
/*  616 */   private static final String NETWORK_CATEGORY = Messages.getString("ConnectionProperties.categoryNetworking");
/*      */   
/*  618 */   private static final String DEBUGING_PROFILING_CATEGORY = Messages.getString("ConnectionProperties.categoryDebuggingProfiling");
/*      */   
/*  620 */   private static final String HA_CATEGORY = Messages.getString("ConnectionProperties.categorryHA");
/*      */   
/*  622 */   private static final String MISC_CATEGORY = Messages.getString("ConnectionProperties.categoryMisc");
/*      */   
/*  624 */   private static final String PERFORMANCE_CATEGORY = Messages.getString("ConnectionProperties.categoryPerformance");
/*      */   
/*  626 */   private static final String SECURITY_CATEGORY = Messages.getString("ConnectionProperties.categorySecurity");
/*      */   
/*  628 */   private static final String[] PROPERTY_CATEGORIES = new String[] { CONNECTION_AND_AUTH_CATEGORY, NETWORK_CATEGORY, HA_CATEGORY, SECURITY_CATEGORY, PERFORMANCE_CATEGORY, DEBUGING_PROFILING_CATEGORY, MISC_CATEGORY };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  633 */   private static final ArrayList PROPERTY_LIST = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  638 */   private static final String STANDARD_LOGGER_NAME = StandardLogger.class.getName();
/*      */   
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_CONVERT_TO_NULL = "convertToNull";
/*      */   
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_EXCEPTION = "exception";
/*      */   
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_ROUND = "round";
/*      */   
/*      */   static  {
/*      */     try {
/*  648 */       Field[] declaredFields = ConnectionPropertiesImpl.class.getDeclaredFields();
/*      */ 
/*      */       
/*  651 */       for (int i = 0; i < declaredFields.length; i++) {
/*  652 */         if (ConnectionProperty.class.isAssignableFrom(declaredFields[i].getType()))
/*      */         {
/*  654 */           PROPERTY_LIST.add(declaredFields[i]);
/*      */         }
/*      */       } 
/*  657 */     } catch (Exception ex) {
/*  658 */       RuntimeException rtEx = new RuntimeException();
/*  659 */       rtEx.initCause(ex);
/*      */       
/*  661 */       throw rtEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  666 */   public ExceptionInterceptor getExceptionInterceptor() { return null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  685 */   protected static DriverPropertyInfo[] exposeAsDriverPropertyInfo(Properties info, int slotsToReserve) throws SQLException { return (new ConnectionPropertiesImpl() {  }).exposeAsDriverPropertyInfoInternal(info, slotsToReserve); }
/*      */ 
/*      */ 
/*      */   
/*  689 */   private BooleanConnectionProperty allowLoadLocalInfile = new BooleanConnectionProperty(this, "allowLoadLocalInfile", true, Messages.getString("ConnectionProperties.loadDataLocal"), "3.0.3", SECURITY_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  695 */   private BooleanConnectionProperty allowMultiQueries = new BooleanConnectionProperty(this, "allowMultiQueries", false, Messages.getString("ConnectionProperties.allowMultiQueries"), "3.1.1", SECURITY_CATEGORY, 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  701 */   private BooleanConnectionProperty allowNanAndInf = new BooleanConnectionProperty(this, "allowNanAndInf", false, Messages.getString("ConnectionProperties.allowNANandINF"), "3.1.5", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  707 */   private BooleanConnectionProperty allowUrlInLocalInfile = new BooleanConnectionProperty(this, "allowUrlInLocalInfile", false, Messages.getString("ConnectionProperties.allowUrlInLoadLocal"), "3.1.4", SECURITY_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  713 */   private BooleanConnectionProperty alwaysSendSetIsolation = new BooleanConnectionProperty(this, "alwaysSendSetIsolation", true, Messages.getString("ConnectionProperties.alwaysSendSetIsolation"), "3.1.7", PERFORMANCE_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  719 */   private BooleanConnectionProperty autoClosePStmtStreams = new BooleanConnectionProperty(this, "autoClosePStmtStreams", false, Messages.getString("ConnectionProperties.autoClosePstmtStreams"), "3.1.12", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  727 */   private BooleanConnectionProperty autoDeserialize = new BooleanConnectionProperty(this, "autoDeserialize", false, Messages.getString("ConnectionProperties.autoDeserialize"), "3.1.5", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  733 */   private BooleanConnectionProperty autoGenerateTestcaseScript = new BooleanConnectionProperty(this, "autoGenerateTestcaseScript", false, Messages.getString("ConnectionProperties.autoGenerateTestcaseScript"), "3.1.9", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean autoGenerateTestcaseScriptAsBoolean = false;
/*      */ 
/*      */   
/*  740 */   private BooleanConnectionProperty autoReconnect = new BooleanConnectionProperty(this, "autoReconnect", false, Messages.getString("ConnectionProperties.autoReconnect"), "1.1", HA_CATEGORY, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  746 */   private BooleanConnectionProperty autoReconnectForPools = new BooleanConnectionProperty(this, "autoReconnectForPools", false, Messages.getString("ConnectionProperties.autoReconnectForPools"), "3.1.3", HA_CATEGORY, 1);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean autoReconnectForPoolsAsBoolean = false;
/*      */ 
/*      */ 
/*      */   
/*  754 */   private MemorySizeConnectionProperty blobSendChunkSize = new MemorySizeConnectionProperty(this, "blobSendChunkSize", 1048576, 1, 2147483647, Messages.getString("ConnectionProperties.blobSendChunkSize"), "3.1.9", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  762 */   private BooleanConnectionProperty autoSlowLog = new BooleanConnectionProperty(this, "autoSlowLog", true, Messages.getString("ConnectionProperties.autoSlowLog"), "5.1.4", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  767 */   private BooleanConnectionProperty blobsAreStrings = new BooleanConnectionProperty(this, "blobsAreStrings", false, "Should the driver always treat BLOBs as Strings - specifically to work around dubious metadata returned by the server for GROUP BY clauses?", "5.0.8", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  773 */   private BooleanConnectionProperty functionsNeverReturnBlobs = new BooleanConnectionProperty(this, "functionsNeverReturnBlobs", false, "Should the driver always treat data from functions returning BLOBs as Strings - specifically to work around dubious metadata returned by the server for GROUP BY clauses?", "5.0.8", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  779 */   private BooleanConnectionProperty cacheCallableStatements = new BooleanConnectionProperty(this, "cacheCallableStmts", false, Messages.getString("ConnectionProperties.cacheCallableStatements"), "3.1.2", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  784 */   private BooleanConnectionProperty cachePreparedStatements = new BooleanConnectionProperty(this, "cachePrepStmts", false, Messages.getString("ConnectionProperties.cachePrepStmts"), "3.0.10", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  790 */   private BooleanConnectionProperty cacheResultSetMetadata = new BooleanConnectionProperty(this, "cacheResultSetMetadata", false, Messages.getString("ConnectionProperties.cacheRSMetadata"), "3.1.1", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean cacheResultSetMetaDataAsBoolean;
/*      */ 
/*      */ 
/*      */   
/*  798 */   private BooleanConnectionProperty cacheServerConfiguration = new BooleanConnectionProperty(this, "cacheServerConfiguration", false, Messages.getString("ConnectionProperties.cacheServerConfiguration"), "3.1.5", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  804 */   private IntegerConnectionProperty callableStatementCacheSize = new IntegerConnectionProperty("callableStmtCacheSize", 100, 0, 2147483647, Messages.getString("ConnectionProperties.callableStmtCacheSize"), "3.1.2", PERFORMANCE_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  812 */   private BooleanConnectionProperty capitalizeTypeNames = new BooleanConnectionProperty(this, "capitalizeTypeNames", true, Messages.getString("ConnectionProperties.capitalizeTypeNames"), "2.0.7", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  818 */   private StringConnectionProperty characterEncoding = new StringConnectionProperty("characterEncoding", null, Messages.getString("ConnectionProperties.characterEncoding"), "1.1g", MISC_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  824 */   private String characterEncodingAsString = null;
/*      */   
/*  826 */   private StringConnectionProperty characterSetResults = new StringConnectionProperty("characterSetResults", null, Messages.getString("ConnectionProperties.characterSetResults"), "3.0.13", MISC_CATEGORY, 6);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  831 */   private StringConnectionProperty clientInfoProvider = new StringConnectionProperty("clientInfoProvider", "com.mysql.jdbc.JDBC4CommentClientInfoProvider", Messages.getString("ConnectionProperties.clientInfoProvider"), "5.1.0", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  837 */   private BooleanConnectionProperty clobberStreamingResults = new BooleanConnectionProperty(this, "clobberStreamingResults", false, Messages.getString("ConnectionProperties.clobberStreamingResults"), "3.0.9", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  843 */   private StringConnectionProperty clobCharacterEncoding = new StringConnectionProperty("clobCharacterEncoding", null, Messages.getString("ConnectionProperties.clobCharacterEncoding"), "5.0.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  849 */   private BooleanConnectionProperty compensateOnDuplicateKeyUpdateCounts = new BooleanConnectionProperty(this, "compensateOnDuplicateKeyUpdateCounts", false, Messages.getString("ConnectionProperties.compensateOnDuplicateKeyUpdateCounts"), "5.1.7", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  854 */   private StringConnectionProperty connectionCollation = new StringConnectionProperty("connectionCollation", null, Messages.getString("ConnectionProperties.connectionCollation"), "3.0.13", MISC_CATEGORY, 7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  860 */   private StringConnectionProperty connectionLifecycleInterceptors = new StringConnectionProperty("connectionLifecycleInterceptors", null, Messages.getString("ConnectionProperties.connectionLifecycleInterceptors"), "5.1.4", CONNECTION_AND_AUTH_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  866 */   private IntegerConnectionProperty connectTimeout = new IntegerConnectionProperty("connectTimeout", 0, 0, 2147483647, Messages.getString("ConnectionProperties.connectTimeout"), "3.0.1", CONNECTION_AND_AUTH_CATEGORY, 9);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  871 */   private BooleanConnectionProperty continueBatchOnError = new BooleanConnectionProperty(this, "continueBatchOnError", true, Messages.getString("ConnectionProperties.continueBatchOnError"), "3.0.3", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  877 */   private BooleanConnectionProperty createDatabaseIfNotExist = new BooleanConnectionProperty(this, "createDatabaseIfNotExist", false, Messages.getString("ConnectionProperties.createDatabaseIfNotExist"), "3.1.9", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  883 */   private IntegerConnectionProperty defaultFetchSize = new IntegerConnectionProperty("defaultFetchSize", 0, Messages.getString("ConnectionProperties.defaultFetchSize"), "3.1.9", PERFORMANCE_CATEGORY, -2147483648);
/*      */   
/*  885 */   private BooleanConnectionProperty detectServerPreparedStmts = new BooleanConnectionProperty(this, "useServerPrepStmts", false, Messages.getString("ConnectionProperties.useServerPrepStmts"), "3.1.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  891 */   private BooleanConnectionProperty dontTrackOpenResources = new BooleanConnectionProperty(this, "dontTrackOpenResources", false, Messages.getString("ConnectionProperties.dontTrackOpenResources"), "3.1.7", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  897 */   private BooleanConnectionProperty dumpQueriesOnException = new BooleanConnectionProperty(this, "dumpQueriesOnException", false, Messages.getString("ConnectionProperties.dumpQueriesOnException"), "3.1.3", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  903 */   private BooleanConnectionProperty dynamicCalendars = new BooleanConnectionProperty(this, "dynamicCalendars", false, Messages.getString("ConnectionProperties.dynamicCalendars"), "3.1.5", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  909 */   private BooleanConnectionProperty elideSetAutoCommits = new BooleanConnectionProperty(this, "elideSetAutoCommits", false, Messages.getString("ConnectionProperties.eliseSetAutoCommit"), "3.1.3", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  915 */   private BooleanConnectionProperty emptyStringsConvertToZero = new BooleanConnectionProperty(this, "emptyStringsConvertToZero", true, Messages.getString("ConnectionProperties.emptyStringsConvertToZero"), "3.1.8", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  920 */   private BooleanConnectionProperty emulateLocators = new BooleanConnectionProperty(this, "emulateLocators", false, Messages.getString("ConnectionProperties.emulateLocators"), "3.1.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/*  924 */   private BooleanConnectionProperty emulateUnsupportedPstmts = new BooleanConnectionProperty(this, "emulateUnsupportedPstmts", true, Messages.getString("ConnectionProperties.emulateUnsupportedPstmts"), "3.1.7", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  930 */   private BooleanConnectionProperty enablePacketDebug = new BooleanConnectionProperty(this, "enablePacketDebug", false, Messages.getString("ConnectionProperties.enablePacketDebug"), "3.1.3", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  936 */   private BooleanConnectionProperty enableQueryTimeouts = new BooleanConnectionProperty(this, "enableQueryTimeouts", true, Messages.getString("ConnectionProperties.enableQueryTimeouts"), "5.0.6", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  943 */   private BooleanConnectionProperty explainSlowQueries = new BooleanConnectionProperty(this, "explainSlowQueries", false, Messages.getString("ConnectionProperties.explainSlowQueries"), "3.1.2", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  949 */   private StringConnectionProperty exceptionInterceptors = new StringConnectionProperty("exceptionInterceptors", null, Messages.getString("ConnectionProperties.exceptionInterceptors"), "5.1.8", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  956 */   private BooleanConnectionProperty failOverReadOnly = new BooleanConnectionProperty(this, "failOverReadOnly", true, Messages.getString("ConnectionProperties.failoverReadOnly"), "3.0.12", HA_CATEGORY, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  962 */   private BooleanConnectionProperty gatherPerformanceMetrics = new BooleanConnectionProperty(this, "gatherPerfMetrics", false, Messages.getString("ConnectionProperties.gatherPerfMetrics"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  968 */   private BooleanConnectionProperty generateSimpleParameterMetadata = new BooleanConnectionProperty(this, "generateSimpleParameterMetadata", false, Messages.getString("ConnectionProperties.generateSimpleParameterMetadata"), "5.0.5", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */   
/*      */   private boolean highAvailabilityAsBoolean = false;
/*      */   
/*  973 */   private BooleanConnectionProperty holdResultsOpenOverStatementClose = new BooleanConnectionProperty(this, "holdResultsOpenOverStatementClose", false, Messages.getString("ConnectionProperties.holdRSOpenOverStmtClose"), "3.1.7", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  979 */   private BooleanConnectionProperty includeInnodbStatusInDeadlockExceptions = new BooleanConnectionProperty(this, "includeInnodbStatusInDeadlockExceptions", false, "Include the output of \"SHOW ENGINE INNODB STATUS\" in exception messages when deadlock exceptions are detected?", "5.0.7", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  985 */   private BooleanConnectionProperty ignoreNonTxTables = new BooleanConnectionProperty(this, "ignoreNonTxTables", false, Messages.getString("ConnectionProperties.ignoreNonTxTables"), "3.0.9", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  991 */   private IntegerConnectionProperty initialTimeout = new IntegerConnectionProperty("initialTimeout", 2, 1, 2147483647, Messages.getString("ConnectionProperties.initialTimeout"), "1.1", HA_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  996 */   private BooleanConnectionProperty isInteractiveClient = new BooleanConnectionProperty(this, "interactiveClient", false, Messages.getString("ConnectionProperties.interactiveClient"), "3.1.0", CONNECTION_AND_AUTH_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1002 */   private BooleanConnectionProperty jdbcCompliantTruncation = new BooleanConnectionProperty(this, "jdbcCompliantTruncation", true, Messages.getString("ConnectionProperties.jdbcCompliantTruncation"), "3.1.2", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1008 */   private boolean jdbcCompliantTruncationForReads = this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */ 
/*      */   
/* 1011 */   protected MemorySizeConnectionProperty largeRowSizeThreshold = new MemorySizeConnectionProperty(this, "largeRowSizeThreshold", 2048, 0, 2147483647, Messages.getString("ConnectionProperties.largeRowSizeThreshold"), "5.1.1", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1016 */   private StringConnectionProperty loadBalanceStrategy = new StringConnectionProperty("loadBalanceStrategy", "random", new String[] { "random", "bestResponseTime" }, Messages.getString("ConnectionProperties.loadBalanceStrategy"), "5.0.6", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1023 */   private IntegerConnectionProperty loadBalanceBlacklistTimeout = new IntegerConnectionProperty("loadBalanceBlacklistTimeout", 0, 0, 2147483647, Messages.getString("ConnectionProperties.loadBalanceBlacklistTimeout"), "5.1.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1029 */   private StringConnectionProperty localSocketAddress = new StringConnectionProperty("localSocketAddress", null, Messages.getString("ConnectionProperties.localSocketAddress"), "5.0.5", CONNECTION_AND_AUTH_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/* 1033 */   private MemorySizeConnectionProperty locatorFetchBufferSize = new MemorySizeConnectionProperty(this, "locatorFetchBufferSize", 1048576, 0, 2147483647, Messages.getString("ConnectionProperties.locatorFetchBufferSize"), "3.2.1", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1041 */   private StringConnectionProperty loggerClassName = new StringConnectionProperty("logger", STANDARD_LOGGER_NAME, Messages.getString("ConnectionProperties.logger", new Object[] { Log.class.getName(), STANDARD_LOGGER_NAME }), "3.1.1", DEBUGING_PROFILING_CATEGORY, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1047 */   private BooleanConnectionProperty logSlowQueries = new BooleanConnectionProperty(this, "logSlowQueries", false, Messages.getString("ConnectionProperties.logSlowQueries"), "3.1.2", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1053 */   private BooleanConnectionProperty logXaCommands = new BooleanConnectionProperty(this, "logXaCommands", false, Messages.getString("ConnectionProperties.logXaCommands"), "5.0.5", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1059 */   private BooleanConnectionProperty maintainTimeStats = new BooleanConnectionProperty(this, "maintainTimeStats", true, Messages.getString("ConnectionProperties.maintainTimeStats"), "3.1.9", PERFORMANCE_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean maintainTimeStatsAsBoolean = true;
/*      */ 
/*      */ 
/*      */   
/* 1067 */   private IntegerConnectionProperty maxQuerySizeToLog = new IntegerConnectionProperty("maxQuerySizeToLog", 2048, 0, 2147483647, Messages.getString("ConnectionProperties.maxQuerySizeToLog"), "3.1.3", DEBUGING_PROFILING_CATEGORY, 4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1075 */   private IntegerConnectionProperty maxReconnects = new IntegerConnectionProperty("maxReconnects", 3, 1, 2147483647, Messages.getString("ConnectionProperties.maxReconnects"), "1.1", HA_CATEGORY, 4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1083 */   private IntegerConnectionProperty retriesAllDown = new IntegerConnectionProperty("retriesAllDown", 120, 0, 2147483647, Messages.getString("ConnectionProperties.retriesAllDown"), "5.1.6", HA_CATEGORY, 4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1091 */   private IntegerConnectionProperty maxRows = new IntegerConnectionProperty("maxRows", -1, -1, 2147483647, Messages.getString("ConnectionProperties.maxRows"), Messages.getString("ConnectionProperties.allVersions"), MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1096 */   private int maxRowsAsInt = -1;
/*      */   
/* 1098 */   private IntegerConnectionProperty metadataCacheSize = new IntegerConnectionProperty("metadataCacheSize", 50, 1, 2147483647, Messages.getString("ConnectionProperties.metadataCacheSize"), "3.1.1", PERFORMANCE_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1106 */   private IntegerConnectionProperty netTimeoutForStreamingResults = new IntegerConnectionProperty("netTimeoutForStreamingResults", 600, 0, 2147483647, Messages.getString("ConnectionProperties.netTimeoutForStreamingResults"), "5.1.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1112 */   private BooleanConnectionProperty noAccessToProcedureBodies = new BooleanConnectionProperty(this, "noAccessToProcedureBodies", false, "When determining procedure parameter types for CallableStatements, and the connected user  can't access procedure bodies through \"SHOW CREATE PROCEDURE\" or select on mysql.proc  should the driver instead create basic metadata (all parameters reported as IN VARCHARs, but allowing registerOutParameter() to be called on them anyway) instead  of throwing an exception?", "5.0.3", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1122 */   private BooleanConnectionProperty noDatetimeStringSync = new BooleanConnectionProperty(this, "noDatetimeStringSync", false, Messages.getString("ConnectionProperties.noDatetimeStringSync"), "3.1.7", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1128 */   private BooleanConnectionProperty noTimezoneConversionForTimeType = new BooleanConnectionProperty(this, "noTimezoneConversionForTimeType", false, Messages.getString("ConnectionProperties.noTzConversionForTimeType"), "5.0.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1134 */   private BooleanConnectionProperty nullCatalogMeansCurrent = new BooleanConnectionProperty(this, "nullCatalogMeansCurrent", true, Messages.getString("ConnectionProperties.nullCatalogMeansCurrent"), "3.1.8", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1140 */   private BooleanConnectionProperty nullNamePatternMatchesAll = new BooleanConnectionProperty(this, "nullNamePatternMatchesAll", true, Messages.getString("ConnectionProperties.nullNamePatternMatchesAll"), "3.1.8", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1146 */   private IntegerConnectionProperty packetDebugBufferSize = new IntegerConnectionProperty("packetDebugBufferSize", 20, 0, 2147483647, Messages.getString("ConnectionProperties.packetDebugBufferSize"), "3.1.3", DEBUGING_PROFILING_CATEGORY, 7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1154 */   private BooleanConnectionProperty padCharsWithSpace = new BooleanConnectionProperty(this, "padCharsWithSpace", false, Messages.getString("ConnectionProperties.padCharsWithSpace"), "5.0.6", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1162 */   private BooleanConnectionProperty paranoid = new BooleanConnectionProperty(this, "paranoid", false, Messages.getString("ConnectionProperties.paranoid"), "3.0.1", SECURITY_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1168 */   private BooleanConnectionProperty pedantic = new BooleanConnectionProperty(this, "pedantic", false, Messages.getString("ConnectionProperties.pedantic"), "3.0.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/* 1172 */   private BooleanConnectionProperty pinGlobalTxToPhysicalConnection = new BooleanConnectionProperty(this, "pinGlobalTxToPhysicalConnection", false, Messages.getString("ConnectionProperties.pinGlobalTxToPhysicalConnection"), "5.0.1", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/* 1176 */   private BooleanConnectionProperty populateInsertRowWithDefaultValues = new BooleanConnectionProperty(this, "populateInsertRowWithDefaultValues", false, Messages.getString("ConnectionProperties.populateInsertRowWithDefaultValues"), "5.0.5", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1181 */   private IntegerConnectionProperty preparedStatementCacheSize = new IntegerConnectionProperty("prepStmtCacheSize", 25, 0, 2147483647, Messages.getString("ConnectionProperties.prepStmtCacheSize"), "3.0.10", PERFORMANCE_CATEGORY, 10);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1186 */   private IntegerConnectionProperty preparedStatementCacheSqlLimit = new IntegerConnectionProperty("prepStmtCacheSqlLimit", 256, 1, 2147483647, Messages.getString("ConnectionProperties.prepStmtCacheSqlLimit"), "3.0.10", PERFORMANCE_CATEGORY, 11);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1194 */   private BooleanConnectionProperty processEscapeCodesForPrepStmts = new BooleanConnectionProperty(this, "processEscapeCodesForPrepStmts", true, Messages.getString("ConnectionProperties.processEscapeCodesForPrepStmts"), "3.1.12", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1201 */   private StringConnectionProperty profilerEventHandler = new StringConnectionProperty("profilerEventHandler", "com.mysql.jdbc.profiler.LoggingProfilerEventHandler", Messages.getString("ConnectionProperties.profilerEventHandler"), "5.1.6", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1207 */   private StringConnectionProperty profileSql = new StringConnectionProperty("profileSql", null, Messages.getString("ConnectionProperties.profileSqlDeprecated"), "2.0.14", DEBUGING_PROFILING_CATEGORY, 3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1213 */   private BooleanConnectionProperty profileSQL = new BooleanConnectionProperty(this, "profileSQL", false, Messages.getString("ConnectionProperties.profileSQL"), "3.1.0", DEBUGING_PROFILING_CATEGORY, 1);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean profileSQLAsBoolean = false;
/*      */ 
/*      */ 
/*      */   
/* 1221 */   private StringConnectionProperty propertiesTransform = new StringConnectionProperty("propertiesTransform", null, Messages.getString("ConnectionProperties.connectionPropertiesTransform"), "3.1.4", CONNECTION_AND_AUTH_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1227 */   private IntegerConnectionProperty queriesBeforeRetryMaster = new IntegerConnectionProperty("queriesBeforeRetryMaster", 50, 1, 2147483647, Messages.getString("ConnectionProperties.queriesBeforeRetryMaster"), "3.0.2", HA_CATEGORY, 7);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1235 */   private BooleanConnectionProperty reconnectAtTxEnd = new BooleanConnectionProperty(this, "reconnectAtTxEnd", false, Messages.getString("ConnectionProperties.reconnectAtTxEnd"), "3.0.10", HA_CATEGORY, 4);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean reconnectTxAtEndAsBoolean = false;
/*      */ 
/*      */   
/* 1242 */   private BooleanConnectionProperty relaxAutoCommit = new BooleanConnectionProperty(this, "relaxAutoCommit", false, Messages.getString("ConnectionProperties.relaxAutoCommit"), "2.0.13", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1248 */   private IntegerConnectionProperty reportMetricsIntervalMillis = new IntegerConnectionProperty("reportMetricsIntervalMillis", 30000, 0, 2147483647, Messages.getString("ConnectionProperties.reportMetricsIntervalMillis"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 3);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1256 */   private BooleanConnectionProperty requireSSL = new BooleanConnectionProperty(this, "requireSSL", false, Messages.getString("ConnectionProperties.requireSSL"), "3.1.0", SECURITY_CATEGORY, 3);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1261 */   private StringConnectionProperty resourceId = new StringConnectionProperty("resourceId", null, Messages.getString("ConnectionProperties.resourceId"), "5.0.1", HA_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1268 */   private IntegerConnectionProperty resultSetSizeThreshold = new IntegerConnectionProperty("resultSetSizeThreshold", 100, Messages.getString("ConnectionProperties.resultSetSizeThreshold"), "5.0.5", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */   
/* 1271 */   private BooleanConnectionProperty retainStatementAfterResultSetClose = new BooleanConnectionProperty(this, "retainStatementAfterResultSetClose", false, Messages.getString("ConnectionProperties.retainStatementAfterResultSetClose"), "3.1.11", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1277 */   private BooleanConnectionProperty rewriteBatchedStatements = new BooleanConnectionProperty(this, "rewriteBatchedStatements", false, Messages.getString("ConnectionProperties.rewriteBatchedStatements"), "3.1.13", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1283 */   private BooleanConnectionProperty rollbackOnPooledClose = new BooleanConnectionProperty(this, "rollbackOnPooledClose", true, Messages.getString("ConnectionProperties.rollbackOnPooledClose"), "3.0.15", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1289 */   private BooleanConnectionProperty roundRobinLoadBalance = new BooleanConnectionProperty(this, "roundRobinLoadBalance", false, Messages.getString("ConnectionProperties.roundRobinLoadBalance"), "3.1.2", HA_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1295 */   private BooleanConnectionProperty runningCTS13 = new BooleanConnectionProperty(this, "runningCTS13", false, Messages.getString("ConnectionProperties.runningCTS13"), "3.1.7", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1301 */   private IntegerConnectionProperty secondsBeforeRetryMaster = new IntegerConnectionProperty("secondsBeforeRetryMaster", 30, 1, 2147483647, Messages.getString("ConnectionProperties.secondsBeforeRetryMaster"), "3.0.2", HA_CATEGORY, 8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1309 */   private IntegerConnectionProperty selfDestructOnPingSecondsLifetime = new IntegerConnectionProperty("selfDestructOnPingSecondsLifetime", 0, 0, 2147483647, Messages.getString("ConnectionProperties.selfDestructOnPingSecondsLifetime"), "5.1.6", HA_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1317 */   private IntegerConnectionProperty selfDestructOnPingMaxOperations = new IntegerConnectionProperty("selfDestructOnPingMaxOperations", 0, 0, 2147483647, Messages.getString("ConnectionProperties.selfDestructOnPingMaxOperations"), "5.1.6", HA_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1325 */   private StringConnectionProperty serverTimezone = new StringConnectionProperty("serverTimezone", null, Messages.getString("ConnectionProperties.serverTimezone"), "3.0.2", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1331 */   private StringConnectionProperty sessionVariables = new StringConnectionProperty("sessionVariables", null, Messages.getString("ConnectionProperties.sessionVariables"), "3.1.8", MISC_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1336 */   private IntegerConnectionProperty slowQueryThresholdMillis = new IntegerConnectionProperty("slowQueryThresholdMillis", 2000, 0, 2147483647, Messages.getString("ConnectionProperties.slowQueryThresholdMillis"), "3.1.2", DEBUGING_PROFILING_CATEGORY, 9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1344 */   private LongConnectionProperty slowQueryThresholdNanos = new LongConnectionProperty("slowQueryThresholdNanos", 0L, Messages.getString("ConnectionProperties.slowQueryThresholdNanos"), "5.0.7", DEBUGING_PROFILING_CATEGORY, 10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1352 */   private StringConnectionProperty socketFactoryClassName = new StringConnectionProperty("socketFactory", StandardSocketFactory.class.getName(), Messages.getString("ConnectionProperties.socketFactory"), "3.0.3", CONNECTION_AND_AUTH_CATEGORY, 4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1358 */   private IntegerConnectionProperty socketTimeout = new IntegerConnectionProperty("socketTimeout", 0, 0, 2147483647, Messages.getString("ConnectionProperties.socketTimeout"), "3.0.1", CONNECTION_AND_AUTH_CATEGORY, 10);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1366 */   private StringConnectionProperty statementInterceptors = new StringConnectionProperty("statementInterceptors", null, Messages.getString("ConnectionProperties.statementInterceptors"), "5.1.1", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */   
/* 1369 */   private BooleanConnectionProperty strictFloatingPoint = new BooleanConnectionProperty(this, "strictFloatingPoint", false, Messages.getString("ConnectionProperties.strictFloatingPoint"), "3.0.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1374 */   private BooleanConnectionProperty strictUpdates = new BooleanConnectionProperty(this, "strictUpdates", true, Messages.getString("ConnectionProperties.strictUpdates"), "3.0.4", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1380 */   private BooleanConnectionProperty overrideSupportsIntegrityEnhancementFacility = new BooleanConnectionProperty(this, "overrideSupportsIntegrityEnhancementFacility", false, Messages.getString("ConnectionProperties.overrideSupportsIEF"), "3.1.12", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1386 */   private BooleanConnectionProperty tcpNoDelay = new BooleanConnectionProperty(this, "tcpNoDelay", Boolean.valueOf("true").booleanValue(), Messages.getString("ConnectionProperties.tcpNoDelay"), "5.0.7", NETWORK_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1392 */   private BooleanConnectionProperty tcpKeepAlive = new BooleanConnectionProperty(this, "tcpKeepAlive", Boolean.valueOf("true").booleanValue(), Messages.getString("ConnectionProperties.tcpKeepAlive"), "5.0.7", NETWORK_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1398 */   private IntegerConnectionProperty tcpRcvBuf = new IntegerConnectionProperty("tcpRcvBuf", Integer.parseInt("0"), 0, 2147483647, Messages.getString("ConnectionProperties.tcpSoRcvBuf"), "5.0.7", NETWORK_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1405 */   private IntegerConnectionProperty tcpSndBuf = new IntegerConnectionProperty("tcpSndBuf", Integer.parseInt("0"), 0, 2147483647, Messages.getString("ConnectionProperties.tcpSoSndBuf"), "5.0.7", NETWORK_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1412 */   private IntegerConnectionProperty tcpTrafficClass = new IntegerConnectionProperty("tcpTrafficClass", Integer.parseInt("0"), 0, 255, Messages.getString("ConnectionProperties.tcpTrafficClass"), "5.0.7", NETWORK_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1419 */   private BooleanConnectionProperty tinyInt1isBit = new BooleanConnectionProperty(this, "tinyInt1isBit", true, Messages.getString("ConnectionProperties.tinyInt1isBit"), "3.0.16", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1425 */   private BooleanConnectionProperty traceProtocol = new BooleanConnectionProperty(this, "traceProtocol", false, Messages.getString("ConnectionProperties.traceProtocol"), "3.1.2", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1430 */   private BooleanConnectionProperty treatUtilDateAsTimestamp = new BooleanConnectionProperty(this, "treatUtilDateAsTimestamp", true, Messages.getString("ConnectionProperties.treatUtilDateAsTimestamp"), "5.0.5", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1435 */   private BooleanConnectionProperty transformedBitIsBoolean = new BooleanConnectionProperty(this, "transformedBitIsBoolean", false, Messages.getString("ConnectionProperties.transformedBitIsBoolean"), "3.1.9", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1441 */   private BooleanConnectionProperty useBlobToStoreUTF8OutsideBMP = new BooleanConnectionProperty(this, "useBlobToStoreUTF8OutsideBMP", false, Messages.getString("ConnectionProperties.useBlobToStoreUTF8OutsideBMP"), "5.1.3", MISC_CATEGORY, 128);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1447 */   private StringConnectionProperty utf8OutsideBmpExcludedColumnNamePattern = new StringConnectionProperty("utf8OutsideBmpExcludedColumnNamePattern", null, Messages.getString("ConnectionProperties.utf8OutsideBmpExcludedColumnNamePattern"), "5.1.3", MISC_CATEGORY, 129);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1453 */   private StringConnectionProperty utf8OutsideBmpIncludedColumnNamePattern = new StringConnectionProperty("utf8OutsideBmpIncludedColumnNamePattern", null, Messages.getString("ConnectionProperties.utf8OutsideBmpIncludedColumnNamePattern"), "5.1.3", MISC_CATEGORY, 129);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1459 */   private BooleanConnectionProperty useCompression = new BooleanConnectionProperty(this, "useCompression", false, Messages.getString("ConnectionProperties.useCompression"), "3.0.17", CONNECTION_AND_AUTH_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1465 */   private BooleanConnectionProperty useColumnNamesInFindColumn = new BooleanConnectionProperty(this, "useColumnNamesInFindColumn", false, Messages.getString("ConnectionProperties.useColumnNamesInFindColumn"), "5.1.7", MISC_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1471 */   private StringConnectionProperty useConfigs = new StringConnectionProperty("useConfigs", null, Messages.getString("ConnectionProperties.useConfigs"), "3.1.5", CONNECTION_AND_AUTH_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1477 */   private BooleanConnectionProperty useCursorFetch = new BooleanConnectionProperty(this, "useCursorFetch", false, Messages.getString("ConnectionProperties.useCursorFetch"), "5.0.0", PERFORMANCE_CATEGORY, 2147483647);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1483 */   private BooleanConnectionProperty useDynamicCharsetInfo = new BooleanConnectionProperty(this, "useDynamicCharsetInfo", true, Messages.getString("ConnectionProperties.useDynamicCharsetInfo"), "5.0.6", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1489 */   private BooleanConnectionProperty useDirectRowUnpack = new BooleanConnectionProperty(this, "useDirectRowUnpack", true, "Use newer result set row unpacking code that skips a copy from network buffers  to a MySQL packet instance and instead reads directly into the result set row data buffers.", "5.1.1", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1495 */   private BooleanConnectionProperty useFastIntParsing = new BooleanConnectionProperty(this, "useFastIntParsing", true, Messages.getString("ConnectionProperties.useFastIntParsing"), "3.1.4", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1501 */   private BooleanConnectionProperty useFastDateParsing = new BooleanConnectionProperty(this, "useFastDateParsing", true, Messages.getString("ConnectionProperties.useFastDateParsing"), "5.0.5", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1507 */   private BooleanConnectionProperty useHostsInPrivileges = new BooleanConnectionProperty(this, "useHostsInPrivileges", true, Messages.getString("ConnectionProperties.useHostsInPrivileges"), "3.0.2", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1512 */   private BooleanConnectionProperty useInformationSchema = new BooleanConnectionProperty(this, "useInformationSchema", false, Messages.getString("ConnectionProperties.useInformationSchema"), "5.0.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1517 */   private BooleanConnectionProperty useJDBCCompliantTimezoneShift = new BooleanConnectionProperty(this, "useJDBCCompliantTimezoneShift", false, Messages.getString("ConnectionProperties.useJDBCCompliantTimezoneShift"), "5.0.0", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1524 */   private BooleanConnectionProperty useLocalSessionState = new BooleanConnectionProperty(this, "useLocalSessionState", false, Messages.getString("ConnectionProperties.useLocalSessionState"), "3.1.7", PERFORMANCE_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1530 */   private BooleanConnectionProperty useLocalTransactionState = new BooleanConnectionProperty(this, "useLocalTransactionState", false, Messages.getString("ConnectionProperties.useLocalTransactionState"), "5.1.7", PERFORMANCE_CATEGORY, 6);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1536 */   private BooleanConnectionProperty useLegacyDatetimeCode = new BooleanConnectionProperty(this, "useLegacyDatetimeCode", true, Messages.getString("ConnectionProperties.useLegacyDatetimeCode"), "5.1.6", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1542 */   private BooleanConnectionProperty useNanosForElapsedTime = new BooleanConnectionProperty(this, "useNanosForElapsedTime", false, Messages.getString("ConnectionProperties.useNanosForElapsedTime"), "5.0.7", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1549 */   private BooleanConnectionProperty useOldAliasMetadataBehavior = new BooleanConnectionProperty(this, "useOldAliasMetadataBehavior", false, Messages.getString("ConnectionProperties.useOldAliasMetadataBehavior"), "5.0.4", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1557 */   private BooleanConnectionProperty useOldUTF8Behavior = new BooleanConnectionProperty(this, "useOldUTF8Behavior", false, Messages.getString("ConnectionProperties.useOldUtf8Behavior"), "3.1.6", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useOldUTF8BehaviorAsBoolean = false;
/*      */ 
/*      */ 
/*      */   
/* 1565 */   private BooleanConnectionProperty useOnlyServerErrorMessages = new BooleanConnectionProperty(this, "useOnlyServerErrorMessages", true, Messages.getString("ConnectionProperties.useOnlyServerErrorMessages"), "3.0.15", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1571 */   private BooleanConnectionProperty useReadAheadInput = new BooleanConnectionProperty(this, "useReadAheadInput", true, Messages.getString("ConnectionProperties.useReadAheadInput"), "3.1.5", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1577 */   private BooleanConnectionProperty useSqlStateCodes = new BooleanConnectionProperty(this, "useSqlStateCodes", true, Messages.getString("ConnectionProperties.useSqlStateCodes"), "3.1.3", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1583 */   private BooleanConnectionProperty useSSL = new BooleanConnectionProperty(this, "useSSL", false, Messages.getString("ConnectionProperties.useSSL"), "3.0.2", SECURITY_CATEGORY, 2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1589 */   private BooleanConnectionProperty useSSPSCompatibleTimezoneShift = new BooleanConnectionProperty(this, "useSSPSCompatibleTimezoneShift", false, Messages.getString("ConnectionProperties.useSSPSCompatibleTimezoneShift"), "5.0.5", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1595 */   private BooleanConnectionProperty useStreamLengthsInPrepStmts = new BooleanConnectionProperty(this, "useStreamLengthsInPrepStmts", true, Messages.getString("ConnectionProperties.useStreamLengthsInPrepStmts"), "3.0.2", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1601 */   private BooleanConnectionProperty useTimezone = new BooleanConnectionProperty(this, "useTimezone", false, Messages.getString("ConnectionProperties.useTimezone"), "3.0.2", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1607 */   private BooleanConnectionProperty useUltraDevWorkAround = new BooleanConnectionProperty(this, "ultraDevHack", false, Messages.getString("ConnectionProperties.ultraDevHack"), "2.0.3", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1613 */   private BooleanConnectionProperty useUnbufferedInput = new BooleanConnectionProperty(this, "useUnbufferedInput", true, Messages.getString("ConnectionProperties.useUnbufferedInput"), "3.0.11", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1618 */   private BooleanConnectionProperty useUnicode = new BooleanConnectionProperty(this, "useUnicode", true, Messages.getString("ConnectionProperties.useUnicode"), "1.1g", MISC_CATEGORY, 0);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useUnicodeAsBoolean = true;
/*      */ 
/*      */ 
/*      */   
/* 1627 */   private BooleanConnectionProperty useUsageAdvisor = new BooleanConnectionProperty(this, "useUsageAdvisor", false, Messages.getString("ConnectionProperties.useUsageAdvisor"), "3.1.1", DEBUGING_PROFILING_CATEGORY, 10);
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useUsageAdvisorAsBoolean = false;
/*      */ 
/*      */ 
/*      */   
/* 1635 */   private BooleanConnectionProperty yearIsDateType = new BooleanConnectionProperty(this, "yearIsDateType", true, Messages.getString("ConnectionProperties.yearIsDateType"), "3.1.9", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1641 */   private StringConnectionProperty zeroDateTimeBehavior = new StringConnectionProperty("zeroDateTimeBehavior", "exception", new String[] { "exception", "round", "convertToNull" }, Messages.getString("ConnectionProperties.zeroDateTimeBehavior", new Object[] { "exception", "round", "convertToNull" }), "3.1.4", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1651 */   private BooleanConnectionProperty useJvmCharsetConverters = new BooleanConnectionProperty(this, "useJvmCharsetConverters", false, Messages.getString("ConnectionProperties.useJvmCharsetConverters"), "5.0.1", PERFORMANCE_CATEGORY, -2147483648);
/*      */ 
/*      */   
/* 1654 */   private BooleanConnectionProperty useGmtMillisForDatetimes = new BooleanConnectionProperty(this, "useGmtMillisForDatetimes", false, Messages.getString("ConnectionProperties.useGmtMillisForDatetimes"), "3.1.12", MISC_CATEGORY, -2147483648);
/*      */   
/* 1656 */   private BooleanConnectionProperty dumpMetadataOnColumnNotFound = new BooleanConnectionProperty(this, "dumpMetadataOnColumnNotFound", false, Messages.getString("ConnectionProperties.dumpMetadataOnColumnNotFound"), "3.1.13", DEBUGING_PROFILING_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */   
/* 1660 */   private StringConnectionProperty clientCertificateKeyStoreUrl = new StringConnectionProperty("clientCertificateKeyStoreUrl", null, Messages.getString("ConnectionProperties.clientCertificateKeyStoreUrl"), "5.1.0", SECURITY_CATEGORY, 5);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1665 */   private StringConnectionProperty trustCertificateKeyStoreUrl = new StringConnectionProperty("trustCertificateKeyStoreUrl", null, Messages.getString("ConnectionProperties.trustCertificateKeyStoreUrl"), "5.1.0", SECURITY_CATEGORY, 8);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1670 */   private StringConnectionProperty clientCertificateKeyStoreType = new StringConnectionProperty("clientCertificateKeyStoreType", null, Messages.getString("ConnectionProperties.clientCertificateKeyStoreType"), "5.1.0", SECURITY_CATEGORY, 6);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1675 */   private StringConnectionProperty clientCertificateKeyStorePassword = new StringConnectionProperty("clientCertificateKeyStorePassword", null, Messages.getString("ConnectionProperties.clientCertificateKeyStorePassword"), "5.1.0", SECURITY_CATEGORY, 7);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1680 */   private StringConnectionProperty trustCertificateKeyStoreType = new StringConnectionProperty("trustCertificateKeyStoreType", null, Messages.getString("ConnectionProperties.trustCertificateKeyStoreType"), "5.1.0", SECURITY_CATEGORY, 9);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1685 */   private StringConnectionProperty trustCertificateKeyStorePassword = new StringConnectionProperty("trustCertificateKeyStorePassword", null, Messages.getString("ConnectionProperties.trustCertificateKeyStorePassword"), "5.1.0", SECURITY_CATEGORY, 10);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1690 */   private BooleanConnectionProperty verifyServerCertificate = new BooleanConnectionProperty(this, "verifyServerCertificate", true, Messages.getString("ConnectionProperties.verifyServerCertificate"), "5.1.6", SECURITY_CATEGORY, 4);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1696 */   private BooleanConnectionProperty useAffectedRows = new BooleanConnectionProperty(this, "useAffectedRows", false, Messages.getString("ConnectionProperties.useAffectedRows"), "5.1.7", MISC_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1701 */   private StringConnectionProperty passwordCharacterEncoding = new StringConnectionProperty("passwordCharacterEncoding", null, Messages.getString("ConnectionProperties.passwordCharacterEncoding"), "5.1.7", SECURITY_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1706 */   private IntegerConnectionProperty maxAllowedPacket = new IntegerConnectionProperty("maxAllowedPacket", -1, Messages.getString("ConnectionProperties.maxAllowedPacket"), "5.1.8", NETWORK_CATEGORY, -2147483648);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected DriverPropertyInfo[] exposeAsDriverPropertyInfoInternal(Properties info, int slotsToReserve) throws SQLException {
/* 1712 */     initializeProperties(info);
/*      */     
/* 1714 */     int numProperties = PROPERTY_LIST.size();
/*      */     
/* 1716 */     int listSize = numProperties + slotsToReserve;
/*      */     
/* 1718 */     DriverPropertyInfo[] driverProperties = new DriverPropertyInfo[listSize];
/*      */     
/* 1720 */     for (int i = slotsToReserve; i < listSize; i++) {
/* 1721 */       Field propertyField = PROPERTY_LIST.get(i - slotsToReserve);
/*      */ 
/*      */       
/*      */       try {
/* 1725 */         ConnectionProperty propToExpose = (ConnectionProperty)propertyField.get(this);
/*      */ 
/*      */         
/* 1728 */         if (info != null) {
/* 1729 */           propToExpose.initializeFrom(info);
/*      */         }
/*      */ 
/*      */         
/* 1733 */         driverProperties[i] = propToExpose.getAsDriverPropertyInfo();
/* 1734 */       } catch (IllegalAccessException iae) {
/* 1735 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.InternalPropertiesFailure"), "S1000", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1740 */     return driverProperties;
/*      */   }
/*      */ 
/*      */   
/*      */   protected Properties exposeAsProperties(Properties info) throws SQLException {
/* 1745 */     if (info == null) {
/* 1746 */       info = new Properties();
/*      */     }
/*      */     
/* 1749 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 1751 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 1752 */       Field propertyField = PROPERTY_LIST.get(i);
/*      */ 
/*      */       
/*      */       try {
/* 1756 */         ConnectionProperty propToGet = (ConnectionProperty)propertyField.get(this);
/*      */ 
/*      */         
/* 1759 */         Object propValue = propToGet.getValueAsObject();
/*      */         
/* 1761 */         if (propValue != null) {
/* 1762 */           info.setProperty(propToGet.getPropertyName(), propValue.toString());
/*      */         }
/*      */       }
/* 1765 */       catch (IllegalAccessException iae) {
/* 1766 */         throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1771 */     return info;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String exposeAsXml() throws SQLException {
/* 1778 */     StringBuffer xmlBuf = new StringBuffer();
/* 1779 */     xmlBuf.append("<ConnectionProperties>");
/*      */     
/* 1781 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 1783 */     int numCategories = PROPERTY_CATEGORIES.length;
/*      */     
/* 1785 */     Map propertyListByCategory = new HashMap();
/*      */     
/* 1787 */     for (int i = 0; i < numCategories; i++) {
/* 1788 */       propertyListByCategory.put(PROPERTY_CATEGORIES[i], new Map[] { new TreeMap(), new TreeMap() });
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1798 */     StringConnectionProperty userProp = new StringConnectionProperty("user", null, Messages.getString("ConnectionProperties.Username"), Messages.getString("ConnectionProperties.allVersions"), CONNECTION_AND_AUTH_CATEGORY, -2147483647);
/*      */ 
/*      */ 
/*      */     
/* 1802 */     StringConnectionProperty passwordProp = new StringConnectionProperty("password", null, Messages.getString("ConnectionProperties.Password"), Messages.getString("ConnectionProperties.allVersions"), CONNECTION_AND_AUTH_CATEGORY, -2147483646);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1807 */     Map[] connectionSortMaps = (Map[])propertyListByCategory.get(CONNECTION_AND_AUTH_CATEGORY);
/*      */     
/* 1809 */     TreeMap userMap = new TreeMap();
/* 1810 */     userMap.put(userProp.getPropertyName(), userProp);
/*      */     
/* 1812 */     connectionSortMaps[0].put(new Integer(userProp.getOrder()), userMap);
/*      */     
/* 1814 */     TreeMap passwordMap = new TreeMap();
/* 1815 */     passwordMap.put(passwordProp.getPropertyName(), passwordProp);
/*      */     
/* 1817 */     connectionSortMaps[0].put(new Integer(passwordProp.getOrder()), passwordMap);
/*      */ 
/*      */     
/*      */     try {
/* 1821 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 1822 */         Field propertyField = PROPERTY_LIST.get(i);
/*      */         
/* 1824 */         ConnectionProperty propToGet = (ConnectionProperty)propertyField.get(this);
/*      */         
/* 1826 */         Map[] sortMaps = (Map[])propertyListByCategory.get(propToGet.getCategoryName());
/*      */         
/* 1828 */         int orderInCategory = propToGet.getOrder();
/*      */         
/* 1830 */         if (orderInCategory == Integer.MIN_VALUE) {
/* 1831 */           sortMaps[1].put(propToGet.getPropertyName(), propToGet);
/*      */         } else {
/* 1833 */           Integer order = new Integer(orderInCategory);
/*      */           
/* 1835 */           Map orderMap = sortMaps[0].get(order);
/*      */           
/* 1837 */           if (orderMap == null) {
/* 1838 */             orderMap = new TreeMap();
/* 1839 */             sortMaps[0].put(order, orderMap);
/*      */           } 
/*      */           
/* 1842 */           orderMap.put(propToGet.getPropertyName(), propToGet);
/*      */         } 
/*      */       } 
/*      */       
/* 1846 */       for (int j = 0; j < numCategories; j++) {
/* 1847 */         Map[] sortMaps = (Map[])propertyListByCategory.get(PROPERTY_CATEGORIES[j]);
/*      */         
/* 1849 */         Iterator orderedIter = sortMaps[0].values().iterator();
/* 1850 */         Iterator alphaIter = sortMaps[1].values().iterator();
/*      */         
/* 1852 */         xmlBuf.append("\n <PropertyCategory name=\"");
/* 1853 */         xmlBuf.append(PROPERTY_CATEGORIES[j]);
/* 1854 */         xmlBuf.append("\">");
/*      */         
/* 1856 */         while (orderedIter.hasNext()) {
/* 1857 */           Iterator orderedAlphaIter = ((Map)orderedIter.next()).values().iterator();
/*      */           
/* 1859 */           while (orderedAlphaIter.hasNext()) {
/* 1860 */             ConnectionProperty propToGet = orderedAlphaIter.next();
/*      */ 
/*      */             
/* 1863 */             xmlBuf.append("\n  <Property name=\"");
/* 1864 */             xmlBuf.append(propToGet.getPropertyName());
/* 1865 */             xmlBuf.append("\" required=\"");
/* 1866 */             xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */             
/* 1868 */             xmlBuf.append("\" default=\"");
/*      */             
/* 1870 */             if (propToGet.getDefaultValue() != null) {
/* 1871 */               xmlBuf.append(propToGet.getDefaultValue());
/*      */             }
/*      */             
/* 1874 */             xmlBuf.append("\" sortOrder=\"");
/* 1875 */             xmlBuf.append(propToGet.getOrder());
/* 1876 */             xmlBuf.append("\" since=\"");
/* 1877 */             xmlBuf.append(propToGet.sinceVersion);
/* 1878 */             xmlBuf.append("\">\n");
/* 1879 */             xmlBuf.append("    ");
/* 1880 */             xmlBuf.append(propToGet.description);
/* 1881 */             xmlBuf.append("\n  </Property>");
/*      */           } 
/*      */         } 
/*      */         
/* 1885 */         while (alphaIter.hasNext()) {
/* 1886 */           ConnectionProperty propToGet = alphaIter.next();
/*      */ 
/*      */           
/* 1889 */           xmlBuf.append("\n  <Property name=\"");
/* 1890 */           xmlBuf.append(propToGet.getPropertyName());
/* 1891 */           xmlBuf.append("\" required=\"");
/* 1892 */           xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */           
/* 1894 */           xmlBuf.append("\" default=\"");
/*      */           
/* 1896 */           if (propToGet.getDefaultValue() != null) {
/* 1897 */             xmlBuf.append(propToGet.getDefaultValue());
/*      */           }
/*      */           
/* 1900 */           xmlBuf.append("\" sortOrder=\"alpha\" since=\"");
/* 1901 */           xmlBuf.append(propToGet.sinceVersion);
/* 1902 */           xmlBuf.append("\">\n");
/* 1903 */           xmlBuf.append("    ");
/* 1904 */           xmlBuf.append(propToGet.description);
/* 1905 */           xmlBuf.append("\n  </Property>");
/*      */         } 
/*      */         
/* 1908 */         xmlBuf.append("\n </PropertyCategory>");
/*      */       } 
/* 1910 */     } catch (IllegalAccessException iae) {
/* 1911 */       throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/* 1915 */     xmlBuf.append("\n</ConnectionProperties>");
/*      */     
/* 1917 */     return xmlBuf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1924 */   public boolean getAllowLoadLocalInfile() { return this.allowLoadLocalInfile.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1931 */   public boolean getAllowMultiQueries() { return this.allowMultiQueries.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1938 */   public boolean getAllowNanAndInf() { return this.allowNanAndInf.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1945 */   public boolean getAllowUrlInLocalInfile() { return this.allowUrlInLocalInfile.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1952 */   public boolean getAlwaysSendSetIsolation() { return this.alwaysSendSetIsolation.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1959 */   public boolean getAutoDeserialize() { return this.autoDeserialize.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1966 */   public boolean getAutoGenerateTestcaseScript() { return this.autoGenerateTestcaseScriptAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1973 */   public boolean getAutoReconnectForPools() { return this.autoReconnectForPoolsAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1980 */   public int getBlobSendChunkSize() { return this.blobSendChunkSize.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1987 */   public boolean getCacheCallableStatements() { return this.cacheCallableStatements.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1994 */   public boolean getCachePreparedStatements() { return ((Boolean)this.cachePreparedStatements.getValueAsObject()).booleanValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2002 */   public boolean getCacheResultSetMetadata() { return this.cacheResultSetMetaDataAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2009 */   public boolean getCacheServerConfiguration() { return this.cacheServerConfiguration.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2016 */   public int getCallableStatementCacheSize() { return this.callableStatementCacheSize.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2023 */   public boolean getCapitalizeTypeNames() { return this.capitalizeTypeNames.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2030 */   public String getCharacterSetResults() { return this.characterSetResults.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2037 */   public boolean getClobberStreamingResults() { return this.clobberStreamingResults.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2044 */   public String getClobCharacterEncoding() { return this.clobCharacterEncoding.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2051 */   public String getConnectionCollation() { return this.connectionCollation.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2058 */   public int getConnectTimeout() { return this.connectTimeout.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2065 */   public boolean getContinueBatchOnError() { return this.continueBatchOnError.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2072 */   public boolean getCreateDatabaseIfNotExist() { return this.createDatabaseIfNotExist.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2079 */   public int getDefaultFetchSize() { return this.defaultFetchSize.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2086 */   public boolean getDontTrackOpenResources() { return this.dontTrackOpenResources.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2093 */   public boolean getDumpQueriesOnException() { return this.dumpQueriesOnException.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2100 */   public boolean getDynamicCalendars() { return this.dynamicCalendars.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2107 */   public boolean getElideSetAutoCommits() { return this.elideSetAutoCommits.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2114 */   public boolean getEmptyStringsConvertToZero() { return this.emptyStringsConvertToZero.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2121 */   public boolean getEmulateLocators() { return this.emulateLocators.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2128 */   public boolean getEmulateUnsupportedPstmts() { return this.emulateUnsupportedPstmts.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2135 */   public boolean getEnablePacketDebug() { return this.enablePacketDebug.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2142 */   public String getEncoding() { return this.characterEncodingAsString; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2149 */   public boolean getExplainSlowQueries() { return this.explainSlowQueries.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2156 */   public boolean getFailOverReadOnly() { return this.failOverReadOnly.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2163 */   public boolean getGatherPerformanceMetrics() { return this.gatherPerformanceMetrics.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2172 */   protected boolean getHighAvailability() { return this.highAvailabilityAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2179 */   public boolean getHoldResultsOpenOverStatementClose() { return this.holdResultsOpenOverStatementClose.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2186 */   public boolean getIgnoreNonTxTables() { return this.ignoreNonTxTables.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2193 */   public int getInitialTimeout() { return this.initialTimeout.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2200 */   public boolean getInteractiveClient() { return this.isInteractiveClient.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2207 */   public boolean getIsInteractiveClient() { return this.isInteractiveClient.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2214 */   public boolean getJdbcCompliantTruncation() { return this.jdbcCompliantTruncation.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2221 */   public int getLocatorFetchBufferSize() { return this.locatorFetchBufferSize.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2228 */   public String getLogger() { return this.loggerClassName.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2235 */   public String getLoggerClassName() { return this.loggerClassName.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2242 */   public boolean getLogSlowQueries() { return this.logSlowQueries.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2249 */   public boolean getMaintainTimeStats() { return this.maintainTimeStatsAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2256 */   public int getMaxQuerySizeToLog() { return this.maxQuerySizeToLog.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2263 */   public int getMaxReconnects() { return this.maxReconnects.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2270 */   public int getMaxRows() { return this.maxRowsAsInt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2277 */   public int getMetadataCacheSize() { return this.metadataCacheSize.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2284 */   public boolean getNoDatetimeStringSync() { return this.noDatetimeStringSync.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2291 */   public boolean getNullCatalogMeansCurrent() { return this.nullCatalogMeansCurrent.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2298 */   public boolean getNullNamePatternMatchesAll() { return this.nullNamePatternMatchesAll.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2305 */   public int getPacketDebugBufferSize() { return this.packetDebugBufferSize.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2312 */   public boolean getParanoid() { return this.paranoid.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2319 */   public boolean getPedantic() { return this.pedantic.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2326 */   public int getPreparedStatementCacheSize() { return ((Integer)this.preparedStatementCacheSize.getValueAsObject()).intValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2334 */   public int getPreparedStatementCacheSqlLimit() { return ((Integer)this.preparedStatementCacheSqlLimit.getValueAsObject()).intValue(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2342 */   public boolean getProfileSql() { return this.profileSQLAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2349 */   public boolean getProfileSQL() { return this.profileSQL.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2356 */   public String getPropertiesTransform() { return this.propertiesTransform.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2363 */   public int getQueriesBeforeRetryMaster() { return this.queriesBeforeRetryMaster.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2370 */   public boolean getReconnectAtTxEnd() { return this.reconnectTxAtEndAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2377 */   public boolean getRelaxAutoCommit() { return this.relaxAutoCommit.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2384 */   public int getReportMetricsIntervalMillis() { return this.reportMetricsIntervalMillis.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2391 */   public boolean getRequireSSL() { return this.requireSSL.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 2395 */   protected boolean getRetainStatementAfterResultSetClose() { return this.retainStatementAfterResultSetClose.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2402 */   public boolean getRollbackOnPooledClose() { return this.rollbackOnPooledClose.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2409 */   public boolean getRoundRobinLoadBalance() { return this.roundRobinLoadBalance.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2416 */   public boolean getRunningCTS13() { return this.runningCTS13.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2423 */   public int getSecondsBeforeRetryMaster() { return this.secondsBeforeRetryMaster.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2430 */   public String getServerTimezone() { return this.serverTimezone.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2437 */   public String getSessionVariables() { return this.sessionVariables.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2444 */   public int getSlowQueryThresholdMillis() { return this.slowQueryThresholdMillis.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2451 */   public String getSocketFactoryClassName() { return this.socketFactoryClassName.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2458 */   public int getSocketTimeout() { return this.socketTimeout.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2465 */   public boolean getStrictFloatingPoint() { return this.strictFloatingPoint.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2472 */   public boolean getStrictUpdates() { return this.strictUpdates.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2479 */   public boolean getTinyInt1isBit() { return this.tinyInt1isBit.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2486 */   public boolean getTraceProtocol() { return this.traceProtocol.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2493 */   public boolean getTransformedBitIsBoolean() { return this.transformedBitIsBoolean.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2500 */   public boolean getUseCompression() { return this.useCompression.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2507 */   public boolean getUseFastIntParsing() { return this.useFastIntParsing.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2514 */   public boolean getUseHostsInPrivileges() { return this.useHostsInPrivileges.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2521 */   public boolean getUseInformationSchema() { return this.useInformationSchema.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2528 */   public boolean getUseLocalSessionState() { return this.useLocalSessionState.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2535 */   public boolean getUseOldUTF8Behavior() { return this.useOldUTF8BehaviorAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2542 */   public boolean getUseOnlyServerErrorMessages() { return this.useOnlyServerErrorMessages.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2549 */   public boolean getUseReadAheadInput() { return this.useReadAheadInput.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2556 */   public boolean getUseServerPreparedStmts() { return this.detectServerPreparedStmts.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2563 */   public boolean getUseSqlStateCodes() { return this.useSqlStateCodes.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2570 */   public boolean getUseSSL() { return this.useSSL.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2577 */   public boolean getUseStreamLengthsInPrepStmts() { return this.useStreamLengthsInPrepStmts.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2584 */   public boolean getUseTimezone() { return this.useTimezone.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2591 */   public boolean getUseUltraDevWorkAround() { return this.useUltraDevWorkAround.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2598 */   public boolean getUseUnbufferedInput() { return this.useUnbufferedInput.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2605 */   public boolean getUseUnicode() { return this.useUnicodeAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2612 */   public boolean getUseUsageAdvisor() { return this.useUsageAdvisorAsBoolean; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2619 */   public boolean getYearIsDateType() { return this.yearIsDateType.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2626 */   public String getZeroDateTimeBehavior() { return this.zeroDateTimeBehavior.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeFromRef(Reference ref) throws SQLException {
/* 2640 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 2642 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 2643 */       Field propertyField = PROPERTY_LIST.get(i);
/*      */ 
/*      */       
/*      */       try {
/* 2647 */         ConnectionProperty propToSet = (ConnectionProperty)propertyField.get(this);
/*      */ 
/*      */         
/* 2650 */         if (ref != null) {
/* 2651 */           propToSet.initializeFrom(ref);
/*      */         }
/* 2653 */       } catch (IllegalAccessException iae) {
/* 2654 */         throw SQLError.createSQLException("Internal properties failure", "S1000", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2659 */     postInitialization();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initializeProperties(Properties info) throws SQLException {
/* 2672 */     if (info != null) {
/*      */       
/* 2674 */       String profileSqlLc = info.getProperty("profileSql");
/*      */       
/* 2676 */       if (profileSqlLc != null) {
/* 2677 */         info.put("profileSQL", profileSqlLc);
/*      */       }
/*      */       
/* 2680 */       Properties infoCopy = (Properties)info.clone();
/*      */       
/* 2682 */       infoCopy.remove("HOST");
/* 2683 */       infoCopy.remove("user");
/* 2684 */       infoCopy.remove("password");
/* 2685 */       infoCopy.remove("DBNAME");
/* 2686 */       infoCopy.remove("PORT");
/* 2687 */       infoCopy.remove("profileSql");
/*      */       
/* 2689 */       int numPropertiesToSet = PROPERTY_LIST.size();
/*      */       
/* 2691 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 2692 */         Field propertyField = PROPERTY_LIST.get(i);
/*      */ 
/*      */         
/*      */         try {
/* 2696 */           ConnectionProperty propToSet = (ConnectionProperty)propertyField.get(this);
/*      */ 
/*      */           
/* 2699 */           propToSet.initializeFrom(infoCopy);
/* 2700 */         } catch (IllegalAccessException iae) {
/* 2701 */           throw SQLError.createSQLException(Messages.getString("ConnectionProperties.unableToInitDriverProperties") + iae.toString(), "S1000", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2708 */       postInitialization();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void postInitialization() throws SQLException {
/* 2715 */     if (this.profileSql.getValueAsObject() != null) {
/* 2716 */       this.profileSQL.initializeFrom(this.profileSql.getValueAsObject().toString());
/*      */     }
/*      */ 
/*      */     
/* 2720 */     this.reconnectTxAtEndAsBoolean = ((Boolean)this.reconnectAtTxEnd.getValueAsObject()).booleanValue();
/*      */ 
/*      */ 
/*      */     
/* 2724 */     if (getMaxRows() == 0)
/*      */     {
/*      */       
/* 2727 */       this.maxRows.setValueAsObject(Constants.integerValueOf(-1));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2733 */     String testEncoding = getEncoding();
/*      */     
/* 2735 */     if (testEncoding != null) {
/*      */       
/*      */       try {
/*      */         
/* 2739 */         String testString = "abc";
/* 2740 */         testString.getBytes(testEncoding);
/* 2741 */       } catch (UnsupportedEncodingException UE) {
/* 2742 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.unsupportedCharacterEncoding", new Object[] { testEncoding }), "0S100", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2751 */     if (((Boolean)this.cacheResultSetMetadata.getValueAsObject()).booleanValue()) {
/*      */       
/*      */       try {
/* 2754 */         Class.forName("java.util.LinkedHashMap");
/* 2755 */       } catch (ClassNotFoundException cnfe) {
/* 2756 */         this.cacheResultSetMetadata.setValue(false);
/*      */       } 
/*      */     }
/*      */     
/* 2760 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */     
/* 2762 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/* 2763 */     this.characterEncodingAsString = (String)this.characterEncoding.getValueAsObject();
/*      */     
/* 2765 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/* 2766 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */     
/* 2768 */     this.maxRowsAsInt = ((Integer)this.maxRows.getValueAsObject()).intValue();
/*      */     
/* 2770 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/* 2771 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */     
/* 2773 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */     
/* 2775 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */     
/* 2777 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */     
/* 2779 */     this.jdbcCompliantTruncationForReads = getJdbcCompliantTruncation();
/*      */     
/* 2781 */     if (getUseCursorFetch())
/*      */     {
/*      */       
/* 2784 */       setDetectServerPreparedStmts(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2792 */   public void setAllowLoadLocalInfile(boolean property) { this.allowLoadLocalInfile.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2799 */   public void setAllowMultiQueries(boolean property) { this.allowMultiQueries.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2806 */   public void setAllowNanAndInf(boolean flag) { this.allowNanAndInf.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2813 */   public void setAllowUrlInLocalInfile(boolean flag) { this.allowUrlInLocalInfile.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2820 */   public void setAlwaysSendSetIsolation(boolean flag) { this.alwaysSendSetIsolation.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2827 */   public void setAutoDeserialize(boolean flag) { this.autoDeserialize.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoGenerateTestcaseScript(boolean flag) {
/* 2834 */     this.autoGenerateTestcaseScript.setValue(flag);
/* 2835 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2843 */   public void setAutoReconnect(boolean flag) { this.autoReconnect.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoReconnectForConnectionPools(boolean property) {
/* 2850 */     this.autoReconnectForPools.setValue(property);
/* 2851 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2859 */   public void setAutoReconnectForPools(boolean flag) { this.autoReconnectForPools.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2866 */   public void setBlobSendChunkSize(String value) throws SQLException { this.blobSendChunkSize.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2873 */   public void setCacheCallableStatements(boolean flag) { this.cacheCallableStatements.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2880 */   public void setCachePreparedStatements(boolean flag) { this.cachePreparedStatements.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCacheResultSetMetadata(boolean property) {
/* 2887 */     this.cacheResultSetMetadata.setValue(property);
/* 2888 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2896 */   public void setCacheServerConfiguration(boolean flag) { this.cacheServerConfiguration.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2903 */   public void setCallableStatementCacheSize(int size) { this.callableStatementCacheSize.setValue(size); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2910 */   public void setCapitalizeDBMDTypes(boolean property) { this.capitalizeTypeNames.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2917 */   public void setCapitalizeTypeNames(boolean flag) { this.capitalizeTypeNames.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2924 */   public void setCharacterEncoding(String encoding) { this.characterEncoding.setValue(encoding); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2931 */   public void setCharacterSetResults(String characterSet) { this.characterSetResults.setValue(characterSet); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2938 */   public void setClobberStreamingResults(boolean flag) { this.clobberStreamingResults.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2945 */   public void setClobCharacterEncoding(String encoding) { this.clobCharacterEncoding.setValue(encoding); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2952 */   public void setConnectionCollation(String collation) { this.connectionCollation.setValue(collation); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2959 */   public void setConnectTimeout(int timeoutMs) { this.connectTimeout.setValue(timeoutMs); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2966 */   public void setContinueBatchOnError(boolean property) { this.continueBatchOnError.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2973 */   public void setCreateDatabaseIfNotExist(boolean flag) { this.createDatabaseIfNotExist.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2980 */   public void setDefaultFetchSize(int n) { this.defaultFetchSize.setValue(n); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2987 */   public void setDetectServerPreparedStmts(boolean property) { this.detectServerPreparedStmts.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2994 */   public void setDontTrackOpenResources(boolean flag) { this.dontTrackOpenResources.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3001 */   public void setDumpQueriesOnException(boolean flag) { this.dumpQueriesOnException.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3008 */   public void setDynamicCalendars(boolean flag) { this.dynamicCalendars.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3015 */   public void setElideSetAutoCommits(boolean flag) { this.elideSetAutoCommits.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3022 */   public void setEmptyStringsConvertToZero(boolean flag) { this.emptyStringsConvertToZero.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3029 */   public void setEmulateLocators(boolean property) { this.emulateLocators.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3036 */   public void setEmulateUnsupportedPstmts(boolean flag) { this.emulateUnsupportedPstmts.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3043 */   public void setEnablePacketDebug(boolean flag) { this.enablePacketDebug.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEncoding(String property) {
/* 3050 */     this.characterEncoding.setValue(property);
/* 3051 */     this.characterEncodingAsString = this.characterEncoding.getValueAsString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3059 */   public void setExplainSlowQueries(boolean flag) { this.explainSlowQueries.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3066 */   public void setFailOverReadOnly(boolean flag) { this.failOverReadOnly.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3073 */   public void setGatherPerformanceMetrics(boolean flag) { this.gatherPerformanceMetrics.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setHighAvailability(boolean property) {
/* 3082 */     this.autoReconnect.setValue(property);
/* 3083 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3090 */   public void setHoldResultsOpenOverStatementClose(boolean flag) { this.holdResultsOpenOverStatementClose.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3097 */   public void setIgnoreNonTxTables(boolean property) { this.ignoreNonTxTables.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3104 */   public void setInitialTimeout(int property) { this.initialTimeout.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3111 */   public void setIsInteractiveClient(boolean property) { this.isInteractiveClient.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3118 */   public void setJdbcCompliantTruncation(boolean flag) { this.jdbcCompliantTruncation.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3125 */   public void setLocatorFetchBufferSize(String value) throws SQLException { this.locatorFetchBufferSize.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3132 */   public void setLogger(String property) { this.loggerClassName.setValueAsObject(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3139 */   public void setLoggerClassName(String className) { this.loggerClassName.setValue(className); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3146 */   public void setLogSlowQueries(boolean flag) { this.logSlowQueries.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaintainTimeStats(boolean flag) {
/* 3153 */     this.maintainTimeStats.setValue(flag);
/* 3154 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3162 */   public void setMaxQuerySizeToLog(int sizeInBytes) { this.maxQuerySizeToLog.setValue(sizeInBytes); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3169 */   public void setMaxReconnects(int property) { this.maxReconnects.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int property) {
/* 3176 */     this.maxRows.setValue(property);
/* 3177 */     this.maxRowsAsInt = this.maxRows.getValueAsInt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3184 */   public void setMetadataCacheSize(int value) { this.metadataCacheSize.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3191 */   public void setNoDatetimeStringSync(boolean flag) { this.noDatetimeStringSync.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3198 */   public void setNullCatalogMeansCurrent(boolean value) { this.nullCatalogMeansCurrent.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3205 */   public void setNullNamePatternMatchesAll(boolean value) { this.nullNamePatternMatchesAll.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3212 */   public void setPacketDebugBufferSize(int size) { this.packetDebugBufferSize.setValue(size); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3219 */   public void setParanoid(boolean property) { this.paranoid.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3226 */   public void setPedantic(boolean property) { this.pedantic.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3233 */   public void setPreparedStatementCacheSize(int cacheSize) { this.preparedStatementCacheSize.setValue(cacheSize); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3240 */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) { this.preparedStatementCacheSqlLimit.setValue(cacheSqlLimit); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setProfileSql(boolean property) {
/* 3247 */     this.profileSQL.setValue(property);
/* 3248 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3255 */   public void setProfileSQL(boolean flag) { this.profileSQL.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3262 */   public void setPropertiesTransform(String value) { this.propertiesTransform.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3269 */   public void setQueriesBeforeRetryMaster(int property) { this.queriesBeforeRetryMaster.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReconnectAtTxEnd(boolean property) {
/* 3276 */     this.reconnectAtTxEnd.setValue(property);
/* 3277 */     this.reconnectTxAtEndAsBoolean = this.reconnectAtTxEnd.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3285 */   public void setRelaxAutoCommit(boolean property) { this.relaxAutoCommit.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3292 */   public void setReportMetricsIntervalMillis(int millis) { this.reportMetricsIntervalMillis.setValue(millis); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3299 */   public void setRequireSSL(boolean property) { this.requireSSL.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3306 */   public void setRetainStatementAfterResultSetClose(boolean flag) { this.retainStatementAfterResultSetClose.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3313 */   public void setRollbackOnPooledClose(boolean flag) { this.rollbackOnPooledClose.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3320 */   public void setRoundRobinLoadBalance(boolean flag) { this.roundRobinLoadBalance.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3327 */   public void setRunningCTS13(boolean flag) { this.runningCTS13.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3334 */   public void setSecondsBeforeRetryMaster(int property) { this.secondsBeforeRetryMaster.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3341 */   public void setServerTimezone(String property) { this.serverTimezone.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3348 */   public void setSessionVariables(String variables) { this.sessionVariables.setValue(variables); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3355 */   public void setSlowQueryThresholdMillis(int millis) { this.slowQueryThresholdMillis.setValue(millis); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3362 */   public void setSocketFactoryClassName(String property) { this.socketFactoryClassName.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3369 */   public void setSocketTimeout(int property) { this.socketTimeout.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3376 */   public void setStrictFloatingPoint(boolean property) { this.strictFloatingPoint.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3383 */   public void setStrictUpdates(boolean property) { this.strictUpdates.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3390 */   public void setTinyInt1isBit(boolean flag) { this.tinyInt1isBit.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3397 */   public void setTraceProtocol(boolean flag) { this.traceProtocol.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3404 */   public void setTransformedBitIsBoolean(boolean flag) { this.transformedBitIsBoolean.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3411 */   public void setUseCompression(boolean property) { this.useCompression.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3418 */   public void setUseFastIntParsing(boolean flag) { this.useFastIntParsing.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3425 */   public void setUseHostsInPrivileges(boolean property) { this.useHostsInPrivileges.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3432 */   public void setUseInformationSchema(boolean flag) { this.useInformationSchema.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3439 */   public void setUseLocalSessionState(boolean flag) { this.useLocalSessionState.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseOldUTF8Behavior(boolean flag) {
/* 3446 */     this.useOldUTF8Behavior.setValue(flag);
/* 3447 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3455 */   public void setUseOnlyServerErrorMessages(boolean flag) { this.useOnlyServerErrorMessages.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3462 */   public void setUseReadAheadInput(boolean flag) { this.useReadAheadInput.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3469 */   public void setUseServerPreparedStmts(boolean flag) { this.detectServerPreparedStmts.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3476 */   public void setUseSqlStateCodes(boolean flag) { this.useSqlStateCodes.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3483 */   public void setUseSSL(boolean property) { this.useSSL.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3490 */   public void setUseStreamLengthsInPrepStmts(boolean property) { this.useStreamLengthsInPrepStmts.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3497 */   public void setUseTimezone(boolean property) { this.useTimezone.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3504 */   public void setUseUltraDevWorkAround(boolean property) { this.useUltraDevWorkAround.setValue(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3511 */   public void setUseUnbufferedInput(boolean flag) { this.useUnbufferedInput.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseUnicode(boolean flag) {
/* 3518 */     this.useUnicode.setValue(flag);
/* 3519 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag) {
/* 3526 */     this.useUsageAdvisor.setValue(useUsageAdvisorFlag);
/* 3527 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3535 */   public void setYearIsDateType(boolean flag) { this.yearIsDateType.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3542 */   public void setZeroDateTimeBehavior(String behavior) { this.zeroDateTimeBehavior.setValue(behavior); }
/*      */ 
/*      */   
/*      */   protected void storeToRef(Reference ref) throws SQLException {
/* 3546 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */     
/* 3548 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 3549 */       Field propertyField = PROPERTY_LIST.get(i);
/*      */ 
/*      */       
/*      */       try {
/* 3553 */         ConnectionProperty propToStore = (ConnectionProperty)propertyField.get(this);
/*      */ 
/*      */         
/* 3556 */         if (ref != null) {
/* 3557 */           propToStore.storeTo(ref);
/*      */         }
/* 3559 */       } catch (IllegalAccessException iae) {
/* 3560 */         throw SQLError.createSQLException(Messages.getString("ConnectionProperties.errorNotExpected"), getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3569 */   public boolean useUnbufferedInput() { return this.useUnbufferedInput.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3576 */   public boolean getUseCursorFetch() { return this.useCursorFetch.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3583 */   public void setUseCursorFetch(boolean flag) { this.useCursorFetch.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3590 */   public boolean getOverrideSupportsIntegrityEnhancementFacility() { return this.overrideSupportsIntegrityEnhancementFacility.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3597 */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) { this.overrideSupportsIntegrityEnhancementFacility.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3604 */   public boolean getNoTimezoneConversionForTimeType() { return this.noTimezoneConversionForTimeType.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3611 */   public void setNoTimezoneConversionForTimeType(boolean flag) { this.noTimezoneConversionForTimeType.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3618 */   public boolean getUseJDBCCompliantTimezoneShift() { return this.useJDBCCompliantTimezoneShift.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3625 */   public void setUseJDBCCompliantTimezoneShift(boolean flag) { this.useJDBCCompliantTimezoneShift.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3632 */   public boolean getAutoClosePStmtStreams() { return this.autoClosePStmtStreams.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3639 */   public void setAutoClosePStmtStreams(boolean flag) { this.autoClosePStmtStreams.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3646 */   public boolean getProcessEscapeCodesForPrepStmts() { return this.processEscapeCodesForPrepStmts.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3653 */   public void setProcessEscapeCodesForPrepStmts(boolean flag) { this.processEscapeCodesForPrepStmts.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3660 */   public boolean getUseGmtMillisForDatetimes() { return this.useGmtMillisForDatetimes.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3667 */   public void setUseGmtMillisForDatetimes(boolean flag) { this.useGmtMillisForDatetimes.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3674 */   public boolean getDumpMetadataOnColumnNotFound() { return this.dumpMetadataOnColumnNotFound.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3681 */   public void setDumpMetadataOnColumnNotFound(boolean flag) { this.dumpMetadataOnColumnNotFound.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3688 */   public String getResourceId() { return this.resourceId.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3695 */   public void setResourceId(String resourceId) { this.resourceId.setValue(resourceId); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3702 */   public boolean getRewriteBatchedStatements() { return this.rewriteBatchedStatements.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3709 */   public void setRewriteBatchedStatements(boolean flag) { this.rewriteBatchedStatements.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3716 */   public boolean getJdbcCompliantTruncationForReads() { return this.jdbcCompliantTruncationForReads; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3724 */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) { this.jdbcCompliantTruncationForReads = jdbcCompliantTruncationForReads; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3731 */   public boolean getUseJvmCharsetConverters() { return this.useJvmCharsetConverters.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3738 */   public void setUseJvmCharsetConverters(boolean flag) { this.useJvmCharsetConverters.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3745 */   public boolean getPinGlobalTxToPhysicalConnection() { return this.pinGlobalTxToPhysicalConnection.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3752 */   public void setPinGlobalTxToPhysicalConnection(boolean flag) { this.pinGlobalTxToPhysicalConnection.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3764 */   public void setGatherPerfMetrics(boolean flag) { setGatherPerformanceMetrics(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3771 */   public boolean getGatherPerfMetrics() { return getGatherPerformanceMetrics(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3778 */   public void setUltraDevHack(boolean flag) { setUseUltraDevWorkAround(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3785 */   public boolean getUltraDevHack() { return getUseUltraDevWorkAround(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3792 */   public void setInteractiveClient(boolean property) { setIsInteractiveClient(property); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3799 */   public void setSocketFactory(String name) { setSocketFactoryClassName(name); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3806 */   public String getSocketFactory() { return getSocketFactoryClassName(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3813 */   public void setUseServerPrepStmts(boolean flag) { setUseServerPreparedStmts(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3820 */   public boolean getUseServerPrepStmts() { return getUseServerPreparedStmts(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3827 */   public void setCacheCallableStmts(boolean flag) { setCacheCallableStatements(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3834 */   public boolean getCacheCallableStmts() { return getCacheCallableStatements(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3841 */   public void setCachePrepStmts(boolean flag) { setCachePreparedStatements(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3848 */   public boolean getCachePrepStmts() { return getCachePreparedStatements(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3855 */   public void setCallableStmtCacheSize(int cacheSize) { setCallableStatementCacheSize(cacheSize); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3862 */   public int getCallableStmtCacheSize() { return getCallableStatementCacheSize(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3869 */   public void setPrepStmtCacheSize(int cacheSize) { setPreparedStatementCacheSize(cacheSize); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3876 */   public int getPrepStmtCacheSize() { return getPreparedStatementCacheSize(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3883 */   public void setPrepStmtCacheSqlLimit(int sqlLimit) { setPreparedStatementCacheSqlLimit(sqlLimit); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3890 */   public int getPrepStmtCacheSqlLimit() { return getPreparedStatementCacheSqlLimit(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3897 */   public boolean getNoAccessToProcedureBodies() { return this.noAccessToProcedureBodies.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3904 */   public void setNoAccessToProcedureBodies(boolean flag) { this.noAccessToProcedureBodies.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3911 */   public boolean getUseOldAliasMetadataBehavior() { return this.useOldAliasMetadataBehavior.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3918 */   public void setUseOldAliasMetadataBehavior(boolean flag) { this.useOldAliasMetadataBehavior.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3925 */   public String getClientCertificateKeyStorePassword() { return this.clientCertificateKeyStorePassword.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3933 */   public void setClientCertificateKeyStorePassword(String value) { this.clientCertificateKeyStorePassword.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3940 */   public String getClientCertificateKeyStoreType() { return this.clientCertificateKeyStoreType.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3948 */   public void setClientCertificateKeyStoreType(String value) { this.clientCertificateKeyStoreType.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3955 */   public String getClientCertificateKeyStoreUrl() { return this.clientCertificateKeyStoreUrl.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3963 */   public void setClientCertificateKeyStoreUrl(String value) { this.clientCertificateKeyStoreUrl.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3970 */   public String getTrustCertificateKeyStorePassword() { return this.trustCertificateKeyStorePassword.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3978 */   public void setTrustCertificateKeyStorePassword(String value) { this.trustCertificateKeyStorePassword.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3985 */   public String getTrustCertificateKeyStoreType() { return this.trustCertificateKeyStoreType.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3993 */   public void setTrustCertificateKeyStoreType(String value) { this.trustCertificateKeyStoreType.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4000 */   public String getTrustCertificateKeyStoreUrl() { return this.trustCertificateKeyStoreUrl.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4008 */   public void setTrustCertificateKeyStoreUrl(String value) { this.trustCertificateKeyStoreUrl.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4015 */   public boolean getUseSSPSCompatibleTimezoneShift() { return this.useSSPSCompatibleTimezoneShift.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4022 */   public void setUseSSPSCompatibleTimezoneShift(boolean flag) { this.useSSPSCompatibleTimezoneShift.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4029 */   public boolean getTreatUtilDateAsTimestamp() { return this.treatUtilDateAsTimestamp.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4036 */   public void setTreatUtilDateAsTimestamp(boolean flag) { this.treatUtilDateAsTimestamp.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4043 */   public boolean getUseFastDateParsing() { return this.useFastDateParsing.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4050 */   public void setUseFastDateParsing(boolean flag) { this.useFastDateParsing.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4057 */   public String getLocalSocketAddress() { return this.localSocketAddress.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4064 */   public void setLocalSocketAddress(String address) { this.localSocketAddress.setValue(address); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4071 */   public void setUseConfigs(String configs) { this.useConfigs.setValue(configs); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4078 */   public String getUseConfigs() { return this.useConfigs.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4086 */   public boolean getGenerateSimpleParameterMetadata() { return this.generateSimpleParameterMetadata.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4093 */   public void setGenerateSimpleParameterMetadata(boolean flag) { this.generateSimpleParameterMetadata.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4100 */   public boolean getLogXaCommands() { return this.logXaCommands.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4107 */   public void setLogXaCommands(boolean flag) { this.logXaCommands.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4114 */   public int getResultSetSizeThreshold() { return this.resultSetSizeThreshold.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4121 */   public void setResultSetSizeThreshold(int threshold) { this.resultSetSizeThreshold.setValue(threshold); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4128 */   public int getNetTimeoutForStreamingResults() { return this.netTimeoutForStreamingResults.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4135 */   public void setNetTimeoutForStreamingResults(int value) { this.netTimeoutForStreamingResults.setValue(value); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4142 */   public boolean getEnableQueryTimeouts() { return this.enableQueryTimeouts.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4149 */   public void setEnableQueryTimeouts(boolean flag) { this.enableQueryTimeouts.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4156 */   public boolean getPadCharsWithSpace() { return this.padCharsWithSpace.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4163 */   public void setPadCharsWithSpace(boolean flag) { this.padCharsWithSpace.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4170 */   public boolean getUseDynamicCharsetInfo() { return this.useDynamicCharsetInfo.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4177 */   public void setUseDynamicCharsetInfo(boolean flag) { this.useDynamicCharsetInfo.setValue(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4184 */   public String getClientInfoProvider() { return this.clientInfoProvider.getValueAsString(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4191 */   public void setClientInfoProvider(String classname) { this.clientInfoProvider.setValue(classname); }
/*      */ 
/*      */ 
/*      */   
/* 4195 */   public boolean getPopulateInsertRowWithDefaultValues() { return this.populateInsertRowWithDefaultValues.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4199 */   public void setPopulateInsertRowWithDefaultValues(boolean flag) { this.populateInsertRowWithDefaultValues.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4203 */   public String getLoadBalanceStrategy() { return this.loadBalanceStrategy.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4207 */   public void setLoadBalanceStrategy(String strategy) { this.loadBalanceStrategy.setValue(strategy); }
/*      */ 
/*      */ 
/*      */   
/* 4211 */   public boolean getTcpNoDelay() { return this.tcpNoDelay.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4215 */   public void setTcpNoDelay(boolean flag) { this.tcpNoDelay.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4219 */   public boolean getTcpKeepAlive() { return this.tcpKeepAlive.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4223 */   public void setTcpKeepAlive(boolean flag) { this.tcpKeepAlive.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4227 */   public int getTcpRcvBuf() { return this.tcpRcvBuf.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4231 */   public void setTcpRcvBuf(int bufSize) { this.tcpRcvBuf.setValue(bufSize); }
/*      */ 
/*      */ 
/*      */   
/* 4235 */   public int getTcpSndBuf() { return this.tcpSndBuf.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4239 */   public void setTcpSndBuf(int bufSize) { this.tcpSndBuf.setValue(bufSize); }
/*      */ 
/*      */ 
/*      */   
/* 4243 */   public int getTcpTrafficClass() { return this.tcpTrafficClass.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4247 */   public void setTcpTrafficClass(int classFlags) { this.tcpTrafficClass.setValue(classFlags); }
/*      */ 
/*      */ 
/*      */   
/* 4251 */   public boolean getUseNanosForElapsedTime() { return this.useNanosForElapsedTime.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4255 */   public void setUseNanosForElapsedTime(boolean flag) { this.useNanosForElapsedTime.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4259 */   public long getSlowQueryThresholdNanos() { return this.slowQueryThresholdNanos.getValueAsLong(); }
/*      */ 
/*      */ 
/*      */   
/* 4263 */   public void setSlowQueryThresholdNanos(long nanos) { this.slowQueryThresholdNanos.setValue(nanos); }
/*      */ 
/*      */ 
/*      */   
/* 4267 */   public String getStatementInterceptors() { return this.statementInterceptors.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4271 */   public void setStatementInterceptors(String value) { this.statementInterceptors.setValue(value); }
/*      */ 
/*      */ 
/*      */   
/* 4275 */   public boolean getUseDirectRowUnpack() { return this.useDirectRowUnpack.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4279 */   public void setUseDirectRowUnpack(boolean flag) { this.useDirectRowUnpack.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4283 */   public String getLargeRowSizeThreshold() { return this.largeRowSizeThreshold.getValueAsString(); }
/*      */ 
/*      */   
/*      */   public void setLargeRowSizeThreshold(String value) {
/*      */     try {
/* 4288 */       this.largeRowSizeThreshold.setValue(value);
/* 4289 */     } catch (SQLException sqlEx) {
/* 4290 */       RuntimeException ex = new RuntimeException(sqlEx.getMessage());
/* 4291 */       ex.initCause(sqlEx);
/*      */       
/* 4293 */       throw ex;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 4298 */   public boolean getUseBlobToStoreUTF8OutsideBMP() { return this.useBlobToStoreUTF8OutsideBMP.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4302 */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) { this.useBlobToStoreUTF8OutsideBMP.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4306 */   public String getUtf8OutsideBmpExcludedColumnNamePattern() { return this.utf8OutsideBmpExcludedColumnNamePattern.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4310 */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) { this.utf8OutsideBmpExcludedColumnNamePattern.setValue(regexPattern); }
/*      */ 
/*      */ 
/*      */   
/* 4314 */   public String getUtf8OutsideBmpIncludedColumnNamePattern() { return this.utf8OutsideBmpIncludedColumnNamePattern.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4318 */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) { this.utf8OutsideBmpIncludedColumnNamePattern.setValue(regexPattern); }
/*      */ 
/*      */ 
/*      */   
/* 4322 */   public boolean getIncludeInnodbStatusInDeadlockExceptions() { return this.includeInnodbStatusInDeadlockExceptions.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4326 */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) { this.includeInnodbStatusInDeadlockExceptions.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4330 */   public boolean getBlobsAreStrings() { return this.blobsAreStrings.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4334 */   public void setBlobsAreStrings(boolean flag) { this.blobsAreStrings.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4338 */   public boolean getFunctionsNeverReturnBlobs() { return this.functionsNeverReturnBlobs.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4342 */   public void setFunctionsNeverReturnBlobs(boolean flag) { this.functionsNeverReturnBlobs.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4346 */   public boolean getAutoSlowLog() { return this.autoSlowLog.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4350 */   public void setAutoSlowLog(boolean flag) { this.autoSlowLog.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4354 */   public String getConnectionLifecycleInterceptors() { return this.connectionLifecycleInterceptors.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4358 */   public void setConnectionLifecycleInterceptors(String interceptors) { this.connectionLifecycleInterceptors.setValue(interceptors); }
/*      */ 
/*      */ 
/*      */   
/* 4362 */   public String getProfilerEventHandler() { return this.profilerEventHandler.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4366 */   public void setProfilerEventHandler(String handler) { this.profilerEventHandler.setValue(handler); }
/*      */ 
/*      */ 
/*      */   
/* 4370 */   public boolean getVerifyServerCertificate() { return this.verifyServerCertificate.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4374 */   public void setVerifyServerCertificate(boolean flag) { this.verifyServerCertificate.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4378 */   public boolean getUseLegacyDatetimeCode() { return this.useLegacyDatetimeCode.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4382 */   public void setUseLegacyDatetimeCode(boolean flag) { this.useLegacyDatetimeCode.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4386 */   public int getSelfDestructOnPingSecondsLifetime() { return this.selfDestructOnPingSecondsLifetime.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4390 */   public void setSelfDestructOnPingSecondsLifetime(int seconds) { this.selfDestructOnPingSecondsLifetime.setValue(seconds); }
/*      */ 
/*      */ 
/*      */   
/* 4394 */   public int getSelfDestructOnPingMaxOperations() { return this.selfDestructOnPingMaxOperations.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4398 */   public void setSelfDestructOnPingMaxOperations(int maxOperations) { this.selfDestructOnPingMaxOperations.setValue(maxOperations); }
/*      */ 
/*      */ 
/*      */   
/* 4402 */   public boolean getUseColumnNamesInFindColumn() { return this.useColumnNamesInFindColumn.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4406 */   public void setUseColumnNamesInFindColumn(boolean flag) { this.useColumnNamesInFindColumn.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4410 */   public boolean getUseLocalTransactionState() { return this.useLocalTransactionState.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4414 */   public void setUseLocalTransactionState(boolean flag) { this.useLocalTransactionState.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4418 */   public boolean getCompensateOnDuplicateKeyUpdateCounts() { return this.compensateOnDuplicateKeyUpdateCounts.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4422 */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) { this.compensateOnDuplicateKeyUpdateCounts.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4426 */   public int getLoadBalanceBlacklistTimeout() { return this.loadBalanceBlacklistTimeout.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4430 */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) { this.loadBalanceBlacklistTimeout.setValue(loadBalanceBlacklistTimeout); }
/*      */ 
/*      */ 
/*      */   
/* 4434 */   public void setRetriesAllDown(int retriesAllDown) { this.retriesAllDown.setValue(retriesAllDown); }
/*      */ 
/*      */ 
/*      */   
/* 4438 */   public int getRetriesAllDown() { return this.retriesAllDown.getValueAsInt(); }
/*      */ 
/*      */ 
/*      */   
/* 4442 */   public void setUseAffectedRows(boolean flag) { this.useAffectedRows.setValue(flag); }
/*      */ 
/*      */ 
/*      */   
/* 4446 */   public boolean getUseAffectedRows() { return this.useAffectedRows.getValueAsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 4450 */   public void setPasswordCharacterEncoding(String characterSet) { this.passwordCharacterEncoding.setValue(characterSet); }
/*      */ 
/*      */ 
/*      */   
/* 4454 */   public String getPasswordCharacterEncoding() { return this.passwordCharacterEncoding.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4458 */   public void setExceptionInterceptors(String exceptionInterceptors) { this.exceptionInterceptors.setValue(exceptionInterceptors); }
/*      */ 
/*      */ 
/*      */   
/* 4462 */   public String getExceptionInterceptors() { return this.exceptionInterceptors.getValueAsString(); }
/*      */ 
/*      */ 
/*      */   
/* 4466 */   public void setMaxAllowedPacket(int max) { this.maxAllowedPacket.setValue(max); }
/*      */ 
/*      */ 
/*      */   
/* 4470 */   public int getMaxAllowedPacket() { return this.maxAllowedPacket.getValueAsInt(); }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/ConnectionPropertiesImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */