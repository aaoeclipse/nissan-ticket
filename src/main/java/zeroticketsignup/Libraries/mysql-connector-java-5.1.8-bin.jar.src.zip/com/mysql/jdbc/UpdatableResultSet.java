/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandlerFactory;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class UpdatableResultSet
/*      */   extends ResultSetImpl
/*      */ {
/*   46 */   protected static final byte[] STREAM_DATA_MARKER = "** STREAM DATA **".getBytes();
/*      */ 
/*      */   
/*      */   protected SingleByteCharsetConverter charConverter;
/*      */ 
/*      */   
/*      */   private String charEncoding;
/*      */ 
/*      */   
/*      */   private byte[][] defaultColumnValue;
/*      */   
/*   57 */   private PreparedStatement deleter = null;
/*      */   
/*   59 */   private String deleteSQL = null;
/*      */ 
/*      */   
/*      */   private boolean initializedCharConverter = false;
/*      */   
/*   64 */   protected PreparedStatement inserter = null;
/*      */   
/*   66 */   private String insertSQL = null;
/*      */ 
/*      */   
/*      */   private boolean isUpdatable = false;
/*      */ 
/*      */   
/*   72 */   private String notUpdatableReason = null;
/*      */ 
/*      */   
/*   75 */   private List primaryKeyIndicies = null;
/*      */   
/*      */   private String qualifiedAndQuotedTableName;
/*      */   
/*   79 */   private String quotedIdChar = null;
/*      */ 
/*      */   
/*      */   private PreparedStatement refresher;
/*      */   
/*   84 */   private String refreshSQL = null;
/*      */ 
/*      */   
/*      */   private ResultSetRow savedCurrentRow;
/*      */ 
/*      */   
/*   90 */   protected PreparedStatement updater = null;
/*      */ 
/*      */   
/*   93 */   private String updateSQL = null;
/*      */   
/*      */   private boolean populateInserterWithDefaultValues = false;
/*      */   
/*   97 */   private Map databasesUsedToTablesUsed = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected UpdatableResultSet(String catalog, Field[] fields, RowData tuples, ConnectionImpl conn, StatementImpl creatorStmt) throws SQLException {
/*  118 */     super(catalog, fields, tuples, conn, creatorStmt);
/*  119 */     checkUpdatability();
/*  120 */     this.populateInserterWithDefaultValues = this.connection.getPopulateInsertRowWithDefaultValues();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  163 */   public synchronized boolean absolute(int row) throws SQLException { return super.absolute(row); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  179 */   public synchronized void afterLast() throws SQLException { super.afterLast(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   public synchronized void beforeFirst() throws SQLException { super.beforeFirst(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void cancelRowUpdates() throws SQLException {
/*  209 */     checkClosed();
/*      */     
/*  211 */     if (this.doingUpdates) {
/*  212 */       this.doingUpdates = false;
/*  213 */       this.updater.clearParameters();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkRowPos() throws SQLException {
/*  223 */     checkClosed();
/*      */     
/*  225 */     if (!this.onInsertRow) {
/*  226 */       super.checkRowPos();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkUpdatability() throws SQLException {
/*      */     try {
/*  238 */       if (this.fields == null) {
/*      */         return;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  248 */       String singleTableName = null;
/*  249 */       String catalogName = null;
/*      */       
/*  251 */       int primaryKeyCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  258 */       if (this.catalog == null || this.catalog.length() == 0) {
/*  259 */         this.catalog = this.fields[0].getDatabaseName();
/*      */         
/*  261 */         if (this.catalog == null || this.catalog.length() == 0) {
/*  262 */           throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  268 */       if (this.fields.length > 0) {
/*  269 */         singleTableName = this.fields[0].getOriginalTableName();
/*  270 */         catalogName = this.fields[0].getDatabaseName();
/*      */         
/*  272 */         if (singleTableName == null) {
/*  273 */           singleTableName = this.fields[0].getTableName();
/*  274 */           catalogName = this.catalog;
/*      */         } 
/*      */         
/*  277 */         if (singleTableName != null && singleTableName.length() == 0) {
/*  278 */           this.isUpdatable = false;
/*  279 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */           
/*      */           return;
/*      */         } 
/*      */         
/*  284 */         if (this.fields[0].isPrimaryKey()) {
/*  285 */           primaryKeyCount++;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  291 */         for (int i = 1; i < this.fields.length; i++) {
/*  292 */           String otherTableName = this.fields[i].getOriginalTableName();
/*  293 */           String otherCatalogName = this.fields[i].getDatabaseName();
/*      */           
/*  295 */           if (otherTableName == null) {
/*  296 */             otherTableName = this.fields[i].getTableName();
/*  297 */             otherCatalogName = this.catalog;
/*      */           } 
/*      */           
/*  300 */           if (otherTableName != null && otherTableName.length() == 0) {
/*  301 */             this.isUpdatable = false;
/*  302 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  307 */           if (singleTableName == null || !otherTableName.equals(singleTableName)) {
/*      */             
/*  309 */             this.isUpdatable = false;
/*  310 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.0");
/*      */ 
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  316 */           if (catalogName == null || !otherCatalogName.equals(catalogName)) {
/*      */             
/*  318 */             this.isUpdatable = false;
/*  319 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.1");
/*      */             
/*      */             return;
/*      */           } 
/*      */           
/*  324 */           if (this.fields[i].isPrimaryKey()) {
/*  325 */             primaryKeyCount++;
/*      */           }
/*      */         } 
/*      */         
/*  329 */         if (singleTableName == null || singleTableName.length() == 0) {
/*  330 */           this.isUpdatable = false;
/*  331 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.2");
/*      */           
/*      */           return;
/*      */         } 
/*      */       } else {
/*  336 */         this.isUpdatable = false;
/*  337 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.3");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  342 */       if (this.connection.getStrictUpdates()) {
/*  343 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */         
/*  345 */         ResultSet rs = null;
/*  346 */         HashMap primaryKeyNames = new HashMap();
/*      */         
/*      */         try {
/*  349 */           rs = dbmd.getPrimaryKeys(catalogName, null, singleTableName);
/*      */           
/*  351 */           while (rs.next()) {
/*  352 */             String keyName = rs.getString(4);
/*  353 */             keyName = keyName.toUpperCase();
/*  354 */             primaryKeyNames.put(keyName, keyName);
/*      */           } 
/*      */         } finally {
/*  357 */           if (rs != null) {
/*      */             try {
/*  359 */               rs.close();
/*  360 */             } catch (Exception ex) {
/*  361 */               AssertionFailedException.shouldNotHappen(ex);
/*      */             } 
/*      */             
/*  364 */             rs = null;
/*      */           } 
/*      */         } 
/*      */         
/*  368 */         int existingPrimaryKeysCount = primaryKeyNames.size();
/*      */         
/*  370 */         if (existingPrimaryKeysCount == 0) {
/*  371 */           this.isUpdatable = false;
/*  372 */           this.notUpdatableReason = Messages.getString("NotUpdatableReason.5");
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */ 
/*      */         
/*  380 */         for (int i = 0; i < this.fields.length; i++) {
/*  381 */           if (this.fields[i].isPrimaryKey()) {
/*  382 */             String columnNameUC = this.fields[i].getName().toUpperCase();
/*      */ 
/*      */             
/*  385 */             if (primaryKeyNames.remove(columnNameUC) == null) {
/*      */               
/*  387 */               String originalName = this.fields[i].getOriginalName();
/*      */               
/*  389 */               if (originalName != null && 
/*  390 */                 primaryKeyNames.remove(originalName.toUpperCase()) == null) {
/*      */ 
/*      */                 
/*  393 */                 this.isUpdatable = false;
/*  394 */                 this.notUpdatableReason = Messages.getString("NotUpdatableReason.6", new Object[] { originalName });
/*      */ 
/*      */                 
/*      */                 return;
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/*  404 */         this.isUpdatable = primaryKeyNames.isEmpty();
/*      */         
/*  406 */         if (!this.isUpdatable) {
/*  407 */           if (existingPrimaryKeysCount > 1) {
/*  408 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.7");
/*      */           } else {
/*  410 */             this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  420 */       if (primaryKeyCount == 0) {
/*  421 */         this.isUpdatable = false;
/*  422 */         this.notUpdatableReason = Messages.getString("NotUpdatableReason.4");
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/*  427 */       this.isUpdatable = true;
/*  428 */       this.notUpdatableReason = null;
/*      */       
/*      */       return;
/*  431 */     } catch (SQLException sqlEx) {
/*  432 */       this.isUpdatable = false;
/*  433 */       this.notUpdatableReason = sqlEx.getMessage();
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void deleteRow() throws SQLException {
/*  448 */     checkClosed();
/*      */     
/*  450 */     if (!this.isUpdatable) {
/*  451 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  454 */     if (this.onInsertRow)
/*  455 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"), getExceptionInterceptor()); 
/*  456 */     if (this.rowData.size() == 0)
/*  457 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"), getExceptionInterceptor()); 
/*  458 */     if (isBeforeFirst())
/*  459 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"), getExceptionInterceptor()); 
/*  460 */     if (isAfterLast()) {
/*  461 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"), getExceptionInterceptor());
/*      */     }
/*      */     
/*  464 */     if (this.deleter == null) {
/*  465 */       if (this.deleteSQL == null) {
/*  466 */         generateStatements();
/*      */       }
/*      */       
/*  469 */       this.deleter = (PreparedStatement)this.connection.clientPrepareStatement(this.deleteSQL);
/*      */     } 
/*      */ 
/*      */     
/*  473 */     this.deleter.clearParameters();
/*      */     
/*  475 */     String characterEncoding = null;
/*      */     
/*  477 */     if (this.connection.getUseUnicode()) {
/*  478 */       characterEncoding = this.connection.getEncoding();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  485 */       int numKeys = this.primaryKeyIndicies.size();
/*      */       
/*  487 */       if (numKeys == 1) {
/*  488 */         int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */         
/*  490 */         String currentVal = (characterEncoding == null) ? new String(this.thisRow.getColumnValue(index)) : new String(this.thisRow.getColumnValue(index), characterEncoding);
/*      */ 
/*      */         
/*  493 */         this.deleter.setString(1, currentVal);
/*      */       } else {
/*  495 */         for (int i = 0; i < numKeys; i++) {
/*  496 */           int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */           
/*  498 */           String currentVal = (characterEncoding == null) ? new String(this.thisRow.getColumnValue(index)) : new String(this.thisRow.getColumnValue(index), characterEncoding);
/*      */ 
/*      */ 
/*      */           
/*  502 */           this.deleter.setString(i + 1, currentVal);
/*      */         } 
/*      */       } 
/*      */       
/*  506 */       this.deleter.executeUpdate();
/*  507 */       this.rowData.removeRow(this.rowData.getCurrentRowNumber());
/*  508 */     } catch (UnsupportedEncodingException encodingEx) {
/*  509 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.39", new Object[] { this.charEncoding }), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void extractDefaultValues() throws SQLException { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */     //   4: invokevirtual getMetaData : ()Ljava/sql/DatabaseMetaData;
/*      */     //   7: astore_1
/*      */     //   8: aload_0
/*      */     //   9: aload_0
/*      */     //   10: getfield fields : [Lcom/mysql/jdbc/Field;
/*      */     //   13: arraylength
/*      */     //   14: anewarray [B
/*      */     //   17: putfield defaultColumnValue : [[B
/*      */     //   20: aconst_null
/*      */     //   21: astore_2
/*      */     //   22: aload_0
/*      */     //   23: getfield databasesUsedToTablesUsed : Ljava/util/Map;
/*      */     //   26: invokeinterface entrySet : ()Ljava/util/Set;
/*      */     //   31: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   36: astore_3
/*      */     //   37: aload_3
/*      */     //   38: invokeinterface hasNext : ()Z
/*      */     //   43: ifeq -> 259
/*      */     //   46: aload_3
/*      */     //   47: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   52: checkcast java/util/Map$Entry
/*      */     //   55: astore #4
/*      */     //   57: aload #4
/*      */     //   59: invokeinterface getKey : ()Ljava/lang/Object;
/*      */     //   64: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   67: astore #5
/*      */     //   69: aload #4
/*      */     //   71: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   76: checkcast java/util/Map
/*      */     //   79: invokeinterface entrySet : ()Ljava/util/Set;
/*      */     //   84: invokeinterface iterator : ()Ljava/util/Iterator;
/*      */     //   89: astore #6
/*      */     //   91: aload #6
/*      */     //   93: invokeinterface hasNext : ()Z
/*      */     //   98: ifeq -> 256
/*      */     //   101: aload #6
/*      */     //   103: invokeinterface next : ()Ljava/lang/Object;
/*      */     //   108: checkcast java/util/Map$Entry
/*      */     //   111: astore #7
/*      */     //   113: aload #7
/*      */     //   115: invokeinterface getKey : ()Ljava/lang/Object;
/*      */     //   120: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   123: astore #8
/*      */     //   125: aload #7
/*      */     //   127: invokeinterface getValue : ()Ljava/lang/Object;
/*      */     //   132: checkcast java/util/Map
/*      */     //   135: astore #9
/*      */     //   137: aload_1
/*      */     //   138: aload_0
/*      */     //   139: getfield catalog : Ljava/lang/String;
/*      */     //   142: aconst_null
/*      */     //   143: aload #8
/*      */     //   145: ldc '%'
/*      */     //   147: invokeinterface getColumns : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/sql/ResultSet;
/*      */     //   152: astore_2
/*      */     //   153: aload_2
/*      */     //   154: invokeinterface next : ()Z
/*      */     //   159: ifeq -> 223
/*      */     //   162: aload_2
/*      */     //   163: ldc 'COLUMN_NAME'
/*      */     //   165: invokeinterface getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   170: astore #10
/*      */     //   172: aload_2
/*      */     //   173: ldc 'COLUMN_DEF'
/*      */     //   175: invokeinterface getBytes : (Ljava/lang/String;)[B
/*      */     //   180: astore #11
/*      */     //   182: aload #9
/*      */     //   184: aload #10
/*      */     //   186: invokeinterface containsKey : (Ljava/lang/Object;)Z
/*      */     //   191: ifeq -> 220
/*      */     //   194: aload #9
/*      */     //   196: aload #10
/*      */     //   198: invokeinterface get : (Ljava/lang/Object;)Ljava/lang/Object;
/*      */     //   203: checkcast java/lang/Integer
/*      */     //   206: invokevirtual intValue : ()I
/*      */     //   209: istore #12
/*      */     //   211: aload_0
/*      */     //   212: getfield defaultColumnValue : [[B
/*      */     //   215: iload #12
/*      */     //   217: aload #11
/*      */     //   219: aastore
/*      */     //   220: goto -> 153
/*      */     //   223: jsr -> 237
/*      */     //   226: goto -> 253
/*      */     //   229: astore #13
/*      */     //   231: jsr -> 237
/*      */     //   234: aload #13
/*      */     //   236: athrow
/*      */     //   237: astore #14
/*      */     //   239: aload_2
/*      */     //   240: ifnull -> 251
/*      */     //   243: aload_2
/*      */     //   244: invokeinterface close : ()V
/*      */     //   249: aconst_null
/*      */     //   250: astore_2
/*      */     //   251: ret #14
/*      */     //   253: goto -> 91
/*      */     //   256: goto -> 37
/*      */     //   259: return
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #516	-> 0
/*      */     //   #517	-> 8
/*      */     //   #519	-> 20
/*      */     //   #520	-> 22
/*      */     //   #522	-> 37
/*      */     //   #523	-> 46
/*      */     //   #524	-> 57
/*      */     //   #526	-> 69
/*      */     //   #528	-> 91
/*      */     //   #529	-> 101
/*      */     //   #530	-> 113
/*      */     //   #531	-> 125
/*      */     //   #534	-> 137
/*      */     //   #537	-> 153
/*      */     //   #538	-> 162
/*      */     //   #539	-> 172
/*      */     //   #541	-> 182
/*      */     //   #542	-> 194
/*      */     //   #544	-> 211
/*      */     //   #547	-> 223
/*      */     //   #553	-> 226
/*      */     //   #548	-> 229
/*      */     //   #549	-> 243
/*      */     //   #551	-> 249
/*      */     //   #556	-> 259
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   211	9	12	localColumnIndex	I
/*      */     //   172	48	10	columnName	Ljava/lang/String;
/*      */     //   182	38	11	defaultValue	[B
/*      */     //   113	140	7	tableEntry	Ljava/util/Map$Entry;
/*      */     //   125	128	8	tableName	Ljava/lang/String;
/*      */     //   137	116	9	columnNamesToIndices	Ljava/util/Map;
/*      */     //   57	199	4	dbEntry	Ljava/util/Map$Entry;
/*      */     //   69	187	5	databaseName	Ljava/lang/String;
/*      */     //   91	165	6	referencedTables	Ljava/util/Iterator;
/*      */     //   0	260	0	this	Lcom/mysql/jdbc/UpdatableResultSet;
/*      */     //   8	252	1	dbmd	Ljava/sql/DatabaseMetaData;
/*      */     //   22	238	2	columnsResultSet	Ljava/sql/ResultSet;
/*      */     //   37	223	3	referencedDbs	Ljava/util/Iterator;
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   137	226	229	finally
/*      */     //   229	234	229	finally }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  572 */   public synchronized boolean first() throws SQLException { return super.first(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void generateStatements() throws SQLException {
/*  585 */     if (!this.isUpdatable) {
/*  586 */       this.doingUpdates = false;
/*  587 */       this.onInsertRow = false;
/*      */       
/*  589 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     } 
/*      */     
/*  592 */     String quotedId = getQuotedIdChar();
/*      */     
/*  594 */     Map tableNamesSoFar = null;
/*      */     
/*  596 */     if (this.connection.lowerCaseTableNames()) {
/*  597 */       tableNamesSoFar = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*  598 */       this.databasesUsedToTablesUsed = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */     } else {
/*  600 */       tableNamesSoFar = new TreeMap();
/*  601 */       this.databasesUsedToTablesUsed = new TreeMap();
/*      */     } 
/*      */     
/*  604 */     this.primaryKeyIndicies = new ArrayList();
/*      */     
/*  606 */     StringBuffer fieldValues = new StringBuffer();
/*  607 */     StringBuffer keyValues = new StringBuffer();
/*  608 */     StringBuffer columnNames = new StringBuffer();
/*  609 */     StringBuffer insertPlaceHolders = new StringBuffer();
/*  610 */     StringBuffer allTablesBuf = new StringBuffer();
/*  611 */     Map columnIndicesToTable = new HashMap();
/*      */     
/*  613 */     boolean firstTime = true;
/*  614 */     boolean keysFirstTime = true;
/*      */     
/*  616 */     String equalsStr = this.connection.versionMeetsMinimum(3, 23, 0) ? "<=>" : "=";
/*      */ 
/*      */     
/*  619 */     for (int i = 0; i < this.fields.length; i++) {
/*  620 */       StringBuffer tableNameBuffer = new StringBuffer();
/*  621 */       Map updColumnNameToIndex = null;
/*      */ 
/*      */       
/*  624 */       if (this.fields[i].getOriginalTableName() != null) {
/*      */         
/*  626 */         String databaseName = this.fields[i].getDatabaseName();
/*      */         
/*  628 */         if (databaseName != null && databaseName.length() > 0) {
/*  629 */           tableNameBuffer.append(quotedId);
/*  630 */           tableNameBuffer.append(databaseName);
/*  631 */           tableNameBuffer.append(quotedId);
/*  632 */           tableNameBuffer.append('.');
/*      */         } 
/*      */         
/*  635 */         String tableOnlyName = this.fields[i].getOriginalTableName();
/*      */         
/*  637 */         tableNameBuffer.append(quotedId);
/*  638 */         tableNameBuffer.append(tableOnlyName);
/*  639 */         tableNameBuffer.append(quotedId);
/*      */         
/*  641 */         String fqTableName = tableNameBuffer.toString();
/*      */         
/*  643 */         if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  644 */           if (!tableNamesSoFar.isEmpty()) {
/*  645 */             allTablesBuf.append(',');
/*      */           }
/*      */           
/*  648 */           allTablesBuf.append(fqTableName);
/*  649 */           tableNamesSoFar.put(fqTableName, fqTableName);
/*      */         } 
/*      */         
/*  652 */         columnIndicesToTable.put(new Integer(i), fqTableName);
/*      */         
/*  654 */         updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(databaseName, tableOnlyName);
/*      */       } else {
/*  656 */         String tableOnlyName = this.fields[i].getTableName();
/*      */         
/*  658 */         if (tableOnlyName != null) {
/*  659 */           tableNameBuffer.append(quotedId);
/*  660 */           tableNameBuffer.append(tableOnlyName);
/*  661 */           tableNameBuffer.append(quotedId);
/*      */           
/*  663 */           String fqTableName = tableNameBuffer.toString();
/*      */           
/*  665 */           if (!tableNamesSoFar.containsKey(fqTableName)) {
/*  666 */             if (!tableNamesSoFar.isEmpty()) {
/*  667 */               allTablesBuf.append(',');
/*      */             }
/*      */             
/*  670 */             allTablesBuf.append(fqTableName);
/*  671 */             tableNamesSoFar.put(fqTableName, fqTableName);
/*      */           } 
/*      */           
/*  674 */           columnIndicesToTable.put(new Integer(i), fqTableName);
/*      */           
/*  676 */           updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(this.catalog, tableOnlyName);
/*      */         } 
/*      */       } 
/*      */       
/*  680 */       String originalColumnName = this.fields[i].getOriginalName();
/*  681 */       String columnName = null;
/*      */       
/*  683 */       if (this.connection.getIO().hasLongColumnInfo() && originalColumnName != null && originalColumnName.length() > 0) {
/*      */ 
/*      */         
/*  686 */         columnName = originalColumnName;
/*      */       } else {
/*  688 */         columnName = this.fields[i].getName();
/*      */       } 
/*      */       
/*  691 */       if (updColumnNameToIndex != null && columnName != null) {
/*  692 */         updColumnNameToIndex.put(columnName, new Integer(i));
/*      */       }
/*      */       
/*  695 */       String originalTableName = this.fields[i].getOriginalTableName();
/*  696 */       String tableName = null;
/*      */       
/*  698 */       if (this.connection.getIO().hasLongColumnInfo() && originalTableName != null && originalTableName.length() > 0) {
/*      */ 
/*      */         
/*  701 */         tableName = originalTableName;
/*      */       } else {
/*  703 */         tableName = this.fields[i].getTableName();
/*      */       } 
/*      */       
/*  706 */       StringBuffer fqcnBuf = new StringBuffer();
/*  707 */       String databaseName = this.fields[i].getDatabaseName();
/*      */       
/*  709 */       if (databaseName != null && databaseName.length() > 0) {
/*  710 */         fqcnBuf.append(quotedId);
/*  711 */         fqcnBuf.append(databaseName);
/*  712 */         fqcnBuf.append(quotedId);
/*  713 */         fqcnBuf.append('.');
/*      */       } 
/*      */       
/*  716 */       fqcnBuf.append(quotedId);
/*  717 */       fqcnBuf.append(tableName);
/*  718 */       fqcnBuf.append(quotedId);
/*  719 */       fqcnBuf.append('.');
/*  720 */       fqcnBuf.append(quotedId);
/*  721 */       fqcnBuf.append(columnName);
/*  722 */       fqcnBuf.append(quotedId);
/*      */       
/*  724 */       String qualifiedColumnName = fqcnBuf.toString();
/*      */       
/*  726 */       if (this.fields[i].isPrimaryKey()) {
/*  727 */         this.primaryKeyIndicies.add(Constants.integerValueOf(i));
/*      */         
/*  729 */         if (!keysFirstTime) {
/*  730 */           keyValues.append(" AND ");
/*      */         } else {
/*  732 */           keysFirstTime = false;
/*      */         } 
/*      */         
/*  735 */         keyValues.append(qualifiedColumnName);
/*  736 */         keyValues.append(equalsStr);
/*  737 */         keyValues.append("?");
/*      */       } 
/*      */       
/*  740 */       if (firstTime) {
/*  741 */         firstTime = false;
/*  742 */         fieldValues.append("SET ");
/*      */       } else {
/*  744 */         fieldValues.append(",");
/*  745 */         columnNames.append(",");
/*  746 */         insertPlaceHolders.append(",");
/*      */       } 
/*      */       
/*  749 */       insertPlaceHolders.append("?");
/*      */       
/*  751 */       columnNames.append(qualifiedColumnName);
/*      */       
/*  753 */       fieldValues.append(qualifiedColumnName);
/*  754 */       fieldValues.append("=?");
/*      */     } 
/*      */     
/*  757 */     this.qualifiedAndQuotedTableName = allTablesBuf.toString();
/*      */     
/*  759 */     this.updateSQL = "UPDATE " + this.qualifiedAndQuotedTableName + " " + fieldValues.toString() + " WHERE " + keyValues.toString();
/*      */ 
/*      */     
/*  762 */     this.insertSQL = "INSERT INTO " + this.qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")";
/*      */ 
/*      */     
/*  765 */     this.refreshSQL = "SELECT " + columnNames.toString() + " FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString();
/*      */ 
/*      */     
/*  768 */     this.deleteSQL = "DELETE FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Map getColumnsToIndexMapForTableAndDB(String databaseName, String tableName) {
/*  775 */     Map tablesUsedToColumnsMap = (Map)this.databasesUsedToTablesUsed.get(databaseName);
/*      */     
/*  777 */     if (tablesUsedToColumnsMap == null) {
/*  778 */       if (this.connection.lowerCaseTableNames()) {
/*  779 */         tablesUsedToColumnsMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
/*      */       } else {
/*  781 */         tablesUsedToColumnsMap = new TreeMap();
/*      */       } 
/*      */       
/*  784 */       this.databasesUsedToTablesUsed.put(databaseName, tablesUsedToColumnsMap);
/*      */     } 
/*      */     
/*  787 */     Map nameToIndex = (Map)tablesUsedToColumnsMap.get(tableName);
/*      */     
/*  789 */     if (nameToIndex == null) {
/*  790 */       nameToIndex = new HashMap();
/*  791 */       tablesUsedToColumnsMap.put(tableName, nameToIndex);
/*      */     } 
/*      */     
/*  794 */     return nameToIndex;
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized SingleByteCharsetConverter getCharConverter() throws SQLException {
/*  799 */     if (!this.initializedCharConverter) {
/*  800 */       this.initializedCharConverter = true;
/*      */       
/*  802 */       if (this.connection.getUseUnicode()) {
/*  803 */         this.charEncoding = this.connection.getEncoding();
/*  804 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  809 */     return this.charConverter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  822 */   public int getConcurrency() throws SQLException { return this.isUpdatable ? 1008 : 1007; }
/*      */ 
/*      */   
/*      */   private synchronized String getQuotedIdChar() throws SQLException {
/*  826 */     if (this.quotedIdChar == null) {
/*  827 */       boolean useQuotedIdentifiers = this.connection.supportsQuotedIdentifiers();
/*      */ 
/*      */       
/*  830 */       if (useQuotedIdentifiers) {
/*  831 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*  832 */         this.quotedIdChar = dbmd.getIdentifierQuoteString();
/*      */       } else {
/*  834 */         this.quotedIdChar = "";
/*      */       } 
/*      */     } 
/*      */     
/*  838 */     return this.quotedIdChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void insertRow() throws SQLException {
/*  851 */     checkClosed();
/*      */     
/*  853 */     if (!this.onInsertRow) {
/*  854 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"), getExceptionInterceptor());
/*      */     }
/*      */     
/*  857 */     this.inserter.executeUpdate();
/*      */     
/*  859 */     long autoIncrementId = this.inserter.getLastInsertID();
/*  860 */     int numFields = this.fields.length;
/*  861 */     byte[][] newRow = new byte[numFields][];
/*      */     
/*  863 */     for (int i = 0; i < numFields; i++) {
/*  864 */       if (this.inserter.isNull(i)) {
/*  865 */         newRow[i] = null;
/*      */       } else {
/*  867 */         newRow[i] = this.inserter.getBytesRepresentation(i);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  874 */       if (this.fields[i].isAutoIncrement() && autoIncrementId > 0L) {
/*  875 */         newRow[i] = String.valueOf(autoIncrementId).getBytes();
/*  876 */         this.inserter.setBytesNoEscapeNoQuotes(i + 1, newRow[i]);
/*      */       } 
/*      */     } 
/*      */     
/*  880 */     ResultSetRow resultSetRow = new ByteArrayRow(newRow, getExceptionInterceptor());
/*      */     
/*  882 */     refreshRow(this.inserter, resultSetRow);
/*      */     
/*  884 */     this.rowData.addRow(resultSetRow);
/*  885 */     resetInserter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  902 */   public synchronized boolean isAfterLast() throws SQLException { return super.isAfterLast(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  919 */   public synchronized boolean isBeforeFirst() throws SQLException { return super.isBeforeFirst(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  935 */   public synchronized boolean isFirst() throws SQLException { return super.isFirst(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  954 */   public synchronized boolean isLast() throws SQLException { return super.isLast(); }
/*      */ 
/*      */ 
/*      */   
/*  958 */   boolean isUpdatable() { return this.isUpdatable; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  975 */   public synchronized boolean last() throws SQLException { return super.last(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void moveToCurrentRow() throws SQLException {
/*  989 */     checkClosed();
/*      */     
/*  991 */     if (!this.isUpdatable) {
/*  992 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/*  995 */     if (this.onInsertRow) {
/*  996 */       this.onInsertRow = false;
/*  997 */       this.thisRow = this.savedCurrentRow;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void moveToInsertRow() throws SQLException {
/* 1019 */     checkClosed();
/*      */     
/* 1021 */     if (!this.isUpdatable) {
/* 1022 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 1025 */     if (this.inserter == null) {
/* 1026 */       if (this.insertSQL == null) {
/* 1027 */         generateStatements();
/*      */       }
/*      */       
/* 1030 */       this.inserter = (PreparedStatement)this.connection.clientPrepareStatement(this.insertSQL);
/*      */       
/* 1032 */       if (this.populateInserterWithDefaultValues) {
/* 1033 */         extractDefaultValues();
/*      */       }
/*      */       
/* 1036 */       resetInserter();
/*      */     } else {
/* 1038 */       resetInserter();
/*      */     } 
/*      */     
/* 1041 */     int numFields = this.fields.length;
/*      */     
/* 1043 */     this.onInsertRow = true;
/* 1044 */     this.doingUpdates = false;
/* 1045 */     this.savedCurrentRow = this.thisRow;
/* 1046 */     byte[][] newRowData = new byte[numFields][];
/* 1047 */     this.thisRow = new ByteArrayRow(newRowData, getExceptionInterceptor());
/*      */     
/* 1049 */     for (int i = 0; i < numFields; i++) {
/* 1050 */       if (!this.populateInserterWithDefaultValues) {
/* 1051 */         this.inserter.setBytesNoEscapeNoQuotes(i + 1, "DEFAULT".getBytes());
/*      */         
/* 1053 */         newRowData = (byte[][])null;
/*      */       }
/* 1055 */       else if (this.defaultColumnValue[i] != null) {
/* 1056 */         Field f = this.fields[i];
/*      */         
/* 1058 */         switch (f.getMysqlType()) {
/*      */           
/*      */           case 7:
/*      */           case 10:
/*      */           case 11:
/*      */           case 12:
/*      */           case 14:
/* 1065 */             if ((this.defaultColumnValue[i]).length > 7 && this.defaultColumnValue[i][0] == 67 && this.defaultColumnValue[i][1] == 85 && this.defaultColumnValue[i][2] == 82 && this.defaultColumnValue[i][3] == 82 && this.defaultColumnValue[i][4] == 69 && this.defaultColumnValue[i][5] == 78 && this.defaultColumnValue[i][6] == 84 && this.defaultColumnValue[i][7] == 95) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1074 */               this.inserter.setBytesNoEscapeNoQuotes(i + 1, this.defaultColumnValue[i]);
/*      */               break;
/*      */             } 
/*      */ 
/*      */           
/*      */           default:
/* 1080 */             this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false, false);
/*      */             break;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1086 */         byte[] defaultValueCopy = new byte[(this.defaultColumnValue[i]).length];
/* 1087 */         System.arraycopy(this.defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
/*      */         
/* 1089 */         newRowData[i] = defaultValueCopy;
/*      */       } else {
/* 1091 */         this.inserter.setNull(i + 1, 0);
/* 1092 */         newRowData[i] = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1118 */   public synchronized boolean next() throws SQLException { return super.next(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1137 */   public synchronized boolean prev() throws SQLException { return super.prev(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1159 */   public synchronized boolean previous() throws SQLException { return super.previous(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void realClose(boolean calledExplicitly) throws SQLException {
/* 1172 */     if (this.isClosed) {
/*      */       return;
/*      */     }
/*      */     
/* 1176 */     SQLException sqlEx = null;
/*      */     
/* 1178 */     if (this.useUsageAdvisor && 
/* 1179 */       this.deleter == null && this.inserter == null && this.refresher == null && this.updater == null) {
/*      */       
/* 1181 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */       
/* 1183 */       String message = Messages.getString("UpdatableResultSet.34");
/*      */       
/* 1185 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1199 */       if (this.deleter != null) {
/* 1200 */         this.deleter.close();
/*      */       }
/* 1202 */     } catch (SQLException ex) {
/* 1203 */       sqlEx = ex;
/*      */     } 
/*      */     
/*      */     try {
/* 1207 */       if (this.inserter != null) {
/* 1208 */         this.inserter.close();
/*      */       }
/* 1210 */     } catch (SQLException ex) {
/* 1211 */       sqlEx = ex;
/*      */     } 
/*      */     
/*      */     try {
/* 1215 */       if (this.refresher != null) {
/* 1216 */         this.refresher.close();
/*      */       }
/* 1218 */     } catch (SQLException ex) {
/* 1219 */       sqlEx = ex;
/*      */     } 
/*      */     
/*      */     try {
/* 1223 */       if (this.updater != null) {
/* 1224 */         this.updater.close();
/*      */       }
/* 1226 */     } catch (SQLException ex) {
/* 1227 */       sqlEx = ex;
/*      */     } 
/*      */     
/* 1230 */     super.realClose(calledExplicitly);
/*      */     
/* 1232 */     if (sqlEx != null) {
/* 1233 */       throw sqlEx;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void refreshRow() throws SQLException {
/* 1258 */     checkClosed();
/*      */     
/* 1260 */     if (!this.isUpdatable) {
/* 1261 */       throw new NotUpdatable();
/*      */     }
/*      */     
/* 1264 */     if (this.onInsertRow)
/* 1265 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"), getExceptionInterceptor()); 
/* 1266 */     if (this.rowData.size() == 0)
/* 1267 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"), getExceptionInterceptor()); 
/* 1268 */     if (isBeforeFirst())
/* 1269 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"), getExceptionInterceptor()); 
/* 1270 */     if (isAfterLast()) {
/* 1271 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"), getExceptionInterceptor());
/*      */     }
/*      */     
/* 1274 */     refreshRow(this.updater, this.thisRow);
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized void refreshRow(PreparedStatement updateInsertStmt, ResultSetRow rowToRefresh) throws SQLException {
/* 1279 */     if (this.refresher == null) {
/* 1280 */       if (this.refreshSQL == null) {
/* 1281 */         generateStatements();
/*      */       }
/*      */       
/* 1284 */       this.refresher = (PreparedStatement)this.connection.clientPrepareStatement(this.refreshSQL);
/*      */     } 
/*      */ 
/*      */     
/* 1288 */     this.refresher.clearParameters();
/*      */     
/* 1290 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1292 */     if (numKeys == 1) {
/* 1293 */       byte[] dataFrom = null;
/* 1294 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */       
/* 1296 */       if (!this.doingUpdates && !this.onInsertRow) {
/* 1297 */         dataFrom = rowToRefresh.getColumnValue(index);
/*      */       } else {
/* 1299 */         dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */ 
/*      */         
/* 1302 */         if (updateInsertStmt.isNull(index) || dataFrom.length == 0) {
/* 1303 */           dataFrom = rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1305 */           dataFrom = stripBinaryPrefix(dataFrom);
/*      */         } 
/*      */       } 
/*      */       
/* 1309 */       this.refresher.setBytesNoEscape(1, dataFrom);
/*      */     } else {
/* 1311 */       for (int i = 0; i < numKeys; i++) {
/* 1312 */         byte[] dataFrom = null;
/* 1313 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */ 
/*      */         
/* 1316 */         if (!this.doingUpdates && !this.onInsertRow) {
/* 1317 */           dataFrom = rowToRefresh.getColumnValue(index);
/*      */         } else {
/* 1319 */           dataFrom = updateInsertStmt.getBytesRepresentation(index);
/*      */ 
/*      */           
/* 1322 */           if (updateInsertStmt.isNull(index) || dataFrom.length == 0) {
/* 1323 */             dataFrom = rowToRefresh.getColumnValue(index);
/*      */           } else {
/* 1325 */             dataFrom = stripBinaryPrefix(dataFrom);
/*      */           } 
/*      */         } 
/*      */         
/* 1329 */         this.refresher.setBytesNoEscape(i + 1, dataFrom);
/*      */       } 
/*      */     } 
/*      */     
/* 1333 */     ResultSet rs = null;
/*      */     
/*      */     try {
/* 1336 */       rs = this.refresher.executeQuery();
/*      */       
/* 1338 */       int numCols = rs.getMetaData().getColumnCount();
/*      */       
/* 1340 */       if (rs.next()) {
/* 1341 */         for (int i = 0; i < numCols; i++) {
/* 1342 */           byte[] val = rs.getBytes(i + 1);
/*      */           
/* 1344 */           if (val == null || rs.wasNull()) {
/* 1345 */             rowToRefresh.setColumnValue(i, null);
/*      */           } else {
/* 1347 */             rowToRefresh.setColumnValue(i, rs.getBytes(i + 1));
/*      */           } 
/*      */         } 
/*      */       } else {
/* 1351 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     
/*      */     } finally {
/*      */       
/* 1356 */       if (rs != null) {
/*      */         try {
/* 1358 */           rs.close();
/* 1359 */         } catch (SQLException ex) {}
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1393 */   public synchronized boolean relative(int rows) throws SQLException { return super.relative(rows); }
/*      */ 
/*      */   
/*      */   private void resetInserter() throws SQLException {
/* 1397 */     this.inserter.clearParameters();
/*      */     
/* 1399 */     for (int i = 0; i < this.fields.length; i++) {
/* 1400 */       this.inserter.setNull(i + 1, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1420 */   public synchronized boolean rowDeleted() throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1438 */   public synchronized boolean rowInserted() throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1456 */   public synchronized boolean rowUpdated() throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1466 */   protected void setResultSetConcurrency(int concurrencyFlag) { super.setResultSetConcurrency(concurrencyFlag); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1480 */   private byte[] stripBinaryPrefix(byte[] dataFrom) { return StringUtils.stripEnclosure(dataFrom, "_binary'", "'"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void syncUpdate() throws SQLException {
/* 1491 */     if (this.updater == null) {
/* 1492 */       if (this.updateSQL == null) {
/* 1493 */         generateStatements();
/*      */       }
/*      */       
/* 1496 */       this.updater = (PreparedStatement)this.connection.clientPrepareStatement(this.updateSQL);
/*      */     } 
/*      */ 
/*      */     
/* 1500 */     int numFields = this.fields.length;
/* 1501 */     this.updater.clearParameters();
/*      */     
/* 1503 */     for (int i = 0; i < numFields; i++) {
/* 1504 */       if (this.thisRow.getColumnValue(i) != null) {
/* 1505 */         this.updater.setBytes(i + 1, this.thisRow.getColumnValue(i), this.fields[i].isBinary(), false);
/*      */       } else {
/*      */         
/* 1508 */         this.updater.setNull(i + 1, 0);
/*      */       } 
/*      */     } 
/*      */     
/* 1512 */     int numKeys = this.primaryKeyIndicies.size();
/*      */     
/* 1514 */     if (numKeys == 1) {
/* 1515 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/* 1516 */       byte[] keyData = this.thisRow.getColumnValue(index);
/* 1517 */       this.updater.setBytes(numFields + 1, keyData, false, false);
/*      */     } else {
/* 1519 */       for (int i = 0; i < numKeys; i++) {
/* 1520 */         byte[] currentVal = this.thisRow.getColumnValue(((Integer)this.primaryKeyIndicies.get(i)).intValue());
/*      */ 
/*      */         
/* 1523 */         if (currentVal != null) {
/* 1524 */           this.updater.setBytes(numFields + i + 1, currentVal, false, false);
/*      */         } else {
/*      */           
/* 1527 */           this.updater.setNull(numFields + i + 1, 0);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException {
/* 1552 */     if (!this.onInsertRow) {
/* 1553 */       if (!this.doingUpdates) {
/* 1554 */         this.doingUpdates = true;
/* 1555 */         syncUpdate();
/*      */       } 
/*      */       
/* 1558 */       this.updater.setAsciiStream(columnIndex, x, length);
/*      */     } else {
/* 1560 */       this.inserter.setAsciiStream(columnIndex, x, length);
/* 1561 */       this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1584 */   public synchronized void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException { updateAsciiStream(findColumn(columnName), x, length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException {
/* 1603 */     if (!this.onInsertRow) {
/* 1604 */       if (!this.doingUpdates) {
/* 1605 */         this.doingUpdates = true;
/* 1606 */         syncUpdate();
/*      */       } 
/*      */       
/* 1609 */       this.updater.setBigDecimal(columnIndex, x);
/*      */     } else {
/* 1611 */       this.inserter.setBigDecimal(columnIndex, x);
/*      */       
/* 1613 */       if (x == null) {
/* 1614 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1616 */         this.thisRow.setColumnValue(columnIndex - 1, x.toString().getBytes());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1637 */   public synchronized void updateBigDecimal(String columnName, BigDecimal x) throws SQLException { updateBigDecimal(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException {
/* 1659 */     if (!this.onInsertRow) {
/* 1660 */       if (!this.doingUpdates) {
/* 1661 */         this.doingUpdates = true;
/* 1662 */         syncUpdate();
/*      */       } 
/*      */       
/* 1665 */       this.updater.setBinaryStream(columnIndex, x, length);
/*      */     } else {
/* 1667 */       this.inserter.setBinaryStream(columnIndex, x, length);
/*      */       
/* 1669 */       if (x == null) {
/* 1670 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1672 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1696 */   public synchronized void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException { updateBinaryStream(findColumn(columnName), x, length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateBlob(int columnIndex, Blob blob) throws SQLException {
/* 1704 */     if (!this.onInsertRow) {
/* 1705 */       if (!this.doingUpdates) {
/* 1706 */         this.doingUpdates = true;
/* 1707 */         syncUpdate();
/*      */       } 
/*      */       
/* 1710 */       this.updater.setBlob(columnIndex, blob);
/*      */     } else {
/* 1712 */       this.inserter.setBlob(columnIndex, blob);
/*      */       
/* 1714 */       if (blob == null) {
/* 1715 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1717 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1727 */   public synchronized void updateBlob(String columnName, Blob blob) throws SQLException { updateBlob(findColumn(columnName), blob); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateBoolean(int columnIndex, boolean x) throws SQLException {
/* 1746 */     if (!this.onInsertRow) {
/* 1747 */       if (!this.doingUpdates) {
/* 1748 */         this.doingUpdates = true;
/* 1749 */         syncUpdate();
/*      */       } 
/*      */       
/* 1752 */       this.updater.setBoolean(columnIndex, x);
/*      */     } else {
/* 1754 */       this.inserter.setBoolean(columnIndex, x);
/*      */       
/* 1756 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1777 */   public synchronized void updateBoolean(String columnName, boolean x) throws SQLException { updateBoolean(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateByte(int columnIndex, byte x) throws SQLException {
/* 1796 */     if (!this.onInsertRow) {
/* 1797 */       if (!this.doingUpdates) {
/* 1798 */         this.doingUpdates = true;
/* 1799 */         syncUpdate();
/*      */       } 
/*      */       
/* 1802 */       this.updater.setByte(columnIndex, x);
/*      */     } else {
/* 1804 */       this.inserter.setByte(columnIndex, x);
/*      */       
/* 1806 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1827 */   public synchronized void updateByte(String columnName, byte x) throws SQLException { updateByte(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateBytes(int columnIndex, byte[] x) throws SQLException {
/* 1846 */     if (!this.onInsertRow) {
/* 1847 */       if (!this.doingUpdates) {
/* 1848 */         this.doingUpdates = true;
/* 1849 */         syncUpdate();
/*      */       } 
/*      */       
/* 1852 */       this.updater.setBytes(columnIndex, x);
/*      */     } else {
/* 1854 */       this.inserter.setBytes(columnIndex, x);
/*      */       
/* 1856 */       this.thisRow.setColumnValue(columnIndex - 1, x);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1876 */   public synchronized void updateBytes(String columnName, byte[] x) throws SQLException { updateBytes(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException {
/* 1898 */     if (!this.onInsertRow) {
/* 1899 */       if (!this.doingUpdates) {
/* 1900 */         this.doingUpdates = true;
/* 1901 */         syncUpdate();
/*      */       } 
/*      */       
/* 1904 */       this.updater.setCharacterStream(columnIndex, x, length);
/*      */     } else {
/* 1906 */       this.inserter.setCharacterStream(columnIndex, x, length);
/*      */       
/* 1908 */       if (x == null) {
/* 1909 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       } else {
/* 1911 */         this.thisRow.setColumnValue(columnIndex - 1, STREAM_DATA_MARKER);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1935 */   public synchronized void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException { updateCharacterStream(findColumn(columnName), reader, length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int columnIndex, Clob clob) throws SQLException {
/* 1943 */     if (clob == null) {
/* 1944 */       updateNull(columnIndex);
/*      */     } else {
/* 1946 */       updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateDate(int columnIndex, Date x) throws SQLException {
/* 1967 */     if (!this.onInsertRow) {
/* 1968 */       if (!this.doingUpdates) {
/* 1969 */         this.doingUpdates = true;
/* 1970 */         syncUpdate();
/*      */       } 
/*      */       
/* 1973 */       this.updater.setDate(columnIndex, x);
/*      */     } else {
/* 1975 */       this.inserter.setDate(columnIndex, x);
/*      */       
/* 1977 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1998 */   public synchronized void updateDate(String columnName, Date x) throws SQLException { updateDate(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateDouble(int columnIndex, double x) throws SQLException {
/* 2017 */     if (!this.onInsertRow) {
/* 2018 */       if (!this.doingUpdates) {
/* 2019 */         this.doingUpdates = true;
/* 2020 */         syncUpdate();
/*      */       } 
/*      */       
/* 2023 */       this.updater.setDouble(columnIndex, x);
/*      */     } else {
/* 2025 */       this.inserter.setDouble(columnIndex, x);
/*      */       
/* 2027 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2048 */   public synchronized void updateDouble(String columnName, double x) throws SQLException { updateDouble(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateFloat(int columnIndex, float x) throws SQLException {
/* 2067 */     if (!this.onInsertRow) {
/* 2068 */       if (!this.doingUpdates) {
/* 2069 */         this.doingUpdates = true;
/* 2070 */         syncUpdate();
/*      */       } 
/*      */       
/* 2073 */       this.updater.setFloat(columnIndex, x);
/*      */     } else {
/* 2075 */       this.inserter.setFloat(columnIndex, x);
/*      */       
/* 2077 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2098 */   public synchronized void updateFloat(String columnName, float x) throws SQLException { updateFloat(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateInt(int columnIndex, int x) throws SQLException {
/* 2117 */     if (!this.onInsertRow) {
/* 2118 */       if (!this.doingUpdates) {
/* 2119 */         this.doingUpdates = true;
/* 2120 */         syncUpdate();
/*      */       } 
/*      */       
/* 2123 */       this.updater.setInt(columnIndex, x);
/*      */     } else {
/* 2125 */       this.inserter.setInt(columnIndex, x);
/*      */       
/* 2127 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2148 */   public synchronized void updateInt(String columnName, int x) throws SQLException { updateInt(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateLong(int columnIndex, long x) throws SQLException {
/* 2167 */     if (!this.onInsertRow) {
/* 2168 */       if (!this.doingUpdates) {
/* 2169 */         this.doingUpdates = true;
/* 2170 */         syncUpdate();
/*      */       } 
/*      */       
/* 2173 */       this.updater.setLong(columnIndex, x);
/*      */     } else {
/* 2175 */       this.inserter.setLong(columnIndex, x);
/*      */       
/* 2177 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2198 */   public synchronized void updateLong(String columnName, long x) throws SQLException { updateLong(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateNull(int columnIndex) throws SQLException {
/* 2214 */     if (!this.onInsertRow) {
/* 2215 */       if (!this.doingUpdates) {
/* 2216 */         this.doingUpdates = true;
/* 2217 */         syncUpdate();
/*      */       } 
/*      */       
/* 2220 */       this.updater.setNull(columnIndex, 0);
/*      */     } else {
/* 2222 */       this.inserter.setNull(columnIndex, 0);
/*      */       
/* 2224 */       this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2241 */   public synchronized void updateNull(String columnName) throws SQLException { updateNull(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateObject(int columnIndex, Object x) throws SQLException {
/* 2260 */     if (!this.onInsertRow) {
/* 2261 */       if (!this.doingUpdates) {
/* 2262 */         this.doingUpdates = true;
/* 2263 */         syncUpdate();
/*      */       } 
/*      */       
/* 2266 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2268 */       this.inserter.setObject(columnIndex, x);
/*      */       
/* 2270 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateObject(int columnIndex, Object x, int scale) throws SQLException {
/* 2295 */     if (!this.onInsertRow) {
/* 2296 */       if (!this.doingUpdates) {
/* 2297 */         this.doingUpdates = true;
/* 2298 */         syncUpdate();
/*      */       } 
/*      */       
/* 2301 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2303 */       this.inserter.setObject(columnIndex, x);
/*      */       
/* 2305 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2326 */   public synchronized void updateObject(String columnName, Object x) throws SQLException { updateObject(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2349 */   public synchronized void updateObject(String columnName, Object x, int scale) throws SQLException { updateObject(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateRow() throws SQLException {
/* 2363 */     if (!this.isUpdatable) {
/* 2364 */       throw new NotUpdatable(this.notUpdatableReason);
/*      */     }
/*      */     
/* 2367 */     if (this.doingUpdates) {
/* 2368 */       this.updater.executeUpdate();
/* 2369 */       refreshRow();
/* 2370 */       this.doingUpdates = false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2376 */     syncUpdate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateShort(int columnIndex, short x) throws SQLException {
/* 2395 */     if (!this.onInsertRow) {
/* 2396 */       if (!this.doingUpdates) {
/* 2397 */         this.doingUpdates = true;
/* 2398 */         syncUpdate();
/*      */       } 
/*      */       
/* 2401 */       this.updater.setShort(columnIndex, x);
/*      */     } else {
/* 2403 */       this.inserter.setShort(columnIndex, x);
/*      */       
/* 2405 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2426 */   public synchronized void updateShort(String columnName, short x) throws SQLException { updateShort(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateString(int columnIndex, String x) throws SQLException {
/* 2445 */     checkClosed();
/*      */     
/* 2447 */     if (!this.onInsertRow) {
/* 2448 */       if (!this.doingUpdates) {
/* 2449 */         this.doingUpdates = true;
/* 2450 */         syncUpdate();
/*      */       } 
/*      */       
/* 2453 */       this.updater.setString(columnIndex, x);
/*      */     } else {
/* 2455 */       this.inserter.setString(columnIndex, x);
/*      */       
/* 2457 */       if (x == null) {
/* 2458 */         this.thisRow.setColumnValue(columnIndex - 1, null);
/*      */       }
/* 2460 */       else if (getCharConverter() != null) {
/* 2461 */         this.thisRow.setColumnValue(columnIndex - 1, StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2466 */         this.thisRow.setColumnValue(columnIndex - 1, x.getBytes());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2488 */   public synchronized void updateString(String columnName, String x) throws SQLException { updateString(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateTime(int columnIndex, Time x) throws SQLException {
/* 2507 */     if (!this.onInsertRow) {
/* 2508 */       if (!this.doingUpdates) {
/* 2509 */         this.doingUpdates = true;
/* 2510 */         syncUpdate();
/*      */       } 
/*      */       
/* 2513 */       this.updater.setTime(columnIndex, x);
/*      */     } else {
/* 2515 */       this.inserter.setTime(columnIndex, x);
/*      */       
/* 2517 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2538 */   public synchronized void updateTime(String columnName, Time x) throws SQLException { updateTime(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateTimestamp(int columnIndex, Timestamp x) throws SQLException {
/* 2557 */     if (!this.onInsertRow) {
/* 2558 */       if (!this.doingUpdates) {
/* 2559 */         this.doingUpdates = true;
/* 2560 */         syncUpdate();
/*      */       } 
/*      */       
/* 2563 */       this.updater.setTimestamp(columnIndex, x);
/*      */     } else {
/* 2565 */       this.inserter.setTimestamp(columnIndex, x);
/*      */       
/* 2567 */       this.thisRow.setColumnValue(columnIndex - 1, this.inserter.getBytesRepresentation(columnIndex - 1));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2588 */   public synchronized void updateTimestamp(String columnName, Timestamp x) throws SQLException { updateTimestamp(findColumn(columnName), x); }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/UpdatableResultSet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */