/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedPipeSocketFactory
/*     */   implements SocketFactory
/*     */ {
/*     */   private static final String NAMED_PIPE_PROP_NAME = "namedPipePath";
/*     */   private Socket namedPipeSocket;
/*     */   
/*     */   class NamedPipeSocket
/*     */     extends Socket
/*     */   {
/*     */     private boolean isClosed;
/*     */     private RandomAccessFile namedPipeFile;
/*     */     private final NamedPipeSocketFactory this$0;
/*     */     
/*     */     NamedPipeSocket(NamedPipeSocketFactory this$0, String filePath) throws IOException {
/*  49 */       this.this$0 = this$0; this.isClosed = false;
/*  50 */       if (filePath == null || filePath.length() == 0) {
/*  51 */         throw new IOException(Messages.getString("NamedPipeSocketFactory.4"));
/*     */       }
/*     */ 
/*     */       
/*  55 */       this.namedPipeFile = new RandomAccessFile(filePath, "rw");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public synchronized void close() throws IOException {
/*  62 */       this.namedPipeFile.close();
/*  63 */       this.isClosed = true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  70 */     public InputStream getInputStream() throws IOException { return new NamedPipeSocketFactory.RandomAccessFileInputStream(this.this$0, this.namedPipeFile); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  77 */     public OutputStream getOutputStream() throws IOException { return new NamedPipeSocketFactory.RandomAccessFileOutputStream(this.this$0, this.namedPipeFile); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     public boolean isClosed() { return this.isClosed; }
/*     */   }
/*     */   
/*     */   class RandomAccessFileInputStream
/*     */     extends InputStream
/*     */   {
/*     */     RandomAccessFile raFile;
/*     */     private final NamedPipeSocketFactory this$0;
/*     */     
/*     */     RandomAccessFileInputStream(NamedPipeSocketFactory this$0, RandomAccessFile file) {
/*  94 */       this.this$0 = this$0;
/*  95 */       this.raFile = file;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     public int available() throws IOException { return -1; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     public void close() throws IOException { this.raFile.close(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     public int read() throws IOException { return this.raFile.read(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     public int read(byte[] b) throws IOException { return this.raFile.read(b); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     public int read(byte[] b, int off, int len) throws IOException { return this.raFile.read(b, off, len); }
/*     */   }
/*     */   
/*     */   class RandomAccessFileOutputStream
/*     */     extends OutputStream
/*     */   {
/*     */     RandomAccessFile raFile;
/*     */     private final NamedPipeSocketFactory this$0;
/*     */     
/*     */     RandomAccessFileOutputStream(NamedPipeSocketFactory this$0, RandomAccessFile file) {
/* 140 */       this.this$0 = this$0;
/* 141 */       this.raFile = file;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     public void close() throws IOException { this.raFile.close(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     public void write(byte[] b) throws IOException { this.raFile.write(b); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     public void write(byte[] b, int off, int len) throws IOException { this.raFile.write(b, off, len); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void write(int b) throws IOException {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 187 */   public Socket afterHandshake() throws SocketException, IOException { return this.namedPipeSocket; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public Socket beforeHandshake() throws SocketException, IOException { return this.namedPipeSocket; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Socket connect(String host, int portNumber, Properties props) throws SocketException, IOException {
/* 202 */     String namedPipePath = props.getProperty("namedPipePath");
/*     */     
/* 204 */     if (namedPipePath == null) {
/* 205 */       namedPipePath = "\\\\.\\pipe\\MySQL";
/* 206 */     } else if (namedPipePath.length() == 0) {
/* 207 */       throw new SocketException(Messages.getString("NamedPipeSocketFactory.2") + "namedPipePath" + Messages.getString("NamedPipeSocketFactory.3"));
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 213 */     this.namedPipeSocket = new NamedPipeSocket(this, namedPipePath);
/*     */     
/* 215 */     return this.namedPipeSocket;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/NamedPipeSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */