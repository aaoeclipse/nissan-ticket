/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.rmi.server.UID;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Savepoint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlSavepoint
/*     */   implements Savepoint
/*     */ {
/*     */   private String savepointName;
/*     */   private ExceptionInterceptor exceptionInterceptor;
/*     */   
/*     */   private static String getUniqueId() {
/*  41 */     String uidStr = (new UID()).toString();
/*     */     
/*  43 */     int uidLength = uidStr.length();
/*     */     
/*  45 */     StringBuffer safeString = new StringBuffer(uidLength);
/*     */     
/*  47 */     for (int i = 0; i < uidLength; i++) {
/*  48 */       char c = uidStr.charAt(i);
/*     */       
/*  50 */       if (Character.isLetter(c) || Character.isDigit(c)) {
/*  51 */         safeString.append(c);
/*     */       } else {
/*  53 */         safeString.append('_');
/*     */       } 
/*     */     } 
/*     */     
/*  57 */     return safeString.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   MysqlSavepoint(ExceptionInterceptor exceptionInterceptor) throws SQLException { this(getUniqueId(), exceptionInterceptor); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   MysqlSavepoint(String name, ExceptionInterceptor exceptionInterceptor) throws SQLException {
/*  86 */     if (name == null || name.length() == 0) {
/*  87 */       throw SQLError.createSQLException("Savepoint name can not be NULL or empty", "S1009", exceptionInterceptor);
/*     */     }
/*     */ 
/*     */     
/*  91 */     this.savepointName = name;
/*     */     
/*  93 */     this.exceptionInterceptor = exceptionInterceptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public int getSavepointId() throws SQLException { throw SQLError.createSQLException("Only named savepoints are supported.", "S1C00", this.exceptionInterceptor); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public String getSavepointName() throws SQLException { return this.savepointName; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/MysqlSavepoint.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */