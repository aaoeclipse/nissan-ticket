/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import com.mysql.jdbc.ConnectionPropertiesImpl;
/*     */ import com.mysql.jdbc.NonRegisteringDriver;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import javax.naming.NamingException;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlDataSource
/*     */   extends ConnectionPropertiesImpl
/*     */   implements DataSource, Referenceable, Serializable
/*     */ {
/*  50 */   protected static NonRegisteringDriver mysqlDriver = null;
/*     */   
/*     */   static  {
/*     */     try {
/*  54 */       mysqlDriver = new NonRegisteringDriver();
/*  55 */     } catch (Exception E) {
/*  56 */       throw new RuntimeException("Can not load Driver class com.mysql.jdbc.Driver");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  62 */   protected PrintWriter logWriter = null;
/*     */ 
/*     */   
/*  65 */   protected String databaseName = null;
/*     */ 
/*     */   
/*  68 */   protected String encoding = null;
/*     */ 
/*     */   
/*  71 */   protected String hostName = null;
/*     */ 
/*     */   
/*  74 */   protected String password = null;
/*     */ 
/*     */   
/*  77 */   protected String profileSql = "false";
/*     */ 
/*     */   
/*  80 */   protected String url = null;
/*     */ 
/*     */   
/*  83 */   protected String user = null;
/*     */ 
/*     */   
/*     */   protected boolean explicitUrl = false;
/*     */ 
/*     */   
/*  89 */   protected int port = 3306;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   public Connection getConnection() throws SQLException { return getConnection(this.user, this.password); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection(String userID, String pass) throws SQLException {
/* 125 */     Properties props = new Properties();
/*     */     
/* 127 */     if (userID != null) {
/* 128 */       props.setProperty("user", userID);
/*     */     }
/*     */     
/* 131 */     if (pass != null) {
/* 132 */       props.setProperty("password", pass);
/*     */     }
/*     */     
/* 135 */     exposeAsProperties(props);
/*     */     
/* 137 */     return getConnection(props);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 147 */   public void setDatabaseName(String dbName) { this.databaseName = dbName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 156 */   public String getDatabaseName() { return (this.databaseName != null) ? this.databaseName : ""; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 165 */   public void setLogWriter(PrintWriter output) throws SQLException { this.logWriter = output; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 174 */   public PrintWriter getLogWriter() { return this.logWriter; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int seconds) throws SQLException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   public int getLoginTimeout() { return 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   public void setPassword(String pass) { this.password = pass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public void setPort(int p) { this.port = p; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 224 */   public int getPort() { return this.port; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public void setPortNumber(int p) { setPort(p); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 245 */   public int getPortNumber() { return getPort(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 258 */   public void setPropertiesViaRef(Reference ref) throws SQLException { initializeFromRef(ref); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() throws NamingException {
/* 270 */     String factoryName = "com.mysql.jdbc.jdbc2.optional.MysqlDataSourceFactory";
/* 271 */     Reference ref = new Reference(getClass().getName(), factoryName, null);
/* 272 */     ref.add(new StringRefAddr("user", getUser()));
/*     */     
/* 274 */     ref.add(new StringRefAddr("password", this.password));
/*     */     
/* 276 */     ref.add(new StringRefAddr("serverName", getServerName()));
/* 277 */     ref.add(new StringRefAddr("port", "" + getPort()));
/* 278 */     ref.add(new StringRefAddr("databaseName", getDatabaseName()));
/* 279 */     ref.add(new StringRefAddr("url", getUrl()));
/* 280 */     ref.add(new StringRefAddr("explicitUrl", String.valueOf(this.explicitUrl)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 287 */       storeToRef(ref);
/* 288 */     } catch (SQLException sqlEx) {
/* 289 */       throw new NamingException(sqlEx.getMessage());
/*     */     } 
/*     */     
/* 292 */     return ref;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   public void setServerName(String serverName) { this.hostName = serverName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 311 */   public String getServerName() { return (this.hostName != null) ? this.hostName : ""; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 326 */   public void setURL(String url) { setUrl(url); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 335 */   public String getURL() { return getUrl(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUrl(String url) {
/* 347 */     this.url = url;
/* 348 */     this.explicitUrl = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUrl() {
/* 357 */     if (!this.explicitUrl) {
/* 358 */       String builtUrl = "jdbc:mysql://";
/* 359 */       builtUrl = builtUrl + getServerName() + ":" + getPort() + "/" + getDatabaseName();
/*     */ 
/*     */       
/* 362 */       return builtUrl;
/*     */     } 
/*     */     
/* 365 */     return this.url;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 375 */   public void setUser(String userID) { this.user = userID; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 384 */   public String getUser() { return this.user; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Connection getConnection(Properties props) throws SQLException {
/* 400 */     String jdbcUrlToUse = null;
/*     */     
/* 402 */     if (!this.explicitUrl) {
/* 403 */       StringBuffer jdbcUrl = new StringBuffer("jdbc:mysql://");
/*     */       
/* 405 */       if (this.hostName != null) {
/* 406 */         jdbcUrl.append(this.hostName);
/*     */       }
/*     */       
/* 409 */       jdbcUrl.append(":");
/* 410 */       jdbcUrl.append(this.port);
/* 411 */       jdbcUrl.append("/");
/*     */       
/* 413 */       if (this.databaseName != null) {
/* 414 */         jdbcUrl.append(this.databaseName);
/*     */       }
/*     */       
/* 417 */       jdbcUrlToUse = jdbcUrl.toString();
/*     */     } else {
/* 419 */       jdbcUrlToUse = this.url;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 426 */     Properties urlProps = mysqlDriver.parseURL(jdbcUrlToUse, null);
/* 427 */     urlProps.remove("DBNAME");
/* 428 */     urlProps.remove("HOST");
/* 429 */     urlProps.remove("PORT");
/*     */     
/* 431 */     Iterator keys = urlProps.keySet().iterator();
/*     */     
/* 433 */     while (keys.hasNext()) {
/* 434 */       String key = keys.next();
/*     */       
/* 436 */       props.setProperty(key, urlProps.getProperty(key));
/*     */     } 
/*     */     
/* 439 */     return mysqlDriver.connect(jdbcUrlToUse, props);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/jdbc2/optional/MysqlDataSource.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */