/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MysqlXid
/*     */   implements Xid
/*     */ {
/*     */   int hash;
/*     */   byte[] myBqual;
/*     */   int myFormatId;
/*     */   byte[] myGtrid;
/*     */   
/*     */   public MysqlXid(byte[] gtrid, byte[] bqual, int formatId) {
/*  35 */     this.hash = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     this.myGtrid = gtrid;
/*  45 */     this.myBqual = bqual;
/*  46 */     this.myFormatId = formatId;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object another) {
/*  51 */     if (another instanceof Xid) {
/*  52 */       Xid anotherAsXid = (Xid)another;
/*     */       
/*  54 */       if (this.myFormatId != anotherAsXid.getFormatId()) {
/*  55 */         return false;
/*     */       }
/*     */       
/*  58 */       byte[] otherBqual = anotherAsXid.getBranchQualifier();
/*  59 */       byte[] otherGtrid = anotherAsXid.getGlobalTransactionId();
/*     */       
/*  61 */       if (otherGtrid != null && otherGtrid.length == this.myGtrid.length) {
/*  62 */         int length = otherGtrid.length;
/*     */         
/*  64 */         for (int i = 0; i < length; i++) {
/*  65 */           if (otherGtrid[i] != this.myGtrid[i]) {
/*  66 */             return false;
/*     */           }
/*     */         } 
/*     */         
/*  70 */         if (otherBqual != null && otherBqual.length == this.myBqual.length) {
/*  71 */           length = otherBqual.length;
/*     */           
/*  73 */           for (int i = 0; i < length; i++) {
/*  74 */             if (otherBqual[i] != this.myBqual[i]) {
/*  75 */               return false;
/*     */             }
/*     */           } 
/*     */         } else {
/*  79 */           return false;
/*     */         } 
/*     */         
/*  82 */         return true;
/*     */       } 
/*  84 */       return false;
/*     */     } 
/*     */     
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  92 */   public byte[] getBranchQualifier() { return this.myBqual; }
/*     */ 
/*     */ 
/*     */   
/*  96 */   public int getFormatId() { return this.myFormatId; }
/*     */ 
/*     */ 
/*     */   
/* 100 */   public byte[] getGlobalTransactionId() { return this.myGtrid; }
/*     */ 
/*     */   
/*     */   public synchronized int hashCode() {
/* 104 */     if (this.hash == 0) {
/* 105 */       for (int i = 0; i < this.myGtrid.length; i++) {
/* 106 */         this.hash = 33 * this.hash + this.myGtrid[i];
/*     */       }
/*     */     }
/*     */     
/* 110 */     return this.hash;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/jdbc2/optional/MysqlXid.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */