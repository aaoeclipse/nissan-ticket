/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.CharBuffer;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.CharsetEncoder;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class PreparedStatement
/*      */   extends StatementImpl
/*      */   implements PreparedStatement
/*      */ {
/*      */   private static final Constructor JDBC_4_PSTMT_2_ARG_CTOR;
/*      */   private static final Constructor JDBC_4_PSTMT_3_ARG_CTOR;
/*      */   private static final Constructor JDBC_4_PSTMT_4_ARG_CTOR;
/*      */   private static final byte[] HEX_DIGITS;
/*      */   
/*      */   static  {
/*  101 */     if (Util.isJdbc4()) {
/*      */       try {
/*  103 */         JDBC_4_PSTMT_2_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { ConnectionImpl.class, String.class });
/*      */ 
/*      */ 
/*      */         
/*  107 */         JDBC_4_PSTMT_3_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { ConnectionImpl.class, String.class, String.class });
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  112 */         JDBC_4_PSTMT_4_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4PreparedStatement").getConstructor(new Class[] { ConnectionImpl.class, String.class, String.class, ParseInfo.class });
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  117 */       catch (SecurityException e) {
/*  118 */         throw new RuntimeException(e);
/*  119 */       } catch (NoSuchMethodException e) {
/*  120 */         throw new RuntimeException(e);
/*  121 */       } catch (ClassNotFoundException e) {
/*  122 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*  125 */       JDBC_4_PSTMT_2_ARG_CTOR = null;
/*  126 */       JDBC_4_PSTMT_3_ARG_CTOR = null;
/*  127 */       JDBC_4_PSTMT_4_ARG_CTOR = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  713 */     HEX_DIGITS = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*      */   }
/*      */   class BatchParams {
/*      */     boolean[] isNull;
/*      */     boolean[] isStream;
/*      */     InputStream[] parameterStreams;
/*      */     byte[][] parameterStrings;
/*      */     int[] streamLengths;
/*      */     private final PreparedStatement this$0;
/*      */     BatchParams(PreparedStatement this$0, byte[][] strings, InputStream[] streams, boolean[] isStreamFlags, int[] lengths, boolean[] isNullFlags) { this.this$0 = this$0; this.isNull = null; this.isStream = null; this.parameterStreams = null; this.parameterStrings = (byte[][])null; this.streamLengths = null; this.parameterStrings = new byte[strings.length][]; this.parameterStreams = new InputStream[streams.length]; this.isStream = new boolean[isStreamFlags.length]; this.streamLengths = new int[lengths.length]; this.isNull = new boolean[isNullFlags.length]; System.arraycopy(strings, 0, this.parameterStrings, 0, strings.length); System.arraycopy(streams, 0, this.parameterStreams, 0, streams.length); System.arraycopy(isStreamFlags, 0, this.isStream, 0, isStreamFlags.length); System.arraycopy(lengths, 0, this.streamLengths, 0, lengths.length); System.arraycopy(isNullFlags, 0, this.isNull, 0, isNullFlags.length); } } class EndPoint {
/*      */     int begin; int end; private final PreparedStatement this$0; EndPoint(PreparedStatement this$0, int b, int e) { this.this$0 = this$0; this.begin = b; this.end = e; } } class ParseInfo {
/*      */     char firstStmtChar; boolean foundLimitClause; boolean foundLoadData; long lastUsed; int statementLength; int statementStartPos; boolean canRewriteAsMultiValueInsert; byte[][] staticSql; boolean isOnDuplicateKeyUpdate; int locationOfOnDuplicateKeyUpdate; String valuesClause; private ParseInfo batchHead; private ParseInfo batchValues; private ParseInfo batchODKUClause; private final PreparedStatement this$0; ParseInfo(String sql, ConnectionImpl conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter) throws SQLException { this(sql, conn, dbmd, encoding, converter, true); } public ParseInfo(String sql, ConnectionImpl conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter, boolean buildRewriteInfo) throws SQLException { // Byte code:
/*      */       //   0: aload_0
/*      */       //   1: invokespecial <init> : ()V
/*      */       //   4: aload_0
/*      */       //   5: aload_1
/*      */       //   6: putfield this$0 : Lcom/mysql/jdbc/PreparedStatement;
/*      */       //   9: aload_0
/*      */       //   10: iconst_0
/*      */       //   11: putfield firstStmtChar : C
/*      */       //   14: aload_0
/*      */       //   15: iconst_0
/*      */       //   16: putfield foundLimitClause : Z
/*      */       //   19: aload_0
/*      */       //   20: iconst_0
/*      */       //   21: putfield foundLoadData : Z
/*      */       //   24: aload_0
/*      */       //   25: lconst_0
/*      */       //   26: putfield lastUsed : J
/*      */       //   29: aload_0
/*      */       //   30: iconst_0
/*      */       //   31: putfield statementLength : I
/*      */       //   34: aload_0
/*      */       //   35: iconst_0
/*      */       //   36: putfield statementStartPos : I
/*      */       //   39: aload_0
/*      */       //   40: iconst_0
/*      */       //   41: putfield canRewriteAsMultiValueInsert : Z
/*      */       //   44: aload_0
/*      */       //   45: aconst_null
/*      */       //   46: checkcast [[B
/*      */       //   49: putfield staticSql : [[B
/*      */       //   52: aload_0
/*      */       //   53: iconst_0
/*      */       //   54: putfield isOnDuplicateKeyUpdate : Z
/*      */       //   57: aload_0
/*      */       //   58: iconst_m1
/*      */       //   59: putfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   62: aload_2
/*      */       //   63: ifnonnull -> 81
/*      */       //   66: ldc 'PreparedStatement.61'
/*      */       //   68: invokestatic getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */       //   71: ldc 'S1009'
/*      */       //   73: aload_1
/*      */       //   74: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */       //   77: invokestatic createSQLException : (Ljava/lang/String;Ljava/lang/String;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */       //   80: athrow
/*      */       //   81: aload_0
/*      */       //   82: aload_1
/*      */       //   83: aload_2
/*      */       //   84: invokevirtual getOnDuplicateKeyLocation : (Ljava/lang/String;)I
/*      */       //   87: putfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   90: aload_0
/*      */       //   91: aload_0
/*      */       //   92: getfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   95: iconst_m1
/*      */       //   96: if_icmpeq -> 103
/*      */       //   99: iconst_1
/*      */       //   100: goto -> 104
/*      */       //   103: iconst_0
/*      */       //   104: putfield isOnDuplicateKeyUpdate : Z
/*      */       //   107: aload_0
/*      */       //   108: invokestatic currentTimeMillis : ()J
/*      */       //   111: putfield lastUsed : J
/*      */       //   114: aload #4
/*      */       //   116: invokeinterface getIdentifierQuoteString : ()Ljava/lang/String;
/*      */       //   121: astore #8
/*      */       //   123: iconst_0
/*      */       //   124: istore #9
/*      */       //   126: aload #8
/*      */       //   128: ifnull -> 157
/*      */       //   131: aload #8
/*      */       //   133: ldc ' '
/*      */       //   135: invokevirtual equals : (Ljava/lang/Object;)Z
/*      */       //   138: ifne -> 157
/*      */       //   141: aload #8
/*      */       //   143: invokevirtual length : ()I
/*      */       //   146: ifle -> 157
/*      */       //   149: aload #8
/*      */       //   151: iconst_0
/*      */       //   152: invokevirtual charAt : (I)C
/*      */       //   155: istore #9
/*      */       //   157: aload_0
/*      */       //   158: aload_2
/*      */       //   159: invokevirtual length : ()I
/*      */       //   162: putfield statementLength : I
/*      */       //   165: new java/util/ArrayList
/*      */       //   168: dup
/*      */       //   169: invokespecial <init> : ()V
/*      */       //   172: astore #10
/*      */       //   174: iconst_0
/*      */       //   175: istore #11
/*      */       //   177: iconst_0
/*      */       //   178: istore #12
/*      */       //   180: iconst_0
/*      */       //   181: istore #13
/*      */       //   183: iconst_0
/*      */       //   184: istore #14
/*      */       //   186: aload_0
/*      */       //   187: getfield statementLength : I
/*      */       //   190: iconst_5
/*      */       //   191: isub
/*      */       //   192: istore #16
/*      */       //   194: aload_0
/*      */       //   195: iconst_0
/*      */       //   196: putfield foundLimitClause : Z
/*      */       //   199: aload_1
/*      */       //   200: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */       //   203: invokevirtual isNoBackslashEscapesSet : ()Z
/*      */       //   206: istore #17
/*      */       //   208: aload_0
/*      */       //   209: aload_1
/*      */       //   210: aload_2
/*      */       //   211: invokevirtual findStartOfStatement : (Ljava/lang/String;)I
/*      */       //   214: putfield statementStartPos : I
/*      */       //   217: aload_0
/*      */       //   218: getfield statementStartPos : I
/*      */       //   221: istore #15
/*      */       //   223: iload #15
/*      */       //   225: aload_0
/*      */       //   226: getfield statementLength : I
/*      */       //   229: if_icmpge -> 848
/*      */       //   232: aload_2
/*      */       //   233: iload #15
/*      */       //   235: invokevirtual charAt : (I)C
/*      */       //   238: istore #18
/*      */       //   240: aload_0
/*      */       //   241: getfield firstStmtChar : C
/*      */       //   244: ifne -> 264
/*      */       //   247: iload #18
/*      */       //   249: invokestatic isLetter : (C)Z
/*      */       //   252: ifeq -> 264
/*      */       //   255: aload_0
/*      */       //   256: iload #18
/*      */       //   258: invokestatic toUpperCase : (C)C
/*      */       //   261: putfield firstStmtChar : C
/*      */       //   264: iload #17
/*      */       //   266: ifne -> 293
/*      */       //   269: iload #18
/*      */       //   271: bipush #92
/*      */       //   273: if_icmpne -> 293
/*      */       //   276: iload #15
/*      */       //   278: aload_0
/*      */       //   279: getfield statementLength : I
/*      */       //   282: iconst_1
/*      */       //   283: isub
/*      */       //   284: if_icmpge -> 293
/*      */       //   287: iinc #15, 1
/*      */       //   290: goto -> 842
/*      */       //   293: iload #11
/*      */       //   295: ifne -> 325
/*      */       //   298: iload #9
/*      */       //   300: ifeq -> 325
/*      */       //   303: iload #18
/*      */       //   305: iload #9
/*      */       //   307: if_icmpne -> 325
/*      */       //   310: iload #13
/*      */       //   312: ifne -> 319
/*      */       //   315: iconst_1
/*      */       //   316: goto -> 320
/*      */       //   319: iconst_0
/*      */       //   320: istore #13
/*      */       //   322: goto -> 673
/*      */       //   325: iload #13
/*      */       //   327: ifne -> 673
/*      */       //   330: iload #11
/*      */       //   332: ifeq -> 443
/*      */       //   335: iload #18
/*      */       //   337: bipush #39
/*      */       //   339: if_icmpeq -> 349
/*      */       //   342: iload #18
/*      */       //   344: bipush #34
/*      */       //   346: if_icmpne -> 404
/*      */       //   349: iload #18
/*      */       //   351: iload #12
/*      */       //   353: if_icmpne -> 404
/*      */       //   356: iload #15
/*      */       //   358: aload_0
/*      */       //   359: getfield statementLength : I
/*      */       //   362: iconst_1
/*      */       //   363: isub
/*      */       //   364: if_icmpge -> 386
/*      */       //   367: aload_2
/*      */       //   368: iload #15
/*      */       //   370: iconst_1
/*      */       //   371: iadd
/*      */       //   372: invokevirtual charAt : (I)C
/*      */       //   375: iload #12
/*      */       //   377: if_icmpne -> 386
/*      */       //   380: iinc #15, 1
/*      */       //   383: goto -> 842
/*      */       //   386: iload #11
/*      */       //   388: ifne -> 395
/*      */       //   391: iconst_1
/*      */       //   392: goto -> 396
/*      */       //   395: iconst_0
/*      */       //   396: istore #11
/*      */       //   398: iconst_0
/*      */       //   399: istore #12
/*      */       //   401: goto -> 673
/*      */       //   404: iload #18
/*      */       //   406: bipush #39
/*      */       //   408: if_icmpeq -> 418
/*      */       //   411: iload #18
/*      */       //   413: bipush #34
/*      */       //   415: if_icmpne -> 673
/*      */       //   418: iload #18
/*      */       //   420: iload #12
/*      */       //   422: if_icmpne -> 673
/*      */       //   425: iload #11
/*      */       //   427: ifne -> 434
/*      */       //   430: iconst_1
/*      */       //   431: goto -> 435
/*      */       //   434: iconst_0
/*      */       //   435: istore #11
/*      */       //   437: iconst_0
/*      */       //   438: istore #12
/*      */       //   440: goto -> 673
/*      */       //   443: iload #18
/*      */       //   445: bipush #35
/*      */       //   447: if_icmpeq -> 481
/*      */       //   450: iload #18
/*      */       //   452: bipush #45
/*      */       //   454: if_icmpne -> 527
/*      */       //   457: iload #15
/*      */       //   459: iconst_1
/*      */       //   460: iadd
/*      */       //   461: aload_0
/*      */       //   462: getfield statementLength : I
/*      */       //   465: if_icmpge -> 527
/*      */       //   468: aload_2
/*      */       //   469: iload #15
/*      */       //   471: iconst_1
/*      */       //   472: iadd
/*      */       //   473: invokevirtual charAt : (I)C
/*      */       //   476: bipush #45
/*      */       //   478: if_icmpne -> 527
/*      */       //   481: aload_0
/*      */       //   482: getfield statementLength : I
/*      */       //   485: iconst_1
/*      */       //   486: isub
/*      */       //   487: istore #19
/*      */       //   489: iload #15
/*      */       //   491: iload #19
/*      */       //   493: if_icmpge -> 842
/*      */       //   496: aload_2
/*      */       //   497: iload #15
/*      */       //   499: invokevirtual charAt : (I)C
/*      */       //   502: istore #18
/*      */       //   504: iload #18
/*      */       //   506: bipush #13
/*      */       //   508: if_icmpeq -> 842
/*      */       //   511: iload #18
/*      */       //   513: bipush #10
/*      */       //   515: if_icmpne -> 521
/*      */       //   518: goto -> 842
/*      */       //   521: iinc #15, 1
/*      */       //   524: goto -> 489
/*      */       //   527: iload #18
/*      */       //   529: bipush #47
/*      */       //   531: if_icmpne -> 652
/*      */       //   534: iload #15
/*      */       //   536: iconst_1
/*      */       //   537: iadd
/*      */       //   538: aload_0
/*      */       //   539: getfield statementLength : I
/*      */       //   542: if_icmpge -> 652
/*      */       //   545: aload_2
/*      */       //   546: iload #15
/*      */       //   548: iconst_1
/*      */       //   549: iadd
/*      */       //   550: invokevirtual charAt : (I)C
/*      */       //   553: istore #19
/*      */       //   555: iload #19
/*      */       //   557: bipush #42
/*      */       //   559: if_icmpne -> 649
/*      */       //   562: iinc #15, 2
/*      */       //   565: iload #15
/*      */       //   567: istore #20
/*      */       //   569: iload #20
/*      */       //   571: aload_0
/*      */       //   572: getfield statementLength : I
/*      */       //   575: if_icmpge -> 649
/*      */       //   578: iinc #15, 1
/*      */       //   581: aload_2
/*      */       //   582: iload #20
/*      */       //   584: invokevirtual charAt : (I)C
/*      */       //   587: istore #19
/*      */       //   589: iload #19
/*      */       //   591: bipush #42
/*      */       //   593: if_icmpne -> 643
/*      */       //   596: iload #20
/*      */       //   598: iconst_1
/*      */       //   599: iadd
/*      */       //   600: aload_0
/*      */       //   601: getfield statementLength : I
/*      */       //   604: if_icmpge -> 643
/*      */       //   607: aload_2
/*      */       //   608: iload #20
/*      */       //   610: iconst_1
/*      */       //   611: iadd
/*      */       //   612: invokevirtual charAt : (I)C
/*      */       //   615: bipush #47
/*      */       //   617: if_icmpne -> 643
/*      */       //   620: iinc #15, 1
/*      */       //   623: iload #15
/*      */       //   625: aload_0
/*      */       //   626: getfield statementLength : I
/*      */       //   629: if_icmpge -> 649
/*      */       //   632: aload_2
/*      */       //   633: iload #15
/*      */       //   635: invokevirtual charAt : (I)C
/*      */       //   638: istore #18
/*      */       //   640: goto -> 649
/*      */       //   643: iinc #20, 1
/*      */       //   646: goto -> 569
/*      */       //   649: goto -> 673
/*      */       //   652: iload #18
/*      */       //   654: bipush #39
/*      */       //   656: if_icmpeq -> 666
/*      */       //   659: iload #18
/*      */       //   661: bipush #34
/*      */       //   663: if_icmpne -> 673
/*      */       //   666: iconst_1
/*      */       //   667: istore #11
/*      */       //   669: iload #18
/*      */       //   671: istore #12
/*      */       //   673: iload #18
/*      */       //   675: bipush #63
/*      */       //   677: if_icmpne -> 715
/*      */       //   680: iload #11
/*      */       //   682: ifne -> 715
/*      */       //   685: iload #13
/*      */       //   687: ifne -> 715
/*      */       //   690: aload #10
/*      */       //   692: iconst_2
/*      */       //   693: newarray int
/*      */       //   695: dup
/*      */       //   696: iconst_0
/*      */       //   697: iload #14
/*      */       //   699: iastore
/*      */       //   700: dup
/*      */       //   701: iconst_1
/*      */       //   702: iload #15
/*      */       //   704: iastore
/*      */       //   705: invokevirtual add : (Ljava/lang/Object;)Z
/*      */       //   708: pop
/*      */       //   709: iload #15
/*      */       //   711: iconst_1
/*      */       //   712: iadd
/*      */       //   713: istore #14
/*      */       //   715: iload #11
/*      */       //   717: ifne -> 842
/*      */       //   720: iload #15
/*      */       //   722: iload #16
/*      */       //   724: if_icmpge -> 842
/*      */       //   727: iload #18
/*      */       //   729: bipush #76
/*      */       //   731: if_icmpeq -> 741
/*      */       //   734: iload #18
/*      */       //   736: bipush #108
/*      */       //   738: if_icmpne -> 842
/*      */       //   741: aload_2
/*      */       //   742: iload #15
/*      */       //   744: iconst_1
/*      */       //   745: iadd
/*      */       //   746: invokevirtual charAt : (I)C
/*      */       //   749: istore #19
/*      */       //   751: iload #19
/*      */       //   753: bipush #73
/*      */       //   755: if_icmpeq -> 765
/*      */       //   758: iload #19
/*      */       //   760: bipush #105
/*      */       //   762: if_icmpne -> 842
/*      */       //   765: aload_2
/*      */       //   766: iload #15
/*      */       //   768: iconst_2
/*      */       //   769: iadd
/*      */       //   770: invokevirtual charAt : (I)C
/*      */       //   773: istore #20
/*      */       //   775: iload #20
/*      */       //   777: bipush #77
/*      */       //   779: if_icmpeq -> 789
/*      */       //   782: iload #20
/*      */       //   784: bipush #109
/*      */       //   786: if_icmpne -> 842
/*      */       //   789: aload_2
/*      */       //   790: iload #15
/*      */       //   792: iconst_3
/*      */       //   793: iadd
/*      */       //   794: invokevirtual charAt : (I)C
/*      */       //   797: istore #21
/*      */       //   799: iload #21
/*      */       //   801: bipush #73
/*      */       //   803: if_icmpeq -> 813
/*      */       //   806: iload #21
/*      */       //   808: bipush #105
/*      */       //   810: if_icmpne -> 842
/*      */       //   813: aload_2
/*      */       //   814: iload #15
/*      */       //   816: iconst_4
/*      */       //   817: iadd
/*      */       //   818: invokevirtual charAt : (I)C
/*      */       //   821: istore #22
/*      */       //   823: iload #22
/*      */       //   825: bipush #84
/*      */       //   827: if_icmpeq -> 837
/*      */       //   830: iload #22
/*      */       //   832: bipush #116
/*      */       //   834: if_icmpne -> 842
/*      */       //   837: aload_0
/*      */       //   838: iconst_1
/*      */       //   839: putfield foundLimitClause : Z
/*      */       //   842: iinc #15, 1
/*      */       //   845: goto -> 223
/*      */       //   848: aload_0
/*      */       //   849: getfield firstStmtChar : C
/*      */       //   852: bipush #76
/*      */       //   854: if_icmpne -> 882
/*      */       //   857: aload_2
/*      */       //   858: ldc 'LOAD DATA'
/*      */       //   860: invokestatic startsWithIgnoreCaseAndWs : (Ljava/lang/String;Ljava/lang/String;)Z
/*      */       //   863: ifeq -> 874
/*      */       //   866: aload_0
/*      */       //   867: iconst_1
/*      */       //   868: putfield foundLoadData : Z
/*      */       //   871: goto -> 887
/*      */       //   874: aload_0
/*      */       //   875: iconst_0
/*      */       //   876: putfield foundLoadData : Z
/*      */       //   879: goto -> 887
/*      */       //   882: aload_0
/*      */       //   883: iconst_0
/*      */       //   884: putfield foundLoadData : Z
/*      */       //   887: aload #10
/*      */       //   889: iconst_2
/*      */       //   890: newarray int
/*      */       //   892: dup
/*      */       //   893: iconst_0
/*      */       //   894: iload #14
/*      */       //   896: iastore
/*      */       //   897: dup
/*      */       //   898: iconst_1
/*      */       //   899: aload_0
/*      */       //   900: getfield statementLength : I
/*      */       //   903: iastore
/*      */       //   904: invokevirtual add : (Ljava/lang/Object;)Z
/*      */       //   907: pop
/*      */       //   908: aload_0
/*      */       //   909: aload #10
/*      */       //   911: invokevirtual size : ()I
/*      */       //   914: anewarray [B
/*      */       //   917: putfield staticSql : [[B
/*      */       //   920: aload_2
/*      */       //   921: invokevirtual toCharArray : ()[C
/*      */       //   924: astore #18
/*      */       //   926: iconst_0
/*      */       //   927: istore #15
/*      */       //   929: iload #15
/*      */       //   931: aload_0
/*      */       //   932: getfield staticSql : [[B
/*      */       //   935: arraylength
/*      */       //   936: if_icmpge -> 1160
/*      */       //   939: aload #10
/*      */       //   941: iload #15
/*      */       //   943: invokevirtual get : (I)Ljava/lang/Object;
/*      */       //   946: checkcast [I
/*      */       //   949: astore #19
/*      */       //   951: aload #19
/*      */       //   953: iconst_1
/*      */       //   954: iaload
/*      */       //   955: istore #20
/*      */       //   957: aload #19
/*      */       //   959: iconst_0
/*      */       //   960: iaload
/*      */       //   961: istore #21
/*      */       //   963: iload #20
/*      */       //   965: iload #21
/*      */       //   967: isub
/*      */       //   968: istore #22
/*      */       //   970: aload_0
/*      */       //   971: getfield foundLoadData : Z
/*      */       //   974: ifeq -> 1007
/*      */       //   977: new java/lang/String
/*      */       //   980: dup
/*      */       //   981: aload #18
/*      */       //   983: iload #21
/*      */       //   985: iload #22
/*      */       //   987: invokespecial <init> : ([CII)V
/*      */       //   990: astore #23
/*      */       //   992: aload_0
/*      */       //   993: getfield staticSql : [[B
/*      */       //   996: iload #15
/*      */       //   998: aload #23
/*      */       //   1000: invokevirtual getBytes : ()[B
/*      */       //   1003: aastore
/*      */       //   1004: goto -> 1154
/*      */       //   1007: aload #5
/*      */       //   1009: ifnonnull -> 1061
/*      */       //   1012: iload #22
/*      */       //   1014: newarray byte
/*      */       //   1016: astore #23
/*      */       //   1018: iconst_0
/*      */       //   1019: istore #24
/*      */       //   1021: iload #24
/*      */       //   1023: iload #22
/*      */       //   1025: if_icmpge -> 1049
/*      */       //   1028: aload #23
/*      */       //   1030: iload #24
/*      */       //   1032: aload_2
/*      */       //   1033: iload #21
/*      */       //   1035: iload #24
/*      */       //   1037: iadd
/*      */       //   1038: invokevirtual charAt : (I)C
/*      */       //   1041: i2b
/*      */       //   1042: bastore
/*      */       //   1043: iinc #24, 1
/*      */       //   1046: goto -> 1021
/*      */       //   1049: aload_0
/*      */       //   1050: getfield staticSql : [[B
/*      */       //   1053: iload #15
/*      */       //   1055: aload #23
/*      */       //   1057: aastore
/*      */       //   1058: goto -> 1154
/*      */       //   1061: aload #6
/*      */       //   1063: ifnull -> 1106
/*      */       //   1066: aload_0
/*      */       //   1067: getfield staticSql : [[B
/*      */       //   1070: iload #15
/*      */       //   1072: aload_2
/*      */       //   1073: aload #6
/*      */       //   1075: aload #5
/*      */       //   1077: aload_1
/*      */       //   1078: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */       //   1081: invokevirtual getServerCharacterEncoding : ()Ljava/lang/String;
/*      */       //   1084: iload #21
/*      */       //   1086: iload #22
/*      */       //   1088: aload_1
/*      */       //   1089: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */       //   1092: invokevirtual parserKnowsUnicode : ()Z
/*      */       //   1095: aload_1
/*      */       //   1096: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */       //   1099: invokestatic getBytes : (Ljava/lang/String;Lcom/mysql/jdbc/SingleByteCharsetConverter;Ljava/lang/String;Ljava/lang/String;IIZLcom/mysql/jdbc/ExceptionInterceptor;)[B
/*      */       //   1102: aastore
/*      */       //   1103: goto -> 1154
/*      */       //   1106: new java/lang/String
/*      */       //   1109: dup
/*      */       //   1110: aload #18
/*      */       //   1112: iload #21
/*      */       //   1114: iload #22
/*      */       //   1116: invokespecial <init> : ([CII)V
/*      */       //   1119: astore #23
/*      */       //   1121: aload_0
/*      */       //   1122: getfield staticSql : [[B
/*      */       //   1125: iload #15
/*      */       //   1127: aload #23
/*      */       //   1129: aload #5
/*      */       //   1131: aload_1
/*      */       //   1132: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */       //   1135: invokevirtual getServerCharacterEncoding : ()Ljava/lang/String;
/*      */       //   1138: aload_1
/*      */       //   1139: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */       //   1142: invokevirtual parserKnowsUnicode : ()Z
/*      */       //   1145: aload_3
/*      */       //   1146: aload_1
/*      */       //   1147: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */       //   1150: invokestatic getBytes : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLcom/mysql/jdbc/ConnectionImpl;Lcom/mysql/jdbc/ExceptionInterceptor;)[B
/*      */       //   1153: aastore
/*      */       //   1154: iinc #15, 1
/*      */       //   1157: goto -> 929
/*      */       //   1160: goto -> 1204
/*      */       //   1163: astore #8
/*      */       //   1165: new java/sql/SQLException
/*      */       //   1168: dup
/*      */       //   1169: new java/lang/StringBuffer
/*      */       //   1172: dup
/*      */       //   1173: invokespecial <init> : ()V
/*      */       //   1176: ldc 'Parse error for '
/*      */       //   1178: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   1181: aload_2
/*      */       //   1182: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */       //   1185: invokevirtual toString : ()Ljava/lang/String;
/*      */       //   1188: invokespecial <init> : (Ljava/lang/String;)V
/*      */       //   1191: astore #9
/*      */       //   1193: aload #9
/*      */       //   1195: aload #8
/*      */       //   1197: invokevirtual initCause : (Ljava/lang/Throwable;)Ljava/lang/Throwable;
/*      */       //   1200: pop
/*      */       //   1201: aload #9
/*      */       //   1203: athrow
/*      */       //   1204: iload #7
/*      */       //   1206: ifeq -> 1255
/*      */       //   1209: aload_0
/*      */       //   1210: aload_2
/*      */       //   1211: aload_0
/*      */       //   1212: getfield isOnDuplicateKeyUpdate : Z
/*      */       //   1215: aload_0
/*      */       //   1216: getfield locationOfOnDuplicateKeyUpdate : I
/*      */       //   1219: aload_0
/*      */       //   1220: getfield statementStartPos : I
/*      */       //   1223: invokestatic canRewrite : (Ljava/lang/String;ZII)Z
/*      */       //   1226: putfield canRewriteAsMultiValueInsert : Z
/*      */       //   1229: aload_0
/*      */       //   1230: getfield canRewriteAsMultiValueInsert : Z
/*      */       //   1233: ifeq -> 1255
/*      */       //   1236: aload_3
/*      */       //   1237: invokevirtual getRewriteBatchedStatements : ()Z
/*      */       //   1240: ifeq -> 1255
/*      */       //   1243: aload_0
/*      */       //   1244: aload_2
/*      */       //   1245: aload_3
/*      */       //   1246: aload #4
/*      */       //   1248: aload #5
/*      */       //   1250: aload #6
/*      */       //   1252: invokespecial buildRewriteBatchedParams : (Ljava/lang/String;Lcom/mysql/jdbc/ConnectionImpl;Ljava/sql/DatabaseMetaData;Ljava/lang/String;Lcom/mysql/jdbc/SingleByteCharsetConverter;)V
/*      */       //   1255: return
/*      */       // Line number table:
/*      */       //   Java source line number -> byte code offset
/*      */       //   #213	-> 0
/*      */       //   #177	-> 9
/*      */       //   #179	-> 14
/*      */       //   #181	-> 19
/*      */       //   #183	-> 24
/*      */       //   #185	-> 29
/*      */       //   #187	-> 34
/*      */       //   #189	-> 39
/*      */       //   #191	-> 44
/*      */       //   #193	-> 52
/*      */       //   #195	-> 57
/*      */       //   #215	-> 62
/*      */       //   #216	-> 66
/*      */       //   #221	-> 81
/*      */       //   #222	-> 90
/*      */       //   #224	-> 107
/*      */       //   #226	-> 114
/*      */       //   #228	-> 123
/*      */       //   #230	-> 126
/*      */       //   #233	-> 149
/*      */       //   #236	-> 157
/*      */       //   #238	-> 165
/*      */       //   #239	-> 174
/*      */       //   #240	-> 177
/*      */       //   #241	-> 180
/*      */       //   #242	-> 183
/*      */       //   #245	-> 186
/*      */       //   #247	-> 194
/*      */       //   #249	-> 199
/*      */       //   #255	-> 208
/*      */       //   #257	-> 217
/*      */       //   #258	-> 232
/*      */       //   #260	-> 240
/*      */       //   #263	-> 255
/*      */       //   #266	-> 264
/*      */       //   #268	-> 287
/*      */       //   #269	-> 290
/*      */       //   #274	-> 293
/*      */       //   #276	-> 310
/*      */       //   #277	-> 325
/*      */       //   #280	-> 330
/*      */       //   #281	-> 335
/*      */       //   #282	-> 356
/*      */       //   #283	-> 380
/*      */       //   #284	-> 383
/*      */       //   #287	-> 386
/*      */       //   #288	-> 398
/*      */       //   #289	-> 404
/*      */       //   #290	-> 425
/*      */       //   #291	-> 437
/*      */       //   #294	-> 443
/*      */       //   #299	-> 481
/*      */       //   #301	-> 489
/*      */       //   #302	-> 496
/*      */       //   #304	-> 504
/*      */       //   #305	-> 518
/*      */       //   #301	-> 521
/*      */       //   #310	-> 527
/*      */       //   #312	-> 545
/*      */       //   #314	-> 555
/*      */       //   #315	-> 562
/*      */       //   #317	-> 565
/*      */       //   #318	-> 578
/*      */       //   #319	-> 581
/*      */       //   #321	-> 589
/*      */       //   #322	-> 607
/*      */       //   #323	-> 620
/*      */       //   #325	-> 623
/*      */       //   #326	-> 632
/*      */       //   #317	-> 643
/*      */       //   #334	-> 652
/*      */       //   #335	-> 666
/*      */       //   #336	-> 669
/*      */       //   #341	-> 673
/*      */       //   #342	-> 690
/*      */       //   #343	-> 709
/*      */       //   #346	-> 715
/*      */       //   #347	-> 727
/*      */       //   #348	-> 741
/*      */       //   #350	-> 751
/*      */       //   #351	-> 765
/*      */       //   #353	-> 775
/*      */       //   #354	-> 789
/*      */       //   #356	-> 799
/*      */       //   #357	-> 813
/*      */       //   #359	-> 823
/*      */       //   #360	-> 837
/*      */       //   #257	-> 842
/*      */       //   #369	-> 848
/*      */       //   #370	-> 857
/*      */       //   #371	-> 866
/*      */       //   #373	-> 874
/*      */       //   #376	-> 882
/*      */       //   #379	-> 887
/*      */       //   #380	-> 908
/*      */       //   #381	-> 920
/*      */       //   #383	-> 926
/*      */       //   #384	-> 939
/*      */       //   #385	-> 951
/*      */       //   #386	-> 957
/*      */       //   #387	-> 963
/*      */       //   #389	-> 970
/*      */       //   #390	-> 977
/*      */       //   #391	-> 992
/*      */       //   #392	-> 1007
/*      */       //   #393	-> 1012
/*      */       //   #395	-> 1018
/*      */       //   #396	-> 1028
/*      */       //   #395	-> 1043
/*      */       //   #399	-> 1049
/*      */       //   #401	-> 1061
/*      */       //   #402	-> 1066
/*      */       //   #407	-> 1106
/*      */       //   #409	-> 1121
/*      */       //   #383	-> 1154
/*      */       //   #421	-> 1160
/*      */       //   #416	-> 1163
/*      */       //   #417	-> 1165
/*      */       //   #418	-> 1193
/*      */       //   #420	-> 1201
/*      */       //   #424	-> 1204
/*      */       //   #425	-> 1209
/*      */       //   #430	-> 1229
/*      */       //   #432	-> 1243
/*      */       //   #436	-> 1255
/*      */       // Local variable table:
/*      */       //   start	length	slot	name	descriptor
/*      */       //   489	38	19	endOfStmt	I
/*      */       //   569	80	20	j	I
/*      */       //   555	94	19	cNext	C
/*      */       //   823	19	22	posT	C
/*      */       //   799	43	21	posI2	C
/*      */       //   775	67	20	posM	C
/*      */       //   751	91	19	posI1	C
/*      */       //   240	602	18	c	C
/*      */       //   992	12	23	temp	Ljava/lang/String;
/*      */       //   1021	28	24	j	I
/*      */       //   1018	40	23	buf	[B
/*      */       //   1121	33	23	temp	Ljava/lang/String;
/*      */       //   951	203	19	ep	[I
/*      */       //   957	197	20	end	I
/*      */       //   963	191	21	begin	I
/*      */       //   970	184	22	len	I
/*      */       //   123	1037	8	quotedIdentifierString	Ljava/lang/String;
/*      */       //   126	1034	9	quotedIdentifierChar	C
/*      */       //   174	986	10	endpointList	Ljava/util/ArrayList;
/*      */       //   177	983	11	inQuotes	Z
/*      */       //   180	980	12	quoteChar	C
/*      */       //   183	977	13	inQuotedId	Z
/*      */       //   186	974	14	lastParmEnd	I
/*      */       //   223	937	15	i	I
/*      */       //   194	966	16	stopLookingForLimitClause	I
/*      */       //   208	952	17	noBackslashEscapes	Z
/*      */       //   926	234	18	asCharArray	[C
/*      */       //   1193	11	9	sqlEx	Ljava/sql/SQLException;
/*      */       //   1165	39	8	oobEx	Ljava/lang/StringIndexOutOfBoundsException;
/*      */       //   0	1256	0	this	Lcom/mysql/jdbc/PreparedStatement$ParseInfo;
/*      */       //   0	1256	1	this$0	Lcom/mysql/jdbc/PreparedStatement;
/*      */       //   0	1256	2	sql	Ljava/lang/String;
/*      */       //   0	1256	3	conn	Lcom/mysql/jdbc/ConnectionImpl;
/*      */       //   0	1256	4	dbmd	Ljava/sql/DatabaseMetaData;
/*      */       //   0	1256	5	encoding	Ljava/lang/String;
/*      */       //   0	1256	6	converter	Lcom/mysql/jdbc/SingleByteCharsetConverter;
/*      */       //   0	1256	7	buildRewriteInfo	Z
/*      */       // Exception table:
/*      */       //   from	to	target	type
/*      */       //   62	1160	1163	java/lang/StringIndexOutOfBoundsException } private void buildRewriteBatchedParams(String sql, ConnectionImpl conn, DatabaseMetaData metadata, String encoding, SingleByteCharsetConverter converter) throws SQLException { this.valuesClause = extractValuesClause(sql); String odkuClause = this.isOnDuplicateKeyUpdate ? sql.substring(this.locationOfOnDuplicateKeyUpdate) : null; String headSql = null; if (this.isOnDuplicateKeyUpdate) { headSql = sql.substring(0, this.locationOfOnDuplicateKeyUpdate); } else { headSql = sql; }  this.batchHead = new ParseInfo(headSql, conn, metadata, encoding, converter, false); this.batchValues = new ParseInfo("," + this.valuesClause, conn, metadata, encoding, converter, false); this.batchODKUClause = null; if (odkuClause != null && odkuClause.length() > 0)
/*      */         this.batchODKUClause = new ParseInfo("," + this.valuesClause + " " + odkuClause, conn, metadata, encoding, converter, false);  } private String extractValuesClause(String sql) throws SQLException { String quoteCharStr = PreparedStatement.this.connection.getMetaData().getIdentifierQuoteString(); int indexOfValues = -1; int valuesSearchStart = this.statementStartPos; while (indexOfValues == -1) { if (quoteCharStr.length() > 0) { indexOfValues = StringUtils.indexOfIgnoreCaseRespectQuotes(valuesSearchStart, PreparedStatement.this.originalSql, "VALUES ", quoteCharStr.charAt(0), false); } else { indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, PreparedStatement.this.originalSql, "VALUES "); }  if (indexOfValues > 0) { char c = PreparedStatement.this.originalSql.charAt(indexOfValues - 1); switch (c) { case '\t': case '\n': case ' ': case ')':
/*      */             case '`':
/*      */               continue; }  valuesSearchStart = indexOfValues + 7; indexOfValues = -1; }  }  if (indexOfValues == -1)
/*      */         return null;  int indexOfFirstParen = sql.indexOf('(', indexOfValues + 7); if (indexOfFirstParen == -1)
/*      */         return null;  int endOfValuesClause = sql.lastIndexOf(')'); if (endOfValuesClause == -1)
/*      */         return null;  if (this.isOnDuplicateKeyUpdate)
/*      */         endOfValuesClause = this.locationOfOnDuplicateKeyUpdate - 1;  return sql.substring(indexOfFirstParen, endOfValuesClause + 1); } synchronized ParseInfo getParseInfoForBatch(int numBatch) { PreparedStatement.AppendingBatchVisitor apv = new PreparedStatement.AppendingBatchVisitor(PreparedStatement.this); buildInfoForBatch(numBatch, apv); ParseInfo batchParseInfo = new ParseInfo(apv.getStaticSqlStrings(), this.firstStmtChar, this.foundLimitClause, this.foundLoadData, this.isOnDuplicateKeyUpdate, this.locationOfOnDuplicateKeyUpdate, this.statementLength, this.statementStartPos); return batchParseInfo; } String getSqlForBatch(int numBatch) throws UnsupportedEncodingException { ParseInfo batchInfo = getParseInfoForBatch(numBatch); int size = 0; byte[][] sqlStrings = batchInfo.staticSql; int sqlStringsLength = sqlStrings.length; for (int i = 0; i < sqlStringsLength; i++) { size += (sqlStrings[i]).length; size++; }  StringBuffer buf = new StringBuffer(size); for (int i = 0; i < sqlStringsLength - 1; i++) { buf.append(new String(sqlStrings[i], PreparedStatement.this.charEncoding)); buf.append("?"); }  buf.append(new String(sqlStrings[sqlStringsLength - 1])); return buf.toString(); } private void buildInfoForBatch(int numBatch, PreparedStatement.BatchVisitor visitor) { byte[][] headStaticSql = this.batchHead.staticSql; int headStaticSqlLength = headStaticSql.length; if (headStaticSqlLength > 1)
/*      */         for (int i = 0; i < headStaticSqlLength - 1; i++)
/*      */           visitor.append(headStaticSql[i]).increment();   byte[] endOfHead = headStaticSql[headStaticSqlLength - 1]; byte[][] valuesStaticSql = this.batchValues.staticSql; byte[] beginOfValues = valuesStaticSql[0]; visitor.merge(endOfHead, beginOfValues).increment(); int numValueRepeats = numBatch - 1; if (this.batchODKUClause != null)
/*      */         numValueRepeats--;  int valuesStaticSqlLength = valuesStaticSql.length; byte[] endOfValues = valuesStaticSql[valuesStaticSqlLength - 1]; for (int i = 0; i < numValueRepeats; i++) { for (int j = 1; j < valuesStaticSqlLength - 1; j++)
/*      */           visitor.append(valuesStaticSql[j]).increment();  visitor.merge(endOfValues, beginOfValues).increment(); }  if (this.batchODKUClause != null) { byte[][] batchOdkuStaticSql = this.batchODKUClause.staticSql; byte[] beginOfOdku = batchOdkuStaticSql[0]; visitor.decrement().merge(endOfValues, beginOfOdku).increment(); int batchOdkuStaticSqlLength = batchOdkuStaticSql.length; if (numBatch > 1) { for (int i = 1; i < batchOdkuStaticSqlLength; i++)
/*  736 */             visitor.append(batchOdkuStaticSql[i]).increment();  } else { visitor.decrement().append(batchOdkuStaticSql[batchOdkuStaticSqlLength - 1]); }  } else { visitor.decrement().append(this.staticSql[this.staticSql.length - 1]); }  } private ParseInfo(byte[][] staticSql, char firstStmtChar, boolean foundLimitClause, boolean foundLoadData, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementLength, int statementStartPos) { PreparedStatement.this = PreparedStatement.this; this.firstStmtChar = Character.MIN_VALUE; this.foundLimitClause = false; this.foundLoadData = false; this.lastUsed = 0L; this.statementLength = 0; this.statementStartPos = 0; this.canRewriteAsMultiValueInsert = false; this.staticSql = (byte[][])null; this.isOnDuplicateKeyUpdate = false; this.locationOfOnDuplicateKeyUpdate = -1; this.firstStmtChar = firstStmtChar; this.foundLimitClause = foundLimitClause; this.foundLoadData = foundLoadData; this.isOnDuplicateKeyUpdate = isOnDuplicateKeyUpdate; this.locationOfOnDuplicateKeyUpdate = locationOfOnDuplicateKeyUpdate; this.statementLength = statementLength; this.statementStartPos = statementStartPos; this.staticSql = staticSql; } } protected static int readFully(Reader reader, char[] buf, int length) throws IOException { int numCharsRead = 0;
/*      */     
/*  738 */     while (numCharsRead < length) {
/*  739 */       int count = reader.read(buf, numCharsRead, length - numCharsRead);
/*      */       
/*  741 */       if (count < 0) {
/*      */         break;
/*      */       }
/*      */       
/*  745 */       numCharsRead += count;
/*      */     } 
/*      */     
/*  748 */     return numCharsRead; }
/*      */   
/*      */   static interface BatchVisitor {
/*      */     BatchVisitor increment();
/*      */     
/*      */     BatchVisitor decrement();
/*      */     
/*      */     BatchVisitor append(byte[] param1ArrayOfbyte);
/*      */     
/*      */     BatchVisitor merge(byte[] param1ArrayOfbyte1, byte[] param1ArrayOfbyte2); }
/*      */   
/*  759 */   private DatabaseMetaData dbmd = null; class AppendingBatchVisitor implements BatchVisitor {
/*      */     LinkedList statementComponents; private final PreparedStatement this$0; AppendingBatchVisitor(PreparedStatement this$0) { this.this$0 = this$0; this.statementComponents = new LinkedList(); } public PreparedStatement.BatchVisitor append(byte[] values) { this.statementComponents.addLast(values); return this; }
/*      */     public PreparedStatement.BatchVisitor increment() { return this; }
/*      */     public PreparedStatement.BatchVisitor decrement() { this.statementComponents.removeLast(); return this; }
/*      */     public PreparedStatement.BatchVisitor merge(byte[] front, byte[] back) { int mergedLength = front.length + back.length; byte[] merged = new byte[mergedLength]; System.arraycopy(front, 0, merged, 0, front.length); System.arraycopy(back, 0, merged, front.length, back.length); this.statementComponents.addLast(merged); return this; }
/*      */     public byte[][] getStaticSqlStrings() { byte[][] asBytes = new byte[this.statementComponents.size()][]; this.statementComponents.toArray((Object[])asBytes); return asBytes; }
/*  765 */     public String toString() { StringBuffer buf = new StringBuffer(); Iterator iter = this.statementComponents.iterator(); while (iter.hasNext()) buf.append(new String(iter.next()));  return buf.toString(); } } protected boolean batchHasPlainStatements = false; protected char firstCharOfStmt = Character.MIN_VALUE;
/*      */ 
/*      */   
/*      */   protected boolean hasLimitClause = false;
/*      */ 
/*      */   
/*      */   protected boolean isLoadDataQuery = false;
/*      */   
/*  773 */   private boolean[] isNull = null;
/*      */   
/*  775 */   private boolean[] isStream = null;
/*      */   
/*  777 */   protected int numberOfExecutions = 0;
/*      */ 
/*      */   
/*  780 */   protected String originalSql = null;
/*      */ 
/*      */   
/*      */   protected int parameterCount;
/*      */   
/*      */   protected MysqlParameterMetadata parameterMetaData;
/*      */   
/*  787 */   private InputStream[] parameterStreams = null;
/*      */   
/*  789 */   private byte[][] parameterValues = (byte[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  795 */   protected int[] parameterTypes = null;
/*      */   
/*      */   protected ParseInfo parseInfo;
/*      */   
/*      */   private ResultSetMetaData pstmtResultMetaData;
/*      */   
/*  801 */   private byte[][] staticSqlStrings = (byte[][])null;
/*      */   
/*  803 */   private byte[] streamConvertBuf = new byte[4096];
/*      */   
/*  805 */   private int[] streamLengths = null;
/*      */   
/*  807 */   private SimpleDateFormat tsdf = null;
/*      */ 
/*      */   
/*      */   protected boolean useTrueBoolean = false;
/*      */ 
/*      */   
/*      */   protected boolean usingAnsiMode;
/*      */ 
/*      */   
/*      */   protected String batchedValuesClause;
/*      */ 
/*      */   
/*      */   private int statementAfterCommentsPos;
/*      */ 
/*      */   
/*      */   private boolean hasCheckedForRewrite = false;
/*      */ 
/*      */   
/*      */   private boolean canRewrite = false;
/*      */ 
/*      */   
/*      */   private boolean doPingInstead;
/*      */ 
/*      */   
/*      */   private SimpleDateFormat ddf;
/*      */ 
/*      */   
/*      */   private SimpleDateFormat tdf;
/*      */ 
/*      */   
/*      */   private boolean compensateForOnDuplicateKeyUpdate = false;
/*      */ 
/*      */   
/*      */   private CharsetEncoder charsetEncoder;
/*      */ 
/*      */   
/*  843 */   private int batchCommandIndex = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PreparedStatement getInstance(ConnectionImpl conn, String catalog) throws SQLException {
/*  854 */     if (!Util.isJdbc4()) {
/*  855 */       return new PreparedStatement(conn, catalog);
/*      */     }
/*      */     
/*  858 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_2_ARG_CTOR, new Object[] { conn, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PreparedStatement getInstance(ConnectionImpl conn, String sql, String catalog) throws SQLException {
/*  871 */     if (!Util.isJdbc4()) {
/*  872 */       return new PreparedStatement(conn, sql, catalog);
/*      */     }
/*      */     
/*  875 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_3_ARG_CTOR, new Object[] { conn, sql, catalog }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static PreparedStatement getInstance(ConnectionImpl conn, String sql, String catalog, ParseInfo cachedParseInfo) throws SQLException {
/*  888 */     if (!Util.isJdbc4()) {
/*  889 */       return new PreparedStatement(conn, sql, catalog, cachedParseInfo);
/*      */     }
/*      */     
/*  892 */     return (PreparedStatement)Util.handleNewInstance(JDBC_4_PSTMT_4_ARG_CTOR, new Object[] { conn, sql, catalog, cachedParseInfo }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement(ConnectionImpl conn, String catalog) throws SQLException {
/*  910 */     super(conn, catalog);
/*      */     
/*  912 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement(ConnectionImpl conn, String sql, String catalog) throws SQLException {
/*  930 */     super(conn, catalog);
/*      */     
/*  932 */     if (sql == null) {
/*  933 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.0"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/*  937 */     this.originalSql = sql;
/*      */     
/*  939 */     if (this.originalSql.startsWith("/* ping */")) {
/*  940 */       this.doPingInstead = true;
/*      */     } else {
/*  942 */       this.doPingInstead = false;
/*      */     } 
/*      */     
/*  945 */     this.dbmd = this.connection.getMetaData();
/*      */     
/*  947 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  949 */     this.parseInfo = new ParseInfo(sql, this.connection, this.dbmd, this.charEncoding, this.charConverter);
/*      */ 
/*      */     
/*  952 */     initializeFromParseInfo();
/*      */     
/*  954 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */     
/*  956 */     if (conn.getRequiresEscapingEncoder()) {
/*  957 */       this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement(ConnectionImpl conn, String sql, String catalog, ParseInfo cachedParseInfo) throws SQLException {
/*  977 */     super(conn, catalog);
/*      */     
/*  979 */     if (sql == null) {
/*  980 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.1"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/*  984 */     this.originalSql = sql;
/*      */     
/*  986 */     this.dbmd = this.connection.getMetaData();
/*      */     
/*  988 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */     
/*  990 */     this.parseInfo = cachedParseInfo;
/*      */     
/*  992 */     this.usingAnsiMode = !this.connection.useAnsiQuotedIdentifiers();
/*      */     
/*  994 */     initializeFromParseInfo();
/*      */     
/*  996 */     this.compensateForOnDuplicateKeyUpdate = this.connection.getCompensateOnDuplicateKeyUpdateCounts();
/*      */     
/*  998 */     if (conn.getRequiresEscapingEncoder()) {
/*  999 */       this.charsetEncoder = Charset.forName(conn.getEncoding()).newEncoder();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 1011 */     if (this.batchedArgs == null) {
/* 1012 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */     
/* 1015 */     for (int i = 0; i < this.parameterValues.length; i++) {
/* 1016 */       checkAllParametersSet(this.parameterValues[i], this.parameterStreams[i], i);
/*      */     }
/*      */ 
/*      */     
/* 1020 */     this.batchedArgs.add(new BatchParams(this, this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addBatch(String sql) throws SQLException {
/* 1026 */     this.batchHasPlainStatements = true;
/*      */     
/* 1028 */     super.addBatch(sql);
/*      */   }
/*      */ 
/*      */   
/* 1032 */   protected String asSql() throws SQLException { return asSql(false); }
/*      */ 
/*      */   
/*      */   protected String asSql(boolean quoteStreamsAndUnknowns) throws SQLException {
/* 1036 */     if (this.isClosed) {
/* 1037 */       return "statement has been closed, no further internal information available";
/*      */     }
/*      */     
/* 1040 */     StringBuffer buf = new StringBuffer();
/*      */     
/*      */     try {
/* 1043 */       int realParameterCount = this.parameterCount + getParameterIndexOffset();
/* 1044 */       Object batchArg = null;
/* 1045 */       if (this.batchCommandIndex != -1) {
/* 1046 */         batchArg = this.batchedArgs.get(this.batchCommandIndex);
/*      */       }
/* 1048 */       for (int i = 0; i < realParameterCount; i++) {
/* 1049 */         if (this.charEncoding != null) {
/* 1050 */           buf.append(new String(this.staticSqlStrings[i], this.charEncoding));
/*      */         } else {
/*      */           
/* 1053 */           buf.append(new String(this.staticSqlStrings[i]));
/*      */         } 
/*      */         
/* 1056 */         byte[] val = null;
/* 1057 */         if (batchArg != null && batchArg instanceof String) {
/* 1058 */           buf.append((String)batchArg);
/*      */         } else {
/*      */           
/* 1061 */           if (this.batchCommandIndex == -1) {
/* 1062 */             val = this.parameterValues[i];
/*      */           } else {
/* 1064 */             val = ((BatchParams)batchArg).parameterStrings[i];
/*      */           } 
/* 1066 */           boolean isStreamParam = false;
/* 1067 */           if (this.batchCommandIndex == -1) {
/* 1068 */             isStreamParam = this.isStream[i];
/*      */           } else {
/* 1070 */             isStreamParam = ((BatchParams)batchArg).isStream[i];
/*      */           } 
/* 1072 */           if (val == null && !isStreamParam) {
/* 1073 */             if (quoteStreamsAndUnknowns) {
/* 1074 */               buf.append("'");
/*      */             }
/*      */             
/* 1077 */             buf.append("** NOT SPECIFIED **");
/*      */             
/* 1079 */             if (quoteStreamsAndUnknowns) {
/* 1080 */               buf.append("'");
/*      */             }
/* 1082 */           } else if (isStreamParam) {
/* 1083 */             if (quoteStreamsAndUnknowns) {
/* 1084 */               buf.append("'");
/*      */             }
/*      */             
/* 1087 */             buf.append("** STREAM DATA **");
/*      */             
/* 1089 */             if (quoteStreamsAndUnknowns) {
/* 1090 */               buf.append("'");
/*      */             }
/*      */           }
/* 1093 */           else if (this.charConverter != null) {
/* 1094 */             buf.append(this.charConverter.toString(val));
/*      */           }
/* 1096 */           else if (this.charEncoding != null) {
/* 1097 */             buf.append(new String(val, this.charEncoding));
/*      */           } else {
/* 1099 */             buf.append(StringUtils.toAsciiString(val));
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1105 */       if (this.charEncoding != null) {
/* 1106 */         buf.append(new String(this.staticSqlStrings[this.parameterCount + getParameterIndexOffset()], this.charEncoding));
/*      */       }
/*      */       else {
/*      */         
/* 1110 */         buf.append(StringUtils.toAsciiString(this.staticSqlStrings[this.parameterCount + getParameterIndexOffset()]));
/*      */       }
/*      */     
/*      */     }
/* 1114 */     catch (UnsupportedEncodingException uue) {
/* 1115 */       throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1121 */     return buf.toString();
/*      */   }
/*      */   
/*      */   public synchronized void clearBatch() throws SQLException {
/* 1125 */     this.batchHasPlainStatements = false;
/*      */     
/* 1127 */     super.clearBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearParameters() throws SQLException {
/* 1141 */     checkClosed();
/*      */     
/* 1143 */     for (int i = 0; i < this.parameterValues.length; i++) {
/* 1144 */       this.parameterValues[i] = null;
/* 1145 */       this.parameterStreams[i] = null;
/* 1146 */       this.isStream[i] = false;
/* 1147 */       this.isNull[i] = false;
/* 1148 */       this.parameterTypes[i] = 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1159 */   public synchronized void close() throws SQLException { realClose(true, true); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void escapeblockFast(byte[] buf, Buffer packet, int size) throws SQLException {
/* 1164 */     int lastwritten = 0;
/*      */     
/* 1166 */     for (int i = 0; i < size; i++) {
/* 1167 */       byte b = buf[i];
/*      */       
/* 1169 */       if (b == 0) {
/*      */         
/* 1171 */         if (i > lastwritten) {
/* 1172 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*      */         
/* 1176 */         packet.writeByte((byte)92);
/* 1177 */         packet.writeByte((byte)48);
/* 1178 */         lastwritten = i + 1;
/*      */       }
/* 1180 */       else if (b == 92 || b == 39 || (!this.usingAnsiMode && b == 34)) {
/*      */ 
/*      */         
/* 1183 */         if (i > lastwritten) {
/* 1184 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1189 */         packet.writeByte((byte)92);
/* 1190 */         lastwritten = i;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1196 */     if (lastwritten < size) {
/* 1197 */       packet.writeBytesNoNull(buf, lastwritten, size - lastwritten);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void escapeblockFast(byte[] buf, ByteArrayOutputStream bytesOut, int size) {
/* 1203 */     int lastwritten = 0;
/*      */     
/* 1205 */     for (int i = 0; i < size; i++) {
/* 1206 */       byte b = buf[i];
/*      */       
/* 1208 */       if (b == 0) {
/*      */         
/* 1210 */         if (i > lastwritten) {
/* 1211 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*      */         
/* 1215 */         bytesOut.write(92);
/* 1216 */         bytesOut.write(48);
/* 1217 */         lastwritten = i + 1;
/*      */       }
/* 1219 */       else if (b == 92 || b == 39 || (!this.usingAnsiMode && b == 34)) {
/*      */ 
/*      */         
/* 1222 */         if (i > lastwritten) {
/* 1223 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*      */         
/* 1227 */         bytesOut.write(92);
/* 1228 */         lastwritten = i;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1234 */     if (lastwritten < size) {
/* 1235 */       bytesOut.write(buf, lastwritten, size - lastwritten);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1246 */   protected boolean checkReadOnlySafeStatement() throws SQLException { return (!this.connection.isReadOnly() || this.firstCharOfStmt == 'S'); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 1261 */     checkClosed();
/*      */     
/* 1263 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/* 1265 */     if (!checkReadOnlySafeStatement()) {
/* 1266 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1271 */     ResultSetInternalMethods rs = null;
/*      */     
/* 1273 */     CachedResultSetMetaData cachedMetadata = null;
/*      */     
/* 1275 */     synchronized (locallyScopedConn.getMutex()) {
/* 1276 */       this.lastQueryIsOnDupKeyUpdate = false;
/* 1277 */       if (this.retrieveGeneratedKeys)
/* 1278 */         this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyUpdateInSQL(); 
/* 1279 */       boolean doStreaming = createStreamingResultSet();
/*      */       
/* 1281 */       clearWarnings();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1291 */       if (doStreaming && this.connection.getNetTimeoutForStreamingResults() > 0)
/*      */       {
/* 1293 */         executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1299 */       this.batchedGeneratedKeys = null;
/*      */       
/* 1301 */       Buffer sendPacket = fillSendPacket();
/*      */       
/* 1303 */       String oldCatalog = null;
/*      */       
/* 1305 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1306 */         oldCatalog = locallyScopedConn.getCatalog();
/* 1307 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1313 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1314 */         cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
/*      */       }
/*      */       
/* 1317 */       Field[] metadataFromCache = null;
/*      */       
/* 1319 */       if (cachedMetadata != null) {
/* 1320 */         metadataFromCache = cachedMetadata.fields;
/*      */       }
/*      */       
/* 1323 */       boolean oldInfoMsgState = false;
/*      */       
/* 1325 */       if (this.retrieveGeneratedKeys) {
/* 1326 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 1327 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1339 */       if (locallyScopedConn.useMaxRows()) {
/* 1340 */         int rowLimit = -1;
/*      */         
/* 1342 */         if (this.firstCharOfStmt == 'S') {
/* 1343 */           if (this.hasLimitClause) {
/* 1344 */             rowLimit = this.maxRows;
/*      */           }
/* 1346 */           else if (this.maxRows <= 0) {
/* 1347 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */           } else {
/*      */             
/* 1350 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1356 */           executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1361 */         rs = executeInternal(rowLimit, sendPacket, doStreaming, (this.firstCharOfStmt == 'S'), metadataFromCache, false);
/*      */       }
/*      */       else {
/*      */         
/* 1365 */         rs = executeInternal(-1, sendPacket, doStreaming, (this.firstCharOfStmt == 'S'), metadataFromCache, false);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1370 */       if (cachedMetadata != null) {
/* 1371 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
/*      */       
/*      */       }
/* 1374 */       else if (rs.reallyResult() && locallyScopedConn.getCacheResultSetMetadata()) {
/* 1375 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, rs);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1380 */       if (this.retrieveGeneratedKeys) {
/* 1381 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 1382 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       } 
/*      */       
/* 1385 */       if (oldCatalog != null) {
/* 1386 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 1389 */       if (rs != null) {
/* 1390 */         this.lastInsertId = rs.getUpdateID();
/*      */         
/* 1392 */         this.results = rs;
/*      */       } 
/*      */     } 
/*      */     
/* 1396 */     return (rs != null && rs.reallyResult());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch() throws SQLException {
/* 1414 */     checkClosed();
/*      */     
/* 1416 */     if (this.connection.isReadOnly()) {
/* 1417 */       throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1422 */     synchronized (this.connection.getMutex()) {
/* 1423 */       if (this.batchedArgs == null || this.batchedArgs.size() == 0) {
/* 1424 */         return new int[0];
/*      */       }
/*      */ 
/*      */       
/* 1428 */       int batchTimeout = this.timeoutInMillis;
/* 1429 */       this.timeoutInMillis = 0;
/*      */       
/* 1431 */       resetCancelledState();
/*      */       
/*      */       try {
/* 1434 */         clearWarnings();
/*      */         
/* 1436 */         if (!this.batchHasPlainStatements && this.connection.getRewriteBatchedStatements()) {
/*      */ 
/*      */ 
/*      */           
/* 1440 */           if (canRewriteAsMultiValueInsertAtSqlLevel()) {
/* 1441 */             return executeBatchedInserts(batchTimeout);
/*      */           }
/*      */           
/* 1444 */           if (this.connection.versionMeetsMinimum(4, 1, 0) && !this.batchHasPlainStatements && this.batchedArgs != null && this.batchedArgs.size() > 3)
/*      */           {
/*      */ 
/*      */             
/* 1448 */             return executePreparedBatchAsMultiStatement(batchTimeout);
/*      */           }
/*      */         } 
/*      */         
/* 1452 */         return executeBatchSerially(batchTimeout);
/*      */       } finally {
/* 1454 */         clearBatch();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1460 */   public boolean canRewriteAsMultiValueInsertAtSqlLevel() throws SQLException { return this.parseInfo.canRewriteAsMultiValueInsert; }
/*      */ 
/*      */ 
/*      */   
/* 1464 */   protected int getLocationOfOnDuplicateKeyUpdate() { return this.parseInfo.locationOfOnDuplicateKeyUpdate; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] executePreparedBatchAsMultiStatement(int batchTimeout) throws SQLException {
/* 1478 */     synchronized (this.connection.getMutex()) {
/*      */       
/* 1480 */       if (this.batchedValuesClause == null) {
/* 1481 */         this.batchedValuesClause = this.originalSql + ";";
/*      */       }
/*      */       
/* 1484 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/* 1486 */       boolean multiQueriesEnabled = locallyScopedConn.getAllowMultiQueries();
/* 1487 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       
/*      */       try {
/* 1490 */         clearWarnings();
/*      */         
/* 1492 */         int numBatchedArgs = this.batchedArgs.size();
/*      */         
/* 1494 */         if (this.retrieveGeneratedKeys) {
/* 1495 */           this.batchedGeneratedKeys = new ArrayList(numBatchedArgs);
/*      */         }
/*      */         
/* 1498 */         int numValuesPerBatch = computeBatchSize(numBatchedArgs);
/*      */         
/* 1500 */         if (numBatchedArgs < numValuesPerBatch) {
/* 1501 */           numValuesPerBatch = numBatchedArgs;
/*      */         }
/*      */         
/* 1504 */         PreparedStatement batchedStatement = null;
/*      */         
/* 1506 */         int batchedParamIndex = 1;
/* 1507 */         int numberToExecuteAsMultiValue = 0;
/* 1508 */         int batchCounter = 0;
/* 1509 */         int updateCountCounter = 0;
/* 1510 */         int[] updateCounts = new int[numBatchedArgs];
/* 1511 */         SQLException sqlEx = null;
/*      */         
/*      */         try {
/* 1514 */           if (!multiQueriesEnabled) {
/* 1515 */             locallyScopedConn.getIO().enableMultiQueries();
/*      */           }
/*      */           
/* 1518 */           if (this.retrieveGeneratedKeys) {
/* 1519 */             batchedStatement = locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch), 1);
/*      */           }
/*      */           else {
/*      */             
/* 1523 */             batchedStatement = locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch));
/*      */           } 
/*      */ 
/*      */           
/* 1527 */           if (locallyScopedConn.getEnableQueryTimeouts() && batchTimeout != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */             
/* 1530 */             timeoutTask = new StatementImpl.CancelTask(this, (StatementImpl)batchedStatement);
/* 1531 */             ConnectionImpl.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */           } 
/*      */ 
/*      */           
/* 1535 */           if (numBatchedArgs < numValuesPerBatch) {
/* 1536 */             numberToExecuteAsMultiValue = numBatchedArgs;
/*      */           } else {
/* 1538 */             numberToExecuteAsMultiValue = numBatchedArgs / numValuesPerBatch;
/*      */           } 
/*      */           
/* 1541 */           int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch;
/*      */           
/* 1543 */           for (int i = 0; i < numberArgsToExecute; i++) {
/* 1544 */             if (i != 0 && i % numValuesPerBatch == 0) {
/*      */               try {
/* 1546 */                 batchedStatement.execute();
/* 1547 */               } catch (SQLException ex) {
/* 1548 */                 sqlEx = handleExceptionForBatch(batchCounter, numValuesPerBatch, updateCounts, ex);
/*      */               } 
/*      */ 
/*      */               
/* 1552 */               updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts);
/*      */ 
/*      */ 
/*      */               
/* 1556 */               batchedStatement.clearParameters();
/* 1557 */               batchedParamIndex = 1;
/*      */             } 
/*      */             
/* 1560 */             batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 1566 */             batchedStatement.execute();
/* 1567 */           } catch (SQLException ex) {
/* 1568 */             sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
/*      */           } 
/*      */ 
/*      */           
/* 1572 */           updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts);
/*      */ 
/*      */ 
/*      */           
/* 1576 */           batchedStatement.clearParameters();
/*      */           
/* 1578 */           numValuesPerBatch = numBatchedArgs - batchCounter;
/*      */         } finally {
/* 1580 */           if (batchedStatement != null) {
/* 1581 */             batchedStatement.close();
/*      */           }
/*      */         } 
/*      */         
/*      */         try {
/* 1586 */           if (numValuesPerBatch > 0) {
/*      */             
/* 1588 */             if (this.retrieveGeneratedKeys) {
/* 1589 */               batchedStatement = locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch), 1);
/*      */             }
/*      */             else {
/*      */               
/* 1593 */               batchedStatement = locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch));
/*      */             } 
/*      */ 
/*      */             
/* 1597 */             if (timeoutTask != null) {
/* 1598 */               timeoutTask.toCancel = (StatementImpl)batchedStatement;
/*      */             }
/*      */             
/* 1601 */             batchedParamIndex = 1;
/*      */             
/* 1603 */             while (batchCounter < numBatchedArgs) {
/* 1604 */               batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/* 1610 */               batchedStatement.execute();
/* 1611 */             } catch (SQLException ex) {
/* 1612 */               sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
/*      */             } 
/*      */ 
/*      */             
/* 1616 */             updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts);
/*      */ 
/*      */ 
/*      */             
/* 1620 */             batchedStatement.clearParameters();
/*      */           } 
/*      */           
/* 1623 */           if (timeoutTask != null) {
/* 1624 */             if (timeoutTask.caughtWhileCancelling != null) {
/* 1625 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/* 1628 */             timeoutTask.cancel();
/* 1629 */             timeoutTask = null;
/*      */           } 
/*      */           
/* 1632 */           if (sqlEx != null) {
/* 1633 */             throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1638 */           return updateCounts;
/*      */         } finally {
/* 1640 */           if (batchedStatement != null) {
/* 1641 */             batchedStatement.close();
/*      */           }
/*      */         } 
/*      */       } finally {
/* 1645 */         if (timeoutTask != null) {
/* 1646 */           timeoutTask.cancel();
/*      */         }
/*      */         
/* 1649 */         resetCancelledState();
/*      */         
/* 1651 */         if (!multiQueriesEnabled) {
/* 1652 */           locallyScopedConn.getIO().disableMultiQueries();
/*      */         }
/*      */         
/* 1655 */         clearBatch();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private String generateMultiStatementForBatch(int numBatches) {
/* 1661 */     StringBuffer newStatementSql = new StringBuffer((this.originalSql.length() + 1) * numBatches);
/*      */ 
/*      */     
/* 1664 */     newStatementSql.append(this.originalSql);
/*      */     
/* 1666 */     for (int i = 0; i < numBatches - 1; i++) {
/* 1667 */       newStatementSql.append(';');
/* 1668 */       newStatementSql.append(this.originalSql);
/*      */     } 
/*      */     
/* 1671 */     return newStatementSql.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] executeBatchedInserts(int batchTimeout) throws SQLException {
/* 1684 */     String valuesClause = getValuesClause();
/*      */     
/* 1686 */     Connection locallyScopedConn = this.connection;
/*      */     
/* 1688 */     if (valuesClause == null) {
/* 1689 */       return executeBatchSerially(batchTimeout);
/*      */     }
/*      */     
/* 1692 */     int numBatchedArgs = this.batchedArgs.size();
/*      */     
/* 1694 */     if (this.retrieveGeneratedKeys) {
/* 1695 */       this.batchedGeneratedKeys = new ArrayList(numBatchedArgs);
/*      */     }
/*      */     
/* 1698 */     int numValuesPerBatch = computeBatchSize(numBatchedArgs);
/*      */     
/* 1700 */     if (numBatchedArgs < numValuesPerBatch) {
/* 1701 */       numValuesPerBatch = numBatchedArgs;
/*      */     }
/*      */     
/* 1704 */     PreparedStatement batchedStatement = null;
/*      */     
/* 1706 */     int batchedParamIndex = 1;
/* 1707 */     int updateCountRunningTotal = 0;
/* 1708 */     int numberToExecuteAsMultiValue = 0;
/* 1709 */     int batchCounter = 0;
/* 1710 */     StatementImpl.CancelTask timeoutTask = null;
/* 1711 */     SQLException sqlEx = null;
/*      */     
/* 1713 */     int[] updateCounts = new int[numBatchedArgs];
/*      */     
/* 1715 */     for (int i = 0; i < this.batchedArgs.size(); i++) {
/* 1716 */       updateCounts[i] = 1;
/*      */     }
/*      */     
/*      */     try {
/*      */       try {
/* 1721 */         batchedStatement = prepareBatchedInsertSQL((ConnectionImpl)locallyScopedConn, numValuesPerBatch);
/*      */ 
/*      */         
/* 1724 */         if (this.connection.getEnableQueryTimeouts() && batchTimeout != 0 && this.connection.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */           
/* 1727 */           timeoutTask = new StatementImpl.CancelTask(this, (StatementImpl)batchedStatement);
/*      */           
/* 1729 */           ConnectionImpl.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */         } 
/*      */ 
/*      */         
/* 1733 */         if (numBatchedArgs < numValuesPerBatch) {
/* 1734 */           numberToExecuteAsMultiValue = numBatchedArgs;
/*      */         } else {
/* 1736 */           numberToExecuteAsMultiValue = numBatchedArgs / numValuesPerBatch;
/*      */         } 
/*      */ 
/*      */         
/* 1740 */         int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch;
/*      */ 
/*      */         
/* 1743 */         for (int i = 0; i < numberArgsToExecute; i++) {
/* 1744 */           if (i != 0 && i % numValuesPerBatch == 0) {
/*      */             try {
/* 1746 */               updateCountRunningTotal += batchedStatement.executeUpdate();
/*      */             }
/* 1748 */             catch (SQLException ex) {
/* 1749 */               sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
/*      */             } 
/*      */ 
/*      */             
/* 1753 */             getBatchedGeneratedKeys(batchedStatement);
/* 1754 */             batchedStatement.clearParameters();
/* 1755 */             batchedParamIndex = 1;
/*      */           } 
/*      */ 
/*      */           
/* 1759 */           batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1765 */           updateCountRunningTotal += batchedStatement.executeUpdate();
/* 1766 */         } catch (SQLException ex) {
/* 1767 */           sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
/*      */         } 
/*      */ 
/*      */         
/* 1771 */         getBatchedGeneratedKeys(batchedStatement);
/*      */         
/* 1773 */         numValuesPerBatch = numBatchedArgs - batchCounter;
/*      */       } finally {
/* 1775 */         if (batchedStatement != null) {
/* 1776 */           batchedStatement.close();
/*      */         }
/*      */       } 
/*      */       
/*      */       try {
/* 1781 */         if (numValuesPerBatch > 0) {
/* 1782 */           batchedStatement = prepareBatchedInsertSQL((ConnectionImpl)locallyScopedConn, numValuesPerBatch);
/*      */ 
/*      */ 
/*      */           
/* 1786 */           if (timeoutTask != null) {
/* 1787 */             timeoutTask.toCancel = (StatementImpl)batchedStatement;
/*      */           }
/*      */           
/* 1790 */           batchedParamIndex = 1;
/*      */           
/* 1792 */           while (batchCounter < numBatchedArgs) {
/* 1793 */             batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, this.batchedArgs.get(batchCounter++));
/*      */           }
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/* 1799 */             updateCountRunningTotal += batchedStatement.executeUpdate();
/* 1800 */           } catch (SQLException ex) {
/* 1801 */             sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
/*      */           } 
/*      */ 
/*      */           
/* 1805 */           getBatchedGeneratedKeys(batchedStatement);
/*      */         } 
/*      */         
/* 1808 */         if (sqlEx != null) {
/* 1809 */           throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1814 */         return updateCounts;
/*      */       } finally {
/* 1816 */         if (batchedStatement != null) {
/* 1817 */           batchedStatement.close();
/*      */         }
/*      */       } 
/*      */     } finally {
/* 1821 */       if (timeoutTask != null) {
/* 1822 */         timeoutTask.cancel();
/*      */       }
/*      */       
/* 1825 */       resetCancelledState();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 1830 */   protected String getValuesClause() throws SQLException { return this.parseInfo.valuesClause; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int computeBatchSize(int numBatchedArgs) throws SQLException {
/* 1842 */     long[] combinedValues = computeMaxParameterSetSizeAndBatchSize(numBatchedArgs);
/*      */     
/* 1844 */     long maxSizeOfParameterSet = combinedValues[0];
/* 1845 */     long sizeOfEntireBatch = combinedValues[1];
/*      */     
/* 1847 */     int maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */     
/* 1849 */     if (sizeOfEntireBatch < (maxAllowedPacket - this.originalSql.length())) {
/* 1850 */       return numBatchedArgs;
/*      */     }
/*      */     
/* 1853 */     return (int)Math.max(1L, (maxAllowedPacket - this.originalSql.length()) / maxSizeOfParameterSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs) throws SQLException {
/* 1862 */     long sizeOfEntireBatch = 0L;
/* 1863 */     long maxSizeOfParameterSet = 0L;
/*      */     
/* 1865 */     for (int i = 0; i < numBatchedArgs; i++) {
/* 1866 */       BatchParams paramArg = this.batchedArgs.get(i);
/*      */ 
/*      */       
/* 1869 */       boolean[] isNullBatch = paramArg.isNull;
/* 1870 */       boolean[] isStreamBatch = paramArg.isStream;
/*      */       
/* 1872 */       long sizeOfParameterSet = 0L;
/*      */       
/* 1874 */       for (int j = 0; j < isNullBatch.length; j++) {
/* 1875 */         if (!isNullBatch[j]) {
/*      */           
/* 1877 */           if (isStreamBatch[j]) {
/* 1878 */             int streamLength = paramArg.streamLengths[j];
/*      */             
/* 1880 */             if (streamLength != -1) {
/* 1881 */               sizeOfParameterSet += (streamLength * 2);
/*      */             } else {
/* 1883 */               int paramLength = (paramArg.parameterStrings[j]).length;
/* 1884 */               sizeOfParameterSet += paramLength;
/*      */             } 
/*      */           } else {
/* 1887 */             sizeOfParameterSet += (paramArg.parameterStrings[j]).length;
/*      */           } 
/*      */         } else {
/* 1890 */           sizeOfParameterSet += 4L;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1902 */       if (getValuesClause() != null) {
/* 1903 */         sizeOfParameterSet += (getValuesClause().length() + 1);
/*      */       } else {
/* 1905 */         sizeOfParameterSet += (this.originalSql.length() + 1);
/*      */       } 
/*      */       
/* 1908 */       sizeOfEntireBatch += sizeOfParameterSet;
/*      */       
/* 1910 */       if (sizeOfParameterSet > maxSizeOfParameterSet) {
/* 1911 */         maxSizeOfParameterSet = sizeOfParameterSet;
/*      */       }
/*      */     } 
/*      */     
/* 1915 */     return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int[] executeBatchSerially(int batchTimeout) throws SQLException {
/* 1928 */     Connection locallyScopedConn = this.connection;
/*      */     
/* 1930 */     if (locallyScopedConn == null) {
/* 1931 */       checkClosed();
/*      */     }
/*      */     
/* 1934 */     int[] updateCounts = null;
/*      */     
/* 1936 */     if (this.batchedArgs != null) {
/* 1937 */       int nbrCommands = this.batchedArgs.size();
/* 1938 */       updateCounts = new int[nbrCommands];
/*      */       
/* 1940 */       for (int i = 0; i < nbrCommands; i++) {
/* 1941 */         updateCounts[i] = -3;
/*      */       }
/*      */       
/* 1944 */       SQLException sqlEx = null;
/*      */       
/* 1946 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       
/*      */       try {
/* 1949 */         if (this.connection.getEnableQueryTimeouts() && batchTimeout != 0 && this.connection.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */           
/* 1952 */           timeoutTask = new StatementImpl.CancelTask(this, this);
/* 1953 */           ConnectionImpl.getCancelTimer().schedule(timeoutTask, batchTimeout);
/*      */         } 
/*      */ 
/*      */         
/* 1957 */         if (this.retrieveGeneratedKeys) {
/* 1958 */           this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */         }
/*      */         
/* 1961 */         for (this.batchCommandIndex = 0; this.batchCommandIndex < nbrCommands; this.batchCommandIndex++) {
/* 1962 */           Object arg = this.batchedArgs.get(this.batchCommandIndex);
/*      */           
/* 1964 */           if (arg instanceof String) {
/* 1965 */             updateCounts[this.batchCommandIndex] = executeUpdate((String)arg);
/*      */           } else {
/* 1967 */             BatchParams paramArg = (BatchParams)arg;
/*      */             
/*      */             try {
/* 1970 */               updateCounts[this.batchCommandIndex] = executeUpdate(paramArg.parameterStrings, paramArg.parameterStreams, paramArg.isStream, paramArg.streamLengths, paramArg.isNull, true);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1975 */               if (this.retrieveGeneratedKeys) {
/* 1976 */                 ResultSet rs = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 1994 */             catch (SQLException ex) {
/* 1995 */               updateCounts[this.batchCommandIndex] = -3;
/*      */               
/* 1997 */               if (this.continueBatchOnError && !(ex instanceof MySQLTimeoutException) && !(ex instanceof MySQLStatementCancelledException) && !hasDeadlockOrTimeoutRolledBackTx(ex)) {
/*      */ 
/*      */ 
/*      */                 
/* 2001 */                 sqlEx = ex;
/*      */               } else {
/* 2003 */                 int[] newUpdateCounts = new int[this.batchCommandIndex];
/* 2004 */                 System.arraycopy(updateCounts, 0, newUpdateCounts, 0, this.batchCommandIndex);
/*      */ 
/*      */                 
/* 2007 */                 throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2015 */         if (sqlEx != null) {
/* 2016 */           throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */         }
/*      */       } finally {
/*      */         
/* 2020 */         this.batchCommandIndex = -1;
/*      */         
/* 2022 */         if (timeoutTask != null) {
/* 2023 */           timeoutTask.cancel();
/*      */         }
/*      */         
/* 2026 */         resetCancelledState();
/*      */       } 
/*      */     } 
/*      */     
/* 2030 */     return (updateCounts != null) ? updateCounts : new int[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, Field[] metadataFromCache, boolean isBatch) throws SQLException {
/*      */     try {
/*      */       ResultSetInternalMethods rs;
/* 2061 */       resetCancelledState();
/*      */       
/* 2063 */       ConnectionImpl locallyScopedConnection = this.connection;
/*      */       
/* 2065 */       this.numberOfExecutions++;
/*      */       
/* 2067 */       if (this.doPingInstead) {
/* 2068 */         doPingInstead();
/*      */         
/* 2070 */         return this.results;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2075 */       StatementImpl.CancelTask timeoutTask = null;
/*      */       
/*      */       try {
/* 2078 */         if (locallyScopedConnection.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && locallyScopedConnection.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */           
/* 2081 */           timeoutTask = new StatementImpl.CancelTask(this, this);
/* 2082 */           ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         } 
/*      */ 
/*      */         
/* 2086 */         rs = locallyScopedConnection.execSQL(this, null, maxRowsToRetrieve, sendPacket, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, metadataFromCache, isBatch);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2091 */         if (timeoutTask != null) {
/* 2092 */           timeoutTask.cancel();
/*      */           
/* 2094 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 2095 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 2098 */           timeoutTask = null;
/*      */         } 
/*      */         
/* 2101 */         synchronized (this.cancelTimeoutMutex) {
/* 2102 */           if (this.wasCancelled) {
/* 2103 */             Object object = null;
/*      */             
/* 2105 */             if (this.wasCancelledByTimeout) {
/* 2106 */               MySQLTimeoutException mySQLTimeoutException = new MySQLTimeoutException();
/*      */             } else {
/* 2108 */               object = new MySQLStatementCancelledException();
/*      */             } 
/*      */             
/* 2111 */             resetCancelledState();
/*      */             
/* 2113 */             throw object;
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 2117 */         if (timeoutTask != null) {
/* 2118 */           timeoutTask.cancel();
/*      */         }
/*      */       } 
/*      */       
/* 2122 */       return rs;
/* 2123 */     } catch (NullPointerException npe) {
/* 2124 */       checkClosed();
/*      */ 
/*      */ 
/*      */       
/* 2128 */       throw npe;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLException {
/* 2142 */     checkClosed();
/*      */     
/* 2144 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/* 2146 */     checkForDml(this.originalSql, this.firstCharOfStmt);
/*      */     
/* 2148 */     CachedResultSetMetaData cachedMetadata = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2154 */     synchronized (locallyScopedConn.getMutex()) {
/* 2155 */       clearWarnings();
/*      */       
/* 2157 */       boolean doStreaming = createStreamingResultSet();
/*      */       
/* 2159 */       this.batchedGeneratedKeys = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2169 */       if (doStreaming && this.connection.getNetTimeoutForStreamingResults() > 0)
/*      */       {
/* 2171 */         locallyScopedConn.execSQL(this, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults(), -1, null, 1003, 1007, false, this.currentCatalog, null, false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2178 */       Buffer sendPacket = fillSendPacket();
/*      */       
/* 2180 */       if (this.results != null && 
/* 2181 */         !this.connection.getHoldResultsOpenOverStatementClose() && 
/* 2182 */         !this.holdResultsOpenOverClose) {
/* 2183 */         this.results.realClose(false);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2188 */       String oldCatalog = null;
/*      */       
/* 2190 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 2191 */         oldCatalog = locallyScopedConn.getCatalog();
/* 2192 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2198 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 2199 */         cachedMetadata = locallyScopedConn.getCachedMetaData(this.originalSql);
/*      */       }
/*      */       
/* 2202 */       Field[] metadataFromCache = null;
/*      */       
/* 2204 */       if (cachedMetadata != null) {
/* 2205 */         metadataFromCache = cachedMetadata.fields;
/*      */       }
/*      */       
/* 2208 */       if (locallyScopedConn.useMaxRows()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2215 */         if (this.hasLimitClause) {
/* 2216 */           this.results = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), true, metadataFromCache, false);
/*      */         }
/*      */         else {
/*      */           
/* 2220 */           if (this.maxRows <= 0) {
/* 2221 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */           } else {
/*      */             
/* 2224 */             executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */           } 
/*      */ 
/*      */           
/* 2228 */           this.results = executeInternal(-1, sendPacket, doStreaming, true, metadataFromCache, false);
/*      */ 
/*      */ 
/*      */           
/* 2232 */           if (oldCatalog != null) {
/* 2233 */             this.connection.setCatalog(oldCatalog);
/*      */           }
/*      */         } 
/*      */       } else {
/* 2237 */         this.results = executeInternal(-1, sendPacket, doStreaming, true, metadataFromCache, false);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2242 */       if (oldCatalog != null) {
/* 2243 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */       
/* 2246 */       if (cachedMetadata != null) {
/* 2247 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
/*      */       
/*      */       }
/* 2250 */       else if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 2251 */         locallyScopedConn.initializeResultsMetadataFromCache(this.originalSql, null, this.results);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2257 */     this.lastInsertId = this.results.getUpdateID();
/*      */     
/* 2259 */     return this.results;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2274 */   public int executeUpdate() throws SQLException { return executeUpdate(true, false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int executeUpdate(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch) throws SQLException {
/* 2284 */     if (clearBatchedGeneratedKeysAndWarnings) {
/* 2285 */       clearWarnings();
/* 2286 */       this.batchedGeneratedKeys = null;
/*      */     } 
/*      */     
/* 2289 */     return executeUpdate(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull, isBatch);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int executeUpdate(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths, boolean[] batchedIsNull, boolean isReallyBatch) throws SQLException {
/* 2317 */     checkClosed();
/*      */     
/* 2319 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/* 2321 */     if (locallyScopedConn.isReadOnly()) {
/* 2322 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2327 */     if (this.firstCharOfStmt == 'S' && isSelectQuery())
/*      */     {
/* 2329 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 2333 */     if (this.results != null && 
/* 2334 */       !locallyScopedConn.getHoldResultsOpenOverStatementClose()) {
/* 2335 */       this.results.realClose(false);
/*      */     }
/*      */ 
/*      */     
/* 2339 */     ResultSetInternalMethods rs = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2344 */     synchronized (locallyScopedConn.getMutex()) {
/* 2345 */       Buffer sendPacket = fillSendPacket(batchedParameterStrings, batchedParameterStreams, batchedIsStream, batchedStreamLengths);
/*      */ 
/*      */ 
/*      */       
/* 2349 */       String oldCatalog = null;
/*      */       
/* 2351 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 2352 */         oldCatalog = locallyScopedConn.getCatalog();
/* 2353 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2359 */       if (locallyScopedConn.useMaxRows()) {
/* 2360 */         executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */       }
/*      */ 
/*      */       
/* 2364 */       boolean oldInfoMsgState = false;
/*      */       
/* 2366 */       if (this.retrieveGeneratedKeys) {
/* 2367 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 2368 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       } 
/*      */       
/* 2371 */       rs = executeInternal(-1, sendPacket, false, false, null, isReallyBatch);
/*      */ 
/*      */       
/* 2374 */       if (this.retrieveGeneratedKeys) {
/* 2375 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 2376 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       } 
/*      */       
/* 2379 */       if (oldCatalog != null) {
/* 2380 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */     } 
/*      */     
/* 2384 */     this.results = rs;
/*      */     
/* 2386 */     this.updateCount = rs.getUpdateCount();
/*      */     
/* 2388 */     if (containsOnDuplicateKeyUpdateInSQL() && this.compensateForOnDuplicateKeyUpdate)
/*      */     {
/* 2390 */       if (this.updateCount == 2L || this.updateCount == 0L) {
/* 2391 */         this.updateCount = 1L;
/*      */       }
/*      */     }
/*      */     
/* 2395 */     int truncatedUpdateCount = 0;
/*      */     
/* 2397 */     if (this.updateCount > 2147483647L) {
/* 2398 */       truncatedUpdateCount = Integer.MAX_VALUE;
/*      */     } else {
/* 2400 */       truncatedUpdateCount = (int)this.updateCount;
/*      */     } 
/*      */     
/* 2403 */     this.lastInsertId = rs.getUpdateID();
/*      */     
/* 2405 */     return truncatedUpdateCount;
/*      */   }
/*      */ 
/*      */   
/* 2409 */   protected boolean containsOnDuplicateKeyUpdateInSQL() { return this.parseInfo.isOnDuplicateKeyUpdate; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2424 */   protected Buffer fillSendPacket() throws SQLException { return fillSendPacket(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths) throws SQLException {
/* 2448 */     Buffer sendPacket = this.connection.getIO().getSharedSendPacket();
/*      */     
/* 2450 */     sendPacket.clear();
/*      */     
/* 2452 */     sendPacket.writeByte((byte)3);
/*      */     
/* 2454 */     boolean useStreamLengths = this.connection.getUseStreamLengthsInPrepStmts();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2461 */     int ensurePacketSize = 0;
/*      */     
/* 2463 */     String statementComment = this.connection.getStatementComment();
/*      */     
/* 2465 */     byte[] commentAsBytes = null;
/*      */     
/* 2467 */     if (statementComment != null) {
/* 2468 */       if (this.charConverter != null) {
/* 2469 */         commentAsBytes = this.charConverter.toBytes(statementComment);
/*      */       } else {
/* 2471 */         commentAsBytes = StringUtils.getBytes(statementComment, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2477 */       ensurePacketSize += commentAsBytes.length;
/* 2478 */       ensurePacketSize += 6;
/*      */     } 
/*      */     
/* 2481 */     for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 2482 */       if (batchedIsStream[i] && useStreamLengths) {
/* 2483 */         ensurePacketSize += batchedStreamLengths[i];
/*      */       }
/*      */     } 
/*      */     
/* 2487 */     if (ensurePacketSize != 0) {
/* 2488 */       sendPacket.ensureCapacity(ensurePacketSize);
/*      */     }
/*      */     
/* 2491 */     if (commentAsBytes != null) {
/* 2492 */       sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2493 */       sendPacket.writeBytesNoNull(commentAsBytes);
/* 2494 */       sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */     } 
/*      */     
/* 2497 */     for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 2498 */       checkAllParametersSet(batchedParameterStrings[i], batchedParameterStreams[i], i);
/*      */ 
/*      */       
/* 2501 */       sendPacket.writeBytesNoNull(this.staticSqlStrings[i]);
/*      */       
/* 2503 */       if (batchedIsStream[i]) {
/* 2504 */         streamToBytes(sendPacket, batchedParameterStreams[i], true, batchedStreamLengths[i], useStreamLengths);
/*      */       } else {
/*      */         
/* 2507 */         sendPacket.writeBytesNoNull(batchedParameterStrings[i]);
/*      */       } 
/*      */     } 
/*      */     
/* 2511 */     sendPacket.writeBytesNoNull(this.staticSqlStrings[batchedParameterStrings.length]);
/*      */ 
/*      */     
/* 2514 */     return sendPacket;
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkAllParametersSet(byte[] parameterString, InputStream parameterStream, int columnIndex) throws SQLException {
/* 2519 */     if (parameterString == null && parameterStream == null) {
/*      */       
/* 2521 */       System.out.println(toString());
/* 2522 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.40") + (columnIndex + 1), "07001", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected PreparedStatement prepareBatchedInsertSQL(ConnectionImpl localConn, int numBatches) throws SQLException {
/* 2532 */     PreparedStatement pstmt = new PreparedStatement(localConn, "batch statement, no sql available", this.currentCatalog, this.parseInfo.getParseInfoForBatch(numBatches));
/* 2533 */     pstmt.setRetrieveGeneratedKeys(this.retrieveGeneratedKeys);
/*      */     
/* 2535 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytesRepresentation(int parameterIndex) throws SQLException {
/* 2551 */     if (this.isStream[parameterIndex]) {
/* 2552 */       return streamToBytes(this.parameterStreams[parameterIndex], false, this.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2557 */     byte[] parameterVal = this.parameterValues[parameterIndex];
/*      */     
/* 2559 */     if (parameterVal == null) {
/* 2560 */       return null;
/*      */     }
/*      */     
/* 2563 */     if (parameterVal[0] == 39 && parameterVal[parameterVal.length - 1] == 39) {
/*      */       
/* 2565 */       byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2566 */       System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */ 
/*      */       
/* 2569 */       return valNoQuotes;
/*      */     } 
/*      */     
/* 2572 */     return parameterVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getBytesRepresentationForBatch(int parameterIndex, int commandIndex) throws SQLException {
/* 2584 */     Object batchedArg = this.batchedArgs.get(commandIndex);
/* 2585 */     if (batchedArg instanceof String) {
/*      */       try {
/* 2587 */         return ((String)batchedArg).getBytes(this.charEncoding);
/*      */       }
/* 2589 */       catch (UnsupportedEncodingException uue) {
/* 2590 */         throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2597 */     BatchParams params = (BatchParams)batchedArg;
/* 2598 */     if (params.isStream[parameterIndex]) {
/* 2599 */       return streamToBytes(params.parameterStreams[parameterIndex], false, params.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */     }
/*      */     
/* 2602 */     byte[] parameterVal = params.parameterStrings[parameterIndex];
/* 2603 */     if (parameterVal == null) {
/* 2604 */       return null;
/*      */     }
/* 2606 */     if (parameterVal[0] == 39 && parameterVal[parameterVal.length - 1] == 39) {
/*      */       
/* 2608 */       byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 2609 */       System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */ 
/*      */       
/* 2612 */       return valNoQuotes;
/*      */     } 
/*      */     
/* 2615 */     return parameterVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String getDateTimePattern(String dt, boolean toTime) throws Exception {
/* 2625 */     int dtLength = (dt != null) ? dt.length() : 0;
/*      */     
/* 2627 */     if (dtLength >= 8 && dtLength <= 10) {
/* 2628 */       int dashCount = 0;
/* 2629 */       boolean isDateOnly = true;
/*      */       
/* 2631 */       for (int i = 0; i < dtLength; i++) {
/* 2632 */         char c = dt.charAt(i);
/*      */         
/* 2634 */         if (!Character.isDigit(c) && c != '-') {
/* 2635 */           isDateOnly = false;
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 2640 */         if (c == '-') {
/* 2641 */           dashCount++;
/*      */         }
/*      */       } 
/*      */       
/* 2645 */       if (isDateOnly && dashCount == 2) {
/* 2646 */         return "yyyy-MM-dd";
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2653 */     boolean colonsOnly = true;
/*      */     
/* 2655 */     for (int i = 0; i < dtLength; i++) {
/* 2656 */       char c = dt.charAt(i);
/*      */       
/* 2658 */       if (!Character.isDigit(c) && c != ':') {
/* 2659 */         colonsOnly = false;
/*      */         
/*      */         break;
/*      */       } 
/*      */     } 
/*      */     
/* 2665 */     if (colonsOnly) {
/* 2666 */       return "HH:mm:ss";
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2675 */     StringReader reader = new StringReader(dt + " ");
/* 2676 */     ArrayList vec = new ArrayList();
/* 2677 */     ArrayList vecRemovelist = new ArrayList();
/* 2678 */     Object[] nv = new Object[3];
/*      */     
/* 2680 */     nv[0] = Constants.characterValueOf('y');
/* 2681 */     nv[1] = new StringBuffer();
/* 2682 */     nv[2] = Constants.integerValueOf(0);
/* 2683 */     vec.add(nv);
/*      */     
/* 2685 */     if (toTime) {
/* 2686 */       nv = new Object[3];
/* 2687 */       nv[0] = Constants.characterValueOf('h');
/* 2688 */       nv[1] = new StringBuffer();
/* 2689 */       nv[2] = Constants.integerValueOf(0);
/* 2690 */       vec.add(nv);
/*      */     } 
/*      */     int z;
/* 2693 */     while ((z = reader.read()) != -1) {
/* 2694 */       char separator = (char)z;
/* 2695 */       int maxvecs = vec.size();
/*      */       
/* 2697 */       for (int count = 0; count < maxvecs; count++) {
/* 2698 */         Object[] v = vec.get(count);
/* 2699 */         int n = ((Integer)v[2]).intValue();
/* 2700 */         char c = getSuccessor(((Character)v[0]).charValue(), n);
/*      */         
/* 2702 */         if (!Character.isLetterOrDigit(separator)) {
/* 2703 */           if (c == ((Character)v[0]).charValue() && c != 'S') {
/* 2704 */             vecRemovelist.add(v);
/*      */           } else {
/* 2706 */             ((StringBuffer)v[1]).append(separator);
/*      */             
/* 2708 */             if (c == 'X' || c == 'Y') {
/* 2709 */               v[2] = Constants.integerValueOf(4);
/*      */             }
/*      */           } 
/*      */         } else {
/* 2713 */           if (c == 'X') {
/* 2714 */             c = 'y';
/* 2715 */             nv = new Object[3];
/* 2716 */             nv[1] = (new StringBuffer(((StringBuffer)v[1]).toString())).append('M');
/*      */             
/* 2718 */             nv[0] = Constants.characterValueOf('M');
/* 2719 */             nv[2] = Constants.integerValueOf(1);
/* 2720 */             vec.add(nv);
/* 2721 */           } else if (c == 'Y') {
/* 2722 */             c = 'M';
/* 2723 */             nv = new Object[3];
/* 2724 */             nv[1] = (new StringBuffer(((StringBuffer)v[1]).toString())).append('d');
/*      */             
/* 2726 */             nv[0] = Constants.characterValueOf('d');
/* 2727 */             nv[2] = Constants.integerValueOf(1);
/* 2728 */             vec.add(nv);
/*      */           } 
/*      */           
/* 2731 */           ((StringBuffer)v[1]).append(c);
/*      */           
/* 2733 */           if (c == ((Character)v[0]).charValue()) {
/* 2734 */             v[2] = Constants.integerValueOf(n + 1);
/*      */           } else {
/* 2736 */             v[0] = Constants.characterValueOf(c);
/* 2737 */             v[2] = Constants.integerValueOf(1);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 2742 */       int size = vecRemovelist.size();
/*      */       
/* 2744 */       for (int i = 0; i < size; i++) {
/* 2745 */         Object[] v = vecRemovelist.get(i);
/* 2746 */         vec.remove(v);
/*      */       } 
/*      */       
/* 2749 */       vecRemovelist.clear();
/*      */     } 
/*      */     
/* 2752 */     int size = vec.size();
/*      */     
/* 2754 */     for (int i = 0; i < size; i++) {
/* 2755 */       Object[] v = vec.get(i);
/* 2756 */       char c = ((Character)v[0]).charValue();
/* 2757 */       int n = ((Integer)v[2]).intValue();
/*      */       
/* 2759 */       boolean bk = (getSuccessor(c, n) != c);
/* 2760 */       boolean atEnd = ((c == 's' || c == 'm' || (c == 'h' && toTime)) && bk);
/* 2761 */       boolean finishesAtDate = (bk && c == 'd' && !toTime);
/* 2762 */       boolean containsEnd = (((StringBuffer)v[1]).toString().indexOf('W') != -1);
/*      */ 
/*      */       
/* 2765 */       if ((!atEnd && !finishesAtDate) || containsEnd) {
/* 2766 */         vecRemovelist.add(v);
/*      */       }
/*      */     } 
/*      */     
/* 2770 */     size = vecRemovelist.size();
/*      */     
/* 2772 */     for (int i = 0; i < size; i++) {
/* 2773 */       vec.remove(vecRemovelist.get(i));
/*      */     }
/*      */     
/* 2776 */     vecRemovelist.clear();
/* 2777 */     Object[] v = vec.get(0);
/*      */     
/* 2779 */     StringBuffer format = (StringBuffer)v[1];
/* 2780 */     format.setLength(format.length() - 1);
/*      */     
/* 2782 */     return format.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 2808 */     if (!isSelectQuery()) {
/* 2809 */       return null;
/*      */     }
/*      */     
/* 2812 */     PreparedStatement mdStmt = null;
/* 2813 */     ResultSet mdRs = null;
/*      */     
/* 2815 */     if (this.pstmtResultMetaData == null) {
/*      */       try {
/* 2817 */         mdStmt = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog, this.parseInfo);
/*      */ 
/*      */         
/* 2820 */         mdStmt.setMaxRows(0);
/*      */         
/* 2822 */         int paramCount = this.parameterValues.length;
/*      */         
/* 2824 */         for (int i = 1; i <= paramCount; i++) {
/* 2825 */           mdStmt.setString(i, "");
/*      */         }
/*      */         
/* 2828 */         boolean hadResults = mdStmt.execute();
/*      */         
/* 2830 */         if (hadResults) {
/* 2831 */           mdRs = mdStmt.getResultSet();
/*      */           
/* 2833 */           this.pstmtResultMetaData = mdRs.getMetaData();
/*      */         } else {
/* 2835 */           this.pstmtResultMetaData = new ResultSetMetaData(new Field[0], this.connection.getUseOldAliasMetadataBehavior(), getExceptionInterceptor());
/*      */         }
/*      */       
/*      */       } finally {
/*      */         
/* 2840 */         SQLException sqlExRethrow = null;
/*      */         
/* 2842 */         if (mdRs != null) {
/*      */           try {
/* 2844 */             mdRs.close();
/* 2845 */           } catch (SQLException sqlEx) {
/* 2846 */             sqlExRethrow = sqlEx;
/*      */           } 
/*      */           
/* 2849 */           mdRs = null;
/*      */         } 
/*      */         
/* 2852 */         if (mdStmt != null) {
/*      */           try {
/* 2854 */             mdStmt.close();
/* 2855 */           } catch (SQLException sqlEx) {
/* 2856 */             sqlExRethrow = sqlEx;
/*      */           } 
/*      */           
/* 2859 */           mdStmt = null;
/*      */         } 
/*      */         
/* 2862 */         if (sqlExRethrow != null) {
/* 2863 */           throw sqlExRethrow;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 2868 */     return this.pstmtResultMetaData;
/*      */   }
/*      */ 
/*      */   
/* 2872 */   protected boolean isSelectQuery() { return StringUtils.startsWithIgnoreCaseAndWs(StringUtils.stripComments(this.originalSql, "'\"", "'\"", true, false, true, true), "SELECT"); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 2883 */     if (this.parameterMetaData == null) {
/* 2884 */       if (this.connection.getGenerateSimpleParameterMetadata()) {
/* 2885 */         this.parameterMetaData = new MysqlParameterMetadata(this.parameterCount);
/*      */       } else {
/* 2887 */         this.parameterMetaData = new MysqlParameterMetadata(null, this.parameterCount, getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 2892 */     return this.parameterMetaData;
/*      */   }
/*      */ 
/*      */   
/* 2896 */   ParseInfo getParseInfo() { return this.parseInfo; }
/*      */ 
/*      */ 
/*      */   
/* 2900 */   private final char getSuccessor(char c, int n) { return (c == 'y' && n == 2) ? 'X' : ((c == 'y' && n < 4) ? 'y' : ((c == 'y') ? 'M' : ((c == 'M' && n == 2) ? 'Y' : ((c == 'M' && n < 3) ? 'M' : ((c == 'M') ? 'd' : ((c == 'd' && n < 2) ? 'd' : ((c == 'd') ? 'H' : ((c == 'H' && n < 2) ? 'H' : ((c == 'H') ? 'm' : ((c == 'm' && n < 2) ? 'm' : ((c == 'm') ? 's' : ((c == 's' && n < 2) ? 's' : 'W')))))))))))); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void hexEscapeBlock(byte[] buf, Buffer packet, int size) throws SQLException {
/* 2926 */     for (int i = 0; i < size; i++) {
/* 2927 */       byte b = buf[i];
/* 2928 */       int lowBits = (b & 0xFF) / 16;
/* 2929 */       int highBits = (b & 0xFF) % 16;
/*      */       
/* 2931 */       packet.writeByte(HEX_DIGITS[lowBits]);
/* 2932 */       packet.writeByte(HEX_DIGITS[highBits]);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void initializeFromParseInfo() throws SQLException {
/* 2937 */     this.staticSqlStrings = this.parseInfo.staticSql;
/* 2938 */     this.hasLimitClause = this.parseInfo.foundLimitClause;
/* 2939 */     this.isLoadDataQuery = this.parseInfo.foundLoadData;
/* 2940 */     this.firstCharOfStmt = this.parseInfo.firstStmtChar;
/*      */     
/* 2942 */     this.parameterCount = this.staticSqlStrings.length - 1;
/*      */     
/* 2944 */     this.parameterValues = new byte[this.parameterCount][];
/* 2945 */     this.parameterStreams = new InputStream[this.parameterCount];
/* 2946 */     this.isStream = new boolean[this.parameterCount];
/* 2947 */     this.streamLengths = new int[this.parameterCount];
/* 2948 */     this.isNull = new boolean[this.parameterCount];
/* 2949 */     this.parameterTypes = new int[this.parameterCount];
/*      */     
/* 2951 */     clearParameters();
/*      */     
/* 2953 */     for (int j = 0; j < this.parameterCount; j++) {
/* 2954 */       this.isStream[j] = false;
/*      */     }
/*      */     
/* 2957 */     this.statementAfterCommentsPos = this.parseInfo.statementStartPos;
/*      */   }
/*      */ 
/*      */   
/* 2961 */   boolean isNull(int paramIndex) { return this.isNull[paramIndex]; }
/*      */ 
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b) throws SQLException {
/*      */     try {
/* 2966 */       return i.read(b);
/* 2967 */     } catch (Throwable ex) {
/* 2968 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 2970 */       sqlEx.initCause(ex);
/*      */       
/* 2972 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final int readblock(InputStream i, byte[] b, int length) throws SQLException {
/*      */     try {
/* 2979 */       int lengthToRead = length;
/*      */       
/* 2981 */       if (lengthToRead > b.length) {
/* 2982 */         lengthToRead = b.length;
/*      */       }
/*      */       
/* 2985 */       return i.read(b, 0, lengthToRead);
/* 2986 */     } catch (Throwable ex) {
/* 2987 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.56") + ex.getClass().getName(), "S1000", getExceptionInterceptor());
/*      */       
/* 2989 */       sqlEx.initCause(ex);
/*      */       
/* 2991 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults) throws SQLException {
/* 3006 */     if (this.useUsageAdvisor && 
/* 3007 */       this.numberOfExecutions <= 1) {
/* 3008 */       String message = Messages.getString("PreparedStatement.43");
/*      */       
/* 3010 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3019 */     super.realClose(calledExplicitly, closeOpenResults);
/*      */     
/* 3021 */     this.dbmd = null;
/* 3022 */     this.originalSql = null;
/* 3023 */     this.staticSqlStrings = (byte[][])null;
/* 3024 */     this.parameterValues = (byte[][])null;
/* 3025 */     this.parameterStreams = null;
/* 3026 */     this.isStream = null;
/* 3027 */     this.streamLengths = null;
/* 3028 */     this.isNull = null;
/* 3029 */     this.streamConvertBuf = null;
/* 3030 */     this.parameterTypes = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3047 */   public void setArray(int i, Array x) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 3074 */     if (x == null) {
/* 3075 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 3077 */       setBinaryStream(parameterIndex, x, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x) throws SQLException {
/* 3095 */     if (x == null) {
/* 3096 */       setNull(parameterIndex, 3);
/*      */     } else {
/* 3098 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString(x)));
/*      */ 
/*      */       
/* 3101 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 3;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 3127 */     if (x == null) {
/* 3128 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 3130 */       int parameterIndexOffset = getParameterIndexOffset();
/*      */       
/* 3132 */       if (parameterIndex < 1 || parameterIndex > this.staticSqlStrings.length)
/*      */       {
/* 3134 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.2") + parameterIndex + Messages.getString("PreparedStatement.3") + this.staticSqlStrings.length + Messages.getString("PreparedStatement.4"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3139 */       if (parameterIndexOffset == -1 && parameterIndex == 1) {
/* 3140 */         throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3145 */       this.parameterStreams[parameterIndex - 1 + parameterIndexOffset] = x;
/* 3146 */       this.isStream[parameterIndex - 1 + parameterIndexOffset] = true;
/* 3147 */       this.streamLengths[parameterIndex - 1 + parameterIndexOffset] = length;
/* 3148 */       this.isNull[parameterIndex - 1 + parameterIndexOffset] = false;
/* 3149 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2004;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 3155 */   public void setBlob(int parameterIndex, InputStream inputStream, long length) throws SQLException { setBinaryStream(parameterIndex, inputStream, (int)length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int i, Blob x) throws SQLException {
/* 3170 */     if (x == null) {
/* 3171 */       setNull(i, 2004);
/*      */     } else {
/* 3173 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */       
/* 3175 */       bytesOut.write(39);
/* 3176 */       escapeblockFast(x.getBytes(1L, (int)x.length()), bytesOut, (int)x.length());
/*      */       
/* 3178 */       bytesOut.write(39);
/*      */       
/* 3180 */       setInternal(i, bytesOut.toByteArray());
/*      */       
/* 3182 */       this.parameterTypes[i - 1 + getParameterIndexOffset()] = 2004;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int parameterIndex, boolean x) throws SQLException {
/* 3199 */     if (this.useTrueBoolean) {
/* 3200 */       setInternal(parameterIndex, x ? "1" : "0");
/*      */     } else {
/* 3202 */       setInternal(parameterIndex, x ? "'t'" : "'f'");
/*      */       
/* 3204 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 16;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int parameterIndex, byte x) throws SQLException {
/* 3221 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3223 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int parameterIndex, byte[] x) throws SQLException {
/* 3240 */     setBytes(parameterIndex, x, true, true);
/*      */     
/* 3242 */     if (x != null) {
/* 3243 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -2;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars) throws SQLException {
/* 3250 */     if (x == null) {
/* 3251 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 3253 */       String connectionEncoding = this.connection.getEncoding();
/*      */       
/* 3255 */       if (this.connection.isNoBackslashEscapesSet() || (escapeForMBChars && this.connection.getUseUnicode() && connectionEncoding != null && CharsetMapping.isMultibyteCharset(connectionEncoding))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3263 */         ByteArrayOutputStream bOut = new ByteArrayOutputStream(x.length * 2 + 3);
/*      */         
/* 3265 */         bOut.write(120);
/* 3266 */         bOut.write(39);
/*      */         
/* 3268 */         for (int i = 0; i < x.length; i++) {
/* 3269 */           int lowBits = (x[i] & 0xFF) / 16;
/* 3270 */           int highBits = (x[i] & 0xFF) % 16;
/*      */           
/* 3272 */           bOut.write(HEX_DIGITS[lowBits]);
/* 3273 */           bOut.write(HEX_DIGITS[highBits]);
/*      */         } 
/*      */         
/* 3276 */         bOut.write(39);
/*      */         
/* 3278 */         setInternal(parameterIndex, bOut.toByteArray());
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 3284 */       int numBytes = x.length;
/*      */       
/* 3286 */       int pad = 2;
/*      */       
/* 3288 */       boolean needsIntroducer = (checkForIntroducer && this.connection.versionMeetsMinimum(4, 1, 0));
/*      */ 
/*      */       
/* 3291 */       if (needsIntroducer) {
/* 3292 */         pad += 7;
/*      */       }
/*      */       
/* 3295 */       ByteArrayOutputStream bOut = new ByteArrayOutputStream(numBytes + pad);
/*      */ 
/*      */       
/* 3298 */       if (needsIntroducer) {
/* 3299 */         bOut.write(95);
/* 3300 */         bOut.write(98);
/* 3301 */         bOut.write(105);
/* 3302 */         bOut.write(110);
/* 3303 */         bOut.write(97);
/* 3304 */         bOut.write(114);
/* 3305 */         bOut.write(121);
/*      */       } 
/* 3307 */       bOut.write(39);
/*      */       
/* 3309 */       for (int i = 0; i < numBytes; i++) {
/* 3310 */         byte b = x[i];
/*      */         
/* 3312 */         switch (b) {
/*      */           case 0:
/* 3314 */             bOut.write(92);
/* 3315 */             bOut.write(48);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 10:
/* 3320 */             bOut.write(92);
/* 3321 */             bOut.write(110);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 13:
/* 3326 */             bOut.write(92);
/* 3327 */             bOut.write(114);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 92:
/* 3332 */             bOut.write(92);
/* 3333 */             bOut.write(92);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 39:
/* 3338 */             bOut.write(92);
/* 3339 */             bOut.write(39);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 34:
/* 3344 */             bOut.write(92);
/* 3345 */             bOut.write(34);
/*      */             break;
/*      */ 
/*      */           
/*      */           case 26:
/* 3350 */             bOut.write(92);
/* 3351 */             bOut.write(90);
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 3356 */             bOut.write(b);
/*      */             break;
/*      */         } 
/*      */       } 
/* 3360 */       bOut.write(39);
/*      */       
/* 3362 */       setInternal(parameterIndex, bOut.toByteArray());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes) throws SQLException {
/* 3380 */     byte[] parameterWithQuotes = new byte[parameterAsBytes.length + 2];
/* 3381 */     parameterWithQuotes[0] = 39;
/* 3382 */     System.arraycopy(parameterAsBytes, 0, parameterWithQuotes, 1, parameterAsBytes.length);
/*      */     
/* 3384 */     parameterWithQuotes[parameterAsBytes.length + 1] = 39;
/*      */     
/* 3386 */     setInternal(parameterIndex, parameterWithQuotes);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 3391 */   protected void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes) throws SQLException { setInternal(parameterIndex, parameterAsBytes); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length) throws SQLException {
/*      */     try {
/* 3419 */       if (reader == null) {
/* 3420 */         setNull(parameterIndex, -1);
/*      */       } else {
/* 3422 */         char[] c = null;
/* 3423 */         int len = 0;
/*      */         
/* 3425 */         boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */ 
/*      */         
/* 3428 */         String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */         
/* 3430 */         if (useLength && length != -1) {
/* 3431 */           c = new char[length];
/*      */           
/* 3433 */           int numCharsRead = readFully(reader, c, length);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3438 */           if (forcedEncoding == null) {
/* 3439 */             setString(parameterIndex, new String(c, 0, numCharsRead));
/*      */           } else {
/*      */             try {
/* 3442 */               setBytes(parameterIndex, (new String(c, 0, numCharsRead)).getBytes(forcedEncoding));
/*      */             
/*      */             }
/* 3445 */             catch (UnsupportedEncodingException uee) {
/* 3446 */               throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         } else {
/*      */           
/* 3451 */           c = new char[4096];
/*      */           
/* 3453 */           StringBuffer buf = new StringBuffer();
/*      */           
/* 3455 */           while ((len = reader.read(c)) != -1) {
/* 3456 */             buf.append(c, 0, len);
/*      */           }
/*      */           
/* 3459 */           if (forcedEncoding == null) {
/* 3460 */             setString(parameterIndex, buf.toString());
/*      */           } else {
/*      */             try {
/* 3463 */               setBytes(parameterIndex, buf.toString().getBytes(forcedEncoding));
/*      */             }
/* 3465 */             catch (UnsupportedEncodingException uee) {
/* 3466 */               throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 3472 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2005;
/*      */       } 
/* 3474 */     } catch (IOException ioEx) {
/* 3475 */       throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int i, Clob x) throws SQLException {
/* 3492 */     if (x == null) {
/* 3493 */       setNull(i, 2005);
/*      */     } else {
/*      */       
/* 3496 */       String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */       
/* 3498 */       if (forcedEncoding == null) {
/* 3499 */         setString(i, x.getSubString(1L, (int)x.length()));
/*      */       } else {
/*      */         try {
/* 3502 */           setBytes(i, x.getSubString(1L, (int)x.length()).getBytes(forcedEncoding));
/*      */         }
/* 3504 */         catch (UnsupportedEncodingException uee) {
/* 3505 */           throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3510 */       this.parameterTypes[i - 1 + getParameterIndexOffset()] = 2005;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3528 */   public void setDate(int parameterIndex, Date x) throws SQLException { setDate(parameterIndex, x, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int parameterIndex, Date x, Calendar cal) throws SQLException {
/* 3547 */     if (x == null) {
/* 3548 */       setNull(parameterIndex, 91);
/*      */     } else {
/* 3550 */       checkClosed();
/*      */       
/* 3552 */       if (!this.useLegacyDatetimeCode) {
/* 3553 */         newSetDateInternal(parameterIndex, x, cal);
/*      */       }
/*      */       else {
/*      */         
/* 3557 */         SimpleDateFormat dateFormatter = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */         
/* 3559 */         setInternal(parameterIndex, dateFormatter.format(x));
/*      */         
/* 3561 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 91;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int parameterIndex, double x) throws SQLException {
/* 3580 */     if (!this.connection.getAllowNanAndInf() && (x == Double.POSITIVE_INFINITY || x == Double.NEGATIVE_INFINITY || Double.isNaN(x)))
/*      */     {
/*      */       
/* 3583 */       throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3589 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */ 
/*      */     
/* 3592 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 8;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int parameterIndex, float x) throws SQLException {
/* 3608 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */ 
/*      */     
/* 3611 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 6;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int parameterIndex, int x) throws SQLException {
/* 3627 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3629 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 4;
/*      */   }
/*      */ 
/*      */   
/*      */   protected final void setInternal(int paramIndex, byte[] val) throws SQLException {
/* 3634 */     if (this.isClosed) {
/* 3635 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.48"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 3639 */     int parameterIndexOffset = getParameterIndexOffset();
/*      */     
/* 3641 */     checkBounds(paramIndex, parameterIndexOffset);
/*      */     
/* 3643 */     this.isStream[paramIndex - 1 + parameterIndexOffset] = false;
/* 3644 */     this.isNull[paramIndex - 1 + parameterIndexOffset] = false;
/* 3645 */     this.parameterStreams[paramIndex - 1 + parameterIndexOffset] = null;
/* 3646 */     this.parameterValues[paramIndex - 1 + parameterIndexOffset] = val;
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkBounds(int paramIndex, int parameterIndexOffset) throws SQLException {
/* 3651 */     if (paramIndex < 1) {
/* 3652 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */     
/* 3656 */     if (paramIndex > this.parameterCount) {
/* 3657 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + this.parameterValues.length + Messages.getString("PreparedStatement.53"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3662 */     if (parameterIndexOffset == -1 && paramIndex == 1) {
/* 3663 */       throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setInternal(int paramIndex, String val) throws SQLException {
/* 3670 */     checkClosed();
/*      */     
/* 3672 */     byte[] parameterAsBytes = null;
/*      */     
/* 3674 */     if (this.charConverter != null) {
/* 3675 */       parameterAsBytes = this.charConverter.toBytes(val);
/*      */     } else {
/* 3677 */       parameterAsBytes = StringUtils.getBytes(val, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3683 */     setInternal(paramIndex, parameterAsBytes);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int parameterIndex, long x) throws SQLException {
/* 3699 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 3701 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int parameterIndex, int sqlType) throws SQLException {
/* 3721 */     setInternal(parameterIndex, "null");
/* 3722 */     this.isNull[parameterIndex - 1 + getParameterIndexOffset()] = true;
/*      */     
/* 3724 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int parameterIndex, int sqlType, String arg) throws SQLException {
/* 3746 */     setNull(parameterIndex, sqlType);
/*      */     
/* 3748 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private void setNumericObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/*      */     Number parameterAsNum;
/* 3754 */     if (parameterObj instanceof Boolean) {
/* 3755 */       parameterAsNum = ((Boolean)parameterObj).booleanValue() ? Constants.integerValueOf(1) : Constants.integerValueOf(0);
/*      */     
/*      */     }
/* 3758 */     else if (parameterObj instanceof String) {
/* 3759 */       boolean parameterAsBoolean; Number parameterAsNum; Number parameterAsNum; Number parameterAsNum; Number parameterAsNum; Number parameterAsNum; switch (targetSqlType) {
/*      */         case -7:
/* 3761 */           if ("1".equals(parameterObj) || "0".equals(parameterObj)) {
/*      */             
/* 3763 */             Number parameterAsNum = Integer.valueOf((String)parameterObj); break;
/*      */           } 
/* 3765 */           parameterAsBoolean = "true".equalsIgnoreCase((String)parameterObj);
/*      */ 
/*      */           
/* 3768 */           parameterAsNum = parameterAsBoolean ? Constants.integerValueOf(1) : Constants.integerValueOf(0);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -6:
/*      */         case 4:
/*      */         case 5:
/* 3777 */           parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case -5:
/* 3783 */           parameterAsNum = Long.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 7:
/* 3789 */           parameterAsNum = Float.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */ 
/*      */         
/*      */         case 6:
/*      */         case 8:
/* 3796 */           parameterAsNum = Double.valueOf((String)parameterObj);
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         default:
/* 3804 */           parameterAsNum = new BigDecimal((String)parameterObj);
/*      */           break;
/*      */       } 
/*      */     } else {
/* 3808 */       parameterAsNum = (Number)parameterObj;
/*      */     } 
/*      */     
/* 3811 */     switch (targetSqlType) {
/*      */       case -7:
/*      */       case -6:
/*      */       case 4:
/*      */       case 5:
/* 3816 */         setInt(parameterIndex, parameterAsNum.intValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case -5:
/* 3821 */         setLong(parameterIndex, parameterAsNum.longValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 7:
/* 3826 */         setFloat(parameterIndex, parameterAsNum.floatValue());
/*      */         break;
/*      */ 
/*      */       
/*      */       case 6:
/*      */       case 8:
/* 3832 */         setDouble(parameterIndex, parameterAsNum.doubleValue());
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 3839 */         if (parameterAsNum instanceof BigDecimal) {
/* 3840 */           BigDecimal scaledBigDecimal = null;
/*      */           
/*      */           try {
/* 3843 */             scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale);
/*      */           }
/* 3845 */           catch (ArithmeticException ex) {
/*      */             try {
/* 3847 */               scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale, 4);
/*      */             
/*      */             }
/* 3850 */             catch (ArithmeticException arEx) {
/* 3851 */               throw SQLError.createSQLException("Can't set scale of '" + scale + "' for DECIMAL argument '" + parameterAsNum + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3860 */           setBigDecimal(parameterIndex, scaledBigDecimal); break;
/* 3861 */         }  if (parameterAsNum instanceof BigInteger) {
/* 3862 */           setBigDecimal(parameterIndex, new BigDecimal((BigInteger)parameterAsNum, scale));
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/* 3868 */         setBigDecimal(parameterIndex, new BigDecimal(parameterAsNum.doubleValue()));
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj) throws SQLException {
/* 3890 */     if (parameterObj == null) {
/* 3891 */       setNull(parameterIndex, 1111);
/*      */     }
/* 3893 */     else if (parameterObj instanceof Byte) {
/* 3894 */       setInt(parameterIndex, ((Byte)parameterObj).intValue());
/* 3895 */     } else if (parameterObj instanceof String) {
/* 3896 */       setString(parameterIndex, (String)parameterObj);
/* 3897 */     } else if (parameterObj instanceof BigDecimal) {
/* 3898 */       setBigDecimal(parameterIndex, (BigDecimal)parameterObj);
/* 3899 */     } else if (parameterObj instanceof Short) {
/* 3900 */       setShort(parameterIndex, ((Short)parameterObj).shortValue());
/* 3901 */     } else if (parameterObj instanceof Integer) {
/* 3902 */       setInt(parameterIndex, ((Integer)parameterObj).intValue());
/* 3903 */     } else if (parameterObj instanceof Long) {
/* 3904 */       setLong(parameterIndex, ((Long)parameterObj).longValue());
/* 3905 */     } else if (parameterObj instanceof Float) {
/* 3906 */       setFloat(parameterIndex, ((Float)parameterObj).floatValue());
/* 3907 */     } else if (parameterObj instanceof Double) {
/* 3908 */       setDouble(parameterIndex, ((Double)parameterObj).doubleValue());
/* 3909 */     } else if (parameterObj instanceof byte[]) {
/* 3910 */       setBytes(parameterIndex, (byte[])parameterObj);
/* 3911 */     } else if (parameterObj instanceof Date) {
/* 3912 */       setDate(parameterIndex, (Date)parameterObj);
/* 3913 */     } else if (parameterObj instanceof Time) {
/* 3914 */       setTime(parameterIndex, (Time)parameterObj);
/* 3915 */     } else if (parameterObj instanceof Timestamp) {
/* 3916 */       setTimestamp(parameterIndex, (Timestamp)parameterObj);
/* 3917 */     } else if (parameterObj instanceof Boolean) {
/* 3918 */       setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */     }
/* 3920 */     else if (parameterObj instanceof InputStream) {
/* 3921 */       setBinaryStream(parameterIndex, (InputStream)parameterObj, -1);
/* 3922 */     } else if (parameterObj instanceof Blob) {
/* 3923 */       setBlob(parameterIndex, (Blob)parameterObj);
/* 3924 */     } else if (parameterObj instanceof Clob) {
/* 3925 */       setClob(parameterIndex, (Clob)parameterObj);
/* 3926 */     } else if (this.connection.getTreatUtilDateAsTimestamp() && parameterObj instanceof Date) {
/*      */       
/* 3928 */       setTimestamp(parameterIndex, new Timestamp(((Date)parameterObj).getTime()));
/*      */     }
/* 3930 */     else if (parameterObj instanceof BigInteger) {
/* 3931 */       setString(parameterIndex, parameterObj.toString());
/*      */     } else {
/* 3933 */       setSerializableObject(parameterIndex, parameterObj);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType) throws SQLException {
/* 3954 */     if (!(parameterObj instanceof BigDecimal)) {
/* 3955 */       setObject(parameterIndex, parameterObj, targetSqlType, 0);
/*      */     } else {
/* 3957 */       setObject(parameterIndex, parameterObj, targetSqlType, ((BigDecimal)parameterObj).scale());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale) throws SQLException {
/* 3993 */     if (parameterObj == null) {
/* 3994 */       setNull(parameterIndex, 1111);
/*      */     } else {
/*      */       try {
/* 3997 */         Date parameterAsDate; switch (targetSqlType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 16:
/* 4017 */             if (parameterObj instanceof Boolean) {
/* 4018 */               setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */             
/*      */             }
/* 4021 */             else if (parameterObj instanceof String) {
/* 4022 */               setBoolean(parameterIndex, ("true".equalsIgnoreCase((String)parameterObj) || !"0".equalsIgnoreCase((String)parameterObj)));
/*      */ 
/*      */             
/*      */             }
/* 4026 */             else if (parameterObj instanceof Number) {
/* 4027 */               int intValue = ((Number)parameterObj).intValue();
/*      */               
/* 4029 */               setBoolean(parameterIndex, (intValue != 0));
/*      */             }
/*      */             else {
/*      */               
/* 4033 */               throw SQLError.createSQLException("No conversion from " + parameterObj.getClass().getName() + " to Types.BOOLEAN possible.", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case -7:
/*      */           case -6:
/*      */           case -5:
/*      */           case 2:
/*      */           case 3:
/*      */           case 4:
/*      */           case 5:
/*      */           case 6:
/*      */           case 7:
/*      */           case 8:
/* 4049 */             setNumericObject(parameterIndex, parameterObj, targetSqlType, scale);
/*      */             return;
/*      */ 
/*      */           
/*      */           case -1:
/*      */           case 1:
/*      */           case 12:
/* 4056 */             if (parameterObj instanceof BigDecimal) {
/* 4057 */               setString(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString((BigDecimal)parameterObj)));
/*      */             
/*      */             }
/*      */             else {
/*      */ 
/*      */               
/* 4063 */               setString(parameterIndex, parameterObj.toString());
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case 2005:
/* 4070 */             if (parameterObj instanceof Clob) {
/* 4071 */               setClob(parameterIndex, (Clob)parameterObj);
/*      */             } else {
/* 4073 */               setString(parameterIndex, parameterObj.toString());
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case -4:
/*      */           case -3:
/*      */           case -2:
/*      */           case 2004:
/* 4083 */             if (parameterObj instanceof byte[]) {
/* 4084 */               setBytes(parameterIndex, (byte[])parameterObj);
/* 4085 */             } else if (parameterObj instanceof Blob) {
/* 4086 */               setBlob(parameterIndex, (Blob)parameterObj);
/*      */             } else {
/* 4088 */               setBytes(parameterIndex, StringUtils.getBytes(parameterObj.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor()));
/*      */             } 
/*      */             return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 91:
/*      */           case 93:
/* 4102 */             if (parameterObj instanceof String) {
/* 4103 */               ParsePosition pp = new ParsePosition(0);
/* 4104 */               DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, false), Locale.US);
/*      */               
/* 4106 */               parameterAsDate = sdf.parse((String)parameterObj, pp);
/*      */             } else {
/* 4108 */               parameterAsDate = (Date)parameterObj;
/*      */             } 
/*      */             
/* 4111 */             switch (targetSqlType) {
/*      */               
/*      */               case 91:
/* 4114 */                 if (parameterAsDate instanceof Date) {
/* 4115 */                   setDate(parameterIndex, (Date)parameterAsDate);
/*      */                   break;
/*      */                 } 
/* 4118 */                 setDate(parameterIndex, new Date(parameterAsDate.getTime()));
/*      */                 break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 93:
/* 4126 */                 if (parameterAsDate instanceof Timestamp) {
/* 4127 */                   setTimestamp(parameterIndex, (Timestamp)parameterAsDate);
/*      */                   break;
/*      */                 } 
/* 4130 */                 setTimestamp(parameterIndex, new Timestamp(parameterAsDate.getTime()));
/*      */                 break;
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             return;
/*      */ 
/*      */ 
/*      */           
/*      */           case 92:
/* 4142 */             if (parameterObj instanceof String) {
/* 4143 */               DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, true), Locale.US);
/*      */               
/* 4145 */               setTime(parameterIndex, new Time(sdf.parse((String)parameterObj).getTime()));
/*      */             }
/* 4147 */             else if (parameterObj instanceof Timestamp) {
/* 4148 */               Timestamp xT = (Timestamp)parameterObj;
/* 4149 */               setTime(parameterIndex, new Time(xT.getTime()));
/*      */             } else {
/* 4151 */               setTime(parameterIndex, (Time)parameterObj);
/*      */             } 
/*      */             return;
/*      */ 
/*      */           
/*      */           case 1111:
/* 4157 */             setSerializableObject(parameterIndex, parameterObj);
/*      */             return;
/*      */         } 
/*      */ 
/*      */         
/* 4162 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.16"), "S1000", getExceptionInterceptor());
/*      */ 
/*      */       
/*      */       }
/* 4166 */       catch (Exception ex) {
/* 4167 */         if (ex instanceof SQLException) {
/* 4168 */           throw (SQLException)ex;
/*      */         }
/*      */         
/* 4171 */         SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.17") + parameterObj.getClass().toString() + Messages.getString("PreparedStatement.18") + ex.getClass().getName() + Messages.getString("PreparedStatement.19") + ex.getMessage(), "S1000", getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4179 */         sqlEx.initCause(ex);
/*      */         
/* 4181 */         throw sqlEx;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int setOneBatchedParameterSet(PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet) throws SQLException {
/* 4189 */     BatchParams paramArg = (BatchParams)paramSet;
/*      */     
/* 4191 */     boolean[] isNullBatch = paramArg.isNull;
/* 4192 */     boolean[] isStreamBatch = paramArg.isStream;
/*      */     
/* 4194 */     for (int j = 0; j < isNullBatch.length; j++) {
/* 4195 */       if (isNullBatch[j]) {
/* 4196 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 4198 */       else if (isStreamBatch[j]) {
/* 4199 */         batchedStatement.setBinaryStream(batchedParamIndex++, paramArg.parameterStreams[j], paramArg.streamLengths[j]);
/*      */       }
/*      */       else {
/*      */         
/* 4203 */         ((PreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, paramArg.parameterStrings[j]);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4210 */     return batchedParamIndex;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4227 */   public void setRef(int i, Ref x) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4237 */   void setResultSetConcurrency(int concurrencyFlag) { this.resultSetConcurrency = concurrencyFlag; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4247 */   void setResultSetType(int typeFlag) { this.resultSetType = typeFlag; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4256 */   protected void setRetrieveGeneratedKeys(boolean retrieveGeneratedKeys) { this.retrieveGeneratedKeys = retrieveGeneratedKeys; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void setSerializableObject(int parameterIndex, Object parameterObj) throws SQLException {
/*      */     try {
/* 4276 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 4277 */       ObjectOutputStream objectOut = new ObjectOutputStream(bytesOut);
/* 4278 */       objectOut.writeObject(parameterObj);
/* 4279 */       objectOut.flush();
/* 4280 */       objectOut.close();
/* 4281 */       bytesOut.flush();
/* 4282 */       bytesOut.close();
/*      */       
/* 4284 */       byte[] buf = bytesOut.toByteArray();
/* 4285 */       ByteArrayInputStream bytesIn = new ByteArrayInputStream(buf);
/* 4286 */       setBinaryStream(parameterIndex, bytesIn, buf.length);
/* 4287 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -2;
/* 4288 */     } catch (Exception ex) {
/* 4289 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("PreparedStatement.54") + ex.getClass().getName(), "S1009", getExceptionInterceptor());
/*      */ 
/*      */       
/* 4292 */       sqlEx.initCause(ex);
/*      */       
/* 4294 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int parameterIndex, short x) throws SQLException {
/* 4311 */     setInternal(parameterIndex, String.valueOf(x));
/*      */     
/* 4313 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 5;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int parameterIndex, String x) throws SQLException {
/* 4331 */     if (x == null) {
/* 4332 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 4334 */       checkClosed();
/*      */       
/* 4336 */       int stringLength = x.length();
/*      */       
/* 4338 */       if (this.connection.isNoBackslashEscapesSet()) {
/*      */ 
/*      */         
/* 4341 */         boolean needsHexEscape = isEscapeNeededForString(x, stringLength);
/*      */ 
/*      */         
/* 4344 */         if (!needsHexEscape) {
/* 4345 */           byte[] parameterAsBytes = null;
/*      */           
/* 4347 */           StringBuffer quotedString = new StringBuffer(x.length() + 2);
/* 4348 */           quotedString.append('\'');
/* 4349 */           quotedString.append(x);
/* 4350 */           quotedString.append('\'');
/*      */           
/* 4352 */           if (!this.isLoadDataQuery) {
/* 4353 */             parameterAsBytes = StringUtils.getBytes(quotedString.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 4359 */             parameterAsBytes = quotedString.toString().getBytes();
/*      */           } 
/*      */           
/* 4362 */           setInternal(parameterIndex, parameterAsBytes);
/*      */         } else {
/* 4364 */           byte[] parameterAsBytes = null;
/*      */           
/* 4366 */           if (!this.isLoadDataQuery) {
/* 4367 */             parameterAsBytes = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 4373 */             parameterAsBytes = x.getBytes();
/*      */           } 
/*      */           
/* 4376 */           setBytes(parameterIndex, parameterAsBytes);
/*      */         } 
/*      */         
/*      */         return;
/*      */       } 
/*      */       
/* 4382 */       String parameterAsString = x;
/* 4383 */       boolean needsQuoted = true;
/*      */       
/* 4385 */       if (this.isLoadDataQuery || isEscapeNeededForString(x, stringLength)) {
/* 4386 */         needsQuoted = false;
/*      */         
/* 4388 */         StringBuffer buf = new StringBuffer((int)(x.length() * 1.1D));
/*      */         
/* 4390 */         buf.append('\'');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4399 */         for (int i = 0; i < stringLength; i++) {
/* 4400 */           char c = x.charAt(i);
/*      */           
/* 4402 */           switch (c) {
/*      */             case '\000':
/* 4404 */               buf.append('\\');
/* 4405 */               buf.append('0');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\n':
/* 4410 */               buf.append('\\');
/* 4411 */               buf.append('n');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\r':
/* 4416 */               buf.append('\\');
/* 4417 */               buf.append('r');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\\':
/* 4422 */               buf.append('\\');
/* 4423 */               buf.append('\\');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\'':
/* 4428 */               buf.append('\\');
/* 4429 */               buf.append('\'');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '"':
/* 4434 */               if (this.usingAnsiMode) {
/* 4435 */                 buf.append('\\');
/*      */               }
/*      */               
/* 4438 */               buf.append('"');
/*      */               break;
/*      */ 
/*      */             
/*      */             case '\032':
/* 4443 */               buf.append('\\');
/* 4444 */               buf.append('Z');
/*      */               break;
/*      */ 
/*      */ 
/*      */             
/*      */             case '¥':
/*      */             case '₩':
/* 4451 */               if (this.charsetEncoder != null) {
/* 4452 */                 CharBuffer cbuf = CharBuffer.allocate(1);
/* 4453 */                 ByteBuffer bbuf = ByteBuffer.allocate(1);
/* 4454 */                 cbuf.put(c);
/* 4455 */                 cbuf.position(0);
/* 4456 */                 this.charsetEncoder.encode(cbuf, bbuf, true);
/* 4457 */                 if (bbuf.get(0) == 92) {
/* 4458 */                   buf.append('\\');
/*      */                 }
/*      */               } 
/*      */ 
/*      */             
/*      */             default:
/* 4464 */               buf.append(c);
/*      */               break;
/*      */           } 
/*      */         } 
/* 4468 */         buf.append('\'');
/*      */         
/* 4470 */         parameterAsString = buf.toString();
/*      */       } 
/*      */       
/* 4473 */       byte[] parameterAsBytes = null;
/*      */       
/* 4475 */       if (!this.isLoadDataQuery) {
/* 4476 */         if (needsQuoted) {
/* 4477 */           parameterAsBytes = StringUtils.getBytesWrapped(parameterAsString, '\'', '\'', this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 4482 */           parameterAsBytes = StringUtils.getBytes(parameterAsString, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 4489 */         parameterAsBytes = parameterAsString.getBytes();
/*      */       } 
/*      */       
/* 4492 */       setInternal(parameterIndex, parameterAsBytes);
/*      */       
/* 4494 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 12;
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isEscapeNeededForString(String x, int stringLength) {
/* 4499 */     boolean needsHexEscape = false;
/*      */     
/* 4501 */     for (int i = 0; i < stringLength; i++) {
/* 4502 */       char c = x.charAt(i);
/*      */       
/* 4504 */       switch (c) {
/*      */         
/*      */         case '\000':
/* 4507 */           needsHexEscape = true;
/*      */           break;
/*      */         
/*      */         case '\n':
/* 4511 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\r':
/* 4516 */           needsHexEscape = true;
/*      */           break;
/*      */         
/*      */         case '\\':
/* 4520 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\'':
/* 4525 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '"':
/* 4530 */           needsHexEscape = true;
/*      */           break;
/*      */ 
/*      */         
/*      */         case '\032':
/* 4535 */           needsHexEscape = true;
/*      */           break;
/*      */       } 
/*      */       
/* 4539 */       if (needsHexEscape) {
/*      */         break;
/*      */       }
/*      */     } 
/* 4543 */     return needsHexEscape;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4562 */   public void setTime(int parameterIndex, Time x, Calendar cal) throws SQLException { setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4579 */   public void setTime(int parameterIndex, Time x) throws SQLException { setTimeInternal(parameterIndex, x, null, Util.getDefaultTimeZone(), false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4600 */     if (x == null) {
/* 4601 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 4603 */       checkClosed();
/*      */       
/* 4605 */       if (!this.useLegacyDatetimeCode) {
/* 4606 */         newSetTimeInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4608 */         Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */         
/* 4610 */         synchronized (sessionCalendar) {
/* 4611 */           x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4618 */         setInternal(parameterIndex, "'" + x.toString() + "'");
/*      */       } 
/*      */       
/* 4621 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 92;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4641 */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal) throws SQLException { setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4658 */   public void setTimestamp(int parameterIndex, Timestamp x) throws SQLException { setTimestampInternal(parameterIndex, x, null, Util.getDefaultTimeZone(), false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4678 */     if (x == null) {
/* 4679 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 4681 */       checkClosed();
/*      */       
/* 4683 */       if (!this.useLegacyDatetimeCode) {
/* 4684 */         newSetTimestampInternal(parameterIndex, x, targetCalendar);
/*      */       } else {
/* 4686 */         String timestampString = null;
/*      */         
/* 4688 */         Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */ 
/*      */         
/* 4692 */         synchronized (sessionCalendar) {
/* 4693 */           x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4700 */         if (this.connection.getUseSSPSCompatibleTimezoneShift()) {
/* 4701 */           doSSPSCompatibleTimezoneShift(parameterIndex, x, sessionCalendar);
/*      */         } else {
/* 4703 */           synchronized (this) {
/* 4704 */             if (this.tsdf == null) {
/* 4705 */               this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss", Locale.US);
/*      */             }
/*      */             
/* 4708 */             timestampString = this.tsdf.format(x);
/* 4709 */             StringBuffer buf = new StringBuffer();
/* 4710 */             buf.append(timestampString);
/* 4711 */             buf.append('.');
/* 4712 */             buf.append(formatNanos(x.getNanos()));
/* 4713 */             buf.append('\'');
/*      */             
/* 4715 */             setInternal(parameterIndex, buf.toString());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 4721 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 93;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized void newSetTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar) throws SQLException {
/* 4727 */     if (this.tsdf == null) {
/* 4728 */       this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss", Locale.US);
/*      */     }
/*      */     
/* 4731 */     String timestampString = null;
/*      */     
/* 4733 */     if (targetCalendar != null) {
/* 4734 */       targetCalendar.setTime(x);
/* 4735 */       this.tsdf.setTimeZone(targetCalendar.getTimeZone());
/*      */       
/* 4737 */       timestampString = this.tsdf.format(x);
/*      */     } else {
/* 4739 */       this.tsdf.setTimeZone(this.connection.getServerTimezoneTZ());
/* 4740 */       timestampString = this.tsdf.format(x);
/*      */     } 
/*      */     
/* 4743 */     StringBuffer buf = new StringBuffer();
/* 4744 */     buf.append(timestampString);
/* 4745 */     buf.append('.');
/* 4746 */     buf.append(formatNanos(x.getNanos()));
/* 4747 */     buf.append('\'');
/*      */     
/* 4749 */     setInternal(parameterIndex, buf.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 4754 */   private String formatNanos(int nanos) { return "0"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void newSetTimeInternal(int parameterIndex, Time x, Calendar targetCalendar) throws SQLException {
/* 4784 */     if (this.tdf == null) {
/* 4785 */       this.tdf = new SimpleDateFormat("''HH:mm:ss''", Locale.US);
/*      */     }
/*      */ 
/*      */     
/* 4789 */     String timeString = null;
/*      */     
/* 4791 */     if (targetCalendar != null) {
/* 4792 */       targetCalendar.setTime(x);
/* 4793 */       this.tdf.setTimeZone(targetCalendar.getTimeZone());
/*      */       
/* 4795 */       timeString = this.tdf.format(x);
/*      */     } else {
/* 4797 */       this.tdf.setTimeZone(this.connection.getServerTimezoneTZ());
/* 4798 */       timeString = this.tdf.format(x);
/*      */     } 
/*      */     
/* 4801 */     setInternal(parameterIndex, timeString);
/*      */   }
/*      */ 
/*      */   
/*      */   private synchronized void newSetDateInternal(int parameterIndex, Date x, Calendar targetCalendar) throws SQLException {
/* 4806 */     if (this.ddf == null) {
/* 4807 */       this.ddf = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */     }
/*      */ 
/*      */     
/* 4811 */     String timeString = null;
/*      */     
/* 4813 */     if (targetCalendar != null) {
/* 4814 */       targetCalendar.setTime(x);
/* 4815 */       this.ddf.setTimeZone(targetCalendar.getTimeZone());
/*      */       
/* 4817 */       timeString = this.ddf.format(x);
/*      */     } else {
/* 4819 */       this.ddf.setTimeZone(this.connection.getServerTimezoneTZ());
/* 4820 */       timeString = this.ddf.format(x);
/*      */     } 
/*      */     
/* 4823 */     setInternal(parameterIndex, timeString);
/*      */   }
/*      */   
/*      */   private void doSSPSCompatibleTimezoneShift(int parameterIndex, Timestamp x, Calendar sessionCalendar) throws SQLException {
/* 4827 */     Calendar sessionCalendar2 = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4832 */     synchronized (sessionCalendar2) {
/* 4833 */       Date oldTime = sessionCalendar2.getTime();
/*      */       
/*      */       try {
/* 4836 */         sessionCalendar2.setTime(x);
/*      */         
/* 4838 */         int year = sessionCalendar2.get(1);
/* 4839 */         int month = sessionCalendar2.get(2) + 1;
/* 4840 */         int date = sessionCalendar2.get(5);
/*      */         
/* 4842 */         int hour = sessionCalendar2.get(11);
/* 4843 */         int minute = sessionCalendar2.get(12);
/* 4844 */         int seconds = sessionCalendar2.get(13);
/*      */         
/* 4846 */         StringBuffer tsBuf = new StringBuffer();
/*      */         
/* 4848 */         tsBuf.append('\'');
/* 4849 */         tsBuf.append(year);
/*      */         
/* 4851 */         tsBuf.append("-");
/*      */         
/* 4853 */         if (month < 10) {
/* 4854 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4857 */         tsBuf.append(month);
/*      */         
/* 4859 */         tsBuf.append('-');
/*      */         
/* 4861 */         if (date < 10) {
/* 4862 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4865 */         tsBuf.append(date);
/*      */         
/* 4867 */         tsBuf.append(' ');
/*      */         
/* 4869 */         if (hour < 10) {
/* 4870 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4873 */         tsBuf.append(hour);
/*      */         
/* 4875 */         tsBuf.append(':');
/*      */         
/* 4877 */         if (minute < 10) {
/* 4878 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4881 */         tsBuf.append(minute);
/*      */         
/* 4883 */         tsBuf.append(':');
/*      */         
/* 4885 */         if (seconds < 10) {
/* 4886 */           tsBuf.append('0');
/*      */         }
/*      */         
/* 4889 */         tsBuf.append(seconds);
/*      */         
/* 4891 */         tsBuf.append('.');
/* 4892 */         tsBuf.append(formatNanos(x.getNanos()));
/* 4893 */         tsBuf.append('\'');
/*      */         
/* 4895 */         setInternal(parameterIndex, tsBuf.toString());
/*      */       } finally {
/*      */         
/* 4898 */         sessionCalendar.setTime(oldTime);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length) throws SQLException {
/* 4929 */     if (x == null) {
/* 4930 */       setNull(parameterIndex, 12);
/*      */     } else {
/* 4932 */       setBinaryStream(parameterIndex, x, length);
/*      */       
/* 4934 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2005;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int parameterIndex, URL arg) throws SQLException {
/* 4942 */     if (arg != null) {
/* 4943 */       setString(parameterIndex, arg.toString());
/*      */       
/* 4945 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 70;
/*      */     } else {
/* 4947 */       setNull(parameterIndex, 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final void streamToBytes(Buffer packet, InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException {
/*      */     try {
/* 4955 */       String connectionEncoding = this.connection.getEncoding();
/*      */       
/* 4957 */       boolean hexEscape = false;
/*      */       
/* 4959 */       if (this.connection.isNoBackslashEscapesSet() || (this.connection.getUseUnicode() && connectionEncoding != null && CharsetMapping.isMultibyteCharset(connectionEncoding) && !this.connection.parserKnowsUnicode()))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 4964 */         hexEscape = true;
/*      */       }
/*      */       
/* 4967 */       if (streamLength == -1) {
/* 4968 */         useLength = false;
/*      */       }
/*      */       
/* 4971 */       int bc = -1;
/*      */       
/* 4973 */       if (useLength) {
/* 4974 */         bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */       } else {
/* 4976 */         bc = readblock(in, this.streamConvertBuf);
/*      */       } 
/*      */       
/* 4979 */       int lengthLeftToRead = streamLength - bc;
/*      */       
/* 4981 */       if (hexEscape) {
/* 4982 */         packet.writeStringNoNull("x");
/* 4983 */       } else if (this.connection.getIO().versionMeetsMinimum(4, 1, 0)) {
/* 4984 */         packet.writeStringNoNull("_binary");
/*      */       } 
/*      */       
/* 4987 */       if (escape) {
/* 4988 */         packet.writeByte((byte)39);
/*      */       }
/*      */       
/* 4991 */       while (bc > 0) {
/* 4992 */         if (hexEscape) {
/* 4993 */           hexEscapeBlock(this.streamConvertBuf, packet, bc);
/* 4994 */         } else if (escape) {
/* 4995 */           escapeblockFast(this.streamConvertBuf, packet, bc);
/*      */         } else {
/* 4997 */           packet.writeBytesNoNull(this.streamConvertBuf, 0, bc);
/*      */         } 
/*      */         
/* 5000 */         if (useLength) {
/* 5001 */           bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */           
/* 5003 */           if (bc > 0)
/* 5004 */             lengthLeftToRead -= bc; 
/*      */           continue;
/*      */         } 
/* 5007 */         bc = readblock(in, this.streamConvertBuf);
/*      */       } 
/*      */ 
/*      */       
/* 5011 */       if (escape) {
/* 5012 */         packet.writeByte((byte)39);
/*      */       }
/*      */     } finally {
/* 5015 */       if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 5017 */           in.close();
/* 5018 */         } catch (IOException ioEx) {}
/*      */ 
/*      */ 
/*      */         
/* 5022 */         in = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private final byte[] streamToBytes(InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException {
/*      */     try {
/* 5030 */       if (streamLength == -1) {
/* 5031 */         useLength = false;
/*      */       }
/*      */       
/* 5034 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */       
/* 5036 */       int bc = -1;
/*      */       
/* 5038 */       if (useLength) {
/* 5039 */         bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */       } else {
/* 5041 */         bc = readblock(in, this.streamConvertBuf);
/*      */       } 
/*      */       
/* 5044 */       int lengthLeftToRead = streamLength - bc;
/*      */       
/* 5046 */       if (escape) {
/* 5047 */         if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 5048 */           bytesOut.write(95);
/* 5049 */           bytesOut.write(98);
/* 5050 */           bytesOut.write(105);
/* 5051 */           bytesOut.write(110);
/* 5052 */           bytesOut.write(97);
/* 5053 */           bytesOut.write(114);
/* 5054 */           bytesOut.write(121);
/*      */         } 
/*      */         
/* 5057 */         bytesOut.write(39);
/*      */       } 
/*      */       
/* 5060 */       while (bc > 0) {
/* 5061 */         if (escape) {
/* 5062 */           escapeblockFast(this.streamConvertBuf, bytesOut, bc);
/*      */         } else {
/* 5064 */           bytesOut.write(this.streamConvertBuf, 0, bc);
/*      */         } 
/*      */         
/* 5067 */         if (useLength) {
/* 5068 */           bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */           
/* 5070 */           if (bc > 0)
/* 5071 */             lengthLeftToRead -= bc; 
/*      */           continue;
/*      */         } 
/* 5074 */         bc = readblock(in, this.streamConvertBuf);
/*      */       } 
/*      */ 
/*      */       
/* 5078 */       if (escape) {
/* 5079 */         bytesOut.write(39);
/*      */       }
/*      */       
/* 5082 */       return bytesOut.toByteArray();
/*      */     } finally {
/* 5084 */       if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 5086 */           in.close();
/* 5087 */         } catch (IOException ioEx) {}
/*      */ 
/*      */ 
/*      */         
/* 5091 */         in = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 5102 */     StringBuffer buf = new StringBuffer();
/* 5103 */     buf.append(super.toString());
/* 5104 */     buf.append(": ");
/*      */     
/*      */     try {
/* 5107 */       buf.append(asSql());
/* 5108 */     } catch (SQLException sqlEx) {
/* 5109 */       buf.append("EXCEPTION: " + sqlEx.toString());
/*      */     } 
/*      */     
/* 5112 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5118 */   public synchronized boolean isClosed() throws SQLException { return this.isClosed; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5129 */   protected int getParameterIndexOffset() { return 0; }
/*      */ 
/*      */ 
/*      */   
/* 5133 */   public void setAsciiStream(int parameterIndex, InputStream x) throws SQLException { setAsciiStream(parameterIndex, x, -1); }
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, long length) throws SQLException {
/* 5137 */     setAsciiStream(parameterIndex, x, (int)length);
/* 5138 */     this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2005;
/*      */   }
/*      */ 
/*      */   
/* 5142 */   public void setBinaryStream(int parameterIndex, InputStream x) throws SQLException { setBinaryStream(parameterIndex, x, -1); }
/*      */ 
/*      */ 
/*      */   
/* 5146 */   public void setBinaryStream(int parameterIndex, InputStream x, long length) throws SQLException { setBinaryStream(parameterIndex, x, (int)length); }
/*      */ 
/*      */ 
/*      */   
/* 5150 */   public void setBlob(int parameterIndex, InputStream inputStream) throws SQLException { setBinaryStream(parameterIndex, inputStream); }
/*      */ 
/*      */ 
/*      */   
/* 5154 */   public void setCharacterStream(int parameterIndex, Reader reader) throws SQLException { setCharacterStream(parameterIndex, reader, -1); }
/*      */ 
/*      */ 
/*      */   
/* 5158 */   public void setCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException { setCharacterStream(parameterIndex, reader, (int)length); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5163 */   public void setClob(int parameterIndex, Reader reader) throws SQLException { setCharacterStream(parameterIndex, reader); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5169 */   public void setClob(int parameterIndex, Reader reader, long length) throws SQLException { setCharacterStream(parameterIndex, reader, length); }
/*      */ 
/*      */ 
/*      */   
/* 5173 */   public void setNCharacterStream(int parameterIndex, Reader value) throws SQLException { setNCharacterStream(parameterIndex, value, -1L); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNString(int parameterIndex, String x) throws SQLException {
/* 5191 */     if (this.charEncoding.equalsIgnoreCase("UTF-8") || this.charEncoding.equalsIgnoreCase("utf8")) {
/*      */       
/* 5193 */       setString(parameterIndex, x);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 5198 */     if (x == null) {
/* 5199 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 5201 */       int stringLength = x.length();
/*      */ 
/*      */ 
/*      */       
/* 5205 */       StringBuffer buf = new StringBuffer((int)(x.length() * 1.1D + 4.0D));
/* 5206 */       buf.append("_utf8");
/* 5207 */       buf.append('\'');
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5216 */       for (int i = 0; i < stringLength; i++) {
/* 5217 */         char c = x.charAt(i);
/*      */         
/* 5219 */         switch (c) {
/*      */           case '\000':
/* 5221 */             buf.append('\\');
/* 5222 */             buf.append('0');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\n':
/* 5227 */             buf.append('\\');
/* 5228 */             buf.append('n');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\r':
/* 5233 */             buf.append('\\');
/* 5234 */             buf.append('r');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\\':
/* 5239 */             buf.append('\\');
/* 5240 */             buf.append('\\');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\'':
/* 5245 */             buf.append('\\');
/* 5246 */             buf.append('\'');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '"':
/* 5251 */             if (this.usingAnsiMode) {
/* 5252 */               buf.append('\\');
/*      */             }
/*      */             
/* 5255 */             buf.append('"');
/*      */             break;
/*      */ 
/*      */           
/*      */           case '\032':
/* 5260 */             buf.append('\\');
/* 5261 */             buf.append('Z');
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 5266 */             buf.append(c);
/*      */             break;
/*      */         } 
/*      */       } 
/* 5270 */       buf.append('\'');
/*      */       
/* 5272 */       String parameterAsString = buf.toString();
/*      */       
/* 5274 */       byte[] parameterAsBytes = null;
/*      */       
/* 5276 */       if (!this.isLoadDataQuery) {
/* 5277 */         parameterAsBytes = StringUtils.getBytes(parameterAsString, this.connection.getCharsetConverter("UTF-8"), "UTF-8", this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 5283 */         parameterAsBytes = parameterAsString.getBytes();
/*      */       } 
/*      */       
/* 5286 */       setInternal(parameterIndex, parameterAsBytes);
/*      */       
/* 5288 */       this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = -9;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNCharacterStream(int parameterIndex, Reader reader, long length) throws SQLException {
/*      */     try {
/* 5317 */       if (reader == null) {
/* 5318 */         setNull(parameterIndex, -1);
/*      */       } else {
/*      */         
/* 5321 */         char[] c = null;
/* 5322 */         int len = 0;
/*      */         
/* 5324 */         boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5329 */         if (useLength && length != -1L) {
/* 5330 */           c = new char[(int)length];
/*      */           
/* 5332 */           int numCharsRead = readFully(reader, c, (int)length);
/*      */ 
/*      */ 
/*      */           
/* 5336 */           setNString(parameterIndex, new String(c, 0, numCharsRead));
/*      */         } else {
/*      */           
/* 5339 */           c = new char[4096];
/*      */           
/* 5341 */           StringBuffer buf = new StringBuffer();
/*      */           
/* 5343 */           while ((len = reader.read(c)) != -1) {
/* 5344 */             buf.append(c, 0, len);
/*      */           }
/*      */           
/* 5347 */           setNString(parameterIndex, buf.toString());
/*      */         } 
/*      */         
/* 5350 */         this.parameterTypes[parameterIndex - 1 + getParameterIndexOffset()] = 2011;
/*      */       } 
/* 5352 */     } catch (IOException ioEx) {
/* 5353 */       throw SQLError.createSQLException(ioEx.toString(), "S1000", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 5359 */   public void setNClob(int parameterIndex, Reader reader) throws SQLException { setNCharacterStream(parameterIndex, reader); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNClob(int parameterIndex, Reader reader, long length) throws SQLException {
/* 5377 */     if (reader == null) {
/* 5378 */       setNull(parameterIndex, -1);
/*      */     } else {
/* 5380 */       setNCharacterStream(parameterIndex, reader, length);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 5385 */   public ParameterBindings getParameterBindings() throws SQLException { return new EmulatedPreparedStatementBindings(this); }
/*      */   
/*      */   class EmulatedPreparedStatementBindings implements ParameterBindings {
/*      */     private ResultSetImpl bindingsAsRs;
/*      */     private boolean[] parameterIsNull;
/*      */     private final PreparedStatement this$0;
/*      */     
/*      */     public EmulatedPreparedStatementBindings(PreparedStatement this$0) throws SQLException {
/* 5393 */       this.this$0 = this$0;
/* 5394 */       List rows = new ArrayList();
/* 5395 */       this.parameterIsNull = new boolean[this$0.parameterCount];
/* 5396 */       System.arraycopy(this$0.isNull, 0, this.parameterIsNull, 0, this$0.parameterCount);
/*      */ 
/*      */       
/* 5399 */       byte[][] rowData = new byte[this$0.parameterCount][];
/* 5400 */       Field[] typeMetadata = new Field[this$0.parameterCount];
/*      */       
/* 5402 */       for (int i = 0; i < this$0.parameterCount; i++) {
/* 5403 */         if (this$0.batchCommandIndex == -1) {
/* 5404 */           rowData[i] = this$0.getBytesRepresentation(i);
/*      */         } else {
/* 5406 */           rowData[i] = this$0.getBytesRepresentationForBatch(i, this$0.batchCommandIndex);
/*      */         } 
/* 5408 */         int charsetIndex = 0;
/*      */         
/* 5410 */         if (this$0.parameterTypes[i] == -2 || this$0.parameterTypes[i] == 2004) {
/*      */           
/* 5412 */           charsetIndex = 63;
/*      */         } else {
/* 5414 */           String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(this$0.connection.getEncoding(), this$0.connection);
/*      */ 
/*      */           
/* 5417 */           charsetIndex = CharsetMapping.getCharsetIndexForMysqlEncodingName(mysqlEncodingName);
/*      */         } 
/*      */ 
/*      */         
/* 5421 */         Field parameterMetadata = new Field(null, "parameter_" + (i + 1), charsetIndex, this$0.parameterTypes[i], (rowData[i]).length);
/*      */ 
/*      */         
/* 5424 */         parameterMetadata.setConnection(this$0.connection);
/* 5425 */         typeMetadata[i] = parameterMetadata;
/*      */       } 
/*      */       
/* 5428 */       rows.add(new ByteArrayRow(rowData, this$0.getExceptionInterceptor()));
/*      */       
/* 5430 */       this.bindingsAsRs = new ResultSetImpl(this$0.connection.getCatalog(), typeMetadata, new RowDataStatic(rows), this$0.connection, null);
/*      */       
/* 5432 */       this.bindingsAsRs.next();
/*      */     }
/*      */ 
/*      */     
/* 5436 */     public Array getArray(int parameterIndex) throws SQLException { return this.bindingsAsRs.getArray(parameterIndex); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5441 */     public InputStream getAsciiStream(int parameterIndex) throws SQLException { return this.bindingsAsRs.getAsciiStream(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5445 */     public BigDecimal getBigDecimal(int parameterIndex) throws SQLException { return this.bindingsAsRs.getBigDecimal(parameterIndex); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5450 */     public InputStream getBinaryStream(int parameterIndex) throws SQLException { return this.bindingsAsRs.getBinaryStream(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5454 */     public Blob getBlob(int parameterIndex) throws SQLException { return this.bindingsAsRs.getBlob(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5458 */     public boolean getBoolean(int parameterIndex) throws SQLException { return this.bindingsAsRs.getBoolean(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5462 */     public byte getByte(int parameterIndex) throws SQLException { return this.bindingsAsRs.getByte(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5466 */     public byte[] getBytes(int parameterIndex) throws SQLException { return this.bindingsAsRs.getBytes(parameterIndex); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5471 */     public Reader getCharacterStream(int parameterIndex) throws SQLException { return this.bindingsAsRs.getCharacterStream(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5475 */     public Clob getClob(int parameterIndex) throws SQLException { return this.bindingsAsRs.getClob(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5479 */     public Date getDate(int parameterIndex) throws SQLException { return this.bindingsAsRs.getDate(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5483 */     public double getDouble(int parameterIndex) throws SQLException { return this.bindingsAsRs.getDouble(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5487 */     public float getFloat(int parameterIndex) throws SQLException { return this.bindingsAsRs.getFloat(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5491 */     public int getInt(int parameterIndex) throws SQLException { return this.bindingsAsRs.getInt(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5495 */     public long getLong(int parameterIndex) throws SQLException { return this.bindingsAsRs.getLong(parameterIndex); }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5500 */     public Reader getNCharacterStream(int parameterIndex) throws SQLException { return this.bindingsAsRs.getCharacterStream(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5504 */     public Reader getNClob(int parameterIndex) throws SQLException { return this.bindingsAsRs.getCharacterStream(parameterIndex); }
/*      */ 
/*      */     
/*      */     public Object getObject(int parameterIndex) throws SQLException {
/* 5508 */       this.this$0.checkBounds(parameterIndex, 0);
/*      */       
/* 5510 */       if (this.parameterIsNull[parameterIndex - 1]) {
/* 5511 */         return null;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5518 */       switch (this.this$0.parameterTypes[parameterIndex - 1]) {
/*      */         case -6:
/* 5520 */           return new Byte(getByte(parameterIndex));
/*      */         case 5:
/* 5522 */           return new Short(getShort(parameterIndex));
/*      */         case 4:
/* 5524 */           return new Integer(getInt(parameterIndex));
/*      */         case -5:
/* 5526 */           return new Long(getLong(parameterIndex));
/*      */         case 6:
/* 5528 */           return new Float(getFloat(parameterIndex));
/*      */         case 8:
/* 5530 */           return new Double(getDouble(parameterIndex));
/*      */       } 
/* 5532 */       return this.bindingsAsRs.getObject(parameterIndex);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 5537 */     public Ref getRef(int parameterIndex) throws SQLException { return this.bindingsAsRs.getRef(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5541 */     public short getShort(int parameterIndex) throws SQLException { return this.bindingsAsRs.getShort(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5545 */     public String getString(int parameterIndex) throws SQLException { return this.bindingsAsRs.getString(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5549 */     public Time getTime(int parameterIndex) throws SQLException { return this.bindingsAsRs.getTime(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5553 */     public Timestamp getTimestamp(int parameterIndex) throws SQLException { return this.bindingsAsRs.getTimestamp(parameterIndex); }
/*      */ 
/*      */ 
/*      */     
/* 5557 */     public URL getURL(int parameterIndex) throws SQLException { return this.bindingsAsRs.getURL(parameterIndex); }
/*      */ 
/*      */     
/*      */     public boolean isNull(int parameterIndex) throws SQLException {
/* 5561 */       this.this$0.checkBounds(parameterIndex, 0);
/*      */       
/* 5563 */       return this.parameterIsNull[parameterIndex - 1];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/* 5568 */   public String getPreparedSql() { return this.originalSql; }
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 5572 */     int count = super.getUpdateCount();
/*      */     
/* 5574 */     if (containsOnDuplicateKeyUpdateInSQL() && this.compensateForOnDuplicateKeyUpdate)
/*      */     {
/* 5576 */       if (count == 2 || count == 0) {
/* 5577 */         count = 1;
/*      */       }
/*      */     }
/*      */     
/* 5581 */     return count;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static boolean canRewrite(String sql, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementStartPos) {
/* 5588 */     boolean rewritableOdku = true;
/*      */     
/* 5590 */     if (isOnDuplicateKeyUpdate) {
/* 5591 */       int updateClausePos = StringUtils.indexOfIgnoreCase(locationOfOnDuplicateKeyUpdate, sql, " UPDATE ");
/*      */ 
/*      */       
/* 5594 */       if (updateClausePos != -1) {
/* 5595 */         rewritableOdku = (StringUtils.indexOfIgnoreCaseRespectMarker(updateClausePos, sql, "LAST_INSERT_ID", "\"'`", "\"'`", false) == -1);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5602 */     return (StringUtils.startsWithIgnoreCaseAndWs(sql, "INSERT", statementStartPos) && StringUtils.indexOfIgnoreCaseRespectMarker(statementStartPos, sql, "SELECT", "\"'`", "\"'`", false) == -1 && rewritableOdku);
/*      */   }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/PreparedStatement.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */