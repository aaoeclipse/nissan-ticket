/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommunicationsException
/*     */   extends SQLException
/*     */   implements StreamingNotifiable
/*     */ {
/*     */   private String exceptionMessage;
/*     */   private boolean streamingResultSetInPlay;
/*     */   private ConnectionImpl conn;
/*     */   private long lastPacketSentTimeMs;
/*     */   private long lastPacketReceivedTimeMs;
/*     */   private Exception underlyingException;
/*     */   
/*     */   public CommunicationsException(ConnectionImpl conn, long lastPacketSentTimeMs, long lastPacketReceivedTimeMs, Exception underlyingException) {
/*  44 */     this.exceptionMessage = null;
/*     */     
/*  46 */     this.streamingResultSetInPlay = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.conn = conn;
/*  58 */     this.lastPacketReceivedTimeMs = lastPacketReceivedTimeMs;
/*  59 */     this.lastPacketSentTimeMs = lastPacketSentTimeMs;
/*  60 */     this.underlyingException = underlyingException;
/*     */     
/*  62 */     if (underlyingException != null) {
/*  63 */       initCause(underlyingException);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMessage() {
/*  77 */     if (this.exceptionMessage == null) {
/*  78 */       this.exceptionMessage = SQLError.createLinkFailureMessageBasedOnHeuristics(this.conn, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, this.underlyingException, this.streamingResultSetInPlay);
/*     */ 
/*     */       
/*  81 */       this.conn = null;
/*  82 */       this.underlyingException = null;
/*     */     } 
/*  84 */     return this.exceptionMessage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public String getSQLState() { return "08S01"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setWasStreamingResults() { this.streamingResultSetInPlay = true; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/CommunicationsException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */