package com.mysql.jdbc;

interface WriterWatcher {
  void writerClosed(WatchableWriter paramWatchableWriter);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/WriterWatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */