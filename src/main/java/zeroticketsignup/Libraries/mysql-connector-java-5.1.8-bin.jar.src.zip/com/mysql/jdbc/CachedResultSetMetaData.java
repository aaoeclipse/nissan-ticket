/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CachedResultSetMetaData
/*    */ {
/* 31 */   Map columnNameToIndex = null;
/*    */ 
/*    */   
/*    */   Field[] fields;
/*    */ 
/*    */   
/* 37 */   Map fullColumnNameToIndex = null;
/*    */ 
/*    */   
/*    */   ResultSetMetaData metadata;
/*    */ 
/*    */   
/* 43 */   public Map getColumnNameToIndex() { return this.columnNameToIndex; }
/*    */ 
/*    */ 
/*    */   
/* 47 */   public Field[] getFields() { return this.fields; }
/*    */ 
/*    */ 
/*    */   
/* 51 */   public Map getFullColumnNameToIndex() { return this.fullColumnNameToIndex; }
/*    */ 
/*    */ 
/*    */   
/* 55 */   public ResultSetMetaData getMetadata() { return this.metadata; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/CachedResultSetMetaData.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */