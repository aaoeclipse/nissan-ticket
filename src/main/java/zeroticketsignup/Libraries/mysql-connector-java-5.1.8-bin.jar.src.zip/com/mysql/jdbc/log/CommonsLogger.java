/*     */ package com.mysql.jdbc.log;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommonsLogger
/*     */   implements Log
/*     */ {
/*     */   private Log logger;
/*     */   
/*  33 */   public CommonsLogger(String instanceName) { this.logger = LogFactory.getLog(instanceName); }
/*     */ 
/*     */ 
/*     */   
/*  37 */   public boolean isDebugEnabled() { return this.logger.isInfoEnabled(); }
/*     */ 
/*     */ 
/*     */   
/*  41 */   public boolean isErrorEnabled() { return this.logger.isErrorEnabled(); }
/*     */ 
/*     */ 
/*     */   
/*  45 */   public boolean isFatalEnabled() { return this.logger.isFatalEnabled(); }
/*     */ 
/*     */ 
/*     */   
/*  49 */   public boolean isInfoEnabled() { return this.logger.isInfoEnabled(); }
/*     */ 
/*     */ 
/*     */   
/*  53 */   public boolean isTraceEnabled() { return this.logger.isTraceEnabled(); }
/*     */ 
/*     */ 
/*     */   
/*  57 */   public boolean isWarnEnabled() { return this.logger.isWarnEnabled(); }
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void logDebug(Object msg) { this.logger.debug(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */   
/*  65 */   public void logDebug(Object msg, Throwable thrown) { this.logger.debug(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void logError(Object msg) { this.logger.error(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */   
/*  73 */   public void logError(Object msg, Throwable thrown) { this.logger.fatal(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */   
/*  77 */   public void logFatal(Object msg) { this.logger.fatal(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */   
/*  81 */   public void logFatal(Object msg, Throwable thrown) { this.logger.fatal(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */   
/*  85 */   public void logInfo(Object msg) { this.logger.info(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */   
/*  89 */   public void logInfo(Object msg, Throwable thrown) { this.logger.info(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */   
/*  93 */   public void logTrace(Object msg) { this.logger.trace(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */   
/*  97 */   public void logTrace(Object msg, Throwable thrown) { this.logger.trace(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */   
/* 101 */   public void logWarn(Object msg) { this.logger.warn(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void logWarn(Object msg, Throwable thrown) { this.logger.warn(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/log/CommonsLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */