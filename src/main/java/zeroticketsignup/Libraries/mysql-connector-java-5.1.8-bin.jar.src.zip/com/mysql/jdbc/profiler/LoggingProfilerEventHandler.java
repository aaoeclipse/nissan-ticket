/*    */ package com.mysql.jdbc.profiler;
/*    */ 
/*    */ import com.mysql.jdbc.Connection;
/*    */ import com.mysql.jdbc.log.Log;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoggingProfilerEventHandler
/*    */   implements ProfilerEventHandler
/*    */ {
/*    */   private Log log;
/*    */   
/*    */   public void consumeEvent(ProfilerEvent evt) {
/* 43 */     if (evt.eventType == 0) {
/* 44 */       this.log.logWarn(evt);
/*    */     } else {
/* 46 */       this.log.logInfo(evt);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 51 */   public void destroy() { this.log = null; }
/*    */ 
/*    */ 
/*    */   
/* 55 */   public void init(Connection conn, Properties props) throws SQLException { this.log = conn.getLog(); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/profiler/LoggingProfilerEventHandler.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */