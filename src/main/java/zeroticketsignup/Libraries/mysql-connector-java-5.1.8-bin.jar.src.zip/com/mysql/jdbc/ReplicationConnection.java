/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ReplicationConnection
/*      */   implements Connection, PingTarget
/*      */ {
/*      */   protected Connection currentConnection;
/*      */   protected Connection masterConnection;
/*      */   protected Connection slavesConnection;
/*      */   
/*      */   protected ReplicationConnection() {}
/*      */   
/*      */   public ReplicationConnection(Properties masterProperties, Properties slaveProperties) throws SQLException {
/*   56 */     NonRegisteringDriver driver = new NonRegisteringDriver();
/*      */     
/*   58 */     StringBuffer masterUrl = new StringBuffer("jdbc:mysql://");
/*   59 */     StringBuffer slaveUrl = new StringBuffer("jdbc:mysql://");
/*      */     
/*   61 */     String masterHost = masterProperties.getProperty("HOST");
/*      */ 
/*      */     
/*   64 */     if (masterHost != null) {
/*   65 */       masterUrl.append(masterHost);
/*      */     }
/*      */     
/*   68 */     String slaveHost = slaveProperties.getProperty("HOST");
/*      */ 
/*      */     
/*   71 */     if (slaveHost != null) {
/*   72 */       slaveUrl.append(slaveHost);
/*      */     }
/*      */     
/*   75 */     String masterDb = masterProperties.getProperty("DBNAME");
/*      */ 
/*      */     
/*   78 */     masterUrl.append("/");
/*      */     
/*   80 */     if (masterDb != null) {
/*   81 */       masterUrl.append(masterDb);
/*      */     }
/*      */     
/*   84 */     String slaveDb = slaveProperties.getProperty("DBNAME");
/*      */ 
/*      */     
/*   87 */     slaveUrl.append("/");
/*      */     
/*   89 */     if (slaveDb != null) {
/*   90 */       slaveUrl.append(slaveDb);
/*      */     }
/*      */     
/*   93 */     slaveProperties.setProperty("roundRobinLoadBalance", "true");
/*      */     
/*   95 */     this.masterConnection = (Connection)driver.connect(masterUrl.toString(), masterProperties);
/*      */     
/*   97 */     this.slavesConnection = (Connection)driver.connect(slaveUrl.toString(), slaveProperties);
/*      */     
/*   99 */     this.slavesConnection.setReadOnly(true);
/*      */     
/*  101 */     this.currentConnection = this.masterConnection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  110 */   public synchronized void clearWarnings() throws SQLException { this.currentConnection.clearWarnings(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close() throws SQLException {
/*  119 */     this.masterConnection.close();
/*  120 */     this.slavesConnection.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  129 */   public synchronized void commit() throws SQLException { this.currentConnection.commit(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement() throws SQLException {
/*  138 */     Statement stmt = this.currentConnection.createStatement();
/*  139 */     ((Statement)stmt).setPingTarget(this);
/*      */     
/*  141 */     return stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*  151 */     Statement stmt = this.currentConnection.createStatement(resultSetType, resultSetConcurrency);
/*      */ 
/*      */     
/*  154 */     ((Statement)stmt).setPingTarget(this);
/*      */     
/*  156 */     return stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  167 */     Statement stmt = this.currentConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */ 
/*      */     
/*  170 */     ((Statement)stmt).setPingTarget(this);
/*      */     
/*  172 */     return stmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  181 */   public synchronized boolean getAutoCommit() throws SQLException { return this.currentConnection.getAutoCommit(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  190 */   public synchronized String getCatalog() throws SQLException { return this.currentConnection.getCatalog(); }
/*      */ 
/*      */ 
/*      */   
/*  194 */   public synchronized Connection getCurrentConnection() { return this.currentConnection; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  203 */   public synchronized int getHoldability() throws SQLException { return this.currentConnection.getHoldability(); }
/*      */ 
/*      */ 
/*      */   
/*  207 */   public synchronized Connection getMasterConnection() { return this.masterConnection; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  216 */   public synchronized DatabaseMetaData getMetaData() throws SQLException { return this.currentConnection.getMetaData(); }
/*      */ 
/*      */ 
/*      */   
/*  220 */   public synchronized Connection getSlavesConnection() { return this.slavesConnection; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  229 */   public synchronized int getTransactionIsolation() throws SQLException { return this.currentConnection.getTransactionIsolation(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  238 */   public synchronized Map getTypeMap() throws SQLException { return this.currentConnection.getTypeMap(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  247 */   public synchronized SQLWarning getWarnings() throws SQLException { return this.currentConnection.getWarnings(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  256 */   public synchronized boolean isClosed() throws SQLException { return this.currentConnection.isClosed(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  265 */   public synchronized boolean isReadOnly() throws SQLException { return (this.currentConnection == this.slavesConnection); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  274 */   public synchronized String nativeSQL(String sql) throws SQLException { return this.currentConnection.nativeSQL(sql); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  283 */   public CallableStatement prepareCall(String sql) throws SQLException { return this.currentConnection.prepareCall(sql); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  293 */   public synchronized CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException { return this.currentConnection.prepareCall(sql, resultSetType, resultSetConcurrency); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  305 */   public synchronized CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException { return this.currentConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/*  315 */     PreparedStatement pstmt = this.currentConnection.prepareStatement(sql);
/*      */     
/*  317 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  319 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement prepareStatement(String sql, int autoGeneratedKeys) throws SQLException {
/*  329 */     PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, autoGeneratedKeys);
/*      */     
/*  331 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  333 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  343 */     PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */ 
/*      */     
/*  346 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  348 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  360 */     PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*      */ 
/*      */     
/*  363 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  365 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement prepareStatement(String sql, int[] columnIndexes) throws SQLException {
/*  375 */     PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, columnIndexes);
/*      */     
/*  377 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  379 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement prepareStatement(String sql, String[] columnNames) throws SQLException {
/*  390 */     PreparedStatement pstmt = this.currentConnection.prepareStatement(sql, columnNames);
/*      */     
/*  392 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  394 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  404 */   public synchronized void releaseSavepoint(Savepoint savepoint) throws SQLException { this.currentConnection.releaseSavepoint(savepoint); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  413 */   public synchronized void rollback() throws SQLException { this.currentConnection.rollback(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  422 */   public synchronized void rollback(Savepoint savepoint) throws SQLException { this.currentConnection.rollback(savepoint); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  432 */   public synchronized void setAutoCommit(boolean autoCommit) throws SQLException { this.currentConnection.setAutoCommit(autoCommit); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  441 */   public synchronized void setCatalog(String catalog) throws SQLException { this.currentConnection.setCatalog(catalog); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  451 */   public synchronized void setHoldability(int holdability) throws SQLException { this.currentConnection.setHoldability(holdability); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setReadOnly(boolean readOnly) throws SQLException {
/*  460 */     if (readOnly) {
/*  461 */       if (this.currentConnection != this.slavesConnection) {
/*  462 */         switchToSlavesConnection();
/*      */       }
/*      */     }
/*  465 */     else if (this.currentConnection != this.masterConnection) {
/*  466 */       switchToMasterConnection();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  477 */   public synchronized Savepoint setSavepoint() throws SQLException { return this.currentConnection.setSavepoint(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  486 */   public synchronized Savepoint setSavepoint(String name) throws SQLException { return this.currentConnection.setSavepoint(name); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  496 */   public synchronized void setTransactionIsolation(int level) throws SQLException { this.currentConnection.setTransactionIsolation(level); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  507 */   public synchronized void setTypeMap(Map arg0) throws SQLException { this.currentConnection.setTypeMap(arg0); }
/*      */ 
/*      */ 
/*      */   
/*  511 */   private synchronized void switchToMasterConnection() throws SQLException { swapConnections(this.masterConnection, this.slavesConnection); }
/*      */ 
/*      */ 
/*      */   
/*  515 */   private synchronized void switchToSlavesConnection() throws SQLException { swapConnections(this.slavesConnection, this.masterConnection); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void swapConnections(Connection switchToConnection, Connection switchFromConnection) throws SQLException {
/*  530 */     String switchFromCatalog = switchFromConnection.getCatalog();
/*  531 */     String switchToCatalog = switchToConnection.getCatalog();
/*      */     
/*  533 */     if (switchToCatalog != null && !switchToCatalog.equals(switchFromCatalog)) {
/*  534 */       switchToConnection.setCatalog(switchFromCatalog);
/*  535 */     } else if (switchFromCatalog != null) {
/*  536 */       switchToConnection.setCatalog(switchFromCatalog);
/*      */     } 
/*      */     
/*  539 */     boolean switchToAutoCommit = switchToConnection.getAutoCommit();
/*  540 */     boolean switchFromConnectionAutoCommit = switchFromConnection.getAutoCommit();
/*      */     
/*  542 */     if (switchFromConnectionAutoCommit != switchToAutoCommit) {
/*  543 */       switchToConnection.setAutoCommit(switchFromConnectionAutoCommit);
/*      */     }
/*      */     
/*  546 */     int switchToIsolation = switchToConnection.getTransactionIsolation();
/*      */ 
/*      */     
/*  549 */     int switchFromIsolation = switchFromConnection.getTransactionIsolation();
/*      */     
/*  551 */     if (switchFromIsolation != switchToIsolation) {
/*  552 */       switchToConnection.setTransactionIsolation(switchFromIsolation);
/*      */     }
/*      */ 
/*      */     
/*  556 */     this.currentConnection = switchToConnection;
/*      */   }
/*      */   
/*      */   public synchronized void doPing() throws SQLException {
/*  560 */     if (this.masterConnection != null) {
/*  561 */       this.masterConnection.ping();
/*      */     }
/*      */     
/*  564 */     if (this.slavesConnection != null) {
/*  565 */       this.slavesConnection.ping();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized void changeUser(String userName, String newPassword) throws SQLException {
/*  571 */     this.masterConnection.changeUser(userName, newPassword);
/*  572 */     this.slavesConnection.changeUser(userName, newPassword);
/*      */   }
/*      */   
/*      */   public synchronized void clearHasTriedMaster() {
/*  576 */     this.masterConnection.clearHasTriedMaster();
/*  577 */     this.slavesConnection.clearHasTriedMaster();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*  583 */     PreparedStatement pstmt = this.currentConnection.clientPrepareStatement(sql);
/*  584 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  586 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*  591 */     PreparedStatement pstmt = this.currentConnection.clientPrepareStatement(sql, autoGenKeyIndex);
/*  592 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  594 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  599 */     PreparedStatement pstmt = this.currentConnection.clientPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*  600 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  602 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*  607 */     PreparedStatement pstmt = this.currentConnection.clientPrepareStatement(sql, autoGenKeyIndexes);
/*  608 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  610 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  616 */     PreparedStatement pstmt = this.currentConnection.clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*  617 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  619 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*  624 */     PreparedStatement pstmt = this.currentConnection.clientPrepareStatement(sql, autoGenKeyColNames);
/*  625 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  627 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*  631 */   public synchronized int getActiveStatementCount() { return this.currentConnection.getActiveStatementCount(); }
/*      */ 
/*      */ 
/*      */   
/*  635 */   public synchronized long getIdleFor() { return this.currentConnection.getIdleFor(); }
/*      */ 
/*      */ 
/*      */   
/*  639 */   public synchronized Log getLog() throws SQLException { return this.currentConnection.getLog(); }
/*      */ 
/*      */ 
/*      */   
/*  643 */   public synchronized String getServerCharacterEncoding() { return this.currentConnection.getServerCharacterEncoding(); }
/*      */ 
/*      */ 
/*      */   
/*  647 */   public synchronized TimeZone getServerTimezoneTZ() { return this.currentConnection.getServerTimezoneTZ(); }
/*      */ 
/*      */ 
/*      */   
/*  651 */   public synchronized String getStatementComment() { return this.currentConnection.getStatementComment(); }
/*      */ 
/*      */ 
/*      */   
/*  655 */   public synchronized boolean hasTriedMaster() { return this.currentConnection.hasTriedMaster(); }
/*      */ 
/*      */ 
/*      */   
/*  659 */   public synchronized void initializeExtension(Extension ex) throws SQLException { this.currentConnection.initializeExtension(ex); }
/*      */ 
/*      */ 
/*      */   
/*  663 */   public synchronized boolean isAbonormallyLongQuery(long millisOrNanos) { return this.currentConnection.isAbonormallyLongQuery(millisOrNanos); }
/*      */ 
/*      */ 
/*      */   
/*  667 */   public synchronized boolean isInGlobalTx() { return this.currentConnection.isInGlobalTx(); }
/*      */ 
/*      */ 
/*      */   
/*  671 */   public synchronized boolean isMasterConnection() { return this.currentConnection.isMasterConnection(); }
/*      */ 
/*      */ 
/*      */   
/*  675 */   public synchronized boolean isNoBackslashEscapesSet() { return this.currentConnection.isNoBackslashEscapesSet(); }
/*      */ 
/*      */ 
/*      */   
/*  679 */   public synchronized boolean lowerCaseTableNames() { return this.currentConnection.lowerCaseTableNames(); }
/*      */ 
/*      */ 
/*      */   
/*  683 */   public synchronized boolean parserKnowsUnicode() { return this.currentConnection.parserKnowsUnicode(); }
/*      */ 
/*      */   
/*      */   public synchronized void ping() throws SQLException {
/*  687 */     this.masterConnection.ping();
/*  688 */     this.slavesConnection.ping();
/*      */   }
/*      */ 
/*      */   
/*  692 */   public synchronized void reportQueryTime(long millisOrNanos) { this.currentConnection.reportQueryTime(millisOrNanos); }
/*      */ 
/*      */ 
/*      */   
/*  696 */   public synchronized void resetServerState() throws SQLException { this.currentConnection.resetServerState(); }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/*  701 */     PreparedStatement pstmt = this.currentConnection.serverPrepareStatement(sql);
/*  702 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  704 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*  709 */     PreparedStatement pstmt = this.currentConnection.serverPrepareStatement(sql, autoGenKeyIndex);
/*  710 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  712 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  717 */     PreparedStatement pstmt = this.currentConnection.serverPrepareStatement(sql, resultSetType, resultSetConcurrency);
/*  718 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  720 */     return pstmt;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*  726 */     PreparedStatement pstmt = this.currentConnection.serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*  727 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  729 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*  734 */     PreparedStatement pstmt = this.currentConnection.serverPrepareStatement(sql, autoGenKeyIndexes);
/*  735 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  737 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*      */   public synchronized PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*  742 */     PreparedStatement pstmt = this.currentConnection.serverPrepareStatement(sql, autoGenKeyColNames);
/*  743 */     ((Statement)pstmt).setPingTarget(this);
/*      */     
/*  745 */     return pstmt;
/*      */   }
/*      */ 
/*      */   
/*  749 */   public synchronized void setFailedOver(boolean flag) { this.currentConnection.setFailedOver(flag); }
/*      */ 
/*      */ 
/*      */   
/*  753 */   public synchronized void setPreferSlaveDuringFailover(boolean flag) { this.currentConnection.setPreferSlaveDuringFailover(flag); }
/*      */ 
/*      */   
/*      */   public synchronized void setStatementComment(String comment) {
/*  757 */     this.masterConnection.setStatementComment(comment);
/*  758 */     this.slavesConnection.setStatementComment(comment);
/*      */   }
/*      */ 
/*      */   
/*  762 */   public synchronized void shutdownServer() throws SQLException { this.currentConnection.shutdownServer(); }
/*      */ 
/*      */ 
/*      */   
/*  766 */   public synchronized boolean supportsIsolationLevel() { return this.currentConnection.supportsIsolationLevel(); }
/*      */ 
/*      */ 
/*      */   
/*  770 */   public synchronized boolean supportsQuotedIdentifiers() { return this.currentConnection.supportsQuotedIdentifiers(); }
/*      */ 
/*      */ 
/*      */   
/*  774 */   public synchronized boolean supportsTransactions() { return this.currentConnection.supportsTransactions(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  779 */   public synchronized boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException { return this.currentConnection.versionMeetsMinimum(major, minor, subminor); }
/*      */ 
/*      */ 
/*      */   
/*  783 */   public synchronized String exposeAsXml() throws SQLException { return this.currentConnection.exposeAsXml(); }
/*      */ 
/*      */ 
/*      */   
/*  787 */   public synchronized boolean getAllowLoadLocalInfile() { return this.currentConnection.getAllowLoadLocalInfile(); }
/*      */ 
/*      */ 
/*      */   
/*  791 */   public synchronized boolean getAllowMultiQueries() { return this.currentConnection.getAllowMultiQueries(); }
/*      */ 
/*      */ 
/*      */   
/*  795 */   public synchronized boolean getAllowNanAndInf() { return this.currentConnection.getAllowNanAndInf(); }
/*      */ 
/*      */ 
/*      */   
/*  799 */   public synchronized boolean getAllowUrlInLocalInfile() { return this.currentConnection.getAllowUrlInLocalInfile(); }
/*      */ 
/*      */ 
/*      */   
/*  803 */   public synchronized boolean getAlwaysSendSetIsolation() { return this.currentConnection.getAlwaysSendSetIsolation(); }
/*      */ 
/*      */ 
/*      */   
/*  807 */   public synchronized boolean getAutoClosePStmtStreams() { return this.currentConnection.getAutoClosePStmtStreams(); }
/*      */ 
/*      */ 
/*      */   
/*  811 */   public synchronized boolean getAutoDeserialize() { return this.currentConnection.getAutoDeserialize(); }
/*      */ 
/*      */ 
/*      */   
/*  815 */   public synchronized boolean getAutoGenerateTestcaseScript() { return this.currentConnection.getAutoGenerateTestcaseScript(); }
/*      */ 
/*      */ 
/*      */   
/*  819 */   public synchronized boolean getAutoReconnectForPools() { return this.currentConnection.getAutoReconnectForPools(); }
/*      */ 
/*      */ 
/*      */   
/*  823 */   public synchronized boolean getAutoSlowLog() { return this.currentConnection.getAutoSlowLog(); }
/*      */ 
/*      */ 
/*      */   
/*  827 */   public synchronized int getBlobSendChunkSize() { return this.currentConnection.getBlobSendChunkSize(); }
/*      */ 
/*      */ 
/*      */   
/*  831 */   public synchronized boolean getBlobsAreStrings() { return this.currentConnection.getBlobsAreStrings(); }
/*      */ 
/*      */ 
/*      */   
/*  835 */   public synchronized boolean getCacheCallableStatements() { return this.currentConnection.getCacheCallableStatements(); }
/*      */ 
/*      */ 
/*      */   
/*  839 */   public synchronized boolean getCacheCallableStmts() { return this.currentConnection.getCacheCallableStmts(); }
/*      */ 
/*      */ 
/*      */   
/*  843 */   public synchronized boolean getCachePrepStmts() { return this.currentConnection.getCachePrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/*  847 */   public synchronized boolean getCachePreparedStatements() { return this.currentConnection.getCachePreparedStatements(); }
/*      */ 
/*      */ 
/*      */   
/*  851 */   public synchronized boolean getCacheResultSetMetadata() { return this.currentConnection.getCacheResultSetMetadata(); }
/*      */ 
/*      */ 
/*      */   
/*  855 */   public synchronized boolean getCacheServerConfiguration() { return this.currentConnection.getCacheServerConfiguration(); }
/*      */ 
/*      */ 
/*      */   
/*  859 */   public synchronized int getCallableStatementCacheSize() { return this.currentConnection.getCallableStatementCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/*  863 */   public synchronized int getCallableStmtCacheSize() { return this.currentConnection.getCallableStmtCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/*  867 */   public synchronized boolean getCapitalizeTypeNames() { return this.currentConnection.getCapitalizeTypeNames(); }
/*      */ 
/*      */ 
/*      */   
/*  871 */   public synchronized String getCharacterSetResults() { return this.currentConnection.getCharacterSetResults(); }
/*      */ 
/*      */ 
/*      */   
/*  875 */   public synchronized String getClientCertificateKeyStorePassword() { return this.currentConnection.getClientCertificateKeyStorePassword(); }
/*      */ 
/*      */ 
/*      */   
/*  879 */   public synchronized String getClientCertificateKeyStoreType() { return this.currentConnection.getClientCertificateKeyStoreType(); }
/*      */ 
/*      */ 
/*      */   
/*  883 */   public synchronized String getClientCertificateKeyStoreUrl() { return this.currentConnection.getClientCertificateKeyStoreUrl(); }
/*      */ 
/*      */ 
/*      */   
/*  887 */   public synchronized String getClientInfoProvider() { return this.currentConnection.getClientInfoProvider(); }
/*      */ 
/*      */ 
/*      */   
/*  891 */   public synchronized String getClobCharacterEncoding() { return this.currentConnection.getClobCharacterEncoding(); }
/*      */ 
/*      */ 
/*      */   
/*  895 */   public synchronized boolean getClobberStreamingResults() { return this.currentConnection.getClobberStreamingResults(); }
/*      */ 
/*      */ 
/*      */   
/*  899 */   public synchronized int getConnectTimeout() { return this.currentConnection.getConnectTimeout(); }
/*      */ 
/*      */ 
/*      */   
/*  903 */   public synchronized String getConnectionCollation() { return this.currentConnection.getConnectionCollation(); }
/*      */ 
/*      */ 
/*      */   
/*  907 */   public synchronized String getConnectionLifecycleInterceptors() { return this.currentConnection.getConnectionLifecycleInterceptors(); }
/*      */ 
/*      */ 
/*      */   
/*  911 */   public synchronized boolean getContinueBatchOnError() { return this.currentConnection.getContinueBatchOnError(); }
/*      */ 
/*      */ 
/*      */   
/*  915 */   public synchronized boolean getCreateDatabaseIfNotExist() { return this.currentConnection.getCreateDatabaseIfNotExist(); }
/*      */ 
/*      */ 
/*      */   
/*  919 */   public synchronized int getDefaultFetchSize() { return this.currentConnection.getDefaultFetchSize(); }
/*      */ 
/*      */ 
/*      */   
/*  923 */   public synchronized boolean getDontTrackOpenResources() { return this.currentConnection.getDontTrackOpenResources(); }
/*      */ 
/*      */ 
/*      */   
/*  927 */   public synchronized boolean getDumpMetadataOnColumnNotFound() { return this.currentConnection.getDumpMetadataOnColumnNotFound(); }
/*      */ 
/*      */ 
/*      */   
/*  931 */   public synchronized boolean getDumpQueriesOnException() { return this.currentConnection.getDumpQueriesOnException(); }
/*      */ 
/*      */ 
/*      */   
/*  935 */   public synchronized boolean getDynamicCalendars() { return this.currentConnection.getDynamicCalendars(); }
/*      */ 
/*      */ 
/*      */   
/*  939 */   public synchronized boolean getElideSetAutoCommits() { return this.currentConnection.getElideSetAutoCommits(); }
/*      */ 
/*      */ 
/*      */   
/*  943 */   public synchronized boolean getEmptyStringsConvertToZero() { return this.currentConnection.getEmptyStringsConvertToZero(); }
/*      */ 
/*      */ 
/*      */   
/*  947 */   public synchronized boolean getEmulateLocators() { return this.currentConnection.getEmulateLocators(); }
/*      */ 
/*      */ 
/*      */   
/*  951 */   public synchronized boolean getEmulateUnsupportedPstmts() { return this.currentConnection.getEmulateUnsupportedPstmts(); }
/*      */ 
/*      */ 
/*      */   
/*  955 */   public synchronized boolean getEnablePacketDebug() { return this.currentConnection.getEnablePacketDebug(); }
/*      */ 
/*      */ 
/*      */   
/*  959 */   public synchronized boolean getEnableQueryTimeouts() { return this.currentConnection.getEnableQueryTimeouts(); }
/*      */ 
/*      */ 
/*      */   
/*  963 */   public synchronized String getEncoding() { return this.currentConnection.getEncoding(); }
/*      */ 
/*      */ 
/*      */   
/*  967 */   public synchronized boolean getExplainSlowQueries() { return this.currentConnection.getExplainSlowQueries(); }
/*      */ 
/*      */ 
/*      */   
/*  971 */   public synchronized boolean getFailOverReadOnly() { return this.currentConnection.getFailOverReadOnly(); }
/*      */ 
/*      */ 
/*      */   
/*  975 */   public synchronized boolean getFunctionsNeverReturnBlobs() { return this.currentConnection.getFunctionsNeverReturnBlobs(); }
/*      */ 
/*      */ 
/*      */   
/*  979 */   public synchronized boolean getGatherPerfMetrics() { return this.currentConnection.getGatherPerfMetrics(); }
/*      */ 
/*      */ 
/*      */   
/*  983 */   public synchronized boolean getGatherPerformanceMetrics() { return this.currentConnection.getGatherPerformanceMetrics(); }
/*      */ 
/*      */ 
/*      */   
/*  987 */   public synchronized boolean getGenerateSimpleParameterMetadata() { return this.currentConnection.getGenerateSimpleParameterMetadata(); }
/*      */ 
/*      */ 
/*      */   
/*  991 */   public synchronized boolean getHoldResultsOpenOverStatementClose() { return this.currentConnection.getHoldResultsOpenOverStatementClose(); }
/*      */ 
/*      */ 
/*      */   
/*  995 */   public synchronized boolean getIgnoreNonTxTables() { return this.currentConnection.getIgnoreNonTxTables(); }
/*      */ 
/*      */ 
/*      */   
/*  999 */   public synchronized boolean getIncludeInnodbStatusInDeadlockExceptions() { return this.currentConnection.getIncludeInnodbStatusInDeadlockExceptions(); }
/*      */ 
/*      */ 
/*      */   
/* 1003 */   public synchronized int getInitialTimeout() { return this.currentConnection.getInitialTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 1007 */   public synchronized boolean getInteractiveClient() { return this.currentConnection.getInteractiveClient(); }
/*      */ 
/*      */ 
/*      */   
/* 1011 */   public synchronized boolean getIsInteractiveClient() { return this.currentConnection.getIsInteractiveClient(); }
/*      */ 
/*      */ 
/*      */   
/* 1015 */   public synchronized boolean getJdbcCompliantTruncation() { return this.currentConnection.getJdbcCompliantTruncation(); }
/*      */ 
/*      */ 
/*      */   
/* 1019 */   public synchronized boolean getJdbcCompliantTruncationForReads() { return this.currentConnection.getJdbcCompliantTruncationForReads(); }
/*      */ 
/*      */ 
/*      */   
/* 1023 */   public synchronized String getLargeRowSizeThreshold() { return this.currentConnection.getLargeRowSizeThreshold(); }
/*      */ 
/*      */ 
/*      */   
/* 1027 */   public synchronized String getLoadBalanceStrategy() { return this.currentConnection.getLoadBalanceStrategy(); }
/*      */ 
/*      */ 
/*      */   
/* 1031 */   public synchronized String getLocalSocketAddress() { return this.currentConnection.getLocalSocketAddress(); }
/*      */ 
/*      */ 
/*      */   
/* 1035 */   public synchronized int getLocatorFetchBufferSize() { return this.currentConnection.getLocatorFetchBufferSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1039 */   public synchronized boolean getLogSlowQueries() { return this.currentConnection.getLogSlowQueries(); }
/*      */ 
/*      */ 
/*      */   
/* 1043 */   public synchronized boolean getLogXaCommands() { return this.currentConnection.getLogXaCommands(); }
/*      */ 
/*      */ 
/*      */   
/* 1047 */   public synchronized String getLogger() { return this.currentConnection.getLogger(); }
/*      */ 
/*      */ 
/*      */   
/* 1051 */   public synchronized String getLoggerClassName() { return this.currentConnection.getLoggerClassName(); }
/*      */ 
/*      */ 
/*      */   
/* 1055 */   public synchronized boolean getMaintainTimeStats() { return this.currentConnection.getMaintainTimeStats(); }
/*      */ 
/*      */ 
/*      */   
/* 1059 */   public synchronized int getMaxQuerySizeToLog() { return this.currentConnection.getMaxQuerySizeToLog(); }
/*      */ 
/*      */ 
/*      */   
/* 1063 */   public synchronized int getMaxReconnects() { return this.currentConnection.getMaxReconnects(); }
/*      */ 
/*      */ 
/*      */   
/* 1067 */   public synchronized int getMaxRows() { return this.currentConnection.getMaxRows(); }
/*      */ 
/*      */ 
/*      */   
/* 1071 */   public synchronized int getMetadataCacheSize() { return this.currentConnection.getMetadataCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1075 */   public synchronized int getNetTimeoutForStreamingResults() { return this.currentConnection.getNetTimeoutForStreamingResults(); }
/*      */ 
/*      */ 
/*      */   
/* 1079 */   public synchronized boolean getNoAccessToProcedureBodies() { return this.currentConnection.getNoAccessToProcedureBodies(); }
/*      */ 
/*      */ 
/*      */   
/* 1083 */   public synchronized boolean getNoDatetimeStringSync() { return this.currentConnection.getNoDatetimeStringSync(); }
/*      */ 
/*      */ 
/*      */   
/* 1087 */   public synchronized boolean getNoTimezoneConversionForTimeType() { return this.currentConnection.getNoTimezoneConversionForTimeType(); }
/*      */ 
/*      */ 
/*      */   
/* 1091 */   public synchronized boolean getNullCatalogMeansCurrent() { return this.currentConnection.getNullCatalogMeansCurrent(); }
/*      */ 
/*      */ 
/*      */   
/* 1095 */   public synchronized boolean getNullNamePatternMatchesAll() { return this.currentConnection.getNullNamePatternMatchesAll(); }
/*      */ 
/*      */ 
/*      */   
/* 1099 */   public synchronized boolean getOverrideSupportsIntegrityEnhancementFacility() { return this.currentConnection.getOverrideSupportsIntegrityEnhancementFacility(); }
/*      */ 
/*      */ 
/*      */   
/* 1103 */   public synchronized int getPacketDebugBufferSize() { return this.currentConnection.getPacketDebugBufferSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1107 */   public synchronized boolean getPadCharsWithSpace() { return this.currentConnection.getPadCharsWithSpace(); }
/*      */ 
/*      */ 
/*      */   
/* 1111 */   public synchronized boolean getParanoid() { return this.currentConnection.getParanoid(); }
/*      */ 
/*      */ 
/*      */   
/* 1115 */   public synchronized boolean getPedantic() { return this.currentConnection.getPedantic(); }
/*      */ 
/*      */ 
/*      */   
/* 1119 */   public synchronized boolean getPinGlobalTxToPhysicalConnection() { return this.currentConnection.getPinGlobalTxToPhysicalConnection(); }
/*      */ 
/*      */ 
/*      */   
/* 1123 */   public synchronized boolean getPopulateInsertRowWithDefaultValues() { return this.currentConnection.getPopulateInsertRowWithDefaultValues(); }
/*      */ 
/*      */ 
/*      */   
/* 1127 */   public synchronized int getPrepStmtCacheSize() { return this.currentConnection.getPrepStmtCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1131 */   public synchronized int getPrepStmtCacheSqlLimit() { return this.currentConnection.getPrepStmtCacheSqlLimit(); }
/*      */ 
/*      */ 
/*      */   
/* 1135 */   public synchronized int getPreparedStatementCacheSize() { return this.currentConnection.getPreparedStatementCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1139 */   public synchronized int getPreparedStatementCacheSqlLimit() { return this.currentConnection.getPreparedStatementCacheSqlLimit(); }
/*      */ 
/*      */ 
/*      */   
/* 1143 */   public synchronized boolean getProcessEscapeCodesForPrepStmts() { return this.currentConnection.getProcessEscapeCodesForPrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1147 */   public synchronized boolean getProfileSQL() { return this.currentConnection.getProfileSQL(); }
/*      */ 
/*      */ 
/*      */   
/* 1151 */   public synchronized boolean getProfileSql() { return this.currentConnection.getProfileSql(); }
/*      */ 
/*      */ 
/*      */   
/* 1155 */   public synchronized String getProfilerEventHandler() { return this.currentConnection.getProfilerEventHandler(); }
/*      */ 
/*      */ 
/*      */   
/* 1159 */   public synchronized String getPropertiesTransform() { return this.currentConnection.getPropertiesTransform(); }
/*      */ 
/*      */ 
/*      */   
/* 1163 */   public synchronized int getQueriesBeforeRetryMaster() { return this.currentConnection.getQueriesBeforeRetryMaster(); }
/*      */ 
/*      */ 
/*      */   
/* 1167 */   public synchronized boolean getReconnectAtTxEnd() { return this.currentConnection.getReconnectAtTxEnd(); }
/*      */ 
/*      */ 
/*      */   
/* 1171 */   public synchronized boolean getRelaxAutoCommit() { return this.currentConnection.getRelaxAutoCommit(); }
/*      */ 
/*      */ 
/*      */   
/* 1175 */   public synchronized int getReportMetricsIntervalMillis() { return this.currentConnection.getReportMetricsIntervalMillis(); }
/*      */ 
/*      */ 
/*      */   
/* 1179 */   public synchronized boolean getRequireSSL() { return this.currentConnection.getRequireSSL(); }
/*      */ 
/*      */ 
/*      */   
/* 1183 */   public synchronized String getResourceId() { return this.currentConnection.getResourceId(); }
/*      */ 
/*      */ 
/*      */   
/* 1187 */   public synchronized int getResultSetSizeThreshold() { return this.currentConnection.getResultSetSizeThreshold(); }
/*      */ 
/*      */ 
/*      */   
/* 1191 */   public synchronized boolean getRewriteBatchedStatements() { return this.currentConnection.getRewriteBatchedStatements(); }
/*      */ 
/*      */ 
/*      */   
/* 1195 */   public synchronized boolean getRollbackOnPooledClose() { return this.currentConnection.getRollbackOnPooledClose(); }
/*      */ 
/*      */ 
/*      */   
/* 1199 */   public synchronized boolean getRoundRobinLoadBalance() { return this.currentConnection.getRoundRobinLoadBalance(); }
/*      */ 
/*      */ 
/*      */   
/* 1203 */   public synchronized boolean getRunningCTS13() { return this.currentConnection.getRunningCTS13(); }
/*      */ 
/*      */ 
/*      */   
/* 1207 */   public synchronized int getSecondsBeforeRetryMaster() { return this.currentConnection.getSecondsBeforeRetryMaster(); }
/*      */ 
/*      */ 
/*      */   
/* 1211 */   public synchronized int getSelfDestructOnPingMaxOperations() { return this.currentConnection.getSelfDestructOnPingMaxOperations(); }
/*      */ 
/*      */ 
/*      */   
/* 1215 */   public synchronized int getSelfDestructOnPingSecondsLifetime() { return this.currentConnection.getSelfDestructOnPingSecondsLifetime(); }
/*      */ 
/*      */ 
/*      */   
/* 1219 */   public synchronized String getServerTimezone() { return this.currentConnection.getServerTimezone(); }
/*      */ 
/*      */ 
/*      */   
/* 1223 */   public synchronized String getSessionVariables() { return this.currentConnection.getSessionVariables(); }
/*      */ 
/*      */ 
/*      */   
/* 1227 */   public synchronized int getSlowQueryThresholdMillis() { return this.currentConnection.getSlowQueryThresholdMillis(); }
/*      */ 
/*      */ 
/*      */   
/* 1231 */   public synchronized long getSlowQueryThresholdNanos() { return this.currentConnection.getSlowQueryThresholdNanos(); }
/*      */ 
/*      */ 
/*      */   
/* 1235 */   public synchronized String getSocketFactory() { return this.currentConnection.getSocketFactory(); }
/*      */ 
/*      */ 
/*      */   
/* 1239 */   public synchronized String getSocketFactoryClassName() { return this.currentConnection.getSocketFactoryClassName(); }
/*      */ 
/*      */ 
/*      */   
/* 1243 */   public synchronized int getSocketTimeout() { return this.currentConnection.getSocketTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 1247 */   public synchronized String getStatementInterceptors() { return this.currentConnection.getStatementInterceptors(); }
/*      */ 
/*      */ 
/*      */   
/* 1251 */   public synchronized boolean getStrictFloatingPoint() { return this.currentConnection.getStrictFloatingPoint(); }
/*      */ 
/*      */ 
/*      */   
/* 1255 */   public synchronized boolean getStrictUpdates() { return this.currentConnection.getStrictUpdates(); }
/*      */ 
/*      */ 
/*      */   
/* 1259 */   public synchronized boolean getTcpKeepAlive() { return this.currentConnection.getTcpKeepAlive(); }
/*      */ 
/*      */ 
/*      */   
/* 1263 */   public synchronized boolean getTcpNoDelay() { return this.currentConnection.getTcpNoDelay(); }
/*      */ 
/*      */ 
/*      */   
/* 1267 */   public synchronized int getTcpRcvBuf() { return this.currentConnection.getTcpRcvBuf(); }
/*      */ 
/*      */ 
/*      */   
/* 1271 */   public synchronized int getTcpSndBuf() { return this.currentConnection.getTcpSndBuf(); }
/*      */ 
/*      */ 
/*      */   
/* 1275 */   public synchronized int getTcpTrafficClass() { return this.currentConnection.getTcpTrafficClass(); }
/*      */ 
/*      */ 
/*      */   
/* 1279 */   public synchronized boolean getTinyInt1isBit() { return this.currentConnection.getTinyInt1isBit(); }
/*      */ 
/*      */ 
/*      */   
/* 1283 */   public synchronized boolean getTraceProtocol() { return this.currentConnection.getTraceProtocol(); }
/*      */ 
/*      */ 
/*      */   
/* 1287 */   public synchronized boolean getTransformedBitIsBoolean() { return this.currentConnection.getTransformedBitIsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 1291 */   public synchronized boolean getTreatUtilDateAsTimestamp() { return this.currentConnection.getTreatUtilDateAsTimestamp(); }
/*      */ 
/*      */ 
/*      */   
/* 1295 */   public synchronized String getTrustCertificateKeyStorePassword() { return this.currentConnection.getTrustCertificateKeyStorePassword(); }
/*      */ 
/*      */ 
/*      */   
/* 1299 */   public synchronized String getTrustCertificateKeyStoreType() { return this.currentConnection.getTrustCertificateKeyStoreType(); }
/*      */ 
/*      */ 
/*      */   
/* 1303 */   public synchronized String getTrustCertificateKeyStoreUrl() { return this.currentConnection.getTrustCertificateKeyStoreUrl(); }
/*      */ 
/*      */ 
/*      */   
/* 1307 */   public synchronized boolean getUltraDevHack() { return this.currentConnection.getUltraDevHack(); }
/*      */ 
/*      */ 
/*      */   
/* 1311 */   public synchronized boolean getUseBlobToStoreUTF8OutsideBMP() { return this.currentConnection.getUseBlobToStoreUTF8OutsideBMP(); }
/*      */ 
/*      */ 
/*      */   
/* 1315 */   public synchronized boolean getUseCompression() { return this.currentConnection.getUseCompression(); }
/*      */ 
/*      */ 
/*      */   
/* 1319 */   public synchronized String getUseConfigs() { return this.currentConnection.getUseConfigs(); }
/*      */ 
/*      */ 
/*      */   
/* 1323 */   public synchronized boolean getUseCursorFetch() { return this.currentConnection.getUseCursorFetch(); }
/*      */ 
/*      */ 
/*      */   
/* 1327 */   public synchronized boolean getUseDirectRowUnpack() { return this.currentConnection.getUseDirectRowUnpack(); }
/*      */ 
/*      */ 
/*      */   
/* 1331 */   public synchronized boolean getUseDynamicCharsetInfo() { return this.currentConnection.getUseDynamicCharsetInfo(); }
/*      */ 
/*      */ 
/*      */   
/* 1335 */   public synchronized boolean getUseFastDateParsing() { return this.currentConnection.getUseFastDateParsing(); }
/*      */ 
/*      */ 
/*      */   
/* 1339 */   public synchronized boolean getUseFastIntParsing() { return this.currentConnection.getUseFastIntParsing(); }
/*      */ 
/*      */ 
/*      */   
/* 1343 */   public synchronized boolean getUseGmtMillisForDatetimes() { return this.currentConnection.getUseGmtMillisForDatetimes(); }
/*      */ 
/*      */ 
/*      */   
/* 1347 */   public synchronized boolean getUseHostsInPrivileges() { return this.currentConnection.getUseHostsInPrivileges(); }
/*      */ 
/*      */ 
/*      */   
/* 1351 */   public synchronized boolean getUseInformationSchema() { return this.currentConnection.getUseInformationSchema(); }
/*      */ 
/*      */ 
/*      */   
/* 1355 */   public synchronized boolean getUseJDBCCompliantTimezoneShift() { return this.currentConnection.getUseJDBCCompliantTimezoneShift(); }
/*      */ 
/*      */ 
/*      */   
/* 1359 */   public synchronized boolean getUseJvmCharsetConverters() { return this.currentConnection.getUseJvmCharsetConverters(); }
/*      */ 
/*      */ 
/*      */   
/* 1363 */   public synchronized boolean getUseLegacyDatetimeCode() { return this.currentConnection.getUseLegacyDatetimeCode(); }
/*      */ 
/*      */ 
/*      */   
/* 1367 */   public synchronized boolean getUseLocalSessionState() { return this.currentConnection.getUseLocalSessionState(); }
/*      */ 
/*      */ 
/*      */   
/* 1371 */   public synchronized boolean getUseNanosForElapsedTime() { return this.currentConnection.getUseNanosForElapsedTime(); }
/*      */ 
/*      */ 
/*      */   
/* 1375 */   public synchronized boolean getUseOldAliasMetadataBehavior() { return this.currentConnection.getUseOldAliasMetadataBehavior(); }
/*      */ 
/*      */ 
/*      */   
/* 1379 */   public synchronized boolean getUseOldUTF8Behavior() { return this.currentConnection.getUseOldUTF8Behavior(); }
/*      */ 
/*      */ 
/*      */   
/* 1383 */   public synchronized boolean getUseOnlyServerErrorMessages() { return this.currentConnection.getUseOnlyServerErrorMessages(); }
/*      */ 
/*      */ 
/*      */   
/* 1387 */   public synchronized boolean getUseReadAheadInput() { return this.currentConnection.getUseReadAheadInput(); }
/*      */ 
/*      */ 
/*      */   
/* 1391 */   public synchronized boolean getUseSSL() { return this.currentConnection.getUseSSL(); }
/*      */ 
/*      */ 
/*      */   
/* 1395 */   public synchronized boolean getUseSSPSCompatibleTimezoneShift() { return this.currentConnection.getUseSSPSCompatibleTimezoneShift(); }
/*      */ 
/*      */ 
/*      */   
/* 1399 */   public synchronized boolean getUseServerPrepStmts() { return this.currentConnection.getUseServerPrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1403 */   public synchronized boolean getUseServerPreparedStmts() { return this.currentConnection.getUseServerPreparedStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1407 */   public synchronized boolean getUseSqlStateCodes() { return this.currentConnection.getUseSqlStateCodes(); }
/*      */ 
/*      */ 
/*      */   
/* 1411 */   public synchronized boolean getUseStreamLengthsInPrepStmts() { return this.currentConnection.getUseStreamLengthsInPrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1415 */   public synchronized boolean getUseTimezone() { return this.currentConnection.getUseTimezone(); }
/*      */ 
/*      */ 
/*      */   
/* 1419 */   public synchronized boolean getUseUltraDevWorkAround() { return this.currentConnection.getUseUltraDevWorkAround(); }
/*      */ 
/*      */ 
/*      */   
/* 1423 */   public synchronized boolean getUseUnbufferedInput() { return this.currentConnection.getUseUnbufferedInput(); }
/*      */ 
/*      */ 
/*      */   
/* 1427 */   public synchronized boolean getUseUnicode() { return this.currentConnection.getUseUnicode(); }
/*      */ 
/*      */ 
/*      */   
/* 1431 */   public synchronized boolean getUseUsageAdvisor() { return this.currentConnection.getUseUsageAdvisor(); }
/*      */ 
/*      */ 
/*      */   
/* 1435 */   public synchronized String getUtf8OutsideBmpExcludedColumnNamePattern() { return this.currentConnection.getUtf8OutsideBmpExcludedColumnNamePattern(); }
/*      */ 
/*      */ 
/*      */   
/* 1439 */   public synchronized String getUtf8OutsideBmpIncludedColumnNamePattern() { return this.currentConnection.getUtf8OutsideBmpIncludedColumnNamePattern(); }
/*      */ 
/*      */ 
/*      */   
/* 1443 */   public synchronized boolean getVerifyServerCertificate() { return this.currentConnection.getVerifyServerCertificate(); }
/*      */ 
/*      */ 
/*      */   
/* 1447 */   public synchronized boolean getYearIsDateType() { return this.currentConnection.getYearIsDateType(); }
/*      */ 
/*      */ 
/*      */   
/* 1451 */   public synchronized String getZeroDateTimeBehavior() { return this.currentConnection.getZeroDateTimeBehavior(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAllowLoadLocalInfile(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAllowMultiQueries(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAllowNanAndInf(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAllowUrlInLocalInfile(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAlwaysSendSetIsolation(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoClosePStmtStreams(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoDeserialize(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoGenerateTestcaseScript(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoReconnect(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoReconnectForConnectionPools(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoReconnectForPools(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setAutoSlowLog(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setBlobSendChunkSize(String value) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setBlobsAreStrings(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCacheCallableStatements(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCacheCallableStmts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCachePrepStmts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCachePreparedStatements(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCacheResultSetMetadata(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCacheServerConfiguration(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCallableStatementCacheSize(int size) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCallableStmtCacheSize(int cacheSize) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCapitalizeDBMDTypes(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCapitalizeTypeNames(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCharacterEncoding(String encoding) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCharacterSetResults(String characterSet) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setClientCertificateKeyStorePassword(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setClientCertificateKeyStoreType(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setClientCertificateKeyStoreUrl(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setClientInfoProvider(String classname) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setClobCharacterEncoding(String encoding) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setClobberStreamingResults(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnectTimeout(int timeoutMs) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnectionCollation(String collation) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setConnectionLifecycleInterceptors(String interceptors) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setContinueBatchOnError(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setCreateDatabaseIfNotExist(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDefaultFetchSize(int n) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDetectServerPreparedStmts(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDontTrackOpenResources(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDumpMetadataOnColumnNotFound(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDumpQueriesOnException(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setDynamicCalendars(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setElideSetAutoCommits(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setEmptyStringsConvertToZero(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setEmulateLocators(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setEmulateUnsupportedPstmts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setEnablePacketDebug(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setEnableQueryTimeouts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setEncoding(String property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setExplainSlowQueries(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setFailOverReadOnly(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setFunctionsNeverReturnBlobs(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setGatherPerfMetrics(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setGatherPerformanceMetrics(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setGenerateSimpleParameterMetadata(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setHoldResultsOpenOverStatementClose(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setIgnoreNonTxTables(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setInitialTimeout(int property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setInteractiveClient(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setIsInteractiveClient(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setJdbcCompliantTruncation(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLargeRowSizeThreshold(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLoadBalanceStrategy(String strategy) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLocalSocketAddress(String address) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLocatorFetchBufferSize(String value) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLogSlowQueries(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLogXaCommands(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLogger(String property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLoggerClassName(String className) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaintainTimeStats(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxQuerySizeToLog(int sizeInBytes) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxReconnects(int property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMaxRows(int property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setMetadataCacheSize(int value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNetTimeoutForStreamingResults(int value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNoAccessToProcedureBodies(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNoDatetimeStringSync(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNoTimezoneConversionForTimeType(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNullCatalogMeansCurrent(boolean value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setNullNamePatternMatchesAll(boolean value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPacketDebugBufferSize(int size) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPadCharsWithSpace(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setParanoid(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPedantic(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPinGlobalTxToPhysicalConnection(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPopulateInsertRowWithDefaultValues(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPrepStmtCacheSize(int cacheSize) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPrepStmtCacheSqlLimit(int sqlLimit) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPreparedStatementCacheSize(int cacheSize) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setProcessEscapeCodesForPrepStmts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setProfileSQL(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setProfileSql(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setProfilerEventHandler(String handler) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setPropertiesTransform(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setQueriesBeforeRetryMaster(int property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setReconnectAtTxEnd(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRelaxAutoCommit(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setReportMetricsIntervalMillis(int millis) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRequireSSL(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setResourceId(String resourceId) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setResultSetSizeThreshold(int threshold) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRetainStatementAfterResultSetClose(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRewriteBatchedStatements(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRollbackOnPooledClose(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRoundRobinLoadBalance(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setRunningCTS13(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSecondsBeforeRetryMaster(int property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSelfDestructOnPingMaxOperations(int maxOperations) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSelfDestructOnPingSecondsLifetime(int seconds) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setServerTimezone(String property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSessionVariables(String variables) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSlowQueryThresholdMillis(int millis) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSlowQueryThresholdNanos(long nanos) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSocketFactory(String name) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSocketFactoryClassName(String property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setSocketTimeout(int property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setStatementInterceptors(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setStrictFloatingPoint(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setStrictUpdates(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTcpKeepAlive(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTcpNoDelay(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTcpRcvBuf(int bufSize) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTcpSndBuf(int bufSize) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTcpTrafficClass(int classFlags) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTinyInt1isBit(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTraceProtocol(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTransformedBitIsBoolean(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTreatUtilDateAsTimestamp(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTrustCertificateKeyStorePassword(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTrustCertificateKeyStoreType(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setTrustCertificateKeyStoreUrl(String value) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUltraDevHack(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseBlobToStoreUTF8OutsideBMP(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseCompression(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseConfigs(String configs) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseCursorFetch(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseDirectRowUnpack(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseDynamicCharsetInfo(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseFastDateParsing(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseFastIntParsing(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseGmtMillisForDatetimes(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseHostsInPrivileges(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseInformationSchema(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseJDBCCompliantTimezoneShift(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseJvmCharsetConverters(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseLegacyDatetimeCode(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseLocalSessionState(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseNanosForElapsedTime(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseOldAliasMetadataBehavior(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseOldUTF8Behavior(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseOnlyServerErrorMessages(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseReadAheadInput(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseSSL(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseSSPSCompatibleTimezoneShift(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseServerPrepStmts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseServerPreparedStmts(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseSqlStateCodes(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseStreamLengthsInPrepStmts(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseTimezone(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseUltraDevWorkAround(boolean property) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseUnbufferedInput(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseUnicode(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUseUsageAdvisor(boolean useUsageAdvisorFlag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setVerifyServerCertificate(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setYearIsDateType(boolean flag) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setZeroDateTimeBehavior(String behavior) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2321 */   public synchronized boolean useUnbufferedInput() { return this.currentConnection.useUnbufferedInput(); }
/*      */ 
/*      */ 
/*      */   
/* 2325 */   public synchronized boolean isSameResource(Connection c) { return this.currentConnection.isSameResource(c); }
/*      */ 
/*      */ 
/*      */   
/* 2329 */   public void setInGlobalTx(boolean flag) { this.currentConnection.setInGlobalTx(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2333 */   public boolean getUseColumnNamesInFindColumn() { return this.currentConnection.getUseColumnNamesInFindColumn(); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseColumnNamesInFindColumn(boolean flag) {}
/*      */ 
/*      */ 
/*      */   
/* 2341 */   public boolean getUseLocalTransactionState() { return this.currentConnection.getUseLocalTransactionState(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseLocalTransactionState(boolean flag) {}
/*      */ 
/*      */ 
/*      */   
/* 2350 */   public boolean getCompensateOnDuplicateKeyUpdateCounts() { return this.currentConnection.getCompensateOnDuplicateKeyUpdateCounts(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) {}
/*      */ 
/*      */ 
/*      */   
/* 2359 */   public boolean getUseAffectedRows() { return this.currentConnection.getUseAffectedRows(); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUseAffectedRows(boolean flag) {}
/*      */ 
/*      */ 
/*      */   
/* 2368 */   public String getPasswordCharacterEncoding() { return this.currentConnection.getPasswordCharacterEncoding(); }
/*      */ 
/*      */ 
/*      */   
/* 2372 */   public void setPasswordCharacterEncoding(String characterSet) { this.currentConnection.setPasswordCharacterEncoding(characterSet); }
/*      */ 
/*      */ 
/*      */   
/* 2376 */   public int getAutoIncrementIncrement() { return this.currentConnection.getAutoIncrementIncrement(); }
/*      */ 
/*      */ 
/*      */   
/* 2380 */   public int getLoadBalanceBlacklistTimeout() { return this.currentConnection.getLoadBalanceBlacklistTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 2384 */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) { this.currentConnection.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout); }
/*      */ 
/*      */ 
/*      */   
/* 2388 */   public int getRetriesAllDown() { return this.currentConnection.getRetriesAllDown(); }
/*      */ 
/*      */ 
/*      */   
/* 2392 */   public void setRetriesAllDown(int retriesAllDown) { this.currentConnection.setRetriesAllDown(retriesAllDown); }
/*      */ 
/*      */ 
/*      */   
/* 2396 */   public ExceptionInterceptor getExceptionInterceptor() { return this.currentConnection.getExceptionInterceptor(); }
/*      */ 
/*      */ 
/*      */   
/* 2400 */   public String getExceptionInterceptors() { return this.currentConnection.getExceptionInterceptors(); }
/*      */ 
/*      */ 
/*      */   
/* 2404 */   public void setExceptionInterceptors(String exceptionInterceptors) { this.currentConnection.setExceptionInterceptors(exceptionInterceptors); }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/ReplicationConnection.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */