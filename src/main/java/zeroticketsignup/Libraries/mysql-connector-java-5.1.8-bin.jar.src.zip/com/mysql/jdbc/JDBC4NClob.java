/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.NClob;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JDBC4NClob
/*    */   extends Clob
/*    */   implements NClob
/*    */ {
/* 38 */   JDBC4NClob(ExceptionInterceptor exceptionInterceptor) { super(exceptionInterceptor); }
/*    */ 
/*    */ 
/*    */   
/* 42 */   JDBC4NClob(String charDataInit, ExceptionInterceptor exceptionInterceptor) { super(charDataInit, exceptionInterceptor); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/JDBC4NClob.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */