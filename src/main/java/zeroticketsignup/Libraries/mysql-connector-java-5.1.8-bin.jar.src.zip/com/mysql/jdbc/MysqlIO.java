/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandlerFactory;
/*      */ import com.mysql.jdbc.util.ReadAheadInputStream;
/*      */ import com.mysql.jdbc.util.ResultSetUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketException;
/*      */ import java.net.URL;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.zip.Deflater;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class MysqlIO
/*      */ {
/*      */   private static final int UTF8_CHARSET_INDEX = 33;
/*      */   private static final String CODE_PAGE_1252 = "Cp1252";
/*      */   protected static final int NULL_LENGTH = -1;
/*      */   protected static final int COMP_HEADER_LENGTH = 3;
/*      */   protected static final int MIN_COMPRESS_LEN = 50;
/*      */   protected static final int HEADER_LENGTH = 4;
/*      */   protected static final int AUTH_411_OVERHEAD = 33;
/*   78 */   private static int maxBufferSize = 65535;
/*      */   
/*      */   private static final int CLIENT_COMPRESS = 32;
/*      */   
/*      */   protected static final int CLIENT_CONNECT_WITH_DB = 8;
/*      */   
/*      */   private static final int CLIENT_FOUND_ROWS = 2;
/*      */   
/*      */   private static final int CLIENT_LOCAL_FILES = 128;
/*      */   
/*      */   private static final int CLIENT_LONG_FLAG = 4;
/*      */   
/*      */   private static final int CLIENT_LONG_PASSWORD = 1;
/*      */   
/*      */   private static final int CLIENT_PROTOCOL_41 = 512;
/*      */   
/*      */   private static final int CLIENT_INTERACTIVE = 1024;
/*      */   
/*      */   protected static final int CLIENT_SSL = 2048;
/*      */   
/*      */   private static final int CLIENT_TRANSACTIONS = 8192;
/*      */   protected static final int CLIENT_RESERVED = 16384;
/*      */   protected static final int CLIENT_SECURE_CONNECTION = 32768;
/*      */   private static final int CLIENT_MULTI_QUERIES = 65536;
/*      */   private static final int CLIENT_MULTI_RESULTS = 131072;
/*      */   private static final int SERVER_STATUS_IN_TRANS = 1;
/*      */   private static final int SERVER_STATUS_AUTOCOMMIT = 2;
/*      */   static final int SERVER_MORE_RESULTS_EXISTS = 8;
/*      */   private static final int SERVER_QUERY_NO_GOOD_INDEX_USED = 16;
/*      */   private static final int SERVER_QUERY_NO_INDEX_USED = 32;
/*      */   private static final int SERVER_QUERY_WAS_SLOW = 2048;
/*      */   private static final int SERVER_STATUS_CURSOR_EXISTS = 64;
/*      */   private static final String FALSE_SCRAMBLE = "xxxxxxxx";
/*      */   protected static final int MAX_QUERY_SIZE_TO_LOG = 1024;
/*      */   protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
/*      */   protected static final int INITIAL_PACKET_SIZE = 1024;
/*  114 */   private static String jvmPlatformCharset = null; protected static final String ZERO_DATE_VALUE_MARKER = "0000-00-00"; protected static final String ZERO_DATETIME_VALUE_MARKER = "0000-00-00 00:00:00"; private static final int MAX_PACKET_DUMP_LENGTH = 1024; private boolean packetSequenceReset; protected int serverCharsetIndex; private Buffer reusablePacket; private Buffer sendPacket; private Buffer sharedSendPacket; protected BufferedOutputStream mysqlOutput; protected ConnectionImpl connection; private Deflater deflater; protected InputStream mysqlInput; private LinkedList packetDebugRingBuffer; private RowData streamingData; protected Socket mysqlConnection; private SocketFactory socketFactory; private SoftReference loadFileBufRef; private SoftReference splitBufRef; protected String host; protected String seed; private String serverVersion; private String socketFactoryClassName; private byte[] packetHeaderBuf; private boolean colDecimalNeedsBump; private boolean hadWarnings; private boolean has41NewNewProt; private boolean hasLongColumnInfo; private boolean isInteractiveClient; private boolean logSlowQueries; private boolean platformDbCharsetMatches; private boolean profileSql; private boolean queryBadIndexUsed; private boolean queryNoIndexUsed; private boolean serverQueryWasSlow; private boolean use41Extensions; private boolean useCompression; private boolean useNewLargePackets; private boolean useNewUpdateCounts; private byte packetSequence; private byte readPacketSequence; private boolean checkPacketSequence; private byte protocolVersion; private int maxAllowedPacket; protected int maxThreeBytes; protected int port; protected int serverCapabilities; private int serverMajorVersion; private int serverMinorVersion; private int oldServerStatus; private int serverStatus; private int serverSubMinorVersion; private int warningCount; protected long clientParam; protected long lastPacketSentTimeMs; protected long lastPacketReceivedTimeMs; private boolean traceProtocol; private boolean enablePacketDebug; private Calendar sessionCalendar; private boolean useConnectWithDb; private boolean needToGrabQueryFromPacket; private boolean autoGenerateTestcaseScript; private long threadId; private boolean useNanosForElapsedTime; private long slowQueryThreshold;
/*      */   private String queryTimingUnits;
/*      */   private boolean useDirectRowUnpack;
/*      */   private int useBufferRowSizeThreshold;
/*      */   private int commandCount;
/*      */   private List statementInterceptors;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   private int statementExecutionDepth;
/*      */   private boolean useAutoSlowLog;
/*      */   
/*  124 */   static  { OutputStreamWriter outWriter = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  132 */     try { outWriter = new OutputStreamWriter(new ByteArrayOutputStream());
/*  133 */       jvmPlatformCharset = outWriter.getEncoding(); }
/*      */     finally
/*      */     { try {
/*  136 */         if (outWriter != null) {
/*  137 */           outWriter.close();
/*      */         }
/*  139 */       } catch (IOException ioEx) {} }  } public boolean hasLongColumnInfo() { return this.hasLongColumnInfo; } protected boolean isDataAvailable() throws SQLException { try { return (this.mysqlInput.available() > 0); } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); }  } protected long getLastPacketSentTimeMs() { return this.lastPacketSentTimeMs; } protected long getLastPacketReceivedTimeMs() { return this.lastPacketReceivedTimeMs; }
/*      */   protected ResultSetImpl getResultSet(StatementImpl callingStatement, long columnCount, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean isBinaryEncoded, Field[] metadataFromCache) throws SQLException { Field[] fields = null; if (metadataFromCache == null) { fields = new Field[(int)columnCount]; for (int i = 0; i < columnCount; i++) { Buffer fieldPacket = null; fieldPacket = readPacket(); fields[i] = unpackField(fieldPacket, false); }  } else { for (int i = 0; i < columnCount; i++) skipPacket();  }  Buffer packet = reuseAndReadPacket(this.reusablePacket); readServerStatusForResultSets(packet); if (this.connection.versionMeetsMinimum(5, 0, 2) && this.connection.getUseCursorFetch() && isBinaryEncoded && callingStatement != null && callingStatement.getFetchSize() != 0 && callingStatement.getResultSetType() == 1003) { ServerPreparedStatement prepStmt = (ServerPreparedStatement)callingStatement; boolean usingCursor = true; if (this.connection.versionMeetsMinimum(5, 0, 5)) usingCursor = ((this.serverStatus & 0x40) != 0);  if (usingCursor) { RowData rows = new RowDataCursor(this, prepStmt, fields); ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, fields, rows, resultSetType, resultSetConcurrency, isBinaryEncoded); if (usingCursor) rs.setFetchSize(callingStatement.getFetchSize());  return rs; }  }  RowData rowData = null; if (!streamResults) { rowData = readSingleRowSet(columnCount, maxRows, resultSetConcurrency, isBinaryEncoded, (metadataFromCache == null) ? fields : metadataFromCache); } else { rowData = new RowDataDynamic(this, (int)columnCount, (metadataFromCache == null) ? fields : metadataFromCache, isBinaryEncoded); this.streamingData = rowData; }  ResultSetImpl rs = buildResultSetWithRows(callingStatement, catalog, (metadataFromCache == null) ? fields : metadataFromCache, rowData, resultSetType, resultSetConcurrency, isBinaryEncoded); return rs; }
/*      */   protected final void forceClose() { try { if (this.mysqlInput != null) this.mysqlInput.close();  } catch (IOException ioEx) { this.mysqlInput = null; }  try { if (this.mysqlOutput != null) this.mysqlOutput.close();  } catch (IOException ioEx) { this.mysqlOutput = null; }  try { if (this.mysqlConnection != null) this.mysqlConnection.close();  } catch (IOException ioEx) { this.mysqlConnection = null; }  }
/*      */   protected final void skipPacket() throws SQLException { try { int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4); if (lengthRead < 4) { forceClose(); throw new IOException(Messages.getString("MysqlIO.1")); }  int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16); if (this.traceProtocol) { StringBuffer traceMessageBuf = new StringBuffer(); traceMessageBuf.append(Messages.getString("MysqlIO.2")); traceMessageBuf.append(packetLength); traceMessageBuf.append(Messages.getString("MysqlIO.3")); traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4)); this.connection.getLog().logTrace(traceMessageBuf.toString()); }  byte multiPacketSeq = this.packetHeaderBuf[3]; if (!this.packetSequenceReset) { if (this.enablePacketDebug && this.checkPacketSequence) checkPacketSequencing(multiPacketSeq);  } else { this.packetSequenceReset = false; }  this.readPacketSequence = multiPacketSeq; skipFully(this.mysqlInput, packetLength); } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); } catch (OutOfMemoryError oom) { try { this.connection.realClose(false, false, true, oom); throw oom; } finally { Exception exception = null; }  }  }
/*      */   protected final Buffer readPacket() throws SQLException { try { int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4); if (lengthRead < 4) { forceClose(); throw new IOException(Messages.getString("MysqlIO.1")); }  int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16); if (packetLength > this.maxAllowedPacket) throw new PacketTooBigException(packetLength, this.maxAllowedPacket);  if (this.traceProtocol) { StringBuffer traceMessageBuf = new StringBuffer(); traceMessageBuf.append(Messages.getString("MysqlIO.2")); traceMessageBuf.append(packetLength); traceMessageBuf.append(Messages.getString("MysqlIO.3")); traceMessageBuf.append(StringUtils.dumpAsHex(this.packetHeaderBuf, 4)); this.connection.getLog().logTrace(traceMessageBuf.toString()); }  byte multiPacketSeq = this.packetHeaderBuf[3]; if (!this.packetSequenceReset) { if (this.enablePacketDebug && this.checkPacketSequence) checkPacketSequencing(multiPacketSeq);  } else { this.packetSequenceReset = false; }  this.readPacketSequence = multiPacketSeq; byte[] buffer = new byte[packetLength + 1]; int numBytesRead = readFully(this.mysqlInput, buffer, 0, packetLength); if (numBytesRead != packetLength) throw new IOException("Short read, expected " + packetLength + " bytes, only read " + numBytesRead);  buffer[packetLength] = 0; Buffer packet = new Buffer(buffer); packet.setBufLength(packetLength + 1); if (this.traceProtocol) { StringBuffer traceMessageBuf = new StringBuffer(); traceMessageBuf.append(Messages.getString("MysqlIO.4")); traceMessageBuf.append(getPacketDumpToLog(packet, packetLength)); this.connection.getLog().logTrace(traceMessageBuf.toString()); }  if (this.enablePacketDebug) enqueuePacketForDebugging(false, false, 0, this.packetHeaderBuf, packet);  if (this.connection.getMaintainTimeStats())
/*      */         this.lastPacketReceivedTimeMs = System.currentTimeMillis();  return packet; } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); } catch (OutOfMemoryError oom) { try { this.connection.realClose(false, false, true, oom); throw oom; } finally { Exception exception = null; }  }  }
/*      */   protected final Field unpackField(Buffer packet, boolean extractDefaultValues) throws SQLException { if (this.use41Extensions) { if (this.has41NewNewProt) { int catalogNameStart = packet.getPosition() + 1; int catalogNameLength = packet.fastSkipLenString(); catalogNameStart = adjustStartForFieldLength(catalogNameStart, catalogNameLength); }  int databaseNameStart = packet.getPosition() + 1; int databaseNameLength = packet.fastSkipLenString(); databaseNameStart = adjustStartForFieldLength(databaseNameStart, databaseNameLength); int tableNameStart = packet.getPosition() + 1; int tableNameLength = packet.fastSkipLenString(); tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength); int originalTableNameStart = packet.getPosition() + 1; int originalTableNameLength = packet.fastSkipLenString(); originalTableNameStart = adjustStartForFieldLength(originalTableNameStart, originalTableNameLength); int nameStart = packet.getPosition() + 1; int nameLength = packet.fastSkipLenString(); nameStart = adjustStartForFieldLength(nameStart, nameLength); int originalColumnNameStart = packet.getPosition() + 1; int originalColumnNameLength = packet.fastSkipLenString(); originalColumnNameStart = adjustStartForFieldLength(originalColumnNameStart, originalColumnNameLength); packet.readByte(); short charSetNumber = (short)packet.readInt(); long colLength = 0L; if (this.has41NewNewProt) { colLength = packet.readLong(); } else { colLength = packet.readLongInt(); }  int colType = packet.readByte() & 0xFF; short colFlag = 0; if (this.hasLongColumnInfo) { colFlag = (short)packet.readInt(); } else { colFlag = (short)(packet.readByte() & 0xFF); }  int colDecimals = packet.readByte() & 0xFF; int defaultValueStart = -1; int defaultValueLength = -1; if (extractDefaultValues) { defaultValueStart = packet.getPosition() + 1; defaultValueLength = packet.fastSkipLenString(); }  Field field = new Field(this.connection, packet.getByteBuffer(), databaseNameStart, databaseNameLength, tableNameStart, tableNameLength, originalTableNameStart, originalTableNameLength, nameStart, nameLength, originalColumnNameStart, originalColumnNameLength, colLength, colType, colFlag, colDecimals, defaultValueStart, defaultValueLength, charSetNumber); return field; }  int tableNameStart = packet.getPosition() + 1; int tableNameLength = packet.fastSkipLenString(); tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength); int nameStart = packet.getPosition() + 1; int nameLength = packet.fastSkipLenString(); nameStart = adjustStartForFieldLength(nameStart, nameLength); int colLength = packet.readnBytes(); int colType = packet.readnBytes(); packet.readByte(); short colFlag = 0; if (this.hasLongColumnInfo) { colFlag = (short)packet.readInt(); } else { colFlag = (short)(packet.readByte() & 0xFF); }  int colDecimals = packet.readByte() & 0xFF; if (this.colDecimalNeedsBump)
/*      */       colDecimals++;  Field field = new Field(this.connection, packet.getByteBuffer(), nameStart, nameLength, tableNameStart, tableNameLength, colLength, colType, colFlag, colDecimals); return field; }
/*  147 */   public MysqlIO(String host, int port, Properties props, String socketFactoryClassName, ConnectionImpl conn, int socketTimeout, int useBufferRowSizeThreshold) throws IOException, SQLException { this.packetSequenceReset = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  155 */     this.reusablePacket = null;
/*  156 */     this.sendPacket = null;
/*  157 */     this.sharedSendPacket = null;
/*      */ 
/*      */     
/*  160 */     this.mysqlOutput = null;
/*      */     
/*  162 */     this.deflater = null;
/*  163 */     this.mysqlInput = null;
/*  164 */     this.packetDebugRingBuffer = null;
/*  165 */     this.streamingData = null;
/*      */ 
/*      */     
/*  168 */     this.mysqlConnection = null;
/*  169 */     this.socketFactory = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  185 */     this.host = null;
/*      */     
/*  187 */     this.serverVersion = null;
/*  188 */     this.socketFactoryClassName = null;
/*  189 */     this.packetHeaderBuf = new byte[4];
/*  190 */     this.colDecimalNeedsBump = false;
/*  191 */     this.hadWarnings = false;
/*  192 */     this.has41NewNewProt = false;
/*      */ 
/*      */     
/*  195 */     this.hasLongColumnInfo = false;
/*  196 */     this.isInteractiveClient = false;
/*  197 */     this.logSlowQueries = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  203 */     this.platformDbCharsetMatches = true;
/*  204 */     this.profileSql = false;
/*  205 */     this.queryBadIndexUsed = false;
/*  206 */     this.queryNoIndexUsed = false;
/*  207 */     this.serverQueryWasSlow = false;
/*      */ 
/*      */     
/*  210 */     this.use41Extensions = false;
/*  211 */     this.useCompression = false;
/*  212 */     this.useNewLargePackets = false;
/*  213 */     this.useNewUpdateCounts = false;
/*  214 */     this.packetSequence = 0;
/*  215 */     this.readPacketSequence = -1;
/*  216 */     this.checkPacketSequence = false;
/*  217 */     this.protocolVersion = 0;
/*  218 */     this.maxAllowedPacket = 1048576;
/*  219 */     this.maxThreeBytes = 16581375;
/*  220 */     this.port = 3306;
/*      */     
/*  222 */     this.serverMajorVersion = 0;
/*  223 */     this.serverMinorVersion = 0;
/*  224 */     this.oldServerStatus = 0;
/*  225 */     this.serverStatus = 0;
/*  226 */     this.serverSubMinorVersion = 0;
/*  227 */     this.warningCount = 0;
/*  228 */     this.clientParam = 0L;
/*  229 */     this.lastPacketSentTimeMs = 0L;
/*  230 */     this.lastPacketReceivedTimeMs = 0L;
/*  231 */     this.traceProtocol = false;
/*  232 */     this.enablePacketDebug = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  241 */     this.useDirectRowUnpack = true;
/*      */     
/*  243 */     this.commandCount = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1976 */     this.statementExecutionDepth = 0; this.connection = conn; if (this.connection.getEnablePacketDebug())
/*      */       this.packetDebugRingBuffer = new LinkedList();  this.traceProtocol = this.connection.getTraceProtocol(); this.useAutoSlowLog = this.connection.getAutoSlowLog(); this.useBufferRowSizeThreshold = useBufferRowSizeThreshold; this.useDirectRowUnpack = this.connection.getUseDirectRowUnpack(); this.logSlowQueries = this.connection.getLogSlowQueries(); this.reusablePacket = new Buffer(1024); this.sendPacket = new Buffer(1024); this.port = port; this.host = host; this.socketFactoryClassName = socketFactoryClassName; this.socketFactory = createSocketFactory(); this.exceptionInterceptor = this.connection.getExceptionInterceptor(); try { this.mysqlConnection = this.socketFactory.connect(this.host, this.port, props); if (socketTimeout != 0)
/*      */         try { this.mysqlConnection.setSoTimeout(socketTimeout); } catch (Exception ex) {}  this.mysqlConnection = this.socketFactory.beforeHandshake(); if (this.connection.getUseReadAheadInput()) { this.mysqlInput = (InputStream)new ReadAheadInputStream(this.mysqlConnection.getInputStream(), 16384, this.connection.getTraceProtocol(), this.connection.getLog()); } else if (this.connection.useUnbufferedInput()) { this.mysqlInput = this.mysqlConnection.getInputStream(); } else { this.mysqlInput = new BufferedInputStream(this.mysqlConnection.getInputStream(), 16384); }  this.mysqlOutput = new BufferedOutputStream(this.mysqlConnection.getOutputStream(), 16384); this.isInteractiveClient = this.connection.getInteractiveClient(); this.profileSql = this.connection.getProfileSql(); this.sessionCalendar = Calendar.getInstance(); this.autoGenerateTestcaseScript = this.connection.getAutoGenerateTestcaseScript(); this.needToGrabQueryFromPacket = (this.profileSql || this.logSlowQueries || this.autoGenerateTestcaseScript); if (this.connection.getUseNanosForElapsedTime() && Util.nanoTimeAvailable()) { this.useNanosForElapsedTime = true; this.queryTimingUnits = Messages.getString("Nanoseconds"); } else { this.queryTimingUnits = Messages.getString("Milliseconds"); }  if (this.connection.getLogSlowQueries())
/*      */         calculateSlowQueryThreshold();  } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, 0L, 0L, ioEx, getExceptionInterceptor()); }  } private int adjustStartForFieldLength(int nameStart, int nameLength) { if (nameLength < 251)
/*      */       return nameStart;  if (nameLength >= 251 && nameLength < 65536)
/*      */       return nameStart + 2;  if (nameLength >= 65536 && nameLength < 16777216)
/*      */       return nameStart + 3;  return nameStart + 8; } protected boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag) { if (this.use41Extensions && this.connection.getElideSetAutoCommits()) { boolean autoCommitModeOnServer = ((this.serverStatus & 0x2) != 0); if (!autoCommitFlag && versionMeetsMinimum(5, 0, 0)) { boolean inTransactionOnServer = ((this.serverStatus & true) != 0); return !inTransactionOnServer; }  return (autoCommitModeOnServer != autoCommitFlag); }
/*      */      return true; } protected boolean inTransactionOnServer() { return ((this.serverStatus & true) != 0); } protected void changeUser(String userName, String password, String database) throws SQLException { this.packetSequence = -1; int passwordLength = 16; int userLength = (userName != null) ? userName.length() : 0; int databaseLength = (database != null) ? database.length() : 0; int packLength = (userLength + passwordLength + databaseLength) * 2 + 7 + 4 + 33; if ((this.serverCapabilities & 0x8000) != 0) { Buffer changeUserPacket = new Buffer(packLength + 1); changeUserPacket.writeByte((byte)17); if (versionMeetsMinimum(4, 1, 1)) { secureAuth411(changeUserPacket, packLength, userName, password, database, false); }
/*      */       else { secureAuth(changeUserPacket, packLength, userName, password, database, false); }
/*      */        }
/*      */     else { Buffer packet = new Buffer(packLength); packet.writeByte((byte)17); packet.writeString(userName); if (this.protocolVersion > 9) { packet.writeString(Util.newCrypt(password, this.seed)); }
/*      */       else { packet.writeString(Util.oldCrypt(password, this.seed)); }
/*      */        boolean localUseConnectWithDb = (this.useConnectWithDb && database != null && database.length() > 0); if (localUseConnectWithDb)
/*      */         packet.writeString(database);  send(packet, packet.getPosition()); checkErrorPacket(); if (!localUseConnectWithDb)
/*      */         changeDatabaseTo(database);  }
/*      */      }
/*      */   protected Buffer checkErrorPacket() throws SQLException { return checkErrorPacket(-1); }
/*      */   protected void checkForCharsetMismatch() { if (this.connection.getUseUnicode() && this.connection.getEncoding() != null) { String encodingToCheck = jvmPlatformCharset; if (encodingToCheck == null)
/*      */         encodingToCheck = System.getProperty("file.encoding");  if (encodingToCheck == null) { this.platformDbCharsetMatches = false; }
/*      */       else { this.platformDbCharsetMatches = encodingToCheck.equals(this.connection.getEncoding()); }
/*      */        }
/*      */      }
/*      */   protected void clearInputStream() throws SQLException { try { int len = this.mysqlInput.available(); while (len > 0) { this.mysqlInput.skip(len); len = this.mysqlInput.available(); }
/*      */        }
/*      */     catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); }
/*      */      }
/*      */   protected void resetReadPacketSequence() { this.readPacketSequence = 0; }
/* 2003 */   final ResultSetInternalMethods sqlQueryDirect(StatementImpl callingStatement, String query, String characterEncoding, Buffer queryPacket, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Field[] cachedMetadata) throws Exception { this.statementExecutionDepth++;
/*      */ 
/*      */     
/* 2006 */     try { if (this.statementInterceptors != null) {
/* 2007 */         ResultSetInternalMethods interceptedResults = invokeStatementInterceptorsPre(query, callingStatement);
/*      */ 
/*      */         
/* 2010 */         if (interceptedResults != null) {
/* 2011 */           return interceptedResults;
/*      */         }
/*      */       } 
/*      */       
/* 2015 */       long queryStartTime = 0L;
/* 2016 */       long queryEndTime = 0L;
/*      */       
/* 2018 */       if (query != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2023 */         int packLength = 5 + query.length() * 2 + 2;
/*      */         
/* 2025 */         String statementComment = this.connection.getStatementComment();
/*      */         
/* 2027 */         byte[] commentAsBytes = null;
/*      */         
/* 2029 */         if (statementComment != null) {
/* 2030 */           commentAsBytes = StringUtils.getBytes(statementComment, null, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2035 */           packLength += commentAsBytes.length;
/* 2036 */           packLength += 6;
/*      */         } 
/*      */         
/* 2039 */         if (this.sendPacket == null) {
/* 2040 */           this.sendPacket = new Buffer(packLength);
/*      */         } else {
/* 2042 */           this.sendPacket.clear();
/*      */         } 
/*      */         
/* 2045 */         this.sendPacket.writeByte((byte)3);
/*      */         
/* 2047 */         if (commentAsBytes != null) {
/* 2048 */           this.sendPacket.writeBytesNoNull(Constants.SLASH_STAR_SPACE_AS_BYTES);
/* 2049 */           this.sendPacket.writeBytesNoNull(commentAsBytes);
/* 2050 */           this.sendPacket.writeBytesNoNull(Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
/*      */         } 
/*      */         
/* 2053 */         if (characterEncoding != null) {
/* 2054 */           if (this.platformDbCharsetMatches) {
/* 2055 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/* 2060 */           else if (StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA")) {
/* 2061 */             this.sendPacket.writeBytesNoNull(query.getBytes());
/*      */           } else {
/* 2063 */             this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 2071 */           this.sendPacket.writeStringNoNull(query);
/*      */         } 
/*      */         
/* 2074 */         queryPacket = this.sendPacket;
/*      */       } 
/*      */       
/* 2077 */       byte[] queryBuf = null;
/* 2078 */       int oldPacketPosition = 0;
/*      */       
/* 2080 */       if (this.needToGrabQueryFromPacket) {
/* 2081 */         queryBuf = queryPacket.getByteBuffer();
/*      */ 
/*      */         
/* 2084 */         oldPacketPosition = queryPacket.getPosition();
/*      */         
/* 2086 */         queryStartTime = getCurrentTimeNanosOrMillis();
/*      */       } 
/*      */       
/* 2089 */       if (this.autoGenerateTestcaseScript) {
/* 2090 */         String testcaseQuery = null;
/*      */         
/* 2092 */         if (query != null) {
/* 2093 */           testcaseQuery = query;
/*      */         } else {
/* 2095 */           testcaseQuery = new String(queryBuf, 5, oldPacketPosition - 5);
/*      */         } 
/*      */ 
/*      */         
/* 2099 */         StringBuffer debugBuf = new StringBuffer(testcaseQuery.length() + 32);
/* 2100 */         this.connection.generateConnectionCommentBlock(debugBuf);
/* 2101 */         debugBuf.append(testcaseQuery);
/* 2102 */         debugBuf.append(';');
/* 2103 */         this.connection.dumpTestcaseQuery(debugBuf.toString());
/*      */       } 
/*      */ 
/*      */       
/* 2107 */       Buffer resultPacket = sendCommand(3, null, queryPacket, false, null, 0);
/*      */ 
/*      */       
/* 2110 */       long fetchBeginTime = 0L;
/* 2111 */       long fetchEndTime = 0L;
/*      */       
/* 2113 */       String profileQueryToLog = null;
/*      */       
/* 2115 */       boolean queryWasSlow = false;
/*      */       
/* 2117 */       if (this.profileSql || this.logSlowQueries) {
/* 2118 */         queryEndTime = System.currentTimeMillis();
/*      */         
/* 2120 */         boolean shouldExtractQuery = false;
/*      */         
/* 2122 */         if (this.profileSql) {
/* 2123 */           shouldExtractQuery = true;
/* 2124 */         } else if (this.logSlowQueries) {
/* 2125 */           long queryTime = queryEndTime - queryStartTime;
/*      */           
/* 2127 */           boolean logSlow = false;
/*      */           
/* 2129 */           if (this.useAutoSlowLog) {
/* 2130 */             logSlow = (queryTime > this.connection.getSlowQueryThresholdMillis());
/*      */           } else {
/* 2132 */             logSlow = this.connection.isAbonormallyLongQuery(queryTime);
/*      */             
/* 2134 */             this.connection.reportQueryTime(queryTime);
/*      */           } 
/*      */           
/* 2137 */           if (logSlow) {
/* 2138 */             shouldExtractQuery = true;
/* 2139 */             queryWasSlow = true;
/*      */           } 
/*      */         } 
/*      */         
/* 2143 */         if (shouldExtractQuery) {
/*      */           
/* 2145 */           boolean truncated = false;
/*      */           
/* 2147 */           int extractPosition = oldPacketPosition;
/*      */           
/* 2149 */           if (oldPacketPosition > this.connection.getMaxQuerySizeToLog()) {
/* 2150 */             extractPosition = this.connection.getMaxQuerySizeToLog() + 5;
/* 2151 */             truncated = true;
/*      */           } 
/*      */           
/* 2154 */           profileQueryToLog = new String(queryBuf, 5, extractPosition - 5);
/*      */ 
/*      */           
/* 2157 */           if (truncated) {
/* 2158 */             profileQueryToLog = profileQueryToLog + Messages.getString("MysqlIO.25");
/*      */           }
/*      */         } 
/*      */         
/* 2162 */         fetchBeginTime = queryEndTime;
/*      */       } 
/*      */       
/* 2165 */       ResultSetInternalMethods rs = readAllResults(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, false, -1L, cachedMetadata);
/*      */ 
/*      */ 
/*      */       
/* 2169 */       if (queryWasSlow && !this.serverQueryWasSlow) {
/* 2170 */         StringBuffer mesgBuf = new StringBuffer(48 + profileQueryToLog.length());
/*      */ 
/*      */         
/* 2173 */         mesgBuf.append(Messages.getString("MysqlIO.SlowQuery", new Object[] { new Long(this.slowQueryThreshold), this.queryTimingUnits, new Long(queryEndTime - queryStartTime) }));
/*      */ 
/*      */ 
/*      */         
/* 2177 */         mesgBuf.append(profileQueryToLog);
/*      */         
/* 2179 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2181 */         eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), this.queryTimingUnits, null, new Throwable(), mesgBuf.toString()));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2188 */         if (this.connection.getExplainSlowQueries()) {
/* 2189 */           if (oldPacketPosition < 1048576) {
/* 2190 */             explainSlowQuery(queryPacket.getBytes(5, oldPacketPosition - 5), profileQueryToLog);
/*      */           } else {
/*      */             
/* 2193 */             this.connection.getLog().logWarn(Messages.getString("MysqlIO.28") + 1048576 + Messages.getString("MysqlIO.29"));
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2201 */       if (this.logSlowQueries) {
/*      */         
/* 2203 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2205 */         if (this.queryBadIndexUsed) {
/* 2206 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), Messages.getString("MysqlIO.33") + profileQueryToLog));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2219 */         if (this.queryNoIndexUsed) {
/* 2220 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), Messages.getString("MysqlIO.35") + profileQueryToLog));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2233 */         if (this.serverQueryWasSlow) {
/* 2234 */           eventSink.consumeEvent(new ProfilerEvent((byte)6, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), Messages.getString("MysqlIO.ServerSlowQuery") + profileQueryToLog));
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2248 */       if (this.profileSql) {
/* 2249 */         fetchEndTime = getCurrentTimeNanosOrMillis();
/*      */         
/* 2251 */         ProfilerEventHandler eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */         
/* 2253 */         eventSink.consumeEvent(new ProfilerEvent((byte)3, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), queryEndTime - queryStartTime, this.queryTimingUnits, null, new Throwable(), profileQueryToLog));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2261 */         eventSink.consumeEvent(new ProfilerEvent((byte)5, "", catalog, this.connection.getId(), (callingStatement != null) ? callingStatement.getId() : 999, ((ResultSetImpl)rs).resultId, System.currentTimeMillis(), fetchEndTime - fetchBeginTime, this.queryTimingUnits, null, new Throwable(), null));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2270 */       if (this.hadWarnings) {
/* 2271 */         scanForAndThrowDataTruncation();
/*      */       }
/*      */       
/* 2274 */       if (this.statementInterceptors != null) {
/* 2275 */         ResultSetInternalMethods interceptedResults = invokeStatementInterceptorsPost(query, callingStatement, rs);
/*      */ 
/*      */         
/* 2278 */         if (interceptedResults != null) {
/* 2279 */           rs = interceptedResults;
/*      */         }
/*      */       } 
/*      */       
/* 2283 */       return rs; }
/*      */     finally
/* 2285 */     { this.statementExecutionDepth--; }  } protected void dumpPacketRingBuffer() throws SQLException { if (this.packetDebugRingBuffer != null && this.connection.getEnablePacketDebug()) { StringBuffer dumpBuffer = new StringBuffer(); dumpBuffer.append("Last " + this.packetDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n"); dumpBuffer.append("\n"); Iterator ringBufIter = this.packetDebugRingBuffer.iterator(); while (ringBufIter.hasNext()) { dumpBuffer.append(ringBufIter.next()); dumpBuffer.append("\n"); }  this.connection.getLog().logTrace(dumpBuffer.toString()); }  } protected void explainSlowQuery(byte[] querySQL, String truncatedQuery) throws SQLException { if (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT")) { PreparedStatement stmt = null; ResultSet rs = null; try { stmt = (PreparedStatement)this.connection.clientPrepareStatement("EXPLAIN ?"); stmt.setBytesNoEscapeNoQuotes(1, querySQL); rs = stmt.executeQuery(); StringBuffer explainResults = new StringBuffer(Messages.getString("MysqlIO.8") + truncatedQuery + Messages.getString("MysqlIO.9")); ResultSetUtil.appendResultSetSlashGStyle(explainResults, rs); this.connection.getLog().logWarn(explainResults.toString()); } catch (SQLException sqlEx) {  } finally { if (rs != null) rs.close();  if (stmt != null) stmt.close();  }  }  } static int getMaxBuf() { return maxBufferSize; } final int getServerMajorVersion() { return this.serverMajorVersion; } final int getServerMinorVersion() { return this.serverMinorVersion; } final int getServerSubMinorVersion() { return this.serverSubMinorVersion; }
/*      */   String getServerVersion() { return this.serverVersion; }
/*      */   void doHandshake(String user, String password, String database) throws SQLException { this.checkPacketSequence = false; this.readPacketSequence = 0; Buffer buf = readPacket(); this.protocolVersion = buf.readByte(); if (this.protocolVersion == -1) { try { this.mysqlConnection.close(); } catch (Exception e) {} int errno = 2000; errno = buf.readInt(); String serverErrorMessage = buf.readString("ASCII", getExceptionInterceptor()); StringBuffer errorBuf = new StringBuffer(Messages.getString("MysqlIO.10")); errorBuf.append(serverErrorMessage); errorBuf.append("\""); String xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes()); throw SQLError.createSQLException(SQLError.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno, getExceptionInterceptor()); }  this.serverVersion = buf.readString("ASCII", getExceptionInterceptor()); int point = this.serverVersion.indexOf('.'); if (point != -1) { try { int n = Integer.parseInt(this.serverVersion.substring(0, point)); this.serverMajorVersion = n; } catch (NumberFormatException NFE1) {} String remaining = this.serverVersion.substring(point + 1, this.serverVersion.length()); point = remaining.indexOf('.'); if (point != -1) { try { int n = Integer.parseInt(remaining.substring(0, point)); this.serverMinorVersion = n; } catch (NumberFormatException nfe) {} remaining = remaining.substring(point + 1, remaining.length()); int pos = 0; while (pos < remaining.length() && remaining.charAt(pos) >= '0' && remaining.charAt(pos) <= '9') pos++;  try { int n = Integer.parseInt(remaining.substring(0, pos)); this.serverSubMinorVersion = n; } catch (NumberFormatException nfe) {} }  }  if (versionMeetsMinimum(4, 0, 8)) { this.maxThreeBytes = 16777215; this.useNewLargePackets = true; } else { this.maxThreeBytes = 16581375; this.useNewLargePackets = false; }  this.colDecimalNeedsBump = versionMeetsMinimum(3, 23, 0); this.colDecimalNeedsBump = !versionMeetsMinimum(3, 23, 15); this.useNewUpdateCounts = versionMeetsMinimum(3, 22, 5); this.threadId = buf.readLong(); this.seed = buf.readString("ASCII", getExceptionInterceptor()); this.serverCapabilities = 0; if (buf.getPosition() < buf.getBufLength()) this.serverCapabilities = buf.readInt();  if (versionMeetsMinimum(4, 1, 1)) { int position = buf.getPosition(); this.serverCharsetIndex = buf.readByte() & 0xFF; this.serverStatus = buf.readInt(); checkTransactionState(0); buf.setPosition(position + 16); String seedPart2 = buf.readString("ASCII", getExceptionInterceptor()); StringBuffer newSeed = new StringBuffer(20); newSeed.append(this.seed); newSeed.append(seedPart2); this.seed = newSeed.toString(); }  if ((this.serverCapabilities & 0x20) != 0 && this.connection.getUseCompression()) this.clientParam |= 0x20L;  this.useConnectWithDb = (database != null && database.length() > 0 && !this.connection.getCreateDatabaseIfNotExist()); if (this.useConnectWithDb) this.clientParam |= 0x8L;  if ((this.serverCapabilities & 0x800) == 0 && this.connection.getUseSSL()) { if (this.connection.getRequireSSL()) { this.connection.close(); forceClose(); throw SQLError.createSQLException(Messages.getString("MysqlIO.15"), "08001", getExceptionInterceptor()); }  this.connection.setUseSSL(false); }  if ((this.serverCapabilities & 0x4) != 0) { this.clientParam |= 0x4L; this.hasLongColumnInfo = true; }  if (!this.connection.getUseAffectedRows()) this.clientParam |= 0x2L;  if (this.connection.getAllowLoadLocalInfile()) this.clientParam |= 0x80L;  if (this.isInteractiveClient) this.clientParam |= 0x400L;  if (this.protocolVersion > 9) { this.clientParam |= 0x1L; } else { this.clientParam &= 0xFFFFFFFFFFFFFFFEL; }  if (versionMeetsMinimum(4, 1, 0)) { if (versionMeetsMinimum(4, 1, 1)) { this.clientParam |= 0x200L; this.has41NewNewProt = true; this.clientParam |= 0x2000L; this.clientParam |= 0x20000L; if (this.connection.getAllowMultiQueries()) this.clientParam |= 0x10000L;  } else { this.clientParam |= 0x4000L; this.has41NewNewProt = false; }  this.use41Extensions = true; }  int passwordLength = 16; int userLength = (user != null) ? user.length() : 0; int databaseLength = (database != null) ? database.length() : 0; int packLength = (userLength + passwordLength + databaseLength) * 2 + 7 + 4 + 33; Buffer packet = null; if (!this.connection.getUseSSL()) { if ((this.serverCapabilities & 0x8000) != 0) { this.clientParam |= 0x8000L; if (versionMeetsMinimum(4, 1, 1)) { secureAuth411(null, packLength, user, password, database, true); } else { secureAuth(null, packLength, user, password, database, true); }  } else { packet = new Buffer(packLength); if ((this.clientParam & 0x4000L) != 0L) { if (versionMeetsMinimum(4, 1, 1)) { packet.writeLong(this.clientParam); packet.writeLong(this.maxThreeBytes); packet.writeByte((byte)8); packet.writeBytesNoNull(new byte[23]); } else { packet.writeLong(this.clientParam); packet.writeLong(this.maxThreeBytes); }  } else { packet.writeInt((int)this.clientParam); packet.writeLongInt(this.maxThreeBytes); }  packet.writeString(user, "Cp1252", this.connection); if (this.protocolVersion > 9) { packet.writeString(Util.newCrypt(password, this.seed), "Cp1252", this.connection); } else { packet.writeString(Util.oldCrypt(password, this.seed), "Cp1252", this.connection); }  if (this.useConnectWithDb) packet.writeString(database, "Cp1252", this.connection);  send(packet, packet.getPosition()); }  } else { negotiateSSLConnection(user, password, database, packLength); }  if (!versionMeetsMinimum(4, 1, 1)) checkErrorPacket();  if ((this.serverCapabilities & 0x20) != 0 && this.connection.getUseCompression()) { this.deflater = new Deflater(); this.useCompression = true; this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput); }  if (!this.useConnectWithDb)
/*      */       changeDatabaseTo(database);  try { this.mysqlConnection = this.socketFactory.afterHandshake(); } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); }  }
/*      */   private void changeDatabaseTo(String database) throws SQLException { if (database == null || database.length() == 0)
/*      */       return;  try { sendCommand(2, database, null, false, null, 0); } catch (Exception ex) { if (this.connection.getCreateDatabaseIfNotExist()) { sendCommand(3, "CREATE DATABASE IF NOT EXISTS " + database, null, false, null, 0); sendCommand(2, database, null, false, null, 0); } else { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor()); }  }  }
/* 2291 */   private ResultSetInternalMethods invokeStatementInterceptorsPre(String sql, Statement interceptedStatement) throws SQLException { ResultSetInternalMethods previousResultSet = null;
/*      */     
/* 2293 */     Iterator interceptors = this.statementInterceptors.iterator();
/*      */     
/* 2295 */     while (interceptors.hasNext()) {
/* 2296 */       StatementInterceptor interceptor = interceptors.next();
/*      */ 
/*      */       
/* 2299 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2300 */       boolean shouldExecute = ((executeTopLevelOnly && this.statementExecutionDepth == 1) || !executeTopLevelOnly);
/*      */ 
/*      */       
/* 2303 */       if (shouldExecute) {
/* 2304 */         String sqlToInterceptor = sql;
/*      */         
/* 2306 */         if (interceptedStatement instanceof PreparedStatement) {
/* 2307 */           sqlToInterceptor = ((PreparedStatement)interceptedStatement).asSql();
/*      */         }
/*      */ 
/*      */         
/* 2311 */         ResultSetInternalMethods interceptedResultSet = interceptor.preProcess(sqlToInterceptor, interceptedStatement, this.connection);
/*      */ 
/*      */ 
/*      */         
/* 2315 */         if (interceptedResultSet != null) {
/* 2316 */           previousResultSet = interceptedResultSet;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2321 */     return previousResultSet; }
/*      */   final ResultSetRow nextRow(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacketForBufferRow, Buffer existingRowPacket) throws SQLException { if (this.useDirectRowUnpack && existingRowPacket == null && !isBinaryEncoded && !useBufferRowIfPossible && !useBufferRowExplicit) return nextRowFast(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacketForBufferRow);  Buffer rowPacket = null; if (existingRowPacket == null) { rowPacket = checkErrorPacket(); if (!useBufferRowExplicit && useBufferRowIfPossible && rowPacket.getBufLength() > this.useBufferRowSizeThreshold) useBufferRowExplicit = true;  } else { rowPacket = existingRowPacket; checkErrorPacket(existingRowPacket); }  if (!isBinaryEncoded) { rowPacket.setPosition(rowPacket.getPosition() - 1); if (!rowPacket.isLastDataPacket()) { if (resultSetConcurrency == 1008 || (!useBufferRowIfPossible && !useBufferRowExplicit)) { byte[][] rowData = new byte[columnCount][]; for (int i = 0; i < columnCount; i++) rowData[i] = rowPacket.readLenByteArray(0);  return new ByteArrayRow(rowData, getExceptionInterceptor()); }  if (!canReuseRowPacketForBufferRow) this.reusablePacket = new Buffer(rowPacket.getBufLength());  return new BufferRow(rowPacket, fields, false, getExceptionInterceptor()); }  readServerStatusForResultSets(rowPacket); return null; }  if (!rowPacket.isLastDataPacket()) { if (resultSetConcurrency == 1008 || (!useBufferRowIfPossible && !useBufferRowExplicit)) return unpackBinaryResultSetRow(fields, rowPacket, resultSetConcurrency);  if (!canReuseRowPacketForBufferRow) this.reusablePacket = new Buffer(rowPacket.getBufLength());  return new BufferRow(rowPacket, fields, true, getExceptionInterceptor()); }  rowPacket.setPosition(rowPacket.getPosition() - 1); readServerStatusForResultSets(rowPacket); return null; }
/*      */   final ResultSetRow nextRowFast(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency, boolean useBufferRowIfPossible, boolean useBufferRowExplicit, boolean canReuseRowPacket) throws SQLException { try { int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4); if (lengthRead < 4) { forceClose(); throw new RuntimeException(Messages.getString("MysqlIO.43")); }  int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16); if (packetLength == this.maxThreeBytes) { reuseAndReadPacket(this.reusablePacket, packetLength); return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, useBufferRowIfPossible, useBufferRowExplicit, canReuseRowPacket, this.reusablePacket); }  if (packetLength > this.useBufferRowSizeThreshold) { reuseAndReadPacket(this.reusablePacket, packetLength); return nextRow(fields, columnCount, isBinaryEncoded, resultSetConcurrency, true, true, false, this.reusablePacket); }  int remaining = packetLength; boolean firstTime = true; byte[][] rowData = (byte[][])null; for (int i = 0; i < columnCount; i++) { int sw = this.mysqlInput.read() & 0xFF; remaining--; if (firstTime) { if (sw == 255) { Buffer errorPacket = new Buffer(packetLength + 4); errorPacket.setPosition(0); errorPacket.writeByte(this.packetHeaderBuf[0]); errorPacket.writeByte(this.packetHeaderBuf[1]); errorPacket.writeByte(this.packetHeaderBuf[2]); errorPacket.writeByte((byte)1); errorPacket.writeByte((byte)sw); readFully(this.mysqlInput, errorPacket.getByteBuffer(), 5, packetLength - 1); errorPacket.setPosition(4); checkErrorPacket(errorPacket); }  if (sw == 254 && packetLength < 9) { if (this.use41Extensions) { this.warningCount = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; remaining -= 2; if (this.warningCount > 0) this.hadWarnings = true;  this.oldServerStatus = this.serverStatus; this.serverStatus = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; checkTransactionState(this.oldServerStatus); remaining -= 2; if (remaining > 0) skipFully(this.mysqlInput, remaining);  }  return null; }  rowData = new byte[columnCount][]; firstTime = false; }  int len = 0; switch (sw) { case 251: len = -1; break;case 252: len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8; remaining -= 2; break;case 253: len = this.mysqlInput.read() & 0xFF | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16; remaining -= 3; break;case 254: len = (int)((this.mysqlInput.read() & 0xFF) | (this.mysqlInput.read() & 0xFF) << 8 | (this.mysqlInput.read() & 0xFF) << 16 | (this.mysqlInput.read() & 0xFF) << 24 | (this.mysqlInput.read() & 0xFF) << 32 | (this.mysqlInput.read() & 0xFF) << 40 | (this.mysqlInput.read() & 0xFF) << 48 | (this.mysqlInput.read() & 0xFF) << 56); remaining -= 8; break;default: len = sw; break; }  if (len == -1) { rowData[i] = null; } else if (len == 0) { rowData[i] = Constants.EMPTY_BYTE_ARRAY; } else { rowData[i] = new byte[len]; int bytesRead = readFully(this.mysqlInput, rowData[i], 0, len); if (bytesRead != len) throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException(Messages.getString("MysqlIO.43")), getExceptionInterceptor());  remaining -= bytesRead; }  }  if (remaining > 0)
/*      */         skipFully(this.mysqlInput, remaining);  return new ByteArrayRow(rowData, getExceptionInterceptor()); } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); }  }
/*      */   final void quit() throws SQLException { Buffer packet = new Buffer(6); this.packetSequence = -1; packet.writeByte((byte)1); send(packet, packet.getPosition()); forceClose(); }
/*      */   Buffer getSharedSendPacket() { if (this.sharedSendPacket == null)
/* 2327 */       this.sharedSendPacket = new Buffer(1024);  return this.sharedSendPacket; } private ResultSetInternalMethods invokeStatementInterceptorsPost(String sql, Statement interceptedStatement, ResultSetInternalMethods originalResultSet) throws SQLException { Iterator interceptors = this.statementInterceptors.iterator();
/*      */     
/* 2329 */     while (interceptors.hasNext()) {
/* 2330 */       StatementInterceptor interceptor = interceptors.next();
/*      */ 
/*      */       
/* 2333 */       boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
/* 2334 */       boolean shouldExecute = ((executeTopLevelOnly && this.statementExecutionDepth == 1) || !executeTopLevelOnly);
/*      */ 
/*      */       
/* 2337 */       if (shouldExecute) {
/* 2338 */         String sqlToInterceptor = sql;
/*      */         
/* 2340 */         if (interceptedStatement instanceof PreparedStatement) {
/* 2341 */           sqlToInterceptor = ((PreparedStatement)interceptedStatement).asSql();
/*      */         }
/*      */ 
/*      */         
/* 2345 */         ResultSetInternalMethods interceptedResultSet = interceptor.postProcess(sqlToInterceptor, interceptedStatement, originalResultSet, this.connection);
/*      */ 
/*      */ 
/*      */         
/* 2349 */         if (interceptedResultSet != null) {
/* 2350 */           originalResultSet = interceptedResultSet;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2355 */     return originalResultSet; }
/*      */   void closeStreamer(RowData streamer) throws SQLException { if (this.streamingData == null) throw SQLError.createSQLException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"), getExceptionInterceptor());  if (streamer != this.streamingData) throw SQLError.createSQLException(Messages.getString("MysqlIO.19") + streamer + Messages.getString("MysqlIO.20") + Messages.getString("MysqlIO.21") + Messages.getString("MysqlIO.22"), getExceptionInterceptor());  this.streamingData = null; }
/*      */   boolean tackOnMoreStreamingResults(ResultSetImpl addingTo) throws SQLException { if ((this.serverStatus & 0x8) != 0) { boolean moreRowSetsExist = true; ResultSetImpl currentResultSet = addingTo; boolean firstTime = true; while (moreRowSetsExist && (firstTime || !currentResultSet.reallyResult())) { firstTime = false; Buffer fieldPacket = checkErrorPacket(); fieldPacket.setPosition(0); Statement owningStatement = addingTo.getStatement(); int maxRows = owningStatement.getMaxRows(); ResultSetImpl newResultSet = readResultsForQueryOrUpdate((StatementImpl)owningStatement, maxRows, owningStatement.getResultSetType(), owningStatement.getResultSetConcurrency(), true, owningStatement.getConnection().getCatalog(), fieldPacket, addingTo.isBinaryEncoded, -1L, null); currentResultSet.setNextResultSet(newResultSet); currentResultSet = newResultSet; moreRowSetsExist = ((this.serverStatus & 0x8) != 0); if (!currentResultSet.reallyResult() && !moreRowSetsExist) return false;  }  return true; }  return false; }
/*      */   ResultSetImpl readAllResults(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache) throws SQLException { resultPacket.setPosition(resultPacket.getPosition() - 1); ResultSetImpl topLevelResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache); ResultSetImpl currentResultSet = topLevelResultSet; boolean checkForMoreResults = ((this.clientParam & 0x20000L) != 0L); boolean serverHasMoreResults = ((this.serverStatus & 0x8) != 0); if (serverHasMoreResults && streamResults) { if (topLevelResultSet.getUpdateCount() != -1L) tackOnMoreStreamingResults(topLevelResultSet);  reclaimLargeReusablePacket(); return topLevelResultSet; }  boolean moreRowSetsExist = checkForMoreResults & serverHasMoreResults; while (moreRowSetsExist) { Buffer fieldPacket = checkErrorPacket(); fieldPacket.setPosition(0); ResultSetImpl newResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, fieldPacket, isBinaryEncoded, preSentColumnCount, metadataFromCache); currentResultSet.setNextResultSet(newResultSet); currentResultSet = newResultSet; moreRowSetsExist = ((this.serverStatus & 0x8) != 0); }  if (!streamResults) clearInputStream();  reclaimLargeReusablePacket(); return topLevelResultSet; }
/* 2359 */   void resetMaxBuf() { this.maxAllowedPacket = this.connection.getMaxAllowedPacket(); } final Buffer sendCommand(int command, String extraData, Buffer queryPacket, boolean skipCheck, String extraDataCharEncoding, int timeoutMillis) throws SQLException { this.commandCount++; this.enablePacketDebug = this.connection.getEnablePacketDebug(); this.readPacketSequence = 0; int oldTimeout = 0; if (timeoutMillis != 0) try { oldTimeout = this.mysqlConnection.getSoTimeout(); this.mysqlConnection.setSoTimeout(timeoutMillis); } catch (SocketException e) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor()); }   try { checkForOutstandingStreamingData(); this.oldServerStatus = this.serverStatus; this.serverStatus = 0; this.hadWarnings = false; this.warningCount = 0; this.queryNoIndexUsed = false; this.queryBadIndexUsed = false; this.serverQueryWasSlow = false; if (this.useCompression) { int bytesLeft = this.mysqlInput.available(); if (bytesLeft > 0) this.mysqlInput.skip(bytesLeft);  }  try { clearInputStream(); if (queryPacket == null) { int packLength = 8 + ((extraData != null) ? extraData.length() : 0) + 2; if (this.sendPacket == null) this.sendPacket = new Buffer(packLength);  this.packetSequence = -1; this.readPacketSequence = 0; this.checkPacketSequence = true; this.sendPacket.clear(); this.sendPacket.writeByte((byte)command); if (command == 2 || command == 5 || command == 6 || command == 3 || command == 22) { if (extraDataCharEncoding == null) { this.sendPacket.writeStringNoNull(extraData); } else { this.sendPacket.writeStringNoNull(extraData, extraDataCharEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection); }  } else if (command == 12) { long id = Long.parseLong(extraData); this.sendPacket.writeLong(id); }  send(this.sendPacket, this.sendPacket.getPosition()); } else { this.packetSequence = -1; send(queryPacket, queryPacket.getPosition()); }  } catch (SQLException sqlEx) { throw sqlEx; } catch (Exception ex) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ex, getExceptionInterceptor()); }  Buffer returnPacket = null; if (!skipCheck) { if (command == 23 || command == 26) { this.readPacketSequence = 0; this.packetSequenceReset = true; }  returnPacket = checkErrorPacket(command); }  return returnPacket; } catch (IOException ioEx) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor()); } finally { if (timeoutMillis != 0) try { this.mysqlConnection.setSoTimeout(oldTimeout); } catch (SocketException e) { throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, e, getExceptionInterceptor()); }   }  } private void calculateSlowQueryThreshold() { this.slowQueryThreshold = this.connection.getSlowQueryThresholdMillis();
/*      */     
/* 2361 */     if (this.connection.getUseNanosForElapsedTime()) {
/* 2362 */       long nanosThreshold = this.connection.getSlowQueryThresholdNanos();
/*      */       
/* 2364 */       if (nanosThreshold != 0L) {
/* 2365 */         this.slowQueryThreshold = nanosThreshold;
/*      */       } else {
/* 2367 */         this.slowQueryThreshold *= 1000000L;
/*      */       } 
/*      */     }  }
/*      */ 
/*      */   
/*      */   protected long getCurrentTimeNanosOrMillis() {
/* 2373 */     if (this.useNanosForElapsedTime) {
/* 2374 */       return Util.getCurrentTimeNanosOrMillis();
/*      */     }
/*      */     
/* 2377 */     return System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2386 */   String getHost() { return this.host; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2401 */   boolean isVersion(int major, int minor, int subminor) { return (major == getServerMajorVersion() && minor == getServerMinorVersion() && subminor == getServerSubMinorVersion()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean versionMeetsMinimum(int major, int minor, int subminor) {
/* 2417 */     if (getServerMajorVersion() >= major) {
/* 2418 */       if (getServerMajorVersion() == major) {
/* 2419 */         if (getServerMinorVersion() >= minor) {
/* 2420 */           if (getServerMinorVersion() == minor) {
/* 2421 */             return (getServerSubMinorVersion() >= subminor);
/*      */           }
/*      */ 
/*      */           
/* 2425 */           return true;
/*      */         } 
/*      */ 
/*      */         
/* 2429 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 2433 */       return true;
/*      */     } 
/*      */     
/* 2436 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String getPacketDumpToLog(Buffer packetToDump, int packetLength) {
/* 2450 */     if (packetLength < 1024) {
/* 2451 */       return packetToDump.dump(packetLength);
/*      */     }
/*      */     
/* 2454 */     StringBuffer packetDumpBuf = new StringBuffer(4096);
/* 2455 */     packetDumpBuf.append(packetToDump.dump(1024));
/* 2456 */     packetDumpBuf.append(Messages.getString("MysqlIO.36"));
/* 2457 */     packetDumpBuf.append(1024);
/* 2458 */     packetDumpBuf.append(Messages.getString("MysqlIO.37"));
/*      */     
/* 2460 */     return packetDumpBuf.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   private final int readFully(InputStream in, byte[] b, int off, int len) throws IOException {
/* 2465 */     if (len < 0) {
/* 2466 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */     
/* 2469 */     int n = 0;
/*      */     
/* 2471 */     while (n < len) {
/* 2472 */       int count = in.read(b, off + n, len - n);
/*      */       
/* 2474 */       if (count < 0) {
/* 2475 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { new Integer(len), new Integer(n) }));
/*      */       }
/*      */ 
/*      */       
/* 2479 */       n += count;
/*      */     } 
/*      */     
/* 2482 */     return n;
/*      */   }
/*      */   
/*      */   private final long skipFully(InputStream in, long len) throws IOException {
/* 2486 */     if (len < 0L) {
/* 2487 */       throw new IOException("Negative skip length not allowed");
/*      */     }
/*      */     
/* 2490 */     long n = 0L;
/*      */     
/* 2492 */     while (n < len) {
/* 2493 */       long count = in.skip(len - n);
/*      */       
/* 2495 */       if (count < 0L) {
/* 2496 */         throw new EOFException(Messages.getString("MysqlIO.EOF", new Object[] { new Long(len), new Long(n) }));
/*      */       }
/*      */ 
/*      */       
/* 2500 */       n += count;
/*      */     } 
/*      */     
/* 2503 */     return n;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final ResultSetImpl readResultsForQueryOrUpdate(StatementImpl callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, Field[] metadataFromCache) throws SQLException {
/* 2531 */     long columnCount = resultPacket.readFieldLength();
/*      */     
/* 2533 */     if (columnCount == 0L)
/* 2534 */       return buildResultSetWithUpdates(callingStatement, resultPacket); 
/* 2535 */     if (columnCount == -1L) {
/* 2536 */       String charEncoding = null;
/*      */       
/* 2538 */       if (this.connection.getUseUnicode()) {
/* 2539 */         charEncoding = this.connection.getEncoding();
/*      */       }
/*      */       
/* 2542 */       String fileName = null;
/*      */       
/* 2544 */       if (this.platformDbCharsetMatches) {
/* 2545 */         fileName = (charEncoding != null) ? resultPacket.readString(charEncoding, getExceptionInterceptor()) : resultPacket.readString();
/*      */       }
/*      */       else {
/*      */         
/* 2549 */         fileName = resultPacket.readString();
/*      */       } 
/*      */       
/* 2552 */       return sendFileToServer(callingStatement, fileName);
/*      */     } 
/* 2554 */     ResultSetImpl results = getResultSet(callingStatement, columnCount, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, isBinaryEncoded, metadataFromCache);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2559 */     return results;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2564 */   private int alignPacketSize(int a, int l) { return a + l - 1 & (l - 1 ^ 0xFFFFFFFF); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetImpl buildResultSetWithRows(StatementImpl callingStatement, String catalog, Field[] fields, RowData rows, int resultSetType, int resultSetConcurrency, boolean isBinaryEncoded) throws SQLException {
/* 2572 */     ResultSetImpl rs = null;
/*      */     
/* 2574 */     switch (resultSetConcurrency) {
/*      */       case 1007:
/* 2576 */         rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */ 
/*      */         
/* 2579 */         if (isBinaryEncoded) {
/* 2580 */           rs.setBinaryEncoded();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2596 */         rs.setResultSetType(resultSetType);
/* 2597 */         rs.setResultSetConcurrency(resultSetConcurrency);
/*      */         
/* 2599 */         return rs;case 1008: rs = ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, true); rs.setResultSetType(resultSetType); rs.setResultSetConcurrency(resultSetConcurrency); return rs;
/*      */     } 
/*      */     return ResultSetImpl.getInstance(catalog, fields, rows, this.connection, callingStatement, false);
/*      */   }
/*      */   
/*      */   private ResultSetImpl buildResultSetWithUpdates(StatementImpl callingStatement, Buffer resultPacket) throws SQLException {
/* 2605 */     long updateCount = -1L;
/* 2606 */     long updateID = -1L;
/* 2607 */     String info = null;
/*      */     
/*      */     try {
/* 2610 */       if (this.useNewUpdateCounts) {
/* 2611 */         updateCount = resultPacket.newReadLength();
/* 2612 */         updateID = resultPacket.newReadLength();
/*      */       } else {
/* 2614 */         updateCount = resultPacket.readLength();
/* 2615 */         updateID = resultPacket.readLength();
/*      */       } 
/*      */       
/* 2618 */       if (this.use41Extensions) {
/*      */         
/* 2620 */         this.serverStatus = resultPacket.readInt();
/*      */         
/* 2622 */         checkTransactionState(this.oldServerStatus);
/*      */         
/* 2624 */         this.warningCount = resultPacket.readInt();
/*      */         
/* 2626 */         if (this.warningCount > 0) {
/* 2627 */           this.hadWarnings = true;
/*      */         }
/*      */         
/* 2630 */         resultPacket.readByte();
/*      */         
/* 2632 */         setServerSlowQueryFlags();
/*      */       } 
/*      */       
/* 2635 */       if (this.connection.isReadInfoMsgEnabled()) {
/* 2636 */         info = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */       }
/* 2638 */     } catch (Exception ex) {
/* 2639 */       SQLException sqlEx = SQLError.createSQLException(SQLError.get("S1000"), "S1000", -1, getExceptionInterceptor());
/*      */       
/* 2641 */       sqlEx.initCause(ex);
/*      */       
/* 2643 */       throw sqlEx;
/*      */     } 
/*      */     
/* 2646 */     ResultSetInternalMethods updateRs = ResultSetImpl.getInstance(updateCount, updateID, this.connection, callingStatement);
/*      */ 
/*      */     
/* 2649 */     if (info != null) {
/* 2650 */       ((ResultSetImpl)updateRs).setServerInfo(info);
/*      */     }
/*      */     
/* 2653 */     return (ResultSetImpl)updateRs;
/*      */   }
/*      */   
/*      */   private void setServerSlowQueryFlags() {
/* 2657 */     if (this.profileSql) {
/* 2658 */       this.queryNoIndexUsed = ((this.serverStatus & 0x10) != 0);
/*      */       
/* 2660 */       this.queryBadIndexUsed = ((this.serverStatus & 0x20) != 0);
/*      */       
/* 2662 */       this.serverQueryWasSlow = ((this.serverStatus & 0x800) != 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkForOutstandingStreamingData() throws SQLException {
/* 2668 */     if (this.streamingData != null) {
/* 2669 */       boolean shouldClobber = this.connection.getClobberStreamingResults();
/*      */       
/* 2671 */       if (!shouldClobber) {
/* 2672 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.39") + this.streamingData + Messages.getString("MysqlIO.40") + Messages.getString("MysqlIO.41") + Messages.getString("MysqlIO.42"), getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2680 */       this.streamingData.getOwner().realClose(false);
/*      */ 
/*      */       
/* 2683 */       clearInputStream();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private Buffer compressPacket(Buffer packet, int offset, int packetLen, int headerLength) throws SQLException {
/* 2689 */     packet.writeLongInt(packetLen - headerLength);
/* 2690 */     packet.writeByte((byte)0);
/*      */     
/* 2692 */     int lengthToWrite = 0;
/* 2693 */     int compressedLength = 0;
/* 2694 */     byte[] bytesToCompress = packet.getByteBuffer();
/* 2695 */     byte[] compressedBytes = null;
/* 2696 */     int offsetWrite = 0;
/*      */     
/* 2698 */     if (packetLen < 50) {
/* 2699 */       lengthToWrite = packetLen;
/* 2700 */       compressedBytes = packet.getByteBuffer();
/* 2701 */       compressedLength = 0;
/* 2702 */       offsetWrite = offset;
/*      */     } else {
/* 2704 */       compressedBytes = new byte[bytesToCompress.length * 2];
/*      */       
/* 2706 */       this.deflater.reset();
/* 2707 */       this.deflater.setInput(bytesToCompress, offset, packetLen);
/* 2708 */       this.deflater.finish();
/*      */       
/* 2710 */       int compLen = this.deflater.deflate(compressedBytes);
/*      */       
/* 2712 */       if (compLen > packetLen) {
/* 2713 */         lengthToWrite = packetLen;
/* 2714 */         compressedBytes = packet.getByteBuffer();
/* 2715 */         compressedLength = 0;
/* 2716 */         offsetWrite = offset;
/*      */       } else {
/* 2718 */         lengthToWrite = compLen;
/* 2719 */         headerLength += 3;
/* 2720 */         compressedLength = packetLen;
/*      */       } 
/*      */     } 
/*      */     
/* 2724 */     Buffer compressedPacket = new Buffer(packetLen + headerLength);
/*      */     
/* 2726 */     compressedPacket.setPosition(0);
/* 2727 */     compressedPacket.writeLongInt(lengthToWrite);
/* 2728 */     compressedPacket.writeByte(this.packetSequence);
/* 2729 */     compressedPacket.writeLongInt(compressedLength);
/* 2730 */     compressedPacket.writeBytesNoNull(compressedBytes, offsetWrite, lengthToWrite);
/*      */ 
/*      */     
/* 2733 */     return compressedPacket;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void readServerStatusForResultSets(Buffer rowPacket) throws SQLException {
/* 2738 */     if (this.use41Extensions) {
/* 2739 */       rowPacket.readByte();
/*      */       
/* 2741 */       this.warningCount = rowPacket.readInt();
/*      */       
/* 2743 */       if (this.warningCount > 0) {
/* 2744 */         this.hadWarnings = true;
/*      */       }
/*      */       
/* 2747 */       this.oldServerStatus = this.serverStatus;
/* 2748 */       this.serverStatus = rowPacket.readInt();
/* 2749 */       checkTransactionState(this.oldServerStatus);
/*      */       
/* 2751 */       setServerSlowQueryFlags();
/*      */     } 
/*      */   }
/*      */   
/*      */   private SocketFactory createSocketFactory() throws SQLException {
/*      */     try {
/* 2757 */       if (this.socketFactoryClassName == null) {
/* 2758 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.75"), "08001", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */       
/* 2762 */       return (SocketFactory)Class.forName(this.socketFactoryClassName).newInstance();
/*      */     }
/* 2764 */     catch (Exception ex) {
/* 2765 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.76") + this.socketFactoryClassName + Messages.getString("MysqlIO.77"), "08001", getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2770 */       sqlEx.initCause(ex);
/*      */       
/* 2772 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void enqueuePacketForDebugging(boolean isPacketBeingSent, boolean isPacketReused, int sendLength, byte[] header, Buffer packet) throws SQLException {
/* 2779 */     if (this.packetDebugRingBuffer.size() + 1 > this.connection.getPacketDebugBufferSize()) {
/* 2780 */       this.packetDebugRingBuffer.removeFirst();
/*      */     }
/*      */     
/* 2783 */     StringBuffer packetDump = null;
/*      */     
/* 2785 */     if (!isPacketBeingSent) {
/* 2786 */       int bytesToDump = Math.min(1024, packet.getBufLength());
/*      */ 
/*      */       
/* 2789 */       Buffer packetToDump = new Buffer(4 + bytesToDump);
/*      */       
/* 2791 */       packetToDump.setPosition(0);
/* 2792 */       packetToDump.writeBytesNoNull(header);
/* 2793 */       packetToDump.writeBytesNoNull(packet.getBytes(0, bytesToDump));
/*      */       
/* 2795 */       String packetPayload = packetToDump.dump(bytesToDump);
/*      */       
/* 2797 */       packetDump = new StringBuffer(96 + packetPayload.length());
/*      */       
/* 2799 */       packetDump.append("Server ");
/*      */       
/* 2801 */       if (isPacketReused) {
/* 2802 */         packetDump.append("(re-used)");
/*      */       } else {
/* 2804 */         packetDump.append("(new)");
/*      */       } 
/*      */       
/* 2807 */       packetDump.append(" ");
/* 2808 */       packetDump.append(packet.toSuperString());
/* 2809 */       packetDump.append(" --------------------> Client\n");
/* 2810 */       packetDump.append("\nPacket payload:\n\n");
/* 2811 */       packetDump.append(packetPayload);
/*      */       
/* 2813 */       if (bytesToDump == 1024) {
/* 2814 */         packetDump.append("\nNote: Packet of " + packet.getBufLength() + " bytes truncated to " + 'Ѐ' + " bytes.\n");
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 2819 */       int bytesToDump = Math.min(1024, sendLength);
/*      */       
/* 2821 */       String packetPayload = packet.dump(bytesToDump);
/*      */       
/* 2823 */       packetDump = new StringBuffer(68 + packetPayload.length());
/*      */       
/* 2825 */       packetDump.append("Client ");
/* 2826 */       packetDump.append(packet.toSuperString());
/* 2827 */       packetDump.append("--------------------> Server\n");
/* 2828 */       packetDump.append("\nPacket payload:\n\n");
/* 2829 */       packetDump.append(packetPayload);
/*      */       
/* 2831 */       if (bytesToDump == 1024) {
/* 2832 */         packetDump.append("\nNote: Packet of " + sendLength + " bytes truncated to " + 'Ѐ' + " bytes.\n");
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2838 */     this.packetDebugRingBuffer.addLast(packetDump);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RowData readSingleRowSet(long columnCount, int maxRows, int resultSetConcurrency, boolean isBinaryEncoded, Field[] fields) throws SQLException {
/* 2845 */     ArrayList rows = new ArrayList();
/*      */     
/* 2847 */     boolean useBufferRowExplicit = useBufferRowExplicit(fields);
/*      */ 
/*      */     
/* 2850 */     ResultSetRow row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */ 
/*      */     
/* 2853 */     int rowCount = 0;
/*      */     
/* 2855 */     if (row != null) {
/* 2856 */       rows.add(row);
/* 2857 */       rowCount = 1;
/*      */     } 
/*      */     
/* 2860 */     while (row != null) {
/* 2861 */       row = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency, false, useBufferRowExplicit, false, null);
/*      */ 
/*      */       
/* 2864 */       if (row != null && (
/* 2865 */         maxRows == -1 || rowCount < maxRows)) {
/* 2866 */         rows.add(row);
/* 2867 */         rowCount++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2872 */     RowData rowData = new RowDataStatic(rows);
/*      */     
/* 2874 */     return rowData;
/*      */   }
/*      */   
/*      */   public static boolean useBufferRowExplicit(Field[] fields) {
/* 2878 */     if (fields == null) {
/* 2879 */       return false;
/*      */     }
/*      */     
/* 2882 */     for (int i = 0; i < fields.length; i++) {
/* 2883 */       switch (fields[i].getSQLType()) {
/*      */         case -4:
/*      */         case -1:
/*      */         case 2004:
/*      */         case 2005:
/* 2888 */           return true;
/*      */       } 
/*      */     
/*      */     } 
/* 2892 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void reclaimLargeReusablePacket() {
/* 2899 */     if (this.reusablePacket != null && this.reusablePacket.getCapacity() > 1048576)
/*      */     {
/* 2901 */       this.reusablePacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2916 */   private final Buffer reuseAndReadPacket(Buffer reuse) throws SQLException { return reuseAndReadPacket(reuse, -1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse, int existingPacketLength) throws SQLException { // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: iconst_0
/*      */     //   2: invokevirtual setWasMultiPacket : (Z)V
/*      */     //   5: iconst_0
/*      */     //   6: istore_3
/*      */     //   7: iload_2
/*      */     //   8: iconst_m1
/*      */     //   9: if_icmpne -> 94
/*      */     //   12: aload_0
/*      */     //   13: aload_0
/*      */     //   14: getfield mysqlInput : Ljava/io/InputStream;
/*      */     //   17: aload_0
/*      */     //   18: getfield packetHeaderBuf : [B
/*      */     //   21: iconst_0
/*      */     //   22: iconst_4
/*      */     //   23: invokespecial readFully : (Ljava/io/InputStream;[BII)I
/*      */     //   26: istore #4
/*      */     //   28: iload #4
/*      */     //   30: iconst_4
/*      */     //   31: if_icmpge -> 52
/*      */     //   34: aload_0
/*      */     //   35: invokevirtual forceClose : ()V
/*      */     //   38: new java/io/IOException
/*      */     //   41: dup
/*      */     //   42: ldc_w 'MysqlIO.43'
/*      */     //   45: invokestatic getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   48: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   51: athrow
/*      */     //   52: aload_0
/*      */     //   53: getfield packetHeaderBuf : [B
/*      */     //   56: iconst_0
/*      */     //   57: baload
/*      */     //   58: sipush #255
/*      */     //   61: iand
/*      */     //   62: aload_0
/*      */     //   63: getfield packetHeaderBuf : [B
/*      */     //   66: iconst_1
/*      */     //   67: baload
/*      */     //   68: sipush #255
/*      */     //   71: iand
/*      */     //   72: bipush #8
/*      */     //   74: ishl
/*      */     //   75: iadd
/*      */     //   76: aload_0
/*      */     //   77: getfield packetHeaderBuf : [B
/*      */     //   80: iconst_2
/*      */     //   81: baload
/*      */     //   82: sipush #255
/*      */     //   85: iand
/*      */     //   86: bipush #16
/*      */     //   88: ishl
/*      */     //   89: iadd
/*      */     //   90: istore_3
/*      */     //   91: goto -> 96
/*      */     //   94: iload_2
/*      */     //   95: istore_3
/*      */     //   96: aload_0
/*      */     //   97: getfield traceProtocol : Z
/*      */     //   100: ifeq -> 174
/*      */     //   103: new java/lang/StringBuffer
/*      */     //   106: dup
/*      */     //   107: invokespecial <init> : ()V
/*      */     //   110: astore #4
/*      */     //   112: aload #4
/*      */     //   114: ldc_w 'MysqlIO.44'
/*      */     //   117: invokestatic getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   123: pop
/*      */     //   124: aload #4
/*      */     //   126: iload_3
/*      */     //   127: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   130: pop
/*      */     //   131: aload #4
/*      */     //   133: ldc_w 'MysqlIO.45'
/*      */     //   136: invokestatic getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   139: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   142: pop
/*      */     //   143: aload #4
/*      */     //   145: aload_0
/*      */     //   146: getfield packetHeaderBuf : [B
/*      */     //   149: iconst_4
/*      */     //   150: invokestatic dumpAsHex : ([BI)Ljava/lang/String;
/*      */     //   153: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   156: pop
/*      */     //   157: aload_0
/*      */     //   158: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */     //   161: invokevirtual getLog : ()Lcom/mysql/jdbc/log/Log;
/*      */     //   164: aload #4
/*      */     //   166: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   169: invokeinterface logTrace : (Ljava/lang/Object;)V
/*      */     //   174: aload_0
/*      */     //   175: getfield packetHeaderBuf : [B
/*      */     //   178: iconst_3
/*      */     //   179: baload
/*      */     //   180: istore #4
/*      */     //   182: aload_0
/*      */     //   183: getfield packetSequenceReset : Z
/*      */     //   186: ifne -> 212
/*      */     //   189: aload_0
/*      */     //   190: getfield enablePacketDebug : Z
/*      */     //   193: ifeq -> 217
/*      */     //   196: aload_0
/*      */     //   197: getfield checkPacketSequence : Z
/*      */     //   200: ifeq -> 217
/*      */     //   203: aload_0
/*      */     //   204: iload #4
/*      */     //   206: invokespecial checkPacketSequencing : (B)V
/*      */     //   209: goto -> 217
/*      */     //   212: aload_0
/*      */     //   213: iconst_0
/*      */     //   214: putfield packetSequenceReset : Z
/*      */     //   217: aload_0
/*      */     //   218: iload #4
/*      */     //   220: putfield readPacketSequence : B
/*      */     //   223: aload_1
/*      */     //   224: iconst_0
/*      */     //   225: invokevirtual setPosition : (I)V
/*      */     //   228: aload_1
/*      */     //   229: invokevirtual getByteBuffer : ()[B
/*      */     //   232: arraylength
/*      */     //   233: iload_3
/*      */     //   234: if_icmpgt -> 246
/*      */     //   237: aload_1
/*      */     //   238: iload_3
/*      */     //   239: iconst_1
/*      */     //   240: iadd
/*      */     //   241: newarray byte
/*      */     //   243: invokevirtual setByteBuffer : ([B)V
/*      */     //   246: aload_1
/*      */     //   247: iload_3
/*      */     //   248: invokevirtual setBufLength : (I)V
/*      */     //   251: aload_0
/*      */     //   252: aload_0
/*      */     //   253: getfield mysqlInput : Ljava/io/InputStream;
/*      */     //   256: aload_1
/*      */     //   257: invokevirtual getByteBuffer : ()[B
/*      */     //   260: iconst_0
/*      */     //   261: iload_3
/*      */     //   262: invokespecial readFully : (Ljava/io/InputStream;[BII)I
/*      */     //   265: istore #5
/*      */     //   267: iload #5
/*      */     //   269: iload_3
/*      */     //   270: if_icmpeq -> 310
/*      */     //   273: new java/io/IOException
/*      */     //   276: dup
/*      */     //   277: new java/lang/StringBuffer
/*      */     //   280: dup
/*      */     //   281: invokespecial <init> : ()V
/*      */     //   284: ldc 'Short read, expected '
/*      */     //   286: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   289: iload_3
/*      */     //   290: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   293: ldc ' bytes, only read '
/*      */     //   295: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   298: iload #5
/*      */     //   300: invokevirtual append : (I)Ljava/lang/StringBuffer;
/*      */     //   303: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   306: invokespecial <init> : (Ljava/lang/String;)V
/*      */     //   309: athrow
/*      */     //   310: aload_0
/*      */     //   311: getfield traceProtocol : Z
/*      */     //   314: ifeq -> 366
/*      */     //   317: new java/lang/StringBuffer
/*      */     //   320: dup
/*      */     //   321: invokespecial <init> : ()V
/*      */     //   324: astore #6
/*      */     //   326: aload #6
/*      */     //   328: ldc_w 'MysqlIO.46'
/*      */     //   331: invokestatic getString : (Ljava/lang/String;)Ljava/lang/String;
/*      */     //   334: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   337: pop
/*      */     //   338: aload #6
/*      */     //   340: aload_1
/*      */     //   341: iload_3
/*      */     //   342: invokestatic getPacketDumpToLog : (Lcom/mysql/jdbc/Buffer;I)Ljava/lang/String;
/*      */     //   345: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   348: pop
/*      */     //   349: aload_0
/*      */     //   350: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */     //   353: invokevirtual getLog : ()Lcom/mysql/jdbc/log/Log;
/*      */     //   356: aload #6
/*      */     //   358: invokevirtual toString : ()Ljava/lang/String;
/*      */     //   361: invokeinterface logTrace : (Ljava/lang/Object;)V
/*      */     //   366: aload_0
/*      */     //   367: getfield enablePacketDebug : Z
/*      */     //   370: ifeq -> 385
/*      */     //   373: aload_0
/*      */     //   374: iconst_0
/*      */     //   375: iconst_1
/*      */     //   376: iconst_0
/*      */     //   377: aload_0
/*      */     //   378: getfield packetHeaderBuf : [B
/*      */     //   381: aload_1
/*      */     //   382: invokespecial enqueuePacketForDebugging : (ZZI[BLcom/mysql/jdbc/Buffer;)V
/*      */     //   385: iconst_0
/*      */     //   386: istore #6
/*      */     //   388: iload_3
/*      */     //   389: aload_0
/*      */     //   390: getfield maxThreeBytes : I
/*      */     //   393: if_icmpne -> 420
/*      */     //   396: aload_1
/*      */     //   397: aload_0
/*      */     //   398: getfield maxThreeBytes : I
/*      */     //   401: invokevirtual setPosition : (I)V
/*      */     //   404: iload_3
/*      */     //   405: istore #7
/*      */     //   407: iconst_1
/*      */     //   408: istore #6
/*      */     //   410: aload_0
/*      */     //   411: aload_1
/*      */     //   412: iload #4
/*      */     //   414: iload #7
/*      */     //   416: invokespecial readRemainingMultiPackets : (Lcom/mysql/jdbc/Buffer;BI)I
/*      */     //   419: istore_3
/*      */     //   420: iload #6
/*      */     //   422: ifne -> 432
/*      */     //   425: aload_1
/*      */     //   426: invokevirtual getByteBuffer : ()[B
/*      */     //   429: iload_3
/*      */     //   430: iconst_0
/*      */     //   431: bastore
/*      */     //   432: aload_0
/*      */     //   433: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */     //   436: invokevirtual getMaintainTimeStats : ()Z
/*      */     //   439: ifeq -> 449
/*      */     //   442: aload_0
/*      */     //   443: invokestatic currentTimeMillis : ()J
/*      */     //   446: putfield lastPacketReceivedTimeMs : J
/*      */     //   449: aload_1
/*      */     //   450: areturn
/*      */     //   451: astore_3
/*      */     //   452: aload_0
/*      */     //   453: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */     //   456: aload_0
/*      */     //   457: getfield lastPacketSentTimeMs : J
/*      */     //   460: aload_0
/*      */     //   461: getfield lastPacketReceivedTimeMs : J
/*      */     //   464: aload_3
/*      */     //   465: aload_0
/*      */     //   466: invokevirtual getExceptionInterceptor : ()Lcom/mysql/jdbc/ExceptionInterceptor;
/*      */     //   469: invokestatic createCommunicationsException : (Lcom/mysql/jdbc/ConnectionImpl;JJLjava/lang/Exception;Lcom/mysql/jdbc/ExceptionInterceptor;)Ljava/sql/SQLException;
/*      */     //   472: athrow
/*      */     //   473: astore_3
/*      */     //   474: aload_0
/*      */     //   475: invokevirtual clearInputStream : ()V
/*      */     //   478: jsr -> 492
/*      */     //   481: goto -> 511
/*      */     //   484: astore #8
/*      */     //   486: jsr -> 492
/*      */     //   489: aload #8
/*      */     //   491: athrow
/*      */     //   492: astore #9
/*      */     //   494: aload_0
/*      */     //   495: getfield connection : Lcom/mysql/jdbc/ConnectionImpl;
/*      */     //   498: iconst_0
/*      */     //   499: iconst_0
/*      */     //   500: iconst_1
/*      */     //   501: aload_3
/*      */     //   502: invokevirtual realClose : (ZZZLjava/lang/Throwable;)V
/*      */     //   505: aload_3
/*      */     //   506: athrow
/*      */     //   507: astore #10
/*      */     //   509: aload_3
/*      */     //   510: athrow
/*      */     //   511: goto -> 511
/*      */     // Line number table:
/*      */     //   Java source line number -> byte code offset
/*      */     //   #2923	-> 0
/*      */     //   #2924	-> 5
/*      */     //   #2926	-> 7
/*      */     //   #2927	-> 12
/*      */     //   #2930	-> 28
/*      */     //   #2931	-> 34
/*      */     //   #2932	-> 38
/*      */     //   #2935	-> 52
/*      */     //   #2939	-> 94
/*      */     //   #2942	-> 96
/*      */     //   #2943	-> 103
/*      */     //   #2945	-> 112
/*      */     //   #2946	-> 124
/*      */     //   #2947	-> 131
/*      */     //   #2948	-> 143
/*      */     //   #2951	-> 157
/*      */     //   #2954	-> 174
/*      */     //   #2956	-> 182
/*      */     //   #2957	-> 189
/*      */     //   #2958	-> 203
/*      */     //   #2961	-> 212
/*      */     //   #2964	-> 217
/*      */     //   #2967	-> 223
/*      */     //   #2975	-> 228
/*      */     //   #2976	-> 237
/*      */     //   #2980	-> 246
/*      */     //   #2983	-> 251
/*      */     //   #2986	-> 267
/*      */     //   #2987	-> 273
/*      */     //   #2991	-> 310
/*      */     //   #2992	-> 317
/*      */     //   #2994	-> 326
/*      */     //   #2995	-> 338
/*      */     //   #2998	-> 349
/*      */     //   #3001	-> 366
/*      */     //   #3002	-> 373
/*      */     //   #3006	-> 385
/*      */     //   #3008	-> 388
/*      */     //   #3009	-> 396
/*      */     //   #3011	-> 404
/*      */     //   #3014	-> 407
/*      */     //   #3016	-> 410
/*      */     //   #3020	-> 420
/*      */     //   #3021	-> 425
/*      */     //   #3024	-> 432
/*      */     //   #3025	-> 442
/*      */     //   #3028	-> 449
/*      */     //   #3029	-> 451
/*      */     //   #3030	-> 452
/*      */     //   #3032	-> 473
/*      */     //   #3035	-> 474
/*      */     //   #3036	-> 478
/*      */     //   #3042	-> 481
/*      */     //   #3037	-> 484
/*      */     //   #3038	-> 494
/*      */     //   #3040	-> 505
/*      */     //   #3045	-> 511
/*      */     // Local variable table:
/*      */     //   start	length	slot	name	descriptor
/*      */     //   28	63	4	lengthRead	I
/*      */     //   112	62	4	traceMessageBuf	Ljava/lang/StringBuffer;
/*      */     //   326	40	6	traceMessageBuf	Ljava/lang/StringBuffer;
/*      */     //   407	13	7	packetEndPoint	I
/*      */     //   7	444	3	packetLength	I
/*      */     //   182	269	4	multiPacketSeq	B
/*      */     //   267	184	5	numBytesRead	I
/*      */     //   388	63	6	isMultiPacket	Z
/*      */     //   452	21	3	ioEx	Ljava/io/IOException;
/*      */     //   474	37	3	oom	Ljava/lang/OutOfMemoryError;
/*      */     //   0	514	0	this	Lcom/mysql/jdbc/MysqlIO;
/*      */     //   0	514	1	reuse	Lcom/mysql/jdbc/Buffer;
/*      */     //   0	514	2	existingPacketLength	I
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	450	451	java/io/IOException
/*      */     //   0	450	473	java/lang/OutOfMemoryError
/*      */     //   474	481	484	finally
/*      */     //   484	489	484	finally
/*      */     //   494	505	507	finally
/*      */     //   507	509	507	finally }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int readRemainingMultiPackets(Buffer reuse, byte multiPacketSeq, int packetEndPoint) throws IOException, SQLException {
/* 3051 */     int lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */ 
/*      */     
/* 3054 */     if (lengthRead < 4) {
/* 3055 */       forceClose();
/* 3056 */       throw new IOException(Messages.getString("MysqlIO.47"));
/*      */     } 
/*      */     
/* 3059 */     int packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */ 
/*      */ 
/*      */     
/* 3063 */     Buffer multiPacket = new Buffer(packetLength);
/* 3064 */     boolean firstMultiPkt = true;
/*      */     
/*      */     while (true) {
/* 3067 */       if (!firstMultiPkt) {
/* 3068 */         lengthRead = readFully(this.mysqlInput, this.packetHeaderBuf, 0, 4);
/*      */ 
/*      */         
/* 3071 */         if (lengthRead < 4) {
/* 3072 */           forceClose();
/* 3073 */           throw new IOException(Messages.getString("MysqlIO.48"));
/*      */         } 
/*      */ 
/*      */         
/* 3077 */         packetLength = (this.packetHeaderBuf[0] & 0xFF) + ((this.packetHeaderBuf[1] & 0xFF) << 8) + ((this.packetHeaderBuf[2] & 0xFF) << 16);
/*      */       }
/*      */       else {
/*      */         
/* 3081 */         firstMultiPkt = false;
/*      */       } 
/*      */       
/* 3084 */       if (!this.useNewLargePackets && packetLength == 1) {
/* 3085 */         clearInputStream();
/*      */         break;
/*      */       } 
/* 3088 */       if (packetLength < this.maxThreeBytes) {
/* 3089 */         byte newPacketSeq = this.packetHeaderBuf[3];
/*      */         
/* 3091 */         if (newPacketSeq != multiPacketSeq + 1) {
/* 3092 */           throw new IOException(Messages.getString("MysqlIO.49"));
/*      */         }
/*      */ 
/*      */         
/* 3096 */         multiPacketSeq = newPacketSeq;
/*      */ 
/*      */         
/* 3099 */         multiPacket.setPosition(0);
/*      */ 
/*      */         
/* 3102 */         multiPacket.setBufLength(packetLength);
/*      */ 
/*      */         
/* 3105 */         byte[] byteBuf = multiPacket.getByteBuffer();
/* 3106 */         int lengthToWrite = packetLength;
/*      */         
/* 3108 */         int bytesRead = readFully(this.mysqlInput, byteBuf, 0, packetLength);
/*      */ 
/*      */         
/* 3111 */         if (bytesRead != lengthToWrite) {
/* 3112 */           throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, SQLError.createSQLException(Messages.getString("MysqlIO.50") + lengthToWrite + Messages.getString("MysqlIO.51") + bytesRead + ".", getExceptionInterceptor()), getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3122 */         reuse.writeBytesNoNull(byteBuf, 0, lengthToWrite);
/*      */         
/* 3124 */         packetEndPoint += lengthToWrite;
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 3129 */       byte newPacketSeq = this.packetHeaderBuf[3];
/*      */       
/* 3131 */       if (newPacketSeq != multiPacketSeq + 1) {
/* 3132 */         throw new IOException(Messages.getString("MysqlIO.53"));
/*      */       }
/*      */ 
/*      */       
/* 3136 */       multiPacketSeq = newPacketSeq;
/*      */ 
/*      */       
/* 3139 */       multiPacket.setPosition(0);
/*      */ 
/*      */       
/* 3142 */       multiPacket.setBufLength(packetLength);
/*      */ 
/*      */       
/* 3145 */       byte[] byteBuf = multiPacket.getByteBuffer();
/* 3146 */       int lengthToWrite = packetLength;
/*      */       
/* 3148 */       int bytesRead = readFully(this.mysqlInput, byteBuf, 0, packetLength);
/*      */ 
/*      */       
/* 3151 */       if (bytesRead != lengthToWrite) {
/* 3152 */         throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, SQLError.createSQLException(Messages.getString("MysqlIO.54") + lengthToWrite + Messages.getString("MysqlIO.55") + bytesRead + ".", getExceptionInterceptor()), getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3161 */       reuse.writeBytesNoNull(byteBuf, 0, lengthToWrite);
/*      */       
/* 3163 */       packetEndPoint += lengthToWrite;
/*      */     } 
/*      */     
/* 3166 */     reuse.setPosition(0);
/* 3167 */     reuse.setWasMultiPacket(true);
/* 3168 */     return packetLength;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkPacketSequencing(byte multiPacketSeq) throws SQLException {
/* 3177 */     if (multiPacketSeq == Byte.MIN_VALUE && this.readPacketSequence != Byte.MAX_VALUE) {
/* 3178 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -128, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3184 */     if (this.readPacketSequence == -1 && multiPacketSeq != 0) {
/* 3185 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # -1, but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3191 */     if (multiPacketSeq != Byte.MIN_VALUE && this.readPacketSequence != -1 && multiPacketSeq != this.readPacketSequence + 1)
/*      */     {
/* 3193 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, new IOException("Packets out of order, expected packet # " + (this.readPacketSequence + 1) + ", but received packet # " + multiPacketSeq), getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void enableMultiQueries() throws SQLException {
/* 3202 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3204 */     buf.clear();
/* 3205 */     buf.writeByte((byte)27);
/* 3206 */     buf.writeInt(0);
/* 3207 */     sendCommand(27, null, buf, false, null, 0);
/*      */   }
/*      */   
/*      */   void disableMultiQueries() throws SQLException {
/* 3211 */     Buffer buf = getSharedSendPacket();
/*      */     
/* 3213 */     buf.clear();
/* 3214 */     buf.writeByte((byte)27);
/* 3215 */     buf.writeInt(1);
/* 3216 */     sendCommand(27, null, buf, false, null, 0);
/*      */   }
/*      */ 
/*      */   
/*      */   private final void send(Buffer packet, int packetLen) throws SQLException {
/*      */     try {
/* 3222 */       if (this.maxAllowedPacket > 0 && packetLen > this.maxAllowedPacket) {
/* 3223 */         throw new PacketTooBigException(packetLen, this.maxAllowedPacket);
/*      */       }
/*      */       
/* 3226 */       if (this.serverMajorVersion >= 4 && packetLen >= this.maxThreeBytes) {
/*      */         
/* 3228 */         sendSplitPackets(packet);
/*      */       } else {
/* 3230 */         this.packetSequence = (byte)(this.packetSequence + 1);
/*      */         
/* 3232 */         Buffer packetToSend = packet;
/*      */         
/* 3234 */         packetToSend.setPosition(0);
/*      */         
/* 3236 */         if (this.useCompression) {
/* 3237 */           int originalPacketLen = packetLen;
/*      */           
/* 3239 */           packetToSend = compressPacket(packet, 0, packetLen, 4);
/*      */           
/* 3241 */           packetLen = packetToSend.getPosition();
/*      */           
/* 3243 */           if (this.traceProtocol) {
/* 3244 */             StringBuffer traceMessageBuf = new StringBuffer();
/*      */             
/* 3246 */             traceMessageBuf.append(Messages.getString("MysqlIO.57"));
/* 3247 */             traceMessageBuf.append(getPacketDumpToLog(packetToSend, packetLen));
/*      */             
/* 3249 */             traceMessageBuf.append(Messages.getString("MysqlIO.58"));
/* 3250 */             traceMessageBuf.append(getPacketDumpToLog(packet, originalPacketLen));
/*      */ 
/*      */             
/* 3253 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           } 
/*      */         } else {
/* 3256 */           packetToSend.writeLongInt(packetLen - 4);
/* 3257 */           packetToSend.writeByte(this.packetSequence);
/*      */           
/* 3259 */           if (this.traceProtocol) {
/* 3260 */             StringBuffer traceMessageBuf = new StringBuffer();
/*      */             
/* 3262 */             traceMessageBuf.append(Messages.getString("MysqlIO.59"));
/* 3263 */             traceMessageBuf.append(packetToSend.dump(packetLen));
/*      */             
/* 3265 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 3270 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */         
/* 3272 */         this.mysqlOutput.flush();
/*      */       } 
/*      */       
/* 3275 */       if (this.enablePacketDebug) {
/* 3276 */         enqueuePacketForDebugging(true, false, packetLen + 5, this.packetHeaderBuf, packet);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3283 */       if (packet == this.sharedSendPacket) {
/* 3284 */         reclaimLargeSharedSendPacket();
/*      */       }
/*      */       
/* 3287 */       if (this.connection.getMaintainTimeStats()) {
/* 3288 */         this.lastPacketSentTimeMs = System.currentTimeMillis();
/*      */       }
/* 3290 */     } catch (IOException ioEx) {
/* 3291 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ResultSetImpl sendFileToServer(StatementImpl callingStatement, String fileName) throws SQLException {
/* 3309 */     Buffer filePacket = (this.loadFileBufRef == null) ? null : this.loadFileBufRef.get();
/*      */ 
/*      */     
/* 3312 */     int bigPacketLength = Math.min(this.connection.getMaxAllowedPacket() - 12, alignPacketSize(this.connection.getMaxAllowedPacket() - 16, 4096) - 12);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3317 */     int oneMeg = 1048576;
/*      */     
/* 3319 */     int smallerPacketSizeAligned = Math.min(oneMeg - 12, alignPacketSize(oneMeg - 16, 4096) - 12);
/*      */ 
/*      */     
/* 3322 */     int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
/*      */     
/* 3324 */     if (filePacket == null) {
/*      */       try {
/* 3326 */         filePacket = new Buffer(packetLength + 4);
/* 3327 */         this.loadFileBufRef = new SoftReference(filePacket);
/* 3328 */       } catch (OutOfMemoryError oom) {
/* 3329 */         throw SQLError.createSQLException("Could not allocate packet of " + packetLength + " bytes required for LOAD DATA LOCAL INFILE operation." + " Try increasing max heap allocation for JVM or decreasing server variable " + "'max_allowed_packet'", "S1001", getExceptionInterceptor());
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3337 */     filePacket.clear();
/* 3338 */     send(filePacket, 0);
/*      */     
/* 3340 */     byte[] fileBuf = new byte[packetLength];
/*      */     
/* 3342 */     BufferedInputStream fileIn = null;
/*      */     
/*      */     try {
/* 3345 */       if (!this.connection.getAllowLoadLocalInfile()) {
/* 3346 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.LoadDataLocalNotAllowed"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 3351 */       InputStream hookedStream = null;
/*      */       
/* 3353 */       if (callingStatement != null) {
/* 3354 */         hookedStream = callingStatement.getLocalInfileInputStream();
/*      */       }
/*      */       
/* 3357 */       if (hookedStream != null) {
/* 3358 */         fileIn = new BufferedInputStream(hookedStream);
/* 3359 */       } else if (!this.connection.getAllowUrlInLocalInfile()) {
/* 3360 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       
/*      */       }
/* 3363 */       else if (fileName.indexOf(':') != -1) {
/*      */         try {
/* 3365 */           URL urlFromFileName = new URL(fileName);
/* 3366 */           fileIn = new BufferedInputStream(urlFromFileName.openStream());
/* 3367 */         } catch (MalformedURLException badUrlEx) {
/*      */           
/* 3369 */           fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */         } 
/*      */       } else {
/*      */         
/* 3373 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3378 */       int bytesRead = 0;
/*      */       
/* 3380 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 3381 */         filePacket.clear();
/* 3382 */         filePacket.writeBytesNoNull(fileBuf, 0, bytesRead);
/* 3383 */         send(filePacket, filePacket.getPosition());
/*      */       } 
/* 3385 */     } catch (IOException ioEx) {
/* 3386 */       StringBuffer messageBuf = new StringBuffer(Messages.getString("MysqlIO.60"));
/*      */ 
/*      */       
/* 3389 */       if (!this.connection.getParanoid()) {
/* 3390 */         messageBuf.append("'");
/*      */         
/* 3392 */         if (fileName != null) {
/* 3393 */           messageBuf.append(fileName);
/*      */         }
/*      */         
/* 3396 */         messageBuf.append("'");
/*      */       } 
/*      */       
/* 3399 */       messageBuf.append(Messages.getString("MysqlIO.63"));
/*      */       
/* 3401 */       if (!this.connection.getParanoid()) {
/* 3402 */         messageBuf.append(Messages.getString("MysqlIO.64"));
/* 3403 */         messageBuf.append(Util.stackTraceToString(ioEx));
/*      */       } 
/*      */       
/* 3406 */       throw SQLError.createSQLException(messageBuf.toString(), "S1009", getExceptionInterceptor());
/*      */     } finally {
/*      */       
/* 3409 */       if (fileIn != null) {
/*      */         try {
/* 3411 */           fileIn.close();
/* 3412 */         } catch (Exception ex) {
/* 3413 */           SQLException sqlEx = SQLError.createSQLException(Messages.getString("MysqlIO.65"), "S1000", getExceptionInterceptor());
/*      */           
/* 3415 */           sqlEx.initCause(ex);
/*      */           
/* 3417 */           throw sqlEx;
/*      */         } 
/*      */         
/* 3420 */         fileIn = null;
/*      */       } else {
/*      */         
/* 3423 */         filePacket.clear();
/* 3424 */         send(filePacket, filePacket.getPosition());
/* 3425 */         checkErrorPacket();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3430 */     filePacket.clear();
/* 3431 */     send(filePacket, filePacket.getPosition());
/*      */     
/* 3433 */     Buffer resultPacket = checkErrorPacket();
/*      */     
/* 3435 */     return buildResultSetWithUpdates(callingStatement, resultPacket);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Buffer checkErrorPacket(int command) throws SQLException {
/* 3450 */     int statusCode = 0;
/* 3451 */     Buffer resultPacket = null;
/* 3452 */     this.serverStatus = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3459 */       resultPacket = reuseAndReadPacket(this.reusablePacket);
/* 3460 */     } catch (SQLException sqlEx) {
/*      */       
/* 3462 */       throw sqlEx;
/* 3463 */     } catch (Exception fallThru) {
/* 3464 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, fallThru, getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */     
/* 3468 */     checkErrorPacket(resultPacket);
/*      */     
/* 3470 */     return resultPacket;
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkErrorPacket(Buffer resultPacket) throws SQLException {
/* 3475 */     int statusCode = resultPacket.readByte();
/*      */ 
/*      */     
/* 3478 */     if (statusCode == -1) {
/*      */       
/* 3480 */       int errno = 2000;
/*      */       
/* 3482 */       if (this.protocolVersion > 9) {
/* 3483 */         errno = resultPacket.readInt();
/*      */         
/* 3485 */         String xOpen = null;
/*      */         
/* 3487 */         String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */ 
/*      */         
/* 3490 */         if (serverErrorMessage.charAt(0) == '#') {
/*      */ 
/*      */           
/* 3493 */           if (serverErrorMessage.length() > 6) {
/* 3494 */             xOpen = serverErrorMessage.substring(1, 6);
/* 3495 */             serverErrorMessage = serverErrorMessage.substring(6);
/*      */             
/* 3497 */             if (xOpen.equals("HY000")) {
/* 3498 */               xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */             }
/*      */           } else {
/*      */             
/* 3502 */             xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */           } 
/*      */         } else {
/*      */           
/* 3506 */           xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */         } 
/*      */ 
/*      */         
/* 3510 */         clearInputStream();
/*      */         
/* 3512 */         StringBuffer errorBuf = new StringBuffer();
/*      */         
/* 3514 */         String xOpenErrorMessage = SQLError.get(xOpen);
/*      */         
/* 3516 */         if (!this.connection.getUseOnlyServerErrorMessages() && 
/* 3517 */           xOpenErrorMessage != null) {
/* 3518 */           errorBuf.append(xOpenErrorMessage);
/* 3519 */           errorBuf.append(Messages.getString("MysqlIO.68"));
/*      */         } 
/*      */ 
/*      */         
/* 3523 */         errorBuf.append(serverErrorMessage);
/*      */         
/* 3525 */         if (!this.connection.getUseOnlyServerErrorMessages() && 
/* 3526 */           xOpenErrorMessage != null) {
/* 3527 */           errorBuf.append("\"");
/*      */         }
/*      */ 
/*      */         
/* 3531 */         appendInnodbStatusInformation(xOpen, errorBuf);
/*      */         
/* 3533 */         if (xOpen != null && xOpen.startsWith("22")) {
/* 3534 */           throw new MysqlDataTruncation(errorBuf.toString(), 0, true, false, 0, 0);
/*      */         }
/* 3536 */         throw SQLError.createSQLException(errorBuf.toString(), xOpen, errno, getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */       
/* 3540 */       String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding(), getExceptionInterceptor());
/*      */       
/* 3542 */       clearInputStream();
/*      */       
/* 3544 */       if (serverErrorMessage.indexOf(Messages.getString("MysqlIO.70")) != -1) {
/* 3545 */         throw SQLError.createSQLException(SQLError.get("S0022") + ", " + serverErrorMessage, "S0022", -1, getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3552 */       StringBuffer errorBuf = new StringBuffer(Messages.getString("MysqlIO.72"));
/*      */       
/* 3554 */       errorBuf.append(serverErrorMessage);
/* 3555 */       errorBuf.append("\"");
/*      */       
/* 3557 */       throw SQLError.createSQLException(SQLError.get("S1000") + ", " + errorBuf.toString(), "S1000", -1, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void appendInnodbStatusInformation(String xOpen, StringBuffer errorBuf) throws SQLException {
/* 3565 */     if (this.connection.getIncludeInnodbStatusInDeadlockExceptions() && xOpen != null && (xOpen.startsWith("40") || xOpen.startsWith("41")) && this.streamingData == null) {
/*      */ 
/*      */ 
/*      */       
/* 3569 */       ResultSet rs = null;
/*      */       
/*      */       try {
/* 3572 */         rs = sqlQueryDirect(null, "SHOW ENGINE INNODB STATUS", this.connection.getEncoding(), null, -1, 1003, 1007, false, this.connection.getCatalog(), null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3578 */         if (rs.next()) {
/* 3579 */           errorBuf.append("\n\n");
/* 3580 */           errorBuf.append(rs.getString("Status"));
/*      */         } else {
/* 3582 */           errorBuf.append("\n\n");
/* 3583 */           errorBuf.append(Messages.getString("MysqlIO.NoInnoDBStatusFound"));
/*      */         }
/*      */       
/* 3586 */       } catch (Exception ex) {
/* 3587 */         errorBuf.append("\n\n");
/* 3588 */         errorBuf.append(Messages.getString("MysqlIO.InnoDBStatusFailed"));
/*      */         
/* 3590 */         errorBuf.append("\n\n");
/* 3591 */         errorBuf.append(Util.stackTraceToString(ex));
/*      */       } finally {
/* 3593 */         if (rs != null) {
/* 3594 */           rs.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void sendSplitPackets(Buffer packet) throws SQLException {
/*      */     try {
/* 3620 */       Buffer headerPacket = (this.splitBufRef == null) ? null : this.splitBufRef.get();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3628 */       if (headerPacket == null) {
/* 3629 */         headerPacket = new Buffer(this.maxThreeBytes + 4);
/*      */         
/* 3631 */         this.splitBufRef = new SoftReference(headerPacket);
/*      */       } 
/*      */       
/* 3634 */       int len = packet.getPosition();
/* 3635 */       int splitSize = this.maxThreeBytes;
/* 3636 */       int originalPacketPos = 4;
/* 3637 */       byte[] origPacketBytes = packet.getByteBuffer();
/* 3638 */       byte[] headerPacketBytes = headerPacket.getByteBuffer();
/*      */       
/* 3640 */       while (len >= this.maxThreeBytes) {
/* 3641 */         this.packetSequence = (byte)(this.packetSequence + 1);
/*      */         
/* 3643 */         headerPacket.setPosition(0);
/* 3644 */         headerPacket.writeLongInt(splitSize);
/*      */         
/* 3646 */         headerPacket.writeByte(this.packetSequence);
/* 3647 */         System.arraycopy(origPacketBytes, originalPacketPos, headerPacketBytes, 4, splitSize);
/*      */ 
/*      */         
/* 3650 */         int packetLen = splitSize + 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3656 */         if (!this.useCompression) {
/* 3657 */           this.mysqlOutput.write(headerPacketBytes, 0, splitSize + 4);
/*      */           
/* 3659 */           this.mysqlOutput.flush();
/*      */         }
/*      */         else {
/*      */           
/* 3663 */           headerPacket.setPosition(0);
/* 3664 */           Buffer packetToSend = compressPacket(headerPacket, 4, splitSize, 4);
/*      */           
/* 3666 */           packetLen = packetToSend.getPosition();
/*      */           
/* 3668 */           this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */           
/* 3670 */           this.mysqlOutput.flush();
/*      */         } 
/*      */         
/* 3673 */         originalPacketPos += splitSize;
/* 3674 */         len -= splitSize;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3680 */       headerPacket.clear();
/* 3681 */       headerPacket.setPosition(0);
/* 3682 */       headerPacket.writeLongInt(len - 4);
/* 3683 */       this.packetSequence = (byte)(this.packetSequence + 1);
/* 3684 */       headerPacket.writeByte(this.packetSequence);
/*      */       
/* 3686 */       if (len != 0) {
/* 3687 */         System.arraycopy(origPacketBytes, originalPacketPos, headerPacketBytes, 4, len - 4);
/*      */       }
/*      */ 
/*      */       
/* 3691 */       int packetLen = len - 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3697 */       if (!this.useCompression) {
/* 3698 */         this.mysqlOutput.write(headerPacket.getByteBuffer(), 0, len);
/* 3699 */         this.mysqlOutput.flush();
/*      */       }
/*      */       else {
/*      */         
/* 3703 */         headerPacket.setPosition(0);
/* 3704 */         Buffer packetToSend = compressPacket(headerPacket, 4, packetLen, 4);
/*      */         
/* 3706 */         packetLen = packetToSend.getPosition();
/*      */         
/* 3708 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */         
/* 3710 */         this.mysqlOutput.flush();
/*      */       } 
/* 3712 */     } catch (IOException ioEx) {
/* 3713 */       throw SQLError.createCommunicationsException(this.connection, this.lastPacketSentTimeMs, this.lastPacketReceivedTimeMs, ioEx, getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void reclaimLargeSharedSendPacket() {
/* 3719 */     if (this.sharedSendPacket != null && this.sharedSendPacket.getCapacity() > 1048576)
/*      */     {
/* 3721 */       this.sharedSendPacket = new Buffer(1024);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/* 3726 */   boolean hadWarnings() { return this.hadWarnings; }
/*      */ 
/*      */   
/*      */   void scanForAndThrowDataTruncation() throws SQLException {
/* 3730 */     if (this.streamingData == null && versionMeetsMinimum(4, 1, 0) && this.connection.getJdbcCompliantTruncation() && this.warningCount > 0)
/*      */     {
/* 3732 */       SQLError.convertShowWarningsToSQLWarnings(this.connection, this.warningCount, true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void secureAuth(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams) throws SQLException {
/* 3753 */     if (packet == null) {
/* 3754 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 3757 */     if (writeClientParams) {
/* 3758 */       if (this.use41Extensions) {
/* 3759 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 3760 */           packet.writeLong(this.clientParam);
/* 3761 */           packet.writeLong(this.maxThreeBytes);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3766 */           packet.writeByte((byte)8);
/*      */ 
/*      */           
/* 3769 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 3771 */           packet.writeLong(this.clientParam);
/* 3772 */           packet.writeLong(this.maxThreeBytes);
/*      */         } 
/*      */       } else {
/* 3775 */         packet.writeInt((int)this.clientParam);
/* 3776 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3781 */     packet.writeString(user, "Cp1252", this.connection);
/*      */     
/* 3783 */     if (password.length() != 0) {
/*      */       
/* 3785 */       packet.writeString("xxxxxxxx", "Cp1252", this.connection);
/*      */     } else {
/*      */       
/* 3788 */       packet.writeString("", "Cp1252", this.connection);
/*      */     } 
/*      */     
/* 3791 */     if (this.useConnectWithDb) {
/* 3792 */       packet.writeString(database, "Cp1252", this.connection);
/*      */     }
/*      */     
/* 3795 */     send(packet, packet.getPosition());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3800 */     if (password.length() > 0) {
/* 3801 */       Buffer b = readPacket();
/*      */       
/* 3803 */       b.setPosition(0);
/*      */       
/* 3805 */       byte[] replyAsBytes = b.getByteBuffer();
/*      */       
/* 3807 */       if (replyAsBytes.length == 25 && replyAsBytes[0] != 0)
/*      */       {
/* 3809 */         if (replyAsBytes[0] != 42) {
/*      */           
/*      */           try {
/* 3812 */             byte[] buff = Security.passwordHashStage1(password);
/*      */ 
/*      */             
/* 3815 */             byte[] passwordHash = new byte[buff.length];
/* 3816 */             System.arraycopy(buff, 0, passwordHash, 0, buff.length);
/*      */ 
/*      */             
/* 3819 */             passwordHash = Security.passwordHashStage2(passwordHash, replyAsBytes);
/*      */ 
/*      */             
/* 3822 */             byte[] packetDataAfterSalt = new byte[replyAsBytes.length - 5];
/*      */ 
/*      */             
/* 3825 */             System.arraycopy(replyAsBytes, 4, packetDataAfterSalt, 0, replyAsBytes.length - 5);
/*      */ 
/*      */             
/* 3828 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */ 
/*      */             
/* 3831 */             Security.passwordCrypt(packetDataAfterSalt, mysqlScrambleBuff, passwordHash, 20);
/*      */ 
/*      */ 
/*      */             
/* 3835 */             Security.passwordCrypt(mysqlScrambleBuff, buff, buff, 20);
/*      */             
/* 3837 */             Buffer packet2 = new Buffer(25);
/* 3838 */             packet2.writeBytesNoNull(buff);
/*      */             
/* 3840 */             this.packetSequence = (byte)(this.packetSequence + 1);
/*      */             
/* 3842 */             send(packet2, 24);
/* 3843 */           } catch (NoSuchAlgorithmException nse) {
/* 3844 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000", getExceptionInterceptor());
/*      */           } 
/*      */         } else {
/*      */ 
/*      */           
/*      */           try {
/*      */             
/* 3851 */             byte[] passwordHash = Security.createKeyFromOldPassword(password);
/*      */ 
/*      */             
/* 3854 */             byte[] netReadPos4 = new byte[replyAsBytes.length - 5];
/*      */             
/* 3856 */             System.arraycopy(replyAsBytes, 4, netReadPos4, 0, replyAsBytes.length - 5);
/*      */ 
/*      */             
/* 3859 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */ 
/*      */             
/* 3862 */             Security.passwordCrypt(netReadPos4, mysqlScrambleBuff, passwordHash, 20);
/*      */ 
/*      */ 
/*      */             
/* 3866 */             String scrambledPassword = Util.scramble(new String(mysqlScrambleBuff), password);
/*      */ 
/*      */             
/* 3869 */             Buffer packet2 = new Buffer(packLength);
/* 3870 */             packet2.writeString(scrambledPassword, "Cp1252", this.connection);
/* 3871 */             this.packetSequence = (byte)(this.packetSequence + 1);
/*      */             
/* 3873 */             send(packet2, 24);
/* 3874 */           } catch (NoSuchAlgorithmException nse) {
/* 3875 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.93") + Messages.getString("MysqlIO.94"), "S1000", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void secureAuth411(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams) throws SQLException {
/* 3917 */     if (packet == null) {
/* 3918 */       packet = new Buffer(packLength);
/*      */     }
/*      */     
/* 3921 */     if (writeClientParams) {
/* 3922 */       if (this.use41Extensions) {
/* 3923 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 3924 */           packet.writeLong(this.clientParam);
/* 3925 */           packet.writeLong(this.maxThreeBytes);
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3930 */           packet.writeByte((byte)33);
/*      */ 
/*      */           
/* 3933 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 3935 */           packet.writeLong(this.clientParam);
/* 3936 */           packet.writeLong(this.maxThreeBytes);
/*      */         } 
/*      */       } else {
/* 3939 */         packet.writeInt((int)this.clientParam);
/* 3940 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 3945 */     packet.writeString(user, "utf-8", this.connection);
/*      */     
/* 3947 */     if (password.length() != 0) {
/* 3948 */       packet.writeByte((byte)20);
/*      */       
/*      */       try {
/* 3951 */         packet.writeBytesNoNull(Security.scramble411(password, this.seed, this.connection));
/* 3952 */       } catch (NoSuchAlgorithmException nse) {
/* 3953 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000", getExceptionInterceptor());
/*      */       
/*      */       }
/* 3956 */       catch (UnsupportedEncodingException e) {
/* 3957 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000", getExceptionInterceptor());
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3963 */       packet.writeByte((byte)0);
/*      */     } 
/*      */     
/* 3966 */     if (this.useConnectWithDb) {
/* 3967 */       packet.writeString(database, "utf-8", this.connection);
/*      */     }
/*      */     
/* 3970 */     send(packet, packet.getPosition());
/*      */     
/* 3972 */     byte savePacketSequence = this.packetSequence = (byte)(this.packetSequence + 1);
/*      */     
/* 3974 */     Buffer reply = checkErrorPacket();
/*      */     
/* 3976 */     if (reply.isLastDataPacket()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3981 */       this.packetSequence = savePacketSequence = (byte)(savePacketSequence + 1);
/* 3982 */       packet.clear();
/*      */       
/* 3984 */       String seed323 = this.seed.substring(0, 8);
/* 3985 */       packet.writeString(Util.newCrypt(password, seed323));
/* 3986 */       send(packet, packet.getPosition());
/*      */ 
/*      */       
/* 3989 */       checkErrorPacket();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final ResultSetRow unpackBinaryResultSetRow(Field[] fields, Buffer binaryData, int resultSetConcurrency) throws SQLException {
/* 4006 */     int numFields = fields.length;
/*      */     
/* 4008 */     byte[][] unpackedRowData = new byte[numFields][];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4015 */     int nullCount = (numFields + 9) / 8;
/*      */     
/* 4017 */     byte[] nullBitMask = new byte[nullCount];
/*      */     
/* 4019 */     for (int i = 0; i < nullCount; i++) {
/* 4020 */       nullBitMask[i] = binaryData.readByte();
/*      */     }
/*      */     
/* 4023 */     int nullMaskPos = 0;
/* 4024 */     int bit = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4031 */     for (int i = 0; i < numFields; i++) {
/* 4032 */       if ((nullBitMask[nullMaskPos] & bit) != 0) {
/* 4033 */         unpackedRowData[i] = null;
/*      */       }
/* 4035 */       else if (resultSetConcurrency != 1008) {
/* 4036 */         extractNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       } else {
/*      */         
/* 4039 */         unpackNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4044 */       if ((bit <<= 1 & 0xFF) == 0) {
/* 4045 */         bit = 1;
/*      */         
/* 4047 */         nullMaskPos++;
/*      */       } 
/*      */     } 
/*      */     
/* 4051 */     return new ByteArrayRow(unpackedRowData, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   private final void extractNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData) throws SQLException
/*      */   {
/*      */     int length, length, length;
/* 4057 */     Field curField = fields[columnIndex];
/*      */     
/* 4059 */     switch (curField.getMysqlType()) {
/*      */       case 6:
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/* 4065 */         (new byte[1])[0] = binaryData.readByte(); unpackedRowData[columnIndex] = new byte[1];
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 4071 */         unpackedRowData[columnIndex] = binaryData.getBytes(2);
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 9:
/* 4076 */         unpackedRowData[columnIndex] = binaryData.getBytes(4);
/*      */ 
/*      */       
/*      */       case 8:
/* 4080 */         unpackedRowData[columnIndex] = binaryData.getBytes(8);
/*      */ 
/*      */       
/*      */       case 4:
/* 4084 */         unpackedRowData[columnIndex] = binaryData.getBytes(4);
/*      */ 
/*      */       
/*      */       case 5:
/* 4088 */         unpackedRowData[columnIndex] = binaryData.getBytes(8);
/*      */ 
/*      */       
/*      */       case 11:
/* 4092 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4094 */         unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */ 
/*      */ 
/*      */       
/*      */       case 10:
/* 4099 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4101 */         unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */ 
/*      */       
/*      */       case 7:
/*      */       case 12:
/* 4106 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4108 */         unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */       
/*      */       case 0:
/*      */       case 15:
/*      */       case 246:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/*      */       case 253:
/*      */       case 254:
/*      */       case 255:
/* 4120 */         unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */ 
/*      */       
/*      */       case 16:
/* 4124 */         unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */     } 
/*      */ 
/*      */     
/* 4128 */     throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor()); } private final void unpackNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, byte[][] unpackedRowData) throws SQLException { boolean bool; byte b; byte[] arrayOfByte3, arrayOfByte2;
/*      */     int m, nanos, k, i;
/*      */     byte[] arrayOfByte1;
/*      */     int day, day, month, month, year, year;
/*      */     byte[] timeAsBytes;
/*      */     int seconds, seconds, seconds, minute, minute, minute, hour, hour, hour, length, length, length;
/*      */     double doubleVal;
/*      */     float floatVal;
/*      */     long longVal;
/*      */     int intVal;
/*      */     short shortVal;
/*      */     byte tinyVal;
/* 4140 */     Field curField = fields[columnIndex];
/*      */     
/* 4142 */     switch (curField.getMysqlType()) {
/*      */       case 6:
/*      */         return;
/*      */ 
/*      */       
/*      */       case 1:
/* 4148 */         tinyVal = binaryData.readByte();
/*      */         
/* 4150 */         if (!curField.isUnsigned()) {
/* 4151 */           unpackedRowData[columnIndex] = String.valueOf(tinyVal).getBytes();
/*      */         } else {
/*      */           
/* 4154 */           short unsignedTinyVal = (short)(tinyVal & 0xFF);
/*      */           
/* 4156 */           unpackedRowData[columnIndex] = String.valueOf(unsignedTinyVal).getBytes();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 4165 */         shortVal = (short)binaryData.readInt();
/*      */         
/* 4167 */         if (!curField.isUnsigned()) {
/* 4168 */           unpackedRowData[columnIndex] = String.valueOf(shortVal).getBytes();
/*      */         } else {
/*      */           
/* 4171 */           int unsignedShortVal = shortVal & 0xFFFF;
/*      */           
/* 4173 */           unpackedRowData[columnIndex] = String.valueOf(unsignedShortVal).getBytes();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/*      */       case 9:
/* 4182 */         intVal = (int)binaryData.readLong();
/*      */         
/* 4184 */         if (!curField.isUnsigned()) {
/* 4185 */           unpackedRowData[columnIndex] = String.valueOf(intVal).getBytes();
/*      */         } else {
/*      */           
/* 4188 */           long longVal = intVal & 0xFFFFFFFFL;
/*      */           
/* 4190 */           unpackedRowData[columnIndex] = String.valueOf(longVal).getBytes();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/* 4198 */         longVal = binaryData.readLongLong();
/*      */         
/* 4200 */         if (!curField.isUnsigned()) {
/* 4201 */           unpackedRowData[columnIndex] = String.valueOf(longVal).getBytes();
/*      */         } else {
/*      */           
/* 4204 */           BigInteger asBigInteger = ResultSetImpl.convertLongToUlong(longVal);
/*      */           
/* 4206 */           unpackedRowData[columnIndex] = asBigInteger.toString().getBytes();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/* 4214 */         floatVal = Float.intBitsToFloat(binaryData.readIntAsLong());
/*      */         
/* 4216 */         unpackedRowData[columnIndex] = String.valueOf(floatVal).getBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 4222 */         doubleVal = Double.longBitsToDouble(binaryData.readLongLong());
/*      */         
/* 4224 */         unpackedRowData[columnIndex] = String.valueOf(doubleVal).getBytes();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 11:
/* 4230 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4232 */         hour = 0;
/* 4233 */         minute = 0;
/* 4234 */         seconds = 0;
/*      */         
/* 4236 */         if (length != 0) {
/* 4237 */           binaryData.readByte();
/* 4238 */           binaryData.readLong();
/* 4239 */           hour = binaryData.readByte();
/* 4240 */           minute = binaryData.readByte();
/* 4241 */           seconds = binaryData.readByte();
/*      */           
/* 4243 */           if (length > 8) {
/* 4244 */             binaryData.readLong();
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/* 4249 */         timeAsBytes = new byte[8];
/*      */         
/* 4251 */         timeAsBytes[0] = (byte)Character.forDigit(hour / 10, 10);
/* 4252 */         timeAsBytes[1] = (byte)Character.forDigit(hour % 10, 10);
/*      */         
/* 4254 */         timeAsBytes[2] = 58;
/*      */         
/* 4256 */         timeAsBytes[3] = (byte)Character.forDigit(minute / 10, 10);
/*      */         
/* 4258 */         timeAsBytes[4] = (byte)Character.forDigit(minute % 10, 10);
/*      */ 
/*      */         
/* 4261 */         timeAsBytes[5] = 58;
/*      */         
/* 4263 */         timeAsBytes[6] = (byte)Character.forDigit(seconds / 10, 10);
/*      */         
/* 4265 */         timeAsBytes[7] = (byte)Character.forDigit(seconds % 10, 10);
/*      */ 
/*      */         
/* 4268 */         unpackedRowData[columnIndex] = timeAsBytes;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 10:
/* 4274 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4276 */         year = 0;
/* 4277 */         month = 0;
/* 4278 */         day = 0;
/*      */         
/* 4280 */         hour = 0;
/* 4281 */         minute = 0;
/* 4282 */         seconds = 0;
/*      */         
/* 4284 */         if (length != 0) {
/* 4285 */           year = binaryData.readInt();
/* 4286 */           month = binaryData.readByte();
/* 4287 */           day = binaryData.readByte();
/*      */         } 
/*      */         
/* 4290 */         if (year == 0 && month == 0 && day == 0)
/* 4291 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           
/* 4293 */           { unpackedRowData[columnIndex] = null; }
/*      */           else
/*      */           
/* 4296 */           { if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */             {
/* 4298 */               throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */             }
/*      */ 
/*      */             
/* 4302 */             year = 1;
/* 4303 */             month = 1;
/* 4304 */             day = 1;
/*      */ 
/*      */ 
/*      */             
/* 4308 */             byte[] dateAsBytes = new byte[10];
/*      */             
/* 4310 */             dateAsBytes[0] = (byte)Character.forDigit(year / 1000, 10);
/*      */ 
/*      */             
/* 4313 */             int after1000 = year % 1000;
/*      */             
/* 4315 */             dateAsBytes[1] = (byte)Character.forDigit(after1000 / 100, 10);
/*      */ 
/*      */             
/* 4318 */             int after100 = after1000 % 100;
/*      */             
/* 4320 */             dateAsBytes[2] = (byte)Character.forDigit(after100 / 10, 10);
/*      */             
/* 4322 */             dateAsBytes[3] = (byte)Character.forDigit(after100 % 10, 10);
/*      */ 
/*      */             
/* 4325 */             dateAsBytes[4] = 45;
/*      */             
/* 4327 */             dateAsBytes[5] = (byte)Character.forDigit(month / 10, 10);
/*      */             
/* 4329 */             dateAsBytes[6] = (byte)Character.forDigit(month % 10, 10);
/*      */ 
/*      */             
/* 4332 */             dateAsBytes[7] = 45;
/*      */             
/* 4334 */             dateAsBytes[8] = (byte)Character.forDigit(day / 10, 10);
/* 4335 */             dateAsBytes[9] = (byte)Character.forDigit(day % 10, 10);
/*      */             
/* 4337 */             unpackedRowData[columnIndex] = dateAsBytes; }   arrayOfByte1 = new byte[10]; arrayOfByte1[0] = (byte)Character.forDigit(year / 1000, 10); i = year % 1000; arrayOfByte1[1] = (byte)Character.forDigit(i / 100, 10); k = i % 100; arrayOfByte1[2] = (byte)Character.forDigit(k / 10, 10); arrayOfByte1[3] = (byte)Character.forDigit(k % 10, 10); arrayOfByte1[4] = 45; arrayOfByte1[5] = (byte)Character.forDigit(month / 10, 10); arrayOfByte1[6] = (byte)Character.forDigit(month % 10, 10); arrayOfByte1[7] = 45; arrayOfByte1[8] = (byte)Character.forDigit(day / 10, 10); arrayOfByte1[9] = (byte)Character.forDigit(day % 10, 10); unpackedRowData[columnIndex] = arrayOfByte1;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 7:
/*      */       case 12:
/* 4344 */         length = (int)binaryData.readFieldLength();
/*      */         
/* 4346 */         year = 0;
/* 4347 */         month = 0;
/* 4348 */         day = 0;
/*      */         
/* 4350 */         hour = 0;
/* 4351 */         minute = 0;
/* 4352 */         seconds = 0;
/*      */         
/* 4354 */         nanos = 0;
/*      */         
/* 4356 */         if (length != 0) {
/* 4357 */           year = binaryData.readInt();
/* 4358 */           month = binaryData.readByte();
/* 4359 */           day = binaryData.readByte();
/*      */           
/* 4361 */           if (length > 4) {
/* 4362 */             hour = binaryData.readByte();
/* 4363 */             minute = binaryData.readByte();
/* 4364 */             seconds = binaryData.readByte();
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4372 */         if (year == 0 && month == 0 && day == 0)
/* 4373 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           
/* 4375 */           { unpackedRowData[columnIndex] = null; }
/*      */           else
/*      */           
/* 4378 */           { if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */             {
/* 4380 */               throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */             }
/*      */ 
/*      */             
/* 4384 */             year = 1;
/* 4385 */             month = 1;
/* 4386 */             day = 1;
/*      */ 
/*      */ 
/*      */             
/* 4390 */             int stringLength = 19;
/*      */             
/* 4392 */             byte[] nanosAsBytes = Integer.toString(nanos).getBytes();
/*      */             
/* 4394 */             stringLength += 1 + nanosAsBytes.length;
/*      */             
/* 4396 */             byte[] datetimeAsBytes = new byte[stringLength];
/*      */             
/* 4398 */             datetimeAsBytes[0] = (byte)Character.forDigit(year / 1000, 10);
/*      */ 
/*      */             
/* 4401 */             int after1000 = year % 1000;
/*      */             
/* 4403 */             datetimeAsBytes[1] = (byte)Character.forDigit(after1000 / 100, 10);
/*      */ 
/*      */             
/* 4406 */             int after100 = after1000 % 100;
/*      */             
/* 4408 */             datetimeAsBytes[2] = (byte)Character.forDigit(after100 / 10, 10);
/*      */             
/* 4410 */             datetimeAsBytes[3] = (byte)Character.forDigit(after100 % 10, 10);
/*      */ 
/*      */             
/* 4413 */             datetimeAsBytes[4] = 45;
/*      */             
/* 4415 */             datetimeAsBytes[5] = (byte)Character.forDigit(month / 10, 10);
/*      */             
/* 4417 */             datetimeAsBytes[6] = (byte)Character.forDigit(month % 10, 10);
/*      */ 
/*      */             
/* 4420 */             datetimeAsBytes[7] = 45;
/*      */             
/* 4422 */             datetimeAsBytes[8] = (byte)Character.forDigit(day / 10, 10);
/*      */             
/* 4424 */             datetimeAsBytes[9] = (byte)Character.forDigit(day % 10, 10);
/*      */ 
/*      */             
/* 4427 */             datetimeAsBytes[10] = 32;
/*      */             
/* 4429 */             datetimeAsBytes[11] = (byte)Character.forDigit(hour / 10, 10);
/*      */             
/* 4431 */             datetimeAsBytes[12] = (byte)Character.forDigit(hour % 10, 10);
/*      */ 
/*      */             
/* 4434 */             datetimeAsBytes[13] = 58;
/*      */             
/* 4436 */             datetimeAsBytes[14] = (byte)Character.forDigit(minute / 10, 10);
/*      */             
/* 4438 */             datetimeAsBytes[15] = (byte)Character.forDigit(minute % 10, 10);
/*      */ 
/*      */             
/* 4441 */             datetimeAsBytes[16] = 58;
/*      */             
/* 4443 */             datetimeAsBytes[17] = (byte)Character.forDigit(seconds / 10, 10);
/*      */             
/* 4445 */             datetimeAsBytes[18] = (byte)Character.forDigit(seconds % 10, 10);
/*      */ 
/*      */             
/* 4448 */             datetimeAsBytes[19] = 46;
/*      */             
/* 4450 */             int nanosOffset = 20;
/*      */             
/* 4452 */             int j = 0; }   m = 19; arrayOfByte2 = Integer.toString(nanos).getBytes(); m += 1 + arrayOfByte2.length; arrayOfByte3 = new byte[m]; arrayOfByte3[0] = (byte)Character.forDigit(year / 1000, 10); i = year % 1000; arrayOfByte3[1] = (byte)Character.forDigit(i / 100, 10); k = i % 100; arrayOfByte3[2] = (byte)Character.forDigit(k / 10, 10); arrayOfByte3[3] = (byte)Character.forDigit(k % 10, 10); arrayOfByte3[4] = 45; arrayOfByte3[5] = (byte)Character.forDigit(month / 10, 10); arrayOfByte3[6] = (byte)Character.forDigit(month % 10, 10); arrayOfByte3[7] = 45; arrayOfByte3[8] = (byte)Character.forDigit(day / 10, 10); arrayOfByte3[9] = (byte)Character.forDigit(day % 10, 10); arrayOfByte3[10] = 32; arrayOfByte3[11] = (byte)Character.forDigit(hour / 10, 10); arrayOfByte3[12] = (byte)Character.forDigit(hour % 10, 10); arrayOfByte3[13] = 58; arrayOfByte3[14] = (byte)Character.forDigit(minute / 10, 10); arrayOfByte3[15] = (byte)Character.forDigit(minute % 10, 10); arrayOfByte3[16] = 58; arrayOfByte3[17] = (byte)Character.forDigit(seconds / 10, 10); arrayOfByte3[18] = (byte)Character.forDigit(seconds % 10, 10); arrayOfByte3[19] = 46; b = 20; bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 0:
/*      */       case 15:
/*      */       case 16:
/*      */       case 246:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/*      */       case 253:
/*      */       case 254:
/* 4471 */         unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4476 */     throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000", getExceptionInterceptor()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void negotiateSSLConnection(String user, String password, String database, int packLength) throws SQLException {
/* 4499 */     if (!ExportControlled.enabled()) {
/* 4500 */       throw new ConnectionFeatureNotAvailableException(this.connection, this.lastPacketSentTimeMs, null);
/*      */     }
/*      */ 
/*      */     
/* 4504 */     boolean doSecureAuth = false;
/*      */     
/* 4506 */     if ((this.serverCapabilities & 0x8000) != 0) {
/* 4507 */       this.clientParam |= 0x8000L;
/* 4508 */       doSecureAuth = true;
/*      */     } 
/*      */     
/* 4511 */     this.clientParam |= 0x800L;
/*      */     
/* 4513 */     Buffer packet = new Buffer(packLength);
/*      */     
/* 4515 */     if (this.use41Extensions) {
/* 4516 */       packet.writeLong(this.clientParam);
/*      */     } else {
/* 4518 */       packet.writeInt((int)this.clientParam);
/*      */     } 
/*      */     
/* 4521 */     send(packet, packet.getPosition());
/*      */     
/* 4523 */     ExportControlled.transformSocketToSSLSocket(this);
/*      */     
/* 4525 */     packet.clear();
/*      */     
/* 4527 */     if (doSecureAuth) {
/* 4528 */       if (versionMeetsMinimum(4, 1, 1)) {
/* 4529 */         secureAuth411(null, packLength, user, password, database, true);
/*      */       } else {
/* 4531 */         secureAuth411(null, packLength, user, password, database, true);
/*      */       } 
/*      */     } else {
/* 4534 */       if (this.use41Extensions) {
/* 4535 */         packet.writeLong(this.clientParam);
/* 4536 */         packet.writeLong(this.maxThreeBytes);
/*      */       } else {
/* 4538 */         packet.writeInt((int)this.clientParam);
/* 4539 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       } 
/*      */ 
/*      */       
/* 4543 */       packet.writeString(user);
/*      */       
/* 4545 */       if (this.protocolVersion > 9) {
/* 4546 */         packet.writeString(Util.newCrypt(password, this.seed));
/*      */       } else {
/* 4548 */         packet.writeString(Util.oldCrypt(password, this.seed));
/*      */       } 
/*      */       
/* 4551 */       if ((this.serverCapabilities & 0x8) != 0 && database != null && database.length() > 0)
/*      */       {
/* 4553 */         packet.writeString(database);
/*      */       }
/*      */       
/* 4556 */       send(packet, packet.getPosition());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 4561 */   protected int getServerStatus() { return this.serverStatus; }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List fetchRowsViaCursor(List fetchedRows, long statementId, Field[] columnTypes, int fetchSize, boolean useBufferRowExplicit) throws SQLException {
/* 4567 */     if (fetchedRows == null) {
/* 4568 */       fetchedRows = new ArrayList(fetchSize);
/*      */     } else {
/* 4570 */       fetchedRows.clear();
/*      */     } 
/*      */     
/* 4573 */     this.sharedSendPacket.clear();
/*      */     
/* 4575 */     this.sharedSendPacket.writeByte((byte)28);
/* 4576 */     this.sharedSendPacket.writeLong(statementId);
/* 4577 */     this.sharedSendPacket.writeLong(fetchSize);
/*      */     
/* 4579 */     sendCommand(28, null, this.sharedSendPacket, true, null, 0);
/*      */ 
/*      */     
/* 4582 */     ResultSetRow row = null;
/*      */ 
/*      */     
/* 4585 */     while ((row = nextRow(columnTypes, columnTypes.length, true, 1007, false, useBufferRowExplicit, false, null)) != null) {
/* 4586 */       fetchedRows.add(row);
/*      */     }
/*      */     
/* 4589 */     return fetchedRows;
/*      */   }
/*      */ 
/*      */   
/* 4593 */   protected long getThreadId() { return this.threadId; }
/*      */ 
/*      */ 
/*      */   
/* 4597 */   protected boolean useNanosForElapsedTime() { return this.useNanosForElapsedTime; }
/*      */ 
/*      */ 
/*      */   
/* 4601 */   protected long getSlowQueryThreshold() { return this.slowQueryThreshold; }
/*      */ 
/*      */ 
/*      */   
/* 4605 */   protected String getQueryTimingUnits() { return this.queryTimingUnits; }
/*      */ 
/*      */ 
/*      */   
/* 4609 */   protected int getCommandCount() { return this.commandCount; }
/*      */ 
/*      */   
/*      */   private void checkTransactionState(int oldStatus) throws SQLException {
/* 4613 */     boolean previouslyInTrans = ((oldStatus & true) != 0);
/* 4614 */     boolean currentlyInTrans = ((this.serverStatus & true) != 0);
/*      */     
/* 4616 */     if (previouslyInTrans && !currentlyInTrans) {
/* 4617 */       this.connection.transactionCompleted();
/* 4618 */     } else if (!previouslyInTrans && currentlyInTrans) {
/* 4619 */       this.connection.transactionBegun();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/* 4624 */   protected void setStatementInterceptors(List statementInterceptors) { this.statementInterceptors = statementInterceptors; }
/*      */ 
/*      */ 
/*      */   
/* 4628 */   protected ExceptionInterceptor getExceptionInterceptor() { return this.exceptionInterceptor; }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/MysqlIO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */