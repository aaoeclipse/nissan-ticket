/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLStatementCancelledException;
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandlerFactory;
/*      */ import java.io.InputStream;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.TimerTask;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class StatementImpl
/*      */   implements Statement
/*      */ {
/*      */   protected static final String PING_MARKER = "/* ping */";
/*      */   
/*      */   class CancelTask
/*      */     extends TimerTask
/*      */   {
/*      */     long connectionId;
/*      */     SQLException caughtWhileCancelling;
/*      */     StatementImpl toCancel;
/*      */     private final StatementImpl this$0;
/*      */     
/*      */     CancelTask(StatementImpl this$0, StatementImpl cancellee) throws SQLException {
/*   82 */       this.this$0 = this$0; this.connectionId = 0L; this.caughtWhileCancelling = null;
/*   83 */       this.connectionId = this$0.connection.getIO().getThreadId();
/*   84 */       this.toCancel = cancellee;
/*      */     }
/*      */ 
/*      */     
/*      */     public void run() {
/*   89 */       Object object = new Object(this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  132 */       object.start();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  139 */   protected Object cancelTimeoutMutex = new Object();
/*      */ 
/*      */   
/*  142 */   protected static int statementCounter = 1;
/*      */ 
/*      */   
/*      */   public static final byte USES_VARIABLES_FALSE = 0;
/*      */   
/*      */   public static final byte USES_VARIABLES_TRUE = 1;
/*      */   
/*      */   public static final byte USES_VARIABLES_UNKNOWN = -1;
/*      */   
/*      */   protected boolean wasCancelled = false;
/*      */   
/*      */   protected boolean wasCancelledByTimeout = false;
/*      */   
/*      */   protected List batchedArgs;
/*      */   
/*  157 */   protected SingleByteCharsetConverter charConverter = null;
/*      */ 
/*      */   
/*  160 */   protected String charEncoding = null;
/*      */ 
/*      */   
/*  163 */   protected ConnectionImpl connection = null;
/*      */   
/*  165 */   protected long connectionId = 0L;
/*      */ 
/*      */   
/*  168 */   protected String currentCatalog = null;
/*      */ 
/*      */   
/*      */   protected boolean doEscapeProcessing = true;
/*      */ 
/*      */   
/*  174 */   protected ProfilerEventHandler eventSink = null;
/*      */ 
/*      */   
/*  177 */   private int fetchSize = 0;
/*      */ 
/*      */   
/*      */   protected boolean isClosed = false;
/*      */ 
/*      */   
/*  183 */   protected long lastInsertId = -1L;
/*      */ 
/*      */   
/*  186 */   protected int maxFieldSize = MysqlIO.getMaxBuf();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  192 */   protected int maxRows = -1;
/*      */ 
/*      */   
/*      */   protected boolean maxRowsChanged = false;
/*      */ 
/*      */   
/*  198 */   protected Set openResults = new HashSet();
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean pedantic = false;
/*      */ 
/*      */ 
/*      */   
/*      */   protected Throwable pointOfOrigin;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean profileSQL = false;
/*      */ 
/*      */   
/*  213 */   protected ResultSetInternalMethods results = null;
/*      */ 
/*      */   
/*  216 */   protected int resultSetConcurrency = 0;
/*      */ 
/*      */   
/*  219 */   protected int resultSetType = 0;
/*      */ 
/*      */   
/*      */   protected int statementId;
/*      */ 
/*      */   
/*  225 */   protected int timeoutInMillis = 0;
/*      */ 
/*      */   
/*  228 */   protected long updateCount = -1L;
/*      */ 
/*      */   
/*      */   protected boolean useUsageAdvisor = false;
/*      */ 
/*      */   
/*  234 */   protected SQLWarning warningChain = null;
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean holdResultsOpenOverClose = false;
/*      */ 
/*      */ 
/*      */   
/*  242 */   protected ArrayList batchedGeneratedKeys = null;
/*      */   
/*      */   protected boolean retrieveGeneratedKeys = false;
/*      */   
/*      */   protected boolean continueBatchOnError = false;
/*      */   
/*  248 */   protected PingTarget pingTarget = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean useLegacyDatetimeCode;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean lastQueryIsOnDupKeyUpdate = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public StatementImpl(ConnectionImpl c, String catalog) throws SQLException {
/*  269 */     if (c == null || c.isClosed()) {
/*  270 */       throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003", null);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  275 */     this.connection = c;
/*  276 */     this.connectionId = this.connection.getId();
/*  277 */     this.exceptionInterceptor = c.getExceptionInterceptor();
/*      */     
/*  279 */     this.currentCatalog = catalog;
/*  280 */     this.pedantic = this.connection.getPedantic();
/*  281 */     this.continueBatchOnError = this.connection.getContinueBatchOnError();
/*  282 */     this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode();
/*      */     
/*  284 */     if (!this.connection.getDontTrackOpenResources()) {
/*  285 */       this.connection.registerStatement(this);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  292 */     if (this.connection != null) {
/*  293 */       this.maxFieldSize = this.connection.getMaxAllowedPacket();
/*      */       
/*  295 */       int defaultFetchSize = this.connection.getDefaultFetchSize();
/*      */       
/*  297 */       if (defaultFetchSize != 0) {
/*  298 */         setFetchSize(defaultFetchSize);
/*      */       }
/*      */     } 
/*      */     
/*  302 */     if (this.connection.getUseUnicode()) {
/*  303 */       this.charEncoding = this.connection.getEncoding();
/*      */       
/*  305 */       this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */     } 
/*      */ 
/*      */     
/*  309 */     boolean profiling = (this.connection.getProfileSql() || this.connection.getUseUsageAdvisor() || this.connection.getLogSlowQueries());
/*      */ 
/*      */     
/*  312 */     if (this.connection.getAutoGenerateTestcaseScript() || profiling) {
/*  313 */       this.statementId = statementCounter++;
/*      */     }
/*      */     
/*  316 */     if (profiling) {
/*  317 */       this.pointOfOrigin = new Throwable();
/*  318 */       this.profileSQL = this.connection.getProfileSql();
/*  319 */       this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  320 */       this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection);
/*      */     } 
/*      */     
/*  323 */     int maxRowsConn = this.connection.getMaxRows();
/*      */     
/*  325 */     if (maxRowsConn != -1) {
/*  326 */       setMaxRows(maxRowsConn);
/*      */     }
/*      */     
/*  329 */     this.holdResultsOpenOverClose = this.connection.getHoldResultsOpenOverStatementClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addBatch(String sql) throws SQLException {
/*  342 */     if (this.batchedArgs == null) {
/*  343 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */     
/*  346 */     if (sql != null) {
/*  347 */       this.batchedArgs.add(sql);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel() throws SQLException {
/*  357 */     if (!this.isClosed && this.connection != null && this.connection.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */       
/*  360 */       Connection cancelConn = null;
/*  361 */       Statement cancelStmt = null;
/*      */       
/*      */       try {
/*  364 */         cancelConn = this.connection.duplicate();
/*  365 */         cancelStmt = cancelConn.createStatement();
/*  366 */         cancelStmt.execute("KILL QUERY " + this.connection.getIO().getThreadId());
/*      */         
/*  368 */         this.wasCancelled = true;
/*      */       } finally {
/*  370 */         if (cancelStmt != null) {
/*  371 */           cancelStmt.close();
/*      */         }
/*      */         
/*  374 */         if (cancelConn != null) {
/*  375 */           cancelConn.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkClosed() throws SQLException {
/*  391 */     if (this.isClosed) {
/*  392 */       throw SQLError.createSQLException(Messages.getString("Statement.49"), "08003", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkForDml(String sql, char firstStatementChar) throws SQLException {
/*  412 */     if (firstStatementChar == 'I' || firstStatementChar == 'U' || firstStatementChar == 'D' || firstStatementChar == 'A' || firstStatementChar == 'C') {
/*      */ 
/*      */       
/*  415 */       String noCommentSql = StringUtils.stripComments(sql, "'\"", "'\"", true, false, true, true);
/*      */ 
/*      */       
/*  418 */       if (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "INSERT") || StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "UPDATE") || StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DELETE") || StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DROP") || StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "CREATE") || StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "ALTER"))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  424 */         throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkNullOrEmptyQuery(String sql) throws SQLException {
/*  441 */     if (sql == null) {
/*  442 */       throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  447 */     if (sql.length() == 0) {
/*  448 */       throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearBatch() throws SQLException {
/*  463 */     if (this.batchedArgs != null) {
/*  464 */       this.batchedArgs.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  476 */   public void clearWarnings() throws SQLException { this.warningChain = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  495 */   public synchronized void close() throws SQLException { realClose(true, true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void closeAllOpenResults() {
/*  502 */     if (this.openResults != null) {
/*  503 */       for (Iterator iter = this.openResults.iterator(); iter.hasNext(); ) {
/*  504 */         ResultSetInternalMethods element = iter.next();
/*      */         
/*      */         try {
/*  507 */           element.realClose(false);
/*  508 */         } catch (SQLException sqlEx) {
/*  509 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         } 
/*      */       } 
/*      */       
/*  513 */       this.openResults.clear();
/*      */     } 
/*      */   }
/*      */   
/*      */   public synchronized void removeOpenResultSet(ResultSet rs) {
/*  518 */     if (this.openResults != null) {
/*  519 */       this.openResults.remove(rs);
/*      */     }
/*      */   }
/*      */   
/*      */   public synchronized int getOpenResultSetCount() {
/*  524 */     if (this.openResults != null) {
/*  525 */       return this.openResults.size();
/*      */     }
/*      */     
/*  528 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetInternalMethods createResultSetUsingServerFetch(String sql) throws SQLException {
/*  537 */     PreparedStatement pStmt = this.connection.prepareStatement(sql, this.resultSetType, this.resultSetConcurrency);
/*      */ 
/*      */     
/*  540 */     pStmt.setFetchSize(this.fetchSize);
/*      */     
/*  542 */     if (this.maxRows > -1) {
/*  543 */       pStmt.setMaxRows(this.maxRows);
/*      */     }
/*      */     
/*  546 */     pStmt.execute();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  552 */     ResultSetInternalMethods rs = ((StatementImpl)pStmt).getResultSetInternal();
/*      */ 
/*      */     
/*  555 */     rs.setStatementUsedForFetchingRows((PreparedStatement)pStmt);
/*      */ 
/*      */     
/*  558 */     this.results = rs;
/*      */     
/*  560 */     return rs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  571 */   protected boolean createStreamingResultSet() { return (this.resultSetType == 1003 && this.resultSetConcurrency == 1007 && this.fetchSize == Integer.MIN_VALUE); }
/*      */ 
/*      */ 
/*      */   
/*  575 */   private int originalResultSetType = 0;
/*  576 */   private int originalFetchSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enableStreamingResults() throws SQLException {
/*  582 */     this.originalResultSetType = this.resultSetType;
/*  583 */     this.originalFetchSize = this.fetchSize;
/*      */     
/*  585 */     setFetchSize(-2147483648);
/*  586 */     setResultSetType(1003);
/*      */   }
/*      */   
/*      */   public void disableStreamingResults() throws SQLException {
/*  590 */     if (this.fetchSize == Integer.MIN_VALUE && this.resultSetType == 1003) {
/*      */       
/*  592 */       setFetchSize(this.originalFetchSize);
/*  593 */       setResultSetType(this.originalResultSetType);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  612 */   public boolean execute(String sql) throws SQLException { return execute(sql, false); }
/*      */ 
/*      */   
/*      */   private boolean execute(String sql, boolean returnGeneratedKeys) throws SQLException {
/*  616 */     checkClosed();
/*      */     
/*  618 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/*  620 */     synchronized (locallyScopedConn.getMutex()) {
/*  621 */       this.retrieveGeneratedKeys = returnGeneratedKeys;
/*  622 */       this.lastQueryIsOnDupKeyUpdate = false;
/*  623 */       if (returnGeneratedKeys) {
/*  624 */         this.lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyInString(sql);
/*      */       }
/*  626 */       resetCancelledState();
/*      */       
/*  628 */       checkNullOrEmptyQuery(sql);
/*      */       
/*  630 */       checkClosed();
/*      */       
/*  632 */       char firstNonWsChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*      */       
/*  634 */       boolean isSelect = true;
/*      */       
/*  636 */       if (firstNonWsChar != 'S') {
/*  637 */         isSelect = false;
/*      */         
/*  639 */         if (locallyScopedConn.isReadOnly()) {
/*  640 */           throw SQLError.createSQLException(Messages.getString("Statement.27") + Messages.getString("Statement.28"), "S1009", getExceptionInterceptor());
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  647 */       boolean doStreaming = createStreamingResultSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  657 */       if (doStreaming && this.connection.getNetTimeoutForStreamingResults() > 0)
/*      */       {
/*  659 */         executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
/*      */       }
/*      */ 
/*      */       
/*  663 */       if (this.doEscapeProcessing) {
/*  664 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), locallyScopedConn);
/*      */ 
/*      */         
/*  667 */         if (escapedSqlResult instanceof String) {
/*  668 */           sql = (String)escapedSqlResult;
/*      */         } else {
/*  670 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         } 
/*      */       } 
/*      */       
/*  674 */       if (this.results != null && 
/*  675 */         !locallyScopedConn.getHoldResultsOpenOverStatementClose()) {
/*  676 */         this.results.realClose(false);
/*      */       }
/*      */ 
/*      */       
/*  680 */       if (sql.charAt(0) == '/' && 
/*  681 */         sql.startsWith("/* ping */")) {
/*  682 */         doPingInstead();
/*      */         
/*  684 */         return true;
/*      */       } 
/*      */ 
/*      */       
/*  688 */       CachedResultSetMetaData cachedMetaData = null;
/*      */       
/*  690 */       ResultSetInternalMethods rs = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  699 */       this.batchedGeneratedKeys = null;
/*      */       
/*  701 */       if (useServerFetch()) {
/*  702 */         rs = createResultSetUsingServerFetch(sql);
/*      */       } else {
/*  704 */         CancelTask timeoutTask = null;
/*      */         
/*  706 */         String oldCatalog = null;
/*      */         
/*      */         try {
/*  709 */           if (locallyScopedConn.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */             
/*  712 */             timeoutTask = new CancelTask(this, this);
/*  713 */             ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  719 */           if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/*      */             
/*  721 */             oldCatalog = locallyScopedConn.getCatalog();
/*  722 */             locallyScopedConn.setCatalog(this.currentCatalog);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  729 */           Field[] cachedFields = null;
/*      */           
/*  731 */           if (locallyScopedConn.getCacheResultSetMetadata()) {
/*  732 */             cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
/*      */             
/*  734 */             if (cachedMetaData != null) {
/*  735 */               cachedFields = cachedMetaData.fields;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  742 */           if (locallyScopedConn.useMaxRows()) {
/*  743 */             int rowLimit = -1;
/*      */             
/*  745 */             if (isSelect) {
/*  746 */               if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
/*  747 */                 rowLimit = this.maxRows;
/*      */               }
/*  749 */               else if (this.maxRows <= 0) {
/*  750 */                 executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */               } else {
/*      */                 
/*  753 */                 executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */               }
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  759 */               executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */             } 
/*      */ 
/*      */ 
/*      */             
/*  764 */             rs = locallyScopedConn.execSQL(this, sql, rowLimit, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  769 */             rs = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  775 */           if (timeoutTask != null) {
/*  776 */             if (timeoutTask.caughtWhileCancelling != null) {
/*  777 */               throw timeoutTask.caughtWhileCancelling;
/*      */             }
/*      */             
/*  780 */             timeoutTask.cancel();
/*  781 */             timeoutTask = null;
/*      */           } 
/*      */           
/*  784 */           synchronized (this.cancelTimeoutMutex) {
/*  785 */             if (this.wasCancelled) {
/*  786 */               Object object = null;
/*      */               
/*  788 */               if (this.wasCancelledByTimeout) {
/*  789 */                 MySQLTimeoutException mySQLTimeoutException = new MySQLTimeoutException();
/*      */               } else {
/*  791 */                 object = new MySQLStatementCancelledException();
/*      */               } 
/*      */               
/*  794 */               resetCancelledState();
/*      */               
/*  796 */               throw object;
/*      */             } 
/*      */           } 
/*      */         } finally {
/*  800 */           if (timeoutTask != null) {
/*  801 */             timeoutTask.cancel();
/*      */           }
/*      */           
/*  804 */           if (oldCatalog != null) {
/*  805 */             locallyScopedConn.setCatalog(oldCatalog);
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  810 */       if (rs != null) {
/*  811 */         this.lastInsertId = rs.getUpdateID();
/*      */         
/*  813 */         this.results = rs;
/*      */         
/*  815 */         rs.setFirstCharOfQuery(firstNonWsChar);
/*      */         
/*  817 */         if (rs.reallyResult()) {
/*  818 */           if (cachedMetaData != null) {
/*  819 */             locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */           
/*      */           }
/*  822 */           else if (this.connection.getCacheResultSetMetadata()) {
/*  823 */             locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  830 */       return (rs != null && rs.reallyResult());
/*      */     } 
/*      */   }
/*      */   
/*      */   protected synchronized void resetCancelledState() {
/*  835 */     if (this.cancelTimeoutMutex == null) {
/*      */       return;
/*      */     }
/*      */     
/*  839 */     synchronized (this.cancelTimeoutMutex) {
/*  840 */       this.wasCancelled = false;
/*  841 */       this.wasCancelledByTimeout = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String sql, int returnGeneratedKeys) throws SQLException {
/*  852 */     if (returnGeneratedKeys == 1) {
/*  853 */       checkClosed();
/*      */       
/*  855 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/*  857 */       synchronized (locallyScopedConn.getMutex()) {
/*      */ 
/*      */ 
/*      */         
/*  861 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */         
/*  863 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         
/*      */         try {
/*  866 */           return execute(sql, true);
/*      */         } finally {
/*  868 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  873 */     return execute(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String sql, int[] generatedKeyIndices) throws SQLException {
/*  881 */     if (generatedKeyIndices != null && generatedKeyIndices.length > 0) {
/*  882 */       checkClosed();
/*      */       
/*  884 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/*  886 */       synchronized (locallyScopedConn.getMutex()) {
/*  887 */         this.retrieveGeneratedKeys = true;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  892 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */         
/*  894 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         
/*      */         try {
/*  897 */           return execute(sql, true);
/*      */         } finally {
/*  899 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  904 */     return execute(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String sql, String[] generatedKeyNames) throws SQLException {
/*  912 */     if (generatedKeyNames != null && generatedKeyNames.length > 0) {
/*  913 */       checkClosed();
/*      */       
/*  915 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/*  917 */       synchronized (locallyScopedConn.getMutex()) {
/*  918 */         this.retrieveGeneratedKeys = true;
/*      */ 
/*      */ 
/*      */         
/*  922 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */         
/*  924 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         
/*      */         try {
/*  927 */           return execute(sql, true);
/*      */         } finally {
/*  929 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  934 */     return execute(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int[] executeBatch() throws SQLException {
/*  952 */     checkClosed();
/*      */     
/*  954 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/*  956 */     if (locallyScopedConn.isReadOnly()) {
/*  957 */       throw SQLError.createSQLException(Messages.getString("Statement.34") + Messages.getString("Statement.35"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  963 */     if (this.results != null && 
/*  964 */       !locallyScopedConn.getHoldResultsOpenOverStatementClose()) {
/*  965 */       this.results.realClose(false);
/*      */     }
/*      */ 
/*      */     
/*  969 */     synchronized (locallyScopedConn.getMutex()) {
/*  970 */       if (this.batchedArgs == null || this.batchedArgs.size() == 0) {
/*  971 */         return new int[0];
/*      */       }
/*      */ 
/*      */       
/*  975 */       int individualStatementTimeout = this.timeoutInMillis;
/*  976 */       this.timeoutInMillis = 0;
/*      */       
/*  978 */       CancelTask timeoutTask = null;
/*      */       
/*      */       try {
/*  981 */         resetCancelledState();
/*      */         
/*  983 */         this.retrieveGeneratedKeys = true;
/*      */         
/*  985 */         int[] updateCounts = null;
/*      */ 
/*      */         
/*  988 */         if (this.batchedArgs != null) {
/*  989 */           int nbrCommands = this.batchedArgs.size();
/*      */           
/*  991 */           this.batchedGeneratedKeys = new ArrayList(this.batchedArgs.size());
/*      */           
/*  993 */           boolean multiQueriesEnabled = locallyScopedConn.getAllowMultiQueries();
/*      */           
/*  995 */           if (locallyScopedConn.versionMeetsMinimum(4, 1, 1) && (multiQueriesEnabled || (locallyScopedConn.getRewriteBatchedStatements() && nbrCommands > 4)))
/*      */           {
/*      */ 
/*      */             
/*  999 */             return executeBatchUsingMultiQueries(multiQueriesEnabled, nbrCommands, individualStatementTimeout);
/*      */           }
/*      */           
/* 1002 */           if (locallyScopedConn.getEnableQueryTimeouts() && individualStatementTimeout != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */             
/* 1005 */             timeoutTask = new CancelTask(this, this);
/* 1006 */             ConnectionImpl.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
/*      */           } 
/*      */ 
/*      */           
/* 1010 */           updateCounts = new int[nbrCommands];
/*      */           
/* 1012 */           for (int i = 0; i < nbrCommands; i++) {
/* 1013 */             updateCounts[i] = -3;
/*      */           }
/*      */           
/* 1016 */           SQLException sqlEx = null;
/*      */           
/* 1018 */           int commandIndex = 0;
/*      */           
/* 1020 */           for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*      */             try {
/* 1022 */               String sql = this.batchedArgs.get(commandIndex);
/* 1023 */               updateCounts[commandIndex] = executeUpdate(sql, true, true);
/*      */               
/* 1025 */               getBatchedGeneratedKeys(containsOnDuplicateKeyInString(sql) ? 1 : 0);
/* 1026 */             } catch (SQLException ex) {
/* 1027 */               updateCounts[commandIndex] = -3;
/*      */               
/* 1029 */               if (this.continueBatchOnError && !(ex instanceof MySQLTimeoutException) && !(ex instanceof MySQLStatementCancelledException) && !hasDeadlockOrTimeoutRolledBackTx(ex)) {
/*      */ 
/*      */ 
/*      */                 
/* 1033 */                 sqlEx = ex;
/*      */               } else {
/* 1035 */                 int[] newUpdateCounts = new int[commandIndex];
/*      */                 
/* 1037 */                 if (hasDeadlockOrTimeoutRolledBackTx(ex)) {
/* 1038 */                   for (int i = 0; i < newUpdateCounts.length; i++) {
/* 1039 */                     newUpdateCounts[i] = -3;
/*      */                   }
/*      */                 } else {
/* 1042 */                   System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */                 } 
/*      */ 
/*      */                 
/* 1046 */                 throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1053 */           if (sqlEx != null) {
/* 1054 */             throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1060 */         if (timeoutTask != null) {
/* 1061 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1062 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1065 */           timeoutTask.cancel();
/* 1066 */           timeoutTask = null;
/*      */         } 
/*      */         
/* 1069 */         return (updateCounts != null) ? updateCounts : new int[0];
/*      */       } finally {
/*      */         
/* 1072 */         if (timeoutTask != null) {
/* 1073 */           timeoutTask.cancel();
/*      */         }
/*      */         
/* 1076 */         resetCancelledState();
/*      */         
/* 1078 */         this.timeoutInMillis = individualStatementTimeout;
/*      */         
/* 1080 */         clearBatch();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final boolean hasDeadlockOrTimeoutRolledBackTx(SQLException ex) {
/* 1086 */     int vendorCode = ex.getErrorCode();
/*      */     
/* 1088 */     switch (vendorCode) {
/*      */       case 1206:
/*      */       case 1213:
/* 1091 */         return true;
/*      */       case 1205:
/*      */         try {
/* 1094 */           return !this.connection.versionMeetsMinimum(5, 0, 13);
/* 1095 */         } catch (SQLException sqlEx) {
/*      */           
/* 1097 */           return false;
/*      */         } 
/*      */     } 
/* 1100 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands, int individualStatementTimeout) throws SQLException {
/* 1115 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/* 1117 */     if (!multiQueriesEnabled) {
/* 1118 */       locallyScopedConn.getIO().enableMultiQueries();
/*      */     }
/*      */     
/* 1121 */     Statement batchStmt = null;
/*      */     
/* 1123 */     CancelTask timeoutTask = null;
/*      */     
/*      */     try {
/* 1126 */       int[] updateCounts = new int[nbrCommands];
/*      */       
/* 1128 */       for (int i = 0; i < nbrCommands; i++) {
/* 1129 */         updateCounts[i] = -3;
/*      */       }
/*      */       
/* 1132 */       int commandIndex = 0;
/*      */       
/* 1134 */       StringBuffer queryBuf = new StringBuffer();
/*      */       
/* 1136 */       batchStmt = locallyScopedConn.createStatement();
/*      */       
/* 1138 */       if (locallyScopedConn.getEnableQueryTimeouts() && individualStatementTimeout != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */         
/* 1141 */         timeoutTask = new CancelTask(this, (StatementImpl)batchStmt);
/* 1142 */         ConnectionImpl.getCancelTimer().schedule(timeoutTask, individualStatementTimeout);
/*      */       } 
/*      */ 
/*      */       
/* 1146 */       int counter = 0;
/*      */       
/* 1148 */       int numberOfBytesPerChar = 1;
/*      */       
/* 1150 */       String connectionEncoding = locallyScopedConn.getEncoding();
/*      */       
/* 1152 */       if (StringUtils.startsWithIgnoreCase(connectionEncoding, "utf")) {
/* 1153 */         numberOfBytesPerChar = 3;
/* 1154 */       } else if (CharsetMapping.isMultibyteCharset(connectionEncoding)) {
/* 1155 */         numberOfBytesPerChar = 2;
/*      */       } 
/*      */       
/* 1158 */       int escapeAdjust = 1;
/*      */       
/* 1160 */       if (this.doEscapeProcessing) {
/* 1161 */         escapeAdjust = 2;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1166 */       SQLException sqlEx = null;
/*      */       
/* 1168 */       int argumentSetsInBatchSoFar = 0;
/*      */       
/* 1170 */       for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/* 1171 */         String nextQuery = this.batchedArgs.get(commandIndex);
/*      */         
/* 1173 */         if (((queryBuf.length() + nextQuery.length()) * numberOfBytesPerChar + 1 + 4) * escapeAdjust + 32 > this.connection.getMaxAllowedPacket()) {
/*      */ 
/*      */           
/*      */           try {
/*      */             
/* 1178 */             batchStmt.execute(queryBuf.toString(), 1);
/* 1179 */           } catch (SQLException ex) {
/* 1180 */             sqlEx = handleExceptionForBatch(commandIndex, argumentSetsInBatchSoFar, updateCounts, ex);
/*      */           } 
/*      */ 
/*      */           
/* 1184 */           counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
/*      */ 
/*      */           
/* 1187 */           queryBuf = new StringBuffer();
/* 1188 */           argumentSetsInBatchSoFar = 0;
/*      */         } 
/*      */         
/* 1191 */         queryBuf.append(nextQuery);
/* 1192 */         queryBuf.append(";");
/* 1193 */         argumentSetsInBatchSoFar++;
/*      */       } 
/*      */       
/* 1196 */       if (queryBuf.length() > 0) {
/*      */         try {
/* 1198 */           batchStmt.execute(queryBuf.toString(), 1);
/* 1199 */         } catch (SQLException ex) {
/* 1200 */           sqlEx = handleExceptionForBatch(commandIndex - 1, argumentSetsInBatchSoFar, updateCounts, ex);
/*      */         } 
/*      */ 
/*      */         
/* 1204 */         counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
/*      */       } 
/*      */ 
/*      */       
/* 1208 */       if (timeoutTask != null) {
/* 1209 */         if (timeoutTask.caughtWhileCancelling != null) {
/* 1210 */           throw timeoutTask.caughtWhileCancelling;
/*      */         }
/*      */         
/* 1213 */         timeoutTask.cancel();
/* 1214 */         timeoutTask = null;
/*      */       } 
/*      */       
/* 1217 */       if (sqlEx != null) {
/* 1218 */         throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1223 */       return (updateCounts != null) ? updateCounts : new int[0];
/*      */     } finally {
/* 1225 */       if (timeoutTask != null) {
/* 1226 */         timeoutTask.cancel();
/*      */       }
/*      */       
/* 1229 */       resetCancelledState();
/*      */       
/*      */       try {
/* 1232 */         if (batchStmt != null) {
/* 1233 */           batchStmt.close();
/*      */         }
/*      */       } finally {
/* 1236 */         if (!multiQueriesEnabled) {
/* 1237 */           locallyScopedConn.getIO().disableMultiQueries();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int processMultiCountsAndKeys(StatementImpl batchedStatement, int updateCountCounter, int[] updateCounts) throws SQLException {
/* 1246 */     updateCounts[updateCountCounter++] = batchedStatement.getUpdateCount();
/*      */     
/* 1248 */     boolean doGenKeys = (this.batchedGeneratedKeys != null);
/*      */     
/* 1250 */     byte[][] row = (byte[][])null;
/*      */     
/* 1252 */     if (doGenKeys) {
/* 1253 */       long generatedKey = batchedStatement.getLastInsertID();
/*      */       
/* 1255 */       row = new byte[1][];
/* 1256 */       row[0] = Long.toString(generatedKey).getBytes();
/* 1257 */       this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */     } 
/*      */ 
/*      */     
/* 1261 */     while (batchedStatement.getMoreResults() || batchedStatement.getUpdateCount() != -1) {
/* 1262 */       updateCounts[updateCountCounter++] = batchedStatement.getUpdateCount();
/*      */       
/* 1264 */       if (doGenKeys) {
/* 1265 */         long generatedKey = batchedStatement.getLastInsertID();
/*      */         
/* 1267 */         row = new byte[1][];
/* 1268 */         row[0] = Long.toString(generatedKey).getBytes();
/* 1269 */         this.batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
/*      */       } 
/*      */     } 
/*      */     
/* 1273 */     return updateCountCounter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLException handleExceptionForBatch(int endOfBatchIndex, int numValuesPerBatch, int[] updateCounts, SQLException ex) throws BatchUpdateException {
/*      */     SQLException sqlEx;
/* 1281 */     for (int j = endOfBatchIndex; j > endOfBatchIndex - numValuesPerBatch; j--) {
/* 1282 */       updateCounts[j] = -3;
/*      */     }
/*      */     
/* 1285 */     if (this.continueBatchOnError && !(ex instanceof MySQLTimeoutException) && !(ex instanceof MySQLStatementCancelledException) && !hasDeadlockOrTimeoutRolledBackTx(ex)) {
/*      */ 
/*      */ 
/*      */       
/* 1289 */       sqlEx = ex;
/*      */     } else {
/* 1291 */       int[] newUpdateCounts = new int[endOfBatchIndex];
/* 1292 */       System.arraycopy(updateCounts, 0, newUpdateCounts, 0, endOfBatchIndex);
/*      */ 
/*      */       
/* 1295 */       throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1300 */     return sqlEx;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String sql) throws SQLException {
/* 1316 */     checkClosed();
/*      */     
/* 1318 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/* 1320 */     synchronized (locallyScopedConn.getMutex()) {
/* 1321 */       this.retrieveGeneratedKeys = false;
/*      */       
/* 1323 */       resetCancelledState();
/*      */       
/* 1325 */       checkNullOrEmptyQuery(sql);
/*      */       
/* 1327 */       boolean doStreaming = createStreamingResultSet();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1337 */       if (doStreaming && this.connection.getNetTimeoutForStreamingResults() > 0)
/*      */       {
/* 1339 */         executeSimpleNonQuery(locallyScopedConn, "SET net_write_timeout=" + this.connection.getNetTimeoutForStreamingResults());
/*      */       }
/*      */ 
/*      */       
/* 1343 */       if (this.doEscapeProcessing) {
/* 1344 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), this.connection);
/*      */ 
/*      */         
/* 1347 */         if (escapedSqlResult instanceof String) {
/* 1348 */           sql = (String)escapedSqlResult;
/*      */         } else {
/* 1350 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         } 
/*      */       } 
/*      */       
/* 1354 */       char firstStatementChar = StringUtils.firstNonWsCharUc(sql, findStartOfStatement(sql));
/*      */ 
/*      */       
/* 1357 */       if (sql.charAt(0) == '/' && 
/* 1358 */         sql.startsWith("/* ping */")) {
/* 1359 */         doPingInstead();
/*      */         
/* 1361 */         return this.results;
/*      */       } 
/*      */ 
/*      */       
/* 1365 */       checkForDml(sql, firstStatementChar);
/*      */       
/* 1367 */       if (this.results != null && 
/* 1368 */         !locallyScopedConn.getHoldResultsOpenOverStatementClose()) {
/* 1369 */         this.results.realClose(false);
/*      */       }
/*      */ 
/*      */       
/* 1373 */       CachedResultSetMetaData cachedMetaData = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1382 */       if (useServerFetch()) {
/* 1383 */         this.results = createResultSetUsingServerFetch(sql);
/*      */         
/* 1385 */         return this.results;
/*      */       } 
/*      */       
/* 1388 */       CancelTask timeoutTask = null;
/*      */       
/* 1390 */       String oldCatalog = null;
/*      */       
/*      */       try {
/* 1393 */         if (locallyScopedConn.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */           
/* 1396 */           timeoutTask = new CancelTask(this, this);
/* 1397 */           ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         } 
/*      */ 
/*      */         
/* 1401 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1402 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1403 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1410 */         Field[] cachedFields = null;
/*      */         
/* 1412 */         if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1413 */           cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
/*      */           
/* 1415 */           if (cachedMetaData != null) {
/* 1416 */             cachedFields = cachedMetaData.fields;
/*      */           }
/*      */         } 
/*      */         
/* 1420 */         if (locallyScopedConn.useMaxRows()) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1425 */           if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
/* 1426 */             this.results = locallyScopedConn.execSQL(this, sql, this.maxRows, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 1432 */             if (this.maxRows <= 0) {
/* 1433 */               executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */             } else {
/*      */               
/* 1436 */               executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows);
/*      */             } 
/*      */ 
/*      */             
/* 1440 */             this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1446 */             if (oldCatalog != null) {
/* 1447 */               locallyScopedConn.setCatalog(oldCatalog);
/*      */             }
/*      */           } 
/*      */         } else {
/* 1451 */           this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, doStreaming, this.currentCatalog, cachedFields);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1457 */         if (timeoutTask != null) {
/* 1458 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1459 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1462 */           timeoutTask.cancel();
/* 1463 */           timeoutTask = null;
/*      */         } 
/*      */         
/* 1466 */         synchronized (this.cancelTimeoutMutex) {
/* 1467 */           if (this.wasCancelled) {
/* 1468 */             Object object = null;
/*      */             
/* 1470 */             if (this.wasCancelledByTimeout) {
/* 1471 */               MySQLTimeoutException mySQLTimeoutException = new MySQLTimeoutException();
/*      */             } else {
/* 1473 */               object = new MySQLStatementCancelledException();
/*      */             } 
/*      */             
/* 1476 */             resetCancelledState();
/*      */             
/* 1478 */             throw object;
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 1482 */         if (timeoutTask != null) {
/* 1483 */           timeoutTask.cancel();
/*      */         }
/*      */         
/* 1486 */         if (oldCatalog != null) {
/* 1487 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */       } 
/*      */       
/* 1491 */       this.lastInsertId = this.results.getUpdateID();
/*      */       
/* 1493 */       if (cachedMetaData != null) {
/* 1494 */         locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */       
/*      */       }
/* 1497 */       else if (this.connection.getCacheResultSetMetadata()) {
/* 1498 */         locallyScopedConn.initializeResultsMetadataFromCache(sql, null, this.results);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1503 */       return this.results;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void doPingInstead() throws SQLException {
/* 1508 */     if (this.pingTarget != null) {
/* 1509 */       this.pingTarget.doPing();
/*      */     } else {
/* 1511 */       this.connection.ping();
/*      */     } 
/*      */     
/* 1514 */     ResultSetInternalMethods fakeSelectOneResultSet = generatePingResultSet();
/* 1515 */     this.results = fakeSelectOneResultSet;
/*      */   }
/*      */   
/*      */   protected ResultSetInternalMethods generatePingResultSet() throws SQLException {
/* 1519 */     Field[] fields = { new Field(null, "1", -5, 1) };
/* 1520 */     ArrayList rows = new ArrayList();
/* 1521 */     byte[] colVal = { 49 };
/*      */     
/* 1523 */     rows.add(new ByteArrayRow(new byte[][] { colVal }, getExceptionInterceptor()));
/*      */     
/* 1525 */     return (ResultSetInternalMethods)DatabaseMetaData.buildResultSet(fields, rows, this.connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1531 */   protected void executeSimpleNonQuery(ConnectionImpl c, String nonQuery) throws SQLException { c.execSQL(this, nonQuery, -1, null, 1003, 1007, false, this.currentCatalog, null, false).close(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1553 */   public int executeUpdate(String sql) throws SQLException { return executeUpdate(sql, false, false); }
/*      */ 
/*      */ 
/*      */   
/*      */   protected int executeUpdate(String sql, boolean isBatch, boolean returnGeneratedKeys) throws SQLException {
/* 1558 */     checkClosed();
/*      */     
/* 1560 */     ConnectionImpl locallyScopedConn = this.connection;
/*      */     
/* 1562 */     char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
/*      */ 
/*      */     
/* 1565 */     ResultSetInternalMethods rs = null;
/*      */     
/* 1567 */     synchronized (locallyScopedConn.getMutex()) {
/* 1568 */       this.retrieveGeneratedKeys = returnGeneratedKeys;
/*      */       
/* 1570 */       resetCancelledState();
/*      */       
/* 1572 */       checkNullOrEmptyQuery(sql);
/*      */       
/* 1574 */       if (this.doEscapeProcessing) {
/* 1575 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.connection.serverSupportsConvertFn(), this.connection);
/*      */ 
/*      */         
/* 1578 */         if (escapedSqlResult instanceof String) {
/* 1579 */           sql = (String)escapedSqlResult;
/*      */         } else {
/* 1581 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         } 
/*      */       } 
/*      */       
/* 1585 */       if (locallyScopedConn.isReadOnly()) {
/* 1586 */         throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1592 */       if (StringUtils.startsWithIgnoreCaseAndWs(sql, "select")) {
/* 1593 */         throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1598 */       if (this.results != null && 
/* 1599 */         !locallyScopedConn.getHoldResultsOpenOverStatementClose()) {
/* 1600 */         this.results.realClose(false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1608 */       CancelTask timeoutTask = null;
/*      */       
/* 1610 */       String oldCatalog = null;
/*      */       
/*      */       try {
/* 1613 */         if (locallyScopedConn.getEnableQueryTimeouts() && this.timeoutInMillis != 0 && locallyScopedConn.versionMeetsMinimum(5, 0, 0)) {
/*      */ 
/*      */           
/* 1616 */           timeoutTask = new CancelTask(this, this);
/* 1617 */           ConnectionImpl.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         } 
/*      */ 
/*      */         
/* 1621 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1622 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1623 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1629 */         if (locallyScopedConn.useMaxRows()) {
/* 1630 */           executeSimpleNonQuery(locallyScopedConn, "SET OPTION SQL_SELECT_LIMIT=DEFAULT");
/*      */         }
/*      */ 
/*      */         
/* 1634 */         rs = locallyScopedConn.execSQL(this, sql, -1, null, 1003, 1007, false, this.currentCatalog, null, isBatch);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1641 */         if (timeoutTask != null) {
/* 1642 */           if (timeoutTask.caughtWhileCancelling != null) {
/* 1643 */             throw timeoutTask.caughtWhileCancelling;
/*      */           }
/*      */           
/* 1646 */           timeoutTask.cancel();
/* 1647 */           timeoutTask = null;
/*      */         } 
/*      */         
/* 1650 */         synchronized (this.cancelTimeoutMutex) {
/* 1651 */           if (this.wasCancelled) {
/* 1652 */             Object object = null;
/*      */             
/* 1654 */             if (this.wasCancelledByTimeout) {
/* 1655 */               MySQLTimeoutException mySQLTimeoutException = new MySQLTimeoutException();
/*      */             } else {
/* 1657 */               object = new MySQLStatementCancelledException();
/*      */             } 
/*      */             
/* 1660 */             resetCancelledState();
/*      */             
/* 1662 */             throw object;
/*      */           } 
/*      */         } 
/*      */       } finally {
/* 1666 */         if (timeoutTask != null) {
/* 1667 */           timeoutTask.cancel();
/*      */         }
/*      */         
/* 1670 */         if (oldCatalog != null) {
/* 1671 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 1676 */     this.results = rs;
/*      */     
/* 1678 */     rs.setFirstCharOfQuery(firstStatementChar);
/*      */     
/* 1680 */     this.updateCount = rs.getUpdateCount();
/*      */     
/* 1682 */     int truncatedUpdateCount = 0;
/*      */     
/* 1684 */     if (this.updateCount > 2147483647L) {
/* 1685 */       truncatedUpdateCount = Integer.MAX_VALUE;
/*      */     } else {
/* 1687 */       truncatedUpdateCount = (int)this.updateCount;
/*      */     } 
/*      */     
/* 1690 */     this.lastInsertId = rs.getUpdateID();
/*      */     
/* 1692 */     return truncatedUpdateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String sql, int returnGeneratedKeys) throws SQLException {
/* 1701 */     if (returnGeneratedKeys == 1) {
/* 1702 */       checkClosed();
/*      */       
/* 1704 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/* 1706 */       synchronized (locallyScopedConn.getMutex()) {
/*      */ 
/*      */ 
/*      */         
/* 1710 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */         
/* 1712 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         
/*      */         try {
/* 1715 */           return executeUpdate(sql, false, true);
/*      */         } finally {
/* 1717 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1722 */     return executeUpdate(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String sql, int[] generatedKeyIndices) throws SQLException {
/* 1730 */     if (generatedKeyIndices != null && generatedKeyIndices.length > 0) {
/* 1731 */       checkClosed();
/*      */       
/* 1733 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/* 1735 */       synchronized (locallyScopedConn.getMutex()) {
/*      */ 
/*      */ 
/*      */         
/* 1739 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */         
/* 1741 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         
/*      */         try {
/* 1744 */           return executeUpdate(sql, false, true);
/*      */         } finally {
/* 1746 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1751 */     return executeUpdate(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String sql, String[] generatedKeyNames) throws SQLException {
/* 1759 */     if (generatedKeyNames != null && generatedKeyNames.length > 0) {
/* 1760 */       checkClosed();
/*      */       
/* 1762 */       ConnectionImpl locallyScopedConn = this.connection;
/*      */       
/* 1764 */       synchronized (locallyScopedConn.getMutex()) {
/*      */ 
/*      */ 
/*      */         
/* 1768 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */         
/* 1770 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         
/*      */         try {
/* 1773 */           return executeUpdate(sql, false, true);
/*      */         } finally {
/* 1775 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1780 */     return executeUpdate(sql);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Calendar getCalendarInstanceForSessionOrNew() {
/* 1788 */     if (this.connection != null) {
/* 1789 */       return this.connection.getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */     
/* 1792 */     return new GregorianCalendar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1805 */   public Connection getConnection() throws SQLException { return this.connection; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1817 */   public int getFetchDirection() throws SQLException { return 1000; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1829 */   public int getFetchSize() throws SQLException { return this.fetchSize; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized ResultSet getGeneratedKeys() throws SQLException {
/* 1842 */     if (!this.retrieveGeneratedKeys) {
/* 1843 */       throw SQLError.createSQLException(Messages.getString("Statement.GeneratedKeysNotRequested"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */     
/* 1846 */     if (this.batchedGeneratedKeys == null) {
/* 1847 */       if (this.lastQueryIsOnDupKeyUpdate) {
/* 1848 */         return getGeneratedKeysInternal(1);
/*      */       }
/* 1850 */       return getGeneratedKeysInternal();
/*      */     } 
/*      */     
/* 1853 */     Field[] fields = new Field[1];
/* 1854 */     fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1855 */     fields[0].setConnection(this.connection);
/*      */     
/* 1857 */     return ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(this.batchedGeneratedKeys), this.connection, this, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected ResultSet getGeneratedKeysInternal() throws SQLException {
/* 1869 */     int numKeys = getUpdateCount();
/* 1870 */     return getGeneratedKeysInternal(numKeys);
/*      */   }
/*      */ 
/*      */   
/*      */   protected synchronized ResultSet getGeneratedKeysInternal(int numKeys) throws SQLException {
/* 1875 */     Field[] fields = new Field[1];
/* 1876 */     fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1877 */     fields[0].setConnection(this.connection);
/* 1878 */     fields[0].setUseOldNameMetadata(true);
/*      */     
/* 1880 */     ArrayList rowSet = new ArrayList();
/*      */     
/* 1882 */     long beginAt = getLastInsertID();
/*      */     
/* 1884 */     if (beginAt < 0L) {
/* 1885 */       fields[0].setUnsigned();
/*      */     }
/*      */     
/* 1888 */     if (this.results != null) {
/* 1889 */       String serverInfo = this.results.getServerInfo();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1895 */       if (numKeys > 0 && this.results.getFirstCharOfQuery() == 'R' && serverInfo != null && serverInfo.length() > 0)
/*      */       {
/* 1897 */         numKeys = getRecordCountFromInfo(serverInfo);
/*      */       }
/*      */       
/* 1900 */       if (beginAt != 0L && numKeys > 0) {
/* 1901 */         for (int i = 0; i < numKeys; i++) {
/* 1902 */           byte[][] row = new byte[1][];
/* 1903 */           if (beginAt > 0L) {
/* 1904 */             row[0] = Long.toString(beginAt).getBytes();
/*      */           } else {
/* 1906 */             byte[] asBytes = new byte[8];
/* 1907 */             asBytes[7] = (byte)(int)(beginAt & 0xFFL);
/* 1908 */             asBytes[6] = (byte)(int)(beginAt >>> 8);
/* 1909 */             asBytes[5] = (byte)(int)(beginAt >>> 16);
/* 1910 */             asBytes[4] = (byte)(int)(beginAt >>> 24);
/* 1911 */             asBytes[3] = (byte)(int)(beginAt >>> 32);
/* 1912 */             asBytes[2] = (byte)(int)(beginAt >>> 40);
/* 1913 */             asBytes[1] = (byte)(int)(beginAt >>> 48);
/* 1914 */             asBytes[0] = (byte)(int)(beginAt >>> 56);
/*      */             
/* 1916 */             BigInteger val = new BigInteger(1, asBytes);
/*      */             
/* 1918 */             row[0] = val.toString().getBytes();
/*      */           } 
/* 1920 */           rowSet.add(new ByteArrayRow(row, getExceptionInterceptor()));
/* 1921 */           beginAt += this.connection.getAutoIncrementIncrement();
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 1926 */     ResultSetImpl gkRs = ResultSetImpl.getInstance(this.currentCatalog, fields, new RowDataStatic(rowSet), this.connection, this, false);
/*      */ 
/*      */     
/* 1929 */     this.openResults.add(gkRs);
/*      */     
/* 1931 */     return gkRs;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1940 */   protected int getId() { return this.statementId; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1957 */   public long getLastInsertID() { return this.lastInsertId; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLongUpdateCount() {
/* 1973 */     if (this.results == null) {
/* 1974 */       return -1L;
/*      */     }
/*      */     
/* 1977 */     if (this.results.reallyResult()) {
/* 1978 */       return -1L;
/*      */     }
/*      */     
/* 1981 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1996 */   public int getMaxFieldSize() throws SQLException { return this.maxFieldSize; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() throws SQLException {
/* 2010 */     if (this.maxRows <= 0) {
/* 2011 */       return 0;
/*      */     }
/*      */     
/* 2014 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2027 */   public boolean getMoreResults() throws SQLException { return getMoreResults(1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean getMoreResults(int current) throws SQLException {
/* 2035 */     if (this.results == null) {
/* 2036 */       return false;
/*      */     }
/*      */     
/* 2039 */     boolean streamingMode = createStreamingResultSet();
/*      */     
/* 2041 */     if (streamingMode && 
/* 2042 */       this.results.reallyResult()) {
/* 2043 */       while (this.results.next());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2048 */     ResultSetInternalMethods nextResultSet = this.results.getNextResultSet();
/*      */     
/* 2050 */     switch (current) {
/*      */       
/*      */       case 1:
/* 2053 */         if (this.results != null) {
/* 2054 */           if (!streamingMode) {
/* 2055 */             this.results.close();
/*      */           }
/*      */           
/* 2058 */           this.results.clearNextResult();
/*      */         } 
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 3:
/* 2065 */         if (this.results != null) {
/* 2066 */           if (!streamingMode) {
/* 2067 */             this.results.close();
/*      */           }
/*      */           
/* 2070 */           this.results.clearNextResult();
/*      */         } 
/*      */         
/* 2073 */         closeAllOpenResults();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 2:
/* 2078 */         if (!this.connection.getDontTrackOpenResources()) {
/* 2079 */           this.openResults.add(this.results);
/*      */         }
/*      */         
/* 2082 */         this.results.clearNextResult();
/*      */         break;
/*      */ 
/*      */       
/*      */       default:
/* 2087 */         throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2092 */     this.results = nextResultSet;
/*      */     
/* 2094 */     if (this.results == null) {
/* 2095 */       this.updateCount = -1L;
/* 2096 */       this.lastInsertId = -1L;
/* 2097 */     } else if (this.results.reallyResult()) {
/* 2098 */       this.updateCount = -1L;
/* 2099 */       this.lastInsertId = -1L;
/*      */     } else {
/* 2101 */       this.updateCount = this.results.getUpdateCount();
/* 2102 */       this.lastInsertId = this.results.getUpdateID();
/*      */     } 
/*      */     
/* 2105 */     return (this.results != null && this.results.reallyResult());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2120 */   public int getQueryTimeout() throws SQLException { return this.timeoutInMillis / 1000; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getRecordCountFromInfo(String serverInfo) {
/* 2132 */     StringBuffer recordsBuf = new StringBuffer();
/* 2133 */     int recordsCount = 0;
/* 2134 */     int duplicatesCount = 0;
/*      */     
/* 2136 */     char c = Character.MIN_VALUE;
/*      */     
/* 2138 */     int length = serverInfo.length();
/* 2139 */     int i = 0;
/*      */     
/* 2141 */     for (; i < length; i++) {
/* 2142 */       c = serverInfo.charAt(i);
/*      */       
/* 2144 */       if (Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 2149 */     recordsBuf.append(c);
/* 2150 */     i++;
/*      */     
/* 2152 */     for (; i < length; i++) {
/* 2153 */       c = serverInfo.charAt(i);
/*      */       
/* 2155 */       if (!Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */       
/* 2159 */       recordsBuf.append(c);
/*      */     } 
/*      */     
/* 2162 */     recordsCount = Integer.parseInt(recordsBuf.toString());
/*      */     
/* 2164 */     StringBuffer duplicatesBuf = new StringBuffer();
/*      */     
/* 2166 */     for (; i < length; i++) {
/* 2167 */       c = serverInfo.charAt(i);
/*      */       
/* 2169 */       if (Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */     
/* 2174 */     duplicatesBuf.append(c);
/* 2175 */     i++;
/*      */     
/* 2177 */     for (; i < length; i++) {
/* 2178 */       c = serverInfo.charAt(i);
/*      */       
/* 2180 */       if (!Character.isDigit(c)) {
/*      */         break;
/*      */       }
/*      */       
/* 2184 */       duplicatesBuf.append(c);
/*      */     } 
/*      */     
/* 2187 */     duplicatesCount = Integer.parseInt(duplicatesBuf.toString());
/*      */     
/* 2189 */     return recordsCount - duplicatesCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2202 */   public ResultSet getResultSet() throws SQLException { return (this.results != null && this.results.reallyResult()) ? this.results : null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2215 */   public int getResultSetConcurrency() throws SQLException { return this.resultSetConcurrency; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2222 */   public int getResultSetHoldability() throws SQLException { return 1; }
/*      */ 
/*      */ 
/*      */   
/* 2226 */   protected ResultSetInternalMethods getResultSetInternal() { return this.results; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2238 */   public int getResultSetType() throws SQLException { return this.resultSetType; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 2252 */     if (this.results == null) {
/* 2253 */       return -1;
/*      */     }
/*      */     
/* 2256 */     if (this.results.reallyResult()) {
/* 2257 */       return -1;
/*      */     }
/*      */     
/* 2260 */     int truncatedUpdateCount = 0;
/*      */     
/* 2262 */     if (this.results.getUpdateCount() > 2147483647L) {
/* 2263 */       truncatedUpdateCount = Integer.MAX_VALUE;
/*      */     } else {
/* 2265 */       truncatedUpdateCount = (int)this.results.getUpdateCount();
/*      */     } 
/*      */     
/* 2268 */     return truncatedUpdateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 2293 */     checkClosed();
/*      */     
/* 2295 */     if (this.connection != null && !this.connection.isClosed() && this.connection.versionMeetsMinimum(4, 1, 0)) {
/*      */       
/* 2297 */       SQLWarning pendingWarningsFromServer = SQLError.convertShowWarningsToSQLWarnings(this.connection);
/*      */ 
/*      */       
/* 2300 */       if (this.warningChain != null) {
/* 2301 */         this.warningChain.setNextWarning(pendingWarningsFromServer);
/*      */       } else {
/* 2303 */         this.warningChain = pendingWarningsFromServer;
/*      */       } 
/*      */       
/* 2306 */       return this.warningChain;
/*      */     } 
/*      */     
/* 2309 */     return this.warningChain;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void realClose(boolean calledExplicitly, boolean closeOpenResults) throws SQLException {
/* 2323 */     if (this.isClosed) {
/*      */       return;
/*      */     }
/*      */     
/* 2327 */     if (this.useUsageAdvisor && 
/* 2328 */       !calledExplicitly) {
/* 2329 */       String message = Messages.getString("Statement.63") + Messages.getString("Statement.64");
/*      */ 
/*      */       
/* 2332 */       this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2342 */     if (closeOpenResults) {
/* 2343 */       closeOpenResults = !this.holdResultsOpenOverClose;
/*      */     }
/*      */     
/* 2346 */     if (closeOpenResults) {
/* 2347 */       if (this.results != null) {
/*      */         
/*      */         try {
/* 2350 */           this.results.close();
/* 2351 */         } catch (Exception ex) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2356 */       closeAllOpenResults();
/*      */     } 
/*      */     
/* 2359 */     if (this.connection != null) {
/* 2360 */       if (this.maxRowsChanged) {
/* 2361 */         this.connection.unsetMaxRows(this);
/*      */       }
/*      */       
/* 2364 */       if (!this.connection.getDontTrackOpenResources()) {
/* 2365 */         this.connection.unregisterStatement(this);
/*      */       }
/*      */     } 
/*      */     
/* 2369 */     this.isClosed = true;
/*      */     
/* 2371 */     this.results = null;
/* 2372 */     this.connection = null;
/* 2373 */     this.warningChain = null;
/* 2374 */     this.openResults = null;
/* 2375 */     this.batchedGeneratedKeys = null;
/* 2376 */     this.localInfileInputStream = null;
/* 2377 */     this.pingTarget = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorName(String name) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2413 */   public void setEscapeProcessing(boolean enable) throws SQLException { this.doEscapeProcessing = enable; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int direction) throws SQLException {
/* 2430 */     switch (direction) {
/*      */       case 1000:
/*      */       case 1001:
/*      */       case 1002:
/*      */         return;
/*      */     } 
/*      */     
/* 2437 */     throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int rows) throws SQLException {
/* 2458 */     if ((rows < 0 && rows != Integer.MIN_VALUE) || (this.maxRows != 0 && this.maxRows != -1 && rows > getMaxRows()))
/*      */     {
/*      */       
/* 2461 */       throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2466 */     this.fetchSize = rows;
/*      */   }
/*      */ 
/*      */   
/* 2470 */   protected void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose) { this.holdResultsOpenOverClose = holdResultsOpenOverClose; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxFieldSize(int max) throws SQLException {
/* 2483 */     if (max < 0) {
/* 2484 */       throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2489 */     int maxBuf = (this.connection != null) ? this.connection.getMaxAllowedPacket() : MysqlIO.getMaxBuf();
/*      */ 
/*      */     
/* 2492 */     if (max > maxBuf) {
/* 2493 */       throw SQLError.createSQLException(Messages.getString("Statement.13", new Object[] { Constants.longValueOf(maxBuf) }), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2499 */     this.maxFieldSize = max;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int max) throws SQLException {
/* 2514 */     if (max > 50000000 || max < 0) {
/* 2515 */       throw SQLError.createSQLException(Messages.getString("Statement.15") + max + " > " + 50000000 + ".", "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2522 */     if (max == 0) {
/* 2523 */       max = -1;
/*      */     }
/*      */     
/* 2526 */     this.maxRows = max;
/* 2527 */     this.maxRowsChanged = true;
/*      */     
/* 2529 */     if (this.maxRows == -1) {
/* 2530 */       this.connection.unsetMaxRows(this);
/* 2531 */       this.maxRowsChanged = false;
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2538 */       this.connection.maxRowsChanged(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int seconds) throws SQLException {
/* 2552 */     if (seconds < 0) {
/* 2553 */       throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 2558 */     this.timeoutInMillis = seconds * 1000;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2568 */   void setResultSetConcurrency(int concurrencyFlag) { this.resultSetConcurrency = concurrencyFlag; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2578 */   void setResultSetType(int typeFlag) { this.resultSetType = typeFlag; }
/*      */ 
/*      */   
/*      */   protected void getBatchedGeneratedKeys(Statement batchedStatement) throws SQLException {
/* 2582 */     if (this.retrieveGeneratedKeys) {
/* 2583 */       ResultSet rs = null;
/*      */       
/*      */       try {
/* 2586 */         rs = batchedStatement.getGeneratedKeys();
/*      */         
/* 2588 */         while (rs.next()) {
/* 2589 */           this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */         } 
/*      */       } finally {
/*      */         
/* 2593 */         if (rs != null) {
/* 2594 */           rs.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void getBatchedGeneratedKeys(int maxKeys) throws SQLException {
/* 2601 */     if (this.retrieveGeneratedKeys) {
/* 2602 */       ResultSet rs = null;
/*      */       
/*      */       try {
/* 2605 */         if (maxKeys == 0) {
/* 2606 */           rs = getGeneratedKeysInternal();
/*      */         } else {
/* 2608 */           rs = getGeneratedKeysInternal(maxKeys);
/*      */         } 
/* 2610 */         while (rs.next()) {
/* 2611 */           this.batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
/*      */         } 
/*      */       } finally {
/*      */         
/* 2615 */         if (rs != null) {
/* 2616 */           rs.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2627 */   private boolean useServerFetch() throws SQLException { return (this.connection.isCursorFetchEnabled() && this.fetchSize > 0 && this.resultSetConcurrency == 1007 && this.resultSetType == 1003); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2633 */   public synchronized boolean isClosed() throws SQLException { return this.isClosed; }
/*      */ 
/*      */   
/*      */   private boolean isPoolable = true;
/*      */   private InputStream localInfileInputStream;
/*      */   
/* 2639 */   public boolean isPoolable() throws SQLException { return this.isPoolable; }
/*      */ 
/*      */ 
/*      */   
/* 2643 */   public void setPoolable(boolean poolable) throws SQLException { this.isPoolable = poolable; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class iface) throws SQLException {
/* 2662 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 2666 */     return iface.isInstance(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object unwrap(Class iface) throws SQLException {
/*      */     try {
/* 2687 */       return Util.cast(iface, this);
/* 2688 */     } catch (ClassCastException cce) {
/* 2689 */       throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int findStartOfStatement(String sql) {
/* 2695 */     int statementStartPos = 0;
/*      */     
/* 2697 */     if (StringUtils.startsWithIgnoreCaseAndWs(sql, "/*")) {
/* 2698 */       statementStartPos = sql.indexOf("*/");
/*      */       
/* 2700 */       if (statementStartPos == -1) {
/* 2701 */         statementStartPos = 0;
/*      */       } else {
/* 2703 */         statementStartPos += 2;
/*      */       } 
/* 2705 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "--") || StringUtils.startsWithIgnoreCaseAndWs(sql, "#")) {
/*      */       
/* 2707 */       statementStartPos = sql.indexOf('\n');
/*      */       
/* 2709 */       if (statementStartPos == -1) {
/* 2710 */         statementStartPos = sql.indexOf('\r');
/*      */         
/* 2712 */         if (statementStartPos == -1) {
/* 2713 */           statementStartPos = 0;
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2718 */     return statementStartPos;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2724 */   public synchronized InputStream getLocalInfileInputStream() { return this.localInfileInputStream; }
/*      */ 
/*      */ 
/*      */   
/* 2728 */   public synchronized void setLocalInfileInputStream(InputStream stream) { this.localInfileInputStream = stream; }
/*      */ 
/*      */ 
/*      */   
/* 2732 */   public synchronized void setPingTarget(PingTarget pingTarget) { this.pingTarget = pingTarget; }
/*      */ 
/*      */ 
/*      */   
/* 2736 */   public ExceptionInterceptor getExceptionInterceptor() { return this.exceptionInterceptor; }
/*      */ 
/*      */ 
/*      */   
/* 2740 */   protected boolean containsOnDuplicateKeyInString(String sql) { return (getOnDuplicateKeyLocation(sql) != -1); }
/*      */ 
/*      */ 
/*      */   
/* 2744 */   protected int getOnDuplicateKeyLocation(String sql) { return StringUtils.indexOfIgnoreCaseRespectMarker(0, sql, " ON DUPLICATE KEY UPDATE ", "\"'`", "\"'`", !this.connection.isNoBackslashEscapesSet()); }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/StatementImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */