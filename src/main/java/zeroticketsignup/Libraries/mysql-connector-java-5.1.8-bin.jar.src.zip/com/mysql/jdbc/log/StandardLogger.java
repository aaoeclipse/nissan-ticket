/*     */ package com.mysql.jdbc.log;
/*     */ 
/*     */ import com.mysql.jdbc.Util;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StandardLogger
/*     */   implements Log
/*     */ {
/*     */   private static final int FATAL = 0;
/*     */   private static final int ERROR = 1;
/*     */   private static final int WARN = 2;
/*     */   private static final int INFO = 3;
/*     */   private static final int DEBUG = 4;
/*     */   private static final int TRACE = 5;
/*  53 */   public static StringBuffer bufferedLog = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean logLocationInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public StandardLogger(String name) { this(name, false); }
/*     */   
/*     */   public StandardLogger(String name, boolean logLocationInfo) {
/*     */     this.logLocationInfo = true;
/*  68 */     this.logLocationInfo = logLocationInfo;
/*     */   }
/*     */   
/*     */   public static void saveLogsToBuffer() {
/*  72 */     if (bufferedLog == null) {
/*  73 */       bufferedLog = new StringBuffer();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  81 */   public boolean isDebugEnabled() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public boolean isErrorEnabled() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   public boolean isFatalEnabled() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public boolean isInfoEnabled() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public boolean isTraceEnabled() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public boolean isWarnEnabled() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public void logDebug(Object message) { logInternal(4, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void logDebug(Object message, Throwable exception) { logInternal(4, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 148 */   public void logError(Object message) { logInternal(1, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public void logError(Object message, Throwable exception) { logInternal(1, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 170 */   public void logFatal(Object message) { logInternal(0, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void logFatal(Object message, Throwable exception) { logInternal(0, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public void logInfo(Object message) { logInternal(3, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public void logInfo(Object message, Throwable exception) { logInternal(3, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 214 */   public void logTrace(Object message) { logInternal(5, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public void logTrace(Object message, Throwable exception) { logInternal(5, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public void logWarn(Object message) { logInternal(2, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public void logWarn(Object message, Throwable exception) { logInternal(2, message, exception); }
/*     */ 
/*     */   
/*     */   private void logInternal(int level, Object msg, Throwable exception) {
/* 252 */     StringBuffer msgBuf = new StringBuffer();
/* 253 */     msgBuf.append((new Date()).toString());
/* 254 */     msgBuf.append(" ");
/*     */     
/* 256 */     switch (level) {
/*     */       case 0:
/* 258 */         msgBuf.append("FATAL: ");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/* 263 */         msgBuf.append("ERROR: ");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 2:
/* 268 */         msgBuf.append("WARN: ");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 3:
/* 273 */         msgBuf.append("INFO: ");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 4:
/* 278 */         msgBuf.append("DEBUG: ");
/*     */         break;
/*     */ 
/*     */       
/*     */       case 5:
/* 283 */         msgBuf.append("TRACE: ");
/*     */         break;
/*     */     } 
/*     */ 
/*     */     
/* 288 */     if (msg instanceof com.mysql.jdbc.profiler.ProfilerEvent) {
/* 289 */       msgBuf.append(LogUtils.expandProfilerEventIfNecessary(msg));
/*     */     } else {
/*     */       
/* 292 */       if (this.logLocationInfo && level != 5) {
/* 293 */         Throwable locationException = new Throwable();
/* 294 */         msgBuf.append(LogUtils.findCallingClassAndMethod(locationException));
/*     */         
/* 296 */         msgBuf.append(" ");
/*     */       } 
/*     */       
/* 299 */       if (msg != null) {
/* 300 */         msgBuf.append(String.valueOf(msg));
/*     */       }
/*     */     } 
/*     */     
/* 304 */     if (exception != null) {
/* 305 */       msgBuf.append("\n");
/* 306 */       msgBuf.append("\n");
/* 307 */       msgBuf.append("EXCEPTION STACK TRACE:");
/* 308 */       msgBuf.append("\n");
/* 309 */       msgBuf.append("\n");
/* 310 */       msgBuf.append(Util.stackTraceToString(exception));
/*     */     } 
/*     */     
/* 313 */     String messageAsString = msgBuf.toString();
/*     */     
/* 315 */     System.err.println(messageAsString);
/*     */     
/* 317 */     if (bufferedLog != null)
/* 318 */       bufferedLog.append(messageAsString); 
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/log/StandardLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */