/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MySQLTimeoutException
/*    */   extends MySQLTransientException
/*    */ {
/* 29 */   public MySQLTimeoutException(String reason, String SQLState, int vendorCode) { super(reason, SQLState, vendorCode); }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public MySQLTimeoutException(String reason, String SQLState) { super(reason, SQLState); }
/*    */ 
/*    */ 
/*    */   
/* 37 */   public MySQLTimeoutException(String reason) { super(reason); }
/*    */ 
/*    */ 
/*    */   
/* 41 */   public MySQLTimeoutException() { super("Statement cancelled due to timeout or client request"); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/exceptions/MySQLTimeoutException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */