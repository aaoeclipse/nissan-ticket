/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.NClob;
/*     */ import java.sql.RowId;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JDBC4ResultSet
/*     */   extends ResultSetImpl
/*     */ {
/*  47 */   public JDBC4ResultSet(long updateCount, long updateID, ConnectionImpl conn, StatementImpl creatorStmt) { super(updateCount, updateID, conn, creatorStmt); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public JDBC4ResultSet(String catalog, Field[] fields, RowData tuples, ConnectionImpl conn, StatementImpl creatorStmt) throws SQLException { super(catalog, fields, tuples, conn, creatorStmt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reader getNCharacterStream(int columnIndex) throws SQLException {
/*  71 */     checkColumnBounds(columnIndex);
/*     */     
/*  73 */     String fieldEncoding = this.fields[columnIndex - 1].getCharacterSet();
/*  74 */     if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/*  75 */       throw new SQLException("Can not call getNCharacterStream() when field's charset isn't UTF-8");
/*     */     }
/*     */     
/*  78 */     return getCharacterStream(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public Reader getNCharacterStream(String columnName) throws SQLException { return getNCharacterStream(findColumn(columnName)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NClob getNClob(int columnIndex) throws SQLException {
/* 112 */     checkColumnBounds(columnIndex);
/*     */     
/* 114 */     String fieldEncoding = this.fields[columnIndex - 1].getCharacterSet();
/* 115 */     if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 116 */       throw new SQLException("Can not call getNClob() when field's charset isn't UTF-8");
/*     */     }
/*     */     
/* 119 */     if (!this.isBinaryEncoded) {
/* 120 */       String asString = getStringForNClob(columnIndex);
/*     */       
/* 122 */       if (asString == null) {
/* 123 */         return null;
/*     */       }
/*     */       
/* 126 */       return new JDBC4NClob(asString, getExceptionInterceptor());
/*     */     } 
/*     */     
/* 129 */     return getNativeNClob(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public NClob getNClob(String columnName) throws SQLException { return getNClob(findColumn(columnName)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected NClob getNativeNClob(int columnIndex) throws SQLException {
/* 160 */     String stringVal = getStringForNClob(columnIndex);
/*     */     
/* 162 */     if (stringVal == null) {
/* 163 */       return null;
/*     */     }
/*     */     
/* 166 */     return getNClobFromString(stringVal, columnIndex);
/*     */   }
/*     */   
/*     */   private String getStringForNClob(int columnIndex) throws SQLException {
/* 170 */     String asString = null;
/*     */     
/* 172 */     String forcedEncoding = "UTF-8";
/*     */     
/*     */     try {
/* 175 */       byte[] asBytes = null;
/*     */       
/* 177 */       if (!this.isBinaryEncoded) {
/* 178 */         asBytes = getBytes(columnIndex);
/*     */       } else {
/* 180 */         asBytes = getNativeBytes(columnIndex, true);
/*     */       } 
/*     */       
/* 183 */       if (asBytes != null) {
/* 184 */         asString = new String(asBytes, forcedEncoding);
/*     */       }
/* 186 */     } catch (UnsupportedEncodingException uee) {
/* 187 */       throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*     */     } 
/*     */ 
/*     */     
/* 191 */     return asString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 196 */   private final NClob getNClobFromString(String stringVal, int columnIndex) throws SQLException { return new JDBC4NClob(stringVal, getExceptionInterceptor()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNString(int columnIndex) throws SQLException {
/* 213 */     checkColumnBounds(columnIndex);
/*     */     
/* 215 */     String fieldEncoding = this.fields[columnIndex - 1].getCharacterSet();
/* 216 */     if (fieldEncoding == null || !fieldEncoding.equals("UTF-8")) {
/* 217 */       throw new SQLException("Can not call getNString() when field's charset isn't UTF-8");
/*     */     }
/*     */     
/* 220 */     return getString(columnIndex);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public String getNString(String columnName) throws SQLException { return getNString(findColumn(columnName)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public void updateNCharacterStream(int columnIndex, Reader x, int length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 284 */   public void updateNCharacterStream(String columnName, Reader reader, int length) throws SQLException { updateNCharacterStream(findColumn(columnName), reader, length); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public void updateNClob(String columnName, NClob nClob) throws SQLException { updateNClob(findColumn(columnName), nClob); }
/*     */ 
/*     */ 
/*     */   
/* 295 */   public void updateRowId(int columnIndex, RowId x) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */   
/* 299 */   public void updateRowId(String columnName, RowId x) throws SQLException { updateRowId(findColumn(columnName), x); }
/*     */ 
/*     */ 
/*     */   
/* 303 */   public int getHoldability() throws SQLException { throw SQLError.notImplemented(); }
/*     */ 
/*     */ 
/*     */   
/* 307 */   public RowId getRowId(int columnIndex) throws SQLException { throw SQLError.notImplemented(); }
/*     */ 
/*     */ 
/*     */   
/* 311 */   public RowId getRowId(String columnLabel) throws SQLException { return getRowId(findColumn(columnLabel)); }
/*     */ 
/*     */   
/*     */   public SQLXML getSQLXML(int columnIndex) throws SQLException {
/* 315 */     checkColumnBounds(columnIndex);
/*     */     
/* 317 */     return new JDBC4MysqlSQLXML(this, columnIndex, getExceptionInterceptor());
/*     */   }
/*     */ 
/*     */   
/* 321 */   public SQLXML getSQLXML(String columnLabel) throws SQLException { return getSQLXML(findColumn(columnLabel)); }
/*     */ 
/*     */ 
/*     */   
/* 325 */   public synchronized boolean isClosed() throws SQLException { return this.isClosed; }
/*     */ 
/*     */ 
/*     */   
/* 329 */   public void updateAsciiStream(int columnIndex, InputStream x) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   public void updateAsciiStream(String columnLabel, InputStream x) throws SQLException { updateAsciiStream(findColumn(columnLabel), x); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 339 */   public void updateAsciiStream(int columnIndex, InputStream x, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 344 */   public void updateAsciiStream(String columnLabel, InputStream x, long length) throws SQLException { updateAsciiStream(findColumn(columnLabel), x, length); }
/*     */ 
/*     */ 
/*     */   
/* 348 */   public void updateBinaryStream(int columnIndex, InputStream x) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 353 */   public void updateBinaryStream(String columnLabel, InputStream x) throws SQLException { updateBinaryStream(findColumn(columnLabel), x); }
/*     */ 
/*     */ 
/*     */   
/* 357 */   public void updateBinaryStream(int columnIndex, InputStream x, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 362 */   public void updateBinaryStream(String columnLabel, InputStream x, long length) throws SQLException { updateBinaryStream(findColumn(columnLabel), x, length); }
/*     */ 
/*     */ 
/*     */   
/* 366 */   public void updateBlob(int columnIndex, InputStream inputStream) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */   
/* 370 */   public void updateBlob(String columnLabel, InputStream inputStream) throws SQLException { updateBlob(findColumn(columnLabel), inputStream); }
/*     */ 
/*     */ 
/*     */   
/* 374 */   public void updateBlob(int columnIndex, InputStream inputStream, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 379 */   public void updateBlob(String columnLabel, InputStream inputStream, long length) throws SQLException { updateBlob(findColumn(columnLabel), inputStream, length); }
/*     */ 
/*     */ 
/*     */   
/* 383 */   public void updateCharacterStream(int columnIndex, Reader x) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 388 */   public void updateCharacterStream(String columnLabel, Reader reader) throws SQLException { updateCharacterStream(findColumn(columnLabel), reader); }
/*     */ 
/*     */ 
/*     */   
/* 392 */   public void updateCharacterStream(int columnIndex, Reader x, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 397 */   public void updateCharacterStream(String columnLabel, Reader reader, long length) throws SQLException { updateCharacterStream(findColumn(columnLabel), reader, length); }
/*     */ 
/*     */ 
/*     */   
/* 401 */   public void updateClob(int columnIndex, Reader reader) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 406 */   public void updateClob(String columnLabel, Reader reader) throws SQLException { updateClob(findColumn(columnLabel), reader); }
/*     */ 
/*     */ 
/*     */   
/* 410 */   public void updateClob(int columnIndex, Reader reader, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 415 */   public void updateClob(String columnLabel, Reader reader, long length) throws SQLException { updateClob(findColumn(columnLabel), reader, length); }
/*     */ 
/*     */ 
/*     */   
/* 419 */   public void updateNCharacterStream(int columnIndex, Reader x) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 424 */   public void updateNCharacterStream(String columnLabel, Reader reader) throws SQLException { updateNCharacterStream(findColumn(columnLabel), reader); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 429 */   public void updateNCharacterStream(int columnIndex, Reader x, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 434 */   public void updateNCharacterStream(String columnLabel, Reader reader, long length) throws SQLException { updateNCharacterStream(findColumn(columnLabel), reader, length); }
/*     */ 
/*     */ 
/*     */   
/* 438 */   public void updateNClob(int columnIndex, NClob nClob) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 443 */   public void updateNClob(int columnIndex, Reader reader) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 448 */   public void updateNClob(String columnLabel, Reader reader) throws SQLException { updateNClob(findColumn(columnLabel), reader); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 453 */   public void updateNClob(int columnIndex, Reader reader, long length) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */   
/* 457 */   public void updateNClob(String columnLabel, Reader reader, long length) throws SQLException { updateNClob(findColumn(columnLabel), reader, length); }
/*     */ 
/*     */ 
/*     */   
/* 461 */   public void updateNString(int columnIndex, String nString) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 466 */   public void updateNString(String columnLabel, String nString) throws SQLException { updateNString(findColumn(columnLabel), nString); }
/*     */ 
/*     */ 
/*     */   
/* 470 */   public void updateSQLXML(int columnIndex, SQLXML xmlObject) throws SQLException { throw new NotUpdatable(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 475 */   public void updateSQLXML(String columnLabel, SQLXML xmlObject) throws SQLException { updateSQLXML(findColumn(columnLabel), xmlObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 495 */     checkClosed();
/*     */ 
/*     */ 
/*     */     
/* 499 */     return iface.isInstance(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T> T unwrap(Class<T> iface) throws SQLException {
/*     */     try {
/* 520 */       return iface.cast(this);
/* 521 */     } catch (ClassCastException cce) {
/* 522 */       throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", getExceptionInterceptor());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/JDBC4ResultSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */