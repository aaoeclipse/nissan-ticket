/*     */ package com.mysql.jdbc.log;
/*     */ 
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk14Logger
/*     */   implements Log
/*     */ {
/*  40 */   private static final Level DEBUG = Level.FINE;
/*     */   
/*  42 */   private static final Level ERROR = Level.SEVERE;
/*     */   
/*  44 */   private static final Level FATAL = Level.SEVERE;
/*     */   
/*  46 */   private static final Level INFO = Level.INFO;
/*     */   
/*  48 */   private static final Level TRACE = Level.FINEST;
/*     */   
/*  50 */   private static final Level WARN = Level.WARNING;
/*     */   
/*     */   protected Logger jdkLogger;
/*     */   
/*     */   public Jdk14Logger(String name) {
/*  55 */     this.jdkLogger = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  64 */     this.jdkLogger = Logger.getLogger(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public boolean isDebugEnabled() { return this.jdkLogger.isLoggable(Level.FINE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public boolean isErrorEnabled() { return this.jdkLogger.isLoggable(Level.SEVERE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  85 */   public boolean isFatalEnabled() { return this.jdkLogger.isLoggable(Level.SEVERE); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public boolean isInfoEnabled() { return this.jdkLogger.isLoggable(Level.INFO); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public boolean isTraceEnabled() { return this.jdkLogger.isLoggable(Level.FINEST); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public boolean isWarnEnabled() { return this.jdkLogger.isLoggable(Level.WARNING); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void logDebug(Object message) { logInternal(DEBUG, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public void logDebug(Object message, Throwable exception) { logInternal(DEBUG, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void logError(Object message) { logInternal(ERROR, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public void logError(Object message, Throwable exception) { logInternal(ERROR, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 160 */   public void logFatal(Object message) { logInternal(FATAL, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 172 */   public void logFatal(Object message, Throwable exception) { logInternal(FATAL, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void logInfo(Object message) { logInternal(INFO, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 194 */   public void logInfo(Object message, Throwable exception) { logInternal(INFO, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 204 */   public void logTrace(Object message) { logInternal(TRACE, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public void logTrace(Object message, Throwable exception) { logInternal(TRACE, message, exception); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public void logWarn(Object message) { logInternal(WARN, message, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 238 */   public void logWarn(Object message, Throwable exception) { logInternal(WARN, message, exception); }
/*     */ 
/*     */   
/*     */   private static final int findCallerStackDepth(StackTraceElement[] stackTrace) {
/* 242 */     int numFrames = stackTrace.length;
/*     */     
/* 244 */     for (int i = 0; i < numFrames; i++) {
/* 245 */       String callerClassName = stackTrace[i].getClassName();
/*     */       
/* 247 */       if (!callerClassName.startsWith("com.mysql.jdbc") || callerClassName.startsWith("com.mysql.jdbc.compliance"))
/*     */       {
/* 249 */         return i;
/*     */       }
/*     */     } 
/*     */     
/* 253 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void logInternal(Level level, Object msg, Throwable exception) {
/* 262 */     if (this.jdkLogger.isLoggable(level)) {
/* 263 */       String messageAsString = null;
/* 264 */       String callerMethodName = "N/A";
/* 265 */       String callerClassName = "N/A";
/* 266 */       int lineNumber = 0;
/* 267 */       String fileName = "N/A";
/*     */       
/* 269 */       if (msg instanceof com.mysql.jdbc.profiler.ProfilerEvent) {
/* 270 */         messageAsString = LogUtils.expandProfilerEventIfNecessary(msg).toString();
/*     */       } else {
/*     */         
/* 273 */         Throwable locationException = new Throwable();
/* 274 */         StackTraceElement[] locations = locationException.getStackTrace();
/*     */ 
/*     */         
/* 277 */         int frameIdx = findCallerStackDepth(locations);
/*     */         
/* 279 */         if (frameIdx != 0) {
/* 280 */           callerClassName = locations[frameIdx].getClassName();
/* 281 */           callerMethodName = locations[frameIdx].getMethodName();
/* 282 */           lineNumber = locations[frameIdx].getLineNumber();
/* 283 */           fileName = locations[frameIdx].getFileName();
/*     */         } 
/*     */         
/* 286 */         messageAsString = String.valueOf(msg);
/*     */       } 
/*     */       
/* 289 */       if (exception == null) {
/* 290 */         this.jdkLogger.logp(level, callerClassName, callerMethodName, messageAsString);
/*     */       } else {
/*     */         
/* 293 */         this.jdkLogger.logp(level, callerClassName, callerMethodName, messageAsString, exception);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/log/Jdk14Logger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */