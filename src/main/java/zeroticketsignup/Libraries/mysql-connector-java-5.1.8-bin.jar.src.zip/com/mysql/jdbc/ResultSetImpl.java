/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandler;
/*      */ import com.mysql.jdbc.profiler.ProfilerEventHandlerFactory;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ResultSetImpl
/*      */   implements ResultSetInternalMethods
/*      */ {
/*      */   private static final Constructor JDBC_4_RS_4_ARG_CTOR;
/*      */   private static final Constructor JDBC_4_RS_6_ARG_CTOR;
/*      */   private static final Constructor JDBC_4_UPD_RS_6_ARG_CTOR;
/*      */   protected static final double MIN_DIFF_PREC;
/*      */   protected static final double MAX_DIFF_PREC;
/*      */   protected static int resultCounter;
/*      */   protected String catalog;
/*      */   protected Map columnLabelToIndex;
/*      */   protected Map columnToIndexCache;
/*      */   protected boolean[] columnUsed;
/*      */   protected ConnectionImpl connection;
/*      */   protected long connectionId;
/*      */   protected int currentRow;
/*      */   TimeZone defaultTimeZone;
/*      */   protected boolean doingUpdates;
/*      */   protected ProfilerEventHandler eventSink;
/*      */   Calendar fastDateCal;
/*      */   protected int fetchDirection;
/*      */   protected int fetchSize;
/*      */   protected Field[] fields;
/*      */   protected char firstCharOfQuery;
/*      */   protected Map fullColumnNameToIndex;
/*      */   protected Map columnNameToIndex;
/*      */   protected boolean hasBuiltIndexMapping;
/*      */   protected boolean isBinaryEncoded;
/*      */   protected boolean isClosed;
/*      */   protected ResultSetInternalMethods nextResultSet;
/*      */   protected boolean onInsertRow;
/*      */   protected StatementImpl owningStatement;
/*      */   protected Throwable pointOfOrigin;
/*      */   protected boolean profileSql;
/*      */   protected boolean reallyResult;
/*      */   protected int resultId;
/*      */   protected int resultSetConcurrency;
/*      */   protected int resultSetType;
/*      */   protected RowData rowData;
/*      */   protected String serverInfo;
/*      */   PreparedStatement statementUsedForFetchingRows;
/*      */   protected ResultSetRow thisRow;
/*      */   protected long updateCount;
/*      */   protected long updateId;
/*      */   private boolean useStrictFloatingPoint;
/*      */   protected boolean useUsageAdvisor;
/*      */   protected SQLWarning warningChain;
/*      */   protected boolean wasNullFlag;
/*      */   protected Statement wrapperStatement;
/*      */   protected boolean retainOwningStatement;
/*      */   protected Calendar gmtCalendar;
/*      */   protected boolean useFastDateParsing;
/*      */   private boolean padCharsWithSpace;
/*      */   private boolean jdbcCompliantTruncationForReads;
/*      */   private boolean useFastIntParsing;
/*      */   private boolean useColumnNamesInFindColumn;
/*      */   private ExceptionInterceptor exceptionInterceptor;
/*      */   protected static final char[] EMPTY_SPACE;
/*      */   private boolean onValidRow;
/*      */   private String invalidRowReason;
/*      */   protected boolean useLegacyDatetimeCode;
/*      */   private TimeZone serverTimeZoneTz;
/*      */   static Class array$Lcom$mysql$jdbc$Field;
/*      */   
/*      */   static  {
/*  123 */     if (Util.isJdbc4()) {
/*      */       try {
/*  125 */         JDBC_4_RS_4_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4ResultSet").getConstructor(new Class[] { long.class, long.class, ConnectionImpl.class, StatementImpl.class });
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  130 */         JDBC_4_RS_6_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4ResultSet").getConstructor(new Class[] { String.class, (array$Lcom$mysql$jdbc$Field == null) ? (array$Lcom$mysql$jdbc$Field = class$("[Lcom.mysql.jdbc.Field;")) : array$Lcom$mysql$jdbc$Field, RowData.class, ConnectionImpl.class, StatementImpl.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  136 */         JDBC_4_UPD_RS_6_ARG_CTOR = Class.forName("com.mysql.jdbc.JDBC4UpdatableResultSet").getConstructor(new Class[] { String.class, (array$Lcom$mysql$jdbc$Field == null) ? (array$Lcom$mysql$jdbc$Field = class$("[Lcom.mysql.jdbc.Field;")) : array$Lcom$mysql$jdbc$Field, RowData.class, ConnectionImpl.class, StatementImpl.class });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*  143 */       catch (SecurityException e) {
/*  144 */         throw new RuntimeException(e);
/*  145 */       } catch (NoSuchMethodException e) {
/*  146 */         throw new RuntimeException(e);
/*  147 */       } catch (ClassNotFoundException e) {
/*  148 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*  151 */       JDBC_4_RS_4_ARG_CTOR = null;
/*  152 */       JDBC_4_RS_6_ARG_CTOR = null;
/*  153 */       JDBC_4_UPD_RS_6_ARG_CTOR = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  160 */     MIN_DIFF_PREC = Float.parseFloat(Float.toString(Float.MIN_VALUE)) - Double.parseDouble(Float.toString(Float.MIN_VALUE));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  166 */     MAX_DIFF_PREC = Float.parseFloat(Float.toString(Float.MAX_VALUE)) - Double.parseDouble(Float.toString(Float.MAX_VALUE));
/*      */ 
/*      */ 
/*      */     
/*  170 */     resultCounter = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  341 */     EMPTY_SPACE = new char[255];
/*      */ 
/*      */     
/*  344 */     for (int i = 0; i < EMPTY_SPACE.length; i++)
/*  345 */       EMPTY_SPACE[i] = ' '; 
/*      */   } protected static BigInteger convertLongToUlong(long longVal) { byte[] asBytes = new byte[8]; asBytes[7] = (byte)(int)(longVal & 0xFFL); asBytes[6] = (byte)(int)(longVal >>> 8); asBytes[5] = (byte)(int)(longVal >>> 16); asBytes[4] = (byte)(int)(longVal >>> 24);
/*      */     asBytes[3] = (byte)(int)(longVal >>> 32);
/*      */     asBytes[2] = (byte)(int)(longVal >>> 40);
/*      */     asBytes[1] = (byte)(int)(longVal >>> 48);
/*      */     asBytes[0] = (byte)(int)(longVal >>> 56);
/*  351 */     return new BigInteger(1, asBytes); } protected static ResultSetImpl getInstance(long updateCount, long updateID, ConnectionImpl conn, StatementImpl creatorStmt) throws SQLException { if (!Util.isJdbc4()) {
/*  352 */       return new ResultSetImpl(updateCount, updateID, conn, creatorStmt);
/*      */     }
/*      */     
/*  355 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_4_ARG_CTOR, new Object[] { Constants.longValueOf(updateCount), Constants.longValueOf(updateID), conn, creatorStmt }, conn.getExceptionInterceptor()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ResultSetImpl getInstance(String catalog, Field[] fields, RowData tuples, ConnectionImpl conn, StatementImpl creatorStmt, boolean isUpdatable) throws SQLException {
/*  371 */     if (!Util.isJdbc4()) {
/*  372 */       if (!isUpdatable) {
/*  373 */         return new ResultSetImpl(catalog, fields, tuples, conn, creatorStmt);
/*      */       }
/*      */       
/*  376 */       return new UpdatableResultSet(catalog, fields, tuples, conn, creatorStmt);
/*      */     } 
/*      */ 
/*      */     
/*  380 */     if (!isUpdatable) {
/*  381 */       return (ResultSetImpl)Util.handleNewInstance(JDBC_4_RS_6_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  386 */     return (ResultSetImpl)Util.handleNewInstance(JDBC_4_UPD_RS_6_ARG_CTOR, new Object[] { catalog, fields, tuples, conn, creatorStmt }, conn.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetImpl(long updateCount, long updateID, ConnectionImpl conn, StatementImpl creatorStmt)
/*      */   {
/*      */     this.catalog = null;
/*      */     this.columnLabelToIndex = null;
/*      */     this.columnToIndexCache = null;
/*      */     this.columnUsed = null;
/*      */     this.connectionId = 0L;
/*      */     this.currentRow = -1;
/*      */     this.doingUpdates = false;
/*      */     this.eventSink = null;
/*      */     this.fastDateCal = null;
/*      */     this.fetchDirection = 1000;
/*      */     this.fetchSize = 0;
/*      */     this.fullColumnNameToIndex = null;
/*      */     this.columnNameToIndex = null;
/*      */     this.hasBuiltIndexMapping = false;
/*      */     this.isBinaryEncoded = false;
/*      */     this.isClosed = false;
/*      */     this.nextResultSet = null;
/*      */     this.onInsertRow = false;
/*      */     this.profileSql = false;
/*      */     this.reallyResult = false;
/*      */     this.resultSetConcurrency = 0;
/*      */     this.resultSetType = 0;
/*      */     this.serverInfo = null;
/*      */     this.thisRow = null;
/*      */     this.updateId = -1L;
/*      */     this.useStrictFloatingPoint = false;
/*      */     this.useUsageAdvisor = false;
/*      */     this.warningChain = null;
/*      */     this.wasNullFlag = false;
/*      */     this.gmtCalendar = null;
/*      */     this.useFastDateParsing = false;
/*      */     this.padCharsWithSpace = false;
/*      */     this.useFastIntParsing = true;
/*  846 */     this.onValidRow = false;
/*  847 */     this.invalidRowReason = null; this.updateCount = updateCount; this.updateId = updateID; this.reallyResult = false; this.fields = new Field[0]; this.connection = conn; this.owningStatement = creatorStmt; this.exceptionInterceptor = this.connection.getExceptionInterceptor(); this.retainOwningStatement = false; if (this.connection != null) { this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose(); this.connectionId = this.connection.getId(); this.serverTimeZoneTz = this.connection.getServerTimezoneTZ(); this.padCharsWithSpace = this.connection.getPadCharsWithSpace(); }  this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode(); } public ResultSetImpl(String catalog, Field[] fields, RowData tuples, ConnectionImpl conn, StatementImpl creatorStmt) throws SQLException { this.catalog = null; this.columnLabelToIndex = null; this.columnToIndexCache = null; this.columnUsed = null; this.connectionId = 0L; this.currentRow = -1; this.doingUpdates = false; this.eventSink = null; this.fastDateCal = null; this.fetchDirection = 1000; this.fetchSize = 0; this.fullColumnNameToIndex = null; this.columnNameToIndex = null; this.hasBuiltIndexMapping = false; this.isBinaryEncoded = false; this.isClosed = false; this.nextResultSet = null; this.onInsertRow = false; this.profileSql = false; this.reallyResult = false; this.resultSetConcurrency = 0; this.resultSetType = 0; this.serverInfo = null; this.thisRow = null; this.updateId = -1L; this.useStrictFloatingPoint = false; this.useUsageAdvisor = false; this.warningChain = null; this.wasNullFlag = false; this.gmtCalendar = null; this.useFastDateParsing = false; this.padCharsWithSpace = false; this.useFastIntParsing = true; this.onValidRow = false; this.invalidRowReason = null; this.connection = conn; this.retainOwningStatement = false; if (this.connection != null) { this.useStrictFloatingPoint = this.connection.getStrictFloatingPoint(); setDefaultTimeZone(this.connection.getDefaultTimeZone()); this.connectionId = this.connection.getId(); this.useFastDateParsing = this.connection.getUseFastDateParsing(); this.profileSql = this.connection.getProfileSql(); this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose(); this.jdbcCompliantTruncationForReads = this.connection.getJdbcCompliantTruncationForReads(); this.useFastIntParsing = this.connection.getUseFastIntParsing(); this.serverTimeZoneTz = this.connection.getServerTimezoneTZ(); this.padCharsWithSpace = this.connection.getPadCharsWithSpace(); }  this.owningStatement = creatorStmt; this.catalog = catalog; this.fields = fields; this.rowData = tuples; this.updateCount = this.rowData.size(); this.reallyResult = true; if (this.rowData.size() > 0) { if (this.updateCount == 1L && this.thisRow == null) { this.rowData.close(); this.updateCount = -1L; }  } else { this.thisRow = null; }  this.rowData.setOwner(this); if (this.fields != null)
/*      */       initializeWithMetadata();  this.useLegacyDatetimeCode = this.connection.getUseLegacyDatetimeCode(); this.useColumnNamesInFindColumn = this.connection.getUseColumnNamesInFindColumn(); setRowPositionValidity(); }
/*      */   public void initializeWithMetadata() throws SQLException { this.rowData.setMetadata(this.fields); if (this.profileSql || this.connection.getUseUsageAdvisor()) { this.columnUsed = new boolean[this.fields.length]; this.pointOfOrigin = new Throwable(); this.resultId = resultCounter++; this.useUsageAdvisor = this.connection.getUseUsageAdvisor(); this.eventSink = ProfilerEventHandlerFactory.getInstance(this.connection); }  if (this.connection.getGatherPerformanceMetrics()) { this.connection.incrementNumberOfResultSetsCreated(); Map tableNamesMap = new HashMap(); for (int i = 0; i < this.fields.length; i++) { Field f = this.fields[i]; String tableName = f.getOriginalTableName(); if (tableName == null)
/*      */           tableName = f.getTableName();  if (tableName != null) { if (this.connection.lowerCaseTableNames())
/*      */             tableName = tableName.toLowerCase();  tableNamesMap.put(tableName, null); }  }  this.connection.reportNumberOfTablesAccessed(tableNamesMap.size()); }  }
/*  852 */   private synchronized void createCalendarIfNeeded() { if (this.fastDateCal == null) { this.fastDateCal = new GregorianCalendar(Locale.US); this.fastDateCal.setTimeZone(getDefaultTimeZone()); }  } private void setRowPositionValidity() throws SQLException { if (!this.rowData.isDynamic() && this.rowData.size() == 0)
/*  853 */     { this.invalidRowReason = Messages.getString("ResultSet.Illegal_operation_on_empty_result_set");
/*      */       
/*  855 */       this.onValidRow = false; }
/*  856 */     else if (this.rowData.isBeforeFirst())
/*  857 */     { this.invalidRowReason = Messages.getString("ResultSet.Before_start_of_result_set_146");
/*      */       
/*  859 */       this.onValidRow = false; }
/*  860 */     else if (this.rowData.isAfterLast())
/*  861 */     { this.invalidRowReason = Messages.getString("ResultSet.After_end_of_result_set_148");
/*      */       
/*  863 */       this.onValidRow = false; }
/*      */     else
/*  865 */     { this.onValidRow = true;
/*  866 */       this.invalidRowReason = null; }  }
/*      */   public boolean absolute(int row) throws SQLException { boolean b; checkClosed(); if (this.rowData.size() == 0) { b = false; } else { if (row == 0) throw SQLError.createSQLException(Messages.getString("ResultSet.Cannot_absolute_position_to_row_0_110"), "S1009", getExceptionInterceptor());  if (this.onInsertRow) this.onInsertRow = false;  if (this.doingUpdates) this.doingUpdates = false;  if (this.thisRow != null) this.thisRow.closeOpenStreams();  if (row == 1) { b = first(); } else if (row == -1) { b = last(); } else if (row > this.rowData.size()) { afterLast(); b = false; } else if (row < 0) { int newRowPosition = this.rowData.size() + row + 1; if (newRowPosition <= 0) { beforeFirst(); b = false; } else { b = absolute(newRowPosition); }  } else { row--; this.rowData.setCurrentRow(row); this.thisRow = this.rowData.getAt(row); b = true; }  }  setRowPositionValidity(); return b; }
/*      */   public void afterLast() throws SQLException { checkClosed(); if (this.onInsertRow) this.onInsertRow = false;  if (this.doingUpdates) this.doingUpdates = false;  if (this.thisRow != null) this.thisRow.closeOpenStreams();  if (this.rowData.size() != 0) { this.rowData.afterLast(); this.thisRow = null; }  setRowPositionValidity(); }
/*      */   public void beforeFirst() throws SQLException { checkClosed(); if (this.onInsertRow) this.onInsertRow = false;  if (this.doingUpdates) this.doingUpdates = false;  if (this.rowData.size() == 0) return;  if (this.thisRow != null) this.thisRow.closeOpenStreams();  this.rowData.beforeFirst(); this.thisRow = null; setRowPositionValidity(); }
/*      */   public void buildIndexMapping() throws SQLException { int numFields = this.fields.length; this.columnLabelToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER); this.fullColumnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER); this.columnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER); this.columnToIndexCache = new HashMap(); for (int i = numFields - 1; i >= 0; i--) { Integer index = Constants.integerValueOf(i); String columnName = this.fields[i].getOriginalName(); String columnLabel = this.fields[i].getName(); String fullColumnName = this.fields[i].getFullName(); if (columnLabel != null) this.columnLabelToIndex.put(columnLabel, index);  if (fullColumnName != null) this.fullColumnNameToIndex.put(fullColumnName, index);  if (columnName != null) this.columnNameToIndex.put(columnName, index);  }  this.hasBuiltIndexMapping = true; }
/*      */   public void cancelRowUpdates() throws SQLException { throw new NotUpdatable(); }
/*      */   protected final void checkClosed() throws SQLException { if (this.isClosed) throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000", getExceptionInterceptor());  }
/*      */   protected final void checkColumnBounds(int columnIndex) throws SQLException { if (columnIndex < 1) throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_low", new Object[] { Constants.integerValueOf(columnIndex), Constants.integerValueOf(this.fields.length) }), "S1009", getExceptionInterceptor());  if (columnIndex > this.fields.length) throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range_high", new Object[] { Constants.integerValueOf(columnIndex), Constants.integerValueOf(this.fields.length) }), "S1009", getExceptionInterceptor());  if (this.profileSql || this.useUsageAdvisor)
/*      */       this.columnUsed[columnIndex - 1] = true;  } protected void checkRowPos() throws SQLException { checkClosed(); if (!this.onValidRow)
/*  875 */       throw SQLError.createSQLException(this.invalidRowReason, "S1000", getExceptionInterceptor());  } public void clearNextResult() { this.nextResultSet = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  886 */   public void clearWarnings() throws SQLException { this.warningChain = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  907 */   public void close() throws SQLException { realClose(true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int convertToZeroWithEmptyCheck() throws SQLException {
/*  914 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  915 */       return 0;
/*      */     }
/*      */     
/*  918 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String convertToZeroLiteralStringWithEmptyCheck() throws SQLException {
/*  925 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  926 */       return "0";
/*      */     }
/*      */     
/*  929 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetInternalMethods copy() throws SQLException {
/*  937 */     ResultSetInternalMethods rs = getInstance(this.catalog, this.fields, this.rowData, this.connection, this.owningStatement, false);
/*      */ 
/*      */     
/*  940 */     return rs;
/*      */   }
/*      */   
/*      */   public void redefineFieldsForDBMD(Field[] f) {
/*  944 */     this.fields = f;
/*      */     
/*  946 */     for (int i = 0; i < this.fields.length; i++) {
/*  947 */       this.fields[i].setUseOldNameMetadata(true);
/*  948 */       this.fields[i].setConnection(this.connection);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void populateCachedMetaData(CachedResultSetMetaData cachedMetaData) throws SQLException {
/*  954 */     cachedMetaData.fields = this.fields;
/*  955 */     cachedMetaData.columnNameToIndex = this.columnLabelToIndex;
/*  956 */     cachedMetaData.fullColumnNameToIndex = this.fullColumnNameToIndex;
/*  957 */     cachedMetaData.metadata = getMetaData();
/*      */   }
/*      */   
/*      */   public void initializeFromCachedMetaData(CachedResultSetMetaData cachedMetaData) {
/*  961 */     this.fields = cachedMetaData.fields;
/*  962 */     this.columnLabelToIndex = cachedMetaData.columnNameToIndex;
/*  963 */     this.fullColumnNameToIndex = cachedMetaData.fullColumnNameToIndex;
/*  964 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  979 */   public void deleteRow() throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String extractStringFromNativeColumn(int columnIndex, int mysqlType) throws SQLException {
/*  991 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/*  993 */     this.wasNullFlag = false;
/*      */     
/*  995 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/*  996 */       this.wasNullFlag = true;
/*      */       
/*  998 */       return null;
/*      */     } 
/*      */     
/* 1001 */     this.wasNullFlag = false;
/*      */     
/* 1003 */     String encoding = this.fields[columnIndexMinusOne].getCharacterSet();
/*      */ 
/*      */     
/* 1006 */     return this.thisRow.getString(columnIndex - 1, encoding, this.connection);
/*      */   }
/*      */ 
/*      */   
/*      */   protected synchronized Date fastDateCreate(Calendar cal, int year, int month, int day) {
/* 1011 */     if (this.useLegacyDatetimeCode) {
/* 1012 */       return TimeUtil.fastDateCreate(year, month, day, cal);
/*      */     }
/*      */     
/* 1015 */     if (cal == null) {
/* 1016 */       createCalendarIfNeeded();
/* 1017 */       cal = this.fastDateCal;
/*      */     } 
/*      */     
/* 1020 */     boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */     
/* 1022 */     return TimeUtil.fastDateCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : cal, cal, year, month, day);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized Time fastTimeCreate(Calendar cal, int hour, int minute, int second) throws SQLException {
/* 1029 */     if (!this.useLegacyDatetimeCode) {
/* 1030 */       return TimeUtil.fastTimeCreate(hour, minute, second, cal, getExceptionInterceptor());
/*      */     }
/*      */     
/* 1033 */     if (cal == null) {
/* 1034 */       createCalendarIfNeeded();
/* 1035 */       cal = this.fastDateCal;
/*      */     } 
/*      */     
/* 1038 */     return TimeUtil.fastTimeCreate(cal, hour, minute, second, getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized Timestamp fastTimestampCreate(Calendar cal, int year, int month, int day, int hour, int minute, int seconds, int secondsPart) {
/* 1044 */     if (!this.useLegacyDatetimeCode) {
/* 1045 */       return TimeUtil.fastTimestampCreate(cal.getTimeZone(), year, month, day, hour, minute, seconds, secondsPart);
/*      */     }
/*      */ 
/*      */     
/* 1049 */     if (cal == null) {
/* 1050 */       createCalendarIfNeeded();
/* 1051 */       cal = this.fastDateCal;
/*      */     } 
/*      */     
/* 1054 */     boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */     
/* 1056 */     return TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : null, cal, year, month, day, hour, minute, seconds, secondsPart);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int findColumn(String columnName) throws SQLException {
/* 1105 */     checkClosed();
/*      */     
/* 1107 */     if (!this.hasBuiltIndexMapping) {
/* 1108 */       buildIndexMapping();
/*      */     }
/*      */     
/* 1111 */     Integer index = (Integer)this.columnToIndexCache.get(columnName);
/*      */     
/* 1113 */     if (index != null) {
/* 1114 */       return index.intValue() + 1;
/*      */     }
/*      */     
/* 1117 */     index = (Integer)this.columnLabelToIndex.get(columnName);
/*      */     
/* 1119 */     if (index == null && this.useColumnNamesInFindColumn) {
/* 1120 */       index = (Integer)this.columnNameToIndex.get(columnName);
/*      */     }
/*      */     
/* 1123 */     if (index == null) {
/* 1124 */       index = (Integer)this.fullColumnNameToIndex.get(columnName);
/*      */     }
/*      */     
/* 1127 */     if (index != null) {
/* 1128 */       this.columnToIndexCache.put(columnName, index);
/*      */       
/* 1130 */       return index.intValue() + 1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1135 */     for (int i = 0; i < this.fields.length; i++) {
/* 1136 */       if (this.fields[i].getName().equalsIgnoreCase(columnName))
/* 1137 */         return i + 1; 
/* 1138 */       if (this.fields[i].getFullName().equalsIgnoreCase(columnName))
/*      */       {
/* 1140 */         return i + 1;
/*      */       }
/*      */     } 
/*      */     
/* 1144 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "S0022", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/* 1164 */     checkClosed();
/*      */     
/* 1166 */     boolean b = true;
/*      */     
/* 1168 */     if (this.rowData.isEmpty()) {
/* 1169 */       b = false;
/*      */     } else {
/*      */       
/* 1172 */       if (this.onInsertRow) {
/* 1173 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 1176 */       if (this.doingUpdates) {
/* 1177 */         this.doingUpdates = false;
/*      */       }
/*      */       
/* 1180 */       this.rowData.beforeFirst();
/* 1181 */       this.thisRow = this.rowData.next();
/*      */     } 
/*      */     
/* 1184 */     setRowPositionValidity();
/*      */     
/* 1186 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int i) throws SQLException {
/* 1203 */     checkColumnBounds(i);
/*      */     
/* 1205 */     throw SQLError.notImplemented();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1222 */   public Array getArray(String colName) throws SQLException { return getArray(findColumn(colName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int columnIndex) throws SQLException {
/* 1251 */     checkRowPos();
/*      */     
/* 1253 */     if (!this.isBinaryEncoded) {
/* 1254 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */     
/* 1257 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1272 */   public InputStream getAsciiStream(String columnName) throws SQLException { return getAsciiStream(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int columnIndex) throws SQLException {
/* 1289 */     if (!this.isBinaryEncoded) {
/* 1290 */       String stringVal = getString(columnIndex);
/*      */ 
/*      */       
/* 1293 */       if (stringVal != null) {
/* 1294 */         if (stringVal.length() == 0) {
/*      */           
/* 1296 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */ 
/*      */           
/* 1299 */           return val;
/*      */         } 
/*      */         
/*      */         try {
/* 1303 */           BigDecimal val = new BigDecimal(stringVal);
/*      */           
/* 1305 */           return val;
/* 1306 */         } catch (NumberFormatException ex) {
/* 1307 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1315 */       return null;
/*      */     } 
/*      */     
/* 1318 */     return getNativeBigDecimal(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale) throws SQLException {
/* 1339 */     if (!this.isBinaryEncoded) {
/* 1340 */       String stringVal = getString(columnIndex);
/*      */ 
/*      */       
/* 1343 */       if (stringVal != null) {
/* 1344 */         BigDecimal val; if (stringVal.length() == 0) {
/* 1345 */           val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */ 
/*      */           
/*      */           try {
/* 1349 */             return val.setScale(scale);
/* 1350 */           } catch (ArithmeticException ex) {
/*      */             try {
/* 1352 */               return val.setScale(scale, 4);
/*      */             }
/* 1354 */             catch (ArithmeticException arEx) {
/* 1355 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1365 */           val = new BigDecimal(stringVal);
/* 1366 */         } catch (NumberFormatException ex) {
/* 1367 */           if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 1368 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 1370 */             val = new BigDecimal(valueAsLong);
/*      */           } else {
/* 1372 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Constants.integerValueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/* 1381 */           return val.setScale(scale);
/* 1382 */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1384 */             return val.setScale(scale, 4);
/* 1385 */           } catch (ArithmeticException arithEx) {
/* 1386 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { Constants.integerValueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1395 */       return null;
/*      */     } 
/*      */     
/* 1398 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1414 */   public BigDecimal getBigDecimal(String columnName) throws SQLException { return getBigDecimal(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1434 */   public BigDecimal getBigDecimal(String columnName, int scale) throws SQLException { return getBigDecimal(findColumn(columnName), scale); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final BigDecimal getBigDecimalFromString(String stringVal, int columnIndex, int scale) throws SQLException {
/* 1441 */     if (stringVal != null) {
/* 1442 */       if (stringVal.length() == 0) {
/* 1443 */         BigDecimal bdVal = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */         
/*      */         try {
/* 1446 */           return bdVal.setScale(scale);
/* 1447 */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1449 */             return bdVal.setScale(scale, 4);
/* 1450 */           } catch (ArithmeticException arEx) {
/* 1451 */             throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009");
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1462 */         return (new BigDecimal(stringVal)).setScale(scale);
/* 1463 */       } catch (ArithmeticException ex) {
/*      */         try {
/* 1465 */           return (new BigDecimal(stringVal)).setScale(scale, 4);
/*      */         }
/* 1467 */         catch (ArithmeticException arEx) {
/* 1468 */           throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009");
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 1475 */       catch (NumberFormatException ex) {
/* 1476 */         if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 1477 */           long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */           
/*      */           try {
/* 1480 */             return (new BigDecimal(valueAsLong)).setScale(scale);
/* 1481 */           } catch (ArithmeticException arEx1) {
/*      */             try {
/* 1483 */               return (new BigDecimal(valueAsLong)).setScale(scale, 4);
/*      */             }
/* 1485 */             catch (ArithmeticException arEx2) {
/* 1486 */               throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009");
/*      */             } 
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1495 */         if (this.fields[columnIndex - 1].getMysqlType() == 1 && this.connection.getTinyInt1isBit() && this.fields[columnIndex - 1].getLength() == 1L)
/*      */         {
/* 1497 */           return (new BigDecimal(stringVal.equalsIgnoreCase("true") ? 1.0D : 0.0D)).setScale(scale);
/*      */         }
/*      */         
/* 1500 */         throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009");
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1508 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int columnIndex) throws SQLException {
/* 1529 */     checkRowPos();
/*      */     
/* 1531 */     if (!this.isBinaryEncoded) {
/* 1532 */       checkColumnBounds(columnIndex);
/*      */       
/* 1534 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1536 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1537 */         this.wasNullFlag = true;
/*      */         
/* 1539 */         return null;
/*      */       } 
/*      */       
/* 1542 */       this.wasNullFlag = false;
/*      */       
/* 1544 */       return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 1547 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1562 */   public InputStream getBinaryStream(String columnName) throws SQLException { return getBinaryStream(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int columnIndex) throws SQLException {
/* 1577 */     if (!this.isBinaryEncoded) {
/* 1578 */       checkRowPos();
/*      */       
/* 1580 */       checkColumnBounds(columnIndex);
/*      */       
/* 1582 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1584 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1585 */         this.wasNullFlag = true;
/*      */       } else {
/* 1587 */         this.wasNullFlag = false;
/*      */       } 
/*      */       
/* 1590 */       if (this.wasNullFlag) {
/* 1591 */         return null;
/*      */       }
/*      */       
/* 1594 */       if (!this.connection.getEmulateLocators()) {
/* 1595 */         return new Blob(this.thisRow.getColumnValue(columnIndexMinusOne), getExceptionInterceptor());
/*      */       }
/*      */       
/* 1598 */       return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 1601 */     return getNativeBlob(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1616 */   public Blob getBlob(String colName) throws SQLException { return getBlob(findColumn(colName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int columnIndex) throws SQLException {
/*      */     long boolVal, boolVal;
/* 1632 */     checkColumnBounds(columnIndex);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1639 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 1641 */     Field field = this.fields[columnIndexMinusOne];
/*      */     
/* 1643 */     if (field.getMysqlType() == 16) {
/* 1644 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1647 */     this.wasNullFlag = false;
/*      */     
/* 1649 */     int sqlType = field.getSQLType();
/*      */     
/* 1651 */     switch (sqlType) {
/*      */       case 16:
/* 1653 */         if (field.getMysqlType() == -1) {
/* 1654 */           String stringVal = getString(columnIndex);
/*      */           
/* 1656 */           return getBooleanFromString(stringVal, columnIndex);
/*      */         } 
/*      */         
/* 1659 */         boolVal = getLong(columnIndex, false);
/*      */         
/* 1661 */         return (boolVal == -1L || boolVal > 0L);
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/* 1672 */         boolVal = getLong(columnIndex, false);
/*      */         
/* 1674 */         return (boolVal == -1L || boolVal > 0L);
/*      */     } 
/* 1676 */     if (this.connection.getPedantic())
/*      */     {
/* 1678 */       switch (sqlType) {
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/*      */         case 70:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/*      */         case 2000:
/*      */         case 2002:
/*      */         case 2003:
/*      */         case 2004:
/*      */         case 2005:
/*      */         case 2006:
/* 1692 */           throw SQLError.createSQLException("Required type conversion not allowed", "22018", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/* 1697 */     if (sqlType == -2 || sqlType == -3 || sqlType == -4 || sqlType == 2004)
/*      */     {
/*      */ 
/*      */       
/* 1701 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */     
/* 1704 */     if (this.useUsageAdvisor) {
/* 1705 */       issueConversionViaParsingWarning("getBoolean()", columnIndex, this.thisRow.getColumnValue(columnIndexMinusOne), this.fields[columnIndex], new int[] { 16, 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1717 */     String stringVal = getString(columnIndex);
/*      */     
/* 1719 */     return getBooleanFromString(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean byteArrayToBoolean(int columnIndexMinusOne) throws SQLException {
/* 1724 */     Object value = this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     
/* 1726 */     if (value == null) {
/* 1727 */       this.wasNullFlag = true;
/*      */       
/* 1729 */       return false;
/*      */     } 
/*      */     
/* 1732 */     this.wasNullFlag = false;
/*      */     
/* 1734 */     if (((byte[])value).length == 0) {
/* 1735 */       return false;
/*      */     }
/*      */     
/* 1738 */     byte boolVal = ((byte[])value)[0];
/*      */     
/* 1740 */     if (boolVal == 49)
/* 1741 */       return true; 
/* 1742 */     if (boolVal == 48) {
/* 1743 */       return false;
/*      */     }
/*      */     
/* 1746 */     return (boolVal == -1 || boolVal > 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1761 */   public boolean getBoolean(String columnName) throws SQLException { return getBoolean(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean getBooleanFromString(String stringVal, int columnIndex) throws SQLException {
/* 1766 */     if (stringVal != null && stringVal.length() > 0) {
/* 1767 */       int c = Character.toLowerCase(stringVal.charAt(0));
/*      */       
/* 1769 */       return (c == 116 || c == 121 || c == 49 || stringVal.equals("-1"));
/*      */     } 
/*      */ 
/*      */     
/* 1773 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int columnIndex) throws SQLException {
/* 1788 */     if (!this.isBinaryEncoded) {
/* 1789 */       String stringVal = getString(columnIndex);
/*      */       
/* 1791 */       if (this.wasNullFlag || stringVal == null) {
/* 1792 */         return 0;
/*      */       }
/*      */       
/* 1795 */       return getByteFromString(stringVal, columnIndex);
/*      */     } 
/*      */     
/* 1798 */     return getNativeByte(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1813 */   public byte getByte(String columnName) throws SQLException { return getByte(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte getByteFromString(String stringVal, int columnIndex) throws SQLException {
/* 1819 */     if (stringVal != null && stringVal.length() == 0) {
/* 1820 */       return (byte)convertToZeroWithEmptyCheck();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1831 */     if (stringVal == null) {
/* 1832 */       return 0;
/*      */     }
/*      */     
/* 1835 */     stringVal = stringVal.trim();
/*      */     
/*      */     try {
/* 1838 */       int decimalIndex = stringVal.indexOf(".");
/*      */ 
/*      */       
/* 1841 */       if (decimalIndex != -1) {
/* 1842 */         double valueAsDouble = Double.parseDouble(stringVal);
/*      */         
/* 1844 */         if (this.jdbcCompliantTruncationForReads && (
/* 1845 */           valueAsDouble < -128.0D || valueAsDouble > 127.0D))
/*      */         {
/* 1847 */           throwRangeException(stringVal, columnIndex, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1852 */         return (byte)(int)valueAsDouble;
/*      */       } 
/*      */       
/* 1855 */       long valueAsLong = Long.parseLong(stringVal);
/*      */       
/* 1857 */       if (this.jdbcCompliantTruncationForReads && (
/* 1858 */         valueAsLong < -128L || valueAsLong > 127L))
/*      */       {
/* 1860 */         throwRangeException(String.valueOf(valueAsLong), columnIndex, -6);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1865 */       return (byte)(int)valueAsLong;
/* 1866 */     } catch (NumberFormatException NFE) {
/* 1867 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value____173") + stringVal + Messages.getString("ResultSet.___is_out_of_range_[-127,127]_174"), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1892 */   public byte[] getBytes(int columnIndex) throws SQLException { return getBytes(columnIndex, false); }
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getBytes(int columnIndex, boolean noConversion) throws SQLException {
/* 1897 */     if (!this.isBinaryEncoded) {
/* 1898 */       checkRowPos();
/*      */       
/* 1900 */       checkColumnBounds(columnIndex);
/*      */       
/* 1902 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1904 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1905 */         this.wasNullFlag = true;
/*      */       } else {
/* 1907 */         this.wasNullFlag = false;
/*      */       } 
/*      */       
/* 1910 */       if (this.wasNullFlag) {
/* 1911 */         return null;
/*      */       }
/*      */       
/* 1914 */       return this.thisRow.getColumnValue(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 1917 */     return getNativeBytes(columnIndex, noConversion);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1932 */   public byte[] getBytes(String columnName) throws SQLException { return getBytes(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final byte[] getBytesFromString(String stringVal, int columnIndex) throws SQLException {
/* 1937 */     if (stringVal != null) {
/* 1938 */       return StringUtils.getBytes(stringVal, this.connection.getEncoding(), this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection, getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1945 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Calendar getCalendarInstanceForSessionOrNew() {
/* 1953 */     if (this.connection != null) {
/* 1954 */       return this.connection.getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */     
/* 1957 */     return new GregorianCalendar();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int columnIndex) throws SQLException {
/* 1978 */     if (!this.isBinaryEncoded) {
/* 1979 */       checkColumnBounds(columnIndex);
/*      */       
/* 1981 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 1983 */       if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 1984 */         this.wasNullFlag = true;
/*      */         
/* 1986 */         return null;
/*      */       } 
/*      */       
/* 1989 */       this.wasNullFlag = false;
/*      */       
/* 1991 */       return this.thisRow.getReader(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 1994 */     return getNativeCharacterStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2014 */   public Reader getCharacterStream(String columnName) throws SQLException { return getCharacterStream(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final Reader getCharacterStreamFromString(String stringVal, int columnIndex) throws SQLException {
/* 2019 */     if (stringVal != null) {
/* 2020 */       return new StringReader(stringVal);
/*      */     }
/*      */     
/* 2023 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int i) throws SQLException {
/* 2038 */     if (!this.isBinaryEncoded) {
/* 2039 */       String asString = getStringForClob(i);
/*      */       
/* 2041 */       if (asString == null) {
/* 2042 */         return null;
/*      */       }
/*      */       
/* 2045 */       return new Clob(asString, getExceptionInterceptor());
/*      */     } 
/*      */     
/* 2048 */     return getNativeClob(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2063 */   public Clob getClob(String colName) throws SQLException { return getClob(findColumn(colName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2068 */   private final Clob getClobFromString(String stringVal, int columnIndex) throws SQLException { return new Clob(stringVal, getExceptionInterceptor()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2081 */   public int getConcurrency() throws SQLException { return 1007; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2110 */   public String getCursorName() throws SQLException { throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00", getExceptionInterceptor()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2127 */   public Date getDate(int columnIndex) throws SQLException { return getDate(columnIndex, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int columnIndex, Calendar cal) throws SQLException {
/* 2148 */     if (this.isBinaryEncoded) {
/* 2149 */       return getNativeDate(columnIndex, (cal != null) ? cal.getTimeZone() : getDefaultTimeZone());
/*      */     }
/*      */ 
/*      */     
/* 2153 */     if (!this.useFastDateParsing) {
/* 2154 */       String stringVal = getStringInternal(columnIndex, false);
/*      */       
/* 2156 */       if (stringVal == null) {
/* 2157 */         return null;
/*      */       }
/*      */       
/* 2160 */       return getDateFromString(stringVal, columnIndex, cal);
/*      */     } 
/*      */     
/* 2163 */     checkColumnBounds(columnIndex);
/*      */     
/* 2165 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 2167 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2168 */       this.wasNullFlag = true;
/*      */       
/* 2170 */       return null;
/*      */     } 
/*      */     
/* 2173 */     this.wasNullFlag = false;
/*      */     
/* 2175 */     return this.thisRow.getDateFast(columnIndexMinusOne, this.connection, this, cal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2191 */   public Date getDate(String columnName) throws SQLException { return getDate(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2211 */   public Date getDate(String columnName, Calendar cal) throws SQLException { return getDate(findColumn(columnName), cal); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final Date getDateFromString(String stringVal, int columnIndex, Calendar targetCalendar) throws SQLException {
/* 2216 */     int year = 0;
/* 2217 */     int month = 0;
/* 2218 */     int day = 0;
/*      */     
/*      */     try {
/* 2221 */       this.wasNullFlag = false;
/*      */       
/* 2223 */       if (stringVal == null) {
/* 2224 */         this.wasNullFlag = true;
/*      */         
/* 2226 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2237 */       stringVal = stringVal.trim();
/*      */       
/* 2239 */       if (stringVal.equals("0") || stringVal.equals("0000-00-00") || stringVal.equals("0000-00-00 00:00:00") || stringVal.equals("00000000000000") || stringVal.equals("0")) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2244 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/*      */           
/* 2246 */           this.wasNullFlag = true;
/*      */           
/* 2248 */           return null;
/* 2249 */         }  if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 2251 */           throw SQLError.createSQLException("Value '" + stringVal + "' can not be represented as java.sql.Date", "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2258 */         return fastDateCreate(targetCalendar, 1, 1, 1);
/*      */       } 
/* 2260 */       if (this.fields[columnIndex - 1].getMysqlType() == 7) {
/*      */         
/* 2262 */         switch (stringVal.length()) {
/*      */           case 19:
/*      */           case 21:
/* 2265 */             year = Integer.parseInt(stringVal.substring(0, 4));
/* 2266 */             month = Integer.parseInt(stringVal.substring(5, 7));
/* 2267 */             day = Integer.parseInt(stringVal.substring(8, 10));
/*      */             
/* 2269 */             return fastDateCreate(targetCalendar, year, month, day);
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 14:
/* 2274 */             year = Integer.parseInt(stringVal.substring(0, 4));
/* 2275 */             month = Integer.parseInt(stringVal.substring(4, 6));
/* 2276 */             day = Integer.parseInt(stringVal.substring(6, 8));
/*      */             
/* 2278 */             return fastDateCreate(targetCalendar, year, month, day);
/*      */ 
/*      */           
/*      */           case 6:
/*      */           case 10:
/*      */           case 12:
/* 2284 */             year = Integer.parseInt(stringVal.substring(0, 2));
/*      */             
/* 2286 */             if (year <= 69) {
/* 2287 */               year += 100;
/*      */             }
/*      */             
/* 2290 */             month = Integer.parseInt(stringVal.substring(2, 4));
/* 2291 */             day = Integer.parseInt(stringVal.substring(4, 6));
/*      */             
/* 2293 */             return fastDateCreate(targetCalendar, year + 1900, month, day);
/*      */ 
/*      */           
/*      */           case 4:
/* 2297 */             year = Integer.parseInt(stringVal.substring(0, 4));
/*      */             
/* 2299 */             if (year <= 69) {
/* 2300 */               year += 100;
/*      */             }
/*      */             
/* 2303 */             month = Integer.parseInt(stringVal.substring(2, 4));
/*      */             
/* 2305 */             return fastDateCreate(targetCalendar, year + 1900, month, 1);
/*      */ 
/*      */           
/*      */           case 2:
/* 2309 */             year = Integer.parseInt(stringVal.substring(0, 2));
/*      */             
/* 2311 */             if (year <= 69) {
/* 2312 */               year += 100;
/*      */             }
/*      */             
/* 2315 */             return fastDateCreate(targetCalendar, year + 1900, 1, 1);
/*      */         } 
/*      */ 
/*      */         
/* 2319 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2324 */       if (this.fields[columnIndex - 1].getMysqlType() == 13) {
/*      */         
/* 2326 */         if (stringVal.length() == 2 || stringVal.length() == 1) {
/* 2327 */           year = Integer.parseInt(stringVal);
/*      */           
/* 2329 */           if (year <= 69) {
/* 2330 */             year += 100;
/*      */           }
/*      */           
/* 2333 */           year += 1900;
/*      */         } else {
/* 2335 */           year = Integer.parseInt(stringVal.substring(0, 4));
/*      */         } 
/*      */         
/* 2338 */         return fastDateCreate(targetCalendar, year, 1, 1);
/* 2339 */       }  if (this.fields[columnIndex - 1].getMysqlType() == 11) {
/* 2340 */         return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */       }
/* 2342 */       if (stringVal.length() < 10) {
/* 2343 */         if (stringVal.length() == 8) {
/* 2344 */           return fastDateCreate(targetCalendar, 1970, 1, 1);
/*      */         }
/*      */         
/* 2347 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2353 */       if (stringVal.length() != 18) {
/* 2354 */         year = Integer.parseInt(stringVal.substring(0, 4));
/* 2355 */         month = Integer.parseInt(stringVal.substring(5, 7));
/* 2356 */         day = Integer.parseInt(stringVal.substring(8, 10));
/*      */       } else {
/*      */         
/* 2359 */         StringTokenizer st = new StringTokenizer(stringVal, "- ");
/*      */         
/* 2361 */         year = Integer.parseInt(st.nextToken());
/* 2362 */         month = Integer.parseInt(st.nextToken());
/* 2363 */         day = Integer.parseInt(st.nextToken());
/*      */       } 
/*      */ 
/*      */       
/* 2367 */       return fastDateCreate(targetCalendar, year, month, day);
/* 2368 */     } catch (SQLException sqlEx) {
/* 2369 */       throw sqlEx;
/* 2370 */     } catch (Exception e) {
/* 2371 */       SQLException sqlEx = SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Date", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2376 */       sqlEx.initCause(e);
/*      */       
/* 2378 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */   
/*      */   private TimeZone getDefaultTimeZone() {
/* 2383 */     if (!this.useLegacyDatetimeCode && this.connection != null) {
/* 2384 */       return this.serverTimeZoneTz;
/*      */     }
/*      */     
/* 2387 */     return this.connection.getDefaultTimeZone();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int columnIndex) throws SQLException {
/* 2402 */     if (!this.isBinaryEncoded) {
/* 2403 */       return getDoubleInternal(columnIndex);
/*      */     }
/*      */     
/* 2406 */     return getNativeDouble(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2421 */   public double getDouble(String columnName) throws SQLException { return getDouble(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2426 */   private final double getDoubleFromString(String stringVal, int columnIndex) throws SQLException { return getDoubleInternal(stringVal, columnIndex); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2442 */   protected double getDoubleInternal(int colIndex) throws SQLException { return getDoubleInternal(getString(colIndex), colIndex); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double getDoubleInternal(String stringVal, int colIndex) throws SQLException {
/*      */     try {
/* 2462 */       if (stringVal == null) {
/* 2463 */         return 0.0D;
/*      */       }
/*      */       
/* 2466 */       if (stringVal.length() == 0) {
/* 2467 */         return convertToZeroWithEmptyCheck();
/*      */       }
/*      */       
/* 2470 */       double d = Double.parseDouble(stringVal);
/*      */       
/* 2472 */       if (this.useStrictFloatingPoint)
/*      */       {
/* 2474 */         if (d == 2.147483648E9D) {
/*      */           
/* 2476 */           d = 2.147483647E9D;
/* 2477 */         } else if (d == 1.0000000036275E-15D) {
/*      */           
/* 2479 */           d = 1.0E-15D;
/* 2480 */         } else if (d == 9.999999869911E14D) {
/* 2481 */           d = 9.99999999999999E14D;
/* 2482 */         } else if (d == 1.4012984643248E-45D) {
/* 2483 */           d = 1.4E-45D;
/* 2484 */         } else if (d == 1.4013E-45D) {
/* 2485 */           d = 1.4E-45D;
/* 2486 */         } else if (d == 3.4028234663853E37D) {
/* 2487 */           d = 3.4028235E37D;
/* 2488 */         } else if (d == -2.14748E9D) {
/* 2489 */           d = -2.147483648E9D;
/* 2490 */         } else if (d == 3.40282E37D) {
/* 2491 */           d = 3.4028235E37D;
/*      */         } 
/*      */       }
/*      */       
/* 2495 */       return d;
/* 2496 */     } catch (NumberFormatException e) {
/* 2497 */       if (this.fields[colIndex - 1].getMysqlType() == 16) {
/* 2498 */         long valueAsLong = getNumericRepresentationOfSQLBitType(colIndex);
/*      */         
/* 2500 */         return valueAsLong;
/*      */       } 
/*      */       
/* 2503 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_number", new Object[] { stringVal, Constants.integerValueOf(colIndex) }), "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2519 */   public int getFetchDirection() throws SQLException { return this.fetchDirection; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2531 */   public int getFetchSize() throws SQLException { return this.fetchSize; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2541 */   public char getFirstCharOfQuery() { return this.firstCharOfQuery; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int columnIndex) throws SQLException {
/* 2556 */     if (!this.isBinaryEncoded) {
/* 2557 */       String val = null;
/*      */       
/* 2559 */       val = getString(columnIndex);
/*      */       
/* 2561 */       return getFloatFromString(val, columnIndex);
/*      */     } 
/*      */     
/* 2564 */     return getNativeFloat(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2579 */   public float getFloat(String columnName) throws SQLException { return getFloat(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final float getFloatFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 2585 */       if (val != null) {
/* 2586 */         if (val.length() == 0) {
/* 2587 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2590 */         float f = Float.parseFloat(val);
/*      */         
/* 2592 */         if (this.jdbcCompliantTruncationForReads && (
/* 2593 */           f == Float.MIN_VALUE || f == Float.MAX_VALUE)) {
/* 2594 */           double valAsDouble = Double.parseDouble(val);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2600 */           if (valAsDouble < 1.401298464324817E-45D - MIN_DIFF_PREC || valAsDouble > 3.4028234663852886E38D - MAX_DIFF_PREC)
/*      */           {
/* 2602 */             throwRangeException(String.valueOf(valAsDouble), columnIndex, 6);
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2608 */         return f;
/*      */       } 
/*      */       
/* 2611 */       return 0.0F;
/* 2612 */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2614 */         Double valueAsDouble = new Double(val);
/* 2615 */         float valueAsFloat = valueAsDouble.floatValue();
/*      */         
/* 2617 */         if (this.jdbcCompliantTruncationForReads)
/*      */         {
/* 2619 */           if ((this.jdbcCompliantTruncationForReads && valueAsFloat == Float.NEGATIVE_INFINITY) || valueAsFloat == Float.POSITIVE_INFINITY)
/*      */           {
/*      */             
/* 2622 */             throwRangeException(valueAsDouble.toString(), columnIndex, 6);
/*      */           }
/*      */         }
/*      */ 
/*      */         
/* 2627 */         return valueAsFloat;
/* 2628 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 2632 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getFloat()_-____200") + val + Messages.getString("ResultSet.___in_column__201") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int columnIndex) throws SQLException {
/* 2653 */     checkRowPos();
/*      */     
/* 2655 */     if (!this.isBinaryEncoded) {
/* 2656 */       int columnIndexMinusOne = columnIndex - 1;
/* 2657 */       if (this.useFastIntParsing) {
/* 2658 */         checkColumnBounds(columnIndex);
/*      */         
/* 2660 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2661 */           this.wasNullFlag = true;
/*      */         } else {
/* 2663 */           this.wasNullFlag = false;
/*      */         } 
/*      */         
/* 2666 */         if (this.wasNullFlag) {
/* 2667 */           return 0;
/*      */         }
/*      */         
/* 2670 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2671 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2674 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */ 
/*      */         
/* 2677 */         if (!needsFullParse) {
/*      */           try {
/* 2679 */             return getIntWithOverflowCheck(columnIndexMinusOne);
/* 2680 */           } catch (NumberFormatException nfe) {
/*      */             
/*      */             try {
/* 2683 */               return parseIntAsDouble(columnIndex, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection));
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 2688 */             catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */               
/* 2692 */               if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2693 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */                 
/* 2695 */                 if (this.connection.getJdbcCompliantTruncationForReads() && (valueAsLong < -2147483648L || valueAsLong > 2147483647L))
/*      */                 {
/*      */                   
/* 2698 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */                 }
/*      */ 
/*      */ 
/*      */                 
/* 2703 */                 return (int)valueAsLong;
/*      */               } 
/*      */               
/* 2706 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2722 */       String val = null;
/*      */       
/*      */       try {
/* 2725 */         val = getString(columnIndex);
/*      */         
/* 2727 */         if (val != null) {
/* 2728 */           if (val.length() == 0) {
/* 2729 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 2732 */           if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1) {
/*      */             
/* 2734 */             int intVal = Integer.parseInt(val);
/*      */             
/* 2736 */             checkForIntegerTruncation(columnIndexMinusOne, null, intVal);
/*      */             
/* 2738 */             return intVal;
/*      */           } 
/*      */ 
/*      */           
/* 2742 */           int intVal = parseIntAsDouble(columnIndex, val);
/*      */           
/* 2744 */           checkForIntegerTruncation(columnIndex, null, intVal);
/*      */           
/* 2746 */           return intVal;
/*      */         } 
/*      */         
/* 2749 */         return 0;
/* 2750 */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2752 */           return parseIntAsDouble(columnIndex, val);
/* 2753 */         } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */           
/* 2757 */           if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2758 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 2760 */             if (this.jdbcCompliantTruncationForReads && (valueAsLong < -2147483648L || valueAsLong > 2147483647L))
/*      */             {
/* 2762 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */ 
/*      */             
/* 2766 */             return (int)valueAsLong;
/*      */           } 
/*      */           
/* 2769 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + val + "'", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2779 */     return getNativeInt(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2794 */   public int getInt(String columnName) throws SQLException { return getInt(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final int getIntFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 2800 */       if (val != null) {
/*      */         
/* 2802 */         if (val.length() == 0) {
/* 2803 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2806 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2816 */           val = val.trim();
/*      */           
/* 2818 */           int valueAsInt = Integer.parseInt(val);
/*      */           
/* 2820 */           if (this.jdbcCompliantTruncationForReads && (
/* 2821 */             valueAsInt == Integer.MIN_VALUE || valueAsInt == Integer.MAX_VALUE)) {
/*      */             
/* 2823 */             long valueAsLong = Long.parseLong(val);
/*      */             
/* 2825 */             if (valueAsLong < -2147483648L || valueAsLong > 2147483647L)
/*      */             {
/* 2827 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2834 */           return valueAsInt;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 2839 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2841 */         if (this.jdbcCompliantTruncationForReads && (
/* 2842 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D))
/*      */         {
/* 2844 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2849 */         return (int)valueAsDouble;
/*      */       } 
/*      */       
/* 2852 */       return 0;
/* 2853 */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2855 */         double valueAsDouble = Double.parseDouble(val);
/*      */         
/* 2857 */         if (this.jdbcCompliantTruncationForReads && (
/* 2858 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D))
/*      */         {
/* 2860 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2865 */         return (int)valueAsDouble;
/* 2866 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 2870 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____206") + val + Messages.getString("ResultSet.___in_column__207") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2890 */   public long getLong(int columnIndex) throws SQLException { return getLong(columnIndex, true); }
/*      */ 
/*      */   
/*      */   private long getLong(int columnIndex, boolean overflowCheck) throws SQLException {
/* 2894 */     if (!this.isBinaryEncoded) {
/* 2895 */       checkRowPos();
/*      */       
/* 2897 */       int columnIndexMinusOne = columnIndex - 1;
/*      */       
/* 2899 */       if (this.useFastIntParsing) {
/*      */         
/* 2901 */         checkColumnBounds(columnIndex);
/*      */         
/* 2903 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 2904 */           this.wasNullFlag = true;
/*      */         } else {
/* 2906 */           this.wasNullFlag = false;
/*      */         } 
/*      */         
/* 2909 */         if (this.wasNullFlag) {
/* 2910 */           return 0L;
/*      */         }
/*      */         
/* 2913 */         if (this.thisRow.length(columnIndexMinusOne) == 0L) {
/* 2914 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 2917 */         boolean needsFullParse = this.thisRow.isFloatingPointNumber(columnIndexMinusOne);
/*      */         
/* 2919 */         if (!needsFullParse) {
/*      */           try {
/* 2921 */             return getLongWithOverflowCheck(columnIndexMinusOne, overflowCheck);
/* 2922 */           } catch (NumberFormatException nfe) {
/*      */             
/*      */             try {
/* 2925 */               return parseLongAsDouble(columnIndexMinusOne, this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection));
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 2930 */             catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */               
/* 2934 */               if (this.fields[columnIndexMinusOne].getMysqlType() == 16) {
/* 2935 */                 return getNumericRepresentationOfSQLBitType(columnIndex);
/*      */               }
/*      */               
/* 2938 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + this.thisRow.getString(columnIndexMinusOne, this.fields[columnIndexMinusOne].getCharacterSet(), this.connection) + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2952 */       String val = null;
/*      */       
/*      */       try {
/* 2955 */         val = getString(columnIndex);
/*      */         
/* 2957 */         if (val != null) {
/* 2958 */           if (val.length() == 0) {
/* 2959 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 2962 */           if (val.indexOf("e") == -1 && val.indexOf("E") == -1) {
/* 2963 */             return parseLongWithOverflowCheck(columnIndexMinusOne, null, val, overflowCheck);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 2968 */           return parseLongAsDouble(columnIndexMinusOne, val);
/*      */         } 
/*      */         
/* 2971 */         return 0L;
/* 2972 */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2974 */           return parseLongAsDouble(columnIndexMinusOne, val);
/* 2975 */         } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */           
/* 2979 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + val + "'", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2987 */     return getNativeLong(columnIndex, overflowCheck, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3002 */   public long getLong(String columnName) throws SQLException { return getLong(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final long getLongFromString(String val, int columnIndexZeroBased) throws SQLException {
/*      */     try {
/* 3008 */       if (val != null) {
/*      */         
/* 3010 */         if (val.length() == 0) {
/* 3011 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 3014 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1) {
/* 3015 */           return parseLongWithOverflowCheck(columnIndexZeroBased, null, val, true);
/*      */         }
/*      */ 
/*      */         
/* 3019 */         return parseLongAsDouble(columnIndexZeroBased, val);
/*      */       } 
/*      */       
/* 3022 */       return 0L;
/* 3023 */     } catch (NumberFormatException nfe) {
/*      */       
/*      */       try {
/* 3026 */         return parseLongAsDouble(columnIndexZeroBased, val);
/* 3027 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 3031 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____211") + val + Messages.getString("ResultSet.___in_column__212") + (columnIndexZeroBased + 1), "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 3050 */     checkClosed();
/*      */     
/* 3052 */     return new ResultSetMetaData(this.fields, this.connection.getUseOldAliasMetadataBehavior(), getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3070 */   protected Array getNativeArray(int i) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getNativeAsciiStream(int columnIndex) throws SQLException {
/* 3100 */     checkRowPos();
/*      */     
/* 3102 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex) throws SQLException {
/* 3121 */     checkColumnBounds(columnIndex);
/*      */     
/* 3123 */     int scale = this.fields[columnIndex - 1].getDecimals();
/*      */     
/* 3125 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex, int scale) throws SQLException {
/* 3144 */     checkColumnBounds(columnIndex);
/*      */     
/* 3146 */     String stringVal = null;
/*      */     
/* 3148 */     Field f = this.fields[columnIndex - 1];
/*      */     
/* 3150 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3152 */     if (value == null) {
/* 3153 */       this.wasNullFlag = true;
/*      */       
/* 3155 */       return null;
/*      */     } 
/*      */     
/* 3158 */     this.wasNullFlag = false;
/*      */     
/* 3160 */     switch (f.getSQLType())
/*      */     { case 2:
/*      */       case 3:
/* 3163 */         stringVal = StringUtils.toAsciiString((byte[])value);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3170 */         return getBigDecimalFromString(stringVal, columnIndex, scale); }  stringVal = getNativeString(columnIndex); return getBigDecimalFromString(stringVal, columnIndex, scale);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getNativeBinaryStream(int columnIndex) throws SQLException {
/* 3192 */     checkRowPos();
/*      */     
/* 3194 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3196 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 3197 */       this.wasNullFlag = true;
/*      */       
/* 3199 */       return null;
/*      */     } 
/*      */     
/* 3202 */     this.wasNullFlag = false;
/*      */     
/* 3204 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */       case -7:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case 2004:
/* 3210 */         return this.thisRow.getBinaryInputStream(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 3213 */     byte[] b = getNativeBytes(columnIndex, false);
/*      */     
/* 3215 */     if (b != null) {
/* 3216 */       return new ByteArrayInputStream(b);
/*      */     }
/*      */     
/* 3219 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Blob getNativeBlob(int columnIndex) throws SQLException {
/* 3234 */     checkRowPos();
/*      */     
/* 3236 */     checkColumnBounds(columnIndex);
/*      */     
/* 3238 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3240 */     if (value == null) {
/* 3241 */       this.wasNullFlag = true;
/*      */     } else {
/* 3243 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 3246 */     if (this.wasNullFlag) {
/* 3247 */       return null;
/*      */     }
/*      */     
/* 3250 */     int mysqlType = this.fields[columnIndex - 1].getMysqlType();
/*      */     
/* 3252 */     byte[] dataAsBytes = null;
/*      */     
/* 3254 */     switch (mysqlType) {
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/* 3259 */         dataAsBytes = (byte[])value;
/*      */         break;
/*      */       
/*      */       default:
/* 3263 */         dataAsBytes = getNativeBytes(columnIndex, false);
/*      */         break;
/*      */     } 
/* 3266 */     if (!this.connection.getEmulateLocators()) {
/* 3267 */       return new Blob(dataAsBytes, getExceptionInterceptor());
/*      */     }
/*      */     
/* 3270 */     return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
/*      */   }
/*      */   
/*      */   public static boolean arraysEqual(byte[] left, byte[] right) {
/* 3274 */     if (left == null) {
/* 3275 */       return (right == null);
/*      */     }
/* 3277 */     if (right == null) {
/* 3278 */       return false;
/*      */     }
/* 3280 */     if (left.length != right.length) {
/* 3281 */       return false;
/*      */     }
/* 3283 */     for (int i = 0; i < left.length; i++) {
/* 3284 */       if (left[i] != right[i]) {
/* 3285 */         return false;
/*      */       }
/*      */     } 
/* 3288 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3303 */   protected byte getNativeByte(int columnIndex) throws SQLException { return getNativeByte(columnIndex, true); } protected byte getNativeByte(int columnIndex, boolean overflowCheck) throws SQLException { double valueAsDouble; float valueAsFloat; int valueAsInt;
/*      */     short valueAsShort, valueAsShort;
/*      */     byte valueAsByte;
/*      */     long valueAsLong, valueAsLong;
/* 3307 */     checkRowPos();
/*      */     
/* 3309 */     checkColumnBounds(columnIndex);
/*      */     
/* 3311 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3313 */     if (value == null) {
/* 3314 */       this.wasNullFlag = true;
/*      */       
/* 3316 */       return 0;
/*      */     } 
/*      */     
/* 3319 */     if (value == null) {
/* 3320 */       this.wasNullFlag = true;
/*      */     } else {
/* 3322 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 3325 */     if (this.wasNullFlag) {
/* 3326 */       return 0;
/*      */     }
/*      */     
/* 3329 */     columnIndex--;
/*      */     
/* 3331 */     Field field = this.fields[columnIndex];
/*      */     
/* 3333 */     switch (field.getMysqlType()) {
/*      */       case 16:
/* 3335 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 3337 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (valueAsLong < -128L || valueAsLong > 127L))
/*      */         {
/*      */           
/* 3340 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */         
/* 3344 */         return (byte)(int)valueAsLong;
/*      */       case 1:
/* 3346 */         valueAsByte = ((byte[])value)[0];
/*      */         
/* 3348 */         if (!field.isUnsigned()) {
/* 3349 */           return valueAsByte;
/*      */         }
/*      */         
/* 3352 */         valueAsShort = (valueAsByte >= 0) ? (short)valueAsByte : (short)(valueAsByte + 256);
/*      */ 
/*      */         
/* 3355 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && 
/* 3356 */           valueAsShort > 127) {
/* 3357 */           throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3362 */         return (byte)valueAsShort;
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 3366 */         valueAsShort = getNativeShort(columnIndex + 1);
/*      */         
/* 3368 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3369 */           valueAsShort < -128 || valueAsShort > 127))
/*      */         {
/* 3371 */           throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3376 */         return (byte)valueAsShort;
/*      */       case 3:
/*      */       case 9:
/* 3379 */         valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */         
/* 3381 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3382 */           valueAsInt < -128 || valueAsInt > 127)) {
/* 3383 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3388 */         return (byte)valueAsInt;
/*      */       
/*      */       case 4:
/* 3391 */         valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */         
/* 3393 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3394 */           valueAsFloat < -128.0F || valueAsFloat > 127.0F))
/*      */         {
/*      */           
/* 3397 */           throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3402 */         return (byte)(int)valueAsFloat;
/*      */       
/*      */       case 5:
/* 3405 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 3407 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3408 */           valueAsDouble < -128.0D || valueAsDouble > 127.0D))
/*      */         {
/* 3410 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3415 */         return (byte)(int)valueAsDouble;
/*      */       
/*      */       case 8:
/* 3418 */         valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */         
/* 3420 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 3421 */           valueAsLong < -128L || valueAsLong > 127L))
/*      */         {
/* 3423 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 3428 */         return (byte)(int)valueAsLong;
/*      */     } 
/*      */     
/* 3431 */     if (this.useUsageAdvisor) {
/* 3432 */       issueConversionViaParsingWarning("getByte()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3442 */     return getByteFromString(getNativeString(columnIndex + 1), columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected byte[] getNativeBytes(int columnIndex, boolean noConversion) throws SQLException {
/* 3464 */     checkRowPos();
/*      */     
/* 3466 */     checkColumnBounds(columnIndex);
/*      */     
/* 3468 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 3470 */     if (value == null) {
/* 3471 */       this.wasNullFlag = true;
/*      */     } else {
/* 3473 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 3476 */     if (this.wasNullFlag) {
/* 3477 */       return null;
/*      */     }
/*      */     
/* 3480 */     Field field = this.fields[columnIndex - 1];
/*      */     
/* 3482 */     int mysqlType = field.getMysqlType();
/*      */ 
/*      */ 
/*      */     
/* 3486 */     if (noConversion) {
/* 3487 */       mysqlType = 252;
/*      */     }
/*      */     
/* 3490 */     switch (mysqlType) {
/*      */       case 16:
/*      */       case 249:
/*      */       case 250:
/*      */       case 251:
/*      */       case 252:
/* 3496 */         return (byte[])value;
/*      */       
/*      */       case 15:
/*      */       case 253:
/*      */       case 254:
/* 3501 */         if (value instanceof byte[]) {
/* 3502 */           return (byte[])value;
/*      */         }
/*      */         break;
/*      */     } 
/* 3506 */     int sqlType = field.getSQLType();
/*      */     
/* 3508 */     if (sqlType == -3 || sqlType == -2) {
/* 3509 */       return (byte[])value;
/*      */     }
/*      */     
/* 3512 */     return getBytesFromString(getNativeString(columnIndex), columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Reader getNativeCharacterStream(int columnIndex) throws SQLException {
/* 3533 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3535 */     switch (this.fields[columnIndexMinusOne].getSQLType()) {
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 2005:
/* 3540 */         if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 3541 */           this.wasNullFlag = true;
/*      */           
/* 3543 */           return null;
/*      */         } 
/*      */         
/* 3546 */         this.wasNullFlag = false;
/*      */         
/* 3548 */         return this.thisRow.getReader(columnIndexMinusOne);
/*      */     } 
/*      */     
/* 3551 */     String asString = null;
/*      */     
/* 3553 */     asString = getStringForClob(columnIndex);
/*      */     
/* 3555 */     if (asString == null) {
/* 3556 */       return null;
/*      */     }
/*      */     
/* 3559 */     return getCharacterStreamFromString(asString, columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Clob getNativeClob(int columnIndex) throws SQLException
/*      */   {
/* 3574 */     String stringVal = getStringForClob(columnIndex);
/*      */     
/* 3576 */     if (stringVal == null) {
/* 3577 */       return null;
/*      */     }
/*      */     
/* 3580 */     return getClobFromString(stringVal, columnIndex); } private String getNativeConvertToString(int columnIndex, Field field) throws SQLException { String result; Timestamp tstamp; Object obj; Time tm; byte[] data; Date dt; String stringVal;
/*      */     double doubleVal;
/*      */     float floatVal;
/*      */     long longVal, longVal;
/*      */     int intVal, intVal;
/*      */     short unsignedTinyVal;
/*      */     byte tinyintVal;
/*      */     boolean booleanVal;
/* 3588 */     int sqlType = field.getSQLType();
/* 3589 */     int mysqlType = field.getMysqlType();
/*      */     
/* 3591 */     switch (sqlType) {
/*      */       case -7:
/* 3593 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */       case 16:
/* 3595 */         booleanVal = getBoolean(columnIndex);
/*      */         
/* 3597 */         if (this.wasNullFlag) {
/* 3598 */           return null;
/*      */         }
/*      */         
/* 3601 */         return String.valueOf(booleanVal);
/*      */       
/*      */       case -6:
/* 3604 */         tinyintVal = getNativeByte(columnIndex, false);
/*      */         
/* 3606 */         if (this.wasNullFlag) {
/* 3607 */           return null;
/*      */         }
/*      */         
/* 3610 */         if (!field.isUnsigned() || tinyintVal >= 0) {
/* 3611 */           return String.valueOf(tinyintVal);
/*      */         }
/*      */         
/* 3614 */         unsignedTinyVal = (short)(tinyintVal & 0xFF);
/*      */         
/* 3616 */         return String.valueOf(unsignedTinyVal);
/*      */ 
/*      */       
/*      */       case 5:
/* 3620 */         intVal = getNativeInt(columnIndex, false);
/*      */         
/* 3622 */         if (this.wasNullFlag) {
/* 3623 */           return null;
/*      */         }
/*      */         
/* 3626 */         if (!field.isUnsigned() || intVal >= 0) {
/* 3627 */           return String.valueOf(intVal);
/*      */         }
/*      */         
/* 3630 */         intVal &= 0xFFFF;
/*      */         
/* 3632 */         return String.valueOf(intVal);
/*      */       
/*      */       case 4:
/* 3635 */         intVal = getNativeInt(columnIndex, false);
/*      */         
/* 3637 */         if (this.wasNullFlag) {
/* 3638 */           return null;
/*      */         }
/*      */         
/* 3641 */         if (!field.isUnsigned() || intVal >= 0 || field.getMysqlType() == 9)
/*      */         {
/*      */           
/* 3644 */           return String.valueOf(intVal);
/*      */         }
/*      */         
/* 3647 */         longVal = intVal & 0xFFFFFFFFL;
/*      */         
/* 3649 */         return String.valueOf(longVal);
/*      */ 
/*      */       
/*      */       case -5:
/* 3653 */         if (!field.isUnsigned()) {
/* 3654 */           long longVal = getNativeLong(columnIndex, false, true);
/*      */           
/* 3656 */           if (this.wasNullFlag) {
/* 3657 */             return null;
/*      */           }
/*      */           
/* 3660 */           return String.valueOf(longVal);
/*      */         } 
/*      */         
/* 3663 */         longVal = getNativeLong(columnIndex, false, false);
/*      */         
/* 3665 */         if (this.wasNullFlag) {
/* 3666 */           return null;
/*      */         }
/*      */         
/* 3669 */         return String.valueOf(convertLongToUlong(longVal));
/*      */       case 7:
/* 3671 */         floatVal = getNativeFloat(columnIndex);
/*      */         
/* 3673 */         if (this.wasNullFlag) {
/* 3674 */           return null;
/*      */         }
/*      */         
/* 3677 */         return String.valueOf(floatVal);
/*      */       
/*      */       case 6:
/*      */       case 8:
/* 3681 */         doubleVal = getNativeDouble(columnIndex);
/*      */         
/* 3683 */         if (this.wasNullFlag) {
/* 3684 */           return null;
/*      */         }
/*      */         
/* 3687 */         return String.valueOf(doubleVal);
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 3691 */         stringVal = StringUtils.toAsciiString(this.thisRow.getColumnValue(columnIndex - 1));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3696 */         if (stringVal != null) {
/* 3697 */           BigDecimal val; this.wasNullFlag = false;
/*      */           
/* 3699 */           if (stringVal.length() == 0) {
/* 3700 */             val = new BigDecimal(0.0D);
/*      */             
/* 3702 */             return val.toString();
/*      */           } 
/*      */           
/*      */           try {
/* 3706 */             val = new BigDecimal(stringVal);
/* 3707 */           } catch (NumberFormatException ex) {
/* 3708 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Constants.integerValueOf(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3715 */           return val.toString();
/*      */         } 
/*      */         
/* 3718 */         this.wasNullFlag = true;
/*      */         
/* 3720 */         return null;
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 3726 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */       
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/* 3731 */         if (!field.isBlob())
/* 3732 */           return extractStringFromNativeColumn(columnIndex, mysqlType); 
/* 3733 */         if (!field.isBinary()) {
/* 3734 */           return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */         }
/* 3736 */         data = getBytes(columnIndex);
/* 3737 */         obj = data;
/*      */         
/* 3739 */         if (data != null && data.length >= 2) {
/* 3740 */           if (data[0] == -84 && data[1] == -19) {
/*      */             
/*      */             try {
/* 3743 */               ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/*      */               
/* 3745 */               ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/*      */               
/* 3747 */               obj = objIn.readObject();
/* 3748 */               objIn.close();
/* 3749 */               bytesIn.close();
/* 3750 */             } catch (ClassNotFoundException cnfe) {
/* 3751 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             }
/* 3757 */             catch (IOException ex) {
/* 3758 */               obj = data;
/*      */             } 
/*      */           }
/*      */           
/* 3762 */           return obj.toString();
/*      */         } 
/*      */         
/* 3765 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 91:
/* 3771 */         if (mysqlType == 13) {
/* 3772 */           short shortVal = getNativeShort(columnIndex);
/*      */           
/* 3774 */           if (!this.connection.getYearIsDateType()) {
/*      */             
/* 3776 */             if (this.wasNullFlag) {
/* 3777 */               return null;
/*      */             }
/*      */             
/* 3780 */             return String.valueOf(shortVal);
/*      */           } 
/*      */           
/* 3783 */           if (field.getLength() == 2L) {
/*      */             
/* 3785 */             if (shortVal <= 69) {
/* 3786 */               shortVal = (short)(shortVal + 100);
/*      */             }
/*      */             
/* 3789 */             shortVal = (short)(shortVal + 1900);
/*      */           } 
/*      */           
/* 3792 */           return fastDateCreate(null, shortVal, 1, 1).toString();
/*      */         } 
/*      */ 
/*      */         
/* 3796 */         dt = getNativeDate(columnIndex);
/*      */         
/* 3798 */         if (dt == null) {
/* 3799 */           return null;
/*      */         }
/*      */         
/* 3802 */         return String.valueOf(dt);
/*      */       
/*      */       case 92:
/* 3805 */         tm = getNativeTime(columnIndex, null, this.defaultTimeZone, false);
/*      */         
/* 3807 */         if (tm == null) {
/* 3808 */           return null;
/*      */         }
/*      */         
/* 3811 */         return String.valueOf(tm);
/*      */       
/*      */       case 93:
/* 3814 */         tstamp = getNativeTimestamp(columnIndex, null, this.defaultTimeZone, false);
/*      */ 
/*      */         
/* 3817 */         if (tstamp == null) {
/* 3818 */           return null;
/*      */         }
/*      */         
/* 3821 */         result = String.valueOf(tstamp);
/*      */         
/* 3823 */         if (!this.connection.getNoDatetimeStringSync()) {
/* 3824 */           return result;
/*      */         }
/*      */         
/* 3827 */         if (result.endsWith(".0")) {
/* 3828 */           return result.substring(0, result.length() - 2);
/*      */         }
/*      */         break;
/*      */     } 
/* 3832 */     return extractStringFromNativeColumn(columnIndex, mysqlType); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 3848 */   protected Date getNativeDate(int columnIndex) throws SQLException { return getNativeDate(columnIndex, null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Date getNativeDate(int columnIndex, TimeZone tz) throws SQLException {
/* 3869 */     checkRowPos();
/* 3870 */     checkColumnBounds(columnIndex);
/*      */     
/* 3872 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 3874 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 3876 */     Date dateToReturn = null;
/*      */     
/* 3878 */     if (mysqlType == 10) {
/*      */       
/* 3880 */       dateToReturn = this.thisRow.getNativeDate(columnIndexMinusOne, this.connection, this);
/*      */     }
/*      */     else {
/*      */       
/* 3884 */       boolean rollForward = (tz != null && !tz.equals(getDefaultTimeZone()));
/*      */       
/* 3886 */       dateToReturn = (Date)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 91, mysqlType, tz, rollForward, this.connection, this);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3898 */     if (dateToReturn == null) {
/*      */       
/* 3900 */       this.wasNullFlag = true;
/*      */       
/* 3902 */       return null;
/*      */     } 
/*      */     
/* 3905 */     this.wasNullFlag = false;
/*      */     
/* 3907 */     return dateToReturn;
/*      */   }
/*      */   
/*      */   Date getNativeDateViaParseConversion(int columnIndex) throws SQLException {
/* 3911 */     if (this.useUsageAdvisor) {
/* 3912 */       issueConversionViaParsingWarning("getDate()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex - 1], new int[] { 10 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3917 */     String stringVal = getNativeString(columnIndex);
/*      */     
/* 3919 */     return getDateFromString(stringVal, columnIndex, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected double getNativeDouble(int columnIndex) throws SQLException {
/*      */     BigInteger asBigInt;
/*      */     long valueAsLong;
/* 3934 */     checkRowPos();
/* 3935 */     checkColumnBounds(columnIndex);
/*      */     
/* 3937 */     columnIndex--;
/*      */     
/* 3939 */     if (this.thisRow.isNull(columnIndex)) {
/* 3940 */       this.wasNullFlag = true;
/*      */       
/* 3942 */       return 0.0D;
/*      */     } 
/*      */     
/* 3945 */     this.wasNullFlag = false;
/*      */     
/* 3947 */     Field f = this.fields[columnIndex];
/*      */     
/* 3949 */     switch (f.getMysqlType()) {
/*      */       case 5:
/* 3951 */         return this.thisRow.getNativeDouble(columnIndex);
/*      */       case 1:
/* 3953 */         if (!f.isUnsigned()) {
/* 3954 */           return getNativeByte(columnIndex + 1);
/*      */         }
/*      */         
/* 3957 */         return getNativeShort(columnIndex + 1);
/*      */       case 2:
/*      */       case 13:
/* 3960 */         if (!f.isUnsigned()) {
/* 3961 */           return getNativeShort(columnIndex + 1);
/*      */         }
/*      */         
/* 3964 */         return getNativeInt(columnIndex + 1);
/*      */       case 3:
/*      */       case 9:
/* 3967 */         if (!f.isUnsigned()) {
/* 3968 */           return getNativeInt(columnIndex + 1);
/*      */         }
/*      */         
/* 3971 */         return getNativeLong(columnIndex + 1);
/*      */       case 8:
/* 3973 */         valueAsLong = getNativeLong(columnIndex + 1);
/*      */         
/* 3975 */         if (!f.isUnsigned()) {
/* 3976 */           return valueAsLong;
/*      */         }
/*      */         
/* 3979 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/*      */ 
/*      */         
/* 3983 */         return asBigInt.doubleValue();
/*      */       case 4:
/* 3985 */         return getNativeFloat(columnIndex + 1);
/*      */       case 16:
/* 3987 */         return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     } 
/* 3989 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 3991 */     if (this.useUsageAdvisor) {
/* 3992 */       issueConversionViaParsingWarning("getDouble()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4002 */     return getDoubleFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected float getNativeFloat(int columnIndex) throws SQLException {
/*      */     BigInteger asBigInt;
/*      */     float valueAsFloat;
/*      */     Double valueAsDouble;
/*      */     long valueAsLong, valueAsLong;
/* 4018 */     checkRowPos();
/* 4019 */     checkColumnBounds(columnIndex);
/*      */     
/* 4021 */     columnIndex--;
/*      */     
/* 4023 */     if (this.thisRow.isNull(columnIndex)) {
/* 4024 */       this.wasNullFlag = true;
/*      */       
/* 4026 */       return 0.0F;
/*      */     } 
/*      */     
/* 4029 */     this.wasNullFlag = false;
/*      */     
/* 4031 */     Field f = this.fields[columnIndex];
/*      */     
/* 4033 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 4035 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 4037 */         return (float)valueAsLong;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 5:
/* 4044 */         valueAsDouble = new Double(getNativeDouble(columnIndex + 1));
/*      */         
/* 4046 */         valueAsFloat = valueAsDouble.floatValue();
/*      */         
/* 4048 */         if ((this.jdbcCompliantTruncationForReads && valueAsFloat == Float.NEGATIVE_INFINITY) || valueAsFloat == Float.POSITIVE_INFINITY)
/*      */         {
/*      */           
/* 4051 */           throwRangeException(valueAsDouble.toString(), columnIndex + 1, 6);
/*      */         }
/*      */ 
/*      */         
/* 4055 */         return (float)getNativeDouble(columnIndex + 1);
/*      */       case 1:
/* 4057 */         if (!f.isUnsigned()) {
/* 4058 */           return getNativeByte(columnIndex + 1);
/*      */         }
/*      */         
/* 4061 */         return getNativeShort(columnIndex + 1);
/*      */       case 2:
/*      */       case 13:
/* 4064 */         if (!f.isUnsigned()) {
/* 4065 */           return getNativeShort(columnIndex + 1);
/*      */         }
/*      */         
/* 4068 */         return getNativeInt(columnIndex + 1);
/*      */       case 3:
/*      */       case 9:
/* 4071 */         if (!f.isUnsigned()) {
/* 4072 */           return getNativeInt(columnIndex + 1);
/*      */         }
/*      */         
/* 4075 */         return (float)getNativeLong(columnIndex + 1);
/*      */       case 8:
/* 4077 */         valueAsLong = getNativeLong(columnIndex + 1);
/*      */         
/* 4079 */         if (!f.isUnsigned()) {
/* 4080 */           return (float)valueAsLong;
/*      */         }
/*      */         
/* 4083 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/*      */ 
/*      */         
/* 4087 */         return asBigInt.floatValue();
/*      */       
/*      */       case 4:
/* 4090 */         return this.thisRow.getNativeFloat(columnIndex);
/*      */     } 
/*      */     
/* 4093 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4095 */     if (this.useUsageAdvisor) {
/* 4096 */       issueConversionViaParsingWarning("getFloat()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4106 */     return getFloatFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4122 */   protected int getNativeInt(int columnIndex) throws SQLException { return getNativeInt(columnIndex, true); } protected int getNativeInt(int columnIndex, boolean overflowCheck) throws SQLException { double valueAsDouble, valueAsDouble; int valueAsInt;
/*      */     short asShort;
/*      */     byte tinyintVal;
/*      */     long valueAsLong, valueAsLong, valueAsLong;
/* 4126 */     checkRowPos();
/* 4127 */     checkColumnBounds(columnIndex);
/*      */     
/* 4129 */     columnIndex--;
/*      */     
/* 4131 */     if (this.thisRow.isNull(columnIndex)) {
/* 4132 */       this.wasNullFlag = true;
/*      */       
/* 4134 */       return 0;
/*      */     } 
/*      */     
/* 4137 */     this.wasNullFlag = false;
/*      */     
/* 4139 */     Field f = this.fields[columnIndex];
/*      */     
/* 4141 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 4143 */         valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */         
/* 4145 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (valueAsLong < -2147483648L || valueAsLong > 2147483647L))
/*      */         {
/*      */           
/* 4148 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */         
/* 4152 */         return (short)(int)valueAsLong;
/*      */       case 1:
/* 4154 */         tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */         
/* 4156 */         if (!f.isUnsigned() || tinyintVal >= 0) {
/* 4157 */           return tinyintVal;
/*      */         }
/*      */         
/* 4160 */         return tinyintVal + 256;
/*      */       case 2:
/*      */       case 13:
/* 4163 */         asShort = getNativeShort(columnIndex + 1, false);
/*      */         
/* 4165 */         if (!f.isUnsigned() || asShort >= 0) {
/* 4166 */           return asShort;
/*      */         }
/*      */         
/* 4169 */         return asShort + 65536;
/*      */       
/*      */       case 3:
/*      */       case 9:
/* 4173 */         valueAsInt = this.thisRow.getNativeInt(columnIndex);
/*      */         
/* 4175 */         if (!f.isUnsigned()) {
/* 4176 */           return valueAsInt;
/*      */         }
/*      */         
/* 4179 */         valueAsLong = (valueAsInt >= 0) ? valueAsInt : (valueAsInt + 4294967296L);
/*      */ 
/*      */         
/* 4182 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && valueAsLong > 2147483647L)
/*      */         {
/* 4184 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */         
/* 4188 */         return (int)valueAsLong;
/*      */       case 8:
/* 4190 */         valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */         
/* 4192 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4193 */           valueAsLong < -2147483648L || valueAsLong > 2147483647L))
/*      */         {
/* 4195 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4200 */         return (int)valueAsLong;
/*      */       case 5:
/* 4202 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 4204 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4205 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D))
/*      */         {
/* 4207 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4212 */         return (int)valueAsDouble;
/*      */       case 4:
/* 4214 */         valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */         
/* 4216 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4217 */           valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D))
/*      */         {
/* 4219 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4224 */         return (int)valueAsDouble;
/*      */     } 
/*      */     
/* 4227 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4229 */     if (this.useUsageAdvisor) {
/* 4230 */       issueConversionViaParsingWarning("getInt()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4240 */     return getIntFromString(stringVal, columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4256 */   protected long getNativeLong(int columnIndex) throws SQLException { return getNativeLong(columnIndex, true, true); } protected long getNativeLong(int columnIndex, boolean overflowCheck, boolean expandUnsignedLong) throws SQLException {
/*      */     double valueAsDouble, valueAsDouble;
/*      */     BigInteger asBigInt;
/*      */     long valueAsLong;
/*      */     int asInt;
/* 4261 */     checkRowPos();
/* 4262 */     checkColumnBounds(columnIndex);
/*      */     
/* 4264 */     columnIndex--;
/*      */     
/* 4266 */     if (this.thisRow.isNull(columnIndex)) {
/* 4267 */       this.wasNullFlag = true;
/*      */       
/* 4269 */       return 0L;
/*      */     } 
/*      */     
/* 4272 */     this.wasNullFlag = false;
/*      */     
/* 4274 */     Field f = this.fields[columnIndex];
/*      */     
/* 4276 */     switch (f.getMysqlType()) {
/*      */       case 16:
/* 4278 */         return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */       case 1:
/* 4280 */         if (!f.isUnsigned()) {
/* 4281 */           return getNativeByte(columnIndex + 1);
/*      */         }
/*      */         
/* 4284 */         return getNativeInt(columnIndex + 1);
/*      */       case 2:
/* 4286 */         if (!f.isUnsigned()) {
/* 4287 */           return getNativeShort(columnIndex + 1);
/*      */         }
/*      */         
/* 4290 */         return getNativeInt(columnIndex + 1, false);
/*      */       
/*      */       case 13:
/* 4293 */         return getNativeShort(columnIndex + 1);
/*      */       case 3:
/*      */       case 9:
/* 4296 */         asInt = getNativeInt(columnIndex + 1, false);
/*      */         
/* 4298 */         if (!f.isUnsigned() || asInt >= 0) {
/* 4299 */           return asInt;
/*      */         }
/*      */         
/* 4302 */         return asInt + 4294967296L;
/*      */       case 8:
/* 4304 */         valueAsLong = this.thisRow.getNativeLong(columnIndex);
/*      */         
/* 4306 */         if (!f.isUnsigned() || !expandUnsignedLong) {
/* 4307 */           return valueAsLong;
/*      */         }
/*      */         
/* 4310 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */         
/* 4312 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (asBigInt.compareTo(new BigInteger(String.valueOf(Long.MAX_VALUE))) > 0 || asBigInt.compareTo(new BigInteger(String.valueOf(Long.MIN_VALUE))) < 0))
/*      */         {
/*      */           
/* 4315 */           throwRangeException(asBigInt.toString(), columnIndex + 1, -5);
/*      */         }
/*      */ 
/*      */         
/* 4319 */         return getLongFromString(asBigInt.toString(), columnIndex);
/*      */       
/*      */       case 5:
/* 4322 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 4324 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4325 */           valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D))
/*      */         {
/* 4327 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4332 */         return (long)valueAsDouble;
/*      */       case 4:
/* 4334 */         valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */         
/* 4336 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4337 */           valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D))
/*      */         {
/* 4339 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4344 */         return (long)valueAsDouble;
/*      */     } 
/* 4346 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4348 */     if (this.useUsageAdvisor) {
/* 4349 */       issueConversionViaParsingWarning("getLong()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4359 */     return getLongFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4377 */   protected Ref getNativeRef(int i) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4392 */   protected short getNativeShort(int columnIndex) throws SQLException { return getNativeShort(columnIndex, true); } protected short getNativeShort(int columnIndex, boolean overflowCheck) throws SQLException { float valueAsFloat; double valueAsDouble; BigInteger asBigInt; long valueAsLong, valueAsLong;
/*      */     int valueAsInt;
/*      */     short asShort;
/*      */     byte tinyintVal;
/* 4396 */     checkRowPos();
/* 4397 */     checkColumnBounds(columnIndex);
/*      */     
/* 4399 */     columnIndex--;
/*      */ 
/*      */     
/* 4402 */     if (this.thisRow.isNull(columnIndex)) {
/* 4403 */       this.wasNullFlag = true;
/*      */       
/* 4405 */       return 0;
/*      */     } 
/*      */     
/* 4408 */     this.wasNullFlag = false;
/*      */     
/* 4410 */     Field f = this.fields[columnIndex];
/*      */     
/* 4412 */     switch (f.getMysqlType()) {
/*      */       
/*      */       case 1:
/* 4415 */         tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */         
/* 4417 */         if (!f.isUnsigned() || tinyintVal >= 0) {
/* 4418 */           return (short)tinyintVal;
/*      */         }
/*      */         
/* 4421 */         return (short)(tinyintVal + 256);
/*      */       
/*      */       case 2:
/*      */       case 13:
/* 4425 */         asShort = this.thisRow.getNativeShort(columnIndex);
/*      */         
/* 4427 */         if (!f.isUnsigned()) {
/* 4428 */           return asShort;
/*      */         }
/*      */         
/* 4431 */         valueAsInt = asShort & 0xFFFF;
/*      */         
/* 4433 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && valueAsInt > 32767)
/*      */         {
/* 4435 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */         
/* 4439 */         return (short)valueAsInt;
/*      */       case 3:
/*      */       case 9:
/* 4442 */         if (!f.isUnsigned()) {
/* 4443 */           int valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */           
/* 4445 */           if ((overflowCheck && this.jdbcCompliantTruncationForReads && valueAsInt > 32767) || valueAsInt < -32768)
/*      */           {
/*      */             
/* 4448 */             throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */           }
/*      */ 
/*      */           
/* 4452 */           return (short)valueAsInt;
/*      */         } 
/*      */         
/* 4455 */         valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */         
/* 4457 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && valueAsLong > 32767L)
/*      */         {
/* 4459 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */         
/* 4463 */         return (short)(int)valueAsLong;
/*      */       
/*      */       case 8:
/* 4466 */         valueAsLong = getNativeLong(columnIndex + 1, false, false);
/*      */         
/* 4468 */         if (!f.isUnsigned()) {
/* 4469 */           if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4470 */             valueAsLong < -32768L || valueAsLong > 32767L))
/*      */           {
/* 4472 */             throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 4477 */           return (short)(int)valueAsLong;
/*      */         } 
/*      */         
/* 4480 */         asBigInt = convertLongToUlong(valueAsLong);
/*      */         
/* 4482 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (asBigInt.compareTo(new BigInteger(String.valueOf(32767))) > 0 || asBigInt.compareTo(new BigInteger(String.valueOf(-32768))) < 0))
/*      */         {
/*      */           
/* 4485 */           throwRangeException(asBigInt.toString(), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */         
/* 4489 */         return (short)getIntFromString(asBigInt.toString(), columnIndex + 1);
/*      */       
/*      */       case 5:
/* 4492 */         valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */         
/* 4494 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4495 */           valueAsDouble < -32768.0D || valueAsDouble > 32767.0D))
/*      */         {
/* 4497 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4502 */         return (short)(int)valueAsDouble;
/*      */       case 4:
/* 4504 */         valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */         
/* 4506 */         if (overflowCheck && this.jdbcCompliantTruncationForReads && (
/* 4507 */           valueAsFloat < -32768.0F || valueAsFloat > 32767.0F))
/*      */         {
/* 4509 */           throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, 5);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 4514 */         return (short)(int)valueAsFloat;
/*      */     } 
/* 4516 */     String stringVal = getNativeString(columnIndex + 1);
/*      */     
/* 4518 */     if (this.useUsageAdvisor) {
/* 4519 */       issueConversionViaParsingWarning("getShort()", columnIndex, stringVal, this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4529 */     return getShortFromString(stringVal, columnIndex + 1); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getNativeString(int columnIndex) throws SQLException {
/* 4545 */     checkRowPos();
/* 4546 */     checkColumnBounds(columnIndex);
/*      */     
/* 4548 */     if (this.fields == null) {
/* 4549 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_133"), "S1002", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4555 */     if (this.thisRow.isNull(columnIndex - 1)) {
/* 4556 */       this.wasNullFlag = true;
/*      */       
/* 4558 */       return null;
/*      */     } 
/*      */     
/* 4561 */     this.wasNullFlag = false;
/*      */     
/* 4563 */     String stringVal = null;
/*      */     
/* 4565 */     Field field = this.fields[columnIndex - 1];
/*      */ 
/*      */     
/* 4568 */     stringVal = getNativeConvertToString(columnIndex, field);
/*      */     
/* 4570 */     if (field.isZeroFill() && stringVal != null) {
/* 4571 */       int origLength = stringVal.length();
/*      */       
/* 4573 */       StringBuffer zeroFillBuf = new StringBuffer(origLength);
/*      */       
/* 4575 */       long numZeros = field.getLength() - origLength;
/*      */       long i;
/* 4577 */       for (i = 0L; i < numZeros; i++) {
/* 4578 */         zeroFillBuf.append('0');
/*      */       }
/*      */       
/* 4581 */       zeroFillBuf.append(stringVal);
/*      */       
/* 4583 */       stringVal = zeroFillBuf.toString();
/*      */     } 
/*      */     
/* 4586 */     return stringVal;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Time getNativeTime(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4592 */     checkRowPos();
/* 4593 */     checkColumnBounds(columnIndex);
/*      */     
/* 4595 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4597 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4599 */     Time timeVal = null;
/*      */     
/* 4601 */     if (mysqlType == 11) {
/* 4602 */       timeVal = this.thisRow.getNativeTime(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */     }
/*      */     else {
/*      */       
/* 4606 */       timeVal = (Time)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 92, mysqlType, tz, rollForward, this.connection, this);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4618 */     if (timeVal == null) {
/*      */       
/* 4620 */       this.wasNullFlag = true;
/*      */       
/* 4622 */       return null;
/*      */     } 
/*      */     
/* 4625 */     this.wasNullFlag = false;
/*      */     
/* 4627 */     return timeVal;
/*      */   }
/*      */ 
/*      */   
/*      */   Time getNativeTimeViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4632 */     if (this.useUsageAdvisor) {
/* 4633 */       issueConversionViaParsingWarning("getTime()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex - 1], new int[] { 11 });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4638 */     String strTime = getNativeString(columnIndex);
/*      */     
/* 4640 */     return getTimeFromString(strTime, targetCalendar, columnIndex, tz, rollForward);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Timestamp getNativeTimestamp(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4647 */     checkRowPos();
/* 4648 */     checkColumnBounds(columnIndex);
/*      */     
/* 4650 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4652 */     Timestamp tsVal = null;
/*      */     
/* 4654 */     int mysqlType = this.fields[columnIndexMinusOne].getMysqlType();
/*      */     
/* 4656 */     switch (mysqlType) {
/*      */       case 7:
/*      */       case 12:
/* 4659 */         tsVal = this.thisRow.getNativeTimestamp(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/* 4666 */         tsVal = (Timestamp)this.thisRow.getNativeDateTimeValue(columnIndexMinusOne, null, 93, mysqlType, tz, rollForward, this.connection, this);
/*      */         break;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4678 */     if (tsVal == null) {
/*      */       
/* 4680 */       this.wasNullFlag = true;
/*      */       
/* 4682 */       return null;
/*      */     } 
/*      */     
/* 4685 */     this.wasNullFlag = false;
/*      */     
/* 4687 */     return tsVal;
/*      */   }
/*      */ 
/*      */   
/*      */   Timestamp getNativeTimestampViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 4692 */     if (this.useUsageAdvisor) {
/* 4693 */       issueConversionViaParsingWarning("getTimestamp()", columnIndex, this.thisRow.getColumnValue(columnIndex - 1), this.fields[columnIndex - 1], new int[] { 7, 12 });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4699 */     String strTimestamp = getNativeString(columnIndex);
/*      */     
/* 4701 */     return getTimestampFromString(columnIndex, targetCalendar, strTimestamp, tz, rollForward);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected InputStream getNativeUnicodeStream(int columnIndex) throws SQLException {
/* 4728 */     checkRowPos();
/*      */     
/* 4730 */     return getBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected URL getNativeURL(int colIndex) throws SQLException {
/* 4737 */     String val = getString(colIndex);
/*      */     
/* 4739 */     if (val == null) {
/* 4740 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 4744 */       return new URL(val);
/* 4745 */     } catch (MalformedURLException mfe) {
/* 4746 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____141") + val + "'", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4758 */   public ResultSetInternalMethods getNextResultSet() { return this.nextResultSet; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int columnIndex) throws SQLException {
/*      */     String stringVal, stringVal;
/* 4785 */     checkRowPos();
/* 4786 */     checkColumnBounds(columnIndex);
/*      */     
/* 4788 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 4790 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 4791 */       this.wasNullFlag = true;
/*      */       
/* 4793 */       return null;
/*      */     } 
/*      */     
/* 4796 */     this.wasNullFlag = false;
/*      */ 
/*      */     
/* 4799 */     Field field = this.fields[columnIndexMinusOne];
/*      */     
/* 4801 */     switch (field.getSQLType()) {
/*      */       case -7:
/*      */       case 16:
/* 4804 */         if (field.getMysqlType() == 16 && !field.isSingleBit())
/*      */         {
/* 4806 */           return getBytes(columnIndex);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4812 */         return Boolean.valueOf(getBoolean(columnIndex));
/*      */       
/*      */       case -6:
/* 4815 */         if (!field.isUnsigned()) {
/* 4816 */           return Constants.integerValueOf(getByte(columnIndex));
/*      */         }
/*      */         
/* 4819 */         return Constants.integerValueOf(getInt(columnIndex));
/*      */ 
/*      */       
/*      */       case 5:
/* 4823 */         return Constants.integerValueOf(getInt(columnIndex));
/*      */ 
/*      */       
/*      */       case 4:
/* 4827 */         if (!field.isUnsigned() || field.getMysqlType() == 9)
/*      */         {
/* 4829 */           return Constants.integerValueOf(getInt(columnIndex));
/*      */         }
/*      */         
/* 4832 */         return Constants.longValueOf(getLong(columnIndex));
/*      */ 
/*      */       
/*      */       case -5:
/* 4836 */         if (!field.isUnsigned()) {
/* 4837 */           return Constants.longValueOf(getLong(columnIndex));
/*      */         }
/*      */         
/* 4840 */         stringVal = getString(columnIndex);
/*      */         
/* 4842 */         if (stringVal == null) {
/* 4843 */           return null;
/*      */         }
/*      */         
/*      */         try {
/* 4847 */           return new BigInteger(stringVal);
/* 4848 */         } catch (NumberFormatException nfe) {
/* 4849 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] { Constants.integerValueOf(columnIndex), stringVal }), "S1009", getExceptionInterceptor());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 4857 */         stringVal = getString(columnIndex);
/*      */ 
/*      */ 
/*      */         
/* 4861 */         if (stringVal != null) {
/* 4862 */           BigDecimal val; if (stringVal.length() == 0) {
/* 4863 */             val = new BigDecimal(0.0D);
/*      */             
/* 4865 */             return val;
/*      */           } 
/*      */           
/*      */           try {
/* 4869 */             val = new BigDecimal(stringVal);
/* 4870 */           } catch (NumberFormatException ex) {
/* 4871 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 4878 */           return val;
/*      */         } 
/*      */         
/* 4881 */         return null;
/*      */       
/*      */       case 7:
/* 4884 */         return new Float(getFloat(columnIndex));
/*      */       
/*      */       case 6:
/*      */       case 8:
/* 4888 */         return new Double(getDouble(columnIndex));
/*      */       
/*      */       case 1:
/*      */       case 12:
/* 4892 */         if (!field.isOpaqueBinary()) {
/* 4893 */           return getString(columnIndex);
/*      */         }
/*      */         
/* 4896 */         return getBytes(columnIndex);
/*      */       case -1:
/* 4898 */         if (!field.isOpaqueBinary()) {
/* 4899 */           return getStringForClob(columnIndex);
/*      */         }
/*      */         
/* 4902 */         return getBytes(columnIndex);
/*      */       
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/* 4907 */         if (field.getMysqlType() == 255)
/* 4908 */           return getBytes(columnIndex); 
/* 4909 */         if (field.isBinary() || field.isBlob()) {
/* 4910 */           byte[] data = getBytes(columnIndex);
/*      */           
/* 4912 */           if (this.connection.getAutoDeserialize()) {
/* 4913 */             Object obj = data;
/*      */             
/* 4915 */             if (data != null && data.length >= 2) {
/* 4916 */               if (data[0] == -84 && data[1] == -19) {
/*      */                 
/*      */                 try {
/* 4919 */                   ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/*      */                   
/* 4921 */                   ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/*      */                   
/* 4923 */                   obj = objIn.readObject();
/* 4924 */                   objIn.close();
/* 4925 */                   bytesIn.close();
/* 4926 */                 } catch (ClassNotFoundException cnfe) {
/* 4927 */                   throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/*      */                 }
/* 4933 */                 catch (IOException ex) {
/* 4934 */                   obj = data;
/*      */                 } 
/*      */               } else {
/* 4937 */                 return getString(columnIndex);
/*      */               } 
/*      */             }
/*      */             
/* 4941 */             return obj;
/*      */           } 
/*      */           
/* 4944 */           return data;
/*      */         } 
/*      */         
/* 4947 */         return getBytes(columnIndex);
/*      */       
/*      */       case 91:
/* 4950 */         if (field.getMysqlType() == 13 && !this.connection.getYearIsDateType())
/*      */         {
/* 4952 */           return Constants.shortValueOf(getShort(columnIndex));
/*      */         }
/*      */         
/* 4955 */         return getDate(columnIndex);
/*      */       
/*      */       case 92:
/* 4958 */         return getTime(columnIndex);
/*      */       
/*      */       case 93:
/* 4961 */         return getTimestamp(columnIndex);
/*      */     } 
/*      */     
/* 4964 */     return getString(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4984 */   public Object getObject(int i, Map map) throws SQLException { return getObject(i); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5011 */   public Object getObject(String columnName) throws SQLException { return getObject(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5031 */   public Object getObject(String colName, Map map) throws SQLException { return getObject(findColumn(colName), map); }
/*      */ 
/*      */   
/*      */   public Object getObjectStoredProc(int columnIndex, int desiredSqlType) throws SQLException {
/*      */     String stringVal;
/* 5036 */     checkRowPos();
/* 5037 */     checkColumnBounds(columnIndex);
/*      */     
/* 5039 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 5041 */     if (value == null) {
/* 5042 */       this.wasNullFlag = true;
/*      */       
/* 5044 */       return null;
/*      */     } 
/*      */     
/* 5047 */     this.wasNullFlag = false;
/*      */ 
/*      */     
/* 5050 */     Field field = this.fields[columnIndex - 1];
/*      */     
/* 5052 */     switch (desiredSqlType) {
/*      */ 
/*      */ 
/*      */       
/*      */       case -7:
/*      */       case 16:
/* 5058 */         return Boolean.valueOf(getBoolean(columnIndex));
/*      */       
/*      */       case -6:
/* 5061 */         return Constants.integerValueOf(getInt(columnIndex));
/*      */       
/*      */       case 5:
/* 5064 */         return Constants.integerValueOf(getInt(columnIndex));
/*      */ 
/*      */       
/*      */       case 4:
/* 5068 */         if (!field.isUnsigned() || field.getMysqlType() == 9)
/*      */         {
/* 5070 */           return Constants.integerValueOf(getInt(columnIndex));
/*      */         }
/*      */         
/* 5073 */         return Constants.longValueOf(getLong(columnIndex));
/*      */ 
/*      */       
/*      */       case -5:
/* 5077 */         if (field.isUnsigned()) {
/* 5078 */           return getBigDecimal(columnIndex);
/*      */         }
/*      */         
/* 5081 */         return Constants.longValueOf(getLong(columnIndex));
/*      */ 
/*      */       
/*      */       case 2:
/*      */       case 3:
/* 5086 */         stringVal = getString(columnIndex);
/*      */ 
/*      */         
/* 5089 */         if (stringVal != null) {
/* 5090 */           BigDecimal val; if (stringVal.length() == 0) {
/* 5091 */             val = new BigDecimal(0.0D);
/*      */             
/* 5093 */             return val;
/*      */           } 
/*      */           
/*      */           try {
/* 5097 */             val = new BigDecimal(stringVal);
/* 5098 */           } catch (NumberFormatException ex) {
/* 5099 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009", getExceptionInterceptor());
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 5106 */           return val;
/*      */         } 
/*      */         
/* 5109 */         return null;
/*      */       
/*      */       case 7:
/* 5112 */         return new Float(getFloat(columnIndex));
/*      */ 
/*      */       
/*      */       case 6:
/* 5116 */         if (!this.connection.getRunningCTS13()) {
/* 5117 */           return new Double(getFloat(columnIndex));
/*      */         }
/* 5119 */         return new Float(getFloat(columnIndex));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/* 5126 */         return new Double(getDouble(columnIndex));
/*      */       
/*      */       case 1:
/*      */       case 12:
/* 5130 */         return getString(columnIndex);
/*      */       case -1:
/* 5132 */         return getStringForClob(columnIndex);
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/* 5136 */         return getBytes(columnIndex);
/*      */       
/*      */       case 91:
/* 5139 */         if (field.getMysqlType() == 13 && !this.connection.getYearIsDateType())
/*      */         {
/* 5141 */           return Constants.shortValueOf(getShort(columnIndex));
/*      */         }
/*      */         
/* 5144 */         return getDate(columnIndex);
/*      */       
/*      */       case 92:
/* 5147 */         return getTime(columnIndex);
/*      */       
/*      */       case 93:
/* 5150 */         return getTimestamp(columnIndex);
/*      */     } 
/*      */     
/* 5153 */     return getString(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5159 */   public Object getObjectStoredProc(int i, Map map, int desiredSqlType) throws SQLException { return getObjectStoredProc(i, desiredSqlType); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5164 */   public Object getObjectStoredProc(String columnName, int desiredSqlType) throws SQLException { return getObjectStoredProc(findColumn(columnName), desiredSqlType); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5169 */   public Object getObjectStoredProc(String colName, Map map, int desiredSqlType) throws SQLException { return getObjectStoredProc(findColumn(colName), map, desiredSqlType); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int i) throws SQLException {
/* 5186 */     checkColumnBounds(i);
/* 5187 */     throw SQLError.notImplemented();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5204 */   public Ref getRef(String colName) throws SQLException { return getRef(findColumn(colName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 5221 */     checkClosed();
/*      */     
/* 5223 */     int currentRowNumber = this.rowData.getCurrentRowNumber();
/* 5224 */     int row = 0;
/*      */ 
/*      */ 
/*      */     
/* 5228 */     if (!this.rowData.isDynamic()) {
/* 5229 */       if (currentRowNumber < 0 || this.rowData.isAfterLast() || this.rowData.isEmpty()) {
/*      */         
/* 5231 */         row = 0;
/*      */       } else {
/* 5233 */         row = currentRowNumber + 1;
/*      */       } 
/*      */     } else {
/*      */       
/* 5237 */       row = currentRowNumber + 1;
/*      */     } 
/*      */     
/* 5240 */     return row;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5249 */   public String getServerInfo() { return this.serverInfo; }
/*      */ 
/*      */ 
/*      */   
/*      */   private long getNumericRepresentationOfSQLBitType(int columnIndex) throws SQLException {
/* 5254 */     Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */     
/* 5256 */     if (this.fields[columnIndex - 1].isSingleBit() || ((byte[])value).length == 1)
/*      */     {
/* 5258 */       return ((byte[])value)[0];
/*      */     }
/*      */ 
/*      */     
/* 5262 */     byte[] asBytes = (byte[])value;
/*      */ 
/*      */     
/* 5265 */     int shift = 0;
/*      */     
/* 5267 */     long[] steps = new long[asBytes.length];
/*      */     
/* 5269 */     for (int i = asBytes.length - 1; i >= 0; i--) {
/* 5270 */       steps[i] = (asBytes[i] & 0xFF) << shift;
/* 5271 */       shift += 8;
/*      */     } 
/*      */     
/* 5274 */     long valueAsLong = 0L;
/*      */     
/* 5276 */     for (int i = 0; i < asBytes.length; i++) {
/* 5277 */       valueAsLong |= steps[i];
/*      */     }
/*      */     
/* 5280 */     return valueAsLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int columnIndex) throws SQLException {
/* 5295 */     if (!this.isBinaryEncoded) {
/* 5296 */       checkRowPos();
/*      */       
/* 5298 */       if (this.useFastIntParsing) {
/*      */         
/* 5300 */         checkColumnBounds(columnIndex);
/*      */         
/* 5302 */         Object value = this.thisRow.getColumnValue(columnIndex - 1);
/*      */         
/* 5304 */         if (value == null) {
/* 5305 */           this.wasNullFlag = true;
/*      */         } else {
/* 5307 */           this.wasNullFlag = false;
/*      */         } 
/*      */         
/* 5310 */         if (this.wasNullFlag) {
/* 5311 */           return 0;
/*      */         }
/*      */         
/* 5314 */         byte[] shortAsBytes = (byte[])value;
/*      */         
/* 5316 */         if (shortAsBytes.length == 0) {
/* 5317 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5320 */         boolean needsFullParse = false;
/*      */         
/* 5322 */         for (int i = 0; i < shortAsBytes.length; i++) {
/* 5323 */           if ((char)shortAsBytes[i] == 'e' || (char)shortAsBytes[i] == 'E') {
/*      */             
/* 5325 */             needsFullParse = true;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/* 5331 */         if (!needsFullParse) {
/*      */           try {
/* 5333 */             return parseShortWithOverflowCheck(columnIndex, shortAsBytes, null);
/*      */           }
/* 5335 */           catch (NumberFormatException nfe) {
/*      */             
/*      */             try {
/* 5338 */               return parseShortAsDouble(columnIndex, new String(shortAsBytes));
/*      */             }
/* 5340 */             catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */               
/* 5344 */               if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 5345 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */                 
/* 5347 */                 if (this.jdbcCompliantTruncationForReads && (valueAsLong < -32768L || valueAsLong > 32767L))
/*      */                 {
/*      */                   
/* 5350 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */                 }
/*      */ 
/*      */                 
/* 5354 */                 return (short)(int)valueAsLong;
/*      */               } 
/*      */               
/* 5357 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + new String(shortAsBytes) + "'", "S1009", getExceptionInterceptor());
/*      */             } 
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5367 */       String val = null;
/*      */       
/*      */       try {
/* 5370 */         val = getString(columnIndex);
/*      */         
/* 5372 */         if (val != null) {
/*      */           
/* 5374 */           if (val.length() == 0) {
/* 5375 */             return (short)convertToZeroWithEmptyCheck();
/*      */           }
/*      */           
/* 5378 */           if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1)
/*      */           {
/* 5380 */             return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 5385 */           return parseShortAsDouble(columnIndex, val);
/*      */         } 
/*      */         
/* 5388 */         return 0;
/* 5389 */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 5391 */           return parseShortAsDouble(columnIndex, val);
/* 5392 */         } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */           
/* 5396 */           if (this.fields[columnIndex - 1].getMysqlType() == 16) {
/* 5397 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */             
/* 5399 */             if (this.jdbcCompliantTruncationForReads && (valueAsLong < -32768L || valueAsLong > 32767L))
/*      */             {
/*      */               
/* 5402 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */             }
/*      */ 
/*      */             
/* 5406 */             return (short)(int)valueAsLong;
/*      */           } 
/*      */           
/* 5409 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + val + "'", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5417 */     return getNativeShort(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5432 */   public short getShort(String columnName) throws SQLException { return getShort(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/*      */   private final short getShortFromString(String val, int columnIndex) throws SQLException {
/*      */     try {
/* 5438 */       if (val != null) {
/*      */         
/* 5440 */         if (val.length() == 0) {
/* 5441 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */         
/* 5444 */         if (val.indexOf("e") == -1 && val.indexOf("E") == -1 && val.indexOf(".") == -1)
/*      */         {
/* 5446 */           return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */         }
/*      */ 
/*      */         
/* 5450 */         return parseShortAsDouble(columnIndex, val);
/*      */       } 
/*      */       
/* 5453 */       return 0;
/* 5454 */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 5456 */         return parseShortAsDouble(columnIndex, val);
/* 5457 */       } catch (NumberFormatException newNfe) {
/*      */ 
/*      */ 
/*      */         
/* 5461 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____217") + val + Messages.getString("ResultSet.___in_column__218") + columnIndex, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/* 5480 */     if (this.isClosed && !this.retainOwningStatement) {
/* 5481 */       throw SQLError.createSQLException("Operation not allowed on closed ResultSet. Statements can be retained over result set closure by setting the connection property \"retainStatementAfterResultSetClose\" to \"true\".", "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5489 */     if (this.wrapperStatement != null) {
/* 5490 */       return this.wrapperStatement;
/*      */     }
/*      */     
/* 5493 */     return this.owningStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int columnIndex) throws SQLException {
/* 5508 */     String stringVal = getStringInternal(columnIndex, true);
/*      */     
/* 5510 */     if (this.padCharsWithSpace && stringVal != null) {
/* 5511 */       Field f = this.fields[columnIndex - 1];
/*      */       
/* 5513 */       if (f.getMysqlType() == 254) {
/* 5514 */         int fieldLength = (int)f.getLength() / f.getMaxBytesPerCharacter();
/*      */ 
/*      */         
/* 5517 */         int currentLength = stringVal.length();
/*      */         
/* 5519 */         if (currentLength < fieldLength) {
/* 5520 */           StringBuffer paddedBuf = new StringBuffer(fieldLength);
/* 5521 */           paddedBuf.append(stringVal);
/*      */           
/* 5523 */           int difference = fieldLength - currentLength;
/*      */           
/* 5525 */           paddedBuf.append(EMPTY_SPACE, 0, difference);
/*      */           
/* 5527 */           stringVal = paddedBuf.toString();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 5532 */     return stringVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5548 */   public String getString(String columnName) throws SQLException { return getString(findColumn(columnName)); }
/*      */ 
/*      */   
/*      */   private String getStringForClob(int columnIndex) throws SQLException {
/* 5552 */     String asString = null;
/*      */     
/* 5554 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */ 
/*      */     
/* 5557 */     if (forcedEncoding == null) {
/* 5558 */       if (!this.isBinaryEncoded) {
/* 5559 */         asString = getString(columnIndex);
/*      */       } else {
/* 5561 */         asString = getNativeString(columnIndex);
/*      */       } 
/*      */     } else {
/*      */       try {
/* 5565 */         byte[] asBytes = null;
/*      */         
/* 5567 */         if (!this.isBinaryEncoded) {
/* 5568 */           asBytes = getBytes(columnIndex);
/*      */         } else {
/* 5570 */           asBytes = getNativeBytes(columnIndex, true);
/*      */         } 
/*      */         
/* 5573 */         if (asBytes != null) {
/* 5574 */           asString = new String(asBytes, forcedEncoding);
/*      */         }
/* 5576 */       } catch (UnsupportedEncodingException uee) {
/* 5577 */         throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", getExceptionInterceptor());
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 5582 */     return asString;
/*      */   }
/*      */ 
/*      */   
/*      */   protected String getStringInternal(int columnIndex, boolean checkDateTypes) throws SQLException {
/* 5587 */     if (!this.isBinaryEncoded) {
/* 5588 */       checkRowPos();
/* 5589 */       checkColumnBounds(columnIndex);
/*      */       
/* 5591 */       if (this.fields == null) {
/* 5592 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_99"), "S1002", getExceptionInterceptor());
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5600 */       int internalColumnIndex = columnIndex - 1;
/*      */       
/* 5602 */       if (this.thisRow.isNull(internalColumnIndex)) {
/* 5603 */         this.wasNullFlag = true;
/*      */         
/* 5605 */         return null;
/*      */       } 
/*      */       
/* 5608 */       this.wasNullFlag = false;
/*      */ 
/*      */       
/* 5611 */       Field metadata = this.fields[internalColumnIndex];
/*      */       
/* 5613 */       String stringVal = null;
/*      */       
/* 5615 */       if (metadata.getMysqlType() == 16) {
/* 5616 */         if (metadata.isSingleBit()) {
/* 5617 */           byte[] value = this.thisRow.getColumnValue(internalColumnIndex);
/*      */           
/* 5619 */           if (value.length == 0) {
/* 5620 */             return String.valueOf(convertToZeroWithEmptyCheck());
/*      */           }
/*      */           
/* 5623 */           return String.valueOf(value[0]);
/*      */         } 
/*      */         
/* 5626 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */       } 
/*      */       
/* 5629 */       String encoding = metadata.getCharacterSet();
/*      */       
/* 5631 */       stringVal = this.thisRow.getString(internalColumnIndex, encoding, this.connection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5638 */       if (metadata.getMysqlType() == 13) {
/* 5639 */         if (!this.connection.getYearIsDateType()) {
/* 5640 */           return stringVal;
/*      */         }
/*      */         
/* 5643 */         Date dt = getDateFromString(stringVal, columnIndex, null);
/*      */         
/* 5645 */         if (dt == null) {
/* 5646 */           this.wasNullFlag = true;
/*      */           
/* 5648 */           return null;
/*      */         } 
/*      */         
/* 5651 */         this.wasNullFlag = false;
/*      */         
/* 5653 */         return dt.toString();
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 5658 */       if (checkDateTypes && !this.connection.getNoDatetimeStringSync()) {
/* 5659 */         Timestamp ts; Date dt; Time tm; switch (metadata.getSQLType()) {
/*      */           case 92:
/* 5661 */             tm = getTimeFromString(stringVal, null, columnIndex, getDefaultTimeZone(), false);
/*      */ 
/*      */             
/* 5664 */             if (tm == null) {
/* 5665 */               this.wasNullFlag = true;
/*      */               
/* 5667 */               return null;
/*      */             } 
/*      */             
/* 5670 */             this.wasNullFlag = false;
/*      */             
/* 5672 */             return tm.toString();
/*      */           
/*      */           case 91:
/* 5675 */             dt = getDateFromString(stringVal, columnIndex, null);
/*      */             
/* 5677 */             if (dt == null) {
/* 5678 */               this.wasNullFlag = true;
/*      */               
/* 5680 */               return null;
/*      */             } 
/*      */             
/* 5683 */             this.wasNullFlag = false;
/*      */             
/* 5685 */             return dt.toString();
/*      */           case 93:
/* 5687 */             ts = getTimestampFromString(columnIndex, null, stringVal, getDefaultTimeZone(), false);
/*      */ 
/*      */             
/* 5690 */             if (ts == null) {
/* 5691 */               this.wasNullFlag = true;
/*      */               
/* 5693 */               return null;
/*      */             } 
/*      */             
/* 5696 */             this.wasNullFlag = false;
/*      */             
/* 5698 */             return ts.toString();
/*      */         } 
/*      */ 
/*      */ 
/*      */       
/*      */       } 
/* 5704 */       return stringVal;
/*      */     } 
/*      */     
/* 5707 */     return getNativeString(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5722 */   public Time getTime(int columnIndex) throws SQLException { return getTimeInternal(columnIndex, null, getDefaultTimeZone(), false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5742 */   public Time getTime(int columnIndex, Calendar cal) throws SQLException { return getTimeInternal(columnIndex, cal, cal.getTimeZone(), true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5757 */   public Time getTime(String columnName) throws SQLException { return getTime(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5777 */   public Time getTime(String columnName, Calendar cal) throws SQLException { return getTime(findColumn(columnName), cal); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Time getTimeFromString(String timeAsString, Calendar targetCalendar, int columnIndex, TimeZone tz, boolean rollForward) throws SQLException {
/* 5784 */     int hr = 0;
/* 5785 */     int min = 0;
/* 5786 */     int sec = 0;
/*      */ 
/*      */     
/*      */     try {
/* 5790 */       if (timeAsString == null) {
/* 5791 */         this.wasNullFlag = true;
/*      */         
/* 5793 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 5804 */       timeAsString = timeAsString.trim();
/*      */       
/* 5806 */       if (timeAsString.equals("0") || timeAsString.equals("0000-00-00") || timeAsString.equals("0000-00-00 00:00:00") || timeAsString.equals("00000000000000")) {
/*      */ 
/*      */ 
/*      */         
/* 5810 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/*      */           
/* 5812 */           this.wasNullFlag = true;
/*      */           
/* 5814 */           return null;
/* 5815 */         }  if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 5817 */           throw SQLError.createSQLException("Value '" + timeAsString + "' can not be represented as java.sql.Time", "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5824 */         return fastTimeCreate(targetCalendar, 0, 0, 0);
/*      */       } 
/*      */       
/* 5827 */       this.wasNullFlag = false;
/*      */       
/* 5829 */       Field timeColField = this.fields[columnIndex - 1];
/*      */       
/* 5831 */       if (timeColField.getMysqlType() == 7)
/*      */       
/* 5833 */       { int length = timeAsString.length();
/*      */         
/* 5835 */         switch (length) {
/*      */           
/*      */           case 19:
/* 5838 */             hr = Integer.parseInt(timeAsString.substring(length - 8, length - 6));
/*      */             
/* 5840 */             min = Integer.parseInt(timeAsString.substring(length - 5, length - 3));
/*      */             
/* 5842 */             sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 12:
/*      */           case 14:
/* 5849 */             hr = Integer.parseInt(timeAsString.substring(length - 6, length - 4));
/*      */             
/* 5851 */             min = Integer.parseInt(timeAsString.substring(length - 4, length - 2));
/*      */             
/* 5853 */             sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 10:
/* 5860 */             hr = Integer.parseInt(timeAsString.substring(6, 8));
/* 5861 */             min = Integer.parseInt(timeAsString.substring(8, 10));
/* 5862 */             sec = 0;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 5868 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Timestamp_too_small_to_convert_to_Time_value_in_column__257") + columnIndex + "(" + this.fields[columnIndex - 1] + ").", "S1009", getExceptionInterceptor());
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5877 */         SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_TIMESTAMP_to_Time_with_getTime()_on_column__261") + columnIndex + "(" + this.fields[columnIndex - 1] + ").");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5884 */         if (this.warningChain == null) {
/* 5885 */           this.warningChain = precisionLost;
/*      */         } else {
/* 5887 */           this.warningChain.setNextWarning(precisionLost);
/*      */         }  }
/* 5889 */       else if (timeColField.getMysqlType() == 12)
/* 5890 */       { hr = Integer.parseInt(timeAsString.substring(11, 13));
/* 5891 */         min = Integer.parseInt(timeAsString.substring(14, 16));
/* 5892 */         sec = Integer.parseInt(timeAsString.substring(17, 19));
/*      */         
/* 5894 */         SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_DATETIME_to_Time_with_getTime()_on_column__264") + columnIndex + "(" + this.fields[columnIndex - 1] + ").");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5901 */         if (this.warningChain == null) {
/* 5902 */           this.warningChain = precisionLost;
/*      */         } else {
/* 5904 */           this.warningChain.setNextWarning(precisionLost);
/*      */         }  }
/* 5906 */       else { if (timeColField.getMysqlType() == 10) {
/* 5907 */           return fastTimeCreate(targetCalendar, 0, 0, 0);
/*      */         }
/*      */ 
/*      */         
/* 5911 */         if (timeAsString.length() != 5 && timeAsString.length() != 8)
/*      */         {
/* 5913 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Time____267") + timeAsString + Messages.getString("ResultSet.___in_column__268") + columnIndex, "S1009", getExceptionInterceptor());
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 5920 */         hr = Integer.parseInt(timeAsString.substring(0, 2));
/* 5921 */         min = Integer.parseInt(timeAsString.substring(3, 5));
/* 5922 */         sec = (timeAsString.length() == 5) ? 0 : Integer.parseInt(timeAsString.substring(6)); }
/*      */ 
/*      */ 
/*      */       
/* 5926 */       Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */       
/* 5928 */       synchronized (sessionCalendar) {
/* 5929 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimeCreate(sessionCalendar, hr, min, sec), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 5937 */     catch (Exception ex) {
/* 5938 */       SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1009", getExceptionInterceptor());
/*      */       
/* 5940 */       sqlEx.initCause(ex);
/*      */       
/* 5942 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Time getTimeInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 5963 */     checkRowPos();
/*      */     
/* 5965 */     if (this.isBinaryEncoded) {
/* 5966 */       return getNativeTime(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 5969 */     if (!this.useFastDateParsing) {
/* 5970 */       String timeAsString = getStringInternal(columnIndex, false);
/*      */       
/* 5972 */       return getTimeFromString(timeAsString, targetCalendar, columnIndex, tz, rollForward);
/*      */     } 
/*      */ 
/*      */     
/* 5976 */     checkColumnBounds(columnIndex);
/*      */     
/* 5978 */     int columnIndexMinusOne = columnIndex - 1;
/*      */     
/* 5980 */     if (this.thisRow.isNull(columnIndexMinusOne)) {
/* 5981 */       this.wasNullFlag = true;
/*      */       
/* 5983 */       return null;
/*      */     } 
/*      */     
/* 5986 */     this.wasNullFlag = false;
/*      */     
/* 5988 */     return this.thisRow.getTimeFast(columnIndexMinusOne, targetCalendar, tz, rollForward, this.connection, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6005 */   public Timestamp getTimestamp(int columnIndex) throws SQLException { return getTimestampInternal(columnIndex, null, getDefaultTimeZone(), false); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6027 */   public Timestamp getTimestamp(int columnIndex, Calendar cal) throws SQLException { return getTimestampInternal(columnIndex, cal, cal.getTimeZone(), true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6043 */   public Timestamp getTimestamp(String columnName) throws SQLException { return getTimestamp(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6064 */   public Timestamp getTimestamp(String columnName, Calendar cal) throws SQLException { return getTimestamp(findColumn(columnName), cal); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Timestamp getTimestampFromString(int columnIndex, Calendar targetCalendar, String timestampValue, TimeZone tz, boolean rollForward) throws SQLException {
/*      */     try {
/* 6072 */       this.wasNullFlag = false;
/*      */       
/* 6074 */       if (timestampValue == null) {
/* 6075 */         this.wasNullFlag = true;
/*      */         
/* 6077 */         return null;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6088 */       timestampValue = timestampValue.trim();
/*      */       
/* 6090 */       int length = timestampValue.length();
/*      */       
/* 6092 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */ 
/*      */       
/* 6096 */       synchronized (sessionCalendar) {
/* 6097 */         if (length > 0 && timestampValue.charAt(0) == '0' && (timestampValue.equals("0000-00-00") || timestampValue.equals("0000-00-00 00:00:00") || timestampValue.equals("00000000000000") || timestampValue.equals("0"))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6104 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/*      */             
/* 6106 */             this.wasNullFlag = true;
/*      */             
/* 6108 */             return null;
/* 6109 */           }  if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 6111 */             throw SQLError.createSQLException("Value '" + timestampValue + "' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6118 */           return fastTimestampCreate(null, 1, 1, 1, 0, 0, 0, 0);
/*      */         } 
/* 6120 */         if (this.fields[columnIndex - 1].getMysqlType() == 13) {
/*      */           
/* 6122 */           if (!this.useLegacyDatetimeCode) {
/* 6123 */             return TimeUtil.fastTimestampCreate(tz, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0);
/*      */           }
/*      */ 
/*      */           
/* 6127 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6137 */         if (timestampValue.endsWith(".")) {
/* 6138 */           timestampValue = timestampValue.substring(0, timestampValue.length() - 1);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6144 */         int year = 0;
/* 6145 */         int month = 0;
/* 6146 */         int day = 0;
/* 6147 */         int hour = 0;
/* 6148 */         int minutes = 0;
/* 6149 */         int seconds = 0;
/* 6150 */         int nanos = 0;
/*      */         
/* 6152 */         switch (length) {
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/* 6161 */             year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6162 */             month = Integer.parseInt(timestampValue.substring(5, 7));
/*      */             
/* 6164 */             day = Integer.parseInt(timestampValue.substring(8, 10));
/* 6165 */             hour = Integer.parseInt(timestampValue.substring(11, 13));
/*      */             
/* 6167 */             minutes = Integer.parseInt(timestampValue.substring(14, 16));
/*      */             
/* 6169 */             seconds = Integer.parseInt(timestampValue.substring(17, 19));
/*      */ 
/*      */             
/* 6172 */             nanos = 0;
/*      */             
/* 6174 */             if (length > 19) {
/* 6175 */               int decimalIndex = timestampValue.lastIndexOf('.');
/*      */               
/* 6177 */               if (decimalIndex != -1) {
/* 6178 */                 if (decimalIndex + 2 <= length) {
/* 6179 */                   nanos = Integer.parseInt(timestampValue.substring(decimalIndex + 1));
/*      */ 
/*      */                   
/* 6182 */                   int numDigits = length - decimalIndex + 1;
/*      */                   
/* 6184 */                   if (numDigits < 9) {
/* 6185 */                     int factor = (int)Math.pow(10.0D, (9 - numDigits));
/* 6186 */                     nanos *= factor;
/*      */                   }  break;
/*      */                 } 
/* 6189 */                 throw new IllegalArgumentException();
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 14:
/* 6203 */             year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6204 */             month = Integer.parseInt(timestampValue.substring(4, 6));
/*      */             
/* 6206 */             day = Integer.parseInt(timestampValue.substring(6, 8));
/* 6207 */             hour = Integer.parseInt(timestampValue.substring(8, 10));
/*      */             
/* 6209 */             minutes = Integer.parseInt(timestampValue.substring(10, 12));
/*      */             
/* 6211 */             seconds = Integer.parseInt(timestampValue.substring(12, 14));
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 12:
/* 6218 */             year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */             
/* 6220 */             if (year <= 69) {
/* 6221 */               year += 100;
/*      */             }
/*      */             
/* 6224 */             year += 1900;
/*      */             
/* 6226 */             month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */             
/* 6228 */             day = Integer.parseInt(timestampValue.substring(4, 6));
/* 6229 */             hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 6230 */             minutes = Integer.parseInt(timestampValue.substring(8, 10));
/*      */             
/* 6232 */             seconds = Integer.parseInt(timestampValue.substring(10, 12));
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 10:
/* 6239 */             if (this.fields[columnIndex - 1].getMysqlType() == 10 || timestampValue.indexOf("-") != -1) {
/*      */               
/* 6241 */               year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6242 */               month = Integer.parseInt(timestampValue.substring(5, 7));
/*      */               
/* 6244 */               day = Integer.parseInt(timestampValue.substring(8, 10));
/* 6245 */               hour = 0;
/* 6246 */               minutes = 0; break;
/*      */             } 
/* 6248 */             year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */             
/* 6250 */             if (year <= 69) {
/* 6251 */               year += 100;
/*      */             }
/*      */             
/* 6254 */             month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */             
/* 6256 */             day = Integer.parseInt(timestampValue.substring(4, 6));
/* 6257 */             hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 6258 */             minutes = Integer.parseInt(timestampValue.substring(8, 10));
/*      */ 
/*      */             
/* 6261 */             year += 1900;
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/* 6268 */             if (timestampValue.indexOf(":") != -1) {
/* 6269 */               hour = Integer.parseInt(timestampValue.substring(0, 2));
/*      */               
/* 6271 */               minutes = Integer.parseInt(timestampValue.substring(3, 5));
/*      */               
/* 6273 */               seconds = Integer.parseInt(timestampValue.substring(6, 8));
/*      */               
/* 6275 */               year = 1970;
/* 6276 */               month = 1;
/* 6277 */               day = 1;
/*      */               
/*      */               break;
/*      */             } 
/* 6281 */             year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6282 */             month = Integer.parseInt(timestampValue.substring(4, 6));
/*      */             
/* 6284 */             day = Integer.parseInt(timestampValue.substring(6, 8));
/*      */             
/* 6286 */             year -= 1900;
/* 6287 */             month--;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 6:
/* 6293 */             year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */             
/* 6295 */             if (year <= 69) {
/* 6296 */               year += 100;
/*      */             }
/*      */             
/* 6299 */             year += 1900;
/*      */             
/* 6301 */             month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */             
/* 6303 */             day = Integer.parseInt(timestampValue.substring(4, 6));
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/* 6309 */             year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */             
/* 6311 */             if (year <= 69) {
/* 6312 */               year += 100;
/*      */             }
/*      */             
/* 6315 */             year += 1900;
/*      */             
/* 6317 */             month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */ 
/*      */             
/* 6320 */             day = 1;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/* 6326 */             year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */             
/* 6328 */             if (year <= 69) {
/* 6329 */               year += 100;
/*      */             }
/*      */             
/* 6332 */             year += 1900;
/* 6333 */             month = 1;
/* 6334 */             day = 1;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 6340 */             throw new SQLException("Bad format for Timestamp '" + timestampValue + "' in column " + columnIndex + ".", "S1009");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6346 */         if (!this.useLegacyDatetimeCode) {
/* 6347 */           return TimeUtil.fastTimestampCreate(tz, year, month, day, hour, minutes, seconds, nanos);
/*      */         }
/*      */ 
/*      */         
/* 6351 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, seconds, nanos), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 6359 */     catch (Exception e) {
/* 6360 */       SQLException sqlEx = SQLError.createSQLException("Cannot convert value '" + timestampValue + "' from column " + columnIndex + " to TIMESTAMP.", "S1009", getExceptionInterceptor());
/*      */ 
/*      */       
/* 6363 */       sqlEx.initCause(e);
/*      */       
/* 6365 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Timestamp getTimestampFromBytes(int columnIndex, Calendar targetCalendar, byte[] timestampAsBytes, TimeZone tz, boolean rollForward) throws SQLException {
/* 6374 */     checkColumnBounds(columnIndex);
/*      */     
/*      */     try {
/* 6377 */       this.wasNullFlag = false;
/*      */       
/* 6379 */       if (timestampAsBytes == null) {
/* 6380 */         this.wasNullFlag = true;
/*      */         
/* 6382 */         return null;
/*      */       } 
/*      */       
/* 6385 */       int length = timestampAsBytes.length;
/*      */       
/* 6387 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/*      */ 
/*      */       
/* 6391 */       synchronized (sessionCalendar) {
/* 6392 */         boolean allZeroTimestamp = true;
/*      */         
/* 6394 */         boolean onlyTimePresent = (StringUtils.indexOf(timestampAsBytes, ':') != -1);
/*      */         
/* 6396 */         for (int i = 0; i < length; i++) {
/* 6397 */           byte b = timestampAsBytes[i];
/*      */           
/* 6399 */           if (b == 32 || b == 45 || b == 47) {
/* 6400 */             onlyTimePresent = false;
/*      */           }
/*      */           
/* 6403 */           if (b != 48 && b != 32 && b != 58 && b != 45 && b != 47 && b != 46) {
/*      */             
/* 6405 */             allZeroTimestamp = false;
/*      */             
/*      */             break;
/*      */           } 
/*      */         } 
/*      */         
/* 6411 */         if (!onlyTimePresent && allZeroTimestamp) {
/*      */           
/* 6413 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior())) {
/*      */             
/* 6415 */             this.wasNullFlag = true;
/*      */             
/* 6417 */             return null;
/* 6418 */           }  if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 6420 */             throw SQLError.createSQLException("Value '" + timestampAsBytes + "' can not be represented as java.sql.Timestamp", "S1009", getExceptionInterceptor());
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 6427 */           if (!this.useLegacyDatetimeCode) {
/* 6428 */             return TimeUtil.fastTimestampCreate(tz, 1, 1, 1, 0, 0, 0, 0);
/*      */           }
/*      */ 
/*      */           
/* 6432 */           return fastTimestampCreate(null, 1, 1, 1, 0, 0, 0, 0);
/* 6433 */         }  if (this.fields[columnIndex - 1].getMysqlType() == 13) {
/*      */           
/* 6435 */           if (!this.useLegacyDatetimeCode) {
/* 6436 */             return TimeUtil.fastTimestampCreate(tz, StringUtils.getInt(timestampAsBytes, 0, 4), 1, 1, 0, 0, 0, 0);
/*      */           }
/*      */ 
/*      */           
/* 6440 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, StringUtils.getInt(timestampAsBytes, 0, 4), 1, 1, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6448 */         if (timestampAsBytes[length - 1] == 46) {
/* 6449 */           length--;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 6454 */         int year = 0;
/* 6455 */         int month = 0;
/* 6456 */         int day = 0;
/* 6457 */         int hour = 0;
/* 6458 */         int minutes = 0;
/* 6459 */         int seconds = 0;
/* 6460 */         int nanos = 0;
/*      */         
/* 6462 */         switch (length) {
/*      */           case 19:
/*      */           case 20:
/*      */           case 21:
/*      */           case 22:
/*      */           case 23:
/*      */           case 24:
/*      */           case 25:
/*      */           case 26:
/* 6471 */             year = StringUtils.getInt(timestampAsBytes, 0, 4);
/* 6472 */             month = StringUtils.getInt(timestampAsBytes, 5, 7);
/* 6473 */             day = StringUtils.getInt(timestampAsBytes, 8, 10);
/* 6474 */             hour = StringUtils.getInt(timestampAsBytes, 11, 13);
/* 6475 */             minutes = StringUtils.getInt(timestampAsBytes, 14, 16);
/* 6476 */             seconds = StringUtils.getInt(timestampAsBytes, 17, 19);
/*      */             
/* 6478 */             nanos = 0;
/*      */             
/* 6480 */             if (length > 19) {
/* 6481 */               int decimalIndex = StringUtils.lastIndexOf(timestampAsBytes, '.');
/*      */               
/* 6483 */               if (decimalIndex != -1) {
/* 6484 */                 if (decimalIndex + 2 <= length) {
/* 6485 */                   nanos = StringUtils.getInt(timestampAsBytes, decimalIndex + 1, length); break;
/*      */                 } 
/* 6487 */                 throw new IllegalArgumentException();
/*      */               } 
/*      */             } 
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 14:
/* 6501 */             year = StringUtils.getInt(timestampAsBytes, 0, 4);
/* 6502 */             month = StringUtils.getInt(timestampAsBytes, 4, 6);
/* 6503 */             day = StringUtils.getInt(timestampAsBytes, 6, 8);
/* 6504 */             hour = StringUtils.getInt(timestampAsBytes, 8, 10);
/* 6505 */             minutes = StringUtils.getInt(timestampAsBytes, 10, 12);
/* 6506 */             seconds = StringUtils.getInt(timestampAsBytes, 12, 14);
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 12:
/* 6512 */             year = StringUtils.getInt(timestampAsBytes, 0, 2);
/*      */             
/* 6514 */             if (year <= 69) {
/* 6515 */               year += 100;
/*      */             }
/*      */             
/* 6518 */             year += 1900;
/*      */             
/* 6520 */             month = StringUtils.getInt(timestampAsBytes, 2, 4);
/* 6521 */             day = StringUtils.getInt(timestampAsBytes, 4, 6);
/* 6522 */             hour = StringUtils.getInt(timestampAsBytes, 6, 8);
/* 6523 */             minutes = StringUtils.getInt(timestampAsBytes, 8, 10);
/* 6524 */             seconds = StringUtils.getInt(timestampAsBytes, 10, 12);
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 10:
/* 6530 */             if (this.fields[columnIndex - 1].getMysqlType() == 10 || StringUtils.indexOf(timestampAsBytes, '-') != -1) {
/*      */               
/* 6532 */               year = StringUtils.getInt(timestampAsBytes, 0, 4);
/* 6533 */               month = StringUtils.getInt(timestampAsBytes, 5, 7);
/* 6534 */               day = StringUtils.getInt(timestampAsBytes, 8, 10);
/* 6535 */               hour = 0;
/* 6536 */               minutes = 0; break;
/*      */             } 
/* 6538 */             year = StringUtils.getInt(timestampAsBytes, 0, 2);
/*      */             
/* 6540 */             if (year <= 69) {
/* 6541 */               year += 100;
/*      */             }
/*      */             
/* 6544 */             month = StringUtils.getInt(timestampAsBytes, 2, 4);
/* 6545 */             day = StringUtils.getInt(timestampAsBytes, 4, 6);
/* 6546 */             hour = StringUtils.getInt(timestampAsBytes, 6, 8);
/* 6547 */             minutes = StringUtils.getInt(timestampAsBytes, 8, 10);
/*      */             
/* 6549 */             year += 1900;
/*      */             break;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           case 8:
/* 6556 */             if (StringUtils.indexOf(timestampAsBytes, ':') != -1) {
/* 6557 */               hour = StringUtils.getInt(timestampAsBytes, 0, 2);
/* 6558 */               minutes = StringUtils.getInt(timestampAsBytes, 3, 5);
/* 6559 */               seconds = StringUtils.getInt(timestampAsBytes, 6, 8);
/*      */               
/* 6561 */               year = 1970;
/* 6562 */               month = 1;
/* 6563 */               day = 1;
/*      */               
/*      */               break;
/*      */             } 
/*      */             
/* 6568 */             year = StringUtils.getInt(timestampAsBytes, 0, 4);
/* 6569 */             month = StringUtils.getInt(timestampAsBytes, 4, 6);
/* 6570 */             day = StringUtils.getInt(timestampAsBytes, 6, 8);
/*      */             
/* 6572 */             year -= 1900;
/* 6573 */             month--;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 6:
/* 6579 */             year = StringUtils.getInt(timestampAsBytes, 0, 2);
/*      */             
/* 6581 */             if (year <= 69) {
/* 6582 */               year += 100;
/*      */             }
/*      */             
/* 6585 */             year += 1900;
/*      */             
/* 6587 */             month = StringUtils.getInt(timestampAsBytes, 2, 4);
/* 6588 */             day = StringUtils.getInt(timestampAsBytes, 4, 6);
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 4:
/* 6594 */             year = StringUtils.getInt(timestampAsBytes, 0, 2);
/*      */             
/* 6596 */             if (year <= 69) {
/* 6597 */               year += 100;
/*      */             }
/*      */             
/* 6600 */             year += 1900;
/*      */             
/* 6602 */             month = StringUtils.getInt(timestampAsBytes, 2, 4);
/* 6603 */             day = 1;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           case 2:
/* 6609 */             year = StringUtils.getInt(timestampAsBytes, 0, 2);
/*      */             
/* 6611 */             if (year <= 69) {
/* 6612 */               year += 100;
/*      */             }
/*      */             
/* 6615 */             year += 1900;
/* 6616 */             month = 1;
/* 6617 */             day = 1;
/*      */             break;
/*      */ 
/*      */ 
/*      */           
/*      */           default:
/* 6623 */             throw new SQLException("Bad format for Timestamp '" + new String(timestampAsBytes) + "' in column " + columnIndex + ".", "S1009");
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 6629 */         if (!this.useLegacyDatetimeCode) {
/* 6630 */           return TimeUtil.fastTimestampCreate(tz, year, month, day, hour, minutes, seconds, nanos);
/*      */         }
/*      */ 
/*      */         
/* 6634 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, seconds, nanos), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 6642 */     catch (Exception e) {
/* 6643 */       SQLException sqlEx = SQLError.createSQLException("Cannot convert value '" + new String(timestampAsBytes) + "' from column " + columnIndex + " to TIMESTAMP.", "S1009", getExceptionInterceptor());
/*      */ 
/*      */       
/* 6646 */       sqlEx.initCause(e);
/*      */       
/* 6648 */       throw sqlEx;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Timestamp getTimestampInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward) throws SQLException {
/* 6669 */     if (this.isBinaryEncoded) {
/* 6670 */       return getNativeTimestamp(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */     
/* 6673 */     Timestamp tsVal = null;
/*      */     
/* 6675 */     if (!this.useFastDateParsing) {
/* 6676 */       String timestampValue = getStringInternal(columnIndex, false);
/*      */       
/* 6678 */       tsVal = getTimestampFromString(columnIndex, targetCalendar, timestampValue, tz, rollForward);
/*      */     }
/*      */     else {
/*      */       
/* 6682 */       checkClosed();
/* 6683 */       checkRowPos();
/* 6684 */       checkColumnBounds(columnIndex);
/*      */       
/* 6686 */       tsVal = this.thisRow.getTimestampFast(columnIndex - 1, targetCalendar, tz, rollForward, this.connection, this);
/*      */     } 
/*      */ 
/*      */     
/* 6690 */     if (tsVal == null) {
/* 6691 */       this.wasNullFlag = true;
/*      */     } else {
/* 6693 */       this.wasNullFlag = false;
/*      */     } 
/*      */     
/* 6696 */     return tsVal;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6710 */   public int getType() throws SQLException { return this.resultSetType; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int columnIndex) throws SQLException {
/* 6732 */     if (!this.isBinaryEncoded) {
/* 6733 */       checkRowPos();
/*      */       
/* 6735 */       return getBinaryStream(columnIndex);
/*      */     } 
/*      */     
/* 6738 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6755 */   public InputStream getUnicodeStream(String columnName) throws SQLException { return getUnicodeStream(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */   
/* 6759 */   public long getUpdateCount() { return this.updateCount; }
/*      */ 
/*      */ 
/*      */   
/* 6763 */   public long getUpdateID() { return this.updateId; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int colIndex) throws SQLException {
/* 6770 */     String val = getString(colIndex);
/*      */     
/* 6772 */     if (val == null) {
/* 6773 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 6777 */       return new URL(val);
/* 6778 */     } catch (MalformedURLException mfe) {
/* 6779 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String colName) throws SQLException {
/* 6789 */     String val = getString(colName);
/*      */     
/* 6791 */     if (val == null) {
/* 6792 */       return null;
/*      */     }
/*      */     
/*      */     try {
/* 6796 */       return new URL(val);
/* 6797 */     } catch (MalformedURLException mfe) {
/* 6798 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009", getExceptionInterceptor());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6825 */   public SQLWarning getWarnings() throws SQLException { return this.warningChain; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6840 */   public void insertRow() throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 6857 */     checkClosed();
/*      */     
/* 6859 */     boolean b = this.rowData.isAfterLast();
/*      */     
/* 6861 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 6878 */     checkClosed();
/*      */     
/* 6880 */     return this.rowData.isBeforeFirst();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 6896 */     checkClosed();
/*      */     
/* 6898 */     return this.rowData.isFirst();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 6917 */     checkClosed();
/*      */     
/* 6919 */     return this.rowData.isLast();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void issueConversionViaParsingWarning(String methodName, int columnIndex, Object value, Field fieldInfo, int[] typesWithNoParseConversion) throws SQLException {
/* 6931 */     StringBuffer originalQueryBuf = new StringBuffer();
/*      */     
/* 6933 */     if (this.owningStatement != null && this.owningStatement instanceof PreparedStatement) {
/*      */       
/* 6935 */       originalQueryBuf.append(Messages.getString("ResultSet.CostlyConversionCreatedFromQuery"));
/* 6936 */       originalQueryBuf.append(((PreparedStatement)this.owningStatement).originalSql);
/*      */       
/* 6938 */       originalQueryBuf.append("\n\n");
/*      */     } else {
/* 6940 */       originalQueryBuf.append(".");
/*      */     } 
/*      */     
/* 6943 */     StringBuffer convertibleTypesBuf = new StringBuffer();
/*      */     
/* 6945 */     for (int i = 0; i < typesWithNoParseConversion.length; i++) {
/* 6946 */       convertibleTypesBuf.append(MysqlDefs.typeToName(typesWithNoParseConversion[i]));
/* 6947 */       convertibleTypesBuf.append("\n");
/*      */     } 
/*      */     
/* 6950 */     String message = Messages.getString("ResultSet.CostlyConversion", new Object[] { methodName, new Integer(columnIndex + 1), fieldInfo.getOriginalName(), fieldInfo.getOriginalTableName(), originalQueryBuf.toString(), (value != null) ? value.getClass().getName() : ResultSetMetaData.getClassNameForJavaType(fieldInfo.getSQLType(), fieldInfo.isUnsigned(), fieldInfo.getMysqlType(), (fieldInfo.isBinary() || fieldInfo.isBlob()), fieldInfo.isOpaqueBinary()), MysqlDefs.typeToName(fieldInfo.getMysqlType()), convertibleTypesBuf.toString() });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6965 */     this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, message));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/* 6989 */     checkClosed();
/*      */     
/* 6991 */     boolean b = true;
/*      */     
/* 6993 */     if (this.rowData.size() == 0) {
/* 6994 */       b = false;
/*      */     } else {
/*      */       
/* 6997 */       if (this.onInsertRow) {
/* 6998 */         this.onInsertRow = false;
/*      */       }
/*      */       
/* 7001 */       if (this.doingUpdates) {
/* 7002 */         this.doingUpdates = false;
/*      */       }
/*      */       
/* 7005 */       if (this.thisRow != null) {
/* 7006 */         this.thisRow.closeOpenStreams();
/*      */       }
/*      */       
/* 7009 */       this.rowData.beforeLast();
/* 7010 */       this.thisRow = this.rowData.next();
/*      */     } 
/*      */     
/* 7013 */     setRowPositionValidity();
/*      */     
/* 7015 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7037 */   public void moveToCurrentRow() throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7058 */   public void moveToInsertRow() throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*      */     boolean b;
/* 7077 */     checkClosed();
/*      */     
/* 7079 */     if (this.onInsertRow) {
/* 7080 */       this.onInsertRow = false;
/*      */     }
/*      */     
/* 7083 */     if (this.doingUpdates) {
/* 7084 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 7089 */     if (!reallyResult()) {
/* 7090 */       throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7096 */     if (this.thisRow != null) {
/* 7097 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/* 7100 */     if (this.rowData.size() == 0) {
/* 7101 */       b = false;
/*      */     } else {
/* 7103 */       this.thisRow = this.rowData.next();
/*      */       
/* 7105 */       if (this.thisRow == null) {
/* 7106 */         b = false;
/*      */       } else {
/* 7108 */         clearWarnings();
/*      */         
/* 7110 */         b = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 7115 */     setRowPositionValidity();
/*      */     
/* 7117 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   private int parseIntAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException {
/* 7122 */     if (val == null) {
/* 7123 */       return 0;
/*      */     }
/*      */     
/* 7126 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 7128 */     if (this.jdbcCompliantTruncationForReads && (
/* 7129 */       valueAsDouble < -2.147483648E9D || valueAsDouble > 2.147483647E9D))
/*      */     {
/* 7131 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 7136 */     return (int)valueAsDouble;
/*      */   }
/*      */   
/*      */   private int getIntWithOverflowCheck(int columnIndex) throws SQLException {
/* 7140 */     int intValue = this.thisRow.getInt(columnIndex);
/*      */     
/* 7142 */     checkForIntegerTruncation(columnIndex, null, intValue);
/*      */ 
/*      */     
/* 7145 */     return intValue;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkForIntegerTruncation(int columnIndex, byte[] valueAsBytes, int intValue) throws SQLException {
/* 7151 */     if (this.jdbcCompliantTruncationForReads && (
/* 7152 */       intValue == Integer.MIN_VALUE || intValue == Integer.MAX_VALUE)) {
/* 7153 */       String valueAsString = null;
/*      */       
/* 7155 */       if (valueAsBytes == null) {
/* 7156 */         valueAsString = this.thisRow.getString(columnIndex, this.fields[columnIndex].getCharacterSet(), this.connection);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 7161 */       long valueAsLong = Long.parseLong((valueAsString == null) ? new String(valueAsBytes) : valueAsString);
/*      */ 
/*      */ 
/*      */       
/* 7165 */       if (valueAsLong < -2147483648L || valueAsLong > 2147483647L)
/*      */       {
/* 7167 */         throwRangeException((valueAsString == null) ? new String(valueAsBytes) : valueAsString, columnIndex + 1, 4);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long parseLongAsDouble(int columnIndexZeroBased, String val) throws NumberFormatException, SQLException {
/* 7177 */     if (val == null) {
/* 7178 */       return 0L;
/*      */     }
/*      */     
/* 7181 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 7183 */     if (this.jdbcCompliantTruncationForReads && (
/* 7184 */       valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D))
/*      */     {
/* 7186 */       throwRangeException(val, columnIndexZeroBased + 1, -5);
/*      */     }
/*      */ 
/*      */     
/* 7190 */     return (long)valueAsDouble;
/*      */   }
/*      */   
/*      */   private long getLongWithOverflowCheck(int columnIndexZeroBased, boolean doOverflowCheck) throws SQLException {
/* 7194 */     long longValue = this.thisRow.getLong(columnIndexZeroBased);
/*      */     
/* 7196 */     if (doOverflowCheck) {
/* 7197 */       checkForLongTruncation(columnIndexZeroBased, null, longValue);
/*      */     }
/*      */     
/* 7200 */     return longValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long parseLongWithOverflowCheck(int columnIndexZeroBased, byte[] valueAsBytes, String valueAsString, boolean doCheck) throws NumberFormatException, SQLException {
/* 7207 */     long longValue = 0L;
/*      */     
/* 7209 */     if (valueAsBytes == null && valueAsString == null) {
/* 7210 */       return 0L;
/*      */     }
/*      */     
/* 7213 */     if (valueAsBytes != null) {
/* 7214 */       longValue = StringUtils.getLong(valueAsBytes);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7224 */       valueAsString = valueAsString.trim();
/*      */       
/* 7226 */       longValue = Long.parseLong(valueAsString);
/*      */     } 
/*      */     
/* 7229 */     if (doCheck && this.jdbcCompliantTruncationForReads) {
/* 7230 */       checkForLongTruncation(columnIndexZeroBased, valueAsBytes, longValue);
/*      */     }
/*      */     
/* 7233 */     return longValue;
/*      */   }
/*      */   
/*      */   private void checkForLongTruncation(int columnIndexZeroBased, byte[] valueAsBytes, long longValue) throws SQLException {
/* 7237 */     if (longValue == Long.MIN_VALUE || longValue == Long.MAX_VALUE) {
/*      */       
/* 7239 */       String valueAsString = null;
/*      */       
/* 7241 */       if (valueAsBytes == null) {
/* 7242 */         valueAsString = this.thisRow.getString(columnIndexZeroBased, this.fields[columnIndexZeroBased].getCharacterSet(), this.connection);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 7247 */       double valueAsDouble = Double.parseDouble((valueAsString == null) ? new String(valueAsBytes) : valueAsString);
/*      */ 
/*      */ 
/*      */       
/* 7251 */       if (valueAsDouble < -9.223372036854776E18D || valueAsDouble > 9.223372036854776E18D)
/*      */       {
/* 7253 */         throwRangeException((valueAsString == null) ? new String(valueAsBytes) : valueAsString, columnIndexZeroBased + 1, -5);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private short parseShortAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException {
/* 7262 */     if (val == null) {
/* 7263 */       return 0;
/*      */     }
/*      */     
/* 7266 */     double valueAsDouble = Double.parseDouble(val);
/*      */     
/* 7268 */     if (this.jdbcCompliantTruncationForReads && (
/* 7269 */       valueAsDouble < -32768.0D || valueAsDouble > 32767.0D))
/*      */     {
/* 7271 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 5);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 7276 */     return (short)(int)valueAsDouble;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private short parseShortWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString) throws NumberFormatException, SQLException {
/* 7283 */     short shortValue = 0;
/*      */     
/* 7285 */     if (valueAsBytes == null && valueAsString == null) {
/* 7286 */       return 0;
/*      */     }
/*      */     
/* 7289 */     if (valueAsBytes != null) {
/* 7290 */       shortValue = StringUtils.getShort(valueAsBytes);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 7300 */       valueAsString = valueAsString.trim();
/*      */       
/* 7302 */       shortValue = Short.parseShort(valueAsString);
/*      */     } 
/*      */     
/* 7305 */     if (this.jdbcCompliantTruncationForReads && (
/* 7306 */       shortValue == Short.MIN_VALUE || shortValue == Short.MAX_VALUE)) {
/* 7307 */       long valueAsLong = Long.parseLong((valueAsString == null) ? new String(valueAsBytes) : valueAsString);
/*      */ 
/*      */ 
/*      */       
/* 7311 */       if (valueAsLong < -32768L || valueAsLong > 32767L)
/*      */       {
/* 7313 */         throwRangeException((valueAsString == null) ? new String(valueAsBytes) : valueAsString, columnIndex, 5);
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7320 */     return shortValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean prev() throws SQLException {
/* 7344 */     checkClosed();
/*      */     
/* 7346 */     int rowIndex = this.rowData.getCurrentRowNumber();
/*      */     
/* 7348 */     if (this.thisRow != null) {
/* 7349 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/* 7352 */     boolean b = true;
/*      */     
/* 7354 */     if (rowIndex - 1 >= 0) {
/* 7355 */       rowIndex--;
/* 7356 */       this.rowData.setCurrentRow(rowIndex);
/* 7357 */       this.thisRow = this.rowData.getAt(rowIndex);
/*      */       
/* 7359 */       b = true;
/* 7360 */     } else if (rowIndex - 1 == -1) {
/* 7361 */       rowIndex--;
/* 7362 */       this.rowData.setCurrentRow(rowIndex);
/* 7363 */       this.thisRow = null;
/*      */       
/* 7365 */       b = false;
/*      */     } else {
/* 7367 */       b = false;
/*      */     } 
/*      */     
/* 7370 */     setRowPositionValidity();
/*      */     
/* 7372 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/* 7394 */     if (this.onInsertRow) {
/* 7395 */       this.onInsertRow = false;
/*      */     }
/*      */     
/* 7398 */     if (this.doingUpdates) {
/* 7399 */       this.doingUpdates = false;
/*      */     }
/*      */     
/* 7402 */     return prev();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void realClose(boolean calledExplicitly) throws SQLException {
/* 7415 */     if (this.isClosed) {
/*      */       return;
/*      */     }
/*      */     
/*      */     try {
/* 7420 */       if (this.useUsageAdvisor)
/*      */       {
/*      */ 
/*      */         
/* 7424 */         if (!calledExplicitly) {
/* 7425 */           this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver")));
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7444 */         if (this.rowData instanceof RowDataStatic) {
/*      */ 
/*      */ 
/*      */           
/* 7448 */           if (this.rowData.size() > this.connection.getResultSetSizeThreshold())
/*      */           {
/* 7450 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Too_Large_Result_Set", new Object[] { new Integer(this.rowData.size()), new Integer(this.connection.getResultSetSizeThreshold()) })));
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 7478 */           if (!isLast() && !isAfterLast() && this.rowData.size() != 0)
/*      */           {
/* 7480 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set", new Object[] { new Integer(getRow()), new Integer(this.rowData.size()) })));
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7513 */         if (this.columnUsed.length > 0 && !this.rowData.wasEmpty()) {
/* 7514 */           StringBuffer buf = new StringBuffer(Messages.getString("ResultSet.The_following_columns_were_never_referenced"));
/*      */ 
/*      */ 
/*      */           
/* 7518 */           boolean issueWarn = false;
/*      */           
/* 7520 */           for (int i = 0; i < this.columnUsed.length; i++) {
/* 7521 */             if (!this.columnUsed[i]) {
/* 7522 */               if (!issueWarn) {
/* 7523 */                 issueWarn = true;
/*      */               } else {
/* 7525 */                 buf.append(", ");
/*      */               } 
/*      */               
/* 7528 */               buf.append(this.fields[i].getFullName());
/*      */             } 
/*      */           } 
/*      */           
/* 7532 */           if (issueWarn) {
/* 7533 */             this.eventSink.consumeEvent(new ProfilerEvent((byte)0, "", (this.owningStatement == null) ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, (this.owningStatement == null) ? -1 : this.owningStatement.getId(), 0, System.currentTimeMillis(), 0L, Constants.MILLIS_I18N, null, this.pointOfOrigin, buf.toString()));
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/* 7547 */       if (this.owningStatement != null && calledExplicitly) {
/* 7548 */         this.owningStatement.removeOpenResultSet(this);
/*      */       }
/*      */       
/* 7551 */       SQLException exceptionDuringClose = null;
/*      */       
/* 7553 */       if (this.rowData != null) {
/*      */         try {
/* 7555 */           this.rowData.close();
/* 7556 */         } catch (SQLException sqlEx) {
/* 7557 */           exceptionDuringClose = sqlEx;
/*      */         } 
/*      */       }
/*      */       
/* 7561 */       if (this.statementUsedForFetchingRows != null) {
/*      */         try {
/* 7563 */           this.statementUsedForFetchingRows.realClose(true, false);
/* 7564 */         } catch (SQLException sqlEx) {
/* 7565 */           if (exceptionDuringClose != null) {
/* 7566 */             exceptionDuringClose.setNextException(sqlEx);
/*      */           } else {
/* 7568 */             exceptionDuringClose = sqlEx;
/*      */           } 
/*      */         } 
/*      */       }
/*      */       
/* 7573 */       this.rowData = null;
/* 7574 */       this.defaultTimeZone = null;
/* 7575 */       this.fields = null;
/* 7576 */       this.columnLabelToIndex = null;
/* 7577 */       this.fullColumnNameToIndex = null;
/* 7578 */       this.columnToIndexCache = null;
/* 7579 */       this.eventSink = null;
/* 7580 */       this.warningChain = null;
/*      */       
/* 7582 */       if (!this.retainOwningStatement) {
/* 7583 */         this.owningStatement = null;
/*      */       }
/*      */       
/* 7586 */       this.catalog = null;
/* 7587 */       this.serverInfo = null;
/* 7588 */       this.thisRow = null;
/* 7589 */       this.fastDateCal = null;
/* 7590 */       this.connection = null;
/*      */       
/* 7592 */       this.isClosed = true;
/*      */       
/* 7594 */       if (exceptionDuringClose != null) {
/* 7595 */         throw exceptionDuringClose;
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean reallyResult() {
/* 7601 */     if (this.rowData != null) {
/* 7602 */       return true;
/*      */     }
/*      */     
/* 7605 */     return this.reallyResult;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7629 */   public void refreshRow() throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int rows) throws SQLException {
/* 7659 */     checkClosed();
/*      */     
/* 7661 */     if (this.rowData.size() == 0) {
/* 7662 */       setRowPositionValidity();
/*      */       
/* 7664 */       return false;
/*      */     } 
/*      */     
/* 7667 */     if (this.thisRow != null) {
/* 7668 */       this.thisRow.closeOpenStreams();
/*      */     }
/*      */     
/* 7671 */     this.rowData.moveRowRelative(rows);
/* 7672 */     this.thisRow = this.rowData.getAt(this.rowData.getCurrentRowNumber());
/*      */     
/* 7674 */     setRowPositionValidity();
/*      */     
/* 7676 */     return (!this.rowData.isAfterLast() && !this.rowData.isBeforeFirst());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7695 */   public boolean rowDeleted() throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7713 */   public boolean rowInserted() throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7731 */   public boolean rowUpdated() throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7739 */   protected void setBinaryEncoded() { this.isBinaryEncoded = true; }
/*      */ 
/*      */ 
/*      */   
/* 7743 */   private void setDefaultTimeZone(TimeZone defaultTimeZone) { this.defaultTimeZone = defaultTimeZone; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int direction) throws SQLException {
/* 7762 */     if (direction != 1000 && direction != 1001 && direction != 1002)
/*      */     {
/* 7764 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7770 */     this.fetchDirection = direction;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int rows) throws SQLException {
/* 7790 */     if (rows < 0) {
/* 7791 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009", getExceptionInterceptor());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 7797 */     this.fetchSize = rows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7808 */   public void setFirstCharOfQuery(char c) { this.firstCharOfQuery = c; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7819 */   protected void setNextResultSet(ResultSetInternalMethods nextResultSet) { this.nextResultSet = nextResultSet; }
/*      */ 
/*      */ 
/*      */   
/* 7823 */   public void setOwningStatement(StatementImpl owningStatement) { this.owningStatement = owningStatement; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7833 */   protected void setResultSetConcurrency(int concurrencyFlag) { this.resultSetConcurrency = concurrencyFlag; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7844 */   protected void setResultSetType(int typeFlag) { this.resultSetType = typeFlag; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7854 */   protected void setServerInfo(String info) { this.serverInfo = info; }
/*      */ 
/*      */ 
/*      */   
/* 7858 */   public void setStatementUsedForFetchingRows(PreparedStatement stmt) { this.statementUsedForFetchingRows = stmt; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7866 */   public void setWrapperStatement(Statement wrapperStatement) { this.wrapperStatement = wrapperStatement; }
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwRangeException(String valueAsString, int columnIndex, int jdbcType) throws SQLException {
/* 7871 */     String datatype = null;
/*      */     
/* 7873 */     switch (jdbcType)
/*      */     { case -6:
/* 7875 */         datatype = "TINYINT";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 7902 */         throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 5: datatype = "SMALLINT"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 4: datatype = "INTEGER"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case -5: datatype = "BIGINT"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 7: datatype = "REAL"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 6: datatype = "FLOAT"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 8: datatype = "DOUBLE"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());case 3: datatype = "DECIMAL"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor()); }  datatype = " (JDBC type '" + jdbcType + "')"; throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003", getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/* 7913 */     if (this.reallyResult) {
/* 7914 */       return super.toString();
/*      */     }
/*      */     
/* 7917 */     return "Result set representing update count of " + this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7924 */   public void updateArray(int arg0, Array arg1) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7931 */   public void updateArray(String arg0, Array arg1) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7955 */   public void updateAsciiStream(int columnIndex, InputStream x, int length) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7977 */   public void updateAsciiStream(String columnName, InputStream x, int length) throws SQLException { updateAsciiStream(findColumn(columnName), x, length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 7998 */   public void updateBigDecimal(int columnIndex, BigDecimal x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8017 */   public void updateBigDecimal(String columnName, BigDecimal x) throws SQLException { updateBigDecimal(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8041 */   public void updateBinaryStream(int columnIndex, InputStream x, int length) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8063 */   public void updateBinaryStream(String columnName, InputStream x, int length) throws SQLException { updateBinaryStream(findColumn(columnName), x, length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8070 */   public void updateBlob(int arg0, Blob arg1) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8077 */   public void updateBlob(String arg0, Blob arg1) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8097 */   public void updateBoolean(int columnIndex, boolean x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8115 */   public void updateBoolean(String columnName, boolean x) throws SQLException { updateBoolean(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8135 */   public void updateByte(int columnIndex, byte x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8153 */   public void updateByte(String columnName, byte x) throws SQLException { updateByte(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8173 */   public void updateBytes(int columnIndex, byte[] x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8191 */   public void updateBytes(String columnName, byte[] x) throws SQLException { updateBytes(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8215 */   public void updateCharacterStream(int columnIndex, Reader x, int length) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8237 */   public void updateCharacterStream(String columnName, Reader reader, int length) throws SQLException { updateCharacterStream(findColumn(columnName), reader, length); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8244 */   public void updateClob(int arg0, Clob arg1) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8252 */   public void updateClob(String columnName, Clob clob) throws SQLException { updateClob(findColumn(columnName), clob); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8273 */   public void updateDate(int columnIndex, Date x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8292 */   public void updateDate(String columnName, Date x) throws SQLException { updateDate(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8312 */   public void updateDouble(int columnIndex, double x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8330 */   public void updateDouble(String columnName, double x) throws SQLException { updateDouble(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8350 */   public void updateFloat(int columnIndex, float x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8368 */   public void updateFloat(String columnName, float x) throws SQLException { updateFloat(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8388 */   public void updateInt(int columnIndex, int x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8406 */   public void updateInt(String columnName, int x) throws SQLException { updateInt(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8426 */   public void updateLong(int columnIndex, long x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8444 */   public void updateLong(String columnName, long x) throws SQLException { updateLong(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8462 */   public void updateNull(int columnIndex) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8478 */   public void updateNull(String columnName) throws SQLException { updateNull(findColumn(columnName)); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8498 */   public void updateObject(int columnIndex, Object x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8523 */   public void updateObject(int columnIndex, Object x, int scale) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8541 */   public void updateObject(String columnName, Object x) throws SQLException { updateObject(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8564 */   public void updateObject(String columnName, Object x, int scale) throws SQLException { updateObject(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8571 */   public void updateRef(int arg0, Ref arg1) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8578 */   public void updateRef(String arg0, Ref arg1) throws SQLException { throw SQLError.notImplemented(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8592 */   public void updateRow() throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8612 */   public void updateShort(int columnIndex, short x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8630 */   public void updateShort(String columnName, short x) throws SQLException { updateShort(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8650 */   public void updateString(int columnIndex, String x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8668 */   public void updateString(String columnName, String x) throws SQLException { updateString(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8689 */   public void updateTime(int columnIndex, Time x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8708 */   public void updateTime(String columnName, Time x) throws SQLException { updateTime(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8730 */   public void updateTimestamp(int columnIndex, Timestamp x) throws SQLException { throw new NotUpdatable(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8749 */   public void updateTimestamp(String columnName, Timestamp x) throws SQLException { updateTimestamp(findColumn(columnName), x); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 8764 */   public boolean wasNull() throws SQLException { return this.wasNullFlag; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Calendar getGmtCalendar() {
/* 8771 */     if (this.gmtCalendar == null) {
/* 8772 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */     
/* 8775 */     return this.gmtCalendar;
/*      */   }
/*      */ 
/*      */   
/* 8779 */   protected ExceptionInterceptor getExceptionInterceptor() { return this.exceptionInterceptor; }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/ResultSetImpl.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */