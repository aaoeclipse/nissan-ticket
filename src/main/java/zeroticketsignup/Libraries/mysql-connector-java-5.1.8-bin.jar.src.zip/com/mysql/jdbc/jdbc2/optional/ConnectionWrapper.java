/*      */ package com.mysql.jdbc.jdbc2.optional;
/*      */ 
/*      */ import com.mysql.jdbc.Connection;
/*      */ import com.mysql.jdbc.ExceptionInterceptor;
/*      */ import com.mysql.jdbc.Extension;
/*      */ import com.mysql.jdbc.SQLError;
/*      */ import com.mysql.jdbc.Util;
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.util.Map;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ConnectionWrapper
/*      */   extends WrapperBase
/*      */   implements Connection
/*      */ {
/*   65 */   protected Connection mc = null;
/*      */   
/*   67 */   private String invalidHandleStr = "Logical handle no longer valid";
/*      */   
/*      */   private boolean closed;
/*      */   
/*      */   private boolean isForXa;
/*      */   
/*      */   private static final Constructor JDBC_4_CONNECTION_WRAPPER_CTOR;
/*      */   
/*      */   static  {
/*   76 */     if (Util.isJdbc4()) {
/*      */       try {
/*   78 */         JDBC_4_CONNECTION_WRAPPER_CTOR = Class.forName("com.mysql.jdbc.jdbc2.optional.JDBC4ConnectionWrapper").getConstructor(new Class[] { MysqlPooledConnection.class, Connection.class, boolean.class });
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*   83 */       catch (SecurityException e) {
/*   84 */         throw new RuntimeException(e);
/*   85 */       } catch (NoSuchMethodException e) {
/*   86 */         throw new RuntimeException(e);
/*   87 */       } catch (ClassNotFoundException e) {
/*   88 */         throw new RuntimeException(e);
/*      */       } 
/*      */     } else {
/*   91 */       JDBC_4_CONNECTION_WRAPPER_CTOR = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected static ConnectionWrapper getInstance(MysqlPooledConnection mysqlPooledConnection, Connection mysqlConnection, boolean forXa) throws SQLException {
/*   98 */     if (!Util.isJdbc4()) {
/*   99 */       return new ConnectionWrapper(mysqlPooledConnection, mysqlConnection, forXa);
/*      */     }
/*      */ 
/*      */     
/*  103 */     return (ConnectionWrapper)Util.handleNewInstance(JDBC_4_CONNECTION_WRAPPER_CTOR, new Object[] { mysqlPooledConnection, mysqlConnection, Boolean.valueOf(forXa) }, mysqlPooledConnection.getExceptionInterceptor());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ConnectionWrapper(MysqlPooledConnection mysqlPooledConnection, Connection mysqlConnection, boolean forXa) throws SQLException {
/*  122 */     super(mysqlPooledConnection);
/*      */     
/*  124 */     this.mc = mysqlConnection;
/*  125 */     this.closed = false;
/*  126 */     this.isForXa = forXa;
/*      */     
/*  128 */     if (this.isForXa) {
/*  129 */       setInGlobalTx(false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoCommit(boolean autoCommit) throws SQLException {
/*  140 */     checkClosed();
/*      */     
/*  142 */     if (autoCommit && isInGlobalTx()) {
/*  143 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  150 */       this.mc.setAutoCommit(autoCommit);
/*  151 */     } catch (SQLException sqlException) {
/*  152 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoCommit() throws SQLException {
/*  163 */     checkClosed();
/*      */     
/*      */     try {
/*  166 */       return this.mc.getAutoCommit();
/*  167 */     } catch (SQLException sqlException) {
/*  168 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  171 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCatalog(String catalog) throws SQLException {
/*  181 */     checkClosed();
/*      */     
/*      */     try {
/*  184 */       this.mc.setCatalog(catalog);
/*  185 */     } catch (SQLException sqlException) {
/*  186 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCatalog() throws SQLException {
/*  200 */     checkClosed();
/*      */     
/*      */     try {
/*  203 */       return this.mc.getCatalog();
/*  204 */     } catch (SQLException sqlException) {
/*  205 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  208 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  218 */   public boolean isClosed() throws SQLException { return (this.closed || this.mc.isClosed()); }
/*      */ 
/*      */ 
/*      */   
/*  222 */   public boolean isMasterConnection() { return this.mc.isMasterConnection(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setHoldability(int arg0) throws SQLException {
/*  229 */     checkClosed();
/*      */     
/*      */     try {
/*  232 */       this.mc.setHoldability(arg0);
/*  233 */     } catch (SQLException sqlException) {
/*  234 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHoldability() throws SQLException {
/*  242 */     checkClosed();
/*      */     
/*      */     try {
/*  245 */       return this.mc.getHoldability();
/*  246 */     } catch (SQLException sqlException) {
/*  247 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  250 */       return 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  260 */   public long getIdleFor() { return this.mc.getIdleFor(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DatabaseMetaData getMetaData() throws SQLException {
/*  273 */     checkClosed();
/*      */     
/*      */     try {
/*  276 */       return this.mc.getMetaData();
/*  277 */     } catch (SQLException sqlException) {
/*  278 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  281 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReadOnly(boolean readOnly) throws SQLException {
/*  291 */     checkClosed();
/*      */     
/*      */     try {
/*  294 */       this.mc.setReadOnly(readOnly);
/*  295 */     } catch (SQLException sqlException) {
/*  296 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadOnly() throws SQLException {
/*  307 */     checkClosed();
/*      */     
/*      */     try {
/*  310 */       return this.mc.isReadOnly();
/*  311 */     } catch (SQLException sqlException) {
/*  312 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  315 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Savepoint setSavepoint() throws SQLException {
/*  322 */     checkClosed();
/*      */     
/*  324 */     if (isInGlobalTx()) {
/*  325 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  332 */       return this.mc.setSavepoint();
/*  333 */     } catch (SQLException sqlException) {
/*  334 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  337 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Savepoint setSavepoint(String arg0) throws SQLException {
/*  344 */     checkClosed();
/*      */     
/*  346 */     if (isInGlobalTx()) {
/*  347 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  354 */       return this.mc.setSavepoint(arg0);
/*  355 */     } catch (SQLException sqlException) {
/*  356 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  359 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTransactionIsolation(int level) throws SQLException {
/*  369 */     checkClosed();
/*      */     
/*      */     try {
/*  372 */       this.mc.setTransactionIsolation(level);
/*  373 */     } catch (SQLException sqlException) {
/*  374 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTransactionIsolation() throws SQLException {
/*  385 */     checkClosed();
/*      */     
/*      */     try {
/*  388 */       return this.mc.getTransactionIsolation();
/*  389 */     } catch (SQLException sqlException) {
/*  390 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  393 */       return 4;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTypeMap(Map map) throws SQLException {
/*  404 */     checkClosed();
/*      */     
/*      */     try {
/*  407 */       this.mc.setTypeMap(map);
/*  408 */     } catch (SQLException sqlException) {
/*  409 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Map getTypeMap() throws SQLException {
/*  420 */     checkClosed();
/*      */     
/*      */     try {
/*  423 */       return this.mc.getTypeMap();
/*  424 */     } catch (SQLException sqlException) {
/*  425 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  428 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/*  438 */     checkClosed();
/*      */     
/*      */     try {
/*  441 */       return this.mc.getWarnings();
/*  442 */     } catch (SQLException sqlException) {
/*  443 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  446 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/*  457 */     checkClosed();
/*      */     
/*      */     try {
/*  460 */       this.mc.clearWarnings();
/*  461 */     } catch (SQLException sqlException) {
/*  462 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  477 */   public void close() throws SQLException { close(true); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void commit() throws SQLException {
/*  488 */     checkClosed();
/*      */     
/*  490 */     if (isInGlobalTx()) {
/*  491 */       throw SQLError.createSQLException("Can't call commit() on an XAConnection associated with a global transaction", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  499 */       this.mc.commit();
/*  500 */     } catch (SQLException sqlException) {
/*  501 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement() throws SQLException {
/*  512 */     checkClosed();
/*      */     
/*      */     try {
/*  515 */       return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement());
/*      */     }
/*  517 */     catch (SQLException sqlException) {
/*  518 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  521 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement(int resultSetType, int resultSetConcurrency) throws SQLException {
/*  532 */     checkClosed();
/*      */     
/*      */     try {
/*  535 */       return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement(resultSetType, resultSetConcurrency));
/*      */     }
/*  537 */     catch (SQLException sqlException) {
/*  538 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  541 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement createStatement(int arg0, int arg1, int arg2) throws SQLException {
/*  549 */     checkClosed();
/*      */     
/*      */     try {
/*  552 */       return StatementWrapper.getInstance(this, this.pooledConnection, this.mc.createStatement(arg0, arg1, arg2));
/*      */     }
/*  554 */     catch (SQLException sqlException) {
/*  555 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  558 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String nativeSQL(String sql) throws SQLException {
/*  568 */     checkClosed();
/*      */     
/*      */     try {
/*  571 */       return this.mc.nativeSQL(sql);
/*  572 */     } catch (SQLException sqlException) {
/*  573 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  576 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String sql) throws SQLException {
/*  587 */     checkClosed();
/*      */     
/*      */     try {
/*  590 */       return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(sql));
/*      */     }
/*  592 */     catch (SQLException sqlException) {
/*  593 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  596 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  607 */     checkClosed();
/*      */     
/*      */     try {
/*  610 */       return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(sql, resultSetType, resultSetConcurrency));
/*      */     }
/*  612 */     catch (SQLException sqlException) {
/*  613 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  616 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement prepareCall(String arg0, int arg1, int arg2, int arg3) throws SQLException {
/*  624 */     checkClosed();
/*      */     
/*      */     try {
/*  627 */       return CallableStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareCall(arg0, arg1, arg2, arg3));
/*      */     }
/*  629 */     catch (SQLException sqlException) {
/*  630 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  633 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepare(String sql) throws SQLException {
/*  638 */     checkClosed();
/*      */     
/*      */     try {
/*  641 */       return new PreparedStatementWrapper(this, this.pooledConnection, this.mc.clientPrepareStatement(sql));
/*      */     }
/*  643 */     catch (SQLException sqlException) {
/*  644 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  647 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepare(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  652 */     checkClosed();
/*      */     
/*      */     try {
/*  655 */       return new PreparedStatementWrapper(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     
/*      */     }
/*  658 */     catch (SQLException sqlException) {
/*  659 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  662 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql) throws SQLException {
/*  673 */     checkClosed();
/*      */     
/*      */     try {
/*  676 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(sql));
/*      */     }
/*  678 */     catch (SQLException sqlException) {
/*  679 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  682 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*  693 */     checkClosed();
/*      */     
/*      */     try {
/*  696 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     
/*      */     }
/*  699 */     catch (SQLException sqlException) {
/*  700 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  703 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, int arg1, int arg2, int arg3) throws SQLException {
/*  711 */     checkClosed();
/*      */     
/*      */     try {
/*  714 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1, arg2, arg3));
/*      */     }
/*  716 */     catch (SQLException sqlException) {
/*  717 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  720 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, int arg1) throws SQLException {
/*  728 */     checkClosed();
/*      */     
/*      */     try {
/*  731 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1));
/*      */     }
/*  733 */     catch (SQLException sqlException) {
/*  734 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  737 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, int[] arg1) throws SQLException {
/*  745 */     checkClosed();
/*      */     
/*      */     try {
/*  748 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1));
/*      */     }
/*  750 */     catch (SQLException sqlException) {
/*  751 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  754 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement prepareStatement(String arg0, String[] arg1) throws SQLException {
/*  762 */     checkClosed();
/*      */     
/*      */     try {
/*  765 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.prepareStatement(arg0, arg1));
/*      */     }
/*  767 */     catch (SQLException sqlException) {
/*  768 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  771 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void releaseSavepoint(Savepoint arg0) throws SQLException {
/*  778 */     checkClosed();
/*      */     
/*      */     try {
/*  781 */       this.mc.releaseSavepoint(arg0);
/*  782 */     } catch (SQLException sqlException) {
/*  783 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback() throws SQLException {
/*  794 */     checkClosed();
/*      */     
/*  796 */     if (isInGlobalTx()) {
/*  797 */       throw SQLError.createSQLException("Can't call rollback() on an XAConnection associated with a global transaction", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  805 */       this.mc.rollback();
/*  806 */     } catch (SQLException sqlException) {
/*  807 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback(Savepoint arg0) throws SQLException {
/*  815 */     checkClosed();
/*      */     
/*  817 */     if (isInGlobalTx()) {
/*  818 */       throw SQLError.createSQLException("Can't call rollback() on an XAConnection associated with a global transaction", "2D000", 1401, this.exceptionInterceptor);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  826 */       this.mc.rollback(arg0);
/*  827 */     } catch (SQLException sqlException) {
/*  828 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */   
/*      */   public boolean isSameResource(Connection c) {
/*  833 */     if (c instanceof ConnectionWrapper)
/*  834 */       return this.mc.isSameResource(((ConnectionWrapper)c).mc); 
/*  835 */     if (c instanceof Connection) {
/*  836 */       return this.mc.isSameResource(c);
/*      */     }
/*      */     
/*  839 */     return false;
/*      */   }
/*      */   
/*      */   protected void close(boolean fireClosedEvent) throws SQLException {
/*  843 */     synchronized (this.pooledConnection) {
/*  844 */       if (this.closed) {
/*      */         return;
/*      */       }
/*      */       
/*  848 */       if (!isInGlobalTx() && this.mc.getRollbackOnPooledClose() && !getAutoCommit())
/*      */       {
/*  850 */         rollback();
/*      */       }
/*      */       
/*  853 */       if (fireClosedEvent) {
/*  854 */         this.pooledConnection.callConnectionEventListeners(2, null);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  863 */       this.closed = true;
/*      */     } 
/*      */   }
/*      */   
/*      */   protected void checkClosed() throws SQLException {
/*  868 */     if (this.closed) {
/*  869 */       throw SQLError.createSQLException(this.invalidHandleStr, this.exceptionInterceptor);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  874 */   public boolean isInGlobalTx() { return this.mc.isInGlobalTx(); }
/*      */ 
/*      */ 
/*      */   
/*  878 */   public void setInGlobalTx(boolean flag) { this.mc.setInGlobalTx(flag); }
/*      */ 
/*      */   
/*      */   public void ping() throws SQLException {
/*  882 */     if (this.mc != null) {
/*  883 */       this.mc.ping();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void changeUser(String userName, String newPassword) throws SQLException {
/*  889 */     checkClosed();
/*      */     
/*      */     try {
/*  892 */       this.mc.changeUser(userName, newPassword);
/*  893 */     } catch (SQLException sqlException) {
/*  894 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*  899 */   public void clearHasTriedMaster() { this.mc.clearHasTriedMaster(); }
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql) throws SQLException {
/*  904 */     checkClosed();
/*      */     
/*      */     try {
/*  907 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql));
/*      */     }
/*  909 */     catch (SQLException sqlException) {
/*  910 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  913 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     try {
/*  919 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyIndex));
/*      */     }
/*  921 */     catch (SQLException sqlException) {
/*  922 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  925 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     try {
/*  931 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     
/*      */     }
/*  934 */     catch (SQLException sqlException) {
/*  935 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  938 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     try {
/*  945 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
/*      */     
/*      */     }
/*  948 */     catch (SQLException sqlException) {
/*  949 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  952 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     try {
/*  958 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyIndexes));
/*      */     }
/*  960 */     catch (SQLException sqlException) {
/*  961 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  964 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     try {
/*  970 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.clientPrepareStatement(sql, autoGenKeyColNames));
/*      */     }
/*  972 */     catch (SQLException sqlException) {
/*  973 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/*  976 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*  980 */   public int getActiveStatementCount() { return this.mc.getActiveStatementCount(); }
/*      */ 
/*      */ 
/*      */   
/*  984 */   public Log getLog() throws SQLException { return this.mc.getLog(); }
/*      */ 
/*      */ 
/*      */   
/*  988 */   public String getServerCharacterEncoding() { return this.mc.getServerCharacterEncoding(); }
/*      */ 
/*      */ 
/*      */   
/*  992 */   public TimeZone getServerTimezoneTZ() { return this.mc.getServerTimezoneTZ(); }
/*      */ 
/*      */ 
/*      */   
/*  996 */   public String getStatementComment() { return this.mc.getStatementComment(); }
/*      */ 
/*      */ 
/*      */   
/* 1000 */   public boolean hasTriedMaster() { return this.mc.hasTriedMaster(); }
/*      */ 
/*      */ 
/*      */   
/* 1004 */   public boolean isAbonormallyLongQuery(long millisOrNanos) { return this.mc.isAbonormallyLongQuery(millisOrNanos); }
/*      */ 
/*      */ 
/*      */   
/* 1008 */   public boolean isNoBackslashEscapesSet() { return this.mc.isNoBackslashEscapesSet(); }
/*      */ 
/*      */ 
/*      */   
/* 1012 */   public boolean lowerCaseTableNames() { return this.mc.lowerCaseTableNames(); }
/*      */ 
/*      */ 
/*      */   
/* 1016 */   public boolean parserKnowsUnicode() { return this.mc.parserKnowsUnicode(); }
/*      */ 
/*      */ 
/*      */   
/* 1020 */   public void reportQueryTime(long millisOrNanos) { this.mc.reportQueryTime(millisOrNanos); }
/*      */ 
/*      */   
/*      */   public void resetServerState() throws SQLException {
/* 1024 */     checkClosed();
/*      */     
/*      */     try {
/* 1027 */       this.mc.resetServerState();
/* 1028 */     } catch (SQLException sqlException) {
/* 1029 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql) throws SQLException {
/* 1035 */     checkClosed();
/*      */     
/*      */     try {
/* 1038 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql));
/*      */     }
/* 1040 */     catch (SQLException sqlException) {
/* 1041 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1044 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex) throws SQLException {
/*      */     try {
/* 1050 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyIndex));
/*      */     }
/* 1052 */     catch (SQLException sqlException) {
/* 1053 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1056 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency) throws SQLException {
/*      */     try {
/* 1062 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*      */     
/*      */     }
/* 1065 */     catch (SQLException sqlException) {
/* 1066 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1069 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability) throws SQLException {
/*      */     try {
/* 1076 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
/*      */     
/*      */     }
/* 1079 */     catch (SQLException sqlException) {
/* 1080 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1083 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes) throws SQLException {
/*      */     try {
/* 1089 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyIndexes));
/*      */     }
/* 1091 */     catch (SQLException sqlException) {
/* 1092 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1095 */       return null;
/*      */     } 
/*      */   }
/*      */   
/*      */   public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames) throws SQLException {
/*      */     try {
/* 1101 */       return PreparedStatementWrapper.getInstance(this, this.pooledConnection, this.mc.serverPrepareStatement(sql, autoGenKeyColNames));
/*      */     }
/* 1103 */     catch (SQLException sqlException) {
/* 1104 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1107 */       return null;
/*      */     } 
/*      */   }
/*      */   
/* 1111 */   public void setFailedOver(boolean flag) { this.mc.setFailedOver(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1116 */   public void setPreferSlaveDuringFailover(boolean flag) { this.mc.setPreferSlaveDuringFailover(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1120 */   public void setStatementComment(String comment) { this.mc.setStatementComment(comment); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void shutdownServer() throws SQLException {
/* 1125 */     checkClosed();
/*      */     
/*      */     try {
/* 1128 */       this.mc.shutdownServer();
/* 1129 */     } catch (SQLException sqlException) {
/* 1130 */       checkAndFireConnectionError(sqlException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1136 */   public boolean supportsIsolationLevel() { return this.mc.supportsIsolationLevel(); }
/*      */ 
/*      */ 
/*      */   
/* 1140 */   public boolean supportsQuotedIdentifiers() { return this.mc.supportsQuotedIdentifiers(); }
/*      */ 
/*      */ 
/*      */   
/* 1144 */   public boolean supportsTransactions() { return this.mc.supportsTransactions(); }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException {
/* 1149 */     checkClosed();
/*      */     
/*      */     try {
/* 1152 */       return this.mc.versionMeetsMinimum(major, minor, subminor);
/* 1153 */     } catch (SQLException sqlException) {
/* 1154 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1157 */       return false;
/*      */     } 
/*      */   }
/*      */   public String exposeAsXml() throws SQLException {
/* 1161 */     checkClosed();
/*      */     
/*      */     try {
/* 1164 */       return this.mc.exposeAsXml();
/* 1165 */     } catch (SQLException sqlException) {
/* 1166 */       checkAndFireConnectionError(sqlException);
/*      */ 
/*      */       
/* 1169 */       return null;
/*      */     } 
/*      */   }
/*      */   
/* 1173 */   public boolean getAllowLoadLocalInfile() { return this.mc.getAllowLoadLocalInfile(); }
/*      */ 
/*      */ 
/*      */   
/* 1177 */   public boolean getAllowMultiQueries() { return this.mc.getAllowMultiQueries(); }
/*      */ 
/*      */ 
/*      */   
/* 1181 */   public boolean getAllowNanAndInf() { return this.mc.getAllowNanAndInf(); }
/*      */ 
/*      */ 
/*      */   
/* 1185 */   public boolean getAllowUrlInLocalInfile() { return this.mc.getAllowUrlInLocalInfile(); }
/*      */ 
/*      */ 
/*      */   
/* 1189 */   public boolean getAlwaysSendSetIsolation() { return this.mc.getAlwaysSendSetIsolation(); }
/*      */ 
/*      */ 
/*      */   
/* 1193 */   public boolean getAutoClosePStmtStreams() { return this.mc.getAutoClosePStmtStreams(); }
/*      */ 
/*      */ 
/*      */   
/* 1197 */   public boolean getAutoDeserialize() { return this.mc.getAutoDeserialize(); }
/*      */ 
/*      */ 
/*      */   
/* 1201 */   public boolean getAutoGenerateTestcaseScript() { return this.mc.getAutoGenerateTestcaseScript(); }
/*      */ 
/*      */ 
/*      */   
/* 1205 */   public boolean getAutoReconnectForPools() { return this.mc.getAutoReconnectForPools(); }
/*      */ 
/*      */ 
/*      */   
/* 1209 */   public boolean getAutoSlowLog() { return this.mc.getAutoSlowLog(); }
/*      */ 
/*      */ 
/*      */   
/* 1213 */   public int getBlobSendChunkSize() { return this.mc.getBlobSendChunkSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1217 */   public boolean getBlobsAreStrings() { return this.mc.getBlobsAreStrings(); }
/*      */ 
/*      */ 
/*      */   
/* 1221 */   public boolean getCacheCallableStatements() { return this.mc.getCacheCallableStatements(); }
/*      */ 
/*      */ 
/*      */   
/* 1225 */   public boolean getCacheCallableStmts() { return this.mc.getCacheCallableStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1229 */   public boolean getCachePrepStmts() { return this.mc.getCachePrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1233 */   public boolean getCachePreparedStatements() { return this.mc.getCachePreparedStatements(); }
/*      */ 
/*      */ 
/*      */   
/* 1237 */   public boolean getCacheResultSetMetadata() { return this.mc.getCacheResultSetMetadata(); }
/*      */ 
/*      */ 
/*      */   
/* 1241 */   public boolean getCacheServerConfiguration() { return this.mc.getCacheServerConfiguration(); }
/*      */ 
/*      */ 
/*      */   
/* 1245 */   public int getCallableStatementCacheSize() { return this.mc.getCallableStatementCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1249 */   public int getCallableStmtCacheSize() { return this.mc.getCallableStmtCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1253 */   public boolean getCapitalizeTypeNames() { return this.mc.getCapitalizeTypeNames(); }
/*      */ 
/*      */ 
/*      */   
/* 1257 */   public String getCharacterSetResults() { return this.mc.getCharacterSetResults(); }
/*      */ 
/*      */ 
/*      */   
/* 1261 */   public String getClientCertificateKeyStorePassword() { return this.mc.getClientCertificateKeyStorePassword(); }
/*      */ 
/*      */ 
/*      */   
/* 1265 */   public String getClientCertificateKeyStoreType() { return this.mc.getClientCertificateKeyStoreType(); }
/*      */ 
/*      */ 
/*      */   
/* 1269 */   public String getClientCertificateKeyStoreUrl() { return this.mc.getClientCertificateKeyStoreUrl(); }
/*      */ 
/*      */ 
/*      */   
/* 1273 */   public String getClientInfoProvider() { return this.mc.getClientInfoProvider(); }
/*      */ 
/*      */ 
/*      */   
/* 1277 */   public String getClobCharacterEncoding() { return this.mc.getClobCharacterEncoding(); }
/*      */ 
/*      */ 
/*      */   
/* 1281 */   public boolean getClobberStreamingResults() { return this.mc.getClobberStreamingResults(); }
/*      */ 
/*      */ 
/*      */   
/* 1285 */   public int getConnectTimeout() { return this.mc.getConnectTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 1289 */   public String getConnectionCollation() { return this.mc.getConnectionCollation(); }
/*      */ 
/*      */ 
/*      */   
/* 1293 */   public String getConnectionLifecycleInterceptors() { return this.mc.getConnectionLifecycleInterceptors(); }
/*      */ 
/*      */ 
/*      */   
/* 1297 */   public boolean getContinueBatchOnError() { return this.mc.getContinueBatchOnError(); }
/*      */ 
/*      */ 
/*      */   
/* 1301 */   public boolean getCreateDatabaseIfNotExist() { return this.mc.getCreateDatabaseIfNotExist(); }
/*      */ 
/*      */ 
/*      */   
/* 1305 */   public int getDefaultFetchSize() { return this.mc.getDefaultFetchSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1309 */   public boolean getDontTrackOpenResources() { return this.mc.getDontTrackOpenResources(); }
/*      */ 
/*      */ 
/*      */   
/* 1313 */   public boolean getDumpMetadataOnColumnNotFound() { return this.mc.getDumpMetadataOnColumnNotFound(); }
/*      */ 
/*      */ 
/*      */   
/* 1317 */   public boolean getDumpQueriesOnException() { return this.mc.getDumpQueriesOnException(); }
/*      */ 
/*      */ 
/*      */   
/* 1321 */   public boolean getDynamicCalendars() { return this.mc.getDynamicCalendars(); }
/*      */ 
/*      */ 
/*      */   
/* 1325 */   public boolean getElideSetAutoCommits() { return this.mc.getElideSetAutoCommits(); }
/*      */ 
/*      */ 
/*      */   
/* 1329 */   public boolean getEmptyStringsConvertToZero() { return this.mc.getEmptyStringsConvertToZero(); }
/*      */ 
/*      */ 
/*      */   
/* 1333 */   public boolean getEmulateLocators() { return this.mc.getEmulateLocators(); }
/*      */ 
/*      */ 
/*      */   
/* 1337 */   public boolean getEmulateUnsupportedPstmts() { return this.mc.getEmulateUnsupportedPstmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1341 */   public boolean getEnablePacketDebug() { return this.mc.getEnablePacketDebug(); }
/*      */ 
/*      */ 
/*      */   
/* 1345 */   public boolean getEnableQueryTimeouts() { return this.mc.getEnableQueryTimeouts(); }
/*      */ 
/*      */ 
/*      */   
/* 1349 */   public String getEncoding() { return this.mc.getEncoding(); }
/*      */ 
/*      */ 
/*      */   
/* 1353 */   public boolean getExplainSlowQueries() { return this.mc.getExplainSlowQueries(); }
/*      */ 
/*      */ 
/*      */   
/* 1357 */   public boolean getFailOverReadOnly() { return this.mc.getFailOverReadOnly(); }
/*      */ 
/*      */ 
/*      */   
/* 1361 */   public boolean getFunctionsNeverReturnBlobs() { return this.mc.getFunctionsNeverReturnBlobs(); }
/*      */ 
/*      */ 
/*      */   
/* 1365 */   public boolean getGatherPerfMetrics() { return this.mc.getGatherPerfMetrics(); }
/*      */ 
/*      */ 
/*      */   
/* 1369 */   public boolean getGatherPerformanceMetrics() { return this.mc.getGatherPerformanceMetrics(); }
/*      */ 
/*      */ 
/*      */   
/* 1373 */   public boolean getGenerateSimpleParameterMetadata() { return this.mc.getGenerateSimpleParameterMetadata(); }
/*      */ 
/*      */ 
/*      */   
/* 1377 */   public boolean getHoldResultsOpenOverStatementClose() { return this.mc.getHoldResultsOpenOverStatementClose(); }
/*      */ 
/*      */ 
/*      */   
/* 1381 */   public boolean getIgnoreNonTxTables() { return this.mc.getIgnoreNonTxTables(); }
/*      */ 
/*      */ 
/*      */   
/* 1385 */   public boolean getIncludeInnodbStatusInDeadlockExceptions() { return this.mc.getIncludeInnodbStatusInDeadlockExceptions(); }
/*      */ 
/*      */ 
/*      */   
/* 1389 */   public int getInitialTimeout() { return this.mc.getInitialTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 1393 */   public boolean getInteractiveClient() { return this.mc.getInteractiveClient(); }
/*      */ 
/*      */ 
/*      */   
/* 1397 */   public boolean getIsInteractiveClient() { return this.mc.getIsInteractiveClient(); }
/*      */ 
/*      */ 
/*      */   
/* 1401 */   public boolean getJdbcCompliantTruncation() { return this.mc.getJdbcCompliantTruncation(); }
/*      */ 
/*      */ 
/*      */   
/* 1405 */   public boolean getJdbcCompliantTruncationForReads() { return this.mc.getJdbcCompliantTruncationForReads(); }
/*      */ 
/*      */ 
/*      */   
/* 1409 */   public String getLargeRowSizeThreshold() { return this.mc.getLargeRowSizeThreshold(); }
/*      */ 
/*      */ 
/*      */   
/* 1413 */   public String getLoadBalanceStrategy() { return this.mc.getLoadBalanceStrategy(); }
/*      */ 
/*      */ 
/*      */   
/* 1417 */   public String getLocalSocketAddress() { return this.mc.getLocalSocketAddress(); }
/*      */ 
/*      */ 
/*      */   
/* 1421 */   public int getLocatorFetchBufferSize() { return this.mc.getLocatorFetchBufferSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1425 */   public boolean getLogSlowQueries() { return this.mc.getLogSlowQueries(); }
/*      */ 
/*      */ 
/*      */   
/* 1429 */   public boolean getLogXaCommands() { return this.mc.getLogXaCommands(); }
/*      */ 
/*      */ 
/*      */   
/* 1433 */   public String getLogger() { return this.mc.getLogger(); }
/*      */ 
/*      */ 
/*      */   
/* 1437 */   public String getLoggerClassName() { return this.mc.getLoggerClassName(); }
/*      */ 
/*      */ 
/*      */   
/* 1441 */   public boolean getMaintainTimeStats() { return this.mc.getMaintainTimeStats(); }
/*      */ 
/*      */ 
/*      */   
/* 1445 */   public int getMaxQuerySizeToLog() { return this.mc.getMaxQuerySizeToLog(); }
/*      */ 
/*      */ 
/*      */   
/* 1449 */   public int getMaxReconnects() { return this.mc.getMaxReconnects(); }
/*      */ 
/*      */ 
/*      */   
/* 1453 */   public int getMaxRows() { return this.mc.getMaxRows(); }
/*      */ 
/*      */ 
/*      */   
/* 1457 */   public int getMetadataCacheSize() { return this.mc.getMetadataCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1461 */   public int getNetTimeoutForStreamingResults() { return this.mc.getNetTimeoutForStreamingResults(); }
/*      */ 
/*      */ 
/*      */   
/* 1465 */   public boolean getNoAccessToProcedureBodies() { return this.mc.getNoAccessToProcedureBodies(); }
/*      */ 
/*      */ 
/*      */   
/* 1469 */   public boolean getNoDatetimeStringSync() { return this.mc.getNoDatetimeStringSync(); }
/*      */ 
/*      */ 
/*      */   
/* 1473 */   public boolean getNoTimezoneConversionForTimeType() { return this.mc.getNoTimezoneConversionForTimeType(); }
/*      */ 
/*      */ 
/*      */   
/* 1477 */   public boolean getNullCatalogMeansCurrent() { return this.mc.getNullCatalogMeansCurrent(); }
/*      */ 
/*      */ 
/*      */   
/* 1481 */   public boolean getNullNamePatternMatchesAll() { return this.mc.getNullNamePatternMatchesAll(); }
/*      */ 
/*      */ 
/*      */   
/* 1485 */   public boolean getOverrideSupportsIntegrityEnhancementFacility() { return this.mc.getOverrideSupportsIntegrityEnhancementFacility(); }
/*      */ 
/*      */ 
/*      */   
/* 1489 */   public int getPacketDebugBufferSize() { return this.mc.getPacketDebugBufferSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1493 */   public boolean getPadCharsWithSpace() { return this.mc.getPadCharsWithSpace(); }
/*      */ 
/*      */ 
/*      */   
/* 1497 */   public boolean getParanoid() { return this.mc.getParanoid(); }
/*      */ 
/*      */ 
/*      */   
/* 1501 */   public boolean getPedantic() { return this.mc.getPedantic(); }
/*      */ 
/*      */ 
/*      */   
/* 1505 */   public boolean getPinGlobalTxToPhysicalConnection() { return this.mc.getPinGlobalTxToPhysicalConnection(); }
/*      */ 
/*      */ 
/*      */   
/* 1509 */   public boolean getPopulateInsertRowWithDefaultValues() { return this.mc.getPopulateInsertRowWithDefaultValues(); }
/*      */ 
/*      */ 
/*      */   
/* 1513 */   public int getPrepStmtCacheSize() { return this.mc.getPrepStmtCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1517 */   public int getPrepStmtCacheSqlLimit() { return this.mc.getPrepStmtCacheSqlLimit(); }
/*      */ 
/*      */ 
/*      */   
/* 1521 */   public int getPreparedStatementCacheSize() { return this.mc.getPreparedStatementCacheSize(); }
/*      */ 
/*      */ 
/*      */   
/* 1525 */   public int getPreparedStatementCacheSqlLimit() { return this.mc.getPreparedStatementCacheSqlLimit(); }
/*      */ 
/*      */ 
/*      */   
/* 1529 */   public boolean getProcessEscapeCodesForPrepStmts() { return this.mc.getProcessEscapeCodesForPrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1533 */   public boolean getProfileSQL() { return this.mc.getProfileSQL(); }
/*      */ 
/*      */ 
/*      */   
/* 1537 */   public boolean getProfileSql() { return this.mc.getProfileSql(); }
/*      */ 
/*      */ 
/*      */   
/* 1541 */   public String getPropertiesTransform() { return this.mc.getPropertiesTransform(); }
/*      */ 
/*      */ 
/*      */   
/* 1545 */   public int getQueriesBeforeRetryMaster() { return this.mc.getQueriesBeforeRetryMaster(); }
/*      */ 
/*      */ 
/*      */   
/* 1549 */   public boolean getReconnectAtTxEnd() { return this.mc.getReconnectAtTxEnd(); }
/*      */ 
/*      */ 
/*      */   
/* 1553 */   public boolean getRelaxAutoCommit() { return this.mc.getRelaxAutoCommit(); }
/*      */ 
/*      */ 
/*      */   
/* 1557 */   public int getReportMetricsIntervalMillis() { return this.mc.getReportMetricsIntervalMillis(); }
/*      */ 
/*      */ 
/*      */   
/* 1561 */   public boolean getRequireSSL() { return this.mc.getRequireSSL(); }
/*      */ 
/*      */ 
/*      */   
/* 1565 */   public String getResourceId() { return this.mc.getResourceId(); }
/*      */ 
/*      */ 
/*      */   
/* 1569 */   public int getResultSetSizeThreshold() { return this.mc.getResultSetSizeThreshold(); }
/*      */ 
/*      */ 
/*      */   
/* 1573 */   public boolean getRewriteBatchedStatements() { return this.mc.getRewriteBatchedStatements(); }
/*      */ 
/*      */ 
/*      */   
/* 1577 */   public boolean getRollbackOnPooledClose() { return this.mc.getRollbackOnPooledClose(); }
/*      */ 
/*      */ 
/*      */   
/* 1581 */   public boolean getRoundRobinLoadBalance() { return this.mc.getRoundRobinLoadBalance(); }
/*      */ 
/*      */ 
/*      */   
/* 1585 */   public boolean getRunningCTS13() { return this.mc.getRunningCTS13(); }
/*      */ 
/*      */ 
/*      */   
/* 1589 */   public int getSecondsBeforeRetryMaster() { return this.mc.getSecondsBeforeRetryMaster(); }
/*      */ 
/*      */ 
/*      */   
/* 1593 */   public String getServerTimezone() { return this.mc.getServerTimezone(); }
/*      */ 
/*      */ 
/*      */   
/* 1597 */   public String getSessionVariables() { return this.mc.getSessionVariables(); }
/*      */ 
/*      */ 
/*      */   
/* 1601 */   public int getSlowQueryThresholdMillis() { return this.mc.getSlowQueryThresholdMillis(); }
/*      */ 
/*      */ 
/*      */   
/* 1605 */   public long getSlowQueryThresholdNanos() { return this.mc.getSlowQueryThresholdNanos(); }
/*      */ 
/*      */ 
/*      */   
/* 1609 */   public String getSocketFactory() { return this.mc.getSocketFactory(); }
/*      */ 
/*      */ 
/*      */   
/* 1613 */   public String getSocketFactoryClassName() { return this.mc.getSocketFactoryClassName(); }
/*      */ 
/*      */ 
/*      */   
/* 1617 */   public int getSocketTimeout() { return this.mc.getSocketTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 1621 */   public String getStatementInterceptors() { return this.mc.getStatementInterceptors(); }
/*      */ 
/*      */ 
/*      */   
/* 1625 */   public boolean getStrictFloatingPoint() { return this.mc.getStrictFloatingPoint(); }
/*      */ 
/*      */ 
/*      */   
/* 1629 */   public boolean getStrictUpdates() { return this.mc.getStrictUpdates(); }
/*      */ 
/*      */ 
/*      */   
/* 1633 */   public boolean getTcpKeepAlive() { return this.mc.getTcpKeepAlive(); }
/*      */ 
/*      */ 
/*      */   
/* 1637 */   public boolean getTcpNoDelay() { return this.mc.getTcpNoDelay(); }
/*      */ 
/*      */ 
/*      */   
/* 1641 */   public int getTcpRcvBuf() { return this.mc.getTcpRcvBuf(); }
/*      */ 
/*      */ 
/*      */   
/* 1645 */   public int getTcpSndBuf() { return this.mc.getTcpSndBuf(); }
/*      */ 
/*      */ 
/*      */   
/* 1649 */   public int getTcpTrafficClass() { return this.mc.getTcpTrafficClass(); }
/*      */ 
/*      */ 
/*      */   
/* 1653 */   public boolean getTinyInt1isBit() { return this.mc.getTinyInt1isBit(); }
/*      */ 
/*      */ 
/*      */   
/* 1657 */   public boolean getTraceProtocol() { return this.mc.getTraceProtocol(); }
/*      */ 
/*      */ 
/*      */   
/* 1661 */   public boolean getTransformedBitIsBoolean() { return this.mc.getTransformedBitIsBoolean(); }
/*      */ 
/*      */ 
/*      */   
/* 1665 */   public boolean getTreatUtilDateAsTimestamp() { return this.mc.getTreatUtilDateAsTimestamp(); }
/*      */ 
/*      */ 
/*      */   
/* 1669 */   public String getTrustCertificateKeyStorePassword() { return this.mc.getTrustCertificateKeyStorePassword(); }
/*      */ 
/*      */ 
/*      */   
/* 1673 */   public String getTrustCertificateKeyStoreType() { return this.mc.getTrustCertificateKeyStoreType(); }
/*      */ 
/*      */ 
/*      */   
/* 1677 */   public String getTrustCertificateKeyStoreUrl() { return this.mc.getTrustCertificateKeyStoreUrl(); }
/*      */ 
/*      */ 
/*      */   
/* 1681 */   public boolean getUltraDevHack() { return this.mc.getUltraDevHack(); }
/*      */ 
/*      */ 
/*      */   
/* 1685 */   public boolean getUseBlobToStoreUTF8OutsideBMP() { return this.mc.getUseBlobToStoreUTF8OutsideBMP(); }
/*      */ 
/*      */ 
/*      */   
/* 1689 */   public boolean getUseCompression() { return this.mc.getUseCompression(); }
/*      */ 
/*      */ 
/*      */   
/* 1693 */   public String getUseConfigs() { return this.mc.getUseConfigs(); }
/*      */ 
/*      */ 
/*      */   
/* 1697 */   public boolean getUseCursorFetch() { return this.mc.getUseCursorFetch(); }
/*      */ 
/*      */ 
/*      */   
/* 1701 */   public boolean getUseDirectRowUnpack() { return this.mc.getUseDirectRowUnpack(); }
/*      */ 
/*      */ 
/*      */   
/* 1705 */   public boolean getUseDynamicCharsetInfo() { return this.mc.getUseDynamicCharsetInfo(); }
/*      */ 
/*      */ 
/*      */   
/* 1709 */   public boolean getUseFastDateParsing() { return this.mc.getUseFastDateParsing(); }
/*      */ 
/*      */ 
/*      */   
/* 1713 */   public boolean getUseFastIntParsing() { return this.mc.getUseFastIntParsing(); }
/*      */ 
/*      */ 
/*      */   
/* 1717 */   public boolean getUseGmtMillisForDatetimes() { return this.mc.getUseGmtMillisForDatetimes(); }
/*      */ 
/*      */ 
/*      */   
/* 1721 */   public boolean getUseHostsInPrivileges() { return this.mc.getUseHostsInPrivileges(); }
/*      */ 
/*      */ 
/*      */   
/* 1725 */   public boolean getUseInformationSchema() { return this.mc.getUseInformationSchema(); }
/*      */ 
/*      */ 
/*      */   
/* 1729 */   public boolean getUseJDBCCompliantTimezoneShift() { return this.mc.getUseJDBCCompliantTimezoneShift(); }
/*      */ 
/*      */ 
/*      */   
/* 1733 */   public boolean getUseJvmCharsetConverters() { return this.mc.getUseJvmCharsetConverters(); }
/*      */ 
/*      */ 
/*      */   
/* 1737 */   public boolean getUseLocalSessionState() { return this.mc.getUseLocalSessionState(); }
/*      */ 
/*      */ 
/*      */   
/* 1741 */   public boolean getUseNanosForElapsedTime() { return this.mc.getUseNanosForElapsedTime(); }
/*      */ 
/*      */ 
/*      */   
/* 1745 */   public boolean getUseOldAliasMetadataBehavior() { return this.mc.getUseOldAliasMetadataBehavior(); }
/*      */ 
/*      */ 
/*      */   
/* 1749 */   public boolean getUseOldUTF8Behavior() { return this.mc.getUseOldUTF8Behavior(); }
/*      */ 
/*      */ 
/*      */   
/* 1753 */   public boolean getUseOnlyServerErrorMessages() { return this.mc.getUseOnlyServerErrorMessages(); }
/*      */ 
/*      */ 
/*      */   
/* 1757 */   public boolean getUseReadAheadInput() { return this.mc.getUseReadAheadInput(); }
/*      */ 
/*      */ 
/*      */   
/* 1761 */   public boolean getUseSSL() { return this.mc.getUseSSL(); }
/*      */ 
/*      */ 
/*      */   
/* 1765 */   public boolean getUseSSPSCompatibleTimezoneShift() { return this.mc.getUseSSPSCompatibleTimezoneShift(); }
/*      */ 
/*      */ 
/*      */   
/* 1769 */   public boolean getUseServerPrepStmts() { return this.mc.getUseServerPrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1773 */   public boolean getUseServerPreparedStmts() { return this.mc.getUseServerPreparedStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1777 */   public boolean getUseSqlStateCodes() { return this.mc.getUseSqlStateCodes(); }
/*      */ 
/*      */ 
/*      */   
/* 1781 */   public boolean getUseStreamLengthsInPrepStmts() { return this.mc.getUseStreamLengthsInPrepStmts(); }
/*      */ 
/*      */ 
/*      */   
/* 1785 */   public boolean getUseTimezone() { return this.mc.getUseTimezone(); }
/*      */ 
/*      */ 
/*      */   
/* 1789 */   public boolean getUseUltraDevWorkAround() { return this.mc.getUseUltraDevWorkAround(); }
/*      */ 
/*      */ 
/*      */   
/* 1793 */   public boolean getUseUnbufferedInput() { return this.mc.getUseUnbufferedInput(); }
/*      */ 
/*      */ 
/*      */   
/* 1797 */   public boolean getUseUnicode() { return this.mc.getUseUnicode(); }
/*      */ 
/*      */ 
/*      */   
/* 1801 */   public boolean getUseUsageAdvisor() { return this.mc.getUseUsageAdvisor(); }
/*      */ 
/*      */ 
/*      */   
/* 1805 */   public String getUtf8OutsideBmpExcludedColumnNamePattern() { return this.mc.getUtf8OutsideBmpExcludedColumnNamePattern(); }
/*      */ 
/*      */ 
/*      */   
/* 1809 */   public String getUtf8OutsideBmpIncludedColumnNamePattern() { return this.mc.getUtf8OutsideBmpIncludedColumnNamePattern(); }
/*      */ 
/*      */ 
/*      */   
/* 1813 */   public boolean getYearIsDateType() { return this.mc.getYearIsDateType(); }
/*      */ 
/*      */ 
/*      */   
/* 1817 */   public String getZeroDateTimeBehavior() { return this.mc.getZeroDateTimeBehavior(); }
/*      */ 
/*      */ 
/*      */   
/* 1821 */   public void setAllowLoadLocalInfile(boolean property) { this.mc.setAllowLoadLocalInfile(property); }
/*      */ 
/*      */ 
/*      */   
/* 1825 */   public void setAllowMultiQueries(boolean property) { this.mc.setAllowMultiQueries(property); }
/*      */ 
/*      */ 
/*      */   
/* 1829 */   public void setAllowNanAndInf(boolean flag) { this.mc.setAllowNanAndInf(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1833 */   public void setAllowUrlInLocalInfile(boolean flag) { this.mc.setAllowUrlInLocalInfile(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1837 */   public void setAlwaysSendSetIsolation(boolean flag) { this.mc.setAlwaysSendSetIsolation(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1841 */   public void setAutoClosePStmtStreams(boolean flag) { this.mc.setAutoClosePStmtStreams(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1845 */   public void setAutoDeserialize(boolean flag) { this.mc.setAutoDeserialize(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1849 */   public void setAutoGenerateTestcaseScript(boolean flag) { this.mc.setAutoGenerateTestcaseScript(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1853 */   public void setAutoReconnect(boolean flag) { this.mc.setAutoReconnect(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1857 */   public void setAutoReconnectForConnectionPools(boolean property) { this.mc.setAutoReconnectForConnectionPools(property); }
/*      */ 
/*      */ 
/*      */   
/* 1861 */   public void setAutoReconnectForPools(boolean flag) { this.mc.setAutoReconnectForPools(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1865 */   public void setAutoSlowLog(boolean flag) { this.mc.setAutoSlowLog(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1869 */   public void setBlobSendChunkSize(String value) throws SQLException { this.mc.setBlobSendChunkSize(value); }
/*      */ 
/*      */ 
/*      */   
/* 1873 */   public void setBlobsAreStrings(boolean flag) { this.mc.setBlobsAreStrings(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1877 */   public void setCacheCallableStatements(boolean flag) { this.mc.setCacheCallableStatements(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1881 */   public void setCacheCallableStmts(boolean flag) { this.mc.setCacheCallableStmts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1885 */   public void setCachePrepStmts(boolean flag) { this.mc.setCachePrepStmts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1889 */   public void setCachePreparedStatements(boolean flag) { this.mc.setCachePreparedStatements(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1893 */   public void setCacheResultSetMetadata(boolean property) { this.mc.setCacheResultSetMetadata(property); }
/*      */ 
/*      */ 
/*      */   
/* 1897 */   public void setCacheServerConfiguration(boolean flag) { this.mc.setCacheServerConfiguration(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1901 */   public void setCallableStatementCacheSize(int size) { this.mc.setCallableStatementCacheSize(size); }
/*      */ 
/*      */ 
/*      */   
/* 1905 */   public void setCallableStmtCacheSize(int cacheSize) { this.mc.setCallableStmtCacheSize(cacheSize); }
/*      */ 
/*      */ 
/*      */   
/* 1909 */   public void setCapitalizeDBMDTypes(boolean property) { this.mc.setCapitalizeDBMDTypes(property); }
/*      */ 
/*      */ 
/*      */   
/* 1913 */   public void setCapitalizeTypeNames(boolean flag) { this.mc.setCapitalizeTypeNames(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1917 */   public void setCharacterEncoding(String encoding) { this.mc.setCharacterEncoding(encoding); }
/*      */ 
/*      */ 
/*      */   
/* 1921 */   public void setCharacterSetResults(String characterSet) { this.mc.setCharacterSetResults(characterSet); }
/*      */ 
/*      */ 
/*      */   
/* 1925 */   public void setClientCertificateKeyStorePassword(String value) { this.mc.setClientCertificateKeyStorePassword(value); }
/*      */ 
/*      */ 
/*      */   
/* 1929 */   public void setClientCertificateKeyStoreType(String value) { this.mc.setClientCertificateKeyStoreType(value); }
/*      */ 
/*      */ 
/*      */   
/* 1933 */   public void setClientCertificateKeyStoreUrl(String value) { this.mc.setClientCertificateKeyStoreUrl(value); }
/*      */ 
/*      */ 
/*      */   
/* 1937 */   public void setClientInfoProvider(String classname) { this.mc.setClientInfoProvider(classname); }
/*      */ 
/*      */ 
/*      */   
/* 1941 */   public void setClobCharacterEncoding(String encoding) { this.mc.setClobCharacterEncoding(encoding); }
/*      */ 
/*      */ 
/*      */   
/* 1945 */   public void setClobberStreamingResults(boolean flag) { this.mc.setClobberStreamingResults(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1949 */   public void setConnectTimeout(int timeoutMs) { this.mc.setConnectTimeout(timeoutMs); }
/*      */ 
/*      */ 
/*      */   
/* 1953 */   public void setConnectionCollation(String collation) { this.mc.setConnectionCollation(collation); }
/*      */ 
/*      */ 
/*      */   
/* 1957 */   public void setConnectionLifecycleInterceptors(String interceptors) { this.mc.setConnectionLifecycleInterceptors(interceptors); }
/*      */ 
/*      */ 
/*      */   
/* 1961 */   public void setContinueBatchOnError(boolean property) { this.mc.setContinueBatchOnError(property); }
/*      */ 
/*      */ 
/*      */   
/* 1965 */   public void setCreateDatabaseIfNotExist(boolean flag) { this.mc.setCreateDatabaseIfNotExist(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1969 */   public void setDefaultFetchSize(int n) { this.mc.setDefaultFetchSize(n); }
/*      */ 
/*      */ 
/*      */   
/* 1973 */   public void setDetectServerPreparedStmts(boolean property) { this.mc.setDetectServerPreparedStmts(property); }
/*      */ 
/*      */ 
/*      */   
/* 1977 */   public void setDontTrackOpenResources(boolean flag) { this.mc.setDontTrackOpenResources(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1981 */   public void setDumpMetadataOnColumnNotFound(boolean flag) { this.mc.setDumpMetadataOnColumnNotFound(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1985 */   public void setDumpQueriesOnException(boolean flag) { this.mc.setDumpQueriesOnException(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1989 */   public void setDynamicCalendars(boolean flag) { this.mc.setDynamicCalendars(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1993 */   public void setElideSetAutoCommits(boolean flag) { this.mc.setElideSetAutoCommits(flag); }
/*      */ 
/*      */ 
/*      */   
/* 1997 */   public void setEmptyStringsConvertToZero(boolean flag) { this.mc.setEmptyStringsConvertToZero(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2001 */   public void setEmulateLocators(boolean property) { this.mc.setEmulateLocators(property); }
/*      */ 
/*      */ 
/*      */   
/* 2005 */   public void setEmulateUnsupportedPstmts(boolean flag) { this.mc.setEmulateUnsupportedPstmts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2009 */   public void setEnablePacketDebug(boolean flag) { this.mc.setEnablePacketDebug(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2013 */   public void setEnableQueryTimeouts(boolean flag) { this.mc.setEnableQueryTimeouts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2017 */   public void setEncoding(String property) { this.mc.setEncoding(property); }
/*      */ 
/*      */ 
/*      */   
/* 2021 */   public void setExplainSlowQueries(boolean flag) { this.mc.setExplainSlowQueries(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2025 */   public void setFailOverReadOnly(boolean flag) { this.mc.setFailOverReadOnly(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2029 */   public void setFunctionsNeverReturnBlobs(boolean flag) { this.mc.setFunctionsNeverReturnBlobs(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2033 */   public void setGatherPerfMetrics(boolean flag) { this.mc.setGatherPerfMetrics(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2037 */   public void setGatherPerformanceMetrics(boolean flag) { this.mc.setGatherPerformanceMetrics(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2041 */   public void setGenerateSimpleParameterMetadata(boolean flag) { this.mc.setGenerateSimpleParameterMetadata(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2045 */   public void setHoldResultsOpenOverStatementClose(boolean flag) { this.mc.setHoldResultsOpenOverStatementClose(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2049 */   public void setIgnoreNonTxTables(boolean property) { this.mc.setIgnoreNonTxTables(property); }
/*      */ 
/*      */ 
/*      */   
/* 2053 */   public void setIncludeInnodbStatusInDeadlockExceptions(boolean flag) { this.mc.setIncludeInnodbStatusInDeadlockExceptions(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2057 */   public void setInitialTimeout(int property) { this.mc.setInitialTimeout(property); }
/*      */ 
/*      */ 
/*      */   
/* 2061 */   public void setInteractiveClient(boolean property) { this.mc.setInteractiveClient(property); }
/*      */ 
/*      */ 
/*      */   
/* 2065 */   public void setIsInteractiveClient(boolean property) { this.mc.setIsInteractiveClient(property); }
/*      */ 
/*      */ 
/*      */   
/* 2069 */   public void setJdbcCompliantTruncation(boolean flag) { this.mc.setJdbcCompliantTruncation(flag); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2074 */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads) { this.mc.setJdbcCompliantTruncationForReads(jdbcCompliantTruncationForReads); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 2079 */   public void setLargeRowSizeThreshold(String value) { this.mc.setLargeRowSizeThreshold(value); }
/*      */ 
/*      */ 
/*      */   
/* 2083 */   public void setLoadBalanceStrategy(String strategy) { this.mc.setLoadBalanceStrategy(strategy); }
/*      */ 
/*      */ 
/*      */   
/* 2087 */   public void setLocalSocketAddress(String address) { this.mc.setLocalSocketAddress(address); }
/*      */ 
/*      */ 
/*      */   
/* 2091 */   public void setLocatorFetchBufferSize(String value) throws SQLException { this.mc.setLocatorFetchBufferSize(value); }
/*      */ 
/*      */ 
/*      */   
/* 2095 */   public void setLogSlowQueries(boolean flag) { this.mc.setLogSlowQueries(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2099 */   public void setLogXaCommands(boolean flag) { this.mc.setLogXaCommands(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2103 */   public void setLogger(String property) { this.mc.setLogger(property); }
/*      */ 
/*      */ 
/*      */   
/* 2107 */   public void setLoggerClassName(String className) { this.mc.setLoggerClassName(className); }
/*      */ 
/*      */ 
/*      */   
/* 2111 */   public void setMaintainTimeStats(boolean flag) { this.mc.setMaintainTimeStats(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2115 */   public void setMaxQuerySizeToLog(int sizeInBytes) { this.mc.setMaxQuerySizeToLog(sizeInBytes); }
/*      */ 
/*      */ 
/*      */   
/* 2119 */   public void setMaxReconnects(int property) { this.mc.setMaxReconnects(property); }
/*      */ 
/*      */ 
/*      */   
/* 2123 */   public void setMaxRows(int property) { this.mc.setMaxRows(property); }
/*      */ 
/*      */ 
/*      */   
/* 2127 */   public void setMetadataCacheSize(int value) { this.mc.setMetadataCacheSize(value); }
/*      */ 
/*      */ 
/*      */   
/* 2131 */   public void setNetTimeoutForStreamingResults(int value) { this.mc.setNetTimeoutForStreamingResults(value); }
/*      */ 
/*      */ 
/*      */   
/* 2135 */   public void setNoAccessToProcedureBodies(boolean flag) { this.mc.setNoAccessToProcedureBodies(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2139 */   public void setNoDatetimeStringSync(boolean flag) { this.mc.setNoDatetimeStringSync(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2143 */   public void setNoTimezoneConversionForTimeType(boolean flag) { this.mc.setNoTimezoneConversionForTimeType(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2147 */   public void setNullCatalogMeansCurrent(boolean value) { this.mc.setNullCatalogMeansCurrent(value); }
/*      */ 
/*      */ 
/*      */   
/* 2151 */   public void setNullNamePatternMatchesAll(boolean value) { this.mc.setNullNamePatternMatchesAll(value); }
/*      */ 
/*      */ 
/*      */   
/* 2155 */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) { this.mc.setOverrideSupportsIntegrityEnhancementFacility(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2159 */   public void setPacketDebugBufferSize(int size) { this.mc.setPacketDebugBufferSize(size); }
/*      */ 
/*      */ 
/*      */   
/* 2163 */   public void setPadCharsWithSpace(boolean flag) { this.mc.setPadCharsWithSpace(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2167 */   public void setParanoid(boolean property) { this.mc.setParanoid(property); }
/*      */ 
/*      */ 
/*      */   
/* 2171 */   public void setPedantic(boolean property) { this.mc.setPedantic(property); }
/*      */ 
/*      */ 
/*      */   
/* 2175 */   public void setPinGlobalTxToPhysicalConnection(boolean flag) { this.mc.setPinGlobalTxToPhysicalConnection(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2179 */   public void setPopulateInsertRowWithDefaultValues(boolean flag) { this.mc.setPopulateInsertRowWithDefaultValues(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2183 */   public void setPrepStmtCacheSize(int cacheSize) { this.mc.setPrepStmtCacheSize(cacheSize); }
/*      */ 
/*      */ 
/*      */   
/* 2187 */   public void setPrepStmtCacheSqlLimit(int sqlLimit) { this.mc.setPrepStmtCacheSqlLimit(sqlLimit); }
/*      */ 
/*      */ 
/*      */   
/* 2191 */   public void setPreparedStatementCacheSize(int cacheSize) { this.mc.setPreparedStatementCacheSize(cacheSize); }
/*      */ 
/*      */ 
/*      */   
/* 2195 */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit) { this.mc.setPreparedStatementCacheSqlLimit(cacheSqlLimit); }
/*      */ 
/*      */ 
/*      */   
/* 2199 */   public void setProcessEscapeCodesForPrepStmts(boolean flag) { this.mc.setProcessEscapeCodesForPrepStmts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2203 */   public void setProfileSQL(boolean flag) { this.mc.setProfileSQL(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2207 */   public void setProfileSql(boolean property) { this.mc.setProfileSql(property); }
/*      */ 
/*      */ 
/*      */   
/* 2211 */   public void setPropertiesTransform(String value) { this.mc.setPropertiesTransform(value); }
/*      */ 
/*      */ 
/*      */   
/* 2215 */   public void setQueriesBeforeRetryMaster(int property) { this.mc.setQueriesBeforeRetryMaster(property); }
/*      */ 
/*      */ 
/*      */   
/* 2219 */   public void setReconnectAtTxEnd(boolean property) { this.mc.setReconnectAtTxEnd(property); }
/*      */ 
/*      */ 
/*      */   
/* 2223 */   public void setRelaxAutoCommit(boolean property) { this.mc.setRelaxAutoCommit(property); }
/*      */ 
/*      */ 
/*      */   
/* 2227 */   public void setReportMetricsIntervalMillis(int millis) { this.mc.setReportMetricsIntervalMillis(millis); }
/*      */ 
/*      */ 
/*      */   
/* 2231 */   public void setRequireSSL(boolean property) { this.mc.setRequireSSL(property); }
/*      */ 
/*      */ 
/*      */   
/* 2235 */   public void setResourceId(String resourceId) { this.mc.setResourceId(resourceId); }
/*      */ 
/*      */ 
/*      */   
/* 2239 */   public void setResultSetSizeThreshold(int threshold) { this.mc.setResultSetSizeThreshold(threshold); }
/*      */ 
/*      */ 
/*      */   
/* 2243 */   public void setRetainStatementAfterResultSetClose(boolean flag) { this.mc.setRetainStatementAfterResultSetClose(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2247 */   public void setRewriteBatchedStatements(boolean flag) { this.mc.setRewriteBatchedStatements(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2251 */   public void setRollbackOnPooledClose(boolean flag) { this.mc.setRollbackOnPooledClose(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2255 */   public void setRoundRobinLoadBalance(boolean flag) { this.mc.setRoundRobinLoadBalance(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2259 */   public void setRunningCTS13(boolean flag) { this.mc.setRunningCTS13(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2263 */   public void setSecondsBeforeRetryMaster(int property) { this.mc.setSecondsBeforeRetryMaster(property); }
/*      */ 
/*      */ 
/*      */   
/* 2267 */   public void setServerTimezone(String property) { this.mc.setServerTimezone(property); }
/*      */ 
/*      */ 
/*      */   
/* 2271 */   public void setSessionVariables(String variables) { this.mc.setSessionVariables(variables); }
/*      */ 
/*      */ 
/*      */   
/* 2275 */   public void setSlowQueryThresholdMillis(int millis) { this.mc.setSlowQueryThresholdMillis(millis); }
/*      */ 
/*      */ 
/*      */   
/* 2279 */   public void setSlowQueryThresholdNanos(long nanos) { this.mc.setSlowQueryThresholdNanos(nanos); }
/*      */ 
/*      */ 
/*      */   
/* 2283 */   public void setSocketFactory(String name) { this.mc.setSocketFactory(name); }
/*      */ 
/*      */ 
/*      */   
/* 2287 */   public void setSocketFactoryClassName(String property) { this.mc.setSocketFactoryClassName(property); }
/*      */ 
/*      */ 
/*      */   
/* 2291 */   public void setSocketTimeout(int property) { this.mc.setSocketTimeout(property); }
/*      */ 
/*      */ 
/*      */   
/* 2295 */   public void setStatementInterceptors(String value) { this.mc.setStatementInterceptors(value); }
/*      */ 
/*      */ 
/*      */   
/* 2299 */   public void setStrictFloatingPoint(boolean property) { this.mc.setStrictFloatingPoint(property); }
/*      */ 
/*      */ 
/*      */   
/* 2303 */   public void setStrictUpdates(boolean property) { this.mc.setStrictUpdates(property); }
/*      */ 
/*      */ 
/*      */   
/* 2307 */   public void setTcpKeepAlive(boolean flag) { this.mc.setTcpKeepAlive(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2311 */   public void setTcpNoDelay(boolean flag) { this.mc.setTcpNoDelay(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2315 */   public void setTcpRcvBuf(int bufSize) { this.mc.setTcpRcvBuf(bufSize); }
/*      */ 
/*      */ 
/*      */   
/* 2319 */   public void setTcpSndBuf(int bufSize) { this.mc.setTcpSndBuf(bufSize); }
/*      */ 
/*      */ 
/*      */   
/* 2323 */   public void setTcpTrafficClass(int classFlags) { this.mc.setTcpTrafficClass(classFlags); }
/*      */ 
/*      */ 
/*      */   
/* 2327 */   public void setTinyInt1isBit(boolean flag) { this.mc.setTinyInt1isBit(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2331 */   public void setTraceProtocol(boolean flag) { this.mc.setTraceProtocol(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2335 */   public void setTransformedBitIsBoolean(boolean flag) { this.mc.setTransformedBitIsBoolean(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2339 */   public void setTreatUtilDateAsTimestamp(boolean flag) { this.mc.setTreatUtilDateAsTimestamp(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2343 */   public void setTrustCertificateKeyStorePassword(String value) { this.mc.setTrustCertificateKeyStorePassword(value); }
/*      */ 
/*      */ 
/*      */   
/* 2347 */   public void setTrustCertificateKeyStoreType(String value) { this.mc.setTrustCertificateKeyStoreType(value); }
/*      */ 
/*      */ 
/*      */   
/* 2351 */   public void setTrustCertificateKeyStoreUrl(String value) { this.mc.setTrustCertificateKeyStoreUrl(value); }
/*      */ 
/*      */ 
/*      */   
/* 2355 */   public void setUltraDevHack(boolean flag) { this.mc.setUltraDevHack(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2359 */   public void setUseBlobToStoreUTF8OutsideBMP(boolean flag) { this.mc.setUseBlobToStoreUTF8OutsideBMP(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2363 */   public void setUseCompression(boolean property) { this.mc.setUseCompression(property); }
/*      */ 
/*      */ 
/*      */   
/* 2367 */   public void setUseConfigs(String configs) { this.mc.setUseConfigs(configs); }
/*      */ 
/*      */ 
/*      */   
/* 2371 */   public void setUseCursorFetch(boolean flag) { this.mc.setUseCursorFetch(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2375 */   public void setUseDirectRowUnpack(boolean flag) { this.mc.setUseDirectRowUnpack(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2379 */   public void setUseDynamicCharsetInfo(boolean flag) { this.mc.setUseDynamicCharsetInfo(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2383 */   public void setUseFastDateParsing(boolean flag) { this.mc.setUseFastDateParsing(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2387 */   public void setUseFastIntParsing(boolean flag) { this.mc.setUseFastIntParsing(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2391 */   public void setUseGmtMillisForDatetimes(boolean flag) { this.mc.setUseGmtMillisForDatetimes(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2395 */   public void setUseHostsInPrivileges(boolean property) { this.mc.setUseHostsInPrivileges(property); }
/*      */ 
/*      */ 
/*      */   
/* 2399 */   public void setUseInformationSchema(boolean flag) { this.mc.setUseInformationSchema(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2403 */   public void setUseJDBCCompliantTimezoneShift(boolean flag) { this.mc.setUseJDBCCompliantTimezoneShift(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2407 */   public void setUseJvmCharsetConverters(boolean flag) { this.mc.setUseJvmCharsetConverters(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2411 */   public void setUseLocalSessionState(boolean flag) { this.mc.setUseLocalSessionState(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2415 */   public void setUseNanosForElapsedTime(boolean flag) { this.mc.setUseNanosForElapsedTime(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2419 */   public void setUseOldAliasMetadataBehavior(boolean flag) { this.mc.setUseOldAliasMetadataBehavior(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2423 */   public void setUseOldUTF8Behavior(boolean flag) { this.mc.setUseOldUTF8Behavior(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2427 */   public void setUseOnlyServerErrorMessages(boolean flag) { this.mc.setUseOnlyServerErrorMessages(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2431 */   public void setUseReadAheadInput(boolean flag) { this.mc.setUseReadAheadInput(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2435 */   public void setUseSSL(boolean property) { this.mc.setUseSSL(property); }
/*      */ 
/*      */ 
/*      */   
/* 2439 */   public void setUseSSPSCompatibleTimezoneShift(boolean flag) { this.mc.setUseSSPSCompatibleTimezoneShift(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2443 */   public void setUseServerPrepStmts(boolean flag) { this.mc.setUseServerPrepStmts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2447 */   public void setUseServerPreparedStmts(boolean flag) { this.mc.setUseServerPreparedStmts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2451 */   public void setUseSqlStateCodes(boolean flag) { this.mc.setUseSqlStateCodes(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2455 */   public void setUseStreamLengthsInPrepStmts(boolean property) { this.mc.setUseStreamLengthsInPrepStmts(property); }
/*      */ 
/*      */ 
/*      */   
/* 2459 */   public void setUseTimezone(boolean property) { this.mc.setUseTimezone(property); }
/*      */ 
/*      */ 
/*      */   
/* 2463 */   public void setUseUltraDevWorkAround(boolean property) { this.mc.setUseUltraDevWorkAround(property); }
/*      */ 
/*      */ 
/*      */   
/* 2467 */   public void setUseUnbufferedInput(boolean flag) { this.mc.setUseUnbufferedInput(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2471 */   public void setUseUnicode(boolean flag) { this.mc.setUseUnicode(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2475 */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag) { this.mc.setUseUsageAdvisor(useUsageAdvisorFlag); }
/*      */ 
/*      */ 
/*      */   
/* 2479 */   public void setUtf8OutsideBmpExcludedColumnNamePattern(String regexPattern) { this.mc.setUtf8OutsideBmpExcludedColumnNamePattern(regexPattern); }
/*      */ 
/*      */ 
/*      */   
/* 2483 */   public void setUtf8OutsideBmpIncludedColumnNamePattern(String regexPattern) { this.mc.setUtf8OutsideBmpIncludedColumnNamePattern(regexPattern); }
/*      */ 
/*      */ 
/*      */   
/* 2487 */   public void setYearIsDateType(boolean flag) { this.mc.setYearIsDateType(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2491 */   public void setZeroDateTimeBehavior(String behavior) { this.mc.setZeroDateTimeBehavior(behavior); }
/*      */ 
/*      */ 
/*      */   
/* 2495 */   public boolean useUnbufferedInput() { return this.mc.useUnbufferedInput(); }
/*      */ 
/*      */ 
/*      */   
/* 2499 */   public void initializeExtension(Extension ex) throws SQLException { this.mc.initializeExtension(ex); }
/*      */ 
/*      */ 
/*      */   
/* 2503 */   public String getProfilerEventHandler() { return this.mc.getProfilerEventHandler(); }
/*      */ 
/*      */ 
/*      */   
/* 2507 */   public void setProfilerEventHandler(String handler) { this.mc.setProfilerEventHandler(handler); }
/*      */ 
/*      */ 
/*      */   
/* 2511 */   public boolean getVerifyServerCertificate() { return this.mc.getVerifyServerCertificate(); }
/*      */ 
/*      */ 
/*      */   
/* 2515 */   public void setVerifyServerCertificate(boolean flag) { this.mc.setVerifyServerCertificate(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2519 */   public boolean getUseLegacyDatetimeCode() { return this.mc.getUseLegacyDatetimeCode(); }
/*      */ 
/*      */ 
/*      */   
/* 2523 */   public void setUseLegacyDatetimeCode(boolean flag) { this.mc.setUseLegacyDatetimeCode(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2527 */   public int getSelfDestructOnPingMaxOperations() { return this.mc.getSelfDestructOnPingMaxOperations(); }
/*      */ 
/*      */ 
/*      */   
/* 2531 */   public int getSelfDestructOnPingSecondsLifetime() { return this.mc.getSelfDestructOnPingSecondsLifetime(); }
/*      */ 
/*      */ 
/*      */   
/* 2535 */   public void setSelfDestructOnPingMaxOperations(int maxOperations) { this.mc.setSelfDestructOnPingMaxOperations(maxOperations); }
/*      */ 
/*      */ 
/*      */   
/* 2539 */   public void setSelfDestructOnPingSecondsLifetime(int seconds) { this.mc.setSelfDestructOnPingSecondsLifetime(seconds); }
/*      */ 
/*      */ 
/*      */   
/* 2543 */   public boolean getUseColumnNamesInFindColumn() { return this.mc.getUseColumnNamesInFindColumn(); }
/*      */ 
/*      */ 
/*      */   
/* 2547 */   public void setUseColumnNamesInFindColumn(boolean flag) { this.mc.setUseColumnNamesInFindColumn(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2551 */   public boolean getUseLocalTransactionState() { return this.mc.getUseLocalTransactionState(); }
/*      */ 
/*      */ 
/*      */   
/* 2555 */   public void setUseLocalTransactionState(boolean flag) { this.mc.setUseLocalTransactionState(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2559 */   public boolean getCompensateOnDuplicateKeyUpdateCounts() { return this.mc.getCompensateOnDuplicateKeyUpdateCounts(); }
/*      */ 
/*      */ 
/*      */   
/* 2563 */   public void setCompensateOnDuplicateKeyUpdateCounts(boolean flag) { this.mc.setCompensateOnDuplicateKeyUpdateCounts(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2567 */   public boolean getUseAffectedRows() { return this.mc.getUseAffectedRows(); }
/*      */ 
/*      */ 
/*      */   
/* 2571 */   public void setUseAffectedRows(boolean flag) { this.mc.setUseAffectedRows(flag); }
/*      */ 
/*      */ 
/*      */   
/* 2575 */   public String getPasswordCharacterEncoding() { return this.mc.getPasswordCharacterEncoding(); }
/*      */ 
/*      */ 
/*      */   
/* 2579 */   public void setPasswordCharacterEncoding(String characterSet) { this.mc.setPasswordCharacterEncoding(characterSet); }
/*      */ 
/*      */ 
/*      */   
/* 2583 */   public int getAutoIncrementIncrement() { return this.mc.getAutoIncrementIncrement(); }
/*      */ 
/*      */ 
/*      */   
/* 2587 */   public int getLoadBalanceBlacklistTimeout() { return this.mc.getLoadBalanceBlacklistTimeout(); }
/*      */ 
/*      */ 
/*      */   
/* 2591 */   public void setLoadBalanceBlacklistTimeout(int loadBalanceBlacklistTimeout) { this.mc.setLoadBalanceBlacklistTimeout(loadBalanceBlacklistTimeout); }
/*      */ 
/*      */ 
/*      */   
/* 2595 */   public void setRetriesAllDown(int retriesAllDown) { this.mc.setRetriesAllDown(retriesAllDown); }
/*      */ 
/*      */ 
/*      */   
/* 2599 */   public int getRetriesAllDown() { return this.mc.getRetriesAllDown(); }
/*      */ 
/*      */ 
/*      */   
/* 2603 */   public ExceptionInterceptor getExceptionInterceptor() { return this.pooledConnection.getExceptionInterceptor(); }
/*      */ 
/*      */ 
/*      */   
/* 2607 */   public String getExceptionInterceptors() { return this.mc.getExceptionInterceptors(); }
/*      */ 
/*      */ 
/*      */   
/* 2611 */   public void setExceptionInterceptors(String exceptionInterceptors) { this.mc.setExceptionInterceptors(exceptionInterceptors); }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/jdbc2/optional/ConnectionWrapper.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */