/*     */ package com.mysql.jdbc.log;
/*     */ 
/*     */ import org.apache.log4j.Level;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.Priority;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Log4JLogger
/*     */   implements Log
/*     */ {
/*     */   private Logger logger;
/*     */   
/*  42 */   public Log4JLogger(String instanceName) { this.logger = Logger.getLogger(instanceName); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public boolean isDebugEnabled() { return this.logger.isDebugEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public boolean isErrorEnabled() { return this.logger.isEnabledFor((Priority)Level.ERROR); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public boolean isFatalEnabled() { return this.logger.isEnabledFor((Priority)Level.FATAL); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  78 */   public boolean isInfoEnabled() { return this.logger.isInfoEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  87 */   public boolean isTraceEnabled() { return this.logger.isDebugEnabled(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public boolean isWarnEnabled() { return this.logger.isEnabledFor((Priority)Level.WARN); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public void logDebug(Object msg) { this.logger.debug(LogUtils.expandProfilerEventIfNecessary(LogUtils.expandProfilerEventIfNecessary(msg))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public void logDebug(Object msg, Throwable thrown) { this.logger.debug(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 125 */   public void logError(Object msg) { this.logger.error(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public void logError(Object msg, Throwable thrown) { this.logger.error(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   public void logFatal(Object msg) { this.logger.fatal(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   public void logFatal(Object msg, Throwable thrown) { this.logger.fatal(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public void logInfo(Object msg) { this.logger.info(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 173 */   public void logInfo(Object msg, Throwable thrown) { this.logger.info(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 182 */   public void logTrace(Object msg) { this.logger.debug(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 192 */   public void logTrace(Object msg, Throwable thrown) { this.logger.debug(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   public void logWarn(Object msg) { this.logger.warn(LogUtils.expandProfilerEventIfNecessary(msg)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public void logWarn(Object msg, Throwable thrown) { this.logger.warn(LogUtils.expandProfilerEventIfNecessary(msg), thrown); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/com/mysql/jdbc/log/Log4JLogger.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */