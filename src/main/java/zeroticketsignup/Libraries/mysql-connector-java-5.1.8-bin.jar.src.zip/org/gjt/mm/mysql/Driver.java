package org.gjt.mm.mysql;

import com.mysql.jdbc.Driver;

public class Driver extends Driver {}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/mysql-connector-java-5.1.8-bin.jar!/org/gjt/mm/mysql/Driver.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.1
 */