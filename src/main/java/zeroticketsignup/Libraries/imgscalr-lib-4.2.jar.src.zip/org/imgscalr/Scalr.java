/*      */ package org.imgscalr;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.RenderingHints;
/*      */ import java.awt.color.ColorSpace;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.geom.Rectangle2D;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.BufferedImageOp;
/*      */ import java.awt.image.ColorConvertOp;
/*      */ import java.awt.image.ConvolveOp;
/*      */ import java.awt.image.ImagingOpException;
/*      */ import java.awt.image.Kernel;
/*      */ import java.awt.image.RescaleOp;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Scalr
/*      */ {
/*      */   public static final String DEBUG_PROPERTY_NAME = "imgscalr.debug";
/*      */   public static final String LOG_PREFIX_PROPERTY_NAME = "imgscalr.logPrefix";
/*  233 */   public static final boolean DEBUG = Boolean.getBoolean("imgscalr.debug");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  249 */   public static final String LOG_PREFIX = System.getProperty("imgscalr.logPrefix", "[imgscalr] ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  311 */   public static final ConvolveOp OP_ANTIALIAS = new ConvolveOp(new Kernel(3, 3, new float[] { 0.0F, 0.08F, 0.0F, 0.08F, 0.68F, 0.08F, 0.0F, 0.08F, 0.0F }), 1, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  323 */   public static final RescaleOp OP_DARKER = new RescaleOp(0.9F, 0.0F, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  333 */   public static final RescaleOp OP_BRIGHTER = new RescaleOp(1.1F, 0.0F, null);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  344 */   public static final ColorConvertOp OP_GRAYSCALE = new ColorConvertOp(ColorSpace.getInstance(1003), null);
/*      */   
/*      */   public static final int THRESHOLD_BALANCED_SPEED = 1600;
/*      */   
/*      */   public static final int THRESHOLD_QUALITY_BALANCED = 800;
/*      */ 
/*      */   
/*      */   static  {
/*  352 */     log(0, "Debug output ENABLED", new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Method
/*      */   {
/*  378 */     AUTOMATIC,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  385 */     SPEED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  394 */     BALANCED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  405 */     QUALITY,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  414 */     ULTRA_QUALITY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Mode
/*      */   {
/*  434 */     AUTOMATIC,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  446 */     FIT_EXACT,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  452 */     FIT_TO_WIDTH,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  458 */     FIT_TO_HEIGHT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public enum Rotation
/*      */   {
/*  474 */     CW_90,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  480 */     CW_180,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  486 */     CW_270,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  498 */     FLIP_HORZ,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  510 */     FLIP_VERT;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage apply(BufferedImage src, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/*  611 */     long t = System.currentTimeMillis();
/*      */     
/*  613 */     if (src == null)
/*  614 */       throw new IllegalArgumentException("src cannot be null"); 
/*  615 */     if (ops == null || ops.length == 0) {
/*  616 */       throw new IllegalArgumentException("ops cannot be null or empty");
/*      */     }
/*  618 */     int type = src.getType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  646 */     if (type != 1 && type != 2) {
/*  647 */       src = copyToOptimalImage(src);
/*      */     }
/*  649 */     if (DEBUG) {
/*  650 */       log(0, "Applying %d BufferedImageOps...", new Object[] { Integer.valueOf(ops.length) });
/*      */     }
/*  652 */     boolean hasReassignedSrc = false;
/*      */     
/*  654 */     for (int i = 0; i < ops.length; i++) {
/*  655 */       long subT = System.currentTimeMillis();
/*  656 */       BufferedImageOp op = ops[i];
/*      */ 
/*      */       
/*  659 */       if (op != null) {
/*      */ 
/*      */         
/*  662 */         if (DEBUG) {
/*  663 */           log(1, "Applying BufferedImageOp [class=%s, toString=%s]...", new Object[] { op.getClass(), op.toString() });
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  673 */         Rectangle2D resultBounds = op.getBounds2D(src);
/*      */ 
/*      */         
/*  676 */         if (resultBounds == null) {
/*  677 */           throw new ImagingOpException("BufferedImageOp [" + op.toString() + "] getBounds2D(src) returned null bounds for the target image; this should not happen and indicates a problem with application of this type of op.");
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  689 */         BufferedImage dest = createOptimalImage(src, (int)Math.round(resultBounds.getWidth()), (int)Math.round(resultBounds.getHeight()));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  694 */         BufferedImage result = op.filter(src, dest);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  701 */         if (hasReassignedSrc) {
/*  702 */           src.flush();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  710 */         src = result;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  717 */         hasReassignedSrc = true;
/*      */         
/*  719 */         if (DEBUG) {
/*  720 */           log(1, "Applied BufferedImageOp in %d ms, result [width=%d, height=%d]", new Object[] { Long.valueOf(System.currentTimeMillis() - subT), Integer.valueOf(result.getWidth()), Integer.valueOf(result.getHeight()) });
/*      */         }
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  726 */     if (DEBUG) {
/*  727 */       log(0, "All %d BufferedImageOps applied in %d ms", new Object[] { Integer.valueOf(ops.length), Long.valueOf(System.currentTimeMillis() - t) });
/*      */     }
/*      */     
/*  730 */     return src;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  779 */   public static BufferedImage crop(BufferedImage src, int width, int height, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return crop(src, 0, 0, width, height, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage crop(BufferedImage src, int x, int y, int width, int height, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/*  833 */     long t = System.currentTimeMillis();
/*      */     
/*  835 */     if (src == null)
/*  836 */       throw new IllegalArgumentException("src cannot be null"); 
/*  837 */     if (x < 0 || y < 0 || width < 0 || height < 0) {
/*  838 */       throw new IllegalArgumentException("Invalid crop bounds: x [" + x + "], y [" + y + "], width [" + width + "] and height [" + height + "] must all be >= 0");
/*      */     }
/*      */ 
/*      */     
/*  842 */     int srcWidth = src.getWidth();
/*  843 */     int srcHeight = src.getHeight();
/*      */     
/*  845 */     if (x + width > srcWidth) {
/*  846 */       throw new IllegalArgumentException("Invalid crop bounds: x + width [" + (x + width) + "] must be <= src.getWidth() [" + srcWidth + "]");
/*      */     }
/*      */     
/*  849 */     if (y + height > srcHeight) {
/*  850 */       throw new IllegalArgumentException("Invalid crop bounds: y + height [" + (y + height) + "] must be <= src.getHeight() [" + srcHeight + "]");
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  855 */     if (DEBUG) {
/*  856 */       log(0, "Cropping Image [width=%d, height=%d] to [x=%d, y=%d, width=%d, height=%d]...", new Object[] { Integer.valueOf(srcWidth), Integer.valueOf(srcHeight), Integer.valueOf(x), Integer.valueOf(y), Integer.valueOf(width), Integer.valueOf(height) });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  861 */     BufferedImage result = createOptimalImage(src, width, height);
/*  862 */     Graphics g = result.getGraphics();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  869 */     g.drawImage(src, 0, 0, width, height, x, y, x + width, y + height, null);
/*      */     
/*  871 */     g.dispose();
/*      */     
/*  873 */     if (DEBUG) {
/*  874 */       log(0, "Cropped Image in %d ms", new Object[] { Long.valueOf(System.currentTimeMillis() - t) });
/*      */     }
/*      */     
/*  877 */     if (ops != null && ops.length > 0) {
/*  878 */       result = apply(result, ops);
/*      */     }
/*  880 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  933 */   public static BufferedImage pad(BufferedImage src, int padding, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return pad(src, padding, Color.BLACK, new BufferedImageOp[0]); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage pad(BufferedImage src, int padding, Color color, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/*      */     BufferedImage result;
/*  991 */     long t = System.currentTimeMillis();
/*      */     
/*  993 */     if (src == null)
/*  994 */       throw new IllegalArgumentException("src cannot be null"); 
/*  995 */     if (padding < 1) {
/*  996 */       throw new IllegalArgumentException("padding [" + padding + "] must be > 0");
/*      */     }
/*  998 */     if (color == null) {
/*  999 */       throw new IllegalArgumentException("color cannot be null");
/*      */     }
/* 1001 */     int srcWidth = src.getWidth();
/* 1002 */     int srcHeight = src.getHeight();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1010 */     int sizeDiff = padding * 2;
/* 1011 */     int newWidth = srcWidth + sizeDiff;
/* 1012 */     int newHeight = srcHeight + sizeDiff;
/*      */     
/* 1014 */     if (DEBUG) {
/* 1015 */       log(0, "Padding Image from [originalWidth=%d, originalHeight=%d, padding=%d] to [newWidth=%d, newHeight=%d]...", new Object[] { Integer.valueOf(srcWidth), Integer.valueOf(srcHeight), Integer.valueOf(padding), Integer.valueOf(newWidth), Integer.valueOf(newHeight) });
/*      */     }
/*      */ 
/*      */     
/* 1019 */     boolean colorHasAlpha = (color.getAlpha() != 255);
/* 1020 */     boolean imageHasAlpha = (src.getTransparency() != 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1029 */     if (colorHasAlpha || imageHasAlpha) {
/* 1030 */       if (DEBUG) {
/* 1031 */         log(1, "Transparency FOUND in source image or color, using ARGB image type...", new Object[0]);
/*      */       }
/*      */       
/* 1034 */       result = new BufferedImage(newWidth, newHeight, 2);
/*      */     } else {
/*      */       
/* 1037 */       if (DEBUG) {
/* 1038 */         log(1, "Transparency NOT FOUND in source image or color, using RGB image type...", new Object[0]);
/*      */       }
/*      */       
/* 1041 */       result = new BufferedImage(newWidth, newHeight, 1);
/*      */     } 
/*      */ 
/*      */     
/* 1045 */     Graphics g = result.getGraphics();
/*      */ 
/*      */     
/* 1048 */     g.setColor(color);
/* 1049 */     g.fillRect(0, 0, newWidth, newHeight);
/*      */ 
/*      */     
/* 1052 */     g.drawImage(src, padding, padding, null);
/* 1053 */     g.dispose();
/*      */     
/* 1055 */     if (DEBUG) {
/* 1056 */       log(0, "Padding Applied in %d ms", new Object[] { Long.valueOf(System.currentTimeMillis() - t) });
/*      */     }
/*      */     
/* 1059 */     if (ops != null && ops.length > 0) {
/* 1060 */       result = apply(result, ops);
/*      */     }
/* 1062 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1110 */   public static BufferedImage resize(BufferedImage src, int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return resize(src, Method.AUTOMATIC, Mode.AUTOMATIC, targetSize, targetSize, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1166 */   public static BufferedImage resize(BufferedImage src, Method scalingMethod, int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return resize(src, scalingMethod, Mode.AUTOMATIC, targetSize, targetSize, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1230 */   public static BufferedImage resize(BufferedImage src, Mode resizeMode, int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return resize(src, Method.AUTOMATIC, resizeMode, targetSize, targetSize, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1298 */   public static BufferedImage resize(BufferedImage src, Method scalingMethod, Mode resizeMode, int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return resize(src, scalingMethod, resizeMode, targetSize, targetSize, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1354 */   public static BufferedImage resize(BufferedImage src, int targetWidth, int targetHeight, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return resize(src, Method.AUTOMATIC, Mode.AUTOMATIC, targetWidth, targetHeight, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1415 */   public static BufferedImage resize(BufferedImage src, Method scalingMethod, int targetWidth, int targetHeight, BufferedImageOp... ops) { return resize(src, scalingMethod, Mode.AUTOMATIC, targetWidth, targetHeight, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1485 */   public static BufferedImage resize(BufferedImage src, Mode resizeMode, int targetWidth, int targetHeight, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException { return resize(src, Method.AUTOMATIC, resizeMode, targetWidth, targetHeight, ops); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage resize(BufferedImage src, Method scalingMethod, Mode resizeMode, int targetWidth, int targetHeight, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 1561 */     long t = System.currentTimeMillis();
/*      */     
/* 1563 */     if (src == null)
/* 1564 */       throw new IllegalArgumentException("src cannot be null"); 
/* 1565 */     if (targetWidth < 0)
/* 1566 */       throw new IllegalArgumentException("targetWidth must be >= 0"); 
/* 1567 */     if (targetHeight < 0)
/* 1568 */       throw new IllegalArgumentException("targetHeight must be >= 0"); 
/* 1569 */     if (scalingMethod == null) {
/* 1570 */       throw new IllegalArgumentException("scalingMethod cannot be null. A good default value is Method.AUTOMATIC.");
/*      */     }
/* 1572 */     if (resizeMode == null) {
/* 1573 */       throw new IllegalArgumentException("resizeMode cannot be null. A good default value is Mode.AUTOMATIC.");
/*      */     }
/*      */     
/* 1576 */     BufferedImage result = null;
/*      */     
/* 1578 */     int currentWidth = src.getWidth();
/* 1579 */     int currentHeight = src.getHeight();
/*      */ 
/*      */     
/* 1582 */     float ratio = currentHeight / currentWidth;
/*      */     
/* 1584 */     if (DEBUG) {
/* 1585 */       log(0, "Resizing Image [size=%dx%d, resizeMode=%s, orientation=%s, ratio(H/W)=%f] to [targetSize=%dx%d]", new Object[] { Integer.valueOf(currentWidth), Integer.valueOf(currentHeight), resizeMode, (ratio <= 1.0F) ? "Landscape/Square" : "Portrait", Float.valueOf(ratio), Integer.valueOf(targetWidth), Integer.valueOf(targetHeight) });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1608 */     if (resizeMode != Mode.FIT_EXACT) {
/* 1609 */       if ((ratio <= 1.0F && resizeMode == Mode.AUTOMATIC) || resizeMode == Mode.FIT_TO_WIDTH)
/*      */       {
/*      */         
/* 1612 */         if (targetWidth == src.getWidth()) {
/* 1613 */           return src;
/*      */         }
/*      */         
/* 1616 */         int originalTargetHeight = targetHeight;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1623 */         targetHeight = Math.round(targetWidth * ratio);
/*      */         
/* 1625 */         if (DEBUG && originalTargetHeight != targetHeight) {
/* 1626 */           log(1, "Auto-Corrected targetHeight [from=%d to=%d] to honor image proportions.", new Object[] { Integer.valueOf(originalTargetHeight), Integer.valueOf(targetHeight) });
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1631 */         if (targetHeight == src.getHeight()) {
/* 1632 */           return src;
/*      */         }
/*      */         
/* 1635 */         int originalTargetWidth = targetWidth;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1641 */         targetWidth = Math.round(targetHeight / ratio);
/*      */         
/* 1643 */         if (DEBUG && originalTargetWidth != targetWidth) {
/* 1644 */           log(1, "Auto-Corrected targetWidth [from=%d to=%d] to honor image proportions.", new Object[] { Integer.valueOf(originalTargetWidth), Integer.valueOf(targetWidth) });
/*      */         }
/*      */       }
/*      */     
/*      */     }
/* 1649 */     else if (DEBUG) {
/* 1650 */       log(1, "Resize Mode FIT_EXACT used, no width/height checking or re-calculation will be done.", new Object[0]);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1655 */     if (scalingMethod == Method.AUTOMATIC) {
/* 1656 */       scalingMethod = determineScalingMethod(targetWidth, targetHeight, ratio);
/*      */     }
/*      */     
/* 1659 */     if (DEBUG) {
/* 1660 */       log(1, "Using Scaling Method: %s", new Object[] { scalingMethod });
/*      */     }
/*      */     
/* 1663 */     if (scalingMethod == Method.SPEED) {
/* 1664 */       result = scaleImage(src, targetWidth, targetHeight, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
/*      */     }
/* 1666 */     else if (scalingMethod == Method.BALANCED) {
/* 1667 */       result = scaleImage(src, targetWidth, targetHeight, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*      */     }
/* 1669 */     else if (scalingMethod == Method.QUALITY || scalingMethod == Method.ULTRA_QUALITY) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1681 */       if (targetWidth > currentWidth || targetHeight > currentHeight) {
/* 1682 */         if (DEBUG) {
/* 1683 */           log(1, "QUALITY scale-up, a single BICUBIC scale operation will be used...", new Object[0]);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1694 */         result = scaleImage(src, targetWidth, targetHeight, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
/*      */       } else {
/*      */         
/* 1697 */         if (DEBUG) {
/* 1698 */           log(1, "QUALITY scale-down, incremental scaling will be used...", new Object[0]);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1711 */         result = scaleImageIncrementally(src, targetWidth, targetHeight, scalingMethod, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1717 */     if (DEBUG) {
/* 1718 */       log(0, "Resized Image in %d ms", new Object[] { Long.valueOf(System.currentTimeMillis() - t) });
/*      */     }
/*      */     
/* 1721 */     if (ops != null && ops.length > 0) {
/* 1722 */       result = apply(result, ops);
/*      */     }
/* 1724 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static BufferedImage rotate(BufferedImage src, Rotation rotation, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 1769 */     long t = System.currentTimeMillis();
/*      */     
/* 1771 */     if (src == null)
/* 1772 */       throw new IllegalArgumentException("src cannot be null"); 
/* 1773 */     if (rotation == null) {
/* 1774 */       throw new IllegalArgumentException("rotation cannot be null");
/*      */     }
/* 1776 */     if (DEBUG) {
/* 1777 */       log(0, "Rotating Image [%s]...", new Object[] { rotation });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1786 */     int newWidth = src.getWidth();
/* 1787 */     int newHeight = src.getHeight();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1816 */     AffineTransform tx = new AffineTransform();
/*      */     
/* 1818 */     switch (rotation) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case CW_90:
/* 1824 */         newWidth = src.getHeight();
/* 1825 */         newHeight = src.getWidth();
/*      */ 
/*      */         
/* 1828 */         tx.translate(newWidth, 0.0D);
/* 1829 */         tx.rotate(Math.toRadians(90.0D));
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case CW_270:
/* 1838 */         newWidth = src.getHeight();
/* 1839 */         newHeight = src.getWidth();
/*      */ 
/*      */         
/* 1842 */         tx.translate(0.0D, newHeight);
/* 1843 */         tx.rotate(Math.toRadians(-90.0D));
/*      */         break;
/*      */       
/*      */       case CW_180:
/* 1847 */         tx.translate(newWidth, newHeight);
/* 1848 */         tx.rotate(Math.toRadians(180.0D));
/*      */         break;
/*      */       
/*      */       case FLIP_HORZ:
/* 1852 */         tx.translate(newWidth, 0.0D);
/* 1853 */         tx.scale(-1.0D, 1.0D);
/*      */         break;
/*      */       
/*      */       case FLIP_VERT:
/* 1857 */         tx.translate(0.0D, newHeight);
/* 1858 */         tx.scale(1.0D, -1.0D);
/*      */         break;
/*      */     } 
/*      */ 
/*      */     
/* 1863 */     BufferedImage result = createOptimalImage(src, newWidth, newHeight);
/* 1864 */     Graphics2D g2d = result.createGraphics();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1872 */     g2d.drawImage(src, tx, null);
/* 1873 */     g2d.dispose();
/*      */     
/* 1875 */     if (DEBUG) {
/* 1876 */       log(0, "Rotation Applied in %d ms, result [width=%d, height=%d]", new Object[] { Long.valueOf(System.currentTimeMillis() - t), Integer.valueOf(result.getWidth()), Integer.valueOf(result.getHeight()) });
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1881 */     if (ops != null && ops.length > 0) {
/* 1882 */       result = apply(result, ops);
/*      */     }
/* 1884 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void log(int depth, String message, Object... params) {
/* 1914 */     if (DEBUG) {
/* 1915 */       System.out.print(LOG_PREFIX);
/*      */       
/* 1917 */       for (int i = 0; i < depth; i++) {
/* 1918 */         System.out.print("\t");
/*      */       }
/* 1920 */       System.out.printf(message, params);
/* 1921 */       System.out.println();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1958 */   protected static BufferedImage createOptimalImage(BufferedImage src) { return createOptimalImage(src, src.getWidth(), src.getHeight()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static BufferedImage createOptimalImage(BufferedImage src, int width, int height) throws IllegalArgumentException {
/* 2002 */     if (width < 0 || height < 0) {
/* 2003 */       throw new IllegalArgumentException("width [" + width + "] and height [" + height + "] must be >= 0");
/*      */     }
/*      */     
/* 2006 */     return new BufferedImage(width, height, (src.getTransparency() == 1) ? 1 : 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static BufferedImage copyToOptimalImage(BufferedImage src) throws IllegalArgumentException {
/* 2044 */     if (src == null) {
/* 2045 */       throw new IllegalArgumentException("src cannot be null");
/*      */     }
/*      */     
/* 2048 */     int type = (src.getTransparency() == 1) ? 1 : 2;
/*      */     
/* 2050 */     BufferedImage result = new BufferedImage(src.getWidth(), src.getHeight(), type);
/*      */ 
/*      */ 
/*      */     
/* 2054 */     Graphics g = result.getGraphics();
/* 2055 */     g.drawImage(src, 0, 0, null);
/* 2056 */     g.dispose();
/*      */     
/* 2058 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static Method determineScalingMethod(int targetWidth, int targetHeight, float ratio) {
/* 2091 */     int length = (ratio <= 1.0F) ? targetWidth : targetHeight;
/*      */ 
/*      */     
/* 2094 */     Method result = Method.SPEED;
/*      */ 
/*      */     
/* 2097 */     if (length <= 800) {
/* 2098 */       result = Method.QUALITY;
/* 2099 */     } else if (length <= 1600) {
/* 2100 */       result = Method.BALANCED;
/*      */     } 
/* 2102 */     if (DEBUG) {
/* 2103 */       log(2, "AUTOMATIC scaling method selected: %s", new Object[] { result.name() });
/*      */     }
/* 2105 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static BufferedImage scaleImage(BufferedImage src, int targetWidth, int targetHeight, Object interpolationHintValue) {
/* 2133 */     BufferedImage result = createOptimalImage(src, targetWidth, targetHeight);
/*      */     
/* 2135 */     Graphics2D resultGraphics = result.createGraphics();
/*      */ 
/*      */     
/* 2138 */     resultGraphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, interpolationHintValue);
/*      */     
/* 2140 */     resultGraphics.drawImage(src, 0, 0, targetWidth, targetHeight, null);
/*      */ 
/*      */     
/* 2143 */     resultGraphics.dispose();
/*      */ 
/*      */     
/* 2146 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static BufferedImage scaleImageIncrementally(BufferedImage src, int targetWidth, int targetHeight, Method scalingMethod, Object interpolationHintValue) {
/* 2181 */     boolean hasReassignedSrc = false;
/* 2182 */     int incrementCount = 0;
/* 2183 */     int currentWidth = src.getWidth();
/* 2184 */     int currentHeight = src.getHeight();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2216 */     int fraction = (scalingMethod == Method.ULTRA_QUALITY) ? 7 : 2;
/*      */     
/*      */     do {
/* 2219 */       int prevCurrentWidth = currentWidth;
/* 2220 */       int prevCurrentHeight = currentHeight;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2226 */       if (currentWidth > targetWidth) {
/* 2227 */         currentWidth -= currentWidth / fraction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2233 */         if (currentWidth < targetWidth) {
/* 2234 */           currentWidth = targetWidth;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2242 */       if (currentHeight > targetHeight) {
/* 2243 */         currentHeight -= currentHeight / fraction;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2250 */         if (currentHeight < targetHeight) {
/* 2251 */           currentHeight = targetHeight;
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2266 */       if (prevCurrentWidth == currentWidth && prevCurrentHeight == currentHeight) {
/*      */         break;
/*      */       }
/*      */       
/* 2270 */       if (DEBUG) {
/* 2271 */         log(2, "Scaling from [%d x %d] to [%d x %d]", new Object[] { Integer.valueOf(prevCurrentWidth), Integer.valueOf(prevCurrentHeight), Integer.valueOf(currentWidth), Integer.valueOf(currentHeight) });
/*      */       }
/*      */ 
/*      */       
/* 2275 */       BufferedImage incrementalImage = scaleImage(src, currentWidth, currentHeight, interpolationHintValue);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2288 */       if (hasReassignedSrc) {
/* 2289 */         src.flush();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2296 */       src = incrementalImage;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2303 */       hasReassignedSrc = true;
/*      */ 
/*      */       
/* 2306 */       incrementCount++;
/* 2307 */     } while (currentWidth != targetWidth || currentHeight != targetHeight);
/*      */     
/* 2309 */     if (DEBUG) {
/* 2310 */       log(2, "Incrementally Scaled Image in %d steps.", new Object[] { Integer.valueOf(incrementCount) });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2316 */     return src;
/*      */   }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/imgscalr-lib-4.2.jar!/org/imgscalr/Scalr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */