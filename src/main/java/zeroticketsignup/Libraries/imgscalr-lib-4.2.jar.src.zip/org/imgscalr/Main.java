/*    */ package org.imgscalr;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.ConvolveOp;
/*    */ import java.awt.image.Kernel;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */ {
/* 19 */   static ConvolveOp OP_ANTIALIAS = new ConvolveOp(new Kernel(2, 2, new float[] { 0.25F, 0.25F, 0.25F, 0.25F }), 1, null);
/*    */ 
/*    */ 
/*    */   
/*    */   public static void main(String[] args) throws IOException {
/* 24 */     BufferedImage i = ImageIO.read(Main.class.getResourceAsStream("imgscalr-mac.png"));
/*    */ 
/*    */     
/* 27 */     System.setProperty("imgscalr.debug", "true");
/*    */     
/* 29 */     ImageIO.write(Scalr.resize(i, Scalr.Mode.FIT_EXACT, 500, 250, new java.awt.image.BufferedImageOp[0]), "PNG", new FileOutputStream("imgscalr-mac-fit-exact-500x250.png"));
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/imgscalr-lib-4.2.jar!/org/imgscalr/Main.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */