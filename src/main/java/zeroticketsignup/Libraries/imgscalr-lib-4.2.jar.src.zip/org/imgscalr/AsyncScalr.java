/*     */ package org.imgscalr;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.BufferedImageOp;
/*     */ import java.awt.image.ImagingOpException;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.atomic.AtomicInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncScalr
/*     */ {
/*     */   public static final String THREAD_COUNT_PROPERTY_NAME = "imgscalr.async.threadCount";
/* 189 */   public static final int THREAD_COUNT = Integer.getInteger("imgscalr.async.threadCount", 2).intValue();
/*     */ 
/*     */   
/*     */   protected static ExecutorService service;
/*     */ 
/*     */   
/*     */   static  {
/* 196 */     if (THREAD_COUNT < 1) {
/* 197 */       throw new RuntimeException("System property 'imgscalr.async.threadCount' set THREAD_COUNT to " + THREAD_COUNT + ", but THREAD_COUNT must be > 0.");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 225 */   public static ExecutorService getService() { return service; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> apply(final BufferedImage src, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 234 */     checkService();
/*     */     
/* 236 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 238 */           public BufferedImage call() throws Exception { return Scalr.apply(src, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> crop(final BufferedImage src, final int width, final int height, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 249 */     checkService();
/*     */     
/* 251 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 253 */           public BufferedImage call() throws Exception { return Scalr.crop(src, width, height, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> crop(final BufferedImage src, final int x, final int y, final int width, final int height, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 265 */     checkService();
/*     */     
/* 267 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 269 */           public BufferedImage call() throws Exception { return Scalr.crop(src, x, y, width, height, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> pad(final BufferedImage src, final int padding, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 280 */     checkService();
/*     */     
/* 282 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 284 */           public BufferedImage call() throws Exception { return Scalr.pad(src, padding, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> pad(final BufferedImage src, final int padding, final Color color, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 295 */     checkService();
/*     */     
/* 297 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 299 */           public BufferedImage call() throws Exception { return Scalr.pad(src, padding, color, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 310 */     checkService();
/*     */     
/* 312 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 314 */           public BufferedImage call() throws Exception { return Scalr.resize(src, targetSize, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final Scalr.Method scalingMethod, final int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 326 */     checkService();
/*     */     
/* 328 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 330 */           public BufferedImage call() throws Exception { return Scalr.resize(src, scalingMethod, targetSize, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final Scalr.Mode resizeMode, final int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 342 */     checkService();
/*     */     
/* 344 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 346 */           public BufferedImage call() throws Exception { return Scalr.resize(src, resizeMode, targetSize, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final Scalr.Method scalingMethod, final Scalr.Mode resizeMode, final int targetSize, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 358 */     checkService();
/*     */     
/* 360 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 362 */           public BufferedImage call() throws Exception { return Scalr.resize(src, scalingMethod, resizeMode, targetSize, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final int targetWidth, final int targetHeight, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 375 */     checkService();
/*     */     
/* 377 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 379 */           public BufferedImage call() throws Exception { return Scalr.resize(src, targetWidth, targetHeight, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final Scalr.Method scalingMethod, final int targetWidth, final int targetHeight, BufferedImageOp... ops) {
/* 390 */     checkService();
/*     */     
/* 392 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 394 */           public BufferedImage call() throws Exception { return Scalr.resize(src, scalingMethod, targetWidth, targetHeight, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final Scalr.Mode resizeMode, final int targetWidth, final int targetHeight, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 407 */     checkService();
/*     */     
/* 409 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 411 */           public BufferedImage call() throws Exception { return Scalr.resize(src, resizeMode, targetWidth, targetHeight, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> resize(final BufferedImage src, final Scalr.Method scalingMethod, final Scalr.Mode resizeMode, final int targetWidth, final int targetHeight, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 426 */     checkService();
/*     */     
/* 428 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 430 */           public BufferedImage call() throws Exception { return Scalr.resize(src, scalingMethod, resizeMode, targetWidth, targetHeight, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Future<BufferedImage> rotate(final BufferedImage src, final Scalr.Rotation rotation, BufferedImageOp... ops) throws IllegalArgumentException, ImagingOpException {
/* 442 */     checkService();
/*     */     
/* 444 */     return service.submit(new Callable<BufferedImage>()
/*     */         {
/* 446 */           public BufferedImage call() throws Exception { return Scalr.rotate(src, rotation, ops); }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 452 */   protected static ExecutorService createService() { return createService(new DefaultThreadFactory()); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static ExecutorService createService(ThreadFactory factory) throws IllegalArgumentException {
/* 457 */     if (factory == null) {
/* 458 */       throw new IllegalArgumentException("factory cannot be null");
/*     */     }
/* 460 */     return Executors.newFixedThreadPool(THREAD_COUNT, factory);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static void checkService() {
/* 477 */     if (service == null || service.isShutdown() || service.isTerminated())
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 483 */       service = createService();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class DefaultThreadFactory
/*     */     implements ThreadFactory
/*     */   {
/* 501 */     protected static final AtomicInteger poolNumber = new AtomicInteger(1);
/*     */     
/*     */     protected final ThreadGroup group;
/* 504 */     protected final AtomicInteger threadNumber = new AtomicInteger(1);
/*     */     protected final String namePrefix;
/*     */     
/*     */     DefaultThreadFactory() {
/* 508 */       SecurityManager manager = System.getSecurityManager();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 514 */       this.group = (manager == null) ? Thread.currentThread().getThreadGroup() : manager.getThreadGroup();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 521 */       this.namePrefix = "pool-" + poolNumber.getAndIncrement() + "-thread-";
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Thread newThread(Runnable r) {
/* 536 */       Thread thread = new Thread(this.group, r, this.namePrefix + this.threadNumber.getAndIncrement(), 0L);
/*     */ 
/*     */ 
/*     */       
/* 540 */       thread.setDaemon(false);
/* 541 */       thread.setPriority(5);
/*     */       
/* 543 */       return thread;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static class ServerThreadFactory
/*     */     extends DefaultThreadFactory
/*     */   {
/*     */     public Thread newThread(Runnable r) {
/* 571 */       Thread thread = super.newThread(r);
/*     */       
/* 573 */       thread.setDaemon(true);
/* 574 */       thread.setPriority(1);
/*     */       
/* 576 */       return thread;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/imgscalr-lib-4.2.jar!/org/imgscalr/AsyncScalr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */