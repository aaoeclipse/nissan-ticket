/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstNot
/*    */   extends SimpleNode
/*    */ {
/* 20 */   public AstNot(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 25 */   public Class getType(EvaluationContext ctx) throws ELException { return Boolean.class; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 30 */     Object obj = this.children[0].getValue(ctx);
/* 31 */     if (obj == ELContext.UNRESOLVABLE_RESULT) {
/* 32 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 34 */     Boolean b = coerceToBoolean(obj);
/* 35 */     return Boolean.valueOf(!b.booleanValue());
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstNot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */