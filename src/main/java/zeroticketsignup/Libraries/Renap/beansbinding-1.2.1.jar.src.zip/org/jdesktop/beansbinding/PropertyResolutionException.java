/*    */ package org.jdesktop.beansbinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertyResolutionException
/*    */   extends RuntimeException
/*    */ {
/* 28 */   public PropertyResolutionException(String message) { super(message); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   public PropertyResolutionException(String message, Exception reason) { super(message, reason); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/PropertyResolutionException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */