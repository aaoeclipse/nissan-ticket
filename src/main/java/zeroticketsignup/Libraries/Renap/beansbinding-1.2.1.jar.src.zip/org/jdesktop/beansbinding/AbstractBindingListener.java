/*    */ package org.jdesktop.beansbinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractBindingListener
/*    */   implements BindingListener
/*    */ {
/*    */   public void bindingBecameBound(Binding binding) {}
/*    */   
/*    */   public void bindingBecameUnbound(Binding binding) {}
/*    */   
/*    */   public void syncFailed(Binding binding, Binding.SyncFailure failure) {}
/*    */   
/*    */   public void synced(Binding binding) {}
/*    */   
/*    */   public void sourceChanged(Binding binding, PropertyStateEvent event) {
/* 44 */     if (event.getValueChanged()) {
/* 45 */       sourceEdited(binding);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void targetChanged(Binding binding, PropertyStateEvent event) {
/* 56 */     if (event.getValueChanged())
/* 57 */       targetEdited(binding); 
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public void sourceEdited(Binding binding) {}
/*    */   
/*    */   @Deprecated
/*    */   public void targetEdited(Binding binding) {}
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/AbstractBindingListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */