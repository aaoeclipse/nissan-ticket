package org.jdesktop.el.impl.parser;

import org.jdesktop.el.ELException;

public interface NodeVisitor {
  void visit(Node paramNode) throws ELException;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/NodeVisitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */