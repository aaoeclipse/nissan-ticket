package org.jdesktop.observablecollections;

public interface ObservableMapListener {
  void mapKeyValueChanged(ObservableMap paramObservableMap, Object paramObject1, Object paramObject2);
  
  void mapKeyAdded(ObservableMap paramObservableMap, Object paramObject);
  
  void mapKeyRemoved(ObservableMap paramObservableMap, Object paramObject1, Object paramObject2);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/observablecollections/ObservableMapListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */