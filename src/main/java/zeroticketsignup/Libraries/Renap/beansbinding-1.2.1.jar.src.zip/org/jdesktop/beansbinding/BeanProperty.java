/*      */ package org.jdesktop.beansbinding;
/*      */ 
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.EventSetDescriptor;
/*      */ import java.beans.IntrospectionException;
/*      */ import java.beans.Introspector;
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.IdentityHashMap;
/*      */ import java.util.Map;
/*      */ import org.jdesktop.beansbinding.ext.BeanAdapterFactory;
/*      */ import org.jdesktop.observablecollections.ObservableMap;
/*      */ import org.jdesktop.observablecollections.ObservableMapListener;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class BeanProperty<S, V>
/*      */   extends PropertyHelper<S, V>
/*      */ {
/*      */   private Property<S, ?> baseProperty;
/*      */   private final PropertyPath path;
/*      */   private IdentityHashMap<S, SourceEntry> map;
/*  148 */   private static final Object NOREAD = new Object();
/*      */   private static final boolean LOG = false;
/*      */   
/*      */   private final class SourceEntry
/*      */     implements PropertyChangeListener, ObservableMapListener, PropertyStateListener
/*      */   {
/*      */     private S source;
/*      */     private Object cachedBean;
/*      */     private Object[] cache;
/*      */     private Object cachedValue;
/*      */     private Object cachedWriter;
/*      */     private boolean ignoreChange;
/*      */     
/*      */     private SourceEntry(S source) {
/*  162 */       this.source = source;
/*  163 */       this.cache = new Object[BeanProperty.this.path.length()];
/*  164 */       this.cache[0] = NOREAD;
/*      */       
/*  166 */       if (BeanProperty.this.baseProperty != null) {
/*  167 */         BeanProperty.this.baseProperty.addPropertyStateListener(source, this);
/*      */       }
/*      */       
/*  170 */       updateCachedBean();
/*  171 */       updateCachedSources(0);
/*  172 */       updateCachedValue();
/*  173 */       updateCachedWriter();
/*      */     }
/*      */     
/*      */     private void cleanup() {
/*  177 */       for (int i = 0; i < BeanProperty.this.path.length(); i++) {
/*  178 */         BeanProperty.this.unregisterListener(this.cache[i], BeanProperty.this.path.get(i), this);
/*      */       }
/*      */       
/*  181 */       if (BeanProperty.this.baseProperty != null) {
/*  182 */         BeanProperty.this.baseProperty.removePropertyStateListener(this.source, this);
/*      */       }
/*      */       
/*  185 */       this.cachedBean = null;
/*  186 */       this.cache = null;
/*  187 */       this.cachedValue = null;
/*  188 */       this.cachedWriter = null;
/*      */     }
/*      */ 
/*      */     
/*  192 */     private boolean cachedIsReadable() { return (this.cachedValue != NOREAD); }
/*      */ 
/*      */ 
/*      */     
/*  196 */     private boolean cachedIsWriteable() { return (this.cachedWriter != null); }
/*      */ 
/*      */     
/*      */     private int getSourceIndex(Object object) {
/*  200 */       for (int i = 0; i < this.cache.length; i++) {
/*  201 */         if (this.cache[i] == object) {
/*  202 */           return i;
/*      */         }
/*      */       } 
/*      */       
/*  206 */       if (object instanceof Map) {
/*  207 */         return -1;
/*      */       }
/*      */       
/*  210 */       for (int i = 0; i < this.cache.length; i++) {
/*  211 */         if (this.cache[i] != null) {
/*  212 */           Object adapter = BeanProperty.this.getAdapter(this.cache[i], BeanProperty.this.path.get(i));
/*  213 */           if (adapter == object) {
/*  214 */             return i;
/*      */           }
/*      */         } 
/*      */       } 
/*      */       
/*  219 */       return -1;
/*      */     }
/*      */ 
/*      */     
/*  223 */     private void updateCachedBean() { this.cachedBean = BeanProperty.this.getBeanFromSource(this.source); }
/*      */ 
/*      */     
/*      */     private void updateCachedSources(int index) {
/*  227 */       boolean loggedYet = false;
/*      */ 
/*      */ 
/*      */       
/*  231 */       if (index == 0) {
/*  232 */         Object src = this.cachedBean;
/*      */         
/*  234 */         if (this.cache[0] != src) {
/*  235 */           BeanProperty.this.unregisterListener(this.cache[0], BeanProperty.this.path.get(0), this);
/*      */           
/*  237 */           this.cache[0] = src;
/*      */           
/*  239 */           if (src == null) {
/*  240 */             loggedYet = true;
/*  241 */             BeanProperty.log("updateCachedSources()", "source is null");
/*      */           } else {
/*  243 */             BeanProperty.this.registerListener(src, BeanProperty.this.path.get(0), this);
/*      */           } 
/*      */         } 
/*      */         
/*  247 */         index++;
/*      */       } 
/*      */       
/*  250 */       for (int i = index; i < BeanProperty.this.path.length(); i++) {
/*  251 */         Object old = this.cache[i];
/*  252 */         Object src = BeanProperty.this.getProperty(this.cache[i - 1], BeanProperty.this.path.get(i - 1));
/*      */         
/*  254 */         if (src != old) {
/*  255 */           BeanProperty.this.unregisterListener(old, BeanProperty.this.path.get(i), this);
/*      */           
/*  257 */           this.cache[i] = src;
/*      */           
/*  259 */           if (src == null) {
/*  260 */             if (!loggedYet) {
/*  261 */               loggedYet = true;
/*  262 */               BeanProperty.log("updateCachedSources()", "missing source");
/*      */             } 
/*  264 */           } else if (src == NOREAD) {
/*  265 */             if (!loggedYet) {
/*  266 */               loggedYet = true;
/*  267 */               BeanProperty.log("updateCachedSources()", "missing read method");
/*      */             } 
/*      */           } else {
/*  270 */             BeanProperty.this.registerListener(src, BeanProperty.this.path.get(i), this);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void validateCache(int ignore) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void updateCachedWriter() {
/*  323 */       Object src = this.cache[BeanProperty.this.path.length() - 1];
/*  324 */       if (src == null || src == NOREAD) {
/*  325 */         this.cachedWriter = null;
/*      */       } else {
/*  327 */         this.cachedWriter = BeanProperty.this.getWriter(src, BeanProperty.this.path.getLast());
/*  328 */         if (this.cachedWriter == null) {
/*  329 */           BeanProperty.log("updateCachedWriter()", "missing write method");
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     private void updateCachedValue() {
/*  335 */       Object src = this.cache[BeanProperty.this.path.length() - 1];
/*  336 */       if (src == null || src == NOREAD) {
/*  337 */         this.cachedValue = NOREAD;
/*      */       } else {
/*  339 */         this.cachedValue = BeanProperty.this.getProperty(this.cache[BeanProperty.this.path.length() - 1], BeanProperty.this.path.getLast());
/*  340 */         if (this.cachedValue == NOREAD) {
/*  341 */           BeanProperty.log("updateCachedValue()", "missing read method");
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/*      */     private void bindingPropertyChanged(PropertyStateEvent pse) {
/*  347 */       validateCache(0);
/*  348 */       Object oldValue = this.cachedValue;
/*  349 */       boolean wasWriteable = cachedIsWriteable();
/*  350 */       updateCachedBean();
/*  351 */       updateCachedSources(0);
/*  352 */       updateCachedValue();
/*  353 */       updateCachedWriter();
/*  354 */       BeanProperty.this.notifyListeners(wasWriteable, oldValue, this);
/*      */     }
/*      */     
/*      */     private void cachedValueChanged(int index) {
/*  358 */       validateCache(index);
/*      */       
/*  360 */       boolean wasWriteable = cachedIsWriteable();
/*  361 */       Object oldValue = this.cachedValue;
/*      */       
/*  363 */       updateCachedSources(index);
/*  364 */       updateCachedValue();
/*  365 */       if (index != BeanProperty.this.path.length()) {
/*  366 */         updateCachedWriter();
/*      */       }
/*      */       
/*  369 */       BeanProperty.this.notifyListeners(wasWriteable, oldValue, this);
/*      */     }
/*      */     
/*      */     private void mapValueChanged(ObservableMap map, Object key) {
/*  373 */       if (this.ignoreChange) {
/*      */         return;
/*      */       }
/*      */       
/*  377 */       int index = getSourceIndex(map);
/*      */       
/*  379 */       if (index == -1) {
/*  380 */         throw new AssertionError();
/*      */       }
/*      */       
/*  383 */       if (key.equals(BeanProperty.this.path.get(index))) {
/*  384 */         cachedValueChanged(index + 1);
/*      */       }
/*      */     }
/*      */     
/*      */     public void propertyStateChanged(PropertyStateEvent pe) {
/*  389 */       if (!pe.getValueChanged()) {
/*      */         return;
/*      */       }
/*      */       
/*  393 */       bindingPropertyChanged(pe);
/*      */     }
/*      */     
/*      */     private void propertyValueChanged(PropertyChangeEvent pce) {
/*  397 */       if (this.ignoreChange) {
/*      */         return;
/*      */       }
/*      */       
/*  401 */       int index = getSourceIndex(pce.getSource());
/*      */       
/*  403 */       if (index == -1) {
/*  404 */         throw new AssertionError();
/*      */       }
/*      */       
/*  407 */       String propertyName = pce.getPropertyName();
/*  408 */       if (propertyName == null || BeanProperty.this.path.get(index).equals(propertyName)) {
/*  409 */         cachedValueChanged(index + 1);
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*  414 */     public void propertyChange(PropertyChangeEvent e) { propertyValueChanged(e); }
/*      */ 
/*      */ 
/*      */     
/*  418 */     public void mapKeyValueChanged(ObservableMap map, Object key, Object lastValue) { mapValueChanged(map, key); }
/*      */ 
/*      */ 
/*      */     
/*  422 */     public void mapKeyAdded(ObservableMap map, Object key) { mapValueChanged(map, key); }
/*      */ 
/*      */ 
/*      */     
/*  426 */     public void mapKeyRemoved(ObservableMap map, Object key, Object value) { mapValueChanged(map, key); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  439 */   public static final <S, V> BeanProperty<S, V> create(String path) { return new BeanProperty<S, V>(null, path); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  453 */   public static final <S, V> BeanProperty<S, V> create(Property<S, ?> baseProperty, String path) { return new BeanProperty<S, V>(baseProperty, path); }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private BeanProperty(Property<S, ?> baseProperty, String path) {
/*      */     this.map = new IdentityHashMap<S, SourceEntry>();
/*  460 */     this.path = PropertyPath.createPropertyPath(path);
/*  461 */     this.baseProperty = baseProperty;
/*      */   }
/*      */   
/*      */   private Object getLastSource(S source) {
/*  465 */     Object src = getBeanFromSource(source);
/*      */     
/*  467 */     if (src == null || src == NOREAD) {
/*  468 */       return src;
/*      */     }
/*      */     
/*  471 */     for (int i = 0; i < this.path.length() - 1; i++) {
/*  472 */       src = getProperty(src, this.path.get(i));
/*  473 */       if (src == null) {
/*  474 */         log("getLastSource()", "missing source");
/*  475 */         return null;
/*      */       } 
/*      */       
/*  478 */       if (src == NOREAD) {
/*  479 */         log("getLastSource()", "missing read method");
/*  480 */         return NOREAD;
/*      */       } 
/*      */     } 
/*      */     
/*  484 */     return src;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Class<? extends V> getWriteType(S source) {
/*  498 */     SourceEntry entry = this.map.get(source);
/*      */     
/*  500 */     if (entry != null) {
/*  501 */       entry.validateCache(-1);
/*      */       
/*  503 */       if (entry.cachedWriter == null) {
/*  504 */         throw new UnsupportedOperationException("Unwriteable");
/*      */       }
/*      */       
/*  507 */       return (Class)getType(entry.cache[this.path.length() - 1], this.path.getLast());
/*      */     } 
/*      */     
/*  510 */     return (Class)getType(getLastSource(source), this.path.getLast());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public V getValue(S source) {
/*  523 */     SourceEntry entry = this.map.get(source);
/*      */     
/*  525 */     if (entry != null) {
/*  526 */       entry.validateCache(-1);
/*      */       
/*  528 */       if (entry.cachedValue == NOREAD) {
/*  529 */         throw new UnsupportedOperationException("Unreadable");
/*      */       }
/*      */       
/*  532 */       return (V)entry.cachedValue;
/*      */     } 
/*      */     
/*  535 */     Object src = getLastSource(source);
/*  536 */     if (src == null || src == NOREAD) {
/*  537 */       throw new UnsupportedOperationException("Unreadable");
/*      */     }
/*      */     
/*  540 */     src = getProperty(src, this.path.getLast());
/*  541 */     if (src == NOREAD) {
/*  542 */       log("getValue()", "missing read method");
/*  543 */       throw new UnsupportedOperationException("Unreadable");
/*      */     } 
/*      */     
/*  546 */     return (V)src;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setValue(S source, V value) {
/*  560 */     SourceEntry entry = this.map.get(source);
/*      */     
/*  562 */     if (entry != null) {
/*  563 */       entry.validateCache(-1);
/*      */       
/*  565 */       if (entry.cachedWriter == null) {
/*  566 */         throw new UnsupportedOperationException("Unwritable");
/*      */       }
/*      */       
/*      */       try {
/*  570 */         entry.ignoreChange = true;
/*  571 */         write(entry.cachedWriter, entry.cache[this.path.length() - 1], this.path.getLast(), value);
/*      */       } finally {
/*  573 */         entry.ignoreChange = false;
/*      */       } 
/*      */       
/*  576 */       Object oldValue = entry.cachedValue;
/*  577 */       entry.updateCachedValue();
/*  578 */       notifyListeners(entry.cachedIsWriteable(), oldValue, entry);
/*      */     } else {
/*  580 */       setProperty(getLastSource(source), this.path.getLast(), value);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isReadable(S source) {
/*  594 */     SourceEntry entry = this.map.get(source);
/*      */     
/*  596 */     if (entry != null) {
/*  597 */       entry.validateCache(-1);
/*  598 */       return entry.cachedIsReadable();
/*      */     } 
/*      */     
/*  601 */     Object src = getLastSource(source);
/*  602 */     if (src == null || src == NOREAD) {
/*  603 */       return false;
/*      */     }
/*      */     
/*  606 */     Object reader = getReader(src, this.path.getLast());
/*  607 */     if (reader == null) {
/*  608 */       log("isReadable()", "missing read method");
/*  609 */       return false;
/*      */     } 
/*      */     
/*  612 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isWriteable(S source) {
/*  625 */     SourceEntry entry = this.map.get(source);
/*      */     
/*  627 */     if (entry != null) {
/*  628 */       entry.validateCache(-1);
/*  629 */       return entry.cachedIsWriteable();
/*      */     } 
/*      */     
/*  632 */     Object src = getLastSource(source);
/*  633 */     if (src == null || src == NOREAD) {
/*  634 */       return false;
/*      */     }
/*      */     
/*  637 */     Object writer = getWriter(src, this.path.getLast());
/*  638 */     if (writer == null) {
/*  639 */       log("isWritable()", "missing write method");
/*  640 */       return false;
/*      */     } 
/*      */     
/*  643 */     return true;
/*      */   }
/*      */   
/*      */   private Object getBeanFromSource(S source) {
/*  647 */     if (this.baseProperty == null) {
/*  648 */       if (source == null) {
/*  649 */         log("getBeanFromSource()", "source is null");
/*      */       }
/*      */       
/*  652 */       return source;
/*      */     } 
/*      */     
/*  655 */     if (!this.baseProperty.isReadable(source)) {
/*  656 */       log("getBeanFromSource()", "unreadable source property");
/*  657 */       return NOREAD;
/*      */     } 
/*      */     
/*  660 */     Object bean = this.baseProperty.getValue(source);
/*  661 */     if (bean == null) {
/*  662 */       log("getBeanFromSource()", "source property returned null");
/*  663 */       return null;
/*      */     } 
/*      */     
/*  666 */     return bean;
/*      */   }
/*      */   
/*      */   protected final void listeningStarted(S source) {
/*  670 */     SourceEntry entry = this.map.get(source);
/*  671 */     if (entry == null) {
/*  672 */       entry = new SourceEntry(source);
/*  673 */       this.map.put(source, entry);
/*      */     } 
/*      */   }
/*      */   
/*      */   protected final void listeningStopped(S source) {
/*  678 */     SourceEntry entry = this.map.remove(source);
/*  679 */     if (entry != null) {
/*  680 */       entry.cleanup();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*  685 */   private static boolean didValueChange(Object oldValue, Object newValue) { return (oldValue == null || newValue == null || !oldValue.equals(newValue)); }
/*      */ 
/*      */   
/*      */   private void notifyListeners(boolean wasWriteable, Object oldValue, SourceEntry entry) {
/*  689 */     PropertyStateListener[] listeners = getPropertyStateListeners(entry.source);
/*      */     
/*  691 */     if (listeners == null || listeners.length == 0) {
/*      */       return;
/*      */     }
/*      */     
/*  695 */     oldValue = toUNREADABLE(oldValue);
/*  696 */     Object newValue = toUNREADABLE(entry.cachedValue);
/*  697 */     boolean valueChanged = didValueChange(oldValue, newValue);
/*  698 */     boolean writeableChanged = (wasWriteable != entry.cachedIsWriteable());
/*      */     
/*  700 */     if (!valueChanged && !writeableChanged) {
/*      */       return;
/*      */     }
/*      */     
/*  704 */     PropertyStateEvent pse = new PropertyStateEvent(this, entry.source, valueChanged, oldValue, newValue, writeableChanged, entry.cachedIsWriteable());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  712 */     firePropertyStateChange(pse);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  725 */   public String toString() { return getClass().getName() + "[" + this.path + "]"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static BeanInfo getBeanInfo(Object object) {
/*  732 */     assert object != null;
/*      */ 
/*      */     
/*      */     try {
/*  736 */       return Introspector.getBeanInfo(object.getClass(), 3);
/*  737 */     } catch (IntrospectionException ie) {
/*  738 */       throw new PropertyResolutionException("Exception while introspecting " + object.getClass().getName(), ie);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static PropertyDescriptor getPropertyDescriptor(Object object, String string) {
/*  746 */     assert object != null;
/*      */     
/*  748 */     PropertyDescriptor[] pds = getBeanInfo(object).getPropertyDescriptors();
/*  749 */     if (pds == null) {
/*  750 */       return null;
/*      */     }
/*      */     
/*  753 */     for (PropertyDescriptor pd : pds) {
/*  754 */       if (!(pd instanceof java.beans.IndexedPropertyDescriptor) && pd.getName().equals(string)) {
/*  755 */         return pd;
/*      */       }
/*      */     } 
/*      */     
/*  759 */     return null;
/*      */   }
/*      */   
/*      */   private static EventSetDescriptor getEventSetDescriptor(Object object) {
/*  763 */     assert object != null;
/*      */     
/*  765 */     EventSetDescriptor[] eds = getBeanInfo(object).getEventSetDescriptors();
/*  766 */     for (EventSetDescriptor ed : eds) {
/*  767 */       if (ed.getListenerType() == PropertyChangeListener.class) {
/*  768 */         return ed;
/*      */       }
/*      */     } 
/*      */     
/*  772 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object invokeMethod(Method method, Object object, Object... args) {
/*  779 */     Exception reason = null;
/*      */     
/*      */     try {
/*  782 */       return method.invoke(object, args);
/*  783 */     } catch (IllegalArgumentException ex) {
/*  784 */       reason = ex;
/*  785 */     } catch (IllegalAccessException ex) {
/*  786 */       reason = ex;
/*  787 */     } catch (InvocationTargetException ex) {
/*  788 */       reason = ex;
/*      */     } 
/*      */     
/*  791 */     throw new PropertyResolutionException("Exception invoking method " + method + " on " + object, reason);
/*      */   }
/*      */   
/*      */   private Object getReader(Object object, String string) {
/*  795 */     assert object != null;
/*      */     
/*  797 */     if (object instanceof Map) {
/*  798 */       return object;
/*      */     }
/*      */     
/*  801 */     object = getAdapter(object, string);
/*      */     
/*  803 */     PropertyDescriptor pd = getPropertyDescriptor(object, string);
/*  804 */     Method readMethod = null;
/*  805 */     return (pd == null) ? null : pd.getReadMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object read(Object reader, Object object, String string) {
/*  812 */     assert reader != null;
/*      */     
/*  814 */     if (reader instanceof Map) {
/*  815 */       assert reader == object;
/*  816 */       return ((Map)reader).get(string);
/*      */     } 
/*      */     
/*  819 */     object = getAdapter(object, string);
/*      */     
/*  821 */     return invokeMethod((Method)reader, object, new Object[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getProperty(Object object, String string) {
/*  828 */     if (object == null || object == NOREAD) {
/*  829 */       return NOREAD;
/*      */     }
/*      */     
/*  832 */     Object reader = getReader(object, string);
/*  833 */     if (reader == null) {
/*  834 */       return NOREAD;
/*      */     }
/*      */     
/*  837 */     return read(reader, object, string);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Class<?> getType(Object object, String string) {
/*  844 */     if (object == null || object == NOREAD) {
/*  845 */       throw new UnsupportedOperationException("Unwritable");
/*      */     }
/*      */     
/*  848 */     if (object instanceof Map) {
/*  849 */       return Object.class;
/*      */     }
/*      */     
/*  852 */     object = getAdapter(object, string);
/*      */     
/*  854 */     PropertyDescriptor pd = getPropertyDescriptor(object, string);
/*  855 */     if (pd == null || pd.getWriteMethod() == null) {
/*  856 */       log("getType()", "missing write method");
/*  857 */       throw new UnsupportedOperationException("Unwritable");
/*      */     } 
/*      */     
/*  860 */     return pd.getPropertyType();
/*      */   }
/*      */   
/*      */   private Object getWriter(Object object, String string) {
/*  864 */     assert object != null;
/*      */     
/*  866 */     if (object instanceof Map) {
/*  867 */       return object;
/*      */     }
/*      */     
/*  870 */     object = getAdapter(object, string);
/*      */     
/*  872 */     PropertyDescriptor pd = getPropertyDescriptor(object, string);
/*  873 */     Method writeMethod = null;
/*  874 */     return (pd == null) ? null : pd.getWriteMethod();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void write(Object writer, Object object, String string, Object value) {
/*  881 */     assert writer != null;
/*      */     
/*  883 */     if (writer instanceof Map) {
/*  884 */       assert writer == object;
/*  885 */       ((Map<String, Object>)writer).put(string, value);
/*      */       
/*      */       return;
/*      */     } 
/*  889 */     object = getAdapter(object, string);
/*      */     
/*  891 */     invokeMethod((Method)writer, object, new Object[] { value });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setProperty(Object object, String string, Object value) {
/*  899 */     if (object == null || object == NOREAD) {
/*  900 */       throw new UnsupportedOperationException("Unwritable");
/*      */     }
/*      */     
/*  903 */     Object writer = getWriter(object, string);
/*  904 */     if (writer == null) {
/*  905 */       log("setProperty()", "missing write method");
/*  906 */       throw new UnsupportedOperationException("Unwritable");
/*      */     } 
/*      */     
/*  909 */     write(writer, object, string, value);
/*      */   }
/*      */ 
/*      */   
/*  913 */   private static Object toUNREADABLE(Object src) { return (src == NOREAD) ? PropertyStateEvent.UNREADABLE : src; }
/*      */ 
/*      */   
/*      */   private void registerListener(Object object, String property, SourceEntry entry) {
/*  917 */     assert object != null;
/*      */     
/*  919 */     if (object != NOREAD) {
/*  920 */       if (object instanceof ObservableMap) {
/*  921 */         ((ObservableMap)object).addObservableMapListener(entry);
/*  922 */       } else if (!(object instanceof Map)) {
/*  923 */         object = getAdapter(object, property);
/*  924 */         addPropertyChangeListener(object, entry);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unregisterListener(Object object, String property, SourceEntry entry) {
/*  933 */     if (object != null && object != NOREAD) {
/*  934 */       if (object instanceof ObservableMap) {
/*  935 */         ((ObservableMap)object).removeObservableMapListener(entry);
/*  936 */       } else if (!(object instanceof Map)) {
/*  937 */         object = getAdapter(object, property);
/*  938 */         removePropertyChangeListener(object, entry);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void addPropertyChangeListener(Object object, PropertyChangeListener listener) {
/*  947 */     EventSetDescriptor ed = getEventSetDescriptor(object);
/*  948 */     Method addPCMethod = null;
/*      */     
/*  950 */     if (ed == null || (addPCMethod = ed.getAddListenerMethod()) == null) {
/*  951 */       log("addPropertyChangeListener()", "can't add listener");
/*      */       
/*      */       return;
/*      */     } 
/*  955 */     invokeMethod(addPCMethod, object, new Object[] { listener });
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void removePropertyChangeListener(Object object, PropertyChangeListener listener) {
/*  962 */     EventSetDescriptor ed = getEventSetDescriptor(object);
/*  963 */     Method removePCMethod = null;
/*      */     
/*  965 */     if (ed == null || (removePCMethod = ed.getRemoveListenerMethod()) == null) {
/*  966 */       log("removePropertyChangeListener()", "can't remove listener from source");
/*      */       
/*      */       return;
/*      */     } 
/*  970 */     invokeMethod(removePCMethod, object, new Object[] { listener });
/*      */   }
/*      */   
/*      */   private static boolean wrapsLiteral(Object o) {
/*  974 */     assert o != null;
/*      */     
/*  976 */     return (o instanceof String || o instanceof Byte || o instanceof Character || o instanceof Boolean || o instanceof Short || o instanceof Integer || o instanceof Long || o instanceof Float || o instanceof Double);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean match(Object a, Object b) {
/*  991 */     if (a == b) {
/*  992 */       return true;
/*      */     }
/*      */     
/*  995 */     if (a == null) {
/*  996 */       return false;
/*      */     }
/*      */     
/*  999 */     if (wrapsLiteral(a)) {
/* 1000 */       return a.equals(b);
/*      */     }
/*      */     
/* 1003 */     return false;
/*      */   }
/*      */   
/*      */   private Object getAdapter(Object o, String property) {
/* 1007 */     Object adapter = null;
/* 1008 */     adapter = BeanAdapterFactory.getAdapter(o, property);
/* 1009 */     return (adapter == null) ? o : adapter;
/*      */   }
/*      */   
/*      */   private static void log(String method, String message) {}
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/BeanProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */