/*    */ package org.jdesktop.el.impl;
/*    */ 
/*    */ import java.io.Externalizable;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInput;
/*    */ import java.io.ObjectOutput;
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.PropertyNotWritableException;
/*    */ import org.jdesktop.el.ValueExpression;
/*    */ import org.jdesktop.el.impl.lang.ELSupport;
/*    */ import org.jdesktop.el.impl.util.MessageFactory;
/*    */ import org.jdesktop.el.impl.util.ReflectionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ValueExpressionLiteral
/*    */   extends ValueExpression
/*    */   implements Externalizable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Object value;
/*    */   private Class expectedType;
/*    */   
/*    */   public ValueExpressionLiteral() {}
/*    */   
/*    */   public ValueExpressionLiteral(Object value, Class expectedType) {
/* 36 */     this.value = value;
/* 37 */     this.expectedType = expectedType;
/*    */   }
/*    */   
/*    */   public Object getValue(ELContext context) {
/* 41 */     if (this.expectedType != null) {
/* 42 */       return ELSupport.coerceToType(this.value, this.expectedType);
/*    */     }
/* 44 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/* 48 */   public void setValue(ELContext context, Object value) { throw new PropertyNotWritableException(MessageFactory.get("error.value.literal.write", this.value)); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 53 */   public boolean isReadOnly(ELContext context) { return true; }
/*    */ 
/*    */ 
/*    */   
/* 57 */   public Class getType(ELContext context) { return (this.value != null) ? this.value.getClass() : null; }
/*    */ 
/*    */ 
/*    */   
/* 61 */   public Class getExpectedType() { return this.expectedType; }
/*    */ 
/*    */ 
/*    */   
/* 65 */   public String getExpressionString() { return (this.value != null) ? this.value.toString() : null; }
/*    */ 
/*    */ 
/*    */   
/* 69 */   public boolean equals(Object obj) { return (obj instanceof ValueExpressionLiteral && equals((ValueExpressionLiteral)obj)); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public boolean equals(ValueExpressionLiteral ve) { return (ve != null && this.value != null && ve.value != null && (this.value == ve.value || this.value.equals(ve.value))); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 79 */   public int hashCode() { return (this.value != null) ? this.value.hashCode() : 0; }
/*    */ 
/*    */ 
/*    */   
/* 83 */   public boolean isLiteralText() { return true; }
/*    */ 
/*    */   
/*    */   public void writeExternal(ObjectOutput out) throws IOException {
/* 87 */     out.writeObject(this.value);
/* 88 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 94 */     this.value = in.readObject();
/* 95 */     String type = in.readUTF();
/* 96 */     if (!"".equals(type))
/* 97 */       this.expectedType = ReflectionUtil.forName(type); 
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/ValueExpressionLiteral.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */