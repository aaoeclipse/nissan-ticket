package org.jdesktop.observablecollections;

import java.util.Map;

public interface ObservableMap<K, V> extends Map<K, V> {
  void addObservableMapListener(ObservableMapListener paramObservableMapListener);
  
  void removeObservableMapListener(ObservableMapListener paramObservableMapListener);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/observablecollections/ObservableMap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */