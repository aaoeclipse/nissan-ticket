/*    */ package org.jdesktop.swingbinding.adapters;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.JList;
/*    */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JComboBoxAdapterProvider
/*    */   implements BeanAdapterProvider
/*    */ {
/*    */   private static final String SELECTED_ITEM_P = "selectedItem";
/*    */   
/*    */   public static final class Adapter
/*    */     extends BeanAdapterBase
/*    */   {
/*    */     private JComboBox combo;
/*    */     private Handler handler;
/*    */     private Object cachedItem;
/*    */     
/*    */     private Adapter(JComboBox combo) {
/* 26 */       super("selectedItem");
/* 27 */       this.combo = combo;
/*    */     }
/*    */ 
/*    */     
/* 31 */     public Object getSelectedItem() { return this.combo.getSelectedItem(); }
/*    */ 
/*    */ 
/*    */     
/* 35 */     public void setSelectedItem(Object item) { this.combo.setSelectedItem(item); }
/*    */ 
/*    */     
/*    */     protected void listeningStarted() {
/* 39 */       this.handler = new Handler();
/* 40 */       this.cachedItem = this.combo.getSelectedItem();
/* 41 */       this.combo.addActionListener(this.handler);
/* 42 */       this.combo.addPropertyChangeListener("model", this.handler);
/*    */     }
/*    */     
/*    */     protected void listeningStopped() {
/* 46 */       this.combo.removeActionListener(this.handler);
/* 47 */       this.combo.removePropertyChangeListener("model", this.handler);
/* 48 */       this.handler = null;
/* 49 */       this.cachedItem = null;
/*    */     }
/*    */     
/*    */     private class Handler implements ActionListener, PropertyChangeListener {
/*    */       private void comboSelectionChanged() {
/* 54 */         Object oldValue = JComboBoxAdapterProvider.Adapter.this.cachedItem;
/* 55 */         JComboBoxAdapterProvider.Adapter.this.cachedItem = JComboBoxAdapterProvider.Adapter.this.getSelectedItem();
/* 56 */         JComboBoxAdapterProvider.Adapter.this.firePropertyChange(oldValue, JComboBoxAdapterProvider.Adapter.this.cachedItem);
/*    */       }
/*    */ 
/*    */       
/* 60 */       public void actionPerformed(ActionEvent ae) { comboSelectionChanged(); }
/*    */       
/*    */       private Handler() {}
/*    */       
/* 64 */       public void propertyChange(PropertyChangeEvent pce) { comboSelectionChanged(); }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 70 */   public boolean providesAdapter(Class<?> type, String property) { return (JComboBox.class.isAssignableFrom(type) && property.intern() == "selectedItem"); }
/*    */ 
/*    */   
/*    */   public Object createAdapter(Object source, String property) {
/* 74 */     if (!providesAdapter(source.getClass(), property)) {
/* 75 */       throw new IllegalArgumentException();
/*    */     }
/*    */     
/* 78 */     return new Adapter((JComboBox)source);
/*    */   }
/*    */ 
/*    */   
/* 82 */   public Class<?> getAdapterClass(Class<?> type) { return JList.class.isAssignableFrom(type) ? Adapter.class : null; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/JComboBoxAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */