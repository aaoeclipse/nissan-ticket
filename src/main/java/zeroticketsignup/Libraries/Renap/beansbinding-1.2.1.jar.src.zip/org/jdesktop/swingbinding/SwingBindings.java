/*     */ package org.jdesktop.swingbinding;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JTable;
/*     */ import org.jdesktop.beansbinding.AutoBinding;
/*     */ import org.jdesktop.beansbinding.ObjectProperty;
/*     */ import org.jdesktop.beansbinding.Property;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SwingBindings
/*     */ {
/*  35 */   public static <E> JListBinding<E, List<E>, JList> createJListBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, JList targetJList) { return new JListBinding<E, List<E>, JList>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetJList, (Property<JList, ? extends JList>)ObjectProperty.create(), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static <E> JListBinding<E, List<E>, JList> createJListBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, JList targetJList, String name) { return new JListBinding<E, List<E>, JList>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetJList, (Property<JList, ? extends JList>)ObjectProperty.create(), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public static <E, SS> JListBinding<E, SS, JList> createJListBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, JList targetJList) { return new JListBinding<E, SS, JList>(strategy, sourceObject, sourceListProperty, targetJList, (Property<JList, ? extends JList>)ObjectProperty.create(), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public static <E, SS> JListBinding<E, SS, JList> createJListBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, JList targetJList, String name) { return new JListBinding<E, SS, JList>(strategy, sourceObject, sourceListProperty, targetJList, (Property<JList, ? extends JList>)ObjectProperty.create(), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static <E, TS> JListBinding<E, List<E>, TS> createJListBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, TS targetObject, Property<TS, ? extends JList> targetJListProperty) { return new JListBinding<E, List<E>, TS>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetObject, targetJListProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   public static <E, TS> JListBinding<E, List<E>, TS> createJListBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, TS targetObject, Property<TS, ? extends JList> targetJListProperty, String name) { return new JListBinding<E, List<E>, TS>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetObject, targetJListProperty, name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public static <E, SS, TS> JListBinding<E, SS, TS> createJListBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JList> targetJListProperty) { return new JListBinding<E, SS, TS>(strategy, sourceObject, sourceListProperty, targetObject, targetJListProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 136 */   public static <E, SS, TS> JListBinding<E, SS, TS> createJListBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JList> targetJListProperty, String name) { return new JListBinding<E, SS, TS>(strategy, sourceObject, sourceListProperty, targetObject, targetJListProperty, name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 150 */   public static <E> JTableBinding<E, List<E>, JTable> createJTableBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, JTable targetJTable) { return new JTableBinding<E, List<E>, JTable>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetJTable, (Property<JTable, ? extends JTable>)ObjectProperty.create(), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 162 */   public static <E> JTableBinding<E, List<E>, JTable> createJTableBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, JTable targetJTable, String name) { return new JTableBinding<E, List<E>, JTable>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetJTable, (Property<JTable, ? extends JTable>)ObjectProperty.create(), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 177 */   public static <E, SS> JTableBinding<E, SS, JTable> createJTableBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, JTable targetJTable) { return new JTableBinding<E, SS, JTable>(strategy, sourceObject, sourceListProperty, targetJTable, (Property<JTable, ? extends JTable>)ObjectProperty.create(), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 191 */   public static <E, SS> JTableBinding<E, SS, JTable> createJTableBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, JTable targetJTable, String name) { return new JTableBinding<E, SS, JTable>(strategy, sourceObject, sourceListProperty, targetJTable, (Property<JTable, ? extends JTable>)ObjectProperty.create(), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public static <E, TS> JTableBinding<E, List<E>, TS> createJTableBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, TS targetObject, Property<TS, ? extends JTable> targetJTableProperty) { return new JTableBinding<E, List<E>, TS>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetObject, targetJTableProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   public static <E, TS> JTableBinding<E, List<E>, TS> createJTableBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, TS targetObject, Property<TS, ? extends JTable> targetJTableProperty, String name) { return new JTableBinding<E, List<E>, TS>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetObject, targetJTableProperty, name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 236 */   public static <E, SS, TS> JTableBinding<E, SS, TS> createJTableBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JTable> targetJTableProperty) { return new JTableBinding<E, SS, TS>(strategy, sourceObject, sourceListProperty, targetObject, targetJTableProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 251 */   public static <E, SS, TS> JTableBinding<E, SS, TS> createJTableBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JTable> targetJTableProperty, String name) { return new JTableBinding<E, SS, TS>(strategy, sourceObject, sourceListProperty, targetObject, targetJTableProperty, name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   public static <E> JComboBoxBinding<E, List<E>, JComboBox> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, JComboBox targetJComboBox) { return new JComboBoxBinding<E, List<E>, JComboBox>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetJComboBox, (Property<JComboBox, ? extends JComboBox>)ObjectProperty.create(), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 277 */   public static <E> JComboBoxBinding<E, List<E>, JComboBox> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, JComboBox targetJComboBox, String name) { return new JComboBoxBinding<E, List<E>, JComboBox>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetJComboBox, (Property<JComboBox, ? extends JComboBox>)ObjectProperty.create(), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 292 */   public static <E, SS> JComboBoxBinding<E, SS, JComboBox> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, JComboBox targetJComboBox) { return new JComboBoxBinding<E, SS, JComboBox>(strategy, sourceObject, sourceListProperty, targetJComboBox, (Property<JComboBox, ? extends JComboBox>)ObjectProperty.create(), null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 306 */   public static <E, SS> JComboBoxBinding<E, SS, JComboBox> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, JComboBox targetJComboBox, String name) { return new JComboBoxBinding<E, SS, JComboBox>(strategy, sourceObject, sourceListProperty, targetJComboBox, (Property<JComboBox, ? extends JComboBox>)ObjectProperty.create(), name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 321 */   public static <E, TS> JComboBoxBinding<E, List<E>, TS> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, TS targetObject, Property<TS, ? extends JComboBox> targetJComboBoxProperty) { return new JComboBoxBinding<E, List<E>, TS>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetObject, targetJComboBoxProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 335 */   public static <E, TS> JComboBoxBinding<E, List<E>, TS> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, List<E> sourceList, TS targetObject, Property<TS, ? extends JComboBox> targetJComboBoxProperty, String name) { return new JComboBoxBinding<E, List<E>, TS>(strategy, sourceList, (Property<List<E>, List<E>>)ObjectProperty.create(), targetObject, targetJComboBoxProperty, name); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 351 */   public static <E, SS, TS> JComboBoxBinding<E, SS, TS> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JComboBox> targetJComboBoxProperty) { return new JComboBoxBinding<E, SS, TS>(strategy, sourceObject, sourceListProperty, targetObject, targetJComboBoxProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 366 */   public static <E, SS, TS> JComboBoxBinding<E, SS, TS> createJComboBoxBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JComboBox> targetJComboBoxProperty, String name) { return new JComboBoxBinding<E, SS, TS>(strategy, sourceObject, sourceListProperty, targetObject, targetJComboBoxProperty, name); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/SwingBindings.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */