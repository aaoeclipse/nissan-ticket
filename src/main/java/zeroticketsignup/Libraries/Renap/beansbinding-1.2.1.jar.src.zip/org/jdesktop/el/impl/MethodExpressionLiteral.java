/*    */ package org.jdesktop.el.impl;
/*    */ 
/*    */ import java.io.Externalizable;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInput;
/*    */ import java.io.ObjectOutput;
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.MethodExpression;
/*    */ import org.jdesktop.el.MethodInfo;
/*    */ import org.jdesktop.el.impl.lang.ELSupport;
/*    */ import org.jdesktop.el.impl.util.ReflectionUtil;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodExpressionLiteral
/*    */   extends MethodExpression
/*    */   implements Externalizable
/*    */ {
/*    */   private Class expectedType;
/*    */   private String expr;
/*    */   private Class[] paramTypes;
/*    */   
/*    */   public MethodExpressionLiteral() {}
/*    */   
/*    */   public MethodExpressionLiteral(String expr, Class expectedType, Class[] paramTypes) {
/* 34 */     this.expr = expr;
/* 35 */     this.expectedType = expectedType;
/* 36 */     this.paramTypes = paramTypes;
/*    */   }
/*    */ 
/*    */   
/* 40 */   public MethodInfo getMethodInfo(ELContext context) throws ELException { return new MethodInfo(this.expr, this.expectedType, this.paramTypes); }
/*    */ 
/*    */   
/*    */   public Object invoke(ELContext context, Object[] params) throws ELException {
/* 44 */     if (this.expectedType != null) {
/* 45 */       return ELSupport.coerceToType(this.expr, this.expectedType);
/*    */     }
/* 47 */     return this.expr;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 52 */   public String getExpressionString() { return this.expr; }
/*    */ 
/*    */ 
/*    */   
/* 56 */   public boolean equals(Object obj) { return (obj instanceof MethodExpressionLiteral && hashCode() == obj.hashCode()); }
/*    */ 
/*    */ 
/*    */   
/* 60 */   public int hashCode() { return this.expr.hashCode(); }
/*    */ 
/*    */ 
/*    */   
/* 64 */   public boolean isLiteralText() { return true; }
/*    */ 
/*    */   
/*    */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 68 */     this.expr = in.readUTF();
/* 69 */     String type = in.readUTF();
/* 70 */     if (!"".equals(type)) {
/* 71 */       this.expectedType = ReflectionUtil.forName(type);
/*    */     }
/* 73 */     this.paramTypes = ReflectionUtil.toTypeArray((String[])in.readObject());
/*    */   }
/*    */ 
/*    */   
/*    */   public void writeExternal(ObjectOutput out) throws IOException {
/* 78 */     out.writeUTF(this.expr);
/* 79 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/*    */     
/* 81 */     out.writeObject(ReflectionUtil.toTypeNameArray(this.paramTypes));
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/MethodExpressionLiteral.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */