/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.Expression;
/*     */ import org.jdesktop.el.MethodExpression;
/*     */ import org.jdesktop.el.MethodInfo;
/*     */ import org.jdesktop.el.MethodNotFoundException;
/*     */ import org.jdesktop.el.ValueExpression;
/*     */ import org.jdesktop.el.VariableMapper;
/*     */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstIdentifier
/*     */   extends SimpleNode
/*     */ {
/*  26 */   public AstIdentifier(int id) { super(id); }
/*     */ 
/*     */   
/*     */   public Class getType(EvaluationContext ctx) throws ELException {
/*  30 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  31 */     if (varMapper != null) {
/*  32 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  33 */       if (expr != null) {
/*  34 */         return expr.getType(ctx.getELContext());
/*     */       }
/*     */     } 
/*  37 */     ctx.setPropertyResolved(false);
/*  38 */     return ctx.getELResolver().getType((ELContext)ctx, getSource(ctx), this.image);
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/*  42 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  43 */     if (varMapper != null) {
/*  44 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  45 */       if (expr != null) {
/*  46 */         return expr.getValue(ctx.getELContext());
/*     */       }
/*     */     } 
/*  49 */     ctx.setPropertyResolved(false);
/*  50 */     Object source = getSource(ctx);
/*  51 */     Object retVal = ctx.getELResolver().getValue((ELContext)ctx, source, this.image);
/*  52 */     if (retVal != ELContext.UNRESOLVABLE_RESULT) {
/*  53 */       ctx.resolvedIdentifier(source, this.image);
/*     */     }
/*  55 */     return retVal;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx) throws ELException {
/*  59 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  60 */     if (varMapper != null) {
/*  61 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  62 */       if (expr != null) {
/*  63 */         return expr.isReadOnly(ctx.getELContext());
/*     */       }
/*     */     } 
/*  66 */     ctx.setPropertyResolved(false);
/*  67 */     return ctx.getELResolver().isReadOnly((ELContext)ctx, getSource(ctx), this.image);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value) throws ELException {
/*  72 */     VariableMapper varMapper = ctx.getVariableMapper();
/*  73 */     if (varMapper != null) {
/*  74 */       ValueExpression expr = varMapper.resolveVariable(this.image);
/*  75 */       if (expr != null) {
/*  76 */         expr.setValue(ctx.getELContext(), value);
/*     */         return;
/*     */       } 
/*     */     } 
/*  80 */     ctx.setPropertyResolved(false);
/*  81 */     ctx.getELResolver().setValue((ELContext)ctx, getSource(ctx), this.image, value);
/*     */   }
/*     */ 
/*     */   
/*     */   private final Object invokeTarget(EvaluationContext ctx, Object target, Object[] paramValues) throws ELException {
/*  86 */     if (target instanceof MethodExpression) {
/*  87 */       MethodExpression me = (MethodExpression)target;
/*  88 */       return me.invoke(ctx.getELContext(), paramValues);
/*  89 */     }  if (target == null) {
/*  90 */       throw new MethodNotFoundException("Identity '" + this.image + "' was null and was unable to invoke");
/*     */     }
/*     */     
/*  93 */     throw new ELException("Identity '" + this.image + "' does not reference a MethodExpression instance, returned type: " + target.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public Object invoke(EvaluationContext ctx, Class[] paramTypes, Object[] paramValues) throws ELException { return getMethodExpression(ctx).invoke(ctx.getELContext(), paramValues); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class[] paramTypes) throws ELException { return getMethodExpression(ctx).getMethodInfo(ctx.getELContext()); }
/*     */ 
/*     */ 
/*     */   
/*     */   private final MethodExpression getMethodExpression(EvaluationContext ctx) throws ELException {
/* 114 */     Object obj = null;
/*     */ 
/*     */ 
/*     */     
/* 118 */     VariableMapper varMapper = ctx.getVariableMapper();
/* 119 */     ValueExpression ve = null;
/* 120 */     if (varMapper != null) {
/* 121 */       ve = varMapper.resolveVariable(this.image);
/* 122 */       if (ve != null) {
/* 123 */         obj = ve.getValue((ELContext)ctx);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     if (ve == null) {
/* 130 */       ctx.setPropertyResolved(false);
/* 131 */       obj = ctx.getELResolver().getValue((ELContext)ctx, null, this.image);
/*     */     } 
/*     */ 
/*     */     
/* 135 */     if (obj instanceof MethodExpression)
/* 136 */       return (MethodExpression)obj; 
/* 137 */     if (obj == null) {
/* 138 */       throw new MethodNotFoundException("Identity '" + this.image + "' was null and was unable to invoke");
/*     */     }
/*     */     
/* 141 */     throw new ELException("Identity '" + this.image + "' does not reference a MethodExpression instance, returned type: " + obj.getClass().getName());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object getSource(EvaluationContext ctx) {
/* 150 */     Expression expression = ctx.getExpression();
/* 151 */     if (expression instanceof ValueExpression) {
/* 152 */       return ((ValueExpression)expression).getSource();
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstIdentifier.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */