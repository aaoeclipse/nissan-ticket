package org.jdesktop.el;

import java.beans.FeatureDescriptor;
import java.util.Iterator;

public abstract class ELResolver {
  public static final String TYPE = "type";
  
  public static final String RESOLVABLE_AT_DESIGN_TIME = "resolvableAtDesignTime";
  
  public abstract Object getValue(ELContext paramELContext, Object paramObject1, Object paramObject2);
  
  public abstract Class<?> getType(ELContext paramELContext, Object paramObject1, Object paramObject2);
  
  public abstract void setValue(ELContext paramELContext, Object paramObject1, Object paramObject2, Object paramObject3);
  
  public abstract boolean isReadOnly(ELContext paramELContext, Object paramObject1, Object paramObject2);
  
  public abstract Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext paramELContext, Object paramObject);
  
  public abstract Class<?> getCommonPropertyType(ELContext paramELContext, Object paramObject);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */