/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokenMgrError
/*     */   extends Error
/*     */ {
/*     */   static final int LEXICAL_ERROR = 0;
/*     */   static final int STATIC_LEXER_ERROR = 1;
/*     */   static final int INVALID_LEXICAL_STATE = 2;
/*     */   static final int LOOP_DETECTED = 3;
/*     */   int errorCode;
/*     */   
/*     */   protected static final String addEscapes(String str) {
/*  45 */     StringBuffer retval = new StringBuffer();
/*     */     
/*  47 */     for (int i = 0; i < str.length(); i++) {
/*  48 */       char ch; switch (str.charAt(i)) {
/*     */         case '\000':
/*     */           break;
/*     */         
/*     */         case '\b':
/*  53 */           retval.append("\\b");
/*     */           break;
/*     */         case '\t':
/*  56 */           retval.append("\\t");
/*     */           break;
/*     */         case '\n':
/*  59 */           retval.append("\\n");
/*     */           break;
/*     */         case '\f':
/*  62 */           retval.append("\\f");
/*     */           break;
/*     */         case '\r':
/*  65 */           retval.append("\\r");
/*     */           break;
/*     */         case '"':
/*  68 */           retval.append("\\\"");
/*     */           break;
/*     */         case '\'':
/*  71 */           retval.append("\\'");
/*     */           break;
/*     */         case '\\':
/*  74 */           retval.append("\\\\");
/*     */           break;
/*     */         default:
/*  77 */           if ((ch = str.charAt(i)) < ' ' || ch > '~') {
/*  78 */             String s = "0000" + Integer.toString(ch, 16);
/*  79 */             retval.append("\\u" + s.substring(s.length() - 4, s.length())); break;
/*     */           } 
/*  81 */           retval.append(ch);
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/*  86 */     return retval.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   protected static String LexicalError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar) { return "Lexical error at line " + errorLine + ", column " + errorColumn + ".  Encountered: " + (EOFSeen ? "<EOF> " : ("\"" + addEscapes(String.valueOf(curChar)) + "\"" + " (" + curChar + "), ")) + "after : \"" + addEscapes(errorAfter) + "\""; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   public String getMessage() { return super.getMessage(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenMgrError() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TokenMgrError(String message, int reason) {
/* 130 */     super(message);
/* 131 */     this.errorCode = reason;
/*     */   }
/*     */ 
/*     */   
/* 135 */   public TokenMgrError(boolean EOFSeen, int lexState, int errorLine, int errorColumn, String errorAfter, char curChar, int reason) { this(LexicalError(EOFSeen, lexState, errorLine, errorColumn, errorAfter, curChar), reason); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/TokenMgrError.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */