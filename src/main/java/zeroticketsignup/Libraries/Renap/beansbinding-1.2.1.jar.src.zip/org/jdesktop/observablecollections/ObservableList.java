package org.jdesktop.observablecollections;

import java.util.List;

public interface ObservableList<E> extends List<E> {
  void addObservableListListener(ObservableListListener paramObservableListListener);
  
  void removeObservableListListener(ObservableListListener paramObservableListListener);
  
  boolean supportsElementPropertyChanged();
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/observablecollections/ObservableList.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */