/*    */ package org.jdesktop.swingbinding.adapters;
/*    */ 
/*    */ import java.awt.event.ItemEvent;
/*    */ import java.awt.event.ItemListener;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.AbstractButton;
/*    */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AbstractButtonAdapterProvider
/*    */   implements BeanAdapterProvider
/*    */ {
/*    */   private static final String SELECTED_P = "selected";
/*    */   
/*    */   public static final class Adapter
/*    */     extends BeanAdapterBase
/*    */   {
/*    */     private AbstractButton button;
/*    */     private Handler handler;
/*    */     private boolean cachedSelected;
/*    */     
/*    */     private Adapter(AbstractButton button) {
/* 26 */       super("selected");
/* 27 */       this.button = button;
/*    */     }
/*    */ 
/*    */     
/* 31 */     public boolean isSelected() { return this.button.isSelected(); }
/*    */ 
/*    */ 
/*    */     
/* 35 */     public void setSelected(boolean selected) { this.button.setSelected(selected); }
/*    */ 
/*    */     
/*    */     protected void listeningStarted() {
/* 39 */       this.handler = new Handler();
/* 40 */       this.cachedSelected = isSelected();
/* 41 */       this.button.addItemListener(this.handler);
/* 42 */       this.button.addPropertyChangeListener("model", this.handler);
/*    */     }
/*    */     
/*    */     protected void listeningStopped() {
/* 46 */       this.button.removeItemListener(this.handler);
/* 47 */       this.button.removePropertyChangeListener("model", this.handler);
/* 48 */       this.handler = null;
/*    */     }
/*    */     
/*    */     private class Handler implements ItemListener, PropertyChangeListener {
/*    */       private void buttonSelectedChanged() {
/* 53 */         boolean oldSelected = AbstractButtonAdapterProvider.Adapter.this.cachedSelected;
/* 54 */         AbstractButtonAdapterProvider.Adapter.this.cachedSelected = AbstractButtonAdapterProvider.Adapter.this.isSelected();
/* 55 */         AbstractButtonAdapterProvider.Adapter.this.firePropertyChange(Boolean.valueOf(oldSelected), Boolean.valueOf(AbstractButtonAdapterProvider.Adapter.this.cachedSelected));
/*    */       }
/*    */ 
/*    */       
/* 59 */       public void itemStateChanged(ItemEvent ie) { buttonSelectedChanged(); }
/*    */       
/*    */       private Handler() {}
/*    */       
/* 63 */       public void propertyChange(PropertyChangeEvent pe) { buttonSelectedChanged(); }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 69 */   public boolean providesAdapter(Class<?> type, String property) { return (AbstractButton.class.isAssignableFrom(type) && property.intern() == "selected"); }
/*    */ 
/*    */   
/*    */   public Object createAdapter(Object source, String property) {
/* 73 */     if (!providesAdapter(source.getClass(), property)) {
/* 74 */       throw new IllegalArgumentException();
/*    */     }
/*    */     
/* 77 */     return new Adapter((AbstractButton)source);
/*    */   }
/*    */ 
/*    */   
/* 81 */   public Class<?> getAdapterClass(Class<?> type) { return AbstractButton.class.isAssignableFrom(type) ? Adapter.class : null; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/AbstractButtonAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */