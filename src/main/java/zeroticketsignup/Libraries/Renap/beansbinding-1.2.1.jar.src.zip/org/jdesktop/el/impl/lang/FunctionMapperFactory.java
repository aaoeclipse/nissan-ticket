/*    */ package org.jdesktop.el.impl.lang;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.jdesktop.el.FunctionMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionMapperFactory
/*    */   extends FunctionMapper
/*    */ {
/* 18 */   protected FunctionMapperImpl memento = null;
/*    */   protected FunctionMapper target;
/*    */   
/*    */   public FunctionMapperFactory(FunctionMapper mapper) {
/* 22 */     if (mapper == null) {
/* 23 */       throw new NullPointerException("FunctionMapper target cannot be null");
/*    */     }
/* 25 */     this.target = mapper;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Method resolveFunction(String prefix, String localName) {
/* 33 */     if (this.memento == null) {
/* 34 */       this.memento = new FunctionMapperImpl();
/*    */     }
/* 36 */     Method m = this.target.resolveFunction(prefix, localName);
/* 37 */     if (m != null) {
/* 38 */       this.memento.addFunction(prefix, localName, m);
/*    */     }
/* 40 */     return m;
/*    */   }
/*    */ 
/*    */   
/* 44 */   public FunctionMapper create() { return this.memento; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/FunctionMapperFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */