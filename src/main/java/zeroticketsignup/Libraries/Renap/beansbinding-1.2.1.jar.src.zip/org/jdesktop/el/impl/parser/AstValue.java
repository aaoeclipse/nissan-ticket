/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.ELResolver;
/*     */ import org.jdesktop.el.MethodInfo;
/*     */ import org.jdesktop.el.PropertyNotFoundException;
/*     */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*     */ import org.jdesktop.el.impl.util.MessageFactory;
/*     */ import org.jdesktop.el.impl.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstValue
/*     */   extends SimpleNode
/*     */ {
/*     */   protected static class Target
/*     */   {
/*     */     protected Object base;
/*     */     protected Object property;
/*     */   }
/*     */   
/*  35 */   public AstValue(int id) { super(id); }
/*     */ 
/*     */   
/*     */   public Class getType(EvaluationContext ctx) throws ELException {
/*  39 */     Target t = getTarget(ctx);
/*  40 */     ctx.setPropertyResolved(false);
/*  41 */     return ctx.getELResolver().getType((ELContext)ctx, t.base, t.property);
/*     */   }
/*     */ 
/*     */   
/*     */   private final Target getTarget(EvaluationContext ctx) throws ELException {
/*  46 */     Object base = this.children[0].getValue(ctx);
/*     */ 
/*     */     
/*  49 */     if (base == null || base == ELContext.UNRESOLVABLE_RESULT) {
/*  50 */       throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.base", this.children[0].getImage()));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  55 */     Object property = null;
/*  56 */     int propCount = jjtGetNumChildren() - 1;
/*  57 */     int i = 1;
/*     */ 
/*     */     
/*  60 */     ELResolver resolver = ctx.getELResolver();
/*  61 */     if (propCount > 1) {
/*  62 */       while (base != null && base != ELContext.UNRESOLVABLE_RESULT && i < propCount) {
/*  63 */         property = this.children[i].getValue(ctx);
/*  64 */         ctx.setPropertyResolved(false);
/*  65 */         base = resolver.getValue((ELContext)ctx, base, property);
/*  66 */         i++;
/*     */       } 
/*     */ 
/*     */       
/*  70 */       if (base == ELContext.UNRESOLVABLE_RESULT || base == null || property == null) {
/*  71 */         throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.property", property));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  76 */     property = this.children[i].getValue(ctx);
/*     */     
/*  78 */     if (property == null) {
/*  79 */       throw new PropertyNotFoundException(MessageFactory.get("error.unreachable.property", this.children[i]));
/*     */     }
/*     */ 
/*     */     
/*  83 */     Target t = new Target();
/*  84 */     t.base = base;
/*  85 */     t.property = property;
/*  86 */     return t;
/*     */   }
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/*  90 */     Object base = this.children[0].getValue(ctx);
/*  91 */     int propCount = jjtGetNumChildren();
/*  92 */     if (base == ELContext.UNRESOLVABLE_RESULT || (base == null && propCount > 1)) {
/*  93 */       ctx.clearResolvedProperties();
/*  94 */       return ELContext.UNRESOLVABLE_RESULT;
/*     */     } 
/*  96 */     int i = 1;
/*  97 */     Object property = null;
/*  98 */     ELResolver resolver = ctx.getELResolver();
/*  99 */     while (base != null && i < propCount) {
/* 100 */       property = this.children[i].getValue(ctx);
/* 101 */       if (property == null) {
/* 102 */         return null;
/*     */       }
/* 104 */       ctx.setPropertyResolved(false);
/* 105 */       Object origBase = base;
/* 106 */       base = resolver.getValue((ELContext)ctx, base, property);
/* 107 */       if (base == ELContext.UNRESOLVABLE_RESULT) {
/* 108 */         ctx.clearResolvedProperties();
/* 109 */         return base;
/*     */       } 
/* 111 */       ctx.resolvedProperty(origBase, property);
/*     */ 
/*     */       
/* 114 */       i++;
/*     */     } 
/* 116 */     if (base == null && i < propCount) {
/* 117 */       ctx.clearResolvedProperties();
/* 118 */       return ELContext.UNRESOLVABLE_RESULT;
/*     */     } 
/* 120 */     return base;
/*     */   }
/*     */   
/*     */   public boolean isReadOnly(EvaluationContext ctx) throws ELException {
/* 124 */     Target t = getTarget(ctx);
/* 125 */     ctx.setPropertyResolved(false);
/* 126 */     return ctx.getELResolver().isReadOnly((ELContext)ctx, t.base, t.property);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(EvaluationContext ctx, Object value) throws ELException {
/* 131 */     Target t = getTarget(ctx);
/* 132 */     ctx.setPropertyResolved(false);
/* 133 */     ctx.getELResolver().setValue((ELContext)ctx, t.base, t.property, value);
/*     */   }
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class[] paramTypes) throws ELException {
/* 138 */     Target t = getTarget(ctx);
/* 139 */     Method m = ReflectionUtil.getMethod(t.base, t.property, paramTypes);
/* 140 */     return new MethodInfo(m.getName(), m.getReturnType(), m.getParameterTypes());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(EvaluationContext ctx, Class[] paramTypes, Object[] paramValues) throws ELException {
/* 146 */     Target t = getTarget(ctx);
/* 147 */     Method m = ReflectionUtil.getMethod(t.base, t.property, paramTypes);
/* 148 */     Object result = null;
/*     */     try {
/* 150 */       result = m.invoke(t.base, paramValues);
/* 151 */     } catch (IllegalAccessException iae) {
/* 152 */       throw new ELException(iae);
/* 153 */     } catch (InvocationTargetException ite) {
/* 154 */       throw new ELException(ite.getCause());
/*     */     } 
/* 156 */     return result;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */