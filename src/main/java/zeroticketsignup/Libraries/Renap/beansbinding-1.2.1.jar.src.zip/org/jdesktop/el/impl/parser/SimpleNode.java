/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.MethodInfo;
/*     */ import org.jdesktop.el.PropertyNotWritableException;
/*     */ import org.jdesktop.el.impl.lang.ELSupport;
/*     */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*     */ import org.jdesktop.el.impl.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SimpleNode
/*     */   extends ELSupport
/*     */   implements Node
/*     */ {
/*     */   protected Node parent;
/*     */   protected Node[] children;
/*     */   protected int id;
/*     */   protected String image;
/*     */   
/*  31 */   public SimpleNode(int i) { this.id = i; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void jjtOpen() {}
/*     */ 
/*     */   
/*     */   public void jjtClose() {}
/*     */ 
/*     */   
/*  41 */   public void jjtSetParent(Node n) { this.parent = n; }
/*     */ 
/*     */ 
/*     */   
/*  45 */   public Node jjtGetParent() { return this.parent; }
/*     */ 
/*     */   
/*     */   public void jjtAddChild(Node n, int i) {
/*  49 */     if (this.children == null) {
/*  50 */       this.children = new Node[i + 1];
/*  51 */     } else if (i >= this.children.length) {
/*  52 */       Node[] c = new Node[i + 1];
/*  53 */       System.arraycopy(this.children, 0, c, 0, this.children.length);
/*  54 */       this.children = c;
/*     */     } 
/*  56 */     this.children[i] = n;
/*     */   }
/*     */ 
/*     */   
/*  60 */   public Node jjtGetChild(int i) { return this.children[i]; }
/*     */ 
/*     */ 
/*     */   
/*  64 */   public int jjtGetNumChildren() { return (this.children == null) ? 0 : this.children.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     if (this.image != null) {
/*  76 */       return ELParserTreeConstants.jjtNodeName[this.id] + "[" + this.image + "]";
/*     */     }
/*     */     
/*  79 */     return ELParserTreeConstants.jjtNodeName[this.id];
/*     */   }
/*     */ 
/*     */   
/*  83 */   public String toString(String prefix) { return prefix + toString(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dump(String prefix) {
/*  92 */     System.out.println(toString(prefix));
/*  93 */     if (this.children != null) {
/*  94 */       for (int i = 0; i < this.children.length; i++) {
/*  95 */         SimpleNode n = (SimpleNode)this.children[i];
/*  96 */         if (n != null) {
/*  97 */           n.dump(prefix + " ");
/*     */         }
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 104 */   public String getImage() { return this.image; }
/*     */ 
/*     */ 
/*     */   
/* 108 */   public void setImage(String image) { this.image = image; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 113 */   public Class getType(EvaluationContext ctx) throws ELException { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 118 */   public Object getValue(EvaluationContext ctx) throws ELException { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public boolean isReadOnly(EvaluationContext ctx) throws ELException { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 128 */   public void setValue(EvaluationContext ctx, Object value) throws ELException { throw new PropertyNotWritableException(MessageFactory.get("error.syntax.set")); }
/*     */ 
/*     */   
/*     */   public void accept(NodeVisitor visitor) throws ELException {
/* 132 */     visitor.visit(this);
/* 133 */     if (this.children != null && this.children.length > 0) {
/* 134 */       for (int i = 0; i < this.children.length; i++) {
/* 135 */         this.children[i].accept(visitor);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 141 */   public Object invoke(EvaluationContext ctx, Class[] paramTypes, Object[] paramValues) throws ELException { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */   
/* 145 */   public MethodInfo getMethodInfo(EvaluationContext ctx, Class[] paramTypes) throws ELException { throw new UnsupportedOperationException(); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/SimpleNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */