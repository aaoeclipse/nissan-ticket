/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ArrayELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private boolean isReadOnly;
/*     */   
/*  40 */   public ArrayELResolver() { this.isReadOnly = false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public ArrayELResolver(boolean isReadOnly) { this.isReadOnly = isReadOnly; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  90 */     if (context == null) {
/*  91 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  94 */     if (base != null && base.getClass().isArray()) {
/*  95 */       context.setPropertyResolved(true);
/*  96 */       int index = toInteger(property);
/*  97 */       if (index < 0 || index >= Array.getLength(base)) {
/*  98 */         throw new PropertyNotFoundException();
/*     */       }
/* 100 */       return base.getClass().getComponentType();
/*     */     } 
/* 102 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/* 139 */     if (context == null) {
/* 140 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 143 */     if (base != null && base.getClass().isArray()) {
/* 144 */       context.setPropertyResolved(true);
/* 145 */       int index = toInteger(property);
/* 146 */       if (index >= 0 && index < Array.getLength(base)) {
/* 147 */         return Array.get(base, index);
/*     */       }
/*     */     } 
/* 150 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object val) {
/* 194 */     if (context == null) {
/* 195 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 198 */     if (base != null && base.getClass().isArray()) {
/* 199 */       context.setPropertyResolved(true);
/* 200 */       if (this.isReadOnly) {
/* 201 */         throw new PropertyNotWritableException();
/*     */       }
/* 203 */       Class<?> type = base.getClass().getComponentType();
/* 204 */       if (val != null && !type.isAssignableFrom(val.getClass())) {
/* 205 */         throw new ClassCastException();
/*     */       }
/* 207 */       int index = toInteger(property);
/* 208 */       if (index < 0 || index >= Array.getLength(base)) {
/* 209 */         throw new PropertyNotFoundException();
/*     */       }
/* 211 */       Array.set(base, index, val);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 252 */     if (context == null) {
/* 253 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 256 */     if (base != null && base.getClass().isArray()) {
/* 257 */       context.setPropertyResolved(true);
/* 258 */       int index = toInteger(property);
/* 259 */       if (index < 0 || index >= Array.getLength(base)) {
/* 260 */         throw new PropertyNotFoundException();
/*     */       }
/*     */     } 
/* 263 */     return this.isReadOnly;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 281 */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 302 */     if (base != null && base.getClass().isArray()) {
/* 303 */       return Integer.class;
/*     */     }
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private int toInteger(Object p) {
/* 310 */     if (p instanceof Integer) {
/* 311 */       return ((Integer)p).intValue();
/*     */     }
/* 313 */     if (p instanceof Character) {
/* 314 */       return ((Character)p).charValue();
/*     */     }
/* 316 */     if (p instanceof Boolean) {
/* 317 */       return ((Boolean)p).booleanValue() ? 1 : 0;
/*     */     }
/* 319 */     if (p instanceof Number) {
/* 320 */       return ((Number)p).intValue();
/*     */     }
/* 322 */     if (p instanceof String) {
/* 323 */       return Integer.parseInt((String)p);
/*     */     }
/* 325 */     throw new IllegalArgumentException();
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ArrayELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */