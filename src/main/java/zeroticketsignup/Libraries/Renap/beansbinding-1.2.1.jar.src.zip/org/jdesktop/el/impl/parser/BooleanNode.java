/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BooleanNode
/*    */   extends SimpleNode
/*    */ {
/* 21 */   public BooleanNode(int i) { super(i); }
/*    */ 
/*    */ 
/*    */   
/* 25 */   public Class getType(EvaluationContext ctx) throws ELException { return Boolean.class; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/BooleanNode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */