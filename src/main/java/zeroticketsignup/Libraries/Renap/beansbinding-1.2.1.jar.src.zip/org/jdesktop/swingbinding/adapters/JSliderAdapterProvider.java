/*     */ package org.jdesktop.swingbinding.adapters;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JSliderAdapterProvider
/*     */   implements BeanAdapterProvider
/*     */ {
/*     */   private static final String PROPERTY_BASE = "value";
/*     */   private static final String IGNORE_ADJUSTING = "value_IGNORE_ADJUSTING";
/*     */   
/*     */   public static final class Adapter
/*     */     extends BeanAdapterBase
/*     */   {
/*     */     private JSlider slider;
/*     */     private Handler handler;
/*     */     private int cachedValue;
/*     */     
/*     */     private Adapter(JSlider slider, String property) {
/*  27 */       super(property);
/*  28 */       this.slider = slider;
/*     */     }
/*     */ 
/*     */     
/*  32 */     public int getValue() { return this.slider.getValue(); }
/*     */ 
/*     */ 
/*     */     
/*  36 */     public int getValue_IGNORE_ADJUSTING() { return getValue(); }
/*     */ 
/*     */ 
/*     */     
/*  40 */     public void setValue(int value) { this.slider.setValue(value); }
/*     */ 
/*     */ 
/*     */     
/*  44 */     public void setValue_IGNORE_ADJUSTING(int value) { setValue(value); }
/*     */ 
/*     */     
/*     */     protected void listeningStarted() {
/*  48 */       this.handler = new Handler();
/*  49 */       this.cachedValue = getValue();
/*  50 */       this.slider.addChangeListener(this.handler);
/*  51 */       this.slider.addPropertyChangeListener("model", this.handler);
/*     */     }
/*     */     
/*     */     protected void listeningStopped() {
/*  55 */       this.slider.removeChangeListener(this.handler);
/*  56 */       this.slider.removePropertyChangeListener("model", this.handler);
/*  57 */       this.handler = null;
/*     */     }
/*     */     
/*     */     private class Handler implements ChangeListener, PropertyChangeListener {
/*     */       private void sliderValueChanged() {
/*  62 */         int oldValue = JSliderAdapterProvider.Adapter.this.cachedValue;
/*  63 */         JSliderAdapterProvider.Adapter.this.cachedValue = JSliderAdapterProvider.Adapter.this.getValue();
/*  64 */         JSliderAdapterProvider.Adapter.this.firePropertyChange(Integer.valueOf(oldValue), Integer.valueOf(JSliderAdapterProvider.Adapter.this.cachedValue));
/*     */       }
/*     */       private Handler() {}
/*     */       public void stateChanged(ChangeEvent ce) {
/*  68 */         if (JSliderAdapterProvider.Adapter.this.property == "value_IGNORE_ADJUSTING" && JSliderAdapterProvider.Adapter.this.slider.getValueIsAdjusting()) {
/*     */           return;
/*     */         }
/*     */         
/*  72 */         sliderValueChanged();
/*     */       }
/*     */ 
/*     */       
/*  76 */       public void propertyChange(PropertyChangeEvent pe) { sliderValueChanged(); }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean providesAdapter(Class<?> type, String property) {
/*  82 */     if (!JSlider.class.isAssignableFrom(type)) {
/*  83 */       return false;
/*     */     }
/*     */     
/*  86 */     property = property.intern();
/*     */     
/*  88 */     return (property == "value" || property == "value_IGNORE_ADJUSTING");
/*     */   }
/*     */ 
/*     */   
/*     */   public Object createAdapter(Object source, String property) {
/*  93 */     if (!providesAdapter(source.getClass(), property)) {
/*  94 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  97 */     return new Adapter((JSlider)source, property);
/*     */   }
/*     */ 
/*     */   
/* 101 */   public Class<?> getAdapterClass(Class<?> type) { return JSlider.class.isAssignableFrom(type) ? Adapter.class : null; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/JSliderAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */