/*      */ package org.jdesktop.el.impl.parser;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ELParserTokenManager
/*      */   implements ELParserConstants
/*      */ {
/*      */   public PrintStream debugStream;
/*      */   
/*   13 */   public void setDebugStream(PrintStream ds) { this.debugStream = ds; }
/*      */   
/*      */   private final int jjStopStringLiteralDfa_0(int pos, long active0) {
/*   16 */     switch (pos) {
/*      */       
/*      */       case 0:
/*   19 */         if ((active0 & 0x10L) != 0L)
/*   20 */           return 2; 
/*   21 */         if ((active0 & 0x4L) != 0L) {
/*      */           
/*   23 */           this.jjmatchedKind = 1;
/*   24 */           return 4;
/*      */         } 
/*   26 */         if ((active0 & 0x8L) != 0L) {
/*      */           
/*   28 */           this.jjmatchedKind = 1;
/*   29 */           return 6;
/*      */         } 
/*   31 */         return -1;
/*      */     } 
/*   33 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*   38 */   private final int jjStartNfa_0(int pos, long active0) { return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0), pos + 1); }
/*      */ 
/*      */   
/*      */   private final int jjStopAtPos(int pos, int kind) {
/*   42 */     this.jjmatchedKind = kind;
/*   43 */     this.jjmatchedPos = pos;
/*   44 */     return pos + 1;
/*      */   }
/*      */   
/*      */   private final int jjStartNfaWithStates_0(int pos, int kind, int state) {
/*   48 */     this.jjmatchedKind = kind;
/*   49 */     this.jjmatchedPos = pos; 
/*   50 */     try { this.curChar = this.input_stream.readChar(); }
/*   51 */     catch (IOException e) { return pos + 1; }
/*   52 */      return jjMoveNfa_0(state, pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa0_0() {
/*   56 */     switch (this.curChar) {
/*      */       
/*      */       case '#':
/*   59 */         return jjMoveStringLiteralDfa1_0(8L);
/*      */       case '$':
/*   61 */         return jjMoveStringLiteralDfa1_0(4L);
/*      */       case '\\':
/*   63 */         return jjStartNfaWithStates_0(0, 4, 2);
/*      */     } 
/*   65 */     return jjMoveNfa_0(7, 0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa1_0(long active0) {
/*      */     try {
/*   70 */       this.curChar = this.input_stream.readChar();
/*   71 */     } catch (IOException e) {
/*   72 */       jjStopStringLiteralDfa_0(0, active0);
/*   73 */       return 1;
/*      */     } 
/*   75 */     switch (this.curChar) {
/*      */       
/*      */       case '{':
/*   78 */         if ((active0 & 0x4L) != 0L)
/*   79 */           return jjStopAtPos(1, 2); 
/*   80 */         if ((active0 & 0x8L) != 0L) {
/*   81 */           return jjStopAtPos(1, 3);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*   86 */     return jjStartNfa_0(0, active0);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAdd(int state) {
/*   90 */     if (this.jjrounds[state] != this.jjround) {
/*      */       
/*   92 */       this.jjstateSet[this.jjnewStateCnt++] = state;
/*   93 */       this.jjrounds[state] = this.jjround;
/*      */     } 
/*      */   }
/*      */   
/*      */   private final void jjAddStates(int start, int end) {
/*      */     do {
/*   99 */       this.jjstateSet[this.jjnewStateCnt++] = jjnextStates[start];
/*  100 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddTwoStates(int state1, int state2) {
/*  104 */     jjCheckNAdd(state1);
/*  105 */     jjCheckNAdd(state2);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddStates(int start, int end) {
/*      */     do {
/*  110 */       jjCheckNAdd(jjnextStates[start]);
/*  111 */     } while (start++ != end);
/*      */   }
/*      */   
/*      */   private final void jjCheckNAddStates(int start) {
/*  115 */     jjCheckNAdd(jjnextStates[start]);
/*  116 */     jjCheckNAdd(jjnextStates[start + 1]);
/*      */   }
/*  118 */   static final long[] jjbitVec0 = new long[] { -2L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  121 */   static final long[] jjbitVec2 = new long[] { 0L, 0L, -1L, -1L };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int jjMoveNfa_0(int startState, int curPos) {
/*  127 */     int startsAt = 0;
/*  128 */     this.jjnewStateCnt = 8;
/*  129 */     int i = 1;
/*  130 */     this.jjstateSet[0] = startState;
/*  131 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  134 */       if (++this.jjround == Integer.MAX_VALUE)
/*  135 */         ReInitRounds(); 
/*  136 */       if (this.curChar < '@') {
/*      */         
/*  138 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  141 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 7:
/*  144 */               if ((0xFFFFFFE7FFFFFFFFL & l) != 0L) {
/*      */                 
/*  146 */                 if (kind > 1)
/*  147 */                   kind = 1; 
/*  148 */                 jjCheckNAddStates(0, 3);
/*      */               }
/*  150 */               else if ((0x1800000000L & l) != 0L) {
/*      */                 
/*  152 */                 if (kind > 1)
/*  153 */                   kind = 1; 
/*      */               } 
/*  155 */               if (this.curChar == '#') {
/*  156 */                 this.jjstateSet[this.jjnewStateCnt++] = 6; break;
/*  157 */               }  if (this.curChar == '$')
/*  158 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 0:
/*  161 */               if ((0xFFFFFFE7FFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  163 */               if (kind > 1)
/*  164 */                 kind = 1; 
/*  165 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 2:
/*  168 */               if ((0x1800000000L & l) == 0L)
/*      */                 break; 
/*  170 */               if (kind > 1)
/*  171 */                 kind = 1; 
/*  172 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 3:
/*  175 */               if (this.curChar == '$')
/*  176 */                 this.jjstateSet[this.jjnewStateCnt++] = 4; 
/*      */               break;
/*      */             case 4:
/*  179 */               if ((0xFFFFFFEFFFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  181 */               if (kind > 1)
/*  182 */                 kind = 1; 
/*  183 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 5:
/*  186 */               if (this.curChar == '#')
/*  187 */                 this.jjstateSet[this.jjnewStateCnt++] = 6; 
/*      */               break;
/*      */             case 6:
/*  190 */               if ((0xFFFFFFF7FFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  192 */               if (kind > 1)
/*  193 */                 kind = 1; 
/*  194 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */           } 
/*      */         
/*  198 */         } while (i != startsAt);
/*      */       }
/*  200 */       else if (this.curChar < '') {
/*      */         
/*  202 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  205 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 7:
/*  208 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L) {
/*      */                 
/*  210 */                 if (kind > 1)
/*  211 */                   kind = 1; 
/*  212 */                 jjCheckNAddStates(0, 3); break;
/*      */               } 
/*  214 */               if (this.curChar == '\\')
/*  215 */                 this.jjstateSet[this.jjnewStateCnt++] = 2; 
/*      */               break;
/*      */             case 0:
/*  218 */               if ((0xFFFFFFFFEFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  220 */               if (kind > 1)
/*  221 */                 kind = 1; 
/*  222 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 1:
/*  225 */               if (this.curChar == '\\')
/*  226 */                 this.jjstateSet[this.jjnewStateCnt++] = 2; 
/*      */               break;
/*      */             case 2:
/*  229 */               if (this.curChar != '\\')
/*      */                 break; 
/*  231 */               if (kind > 1)
/*  232 */                 kind = 1; 
/*  233 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */             case 4:
/*      */             case 6:
/*  237 */               if ((0xF7FFFFFFFFFFFFFFL & l) == 0L)
/*      */                 break; 
/*  239 */               if (kind > 1)
/*  240 */                 kind = 1; 
/*  241 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */           } 
/*      */         
/*  245 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/*  249 */         int hiByte = this.curChar >> 8;
/*  250 */         int i1 = hiByte >> 6;
/*  251 */         long l1 = 1L << (hiByte & 0x3F);
/*  252 */         int i2 = (this.curChar & 0xFF) >> 6;
/*  253 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  256 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 4:
/*      */             case 6:
/*      */             case 7:
/*  262 */               if (!jjCanMove_0(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/*  264 */               if (kind > 1)
/*  265 */                 kind = 1; 
/*  266 */               jjCheckNAddStates(0, 3);
/*      */               break;
/*      */           } 
/*      */         
/*  270 */         } while (i != startsAt);
/*      */       } 
/*  272 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/*  274 */         this.jjmatchedKind = kind;
/*  275 */         this.jjmatchedPos = curPos;
/*  276 */         kind = Integer.MAX_VALUE;
/*      */       } 
/*  278 */       curPos++;
/*  279 */       if ((i = this.jjnewStateCnt) == (startsAt = 8 - (this.jjnewStateCnt = startsAt)))
/*  280 */         return curPos;  
/*  281 */       try { this.curChar = this.input_stream.readChar(); }
/*  282 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/*      */   }
/*      */   private final int jjStopStringLiteralDfa_1(int pos, long active0) {
/*  287 */     switch (pos) {
/*      */       
/*      */       case 0:
/*  290 */         if ((active0 & 0x800000L) != 0L)
/*  291 */           return 8; 
/*  292 */         if ((active0 & 0x40000L) != 0L)
/*  293 */           return 1; 
/*  294 */         if ((active0 & 0x141D555401C000L) != 0L) {
/*      */           
/*  296 */           this.jjmatchedKind = 53;
/*  297 */           return 6;
/*      */         } 
/*  299 */         return -1;
/*      */       case 1:
/*  301 */         if ((active0 & 0x41554000000L) != 0L)
/*  302 */           return 6; 
/*  303 */         if ((active0 & 0x1419400001C000L) != 0L) {
/*      */           
/*  305 */           this.jjmatchedKind = 53;
/*  306 */           this.jjmatchedPos = 1;
/*  307 */           return 6;
/*      */         } 
/*  309 */         return -1;
/*      */       case 2:
/*  311 */         if ((active0 & 0x14014000000000L) != 0L)
/*  312 */           return 6; 
/*  313 */         if ((active0 & 0x18000001C000L) != 0L) {
/*      */           
/*  315 */           this.jjmatchedKind = 53;
/*  316 */           this.jjmatchedPos = 2;
/*  317 */           return 6;
/*      */         } 
/*  319 */         return -1;
/*      */       case 3:
/*  321 */         if ((active0 & 0x14000L) != 0L)
/*  322 */           return 6; 
/*  323 */         if ((active0 & 0x180000008000L) != 0L) {
/*      */           
/*  325 */           this.jjmatchedKind = 53;
/*  326 */           this.jjmatchedPos = 3;
/*  327 */           return 6;
/*      */         } 
/*  329 */         return -1;
/*      */       case 4:
/*  331 */         if ((active0 & 0x80000008000L) != 0L)
/*  332 */           return 6; 
/*  333 */         if ((active0 & 0x100000000000L) != 0L) {
/*      */           
/*  335 */           this.jjmatchedKind = 53;
/*  336 */           this.jjmatchedPos = 4;
/*  337 */           return 6;
/*      */         } 
/*  339 */         return -1;
/*      */       case 5:
/*  341 */         if ((active0 & 0x100000000000L) != 0L) {
/*      */           
/*  343 */           this.jjmatchedKind = 53;
/*  344 */           this.jjmatchedPos = 5;
/*  345 */           return 6;
/*      */         } 
/*  347 */         return -1;
/*      */       case 6:
/*  349 */         if ((active0 & 0x100000000000L) != 0L) {
/*      */           
/*  351 */           this.jjmatchedKind = 53;
/*  352 */           this.jjmatchedPos = 6;
/*  353 */           return 6;
/*      */         } 
/*  355 */         return -1;
/*      */       case 7:
/*  357 */         if ((active0 & 0x100000000000L) != 0L) {
/*      */           
/*  359 */           this.jjmatchedKind = 53;
/*  360 */           this.jjmatchedPos = 7;
/*  361 */           return 6;
/*      */         } 
/*  363 */         return -1;
/*      */       case 8:
/*  365 */         if ((active0 & 0x100000000000L) != 0L) {
/*      */           
/*  367 */           this.jjmatchedKind = 53;
/*  368 */           this.jjmatchedPos = 8;
/*  369 */           return 6;
/*      */         } 
/*  371 */         return -1;
/*      */     } 
/*  373 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*  378 */   private final int jjStartNfa_1(int pos, long active0) { return jjMoveNfa_1(jjStopStringLiteralDfa_1(pos, active0), pos + 1); }
/*      */ 
/*      */   
/*      */   private final int jjStartNfaWithStates_1(int pos, int kind, int state) {
/*  382 */     this.jjmatchedKind = kind;
/*  383 */     this.jjmatchedPos = pos; 
/*  384 */     try { this.curChar = this.input_stream.readChar(); }
/*  385 */     catch (IOException e) { return pos + 1; }
/*  386 */      return jjMoveNfa_1(state, pos + 1);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa0_1() {
/*  390 */     switch (this.curChar) {
/*      */       
/*      */       case '!':
/*  393 */         this.jjmatchedKind = 37;
/*  394 */         return jjMoveStringLiteralDfa1_1(34359738368L);
/*      */       case '%':
/*  396 */         return jjStopAtPos(0, 51);
/*      */       case '&':
/*  398 */         return jjMoveStringLiteralDfa1_1(549755813888L);
/*      */       case '(':
/*  400 */         return jjStopAtPos(0, 19);
/*      */       case ')':
/*  402 */         return jjStopAtPos(0, 20);
/*      */       case '*':
/*  404 */         return jjStopAtPos(0, 45);
/*      */       case '+':
/*  406 */         return jjStopAtPos(0, 46);
/*      */       case ',':
/*  408 */         return jjStopAtPos(0, 24);
/*      */       case '-':
/*  410 */         return jjStopAtPos(0, 47);
/*      */       case '.':
/*  412 */         return jjStartNfaWithStates_1(0, 18, 1);
/*      */       case '/':
/*  414 */         return jjStopAtPos(0, 49);
/*      */       case ':':
/*  416 */         return jjStartNfaWithStates_1(0, 23, 8);
/*      */       case '<':
/*  418 */         this.jjmatchedKind = 27;
/*  419 */         return jjMoveStringLiteralDfa1_1(2147483648L);
/*      */       case '=':
/*  421 */         return jjMoveStringLiteralDfa1_1(8589934592L);
/*      */       case '>':
/*  423 */         this.jjmatchedKind = 25;
/*  424 */         return jjMoveStringLiteralDfa1_1(536870912L);
/*      */       case '?':
/*  426 */         return jjStopAtPos(0, 48);
/*      */       case '[':
/*  428 */         return jjStopAtPos(0, 21);
/*      */       case ']':
/*  430 */         return jjStopAtPos(0, 22);
/*      */       case 'a':
/*  432 */         return jjMoveStringLiteralDfa1_1(1099511627776L);
/*      */       case 'd':
/*  434 */         return jjMoveStringLiteralDfa1_1(1125899906842624L);
/*      */       case 'e':
/*  436 */         return jjMoveStringLiteralDfa1_1(8813272891392L);
/*      */       case 'f':
/*  438 */         return jjMoveStringLiteralDfa1_1(32768L);
/*      */       case 'g':
/*  440 */         return jjMoveStringLiteralDfa1_1(1140850688L);
/*      */       case 'i':
/*  442 */         return jjMoveStringLiteralDfa1_1(17592186044416L);
/*      */       case 'l':
/*  444 */         return jjMoveStringLiteralDfa1_1(4563402752L);
/*      */       case 'm':
/*  446 */         return jjMoveStringLiteralDfa1_1(4503599627370496L);
/*      */       case 'n':
/*  448 */         return jjMoveStringLiteralDfa1_1(343597449216L);
/*      */       case 'o':
/*  450 */         return jjMoveStringLiteralDfa1_1(4398046511104L);
/*      */       case 't':
/*  452 */         return jjMoveStringLiteralDfa1_1(16384L);
/*      */       case '|':
/*  454 */         return jjMoveStringLiteralDfa1_1(2199023255552L);
/*      */       case '}':
/*  456 */         return jjStopAtPos(0, 17);
/*      */     } 
/*  458 */     return jjMoveNfa_1(0, 0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa1_1(long active0) {
/*      */     try {
/*  463 */       this.curChar = this.input_stream.readChar();
/*  464 */     } catch (IOException e) {
/*  465 */       jjStopStringLiteralDfa_1(0, active0);
/*  466 */       return 1;
/*      */     } 
/*  468 */     switch (this.curChar) {
/*      */       
/*      */       case '&':
/*  471 */         if ((active0 & 0x8000000000L) != 0L)
/*  472 */           return jjStopAtPos(1, 39); 
/*      */         break;
/*      */       case '=':
/*  475 */         if ((active0 & 0x20000000L) != 0L)
/*  476 */           return jjStopAtPos(1, 29); 
/*  477 */         if ((active0 & 0x80000000L) != 0L)
/*  478 */           return jjStopAtPos(1, 31); 
/*  479 */         if ((active0 & 0x200000000L) != 0L)
/*  480 */           return jjStopAtPos(1, 33); 
/*  481 */         if ((active0 & 0x800000000L) != 0L)
/*  482 */           return jjStopAtPos(1, 35); 
/*      */         break;
/*      */       case 'a':
/*  485 */         return jjMoveStringLiteralDfa2_1(active0, 32768L);
/*      */       case 'e':
/*  487 */         if ((active0 & 0x40000000L) != 0L)
/*  488 */           return jjStartNfaWithStates_1(1, 30, 6); 
/*  489 */         if ((active0 & 0x100000000L) != 0L)
/*  490 */           return jjStartNfaWithStates_1(1, 32, 6); 
/*  491 */         if ((active0 & 0x1000000000L) != 0L)
/*  492 */           return jjStartNfaWithStates_1(1, 36, 6); 
/*      */         break;
/*      */       case 'i':
/*  495 */         return jjMoveStringLiteralDfa2_1(active0, 1125899906842624L);
/*      */       case 'm':
/*  497 */         return jjMoveStringLiteralDfa2_1(active0, 8796093022208L);
/*      */       case 'n':
/*  499 */         return jjMoveStringLiteralDfa2_1(active0, 18691697672192L);
/*      */       case 'o':
/*  501 */         return jjMoveStringLiteralDfa2_1(active0, 4503874505277440L);
/*      */       case 'q':
/*  503 */         if ((active0 & 0x400000000L) != 0L)
/*  504 */           return jjStartNfaWithStates_1(1, 34, 6); 
/*      */         break;
/*      */       case 'r':
/*  507 */         if ((active0 & 0x40000000000L) != 0L)
/*  508 */           return jjStartNfaWithStates_1(1, 42, 6); 
/*  509 */         return jjMoveStringLiteralDfa2_1(active0, 16384L);
/*      */       case 't':
/*  511 */         if ((active0 & 0x4000000L) != 0L)
/*  512 */           return jjStartNfaWithStates_1(1, 26, 6); 
/*  513 */         if ((active0 & 0x10000000L) != 0L)
/*  514 */           return jjStartNfaWithStates_1(1, 28, 6); 
/*      */         break;
/*      */       case 'u':
/*  517 */         return jjMoveStringLiteralDfa2_1(active0, 65536L);
/*      */       case '|':
/*  519 */         if ((active0 & 0x20000000000L) != 0L) {
/*  520 */           return jjStopAtPos(1, 41);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  525 */     return jjStartNfa_1(0, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa2_1(long old0, long active0) {
/*  529 */     if ((active0 &= old0) == 0L)
/*  530 */       return jjStartNfa_1(0, old0);  try {
/*  531 */       this.curChar = this.input_stream.readChar();
/*  532 */     } catch (IOException e) {
/*  533 */       jjStopStringLiteralDfa_1(1, active0);
/*  534 */       return 2;
/*      */     } 
/*  536 */     switch (this.curChar) {
/*      */       
/*      */       case 'd':
/*  539 */         if ((active0 & 0x10000000000L) != 0L)
/*  540 */           return jjStartNfaWithStates_1(2, 40, 6); 
/*  541 */         if ((active0 & 0x10000000000000L) != 0L)
/*  542 */           return jjStartNfaWithStates_1(2, 52, 6); 
/*      */         break;
/*      */       case 'l':
/*  545 */         return jjMoveStringLiteralDfa3_1(active0, 98304L);
/*      */       case 'p':
/*  547 */         return jjMoveStringLiteralDfa3_1(active0, 8796093022208L);
/*      */       case 's':
/*  549 */         return jjMoveStringLiteralDfa3_1(active0, 17592186044416L);
/*      */       case 't':
/*  551 */         if ((active0 & 0x4000000000L) != 0L)
/*  552 */           return jjStartNfaWithStates_1(2, 38, 6); 
/*      */         break;
/*      */       case 'u':
/*  555 */         return jjMoveStringLiteralDfa3_1(active0, 16384L);
/*      */       case 'v':
/*  557 */         if ((active0 & 0x4000000000000L) != 0L) {
/*  558 */           return jjStartNfaWithStates_1(2, 50, 6);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  563 */     return jjStartNfa_1(1, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa3_1(long old0, long active0) {
/*  567 */     if ((active0 &= old0) == 0L)
/*  568 */       return jjStartNfa_1(1, old0);  try {
/*  569 */       this.curChar = this.input_stream.readChar();
/*  570 */     } catch (IOException e) {
/*  571 */       jjStopStringLiteralDfa_1(2, active0);
/*  572 */       return 3;
/*      */     } 
/*  574 */     switch (this.curChar) {
/*      */       
/*      */       case 'e':
/*  577 */         if ((active0 & 0x4000L) != 0L)
/*  578 */           return jjStartNfaWithStates_1(3, 14, 6); 
/*      */         break;
/*      */       case 'l':
/*  581 */         if ((active0 & 0x10000L) != 0L)
/*  582 */           return jjStartNfaWithStates_1(3, 16, 6); 
/*      */         break;
/*      */       case 's':
/*  585 */         return jjMoveStringLiteralDfa4_1(active0, 32768L);
/*      */       case 't':
/*  587 */         return jjMoveStringLiteralDfa4_1(active0, 26388279066624L);
/*      */     } 
/*      */ 
/*      */     
/*  591 */     return jjStartNfa_1(2, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa4_1(long old0, long active0) {
/*  595 */     if ((active0 &= old0) == 0L)
/*  596 */       return jjStartNfa_1(2, old0);  try {
/*  597 */       this.curChar = this.input_stream.readChar();
/*  598 */     } catch (IOException e) {
/*  599 */       jjStopStringLiteralDfa_1(3, active0);
/*  600 */       return 4;
/*      */     } 
/*  602 */     switch (this.curChar) {
/*      */       
/*      */       case 'a':
/*  605 */         return jjMoveStringLiteralDfa5_1(active0, 17592186044416L);
/*      */       case 'e':
/*  607 */         if ((active0 & 0x8000L) != 0L)
/*  608 */           return jjStartNfaWithStates_1(4, 15, 6); 
/*      */         break;
/*      */       case 'y':
/*  611 */         if ((active0 & 0x80000000000L) != 0L) {
/*  612 */           return jjStartNfaWithStates_1(4, 43, 6);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  617 */     return jjStartNfa_1(3, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa5_1(long old0, long active0) {
/*  621 */     if ((active0 &= old0) == 0L)
/*  622 */       return jjStartNfa_1(3, old0);  try {
/*  623 */       this.curChar = this.input_stream.readChar();
/*  624 */     } catch (IOException e) {
/*  625 */       jjStopStringLiteralDfa_1(4, active0);
/*  626 */       return 5;
/*      */     } 
/*  628 */     switch (this.curChar) {
/*      */       
/*      */       case 'n':
/*  631 */         return jjMoveStringLiteralDfa6_1(active0, 17592186044416L);
/*      */     } 
/*      */ 
/*      */     
/*  635 */     return jjStartNfa_1(4, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa6_1(long old0, long active0) {
/*  639 */     if ((active0 &= old0) == 0L)
/*  640 */       return jjStartNfa_1(4, old0);  try {
/*  641 */       this.curChar = this.input_stream.readChar();
/*  642 */     } catch (IOException e) {
/*  643 */       jjStopStringLiteralDfa_1(5, active0);
/*  644 */       return 6;
/*      */     } 
/*  646 */     switch (this.curChar) {
/*      */       
/*      */       case 'c':
/*  649 */         return jjMoveStringLiteralDfa7_1(active0, 17592186044416L);
/*      */     } 
/*      */ 
/*      */     
/*  653 */     return jjStartNfa_1(5, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa7_1(long old0, long active0) {
/*  657 */     if ((active0 &= old0) == 0L)
/*  658 */       return jjStartNfa_1(5, old0);  try {
/*  659 */       this.curChar = this.input_stream.readChar();
/*  660 */     } catch (IOException e) {
/*  661 */       jjStopStringLiteralDfa_1(6, active0);
/*  662 */       return 7;
/*      */     } 
/*  664 */     switch (this.curChar) {
/*      */       
/*      */       case 'e':
/*  667 */         return jjMoveStringLiteralDfa8_1(active0, 17592186044416L);
/*      */     } 
/*      */ 
/*      */     
/*  671 */     return jjStartNfa_1(6, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa8_1(long old0, long active0) {
/*  675 */     if ((active0 &= old0) == 0L)
/*  676 */       return jjStartNfa_1(6, old0);  try {
/*  677 */       this.curChar = this.input_stream.readChar();
/*  678 */     } catch (IOException e) {
/*  679 */       jjStopStringLiteralDfa_1(7, active0);
/*  680 */       return 8;
/*      */     } 
/*  682 */     switch (this.curChar) {
/*      */       
/*      */       case 'o':
/*  685 */         return jjMoveStringLiteralDfa9_1(active0, 17592186044416L);
/*      */     } 
/*      */ 
/*      */     
/*  689 */     return jjStartNfa_1(7, active0);
/*      */   }
/*      */   
/*      */   private final int jjMoveStringLiteralDfa9_1(long old0, long active0) {
/*  693 */     if ((active0 &= old0) == 0L)
/*  694 */       return jjStartNfa_1(7, old0);  try {
/*  695 */       this.curChar = this.input_stream.readChar();
/*  696 */     } catch (IOException e) {
/*  697 */       jjStopStringLiteralDfa_1(8, active0);
/*  698 */       return 9;
/*      */     } 
/*  700 */     switch (this.curChar) {
/*      */       
/*      */       case 'f':
/*  703 */         if ((active0 & 0x100000000000L) != 0L) {
/*  704 */           return jjStartNfaWithStates_1(9, 44, 6);
/*      */         }
/*      */         break;
/*      */     } 
/*      */     
/*  709 */     return jjStartNfa_1(8, active0);
/*      */   }
/*  711 */   static final long[] jjbitVec3 = new long[] { 2301339413881290750L, -16384L, 4294967295L, 432345564227567616L };
/*      */ 
/*      */   
/*  714 */   static final long[] jjbitVec4 = new long[] { 0L, 0L, 0L, -36028797027352577L };
/*      */ 
/*      */   
/*  717 */   static final long[] jjbitVec5 = new long[] { 0L, -1L, -1L, -1L };
/*      */ 
/*      */   
/*  720 */   static final long[] jjbitVec6 = new long[] { -1L, -1L, 65535L, 0L };
/*      */ 
/*      */   
/*  723 */   static final long[] jjbitVec7 = new long[] { -1L, -1L, 0L, 0L };
/*      */ 
/*      */   
/*  726 */   static final long[] jjbitVec8 = new long[] { 70368744177663L, 0L, 0L, 0L };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int jjMoveNfa_1(int startState, int curPos) {
/*  732 */     int startsAt = 0;
/*  733 */     this.jjnewStateCnt = 38;
/*  734 */     int i = 1;
/*  735 */     this.jjstateSet[0] = startState;
/*  736 */     int kind = Integer.MAX_VALUE;
/*      */     
/*      */     while (true) {
/*  739 */       if (++this.jjround == Integer.MAX_VALUE)
/*  740 */         ReInitRounds(); 
/*  741 */       if (this.curChar < '@') {
/*      */         
/*  743 */         long l = 1L << this.curChar;
/*      */         
/*      */         do {
/*  746 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*  749 */               if ((0x3FF000000000000L & l) != 0L) {
/*      */                 
/*  751 */                 if (kind > 9)
/*  752 */                   kind = 9; 
/*  753 */                 jjCheckNAddStates(4, 8); break;
/*      */               } 
/*  755 */               if ((0x1800000000L & l) != 0L) {
/*      */                 
/*  757 */                 if (kind > 53)
/*  758 */                   kind = 53; 
/*  759 */                 jjCheckNAdd(6); break;
/*      */               } 
/*  761 */               if (this.curChar == '\'') {
/*  762 */                 jjCheckNAddStates(9, 13); break;
/*  763 */               }  if (this.curChar == '"') {
/*  764 */                 jjCheckNAddStates(14, 18); break;
/*  765 */               }  if (this.curChar == ':') {
/*  766 */                 this.jjstateSet[this.jjnewStateCnt++] = 8; break;
/*  767 */               }  if (this.curChar == '.')
/*  768 */                 jjCheckNAdd(1); 
/*      */               break;
/*      */             case 1:
/*  771 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  773 */               if (kind > 10)
/*  774 */                 kind = 10; 
/*  775 */               jjCheckNAddTwoStates(1, 2);
/*      */               break;
/*      */             case 3:
/*  778 */               if ((0x280000000000L & l) != 0L)
/*  779 */                 jjCheckNAdd(4); 
/*      */               break;
/*      */             case 4:
/*  782 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  784 */               if (kind > 10)
/*  785 */                 kind = 10; 
/*  786 */               jjCheckNAdd(4);
/*      */               break;
/*      */             case 5:
/*  789 */               if ((0x1800000000L & l) == 0L)
/*      */                 break; 
/*  791 */               if (kind > 53)
/*  792 */                 kind = 53; 
/*  793 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 6:
/*  796 */               if ((0x3FF001000000000L & l) == 0L)
/*      */                 break; 
/*  798 */               if (kind > 53)
/*  799 */                 kind = 53; 
/*  800 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 7:
/*  803 */               if (this.curChar == ':')
/*  804 */                 this.jjstateSet[this.jjnewStateCnt++] = 8; 
/*      */               break;
/*      */             case 8:
/*  807 */               if ((0x1800000000L & l) == 0L)
/*      */                 break; 
/*  809 */               if (kind > 54)
/*  810 */                 kind = 54; 
/*  811 */               jjCheckNAdd(9);
/*      */               break;
/*      */             case 9:
/*  814 */               if ((0x3FF001000000000L & l) == 0L)
/*      */                 break; 
/*  816 */               if (kind > 54)
/*  817 */                 kind = 54; 
/*  818 */               jjCheckNAdd(9);
/*      */               break;
/*      */             case 10:
/*  821 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  823 */               if (kind > 9)
/*  824 */                 kind = 9; 
/*  825 */               jjCheckNAddStates(4, 8);
/*      */               break;
/*      */             case 11:
/*  828 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  830 */               if (kind > 9)
/*  831 */                 kind = 9; 
/*  832 */               jjCheckNAdd(11);
/*      */               break;
/*      */             case 12:
/*  835 */               if ((0x3FF000000000000L & l) != 0L)
/*  836 */                 jjCheckNAddTwoStates(12, 13); 
/*      */               break;
/*      */             case 13:
/*  839 */               if (this.curChar != '.')
/*      */                 break; 
/*  841 */               if (kind > 10)
/*  842 */                 kind = 10; 
/*  843 */               jjCheckNAddTwoStates(14, 15);
/*      */               break;
/*      */             case 14:
/*  846 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  848 */               if (kind > 10)
/*  849 */                 kind = 10; 
/*  850 */               jjCheckNAddTwoStates(14, 15);
/*      */               break;
/*      */             case 16:
/*  853 */               if ((0x280000000000L & l) != 0L)
/*  854 */                 jjCheckNAdd(17); 
/*      */               break;
/*      */             case 17:
/*  857 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  859 */               if (kind > 10)
/*  860 */                 kind = 10; 
/*  861 */               jjCheckNAdd(17);
/*      */               break;
/*      */             case 18:
/*  864 */               if ((0x3FF000000000000L & l) != 0L)
/*  865 */                 jjCheckNAddTwoStates(18, 19); 
/*      */               break;
/*      */             case 20:
/*  868 */               if ((0x280000000000L & l) != 0L)
/*  869 */                 jjCheckNAdd(21); 
/*      */               break;
/*      */             case 21:
/*  872 */               if ((0x3FF000000000000L & l) == 0L)
/*      */                 break; 
/*  874 */               if (kind > 10)
/*  875 */                 kind = 10; 
/*  876 */               jjCheckNAdd(21);
/*      */               break;
/*      */             case 22:
/*  879 */               if (this.curChar == '"')
/*  880 */                 jjCheckNAddStates(14, 18); 
/*      */               break;
/*      */             case 23:
/*  883 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  884 */                 jjCheckNAddStates(19, 21); 
/*      */               break;
/*      */             case 25:
/*  887 */               if (this.curChar == '"')
/*  888 */                 jjCheckNAddStates(19, 21); 
/*      */               break;
/*      */             case 26:
/*  891 */               if (this.curChar == '"' && kind > 12)
/*  892 */                 kind = 12; 
/*      */               break;
/*      */             case 27:
/*  895 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L)
/*  896 */                 jjCheckNAddTwoStates(27, 28); 
/*      */               break;
/*      */             case 29:
/*  899 */               if ((0xFFFFFFFBFFFFFFFFL & l) != 0L && kind > 13)
/*  900 */                 kind = 13; 
/*      */               break;
/*      */             case 30:
/*  903 */               if (this.curChar == '\'')
/*  904 */                 jjCheckNAddStates(9, 13); 
/*      */               break;
/*      */             case 31:
/*  907 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  908 */                 jjCheckNAddStates(22, 24); 
/*      */               break;
/*      */             case 33:
/*  911 */               if (this.curChar == '\'')
/*  912 */                 jjCheckNAddStates(22, 24); 
/*      */               break;
/*      */             case 34:
/*  915 */               if (this.curChar == '\'' && kind > 12)
/*  916 */                 kind = 12; 
/*      */               break;
/*      */             case 35:
/*  919 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L)
/*  920 */                 jjCheckNAddTwoStates(35, 36); 
/*      */               break;
/*      */             case 37:
/*  923 */               if ((0xFFFFFF7FFFFFFFFFL & l) != 0L && kind > 13) {
/*  924 */                 kind = 13;
/*      */               }
/*      */               break;
/*      */           } 
/*  928 */         } while (i != startsAt);
/*      */       }
/*  930 */       else if (this.curChar < '') {
/*      */         
/*  932 */         long l = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/*  935 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 6:
/*  939 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  941 */               if (kind > 53)
/*  942 */                 kind = 53; 
/*  943 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 2:
/*  946 */               if ((0x2000000020L & l) != 0L)
/*  947 */                 jjAddStates(25, 26); 
/*      */               break;
/*      */             case 8:
/*      */             case 9:
/*  951 */               if ((0x7FFFFFE87FFFFFEL & l) == 0L)
/*      */                 break; 
/*  953 */               if (kind > 54)
/*  954 */                 kind = 54; 
/*  955 */               jjCheckNAdd(9);
/*      */               break;
/*      */             case 15:
/*  958 */               if ((0x2000000020L & l) != 0L)
/*  959 */                 jjAddStates(27, 28); 
/*      */               break;
/*      */             case 19:
/*  962 */               if ((0x2000000020L & l) != 0L)
/*  963 */                 jjAddStates(29, 30); 
/*      */               break;
/*      */             case 23:
/*  966 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  967 */                 jjCheckNAddStates(19, 21); 
/*      */               break;
/*      */             case 24:
/*  970 */               if (this.curChar == '\\')
/*  971 */                 this.jjstateSet[this.jjnewStateCnt++] = 25; 
/*      */               break;
/*      */             case 25:
/*  974 */               if (this.curChar == '\\')
/*  975 */                 jjCheckNAddStates(19, 21); 
/*      */               break;
/*      */             case 27:
/*  978 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  979 */                 jjAddStates(31, 32); 
/*      */               break;
/*      */             case 28:
/*  982 */               if (this.curChar == '\\')
/*  983 */                 this.jjstateSet[this.jjnewStateCnt++] = 29; 
/*      */               break;
/*      */             case 29:
/*      */             case 37:
/*  987 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L && kind > 13)
/*  988 */                 kind = 13; 
/*      */               break;
/*      */             case 31:
/*  991 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/*  992 */                 jjCheckNAddStates(22, 24); 
/*      */               break;
/*      */             case 32:
/*  995 */               if (this.curChar == '\\')
/*  996 */                 this.jjstateSet[this.jjnewStateCnt++] = 33; 
/*      */               break;
/*      */             case 33:
/*  999 */               if (this.curChar == '\\')
/* 1000 */                 jjCheckNAddStates(22, 24); 
/*      */               break;
/*      */             case 35:
/* 1003 */               if ((0xFFFFFFFFEFFFFFFFL & l) != 0L)
/* 1004 */                 jjAddStates(33, 34); 
/*      */               break;
/*      */             case 36:
/* 1007 */               if (this.curChar == '\\') {
/* 1008 */                 this.jjstateSet[this.jjnewStateCnt++] = 37;
/*      */               }
/*      */               break;
/*      */           } 
/* 1012 */         } while (i != startsAt);
/*      */       }
/*      */       else {
/*      */         
/* 1016 */         int hiByte = this.curChar >> 8;
/* 1017 */         int i1 = hiByte >> 6;
/* 1018 */         long l1 = 1L << (hiByte & 0x3F);
/* 1019 */         int i2 = (this.curChar & 0xFF) >> 6;
/* 1020 */         long l2 = 1L << (this.curChar & 0x3F);
/*      */         
/*      */         do {
/* 1023 */           switch (this.jjstateSet[--i]) {
/*      */             
/*      */             case 0:
/*      */             case 6:
/* 1027 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/* 1029 */               if (kind > 53)
/* 1030 */                 kind = 53; 
/* 1031 */               jjCheckNAdd(6);
/*      */               break;
/*      */             case 8:
/*      */             case 9:
/* 1035 */               if (!jjCanMove_1(hiByte, i1, i2, l1, l2))
/*      */                 break; 
/* 1037 */               if (kind > 54)
/* 1038 */                 kind = 54; 
/* 1039 */               jjCheckNAdd(9);
/*      */               break;
/*      */             case 23:
/* 1042 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 1043 */                 jjAddStates(19, 21); 
/*      */               break;
/*      */             case 27:
/* 1046 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 1047 */                 jjAddStates(31, 32); 
/*      */               break;
/*      */             case 29:
/*      */             case 37:
/* 1051 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2) && kind > 13)
/* 1052 */                 kind = 13; 
/*      */               break;
/*      */             case 31:
/* 1055 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2))
/* 1056 */                 jjAddStates(22, 24); 
/*      */               break;
/*      */             case 35:
/* 1059 */               if (jjCanMove_0(hiByte, i1, i2, l1, l2)) {
/* 1060 */                 jjAddStates(33, 34);
/*      */               }
/*      */               break;
/*      */           } 
/* 1064 */         } while (i != startsAt);
/*      */       } 
/* 1066 */       if (kind != Integer.MAX_VALUE) {
/*      */         
/* 1068 */         this.jjmatchedKind = kind;
/* 1069 */         this.jjmatchedPos = curPos;
/* 1070 */         kind = Integer.MAX_VALUE;
/*      */       } 
/* 1072 */       curPos++;
/* 1073 */       if ((i = this.jjnewStateCnt) == (startsAt = 38 - (this.jjnewStateCnt = startsAt)))
/* 1074 */         return curPos;  
/* 1075 */       try { this.curChar = this.input_stream.readChar(); }
/* 1076 */       catch (IOException e) { return curPos; }
/*      */     
/*      */     } 
/* 1079 */   } static final int[] jjnextStates = new int[] { 0, 1, 3, 5, 11, 12, 13, 18, 19, 31, 32, 34, 35, 36, 23, 24, 26, 27, 28, 23, 24, 26, 31, 32, 34, 3, 4, 16, 17, 20, 21, 27, 28, 35, 36 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2) {
/* 1086 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/* 1089 */         return ((jjbitVec2[i2] & l2) != 0L);
/*      */     } 
/* 1091 */     if ((jjbitVec0[i1] & l1) != 0L)
/* 1092 */       return true; 
/* 1093 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2) {
/* 1098 */     switch (hiByte) {
/*      */       
/*      */       case 0:
/* 1101 */         return ((jjbitVec4[i2] & l2) != 0L);
/*      */       case 48:
/* 1103 */         return ((jjbitVec5[i2] & l2) != 0L);
/*      */       case 49:
/* 1105 */         return ((jjbitVec6[i2] & l2) != 0L);
/*      */       case 51:
/* 1107 */         return ((jjbitVec7[i2] & l2) != 0L);
/*      */       case 61:
/* 1109 */         return ((jjbitVec8[i2] & l2) != 0L);
/*      */     } 
/* 1111 */     if ((jjbitVec3[i1] & l1) != 0L)
/* 1112 */       return true; 
/* 1113 */     return false;
/*      */   }
/*      */   
/* 1116 */   public static final String[] jjstrLiteralImages = new String[] { "", null, "${", "#{", null, null, null, null, null, null, null, null, null, null, "true", "false", "null", "}", ".", "(", ")", "[", "]", ":", ",", ">", "gt", "<", "lt", ">=", "ge", "<=", "le", "==", "eq", "!=", "ne", "!", "not", "&&", "and", "||", "or", "empty", "instanceof", "*", "+", "-", "?", "/", "div", "%", "mod", null, null, null, null, null, null };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1124 */   public static final String[] lexStateNames = new String[] { "DEFAULT", "IN_EXPRESSION" };
/*      */ 
/*      */ 
/*      */   
/* 1128 */   public static final int[] jjnewLexState = new int[] { -1, -1, 1, 1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1133 */   static final long[] jjtoToken = new long[] { 324259173170673167L }; protected SimpleCharStream input_stream; private final int[] jjrounds; private final int[] jjstateSet;
/*      */   protected char curChar;
/*      */   int curLexState;
/* 1136 */   static final long[] jjtoSkip = new long[] { 496L }; int defaultLexState; int jjnewStateCnt;
/*      */   
/*      */   public ELParserTokenManager(SimpleCharStream stream) {
/*      */     this.debugStream = System.out;
/* 1140 */     this.jjrounds = new int[38];
/* 1141 */     this.jjstateSet = new int[76];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1194 */     this.curLexState = 0;
/* 1195 */     this.defaultLexState = 0;
/*      */     this.input_stream = stream;
/*      */   }
/*      */   int jjround; int jjmatchedPos; int jjmatchedKind;
/*      */   public ELParserTokenManager(SimpleCharStream stream, int lexState) {
/*      */     this(stream);
/*      */     SwitchTo(lexState);
/*      */   }
/*      */   public Token getNextToken() {
/* 1204 */     Token specialToken = null;
/*      */     
/* 1206 */     int curPos = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*      */       try {
/* 1213 */         this.curChar = this.input_stream.BeginToken();
/*      */       }
/* 1215 */       catch (IOException e) {
/*      */         
/* 1217 */         this.jjmatchedKind = 0;
/* 1218 */         Token matchedToken = jjFillToken();
/* 1219 */         return matchedToken;
/*      */       } 
/*      */       
/* 1222 */       switch (this.curLexState) {
/*      */         
/*      */         case 0:
/* 1225 */           this.jjmatchedKind = Integer.MAX_VALUE;
/* 1226 */           this.jjmatchedPos = 0;
/* 1227 */           curPos = jjMoveStringLiteralDfa0_0(); break;
/*      */         case 1:
/*      */           
/* 1230 */           try { this.input_stream.backup(0);
/* 1231 */             while (this.curChar <= ' ' && (0x100002600L & 1L << this.curChar) != 0L) {
/* 1232 */               this.curChar = this.input_stream.BeginToken();
/*      */             } }
/* 1234 */           catch (IOException e1) { continue; }
/* 1235 */            this.jjmatchedKind = Integer.MAX_VALUE;
/* 1236 */           this.jjmatchedPos = 0;
/* 1237 */           curPos = jjMoveStringLiteralDfa0_1();
/* 1238 */           if (this.jjmatchedPos == 0 && this.jjmatchedKind > 58)
/*      */           {
/* 1240 */             this.jjmatchedKind = 58;
/*      */           }
/*      */           break;
/*      */       } 
/* 1244 */       if (this.jjmatchedKind != Integer.MAX_VALUE) {
/*      */         
/* 1246 */         if (this.jjmatchedPos + 1 < curPos)
/* 1247 */           this.input_stream.backup(curPos - this.jjmatchedPos - 1); 
/* 1248 */         if ((jjtoToken[this.jjmatchedKind >> 6] & 1L << (this.jjmatchedKind & 0x3F)) != 0L) {
/*      */           
/* 1250 */           Token matchedToken = jjFillToken();
/* 1251 */           if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1252 */             this.curLexState = jjnewLexState[this.jjmatchedKind]; 
/* 1253 */           return matchedToken;
/*      */         } 
/*      */ 
/*      */         
/* 1257 */         if (jjnewLexState[this.jjmatchedKind] != -1)
/* 1258 */           this.curLexState = jjnewLexState[this.jjmatchedKind];  continue;
/*      */       } 
/*      */       break;
/*      */     } 
/* 1262 */     int error_line = this.input_stream.getEndLine();
/* 1263 */     int error_column = this.input_stream.getEndColumn();
/* 1264 */     String error_after = null;
/* 1265 */     boolean EOFSeen = false; try {
/* 1266 */       this.input_stream.readChar(); this.input_stream.backup(1);
/* 1267 */     } catch (IOException e1) {
/* 1268 */       EOFSeen = true;
/* 1269 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/* 1270 */       if (this.curChar == '\n' || this.curChar == '\r') {
/* 1271 */         error_line++;
/* 1272 */         error_column = 0;
/*      */       } else {
/*      */         
/* 1275 */         error_column++;
/*      */       } 
/* 1277 */     }  if (!EOFSeen) {
/* 1278 */       this.input_stream.backup(1);
/* 1279 */       error_after = (curPos <= 1) ? "" : this.input_stream.GetImage();
/*      */     } 
/* 1281 */     throw new TokenMgrError(EOFSeen, this.curLexState, error_line, error_column, error_after, this.curChar, 0);
/*      */   }
/*      */   
/*      */   public void ReInit(SimpleCharStream stream) {
/*      */     this.jjmatchedPos = this.jjnewStateCnt = 0;
/*      */     this.curLexState = this.defaultLexState;
/*      */     this.input_stream = stream;
/*      */     ReInitRounds();
/*      */   }
/*      */   
/*      */   private final void ReInitRounds() {
/*      */     this.jjround = -2147483647;
/*      */     for (int i = 38; i-- > 0;)
/*      */       this.jjrounds[i] = Integer.MIN_VALUE; 
/*      */   }
/*      */   
/*      */   public void ReInit(SimpleCharStream stream, int lexState) {
/*      */     ReInit(stream);
/*      */     SwitchTo(lexState);
/*      */   }
/*      */   
/*      */   public void SwitchTo(int lexState) {
/*      */     if (lexState >= 2 || lexState < 0)
/*      */       throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2); 
/*      */     this.curLexState = lexState;
/*      */   }
/*      */   
/*      */   protected Token jjFillToken() {
/*      */     Token t = Token.newToken(this.jjmatchedKind);
/*      */     t.kind = this.jjmatchedKind;
/*      */     String im = jjstrLiteralImages[this.jjmatchedKind];
/*      */     t.image = (im == null) ? this.input_stream.GetImage() : im;
/*      */     t.beginLine = this.input_stream.getBeginLine();
/*      */     t.beginColumn = this.input_stream.getBeginColumn();
/*      */     t.endLine = this.input_stream.getEndLine();
/*      */     t.endColumn = this.input_stream.getEndColumn();
/*      */     return t;
/*      */   }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/ELParserTokenManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */