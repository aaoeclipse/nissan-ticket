/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Converter<S, T>
/*     */ {
/*  49 */   static final Converter BYTE_TO_STRING_CONVERTER = new Converter()
/*     */     {
/*  51 */       public Object convertForward(Object value) { return Byte.toString(((Byte)value).byteValue()); }
/*     */ 
/*     */ 
/*     */       
/*  55 */       public Object convertReverse(Object value) { return Byte.valueOf(Byte.parseByte((String)value)); }
/*     */     };
/*     */ 
/*     */   
/*  59 */   static final Converter SHORT_TO_STRING_CONVERTER = new Converter()
/*     */     {
/*  61 */       public Object convertForward(Object value) { return Short.toString(((Short)value).shortValue()); }
/*     */ 
/*     */ 
/*     */       
/*  65 */       public Object convertReverse(Object value) { return Short.valueOf(Short.parseShort((String)value)); }
/*     */     };
/*     */ 
/*     */   
/*  69 */   static final Converter INT_TO_STRING_CONVERTER = new Converter()
/*     */     {
/*  71 */       public Object convertForward(Object value) { return Integer.toString(((Integer)value).intValue()); }
/*     */ 
/*     */ 
/*     */       
/*  75 */       public Object convertReverse(Object value) { return Integer.valueOf(Integer.parseInt((String)value)); }
/*     */     };
/*     */ 
/*     */   
/*  79 */   static final Converter LONG_TO_STRING_CONVERTER = new Converter()
/*     */     {
/*  81 */       public Object convertForward(Object value) { return Long.toString(((Long)value).longValue()); }
/*     */ 
/*     */ 
/*     */       
/*  85 */       public Object convertReverse(Object value) { return Long.valueOf(Long.parseLong((String)value)); }
/*     */     };
/*     */ 
/*     */   
/*  89 */   static final Converter FLOAT_TO_STRING_CONVERTER = new Converter()
/*     */     {
/*  91 */       public Object convertForward(Object value) { return Float.toString(((Float)value).floatValue()); }
/*     */ 
/*     */ 
/*     */       
/*  95 */       public Object convertReverse(Object value) { return Float.valueOf(Float.parseFloat((String)value)); }
/*     */     };
/*     */ 
/*     */   
/*  99 */   static final Converter DOUBLE_TO_STRING_CONVERTER = new Converter()
/*     */     {
/* 101 */       public Object convertForward(Object value) { return Double.toString(((Double)value).doubleValue()); }
/*     */ 
/*     */ 
/*     */       
/* 105 */       public Object convertReverse(Object value) { return Double.valueOf(Double.parseDouble((String)value)); }
/*     */     };
/*     */ 
/*     */   
/* 109 */   static final Converter CHAR_TO_STRING_CONVERTER = new Converter()
/*     */     {
/* 111 */       public Object convertForward(Object value) { return ((Character)value).toString(); }
/*     */ 
/*     */       
/*     */       public Object convertReverse(Object value) {
/* 115 */         String strVal = (String)value;
/*     */         
/* 117 */         if (strVal.length() != 1) {
/* 118 */           throw new IllegalArgumentException("String doesn't represent a char");
/*     */         }
/*     */         
/* 121 */         return Character.valueOf(strVal.charAt(0));
/*     */       }
/*     */     };
/*     */   
/* 125 */   static final Converter BOOLEAN_TO_STRING_CONVERTER = new Converter()
/*     */     {
/* 127 */       public Object convertForward(Object value) { return ((Boolean)value).toString(); }
/*     */ 
/*     */ 
/*     */       
/* 131 */       public Object convertReverse(Object value) { return new Boolean((String)value); }
/*     */     };
/*     */ 
/*     */   
/* 135 */   static final Converter INT_TO_BOOLEAN_CONVERTER = new Converter() {
/*     */       public Object convertForward(Object value) {
/* 137 */         if (((Integer)value).intValue() == 0) {
/* 138 */           return Boolean.FALSE;
/*     */         }
/* 140 */         return Boolean.TRUE;
/*     */       }
/*     */       
/*     */       public Object convertReverse(Object value) {
/* 144 */         if (((Boolean)value).booleanValue()) {
/* 145 */           return Integer.valueOf(1);
/*     */         }
/* 147 */         return Integer.valueOf(0);
/*     */       }
/*     */     };
/*     */   
/* 151 */   static final Converter BIGINTEGER_TO_STRING_CONVERTER = new Converter()
/*     */     {
/* 153 */       public Object convertForward(Object value) { return ((BigInteger)value).toString(); }
/*     */ 
/*     */ 
/*     */       
/* 157 */       public Object convertReverse(Object value) { return new BigInteger((String)value); }
/*     */     };
/*     */ 
/*     */   
/* 161 */   static final Converter BIGDECIMAL_TO_STRING_CONVERTER = new Converter()
/*     */     {
/* 163 */       public Object convertForward(Object value) { return ((BigDecimal)value).toString(); }
/*     */ 
/*     */ 
/*     */       
/* 167 */       public Object convertReverse(Object value) { return new BigDecimal((String)value); }
/*     */     };
/*     */ 
/*     */   
/*     */   static final Object defaultConvert(Object source, Class<?> targetType) {
/* 172 */     Class<?> sourceType = source.getClass();
/*     */     
/* 174 */     if (sourceType == targetType) {
/* 175 */       return source;
/*     */     }
/*     */     
/* 178 */     if (targetType == String.class) {
/* 179 */       if (sourceType == Byte.class)
/* 180 */         return BYTE_TO_STRING_CONVERTER.convertForward(source); 
/* 181 */       if (sourceType == Short.class)
/* 182 */         return SHORT_TO_STRING_CONVERTER.convertForward(source); 
/* 183 */       if (sourceType == Integer.class)
/* 184 */         return INT_TO_STRING_CONVERTER.convertForward(source); 
/* 185 */       if (sourceType == Long.class)
/* 186 */         return LONG_TO_STRING_CONVERTER.convertForward(source); 
/* 187 */       if (sourceType == Float.class)
/* 188 */         return FLOAT_TO_STRING_CONVERTER.convertForward(source); 
/* 189 */       if (sourceType == Double.class)
/* 190 */         return DOUBLE_TO_STRING_CONVERTER.convertForward(source); 
/* 191 */       if (sourceType == Boolean.class)
/* 192 */         return BOOLEAN_TO_STRING_CONVERTER.convertForward(source); 
/* 193 */       if (sourceType == Character.class)
/* 194 */         return CHAR_TO_STRING_CONVERTER.convertForward(source); 
/* 195 */       if (sourceType == BigInteger.class)
/* 196 */         return BIGINTEGER_TO_STRING_CONVERTER.convertForward(source); 
/* 197 */       if (sourceType == BigDecimal.class) {
/* 198 */         return BIGDECIMAL_TO_STRING_CONVERTER.convertForward(source);
/*     */       }
/* 200 */     } else if (sourceType == String.class) {
/* 201 */       if (targetType == Byte.class)
/* 202 */         return BYTE_TO_STRING_CONVERTER.convertReverse(source); 
/* 203 */       if (targetType == Short.class)
/* 204 */         return SHORT_TO_STRING_CONVERTER.convertReverse(source); 
/* 205 */       if (targetType == Integer.class)
/* 206 */         return INT_TO_STRING_CONVERTER.convertReverse(source); 
/* 207 */       if (targetType == Long.class)
/* 208 */         return LONG_TO_STRING_CONVERTER.convertReverse(source); 
/* 209 */       if (targetType == Float.class)
/* 210 */         return FLOAT_TO_STRING_CONVERTER.convertReverse(source); 
/* 211 */       if (targetType == Double.class)
/* 212 */         return DOUBLE_TO_STRING_CONVERTER.convertReverse(source); 
/* 213 */       if (targetType == Boolean.class)
/* 214 */         return BOOLEAN_TO_STRING_CONVERTER.convertReverse(source); 
/* 215 */       if (targetType == Character.class)
/* 216 */         return CHAR_TO_STRING_CONVERTER.convertReverse(source); 
/* 217 */       if (targetType == BigInteger.class)
/* 218 */         return BIGINTEGER_TO_STRING_CONVERTER.convertReverse(source); 
/* 219 */       if (targetType == BigDecimal.class)
/* 220 */         return BIGDECIMAL_TO_STRING_CONVERTER.convertReverse(source); 
/*     */     } else {
/* 222 */       if (sourceType == Integer.class && targetType == Boolean.class)
/* 223 */         return INT_TO_BOOLEAN_CONVERTER.convertForward(source); 
/* 224 */       if (sourceType == Boolean.class && targetType == Integer.class) {
/* 225 */         return INT_TO_BOOLEAN_CONVERTER.convertReverse(source);
/*     */       }
/*     */     } 
/* 228 */     return source;
/*     */   }
/*     */   
/*     */   public abstract T convertForward(S paramS);
/*     */   
/*     */   public abstract S convertReverse(T paramT);
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/Converter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */