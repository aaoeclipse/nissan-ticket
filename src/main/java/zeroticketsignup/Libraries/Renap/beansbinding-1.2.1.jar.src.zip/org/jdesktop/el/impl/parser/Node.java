package org.jdesktop.el.impl.parser;

import org.jdesktop.el.ELException;
import org.jdesktop.el.MethodInfo;
import org.jdesktop.el.impl.lang.EvaluationContext;

public interface Node {
  void jjtOpen();
  
  void jjtClose();
  
  void jjtSetParent(Node paramNode);
  
  Node jjtGetParent();
  
  void jjtAddChild(Node paramNode, int paramInt);
  
  Node jjtGetChild(int paramInt);
  
  int jjtGetNumChildren();
  
  String getImage();
  
  Object getValue(EvaluationContext paramEvaluationContext) throws ELException;
  
  void setValue(EvaluationContext paramEvaluationContext, Object paramObject) throws ELException;
  
  Class getType(EvaluationContext paramEvaluationContext) throws ELException;
  
  boolean isReadOnly(EvaluationContext paramEvaluationContext) throws ELException;
  
  void accept(NodeVisitor paramNodeVisitor) throws ELException;
  
  MethodInfo getMethodInfo(EvaluationContext paramEvaluationContext, Class[] paramArrayOfClass) throws ELException;
  
  Object invoke(EvaluationContext paramEvaluationContext, Class[] paramArrayOfClass, Object[] paramArrayOfObject) throws ELException;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/Node.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */