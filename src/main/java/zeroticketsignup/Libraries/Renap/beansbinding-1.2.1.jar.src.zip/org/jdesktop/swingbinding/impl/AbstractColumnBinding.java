/*    */ package org.jdesktop.swingbinding.impl;
/*    */ 
/*    */ import org.jdesktop.beansbinding.Binding;
/*    */ import org.jdesktop.beansbinding.Property;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractColumnBinding
/*    */   extends Binding
/*    */ {
/*    */   private int column;
/*    */   
/*    */   public AbstractColumnBinding(int column, Property columnSource, Property columnTarget, String name) {
/* 18 */     super(null, columnSource, null, columnTarget, name);
/* 19 */     this.column = column;
/* 20 */     setManaged(true);
/*    */   }
/*    */ 
/*    */   
/* 24 */   public final int getColumn() { return this.column; }
/*    */ 
/*    */ 
/*    */   
/* 28 */   protected final void setColumn(int column) { this.column = column; }
/*    */   
/*    */   public void bindImpl() {}
/*    */   
/*    */   public void unbindImpl() {}
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/impl/AbstractColumnBinding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */