/*      */ package org.jdesktop.el.impl.parser;public class ELParser implements ELParserTreeConstants, ELParserConstants { protected JJTELParserState jjtree; public ELParserTokenManager token_source; SimpleCharStream jj_input_stream; public Token token; public Token jj_nt; private int jj_ntk; private Token jj_scanpos; private Token jj_lastpos; private int jj_la; public boolean lookingAhead; private boolean jj_semLA; private int jj_gen; private final int[] jj_la1; private static int[] jj_la1_0; private static int[] jj_la1_1; private final JJCalls[] jj_2_rtns;
/*      */   private boolean jj_rescan;
/*      */   private int jj_gc;
/*      */   private final LookaheadSuccess jj_ls;
/*      */   private Vector jj_expentries;
/*      */   private int[] jj_expentry;
/*      */   private int jj_kind;
/*      */   private int[] jj_lasttokens;
/*      */   private int jj_endpos;
/*      */   
/*      */   public static Node parse(String ref) throws ELException {
/*      */     try {
/*   13 */       return (new ELParser(new StringReader(ref))).CompositeExpression();
/*   14 */     } catch (ParseException pe) {
/*   15 */       throw new ELException(pe.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final AstCompositeExpression CompositeExpression() throws ParseException {
/*   26 */     AstCompositeExpression jjtn000 = new AstCompositeExpression(0);
/*   27 */     boolean jjtc000 = true;
/*   28 */     this.jjtree.openNodeScope(jjtn000);
/*      */     
/*      */     try {
/*      */       while (true) {
/*   32 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 1:
/*      */           case 2:
/*      */           case 3:
/*      */             break;
/*      */           
/*      */           default:
/*   39 */             this.jj_la1[0] = this.jj_gen;
/*      */             break;
/*      */         } 
/*   42 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 3:
/*   44 */             DeferredExpression();
/*      */             continue;
/*      */           case 2:
/*   47 */             DynamicExpression();
/*      */             continue;
/*      */           case 1:
/*   50 */             LiteralExpression();
/*      */             continue;
/*      */         } 
/*   53 */         this.jj_la1[1] = this.jj_gen;
/*   54 */         jj_consume_token(-1);
/*   55 */         throw new ParseException();
/*      */       } 
/*      */       
/*   58 */       jj_consume_token(0);
/*   59 */       this.jjtree.closeNodeScope(jjtn000, true);
/*   60 */       jjtc000 = false;
/*   61 */       return jjtn000;
/*   62 */     } catch (Throwable jjte000) {
/*   63 */       if (jjtc000) {
/*   64 */         this.jjtree.clearNodeScope(jjtn000);
/*   65 */         jjtc000 = false;
/*      */       } else {
/*   67 */         this.jjtree.popNode();
/*      */       } 
/*   69 */       if (jjte000 instanceof RuntimeException) {
/*   70 */         throw (RuntimeException)jjte000;
/*      */       }
/*   72 */       if (jjte000 instanceof ParseException) {
/*   73 */         throw (ParseException)jjte000;
/*      */       }
/*   75 */       throw (Error)jjte000;
/*      */     } finally {
/*   77 */       if (jjtc000) {
/*   78 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void LiteralExpression() throws ParseException {
/*   90 */     AstLiteralExpression jjtn000 = new AstLiteralExpression(1);
/*   91 */     boolean jjtc000 = true;
/*   92 */     this.jjtree.openNodeScope(jjtn000); Token t = null;
/*      */     try {
/*   94 */       t = jj_consume_token(1);
/*   95 */       this.jjtree.closeNodeScope(jjtn000, true);
/*   96 */       jjtc000 = false;
/*   97 */       jjtn000.setImage(t.image);
/*      */     } finally {
/*   99 */       if (jjtc000) {
/*  100 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void DeferredExpression() throws ParseException {
/*  111 */     AstDeferredExpression jjtn000 = new AstDeferredExpression(2);
/*  112 */     boolean jjtc000 = true;
/*  113 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/*  115 */       jj_consume_token(3);
/*  116 */       Expression();
/*  117 */       jj_consume_token(17);
/*  118 */     } catch (Throwable jjte000) {
/*  119 */       if (jjtc000) {
/*  120 */         this.jjtree.clearNodeScope(jjtn000);
/*  121 */         jjtc000 = false;
/*      */       } else {
/*  123 */         this.jjtree.popNode();
/*      */       } 
/*  125 */       if (jjte000 instanceof RuntimeException) {
/*  126 */         throw (RuntimeException)jjte000;
/*      */       }
/*  128 */       if (jjte000 instanceof ParseException) {
/*  129 */         throw (ParseException)jjte000;
/*      */       }
/*  131 */       throw (Error)jjte000;
/*      */     } finally {
/*  133 */       if (jjtc000) {
/*  134 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void DynamicExpression() throws ParseException {
/*  145 */     AstDynamicExpression jjtn000 = new AstDynamicExpression(3);
/*  146 */     boolean jjtc000 = true;
/*  147 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/*  149 */       jj_consume_token(2);
/*  150 */       Expression();
/*  151 */       jj_consume_token(17);
/*  152 */     } catch (Throwable jjte000) {
/*  153 */       if (jjtc000) {
/*  154 */         this.jjtree.clearNodeScope(jjtn000);
/*  155 */         jjtc000 = false;
/*      */       } else {
/*  157 */         this.jjtree.popNode();
/*      */       } 
/*  159 */       if (jjte000 instanceof RuntimeException) {
/*  160 */         throw (RuntimeException)jjte000;
/*      */       }
/*  162 */       if (jjte000 instanceof ParseException) {
/*  163 */         throw (ParseException)jjte000;
/*      */       }
/*  165 */       throw (Error)jjte000;
/*      */     } finally {
/*  167 */       if (jjtc000) {
/*  168 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  178 */   public final void Expression() throws ParseException { Choice(); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Choice() throws ParseException {
/*  186 */     Or();
/*      */     
/*      */     while (true) {
/*  189 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 48:
/*      */           break;
/*      */         
/*      */         default:
/*  194 */           this.jj_la1[2] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  197 */       jj_consume_token(48);
/*  198 */       Or();
/*  199 */       jj_consume_token(23);
/*  200 */       AstChoice jjtn001 = new AstChoice(5);
/*  201 */       boolean jjtc001 = true;
/*  202 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  204 */         Choice();
/*  205 */       } catch (Throwable jjte001) {
/*  206 */         if (jjtc001) {
/*  207 */           this.jjtree.clearNodeScope(jjtn001);
/*  208 */           jjtc001 = false;
/*      */         } else {
/*  210 */           this.jjtree.popNode();
/*      */         } 
/*  212 */         if (jjte001 instanceof RuntimeException) {
/*  213 */           throw (RuntimeException)jjte001;
/*      */         }
/*  215 */         if (jjte001 instanceof ParseException) {
/*  216 */           throw (ParseException)jjte001;
/*      */         }
/*  218 */         throw (Error)jjte001;
/*      */       } finally {
/*  220 */         if (jjtc001) {
/*  221 */           this.jjtree.closeNodeScope(jjtn001, 3);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Or() throws ParseException {
/*  232 */     And();
/*      */     
/*      */     while (true) {
/*  235 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 41:
/*      */         case 42:
/*      */           break;
/*      */         
/*      */         default:
/*  241 */           this.jj_la1[3] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  244 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 41:
/*  246 */           jj_consume_token(41);
/*      */           break;
/*      */         case 42:
/*  249 */           jj_consume_token(42);
/*      */           break;
/*      */         default:
/*  252 */           this.jj_la1[4] = this.jj_gen;
/*  253 */           jj_consume_token(-1);
/*  254 */           throw new ParseException();
/*      */       } 
/*  256 */       AstOr jjtn001 = new AstOr(6);
/*  257 */       boolean jjtc001 = true;
/*  258 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  260 */         And();
/*  261 */       } catch (Throwable jjte001) {
/*  262 */         if (jjtc001) {
/*  263 */           this.jjtree.clearNodeScope(jjtn001);
/*  264 */           jjtc001 = false;
/*      */         } else {
/*  266 */           this.jjtree.popNode();
/*      */         } 
/*  268 */         if (jjte001 instanceof RuntimeException) {
/*  269 */           throw (RuntimeException)jjte001;
/*      */         }
/*  271 */         if (jjte001 instanceof ParseException) {
/*  272 */           throw (ParseException)jjte001;
/*      */         }
/*  274 */         throw (Error)jjte001;
/*      */       } finally {
/*  276 */         if (jjtc001) {
/*  277 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void And() throws ParseException {
/*  288 */     Equality();
/*      */     
/*      */     while (true) {
/*  291 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 39:
/*      */         case 40:
/*      */           break;
/*      */         
/*      */         default:
/*  297 */           this.jj_la1[5] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  300 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 39:
/*  302 */           jj_consume_token(39);
/*      */           break;
/*      */         case 40:
/*  305 */           jj_consume_token(40);
/*      */           break;
/*      */         default:
/*  308 */           this.jj_la1[6] = this.jj_gen;
/*  309 */           jj_consume_token(-1);
/*  310 */           throw new ParseException();
/*      */       } 
/*  312 */       AstAnd jjtn001 = new AstAnd(7);
/*  313 */       boolean jjtc001 = true;
/*  314 */       this.jjtree.openNodeScope(jjtn001);
/*      */       try {
/*  316 */         Equality();
/*  317 */       } catch (Throwable jjte001) {
/*  318 */         if (jjtc001) {
/*  319 */           this.jjtree.clearNodeScope(jjtn001);
/*  320 */           jjtc001 = false;
/*      */         } else {
/*  322 */           this.jjtree.popNode();
/*      */         } 
/*  324 */         if (jjte001 instanceof RuntimeException) {
/*  325 */           throw (RuntimeException)jjte001;
/*      */         }
/*  327 */         if (jjte001 instanceof ParseException) {
/*  328 */           throw (ParseException)jjte001;
/*      */         }
/*  330 */         throw (Error)jjte001;
/*      */       } finally {
/*  332 */         if (jjtc001) {
/*  333 */           this.jjtree.closeNodeScope(jjtn001, 2);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Equality() throws ParseException {
/*  344 */     Compare(); while (true) {
/*      */       boolean jjtc002; AstNotEqual jjtn002; boolean jjtc001;
/*      */       AstEqual jjtn001;
/*  347 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 33:
/*      */         case 34:
/*      */         case 35:
/*      */         case 36:
/*      */           break;
/*      */         
/*      */         default:
/*  355 */           this.jj_la1[7] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  358 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 33:
/*      */         case 34:
/*  361 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 33:
/*  363 */               jj_consume_token(33);
/*      */               break;
/*      */             case 34:
/*  366 */               jj_consume_token(34);
/*      */               break;
/*      */             default:
/*  369 */               this.jj_la1[8] = this.jj_gen;
/*  370 */               jj_consume_token(-1);
/*  371 */               throw new ParseException();
/*      */           } 
/*  373 */           jjtn001 = new AstEqual(8);
/*  374 */           jjtc001 = true;
/*  375 */           this.jjtree.openNodeScope(jjtn001);
/*      */           
/*  377 */           try { Compare();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  393 */             if (jjtc001)
/*  394 */               this.jjtree.closeNodeScope(jjtn001, 2);  } catch (Throwable jjte001) { if (jjtc001) { this.jjtree.clearNodeScope(jjtn001); jjtc001 = false; } else { this.jjtree.popNode(); }  if (jjte001 instanceof RuntimeException) throw (RuntimeException)jjte001;  if (jjte001 instanceof ParseException) throw (ParseException)jjte001;  throw (Error)jjte001; } finally { if (jjtc001) this.jjtree.closeNodeScope(jjtn001, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 35:
/*      */         case 36:
/*  400 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 35:
/*  402 */               jj_consume_token(35);
/*      */               break;
/*      */             case 36:
/*  405 */               jj_consume_token(36);
/*      */               break;
/*      */             default:
/*  408 */               this.jj_la1[9] = this.jj_gen;
/*  409 */               jj_consume_token(-1);
/*  410 */               throw new ParseException();
/*      */           } 
/*  412 */           jjtn002 = new AstNotEqual(9);
/*  413 */           jjtc002 = true;
/*  414 */           this.jjtree.openNodeScope(jjtn002);
/*      */           
/*  416 */           try { Compare();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  432 */             if (jjtc002)
/*  433 */               this.jjtree.closeNodeScope(jjtn002, 2);  } catch (Throwable jjte002) { if (jjtc002) { this.jjtree.clearNodeScope(jjtn002); jjtc002 = false; } else { this.jjtree.popNode(); }  if (jjte002 instanceof RuntimeException) throw (RuntimeException)jjte002;  if (jjte002 instanceof ParseException) throw (ParseException)jjte002;  throw (Error)jjte002; } finally { if (jjtc002) this.jjtree.closeNodeScope(jjtn002, 2);
/*      */              }
/*      */         
/*      */       } 
/*      */       
/*  438 */       this.jj_la1[10] = this.jj_gen;
/*  439 */       jj_consume_token(-1);
/*  440 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Compare() throws ParseException {
/*  450 */     Math(); while (true) {
/*      */       boolean jjtc004; AstGreaterThanEqual jjtn004; boolean jjtc003; AstLessThanEqual jjtn003; boolean jjtc002; AstGreaterThan jjtn002; boolean jjtc001;
/*      */       AstLessThan jjtn001;
/*  453 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 25:
/*      */         case 26:
/*      */         case 27:
/*      */         case 28:
/*      */         case 29:
/*      */         case 30:
/*      */         case 31:
/*      */         case 32:
/*      */           break;
/*      */         
/*      */         default:
/*  465 */           this.jj_la1[11] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  468 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 27:
/*      */         case 28:
/*  471 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 27:
/*  473 */               jj_consume_token(27);
/*      */               break;
/*      */             case 28:
/*  476 */               jj_consume_token(28);
/*      */               break;
/*      */             default:
/*  479 */               this.jj_la1[12] = this.jj_gen;
/*  480 */               jj_consume_token(-1);
/*  481 */               throw new ParseException();
/*      */           } 
/*  483 */           jjtn001 = new AstLessThan(10);
/*  484 */           jjtc001 = true;
/*  485 */           this.jjtree.openNodeScope(jjtn001);
/*      */           
/*  487 */           try { Math();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  503 */             if (jjtc001)
/*  504 */               this.jjtree.closeNodeScope(jjtn001, 2);  } catch (Throwable jjte001) { if (jjtc001) { this.jjtree.clearNodeScope(jjtn001); jjtc001 = false; } else { this.jjtree.popNode(); }  if (jjte001 instanceof RuntimeException) throw (RuntimeException)jjte001;  if (jjte001 instanceof ParseException) throw (ParseException)jjte001;  throw (Error)jjte001; } finally { if (jjtc001) this.jjtree.closeNodeScope(jjtn001, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 25:
/*      */         case 26:
/*  510 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 25:
/*  512 */               jj_consume_token(25);
/*      */               break;
/*      */             case 26:
/*  515 */               jj_consume_token(26);
/*      */               break;
/*      */             default:
/*  518 */               this.jj_la1[13] = this.jj_gen;
/*  519 */               jj_consume_token(-1);
/*  520 */               throw new ParseException();
/*      */           } 
/*  522 */           jjtn002 = new AstGreaterThan(11);
/*  523 */           jjtc002 = true;
/*  524 */           this.jjtree.openNodeScope(jjtn002);
/*      */           
/*  526 */           try { Math();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  542 */             if (jjtc002)
/*  543 */               this.jjtree.closeNodeScope(jjtn002, 2);  } catch (Throwable jjte002) { if (jjtc002) { this.jjtree.clearNodeScope(jjtn002); jjtc002 = false; } else { this.jjtree.popNode(); }  if (jjte002 instanceof RuntimeException) throw (RuntimeException)jjte002;  if (jjte002 instanceof ParseException) throw (ParseException)jjte002;  throw (Error)jjte002; } finally { if (jjtc002) this.jjtree.closeNodeScope(jjtn002, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 31:
/*      */         case 32:
/*  549 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 31:
/*  551 */               jj_consume_token(31);
/*      */               break;
/*      */             case 32:
/*  554 */               jj_consume_token(32);
/*      */               break;
/*      */             default:
/*  557 */               this.jj_la1[14] = this.jj_gen;
/*  558 */               jj_consume_token(-1);
/*  559 */               throw new ParseException();
/*      */           } 
/*  561 */           jjtn003 = new AstLessThanEqual(12);
/*  562 */           jjtc003 = true;
/*  563 */           this.jjtree.openNodeScope(jjtn003);
/*      */           
/*  565 */           try { Math();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  581 */             if (jjtc003)
/*  582 */               this.jjtree.closeNodeScope(jjtn003, 2);  } catch (Throwable jjte003) { if (jjtc003) { this.jjtree.clearNodeScope(jjtn003); jjtc003 = false; } else { this.jjtree.popNode(); }  if (jjte003 instanceof RuntimeException) throw (RuntimeException)jjte003;  if (jjte003 instanceof ParseException) throw (ParseException)jjte003;  throw (Error)jjte003; } finally { if (jjtc003) this.jjtree.closeNodeScope(jjtn003, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 29:
/*      */         case 30:
/*  588 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 29:
/*  590 */               jj_consume_token(29);
/*      */               break;
/*      */             case 30:
/*  593 */               jj_consume_token(30);
/*      */               break;
/*      */             default:
/*  596 */               this.jj_la1[15] = this.jj_gen;
/*  597 */               jj_consume_token(-1);
/*  598 */               throw new ParseException();
/*      */           } 
/*  600 */           jjtn004 = new AstGreaterThanEqual(13);
/*  601 */           jjtc004 = true;
/*  602 */           this.jjtree.openNodeScope(jjtn004);
/*      */           
/*  604 */           try { Math();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  620 */             if (jjtc004)
/*  621 */               this.jjtree.closeNodeScope(jjtn004, 2);  } catch (Throwable jjte004) { if (jjtc004) { this.jjtree.clearNodeScope(jjtn004); jjtc004 = false; } else { this.jjtree.popNode(); }  if (jjte004 instanceof RuntimeException) throw (RuntimeException)jjte004;  if (jjte004 instanceof ParseException) throw (ParseException)jjte004;  throw (Error)jjte004; } finally { if (jjtc004) this.jjtree.closeNodeScope(jjtn004, 2);
/*      */              }
/*      */         
/*      */       } 
/*      */       
/*  626 */       this.jj_la1[16] = this.jj_gen;
/*  627 */       jj_consume_token(-1);
/*  628 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Math() throws ParseException {
/*  638 */     Multiplication(); while (true) {
/*      */       boolean jjtc002; AstMinus jjtn002; boolean jjtc001;
/*      */       AstPlus jjtn001;
/*  641 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 46:
/*      */         case 47:
/*      */           break;
/*      */         
/*      */         default:
/*  647 */           this.jj_la1[17] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  650 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 46:
/*  652 */           jj_consume_token(46);
/*  653 */           jjtn001 = new AstPlus(14);
/*  654 */           jjtc001 = true;
/*  655 */           this.jjtree.openNodeScope(jjtn001);
/*      */           
/*  657 */           try { Multiplication();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  673 */             if (jjtc001)
/*  674 */               this.jjtree.closeNodeScope(jjtn001, 2);  } catch (Throwable jjte001) { if (jjtc001) { this.jjtree.clearNodeScope(jjtn001); jjtc001 = false; } else { this.jjtree.popNode(); }  if (jjte001 instanceof RuntimeException) throw (RuntimeException)jjte001;  if (jjte001 instanceof ParseException) throw (ParseException)jjte001;  throw (Error)jjte001; } finally { if (jjtc001) this.jjtree.closeNodeScope(jjtn001, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 47:
/*  679 */           jj_consume_token(47);
/*  680 */           jjtn002 = new AstMinus(15);
/*  681 */           jjtc002 = true;
/*  682 */           this.jjtree.openNodeScope(jjtn002);
/*      */           
/*  684 */           try { Multiplication();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  700 */             if (jjtc002)
/*  701 */               this.jjtree.closeNodeScope(jjtn002, 2);  } catch (Throwable jjte002) { if (jjtc002) { this.jjtree.clearNodeScope(jjtn002); jjtc002 = false; } else { this.jjtree.popNode(); }  if (jjte002 instanceof RuntimeException) throw (RuntimeException)jjte002;  if (jjte002 instanceof ParseException) throw (ParseException)jjte002;  throw (Error)jjte002; } finally { if (jjtc002) this.jjtree.closeNodeScope(jjtn002, 2);
/*      */              }
/*      */         
/*      */       } 
/*      */       
/*  706 */       this.jj_la1[18] = this.jj_gen;
/*  707 */       jj_consume_token(-1);
/*  708 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Multiplication() throws ParseException {
/*  718 */     Unary(); while (true) {
/*      */       boolean jjtc003; AstMod jjtn003; boolean jjtc002; AstDiv jjtn002; boolean jjtc001;
/*      */       AstMult jjtn001;
/*  721 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 45:
/*      */         case 49:
/*      */         case 50:
/*      */         case 51:
/*      */         case 52:
/*      */           break;
/*      */         
/*      */         default:
/*  730 */           this.jj_la1[19] = this.jj_gen;
/*      */           break;
/*      */       } 
/*  733 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 45:
/*  735 */           jj_consume_token(45);
/*  736 */           jjtn001 = new AstMult(16);
/*  737 */           jjtc001 = true;
/*  738 */           this.jjtree.openNodeScope(jjtn001);
/*      */           
/*  740 */           try { Unary();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  756 */             if (jjtc001)
/*  757 */               this.jjtree.closeNodeScope(jjtn001, 2);  } catch (Throwable jjte001) { if (jjtc001) { this.jjtree.clearNodeScope(jjtn001); jjtc001 = false; } else { this.jjtree.popNode(); }  if (jjte001 instanceof RuntimeException) throw (RuntimeException)jjte001;  if (jjte001 instanceof ParseException) throw (ParseException)jjte001;  throw (Error)jjte001; } finally { if (jjtc001) this.jjtree.closeNodeScope(jjtn001, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 49:
/*      */         case 50:
/*  763 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 49:
/*  765 */               jj_consume_token(49);
/*      */               break;
/*      */             case 50:
/*  768 */               jj_consume_token(50);
/*      */               break;
/*      */             default:
/*  771 */               this.jj_la1[20] = this.jj_gen;
/*  772 */               jj_consume_token(-1);
/*  773 */               throw new ParseException();
/*      */           } 
/*  775 */           jjtn002 = new AstDiv(17);
/*  776 */           jjtc002 = true;
/*  777 */           this.jjtree.openNodeScope(jjtn002);
/*      */           
/*  779 */           try { Unary();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  795 */             if (jjtc002)
/*  796 */               this.jjtree.closeNodeScope(jjtn002, 2);  } catch (Throwable jjte002) { if (jjtc002) { this.jjtree.clearNodeScope(jjtn002); jjtc002 = false; } else { this.jjtree.popNode(); }  if (jjte002 instanceof RuntimeException) throw (RuntimeException)jjte002;  if (jjte002 instanceof ParseException) throw (ParseException)jjte002;  throw (Error)jjte002; } finally { if (jjtc002) this.jjtree.closeNodeScope(jjtn002, 2);
/*      */              }
/*      */         
/*      */         
/*      */         case 51:
/*      */         case 52:
/*  802 */           switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */             case 51:
/*  804 */               jj_consume_token(51);
/*      */               break;
/*      */             case 52:
/*  807 */               jj_consume_token(52);
/*      */               break;
/*      */             default:
/*  810 */               this.jj_la1[21] = this.jj_gen;
/*  811 */               jj_consume_token(-1);
/*  812 */               throw new ParseException();
/*      */           } 
/*  814 */           jjtn003 = new AstMod(18);
/*  815 */           jjtc003 = true;
/*  816 */           this.jjtree.openNodeScope(jjtn003);
/*      */           
/*  818 */           try { Unary();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  834 */             if (jjtc003)
/*  835 */               this.jjtree.closeNodeScope(jjtn003, 2);  } catch (Throwable jjte003) { if (jjtc003) { this.jjtree.clearNodeScope(jjtn003); jjtc003 = false; } else { this.jjtree.popNode(); }  if (jjte003 instanceof RuntimeException) throw (RuntimeException)jjte003;  if (jjte003 instanceof ParseException) throw (ParseException)jjte003;  throw (Error)jjte003; } finally { if (jjtc003) this.jjtree.closeNodeScope(jjtn003, 2);
/*      */              }
/*      */         
/*      */       } 
/*      */       
/*  840 */       this.jj_la1[22] = this.jj_gen;
/*  841 */       jj_consume_token(-1);
/*  842 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */   public final void Unary() throws ParseException {
/*      */     boolean jjtc003;
/*      */     AstEmpty jjtn003;
/*      */     boolean jjtc002;
/*      */     AstNot jjtn002;
/*      */     boolean jjtc001;
/*      */     AstNegative jjtn001;
/*  852 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 47:
/*  854 */         jj_consume_token(47);
/*  855 */         jjtn001 = new AstNegative(19);
/*  856 */         jjtc001 = true;
/*  857 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/*  859 */           Unary();
/*  860 */         } catch (Throwable jjte001) {
/*  861 */           if (jjtc001) {
/*  862 */             this.jjtree.clearNodeScope(jjtn001);
/*  863 */             jjtc001 = false;
/*      */           } else {
/*  865 */             this.jjtree.popNode();
/*      */           } 
/*  867 */           if (jjte001 instanceof RuntimeException) {
/*  868 */             throw (RuntimeException)jjte001;
/*      */           }
/*  870 */           if (jjte001 instanceof ParseException) {
/*  871 */             throw (ParseException)jjte001;
/*      */           }
/*  873 */           throw (Error)jjte001;
/*      */         } finally {
/*  875 */           if (jjtc001) {
/*  876 */             this.jjtree.closeNodeScope(jjtn001, true);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 37:
/*      */       case 38:
/*  882 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 37:
/*  884 */             jj_consume_token(37);
/*      */             break;
/*      */           case 38:
/*  887 */             jj_consume_token(38);
/*      */             break;
/*      */           default:
/*  890 */             this.jj_la1[23] = this.jj_gen;
/*  891 */             jj_consume_token(-1);
/*  892 */             throw new ParseException();
/*      */         } 
/*  894 */         jjtn002 = new AstNot(20);
/*  895 */         jjtc002 = true;
/*  896 */         this.jjtree.openNodeScope(jjtn002);
/*      */         try {
/*  898 */           Unary();
/*  899 */         } catch (Throwable jjte002) {
/*  900 */           if (jjtc002) {
/*  901 */             this.jjtree.clearNodeScope(jjtn002);
/*  902 */             jjtc002 = false;
/*      */           } else {
/*  904 */             this.jjtree.popNode();
/*      */           } 
/*  906 */           if (jjte002 instanceof RuntimeException) {
/*  907 */             throw (RuntimeException)jjte002;
/*      */           }
/*  909 */           if (jjte002 instanceof ParseException) {
/*  910 */             throw (ParseException)jjte002;
/*      */           }
/*  912 */           throw (Error)jjte002;
/*      */         } finally {
/*  914 */           if (jjtc002) {
/*  915 */             this.jjtree.closeNodeScope(jjtn002, true);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 43:
/*  920 */         jj_consume_token(43);
/*  921 */         jjtn003 = new AstEmpty(21);
/*  922 */         jjtc003 = true;
/*  923 */         this.jjtree.openNodeScope(jjtn003);
/*      */         try {
/*  925 */           Unary();
/*  926 */         } catch (Throwable jjte003) {
/*  927 */           if (jjtc003) {
/*  928 */             this.jjtree.clearNodeScope(jjtn003);
/*  929 */             jjtc003 = false;
/*      */           } else {
/*  931 */             this.jjtree.popNode();
/*      */           } 
/*  933 */           if (jjte003 instanceof RuntimeException) {
/*  934 */             throw (RuntimeException)jjte003;
/*      */           }
/*  936 */           if (jjte003 instanceof ParseException) {
/*  937 */             throw (ParseException)jjte003;
/*      */           }
/*  939 */           throw (Error)jjte003;
/*      */         } finally {
/*  941 */           if (jjtc003) {
/*  942 */             this.jjtree.closeNodeScope(jjtn003, true);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 9:
/*      */       case 10:
/*      */       case 12:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/*      */       case 19:
/*      */       case 53:
/*  954 */         Value();
/*      */         return;
/*      */     } 
/*  957 */     this.jj_la1[24] = this.jj_gen;
/*  958 */     jj_consume_token(-1);
/*  959 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Value() throws ParseException {
/*  968 */     AstValue jjtn001 = new AstValue(22);
/*  969 */     boolean jjtc001 = true;
/*  970 */     this.jjtree.openNodeScope(jjtn001);
/*      */     try {
/*  972 */       ValuePrefix();
/*      */       
/*      */       while (true) {
/*  975 */         switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */           case 18:
/*      */           case 21:
/*      */             break;
/*      */           
/*      */           default:
/*  981 */             this.jj_la1[25] = this.jj_gen;
/*      */             break;
/*      */         } 
/*  984 */         ValueSuffix();
/*      */       } 
/*  986 */     } catch (Throwable jjte001) {
/*  987 */       if (jjtc001) {
/*  988 */         this.jjtree.clearNodeScope(jjtn001);
/*  989 */         jjtc001 = false;
/*      */       } else {
/*  991 */         this.jjtree.popNode();
/*      */       } 
/*  993 */       if (jjte001 instanceof RuntimeException) {
/*  994 */         throw (RuntimeException)jjte001;
/*      */       }
/*  996 */       if (jjte001 instanceof ParseException) {
/*  997 */         throw (ParseException)jjte001;
/*      */       }
/*  999 */       throw (Error)jjte001;
/*      */     } finally {
/* 1001 */       if (jjtc001) {
/* 1002 */         this.jjtree.closeNodeScope(jjtn001, (this.jjtree.nodeArity() > 1));
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void ValuePrefix() throws ParseException {
/* 1012 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 9:
/*      */       case 10:
/*      */       case 12:
/*      */       case 14:
/*      */       case 15:
/*      */       case 16:
/* 1019 */         Literal();
/*      */         return;
/*      */       case 19:
/*      */       case 53:
/* 1023 */         NonLiteral();
/*      */         return;
/*      */     } 
/* 1026 */     this.jj_la1[26] = this.jj_gen;
/* 1027 */     jj_consume_token(-1);
/* 1028 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void ValueSuffix() throws ParseException {
/* 1037 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 18:
/* 1039 */         DotSuffix();
/*      */         return;
/*      */       case 21:
/* 1042 */         BracketSuffix();
/*      */         return;
/*      */     } 
/* 1045 */     this.jj_la1[27] = this.jj_gen;
/* 1046 */     jj_consume_token(-1);
/* 1047 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void DotSuffix() throws ParseException {
/* 1057 */     AstDotSuffix jjtn000 = new AstDotSuffix(23);
/* 1058 */     boolean jjtc000 = true;
/* 1059 */     this.jjtree.openNodeScope(jjtn000); Token t = null;
/*      */     try {
/* 1061 */       jj_consume_token(18);
/* 1062 */       t = jj_consume_token(53);
/* 1063 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 1064 */       jjtc000 = false;
/* 1065 */       jjtn000.setImage(t.image);
/*      */     } finally {
/* 1067 */       if (jjtc000) {
/* 1068 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void BracketSuffix() throws ParseException {
/* 1079 */     AstBracketSuffix jjtn000 = new AstBracketSuffix(24);
/* 1080 */     boolean jjtc000 = true;
/* 1081 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 1083 */       jj_consume_token(21);
/* 1084 */       Expression();
/* 1085 */       jj_consume_token(22);
/* 1086 */     } catch (Throwable jjte000) {
/* 1087 */       if (jjtc000) {
/* 1088 */         this.jjtree.clearNodeScope(jjtn000);
/* 1089 */         jjtc000 = false;
/*      */       } else {
/* 1091 */         this.jjtree.popNode();
/*      */       } 
/* 1093 */       if (jjte000 instanceof RuntimeException) {
/* 1094 */         throw (RuntimeException)jjte000;
/*      */       }
/* 1096 */       if (jjte000 instanceof ParseException) {
/* 1097 */         throw (ParseException)jjte000;
/*      */       }
/* 1099 */       throw (Error)jjte000;
/*      */     } finally {
/* 1101 */       if (jjtc000) {
/* 1102 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void NonLiteral() throws ParseException {
/* 1112 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 19:
/* 1114 */         jj_consume_token(19);
/* 1115 */         Expression();
/* 1116 */         jj_consume_token(20);
/*      */         return;
/*      */     } 
/* 1119 */     this.jj_la1[28] = this.jj_gen;
/* 1120 */     if (jj_2_1(2)) {
/* 1121 */       Function();
/*      */     } else {
/* 1123 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 53:
/* 1125 */           Identifier();
/*      */           return;
/*      */       } 
/* 1128 */       this.jj_la1[29] = this.jj_gen;
/* 1129 */       jj_consume_token(-1);
/* 1130 */       throw new ParseException();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Identifier() throws ParseException {
/* 1142 */     AstIdentifier jjtn000 = new AstIdentifier(25);
/* 1143 */     boolean jjtc000 = true;
/* 1144 */     this.jjtree.openNodeScope(jjtn000); Token t = null;
/*      */     try {
/* 1146 */       t = jj_consume_token(53);
/* 1147 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 1148 */       jjtc000 = false;
/* 1149 */       jjtn000.setImage(t.image);
/*      */     } finally {
/* 1151 */       if (jjtc000) {
/* 1152 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Function() throws ParseException {
/* 1163 */     AstFunction jjtn000 = new AstFunction(26);
/* 1164 */     boolean jjtc000 = true;
/* 1165 */     this.jjtree.openNodeScope(jjtn000); Token t0 = null;
/* 1166 */     Token t1 = null;
/*      */     try {
/* 1168 */       t0 = jj_consume_token(53);
/* 1169 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 54:
/* 1171 */           t1 = jj_consume_token(54);
/*      */           break;
/*      */         default:
/* 1174 */           this.jj_la1[30] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 1177 */       if (t1 != null) {
/* 1178 */         jjtn000.setPrefix(t0.image);
/* 1179 */         jjtn000.setLocalName(t1.image.substring(1));
/*      */       } else {
/* 1181 */         jjtn000.setLocalName(t0.image);
/*      */       } 
/* 1183 */       jj_consume_token(19);
/* 1184 */       switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */         case 9:
/*      */         case 10:
/*      */         case 12:
/*      */         case 14:
/*      */         case 15:
/*      */         case 16:
/*      */         case 19:
/*      */         case 37:
/*      */         case 38:
/*      */         case 43:
/*      */         case 47:
/*      */         case 53:
/* 1197 */           Expression();
/*      */           
/*      */           while (true) {
/* 1200 */             switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */               case 24:
/*      */                 break;
/*      */               
/*      */               default:
/* 1205 */                 this.jj_la1[31] = this.jj_gen;
/*      */                 break;
/*      */             } 
/* 1208 */             jj_consume_token(24);
/* 1209 */             Expression();
/*      */           } 
/*      */           break;
/*      */         default:
/* 1213 */           this.jj_la1[32] = this.jj_gen;
/*      */           break;
/*      */       } 
/* 1216 */       jj_consume_token(20);
/* 1217 */     } catch (Throwable jjte000) {
/* 1218 */       if (jjtc000) {
/* 1219 */         this.jjtree.clearNodeScope(jjtn000);
/* 1220 */         jjtc000 = false;
/*      */       } else {
/* 1222 */         this.jjtree.popNode();
/*      */       } 
/* 1224 */       if (jjte000 instanceof RuntimeException) {
/* 1225 */         throw (RuntimeException)jjte000;
/*      */       }
/* 1227 */       if (jjte000 instanceof ParseException) {
/* 1228 */         throw (ParseException)jjte000;
/*      */       }
/* 1230 */       throw (Error)jjte000;
/*      */     } finally {
/* 1232 */       if (jjtc000) {
/* 1233 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Literal() throws ParseException {
/* 1243 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 14:
/*      */       case 15:
/* 1246 */         Boolean();
/*      */         return;
/*      */       case 10:
/* 1249 */         FloatingPoint();
/*      */         return;
/*      */       case 9:
/* 1252 */         Integer();
/*      */         return;
/*      */       case 12:
/* 1255 */         String();
/*      */         return;
/*      */       case 16:
/* 1258 */         Null();
/*      */         return;
/*      */     } 
/* 1261 */     this.jj_la1[33] = this.jj_gen;
/* 1262 */     jj_consume_token(-1);
/* 1263 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void Boolean() throws ParseException {
/*      */     boolean jjtc002;
/*      */     AstFalse jjtn002;
/*      */     boolean jjtc001;
/*      */     AstTrue jjtn001;
/* 1272 */     switch ((this.jj_ntk == -1) ? jj_ntk() : this.jj_ntk) {
/*      */       case 14:
/* 1274 */         jjtn001 = new AstTrue(27);
/* 1275 */         jjtc001 = true;
/* 1276 */         this.jjtree.openNodeScope(jjtn001);
/*      */         try {
/* 1278 */           jj_consume_token(14);
/*      */         } finally {
/* 1280 */           if (jjtc001) {
/* 1281 */             this.jjtree.closeNodeScope(jjtn001, true);
/*      */           }
/*      */         } 
/*      */         return;
/*      */       case 15:
/* 1286 */         jjtn002 = new AstFalse(28);
/* 1287 */         jjtc002 = true;
/* 1288 */         this.jjtree.openNodeScope(jjtn002);
/*      */         try {
/* 1290 */           jj_consume_token(15);
/*      */         } finally {
/* 1292 */           if (jjtc002) {
/* 1293 */             this.jjtree.closeNodeScope(jjtn002, true);
/*      */           }
/*      */         } 
/*      */         return;
/*      */     } 
/* 1298 */     this.jj_la1[34] = this.jj_gen;
/* 1299 */     jj_consume_token(-1);
/* 1300 */     throw new ParseException();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void FloatingPoint() throws ParseException {
/* 1310 */     AstFloatingPoint jjtn000 = new AstFloatingPoint(29);
/* 1311 */     boolean jjtc000 = true;
/* 1312 */     this.jjtree.openNodeScope(jjtn000); Token t = null;
/*      */     try {
/* 1314 */       t = jj_consume_token(10);
/* 1315 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 1316 */       jjtc000 = false;
/* 1317 */       jjtn000.setImage(t.image);
/*      */     } finally {
/* 1319 */       if (jjtc000) {
/* 1320 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Integer() throws ParseException {
/* 1331 */     AstInteger jjtn000 = new AstInteger(30);
/* 1332 */     boolean jjtc000 = true;
/* 1333 */     this.jjtree.openNodeScope(jjtn000); Token t = null;
/*      */     try {
/* 1335 */       t = jj_consume_token(9);
/* 1336 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 1337 */       jjtc000 = false;
/* 1338 */       jjtn000.setImage(t.image);
/*      */     } finally {
/* 1340 */       if (jjtc000) {
/* 1341 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void String() throws ParseException {
/* 1352 */     AstString jjtn000 = new AstString(31);
/* 1353 */     boolean jjtc000 = true;
/* 1354 */     this.jjtree.openNodeScope(jjtn000); Token t = null;
/*      */     try {
/* 1356 */       t = jj_consume_token(12);
/* 1357 */       this.jjtree.closeNodeScope(jjtn000, true);
/* 1358 */       jjtc000 = false;
/* 1359 */       jjtn000.setImage(t.image);
/*      */     } finally {
/* 1361 */       if (jjtc000) {
/* 1362 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void Null() throws ParseException {
/* 1373 */     AstNull jjtn000 = new AstNull(32);
/* 1374 */     boolean jjtc000 = true;
/* 1375 */     this.jjtree.openNodeScope(jjtn000);
/*      */     try {
/* 1377 */       jj_consume_token(16);
/*      */     } finally {
/* 1379 */       if (jjtc000) {
/* 1380 */         this.jjtree.closeNodeScope(jjtn000, true);
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   private final boolean jj_2_1(int xla) {
/* 1386 */     this.jj_la = xla; this.jj_lastpos = this.jj_scanpos = this.token; 
/* 1387 */     try { return !jj_3_1(); }
/* 1388 */     catch (LookaheadSuccess ls) { return true; }
/* 1389 */     finally { jj_save(0, xla); }
/*      */   
/*      */   }
/*      */   private final boolean jj_3_1() {
/* 1393 */     if (jj_3R_11()) return true; 
/* 1394 */     return false;
/*      */   }
/*      */   
/*      */   private final boolean jj_3R_11() {
/* 1398 */     if (jj_scan_token(53)) return true;
/*      */     
/* 1400 */     Token xsp = this.jj_scanpos;
/* 1401 */     if (jj_scan_token(54)) this.jj_scanpos = xsp; 
/* 1402 */     if (jj_scan_token(19)) return true; 
/* 1403 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static  {
/* 1419 */     jj_la1_0();
/* 1420 */     jj_la1_1();
/*      */   }
/*      */   
/* 1423 */   private static void jj_la1_0() { jj_la1_0 = new int[] { 14, 14, 0, 0, 0, 0, 0, 0, 0, 0, 0, -33554432, 402653184, 100663296, Integer.MIN_VALUE, 1610612736, -33554432, 0, 0, 0, 0, 0, 0, 0, 644608, 2359296, 644608, 2359296, 524288, 0, 0, 16777216, 644608, 120320, 49152 }; }
/*      */ 
/*      */   
/* 1426 */   private static void jj_la1_1() { jj_la1_1 = new int[] { 0, 0, 65536, 1536, 1536, 384, 384, 30, 6, 24, 30, 1, 0, 0, 1, 0, 1, 49152, 49152, 1974272, 393216, 1572864, 1974272, 96, 2132064, 0, 2097152, 0, 0, 2097152, 4194304, 0, 2132064, 0, 0 }; } public ELParser(InputStream stream) { this.jjtree = new JJTELParserState(); this.lookingAhead = false;
/*      */     this.jj_la1 = new int[35];
/* 1428 */     this.jj_2_rtns = new JJCalls[1];
/* 1429 */     this.jj_rescan = false;
/* 1430 */     this.jj_gc = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1518 */     this.jj_ls = new LookaheadSuccess();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1564 */     this.jj_expentries = new Vector();
/*      */     
/* 1566 */     this.jj_kind = -1;
/* 1567 */     this.jj_lasttokens = new int[100]; this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new ELParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; for (int i = 0; i < 35; ) { this.jj_la1[i] = -1; i++; }  for (int i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public void ReInit(InputStream stream) { this.jj_input_stream.ReInit(stream, 1, 1); this.token_source.ReInit(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jjtree.reset(); this.jj_gen = 0; for (int i = 0; i < 35; ) { this.jj_la1[i] = -1; i++; }  for (int i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public ELParser(Reader stream) { this.jjtree = new JJTELParserState(); this.lookingAhead = false; this.jj_la1 = new int[35]; this.jj_2_rtns = new JJCalls[1]; this.jj_rescan = false; this.jj_gc = 0; this.jj_ls = new LookaheadSuccess(); this.jj_expentries = new Vector(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.jj_input_stream = new SimpleCharStream(stream, 1, 1); this.token_source = new ELParserTokenManager(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; for (int i = 0; i < 35; ) { this.jj_la1[i] = -1; i++; }  for (int i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public void ReInit(Reader stream) { this.jj_input_stream.ReInit(stream, 1, 1); this.token_source.ReInit(this.jj_input_stream); this.token = new Token(); this.jj_ntk = -1; this.jjtree.reset(); this.jj_gen = 0; for (int i = 0; i < 35; ) { this.jj_la1[i] = -1; i++; }  for (int i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  } public ELParser(ELParserTokenManager tm) { this.jjtree = new JJTELParserState(); this.lookingAhead = false; this.jj_la1 = new int[35]; this.jj_2_rtns = new JJCalls[1]; this.jj_rescan = false; this.jj_gc = 0; this.jj_ls = new LookaheadSuccess(); this.jj_expentries = new Vector(); this.jj_kind = -1; this.jj_lasttokens = new int[100]; this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; this.jj_gen = 0; for (int i = 0; i < 35; ) { this.jj_la1[i] = -1; i++; }  for (int i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  }
/*      */   public void ReInit(ELParserTokenManager tm) { this.token_source = tm; this.token = new Token(); this.jj_ntk = -1; this.jjtree.reset(); this.jj_gen = 0; for (int i = 0; i < 35; ) { this.jj_la1[i] = -1; i++; }  for (int i = 0; i < this.jj_2_rtns.length; ) { this.jj_2_rtns[i] = new JJCalls(); i++; }  }
/*      */   private final Token jj_consume_token(int kind) throws ParseException { Token oldToken; if ((oldToken = this.token).next != null) { this.token = this.token.next; } else { this.token = this.token.next = this.token_source.getNextToken(); }  this.jj_ntk = -1; if (this.token.kind == kind) { this.jj_gen++; if (++this.jj_gc > 100) { this.jj_gc = 0; for (int i = 0; i < this.jj_2_rtns.length; i++) { JJCalls c = this.jj_2_rtns[i]; while (c != null) { if (c.gen < this.jj_gen)
/*      */               c.first = null;  c = c.next; }  }  }  return this.token; }  this.token = oldToken; this.jj_kind = kind; throw generateParseException(); } private static final class LookaheadSuccess extends Error {
/* 1571 */     private LookaheadSuccess() {} } private void jj_add_error_token(int kind, int pos) { if (pos >= 100)
/* 1572 */       return;  if (pos == this.jj_endpos + 1)
/* 1573 */     { this.jj_lasttokens[this.jj_endpos++] = kind; }
/* 1574 */     else if (this.jj_endpos != 0)
/* 1575 */     { this.jj_expentry = new int[this.jj_endpos];
/* 1576 */       for (int i = 0; i < this.jj_endpos; i++) {
/* 1577 */         this.jj_expentry[i] = this.jj_lasttokens[i];
/*      */       }
/* 1579 */       boolean exists = false;
/* 1580 */       for (Enumeration<int[]> e = this.jj_expentries.elements(); e.hasMoreElements(); ) {
/* 1581 */         int[] oldentry = e.nextElement();
/* 1582 */         if (oldentry.length == this.jj_expentry.length) {
/* 1583 */           exists = true;
/* 1584 */           for (int i = 0; i < this.jj_expentry.length; i++) {
/* 1585 */             if (oldentry[i] != this.jj_expentry[i]) {
/* 1586 */               exists = false;
/*      */               break;
/*      */             } 
/*      */           } 
/* 1590 */           if (exists)
/*      */             break; 
/*      */         } 
/* 1593 */       }  if (!exists) this.jj_expentries.addElement(this.jj_expentry); 
/* 1594 */       if (pos != 0) this.jj_lasttokens[(this.jj_endpos = pos) - 1] = kind;  }  }
/*      */   private final boolean jj_scan_token(int kind) { if (this.jj_scanpos == this.jj_lastpos) { this.jj_la--; if (this.jj_scanpos.next == null) { this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next = this.token_source.getNextToken(); } else { this.jj_lastpos = this.jj_scanpos = this.jj_scanpos.next; }  } else { this.jj_scanpos = this.jj_scanpos.next; }  if (this.jj_rescan) { int i = 0; Token tok = this.token; while (tok != null && tok != this.jj_scanpos) { i++; tok = tok.next; }  if (tok != null) jj_add_error_token(kind, i);  }  if (this.jj_scanpos.kind != kind) return true;  if (this.jj_la == 0 && this.jj_scanpos == this.jj_lastpos) throw this.jj_ls;  return false; }
/*      */   public final Token getNextToken() { if (this.token.next != null) { this.token = this.token.next; } else { this.token = this.token.next = this.token_source.getNextToken(); }  this.jj_ntk = -1; this.jj_gen++; return this.token; }
/*      */   public final Token getToken(int index) { Token t = this.lookingAhead ? this.jj_scanpos : this.token; for (int i = 0; i < index; i++) { if (t.next != null) { t = t.next; } else { t = t.next = this.token_source.getNextToken(); }  }  return t; }
/*      */   private final int jj_ntk() { if ((this.jj_nt = this.token.next) == null)
/* 1599 */       return this.jj_ntk = (this.token.next = this.token_source.getNextToken()).kind;  return this.jj_ntk = this.jj_nt.kind; } public ParseException generateParseException() { this.jj_expentries.removeAllElements();
/* 1600 */     boolean[] la1tokens = new boolean[59];
/* 1601 */     for (int i = 0; i < 59; i++) {
/* 1602 */       la1tokens[i] = false;
/*      */     }
/* 1604 */     if (this.jj_kind >= 0) {
/* 1605 */       la1tokens[this.jj_kind] = true;
/* 1606 */       this.jj_kind = -1;
/*      */     } 
/* 1608 */     for (int i = 0; i < 35; i++) {
/* 1609 */       if (this.jj_la1[i] == this.jj_gen) {
/* 1610 */         for (int j = 0; j < 32; j++) {
/* 1611 */           if ((jj_la1_0[i] & 1 << j) != 0) {
/* 1612 */             la1tokens[j] = true;
/*      */           }
/* 1614 */           if ((jj_la1_1[i] & 1 << j) != 0) {
/* 1615 */             la1tokens[32 + j] = true;
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/* 1620 */     for (int i = 0; i < 59; i++) {
/* 1621 */       if (la1tokens[i]) {
/* 1622 */         this.jj_expentry = new int[1];
/* 1623 */         this.jj_expentry[0] = i;
/* 1624 */         this.jj_expentries.addElement(this.jj_expentry);
/*      */       } 
/*      */     } 
/* 1627 */     this.jj_endpos = 0;
/* 1628 */     jj_rescan_token();
/* 1629 */     jj_add_error_token(0, 0);
/* 1630 */     int[][] exptokseq = new int[this.jj_expentries.size()][];
/* 1631 */     for (int i = 0; i < this.jj_expentries.size(); i++) {
/* 1632 */       exptokseq[i] = this.jj_expentries.elementAt(i);
/*      */     }
/* 1634 */     return new ParseException(this.token, exptokseq, tokenImage); }
/*      */ 
/*      */ 
/*      */   
/*      */   public final void enable_tracing() {}
/*      */ 
/*      */   
/*      */   public final void disable_tracing() {}
/*      */   
/*      */   private final void jj_rescan_token() {
/* 1644 */     this.jj_rescan = true;
/* 1645 */     for (int i = 0; i < 1; i++) {
/* 1646 */       JJCalls p = this.jj_2_rtns[i];
/*      */       do {
/* 1648 */         if (p.gen > this.jj_gen) {
/* 1649 */           this.jj_la = p.arg; this.jj_lastpos = this.jj_scanpos = p.first;
/* 1650 */           switch (i) { case 0:
/* 1651 */               jj_3_1(); break; }
/*      */         
/*      */         } 
/* 1654 */         p = p.next;
/* 1655 */       } while (p != null);
/*      */     } 
/* 1657 */     this.jj_rescan = false;
/*      */   }
/*      */   
/*      */   private final void jj_save(int index, int xla) {
/* 1661 */     JJCalls p = this.jj_2_rtns[index];
/* 1662 */     while (p.gen > this.jj_gen) {
/* 1663 */       if (p.next == null) { p = p.next = new JJCalls(); break; }
/* 1664 */        p = p.next;
/*      */     } 
/* 1666 */     p.gen = this.jj_gen + xla - this.jj_la; p.first = this.token; p.arg = xla;
/*      */   }
/*      */   
/*      */   static final class JJCalls {
/*      */     int gen;
/*      */     Token first;
/*      */     int arg;
/*      */     JJCalls next;
/*      */   } }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/ELParser.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */