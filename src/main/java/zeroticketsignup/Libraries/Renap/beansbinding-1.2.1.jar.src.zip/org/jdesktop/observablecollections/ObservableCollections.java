/*     */ package org.jdesktop.observablecollections;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ObservableCollections
/*     */ {
/*     */   public static <K, V> ObservableMap<K, V> observableMap(Map<K, V> map) {
/*  36 */     if (map == null) {
/*  37 */       throw new IllegalArgumentException("Map must be non-null");
/*     */     }
/*  39 */     return new ObservableMapImpl<K, V>(map);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> ObservableList<E> observableList(List<E> list) {
/*  51 */     if (list == null) {
/*  52 */       throw new IllegalArgumentException("List must be non-null");
/*     */     }
/*  54 */     return new ObservableListImpl<E>(list, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static <E> ObservableListHelper<E> observableListHelper(List<E> list) {
/*  69 */     ObservableListImpl<E> oList = new ObservableListImpl<E>(list, true);
/*  70 */     return new ObservableListHelper<E>(oList);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class ObservableListHelper<E>
/*     */   {
/*     */     private final ObservableCollections.ObservableListImpl<E> list;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     ObservableListHelper(ObservableCollections.ObservableListImpl<E> list) { this.list = list; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     public ObservableList<E> getObservableList() { return this.list; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void fireElementChanged(int index) {
/* 106 */       if (index < 0 || index >= this.list.size()) {
/* 107 */         throw new ArrayIndexOutOfBoundsException("Illegal index");
/*     */       }
/* 109 */       this.list.fireElementChanged(index);
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ObservableMapImpl<K, V>
/*     */     extends AbstractMap<K, V> implements ObservableMap<K, V> {
/*     */     private Map<K, V> map;
/*     */     private List<ObservableMapListener> listeners;
/*     */     private Set<Map.Entry<K, V>> entrySet;
/*     */     
/*     */     ObservableMapImpl(Map<K, V> map) {
/* 120 */       this.map = map;
/* 121 */       this.listeners = new CopyOnWriteArrayList<ObservableMapListener>();
/*     */     }
/*     */ 
/*     */     
/*     */     public void clear() {
/* 126 */       Iterator<K> iterator = keySet().iterator();
/* 127 */       while (iterator.hasNext()) {
/* 128 */         iterator.next();
/* 129 */         iterator.remove();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 134 */     public boolean containsKey(Object key) { return this.map.containsKey(key); }
/*     */ 
/*     */ 
/*     */     
/* 138 */     public boolean containsValue(Object value) { return this.map.containsValue(value); }
/*     */ 
/*     */     
/*     */     public Set<Map.Entry<K, V>> entrySet() {
/* 142 */       Set<Map.Entry<K, V>> es = this.entrySet;
/* 143 */       return (es != null) ? es : (this.entrySet = new EntrySet());
/*     */     }
/*     */ 
/*     */     
/* 147 */     public V get(Object key) { return this.map.get(key); }
/*     */ 
/*     */ 
/*     */     
/* 151 */     public boolean isEmpty() { return this.map.isEmpty(); }
/*     */ 
/*     */     
/*     */     public V put(K key, V value) {
/*     */       V lastValue;
/* 156 */       if (containsKey(key)) {
/* 157 */         lastValue = this.map.put(key, value);
/* 158 */         for (ObservableMapListener listener : this.listeners) {
/* 159 */           listener.mapKeyValueChanged(this, key, lastValue);
/*     */         }
/*     */       } else {
/* 162 */         lastValue = this.map.put(key, value);
/* 163 */         for (ObservableMapListener listener : this.listeners) {
/* 164 */           listener.mapKeyAdded(this, key);
/*     */         }
/*     */       } 
/* 167 */       return lastValue;
/*     */     }
/*     */     
/*     */     public void putAll(Map<? extends K, ? extends V> m) {
/* 171 */       for (K key : m.keySet()) {
/* 172 */         put(key, m.get(key));
/*     */       }
/*     */     }
/*     */     
/*     */     public V remove(Object key) {
/* 177 */       if (containsKey(key)) {
/* 178 */         V value = this.map.remove(key);
/* 179 */         for (ObservableMapListener listener : this.listeners) {
/* 180 */           listener.mapKeyRemoved(this, key, value);
/*     */         }
/* 182 */         return value;
/*     */       } 
/* 184 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 188 */     public int size() { return this.map.size(); }
/*     */ 
/*     */ 
/*     */     
/* 192 */     public void addObservableMapListener(ObservableMapListener listener) { this.listeners.add(listener); }
/*     */ 
/*     */ 
/*     */     
/* 196 */     public void removeObservableMapListener(ObservableMapListener listener) { this.listeners.remove(listener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private class EntryIterator
/*     */       implements Iterator<Map.Entry<K, V>>
/*     */     {
/* 205 */       private Iterator<Map.Entry<K, V>> realIterator = ObservableCollections.ObservableMapImpl.this.map.entrySet().iterator();
/*     */       private Map.Entry<K, V> last;
/*     */       
/* 208 */       public boolean hasNext() { return this.realIterator.hasNext(); }
/*     */ 
/*     */       
/*     */       public Map.Entry<K, V> next() {
/* 212 */         this.last = this.realIterator.next();
/* 213 */         return this.last;
/*     */       }
/*     */       
/*     */       public void remove() {
/* 217 */         if (this.last == null) {
/* 218 */           throw new IllegalStateException();
/*     */         }
/* 220 */         Object toRemove = this.last.getKey();
/* 221 */         this.last = null;
/* 222 */         ObservableCollections.ObservableMapImpl.this.remove(toRemove);
/*     */       }
/*     */     }
/*     */     
/*     */     private class EntrySet extends AbstractSet<Map.Entry<K, V>> {
/*     */       private EntrySet() {}
/*     */       
/* 229 */       public Iterator<Map.Entry<K, V>> iterator() { return new ObservableCollections.ObservableMapImpl.EntryIterator(); }
/*     */ 
/*     */       
/*     */       public boolean contains(Object o) {
/* 233 */         if (!(o instanceof Map.Entry)) {
/* 234 */           return false;
/*     */         }
/* 236 */         Map.Entry<K, V> e = (Map.Entry<K, V>)o;
/* 237 */         return ObservableCollections.ObservableMapImpl.this.containsKey(e.getKey());
/*     */       }
/*     */ 
/*     */       
/*     */       public boolean remove(Object o) {
/* 242 */         if (o instanceof Map.Entry) {
/* 243 */           K key = (K)((Map.Entry)o).getKey();
/* 244 */           if (ObservableCollections.ObservableMapImpl.this.containsKey(key)) {
/* 245 */             remove(key);
/* 246 */             return true;
/*     */           } 
/*     */         } 
/* 249 */         return false;
/*     */       }
/*     */ 
/*     */       
/* 253 */       public int size() { return ObservableCollections.ObservableMapImpl.this.size(); }
/*     */ 
/*     */       
/* 256 */       public void clear() { ObservableCollections.ObservableMapImpl.this.clear(); }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final class ObservableListImpl<E>
/*     */     extends AbstractList<E>
/*     */     implements ObservableList<E>
/*     */   {
/*     */     private final boolean supportsElementPropertyChanged;
/*     */     private List<E> list;
/*     */     private List<ObservableListListener> listeners;
/*     */     
/*     */     ObservableListImpl(List<E> list, boolean supportsElementPropertyChanged) {
/* 269 */       this.list = list;
/* 270 */       this.listeners = new CopyOnWriteArrayList<ObservableListListener>();
/* 271 */       this.supportsElementPropertyChanged = supportsElementPropertyChanged;
/*     */     }
/*     */ 
/*     */     
/* 275 */     public E get(int index) { return this.list.get(index); }
/*     */ 
/*     */ 
/*     */     
/* 279 */     public int size() { return this.list.size(); }
/*     */ 
/*     */     
/*     */     public E set(int index, E element) {
/* 283 */       E oldValue = this.list.set(index, element);
/* 284 */       for (ObservableListListener listener : this.listeners) {
/* 285 */         listener.listElementReplaced(this, index, oldValue);
/*     */       }
/* 287 */       return oldValue;
/*     */     }
/*     */     
/*     */     public void add(int index, E element) {
/* 291 */       this.list.add(index, element);
/* 292 */       this.modCount++;
/* 293 */       for (ObservableListListener listener : this.listeners) {
/* 294 */         listener.listElementsAdded(this, index, 1);
/*     */       }
/*     */     }
/*     */     
/*     */     public E remove(int index) {
/* 299 */       E oldValue = this.list.remove(index);
/* 300 */       this.modCount++;
/* 301 */       for (ObservableListListener listener : this.listeners) {
/* 302 */         listener.listElementsRemoved(this, index, Collections.singletonList(oldValue));
/*     */       }
/*     */       
/* 305 */       return oldValue;
/*     */     }
/*     */ 
/*     */     
/* 309 */     public boolean addAll(Collection<? extends E> c) { return addAll(size(), c); }
/*     */ 
/*     */     
/*     */     public boolean addAll(int index, Collection<? extends E> c) {
/* 313 */       if (this.list.addAll(index, c)) {
/* 314 */         this.modCount++;
/* 315 */         for (ObservableListListener listener : this.listeners) {
/* 316 */           listener.listElementsAdded(this, index, c.size());
/*     */         }
/*     */       } 
/* 319 */       return false;
/*     */     }
/*     */     
/*     */     public void clear() {
/* 323 */       List<E> dup = new ArrayList<E>(this.list);
/* 324 */       this.list.clear();
/* 325 */       this.modCount++;
/* 326 */       if (dup.size() != 0) {
/* 327 */         for (ObservableListListener listener : this.listeners) {
/* 328 */           listener.listElementsRemoved(this, 0, dup);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 334 */     public boolean containsAll(Collection<?> c) { return this.list.containsAll(c); }
/*     */ 
/*     */ 
/*     */     
/* 338 */     public <T> T[] toArray(T[] a) { return this.list.toArray(a); }
/*     */ 
/*     */ 
/*     */     
/* 342 */     public Object[] toArray() { return this.list.toArray(); }
/*     */ 
/*     */     
/*     */     private void fireElementChanged(int index) {
/* 346 */       for (ObservableListListener listener : this.listeners) {
/* 347 */         listener.listElementPropertyChanged(this, index);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 352 */     public void addObservableListListener(ObservableListListener listener) { this.listeners.add(listener); }
/*     */ 
/*     */ 
/*     */     
/* 356 */     public void removeObservableListListener(ObservableListListener listener) { this.listeners.remove(listener); }
/*     */ 
/*     */ 
/*     */     
/* 360 */     public boolean supportsElementPropertyChanged() { return this.supportsElementPropertyChanged; }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/observablecollections/ObservableCollections.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */