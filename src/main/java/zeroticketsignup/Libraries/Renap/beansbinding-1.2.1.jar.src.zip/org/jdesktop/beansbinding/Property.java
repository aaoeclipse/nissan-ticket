package org.jdesktop.beansbinding;

public abstract class Property<S, V> {
  public abstract Class<? extends V> getWriteType(S paramS);
  
  public abstract V getValue(S paramS);
  
  public abstract void setValue(S paramS, V paramV);
  
  public abstract boolean isReadable(S paramS);
  
  public abstract boolean isWriteable(S paramS);
  
  public abstract void addPropertyStateListener(S paramS, PropertyStateListener paramPropertyStateListener);
  
  public abstract void removePropertyStateListener(S paramS, PropertyStateListener paramPropertyStateListener);
  
  public abstract PropertyStateListener[] getPropertyStateListeners(S paramS);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/Property.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */