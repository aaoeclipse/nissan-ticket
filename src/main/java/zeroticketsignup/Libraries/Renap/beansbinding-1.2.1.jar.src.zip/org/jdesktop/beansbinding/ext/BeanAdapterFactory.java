/*     */ package org.jdesktop.beansbinding.ext;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public final class BeanAdapterFactory
/*     */ {
/*  26 */   private static final BeanAdapterFactory INSTANCE = new BeanAdapterFactory();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   public static Object getAdapter(Object source, String property) { return INSTANCE.getAdapter0(source, property); }
/*     */ 
/*     */ 
/*     */   
/*  37 */   public static List<PropertyDescriptor> getAdapterPropertyDescriptors(Class<?> type) { return INSTANCE.getAdapterPropertyDescriptors0(type); }
/*     */ 
/*     */ 
/*     */   
/*  41 */   private final List<BeanAdapterProvider> providers = new ArrayList<BeanAdapterProvider>();
/*  42 */   private final Set<ClassLoader> classLoaders = new HashSet<ClassLoader>();
/*  43 */   private final Set<URL> serviceURLs = new HashSet<URL>();
/*  44 */   private final Map<Object, List<VendedAdapter>> vendedAdapters = new WeakHashMap<Object, List<VendedAdapter>>();
/*     */ 
/*     */   
/*     */   private void loadProvidersIfNecessary() {
/*  48 */     ClassLoader currentLoader = Thread.currentThread().getContextClassLoader();
/*  49 */     if (!this.classLoaders.contains(currentLoader)) {
/*  50 */       this.classLoaders.add(currentLoader);
/*  51 */       loadProviders(currentLoader);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadProviders(ClassLoader classLoader) {
/*  57 */     String serviceName = "META-INF/services/" + BeanAdapterProvider.class.getName();
/*     */     
/*     */     try {
/*  60 */       Enumeration<URL> urls = classLoader.getResources(serviceName);
/*  61 */       while (urls.hasMoreElements()) {
/*  62 */         URL url = urls.nextElement();
/*  63 */         if (!this.serviceURLs.contains(url)) {
/*  64 */           this.serviceURLs.add(url);
/*  65 */           addProviders(url);
/*     */         } 
/*     */       } 
/*  68 */     } catch (IOException ex) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void addProviders(URL url) {
/*  73 */     InputStream inputStream = null;
/*  74 */     BufferedReader reader = null;
/*     */     
/*  76 */     try { inputStream = url.openStream();
/*  77 */       reader = new BufferedReader(new InputStreamReader(inputStream, "utf-8"));
/*     */       String line;
/*  79 */       while ((line = reader.readLine()) != null) {
/*     */         
/*  81 */         try { this.providers.add((BeanAdapterProvider)Class.forName(line).newInstance()); }
/*  82 */         catch (IllegalAccessException ex) {  }
/*  83 */         catch (InstantiationException ex) {  }
/*  84 */         catch (ClassNotFoundException ex) {}
/*     */       }
/*     */        }
/*  87 */     catch (UnsupportedEncodingException ex) {  }
/*  88 */     catch (IOException ex) {}
/*     */     
/*  90 */     if (reader != null) {
/*     */       try {
/*  92 */         reader.close();
/*  93 */       } catch (IOException ex) {}
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public Object getAdapter0(Object source, String property) {
/*  99 */     if (source == null || property == null) {
/* 100 */       throw new IllegalArgumentException();
/*     */     }
/* 102 */     loadProvidersIfNecessary();
/* 103 */     property = property.intern();
/* 104 */     BeanAdapterProvider provider = getProvider(source, property);
/* 105 */     if (provider != null) {
/* 106 */       List<VendedAdapter> adapters = this.vendedAdapters.get(source);
/* 107 */       if (adapters != null) {
/* 108 */         for (int i = adapters.size() - 1; i >= 0; i--) {
/* 109 */           VendedAdapter vendedAdapter = adapters.get(i);
/* 110 */           Object adapter = vendedAdapter.getAdapter();
/* 111 */           if (adapter == null) {
/* 112 */             this.vendedAdapters.remove(Integer.valueOf(i));
/* 113 */           } else if (vendedAdapter.getProvider() == provider && vendedAdapter.getProperty() == property) {
/* 114 */             return adapter;
/*     */           } 
/*     */         } 
/*     */       } else {
/* 118 */         adapters = new ArrayList<VendedAdapter>(1);
/* 119 */         this.vendedAdapters.put(source, adapters);
/*     */       } 
/* 121 */       Object adapter = provider.createAdapter(source, property);
/* 122 */       adapters.add(new VendedAdapter(property, provider, adapter));
/* 123 */       return adapter;
/*     */     } 
/* 125 */     return null;
/*     */   }
/*     */   
/*     */   private BeanAdapterProvider getProvider(Object source, String property) {
/* 129 */     Class<?> type = source.getClass();
/* 130 */     for (BeanAdapterProvider provider : this.providers) {
/* 131 */       if (provider.providesAdapter(type, property)) {
/* 132 */         return provider;
/*     */       }
/*     */     } 
/* 135 */     return null;
/*     */   }
/*     */   
/*     */   private List<FeatureDescriptor> getDescriptors(Class<?> type) {
/* 139 */     BeanInfo info = null;
/*     */     try {
/* 141 */       info = Introspector.getBeanInfo(type);
/* 142 */     } catch (Exception ex) {}
/*     */     
/* 144 */     if (info == null) {
/* 145 */       return Collections.emptyList();
/*     */     }
/* 147 */     ArrayList<FeatureDescriptor> list = new ArrayList<FeatureDescriptor>((info.getPropertyDescriptors()).length);
/*     */     
/* 149 */     for (PropertyDescriptor pd : info.getPropertyDescriptors()) {
/*     */ 
/*     */       
/* 152 */       if (pd.getPropertyType() != null) {
/* 153 */         pd.setValue("type", pd.getPropertyType());
/*     */       }
/* 155 */       pd.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 156 */       list.add(pd);
/*     */     } 
/* 158 */     return list;
/*     */   }
/*     */   
/*     */   private static BeanInfo getBeanInfo(Class<?> type) {
/*     */     try {
/* 163 */       return Introspector.getBeanInfo(type);
/* 164 */     } catch (IntrospectionException ie) {
/* 165 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<PropertyDescriptor> getAdapterPropertyDescriptors0(Class<?> type) {
/* 170 */     if (type == null) {
/* 171 */       throw new IllegalArgumentException("Type must be non-null");
/*     */     }
/*     */     
/* 174 */     loadProvidersIfNecessary();
/*     */     
/* 176 */     ArrayList<PropertyDescriptor> des = new ArrayList<PropertyDescriptor>();
/*     */     
/* 178 */     for (BeanAdapterProvider provider : this.providers) {
/* 179 */       Class<?> pdType = provider.getAdapterClass(type);
/* 180 */       if (pdType != null) {
/* 181 */         BeanInfo info = getBeanInfo(pdType);
/* 182 */         if (info != null) {
/* 183 */           PropertyDescriptor[] pds = info.getPropertyDescriptors();
/* 184 */           if (pds != null) {
/* 185 */             for (PropertyDescriptor pd : pds) {
/* 186 */               if (provider.providesAdapter(type, pd.getName())) {
/* 187 */                 des.add(pd);
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 195 */     return des;
/*     */   }
/*     */   
/*     */   private static final class VendedAdapter {
/*     */     private final BeanAdapterProvider provider;
/*     */     private final String property;
/*     */     private final WeakReference<Object> adapter;
/*     */     
/*     */     public VendedAdapter(String property, BeanAdapterProvider provider, Object adapter) {
/* 204 */       this.property = property;
/* 205 */       this.adapter = new WeakReference(adapter);
/* 206 */       this.provider = provider;
/*     */     }
/*     */ 
/*     */     
/* 210 */     public Object getAdapter() { return this.adapter.get(); }
/*     */ 
/*     */ 
/*     */     
/* 214 */     public String getProperty() { return this.property; }
/*     */ 
/*     */ 
/*     */     
/* 218 */     public BeanAdapterProvider getProvider() { return this.provider; }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/ext/BeanAdapterFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */