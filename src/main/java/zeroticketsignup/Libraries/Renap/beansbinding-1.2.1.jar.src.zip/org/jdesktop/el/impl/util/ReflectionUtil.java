/*     */ package org.jdesktop.el.impl.util;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.MethodNotFoundException;
/*     */ import org.jdesktop.el.PropertyNotFoundException;
/*     */ import org.jdesktop.el.impl.lang.ELSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReflectionUtil
/*     */ {
/*  30 */   protected static final String[] EMPTY_STRING = new String[0];
/*     */   
/*  32 */   protected static final String[] PRIMITIVE_NAMES = new String[] { "boolean", "byte", "char", "double", "float", "int", "long", "short", "void" };
/*     */ 
/*     */   
/*  35 */   protected static final Class[] PRIMITIVES = new Class[] { boolean.class, byte.class, char.class, double.class, float.class, int.class, long.class, short.class, void.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class forName(String name) throws ClassNotFoundException {
/*  47 */     if (null == name || "".equals(name)) {
/*  48 */       return null;
/*     */     }
/*  50 */     Class<?> c = forNamePrimitive(name);
/*  51 */     if (c == null) {
/*  52 */       if (name.endsWith("[]")) {
/*  53 */         String nc = name.substring(0, name.length() - 2);
/*  54 */         c = Class.forName(nc, true, Thread.currentThread().getContextClassLoader());
/*  55 */         c = Array.newInstance(c, 0).getClass();
/*     */       } else {
/*  57 */         c = Class.forName(name, true, Thread.currentThread().getContextClassLoader());
/*     */       } 
/*     */     }
/*  60 */     return c;
/*     */   }
/*     */   
/*     */   protected static Class forNamePrimitive(String name) {
/*  64 */     if (name.length() <= 8) {
/*  65 */       int p = Arrays.binarySearch((Object[])PRIMITIVE_NAMES, name);
/*  66 */       if (p >= 0) {
/*  67 */         return PRIMITIVES[p];
/*     */       }
/*     */     } 
/*  70 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Class[] toTypeArray(String[] s) throws ClassNotFoundException {
/*  80 */     if (s == null)
/*  81 */       return null; 
/*  82 */     Class[] c = new Class[s.length];
/*  83 */     for (int i = 0; i < s.length; i++) {
/*  84 */       c[i] = forName(s[i]);
/*     */     }
/*  86 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] toTypeNameArray(Class[] c) {
/*  95 */     if (c == null)
/*  96 */       return null; 
/*  97 */     String[] s = new String[c.length];
/*  98 */     for (int i = 0; i < c.length; i++) {
/*  99 */       s[i] = c[i].getName();
/*     */     }
/* 101 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Method getMethod(Object base, Object property, Class[] paramTypes) throws MethodNotFoundException {
/* 114 */     if (base == null || property == null) {
/* 115 */       throw new MethodNotFoundException(MessageFactory.get("error.method.notfound", base, property, paramString(paramTypes)));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 120 */     String methodName = property.toString();
/*     */     
/* 122 */     Method method = getMethod(base.getClass(), methodName, paramTypes);
/* 123 */     if (method == null) {
/* 124 */       throw new MethodNotFoundException(MessageFactory.get("error.method.notfound", base, property, paramString(paramTypes)));
/*     */     }
/*     */ 
/*     */     
/* 128 */     return method;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getMethod(Class cl, String methodName, Class[] paramTypes) {
/* 142 */     Method m = null;
/*     */     try {
/* 144 */       m = cl.getMethod(methodName, paramTypes);
/* 145 */     } catch (NoSuchMethodException ex) {
/* 146 */       return null;
/*     */     } 
/*     */     
/* 149 */     Class<?> dclass = m.getDeclaringClass();
/* 150 */     if (Modifier.isPublic(dclass.getModifiers())) {
/* 151 */       return m;
/*     */     }
/*     */     
/* 154 */     for (Class<?> c : dclass.getInterfaces()) {
/* 155 */       m = getMethod(c, methodName, paramTypes);
/* 156 */       if (m != null) {
/* 157 */         return m;
/*     */       }
/*     */     } 
/* 160 */     Class<?> c = dclass.getSuperclass();
/* 161 */     if (c != null) {
/* 162 */       m = getMethod(c, methodName, paramTypes);
/* 163 */       if (m != null) {
/* 164 */         return m;
/*     */       }
/*     */     } 
/* 167 */     return null;
/*     */   }
/*     */   
/*     */   protected static final String paramString(Class[] types) {
/* 171 */     if (types != null) {
/* 172 */       StringBuffer sb = new StringBuffer();
/* 173 */       for (int i = 0; i < types.length; i++) {
/* 174 */         sb.append(types[i].getName()).append(", ");
/*     */       }
/* 176 */       if (sb.length() > 2) {
/* 177 */         sb.setLength(sb.length() - 2);
/*     */       }
/* 179 */       return sb.toString();
/*     */     } 
/* 181 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyDescriptor getPropertyDescriptor(Object base, Object property) throws ELException, PropertyNotFoundException {
/* 193 */     String name = ELSupport.coerceToString(property);
/* 194 */     PropertyDescriptor p = null;
/*     */     try {
/* 196 */       PropertyDescriptor[] desc = Introspector.getBeanInfo(base.getClass()).getPropertyDescriptors();
/*     */       
/* 198 */       for (int i = 0; i < desc.length; i++) {
/* 199 */         if (desc[i].getName().equals(name)) {
/* 200 */           return desc[i];
/*     */         }
/*     */       } 
/* 203 */     } catch (IntrospectionException ie) {
/* 204 */       throw new ELException(ie);
/*     */     } 
/* 206 */     throw new PropertyNotFoundException(MessageFactory.get("error.property.notfound", base, name));
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/util/ReflectionUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */