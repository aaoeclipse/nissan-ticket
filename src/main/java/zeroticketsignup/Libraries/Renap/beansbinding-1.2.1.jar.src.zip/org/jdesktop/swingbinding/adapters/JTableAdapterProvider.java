/*     */ package org.jdesktop.swingbinding.adapters;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.table.TableModel;
/*     */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*     */ import org.jdesktop.swingbinding.impl.ListBindingManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JTableAdapterProvider
/*     */   implements BeanAdapterProvider
/*     */ {
/*     */   private static final String SELECTED_ELEMENT_P = "selectedElement";
/*     */   private static final String SELECTED_ELEMENTS_P = "selectedElements";
/*     */   private static final String SELECTED_ELEMENT_IA_P = "selectedElement_IGNORE_ADJUSTING";
/*     */   private static final String SELECTED_ELEMENTS_IA_P = "selectedElements_IGNORE_ADJUSTING";
/*  29 */   private static boolean IS_JAVA_15 = System.getProperty("java.version").startsWith("1.5");
/*     */   
/*     */   public final class Adapter
/*     */     extends BeanAdapterBase {
/*     */     private JTable table;
/*     */     private Handler handler;
/*     */     private Object cachedElementOrElements;
/*     */     
/*     */     private Adapter(JTable table, String property) {
/*  38 */       super(property);
/*  39 */       this.table = table;
/*     */     }
/*     */ 
/*     */     
/*  43 */     private boolean isPlural() { return (this.property == "selectedElements" || this.property == "selectedElements_IGNORE_ADJUSTING"); }
/*     */ 
/*     */ 
/*     */     
/*  47 */     public Object getSelectedElement() { return JTableAdapterProvider.getSelectedElement(this.table); }
/*     */ 
/*     */ 
/*     */     
/*  51 */     public Object getSelectedElement_IGNORE_ADJUSTING() { return getSelectedElement(); }
/*     */ 
/*     */ 
/*     */     
/*  55 */     public List<Object> getSelectedElements() { return JTableAdapterProvider.getSelectedElements(this.table); }
/*     */ 
/*     */ 
/*     */     
/*  59 */     public List<Object> getSelectedElements_IGNORE_ADJUSTING() { return getSelectedElements(); }
/*     */ 
/*     */     
/*     */     protected void listeningStarted() {
/*  63 */       this.handler = new Handler();
/*  64 */       this.cachedElementOrElements = isPlural() ? getSelectedElements() : JTableAdapterProvider.getSelectedElement(this.table);
/*     */       
/*  66 */       this.table.addPropertyChangeListener("selectionModel", this.handler);
/*  67 */       this.table.getSelectionModel().addListSelectionListener(this.handler);
/*     */     }
/*     */     
/*     */     protected void listeningStopped() {
/*  71 */       this.table.getSelectionModel().removeListSelectionListener(this.handler);
/*  72 */       this.table.removePropertyChangeListener("selectionModel", this.handler);
/*  73 */       this.cachedElementOrElements = null;
/*  74 */       this.handler = null;
/*     */     }
/*     */     
/*     */     private class Handler implements ListSelectionListener, PropertyChangeListener {
/*     */       private void tableSelectionChanged() {
/*  79 */         Object oldElementOrElements = JTableAdapterProvider.Adapter.this.cachedElementOrElements;
/*  80 */         JTableAdapterProvider.Adapter.this.cachedElementOrElements = JTableAdapterProvider.Adapter.this.getSelectedElements();
/*  81 */         JTableAdapterProvider.Adapter.this.firePropertyChange(oldElementOrElements, JTableAdapterProvider.Adapter.this.cachedElementOrElements);
/*     */       }
/*     */       private Handler() {}
/*     */       public void valueChanged(ListSelectionEvent e) {
/*  85 */         if ((JTableAdapterProvider.Adapter.this.property == "selectedElement_IGNORE_ADJUSTING" || JTableAdapterProvider.Adapter.this.property == "selectedElements_IGNORE_ADJUSTING") && e.getValueIsAdjusting()) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  91 */         tableSelectionChanged();
/*     */       }
/*     */       
/*     */       public void propertyChange(PropertyChangeEvent pce) {
/*  95 */         ((ListSelectionModel)pce.getOldValue()).removeListSelectionListener(JTableAdapterProvider.Adapter.this.handler);
/*  96 */         ((ListSelectionModel)pce.getNewValue()).addListSelectionListener(JTableAdapterProvider.Adapter.this.handler);
/*  97 */         tableSelectionChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static int viewToModel(JTable table, int index) {
/* 104 */     if (!IS_JAVA_15) {
/*     */       try {
/* 106 */         Method m = table.getClass().getMethod("convertRowIndexToModel", new Class[] { int.class });
/* 107 */         index = ((Integer)m.invoke(table, new Object[] { Integer.valueOf(index) })).intValue();
/* 108 */       } catch (NoSuchMethodException nsme) {
/* 109 */         throw new AssertionError(nsme);
/* 110 */       } catch (IllegalAccessException iae) {
/* 111 */         throw new AssertionError(iae);
/* 112 */       } catch (InvocationTargetException ite) {
/* 113 */         Throwable cause = ite.getCause();
/* 114 */         if (cause instanceof Error) {
/* 115 */           throw (Error)cause;
/*     */         }
/* 117 */         throw new RuntimeException(cause);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 122 */     return index;
/*     */   }
/*     */ 
/*     */   
/*     */   private static int modelToView(JTable table, int index) {
/* 127 */     if (!IS_JAVA_15) {
/*     */       try {
/* 129 */         Method m = table.getClass().getMethod("convertRowIndexToView", new Class[] { int.class });
/* 130 */         index = ((Integer)m.invoke(table, new Object[] { Integer.valueOf(index) })).intValue();
/* 131 */       } catch (NoSuchMethodException nsme) {
/* 132 */         throw new AssertionError(nsme);
/* 133 */       } catch (IllegalAccessException iae) {
/* 134 */         throw new AssertionError(iae);
/* 135 */       } catch (InvocationTargetException ite) {
/* 136 */         Throwable cause = ite.getCause();
/* 137 */         if (cause instanceof Error) {
/* 138 */           throw (Error)cause;
/*     */         }
/* 140 */         throw new RuntimeException(cause);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 145 */     return index;
/*     */   }
/*     */   
/*     */   private static List<Object> getSelectedElements(JTable table) {
/* 149 */     assert table != null;
/*     */     
/* 151 */     ListSelectionModel selectionModel = table.getSelectionModel();
/* 152 */     int min = selectionModel.getMinSelectionIndex();
/* 153 */     int max = selectionModel.getMaxSelectionIndex();
/*     */ 
/*     */ 
/*     */     
/* 157 */     if (min < 0 || max < 0) {
/* 158 */       return new ArrayList(0);
/*     */     }
/*     */     
/* 161 */     ArrayList<Object> elements = new ArrayList(max - min + 1);
/*     */     
/* 163 */     for (int i = min; i <= max; i++) {
/* 164 */       if (selectionModel.isSelectedIndex(i)) {
/* 165 */         elements.add(getElement(table, i));
/*     */       }
/*     */     } 
/*     */     
/* 169 */     return elements;
/*     */   }
/*     */   
/*     */   private static Object getSelectedElement(JTable table) {
/* 173 */     assert table != null;
/*     */ 
/*     */     
/* 176 */     int index = table.getSelectionModel().getLeadSelectionIndex();
/* 177 */     index = table.getSelectionModel().isSelectedIndex(index) ? index : table.getSelectionModel().getMinSelectionIndex();
/*     */ 
/*     */     
/* 180 */     if (index == -1) {
/* 181 */       return null;
/*     */     }
/*     */     
/* 184 */     return getElement(table, index);
/*     */   }
/*     */   
/*     */   private static Object getElement(JTable table, int index) {
/* 188 */     index = viewToModel(table, index);
/*     */     
/* 190 */     TableModel model = table.getModel();
/* 191 */     if (model instanceof ListBindingManager) {
/* 192 */       return ((ListBindingManager)model).getElement(index);
/*     */     }
/* 194 */     int columnCount = model.getColumnCount();
/*     */     
/* 196 */     HashMap<Object, Object> map = new HashMap<Object, Object>(columnCount);
/* 197 */     for (int i = 0; i < columnCount; i++) {
/* 198 */       map.put("column" + i, model.getValueAt(index, i));
/*     */     }
/* 200 */     return map;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean providesAdapter(Class<?> type, String property) {
/* 205 */     if (!JTable.class.isAssignableFrom(type)) {
/* 206 */       return false;
/*     */     }
/*     */     
/* 209 */     property = property.intern();
/*     */     
/* 211 */     return (property == "selectedElement" || property == "selectedElement_IGNORE_ADJUSTING" || property == "selectedElements" || property == "selectedElements_IGNORE_ADJUSTING");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createAdapter(Object source, String property) {
/* 219 */     if (!providesAdapter(source.getClass(), property)) {
/* 220 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 223 */     return new Adapter((JTable)source, property);
/*     */   }
/*     */ 
/*     */   
/* 227 */   public Class<?> getAdapterClass(Class<?> type) { return JTable.class.isAssignableFrom(type) ? Adapter.class : null; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/JTableAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */