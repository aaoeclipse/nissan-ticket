/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PropertyHelper<S, V>
/*     */   extends Property<S, V>
/*     */ {
/*     */   private final boolean ignoresSource;
/*     */   private Object listeners;
/*     */   
/*  39 */   public PropertyHelper() { this(false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  51 */   public PropertyHelper(boolean ignoresSource) { this.ignoresSource = ignoresSource; }
/*     */ 
/*     */   
/*     */   private List<PropertyStateListener> getListeners(S source, boolean create) {
/*  55 */     if (this.ignoresSource) {
/*  56 */       List<PropertyStateListener> list = (List<PropertyStateListener>)this.listeners;
/*     */       
/*  58 */       if (list == null && create) {
/*  59 */         list = new ArrayList<PropertyStateListener>();
/*  60 */         this.listeners = list;
/*     */       } 
/*     */       
/*  63 */       return list;
/*     */     } 
/*     */     
/*  66 */     IdentityHashMap<S, List<PropertyStateListener>> map = (IdentityHashMap<S, List<PropertyStateListener>>)this.listeners;
/*     */     
/*  68 */     if (map == null) {
/*  69 */       if (create) {
/*  70 */         map = new IdentityHashMap<S, List<PropertyStateListener>>();
/*  71 */         this.listeners = map;
/*     */       } else {
/*  73 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*  77 */     List<PropertyStateListener> list = map.get(source);
/*  78 */     if (list == null && create) {
/*  79 */       list = new ArrayList<PropertyStateListener>();
/*  80 */       map.put(source, list);
/*     */     } 
/*     */     
/*  83 */     return list;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Class<? extends V> getWriteType(S paramS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract V getValue(S paramS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void setValue(S paramS, V paramV);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isReadable(S paramS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean isWriteable(S paramS);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void listeningStarted(S source) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void listeningStopped(S source) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addPropertyStateListener(S source, PropertyStateListener listener) {
/* 144 */     if (listener == null) {
/*     */       return;
/*     */     }
/*     */     
/* 148 */     List<PropertyStateListener> listeners = getListeners(source, true);
/* 149 */     boolean wasListening = (listeners.size() != 0);
/* 150 */     listeners.add(listener);
/*     */     
/* 152 */     if (!wasListening) {
/* 153 */       listeningStarted(this.ignoresSource ? null : source);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removePropertyStateListener(S source, PropertyStateListener listener) {
/* 161 */     if (listener == null) {
/*     */       return;
/*     */     }
/*     */     
/* 165 */     List<PropertyStateListener> listeners = getListeners(source, false);
/*     */     
/* 167 */     if (listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 171 */     boolean wasListening = (listeners.size() != 0);
/*     */     
/* 173 */     listeners.remove(listener);
/*     */     
/* 175 */     if (wasListening && listeners.size() == 0) {
/* 176 */       listeningStopped(this.ignoresSource ? null : source);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final PropertyStateListener[] getPropertyStateListeners(S source) {
/* 184 */     List<PropertyStateListener> listeners = getListeners(source, false);
/*     */     
/* 186 */     if (listeners == null) {
/* 187 */       return new PropertyStateListener[0];
/*     */     }
/*     */     
/* 190 */     PropertyStateListener[] ret = new PropertyStateListener[listeners.size()];
/* 191 */     ret = listeners.toArray(ret);
/* 192 */     return ret;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected final void firePropertyStateChange(PropertyStateEvent pse) {
/* 205 */     List<PropertyStateListener> listeners = getListeners((S)pse.getSourceObject(), false);
/*     */     
/* 207 */     if (listeners == null) {
/*     */       return;
/*     */     }
/*     */     
/* 211 */     for (PropertyStateListener listener : listeners) {
/* 212 */       listener.propertyStateChanged(pse);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isListening(S source) {
/* 225 */     List<PropertyStateListener> listeners = getListeners(source, false);
/* 226 */     return (listeners != null && listeners.size() != 0);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/PropertyHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */