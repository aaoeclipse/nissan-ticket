/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDotSuffix
/*    */   extends SimpleNode
/*    */ {
/* 19 */   public AstDotSuffix(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   public Object getValue(EvaluationContext ctx) throws ELException { return this.image; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstDotSuffix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */