/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BindingGroup
/*     */ {
/*  18 */   private final List<Binding> unbound = new ArrayList<Binding>();
/*  19 */   private final List<Binding> bound = new ArrayList<Binding>();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List<BindingListener> listeners;
/*     */ 
/*     */ 
/*     */   
/*     */   private Handler handler;
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, Binding> namedBindings;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addBinding(Binding binding) {
/*  38 */     if (binding == null) {
/*  39 */       throw new IllegalArgumentException("Binding must be non-null");
/*     */     }
/*     */     
/*  42 */     if (binding.isManaged()) {
/*  43 */       throw new IllegalArgumentException("Managed bindings can't be in a group");
/*     */     }
/*     */     
/*  46 */     if (this.bound.contains(binding) || this.unbound.contains(binding)) {
/*  47 */       throw new IllegalArgumentException("Group already contains this binding");
/*     */     }
/*     */     
/*  50 */     String name = binding.getName();
/*  51 */     if (name != null) {
/*  52 */       if (getBinding(name) != null) {
/*  53 */         throw new IllegalArgumentException("Context already contains a binding with name \"" + name + "\"");
/*     */       }
/*  55 */       putNamed(name, binding);
/*     */     } 
/*     */ 
/*     */     
/*  59 */     binding.addBindingListener(getHandler());
/*     */     
/*  61 */     if (binding.isBound()) {
/*  62 */       this.bound.add(binding);
/*     */     } else {
/*  64 */       this.unbound.add(binding);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeBinding(Binding binding) {
/*  76 */     if (binding == null) {
/*  77 */       throw new IllegalArgumentException("Binding must be non-null");
/*     */     }
/*     */     
/*  80 */     if (binding.isBound()) {
/*  81 */       if (!this.bound.remove(binding)) {
/*  82 */         throw new IllegalArgumentException("Unknown Binding");
/*     */       }
/*     */     }
/*  85 */     else if (!this.unbound.remove(binding)) {
/*  86 */       throw new IllegalArgumentException("Unknown Binding");
/*     */     } 
/*     */ 
/*     */     
/*  90 */     String name = binding.getName();
/*  91 */     if (name != null) {
/*  92 */       assert this.namedBindings != null;
/*  93 */       this.namedBindings.remove(name);
/*     */     } 
/*     */     
/*  96 */     binding.removeBindingListener(getHandler());
/*     */   }
/*     */   
/*     */   private void putNamed(String name, Binding binding) {
/* 100 */     if (this.namedBindings == null) {
/* 101 */       this.namedBindings = new HashMap<String, Binding>();
/*     */     }
/*     */     
/* 104 */     this.namedBindings.put(name, binding);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Binding getBinding(String name) {
/* 118 */     if (name == null) {
/* 119 */       throw new IllegalArgumentException("cannot fetch unnamed bindings");
/*     */     }
/*     */     
/* 122 */     return (this.namedBindings == null) ? null : this.namedBindings.get(name);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List<Binding> getBindings() {
/* 132 */     ArrayList<Binding> list = new ArrayList<Binding>(this.bound);
/* 133 */     list.addAll(this.unbound);
/* 134 */     return Collections.unmodifiableList(list);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void bind() {
/* 141 */     List<Binding> toBind = new ArrayList<Binding>(this.unbound);
/* 142 */     for (Binding binding : toBind) {
/* 143 */       binding.bind();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void unbind() {
/* 151 */     List<Binding> toUnbind = new ArrayList<Binding>(this.bound);
/* 152 */     for (Binding binding : toUnbind) {
/* 153 */       binding.unbind();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void addBindingListener(BindingListener listener) {
/* 167 */     if (listener == null) {
/*     */       return;
/*     */     }
/*     */     
/* 171 */     if (this.listeners == null) {
/* 172 */       this.listeners = new ArrayList<BindingListener>();
/*     */     }
/*     */     
/* 175 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void removeBindingListener(BindingListener listener) {
/* 189 */     if (listener == null) {
/*     */       return;
/*     */     }
/*     */     
/* 193 */     if (this.listeners != null) {
/* 194 */       this.listeners.remove(listener);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final BindingListener[] getBindingListeners() {
/* 207 */     if (this.listeners == null) {
/* 208 */       return new BindingListener[0];
/*     */     }
/*     */     
/* 211 */     BindingListener[] ret = new BindingListener[this.listeners.size()];
/* 212 */     ret = this.listeners.toArray(ret);
/* 213 */     return ret;
/*     */   }
/*     */   
/*     */   private final Handler getHandler() {
/* 217 */     if (this.handler == null) {
/* 218 */       this.handler = new Handler();
/*     */     }
/*     */     
/* 221 */     return this.handler;
/*     */   }
/*     */   
/*     */   private class Handler implements BindingListener {
/*     */     public void syncFailed(Binding binding, Binding.SyncFailure failure) {
/* 226 */       if (BindingGroup.this.listeners == null) {
/*     */         return;
/*     */       }
/*     */       
/* 230 */       for (BindingListener listener : BindingGroup.this.listeners) {
/* 231 */         listener.syncFailed(binding, failure);
/*     */       }
/*     */     }
/*     */     
/*     */     public void synced(Binding binding) {
/* 236 */       if (BindingGroup.this.listeners == null) {
/*     */         return;
/*     */       }
/*     */       
/* 240 */       for (BindingListener listener : BindingGroup.this.listeners)
/* 241 */         listener.synced(binding); 
/*     */     }
/*     */     private Handler() {}
/*     */     
/*     */     public void sourceChanged(Binding binding, PropertyStateEvent event) {
/* 246 */       if (BindingGroup.this.listeners == null) {
/*     */         return;
/*     */       }
/*     */       
/* 250 */       for (BindingListener listener : BindingGroup.this.listeners) {
/* 251 */         listener.sourceChanged(binding, event);
/*     */       }
/*     */     }
/*     */     
/*     */     public void targetChanged(Binding binding, PropertyStateEvent event) {
/* 256 */       if (BindingGroup.this.listeners == null) {
/*     */         return;
/*     */       }
/*     */       
/* 260 */       for (BindingListener listener : BindingGroup.this.listeners) {
/* 261 */         listener.targetChanged(binding, event);
/*     */       }
/*     */     }
/*     */     
/*     */     public void bindingBecameBound(Binding binding) {
/* 266 */       BindingGroup.this.unbound.remove(binding);
/* 267 */       BindingGroup.this.bound.add(binding);
/*     */       
/* 269 */       if (BindingGroup.this.listeners == null) {
/*     */         return;
/*     */       }
/*     */       
/* 273 */       for (BindingListener listener : BindingGroup.this.listeners) {
/* 274 */         listener.bindingBecameBound(binding);
/*     */       }
/*     */     }
/*     */     
/*     */     public void bindingBecameUnbound(Binding binding) {
/* 279 */       BindingGroup.this.bound.remove(binding);
/* 280 */       BindingGroup.this.unbound.add(binding);
/*     */       
/* 282 */       if (BindingGroup.this.listeners == null) {
/*     */         return;
/*     */       }
/*     */       
/* 286 */       for (BindingListener listener : BindingGroup.this.listeners)
/* 287 */         listener.bindingBecameUnbound(binding); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/BindingGroup.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */