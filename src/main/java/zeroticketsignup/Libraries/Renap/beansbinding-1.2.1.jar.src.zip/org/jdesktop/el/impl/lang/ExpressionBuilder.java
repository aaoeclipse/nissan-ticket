/*     */ package org.jdesktop.el.impl.lang;
/*     */ 
/*     */ import java.io.StringReader;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.MethodExpression;
/*     */ import org.jdesktop.el.ValueExpression;
/*     */ import org.jdesktop.el.VariableMapper;
/*     */ import org.jdesktop.el.impl.MethodExpressionImpl;
/*     */ import org.jdesktop.el.impl.MethodExpressionLiteral;
/*     */ import org.jdesktop.el.impl.ValueExpressionImpl;
/*     */ import org.jdesktop.el.impl.parser.AstFunction;
/*     */ import org.jdesktop.el.impl.parser.AstIdentifier;
/*     */ import org.jdesktop.el.impl.parser.ELParser;
/*     */ import org.jdesktop.el.impl.parser.Node;
/*     */ import org.jdesktop.el.impl.parser.NodeVisitor;
/*     */ import org.jdesktop.el.impl.parser.ParseException;
/*     */ import org.jdesktop.el.impl.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ExpressionBuilder
/*     */   implements NodeVisitor
/*     */ {
/*     */   private static final int SIZE = 5000;
/*  43 */   private static final Map cache = new ConcurrentHashMap<Object, Object>(5000);
/*  44 */   private static final Map cache2 = new ConcurrentHashMap<Object, Object>(5000);
/*     */ 
/*     */   
/*     */   private FunctionMapper fnMapper;
/*     */ 
/*     */   
/*     */   private VariableMapper varMapper;
/*     */ 
/*     */   
/*     */   private String expression;
/*     */ 
/*     */   
/*     */   public ExpressionBuilder(String expression, ELContext ctx) throws ELException {
/*  57 */     this.expression = expression;
/*     */     
/*  59 */     FunctionMapper ctxFn = ctx.getFunctionMapper();
/*  60 */     VariableMapper ctxVar = ctx.getVariableMapper();
/*     */     
/*  62 */     if (ctxFn != null) {
/*  63 */       this.fnMapper = new FunctionMapperFactory(ctxFn);
/*     */     }
/*  65 */     if (ctxVar != null) {
/*  66 */       this.varMapper = new VariableMapperFactory(ctxVar);
/*     */     }
/*     */   }
/*     */   
/*     */   public static final Node createNode(String expr) throws ELException {
/*  71 */     Node n = createNodeInternal(expr);
/*  72 */     return n;
/*     */   }
/*     */ 
/*     */   
/*     */   private static final Node createNodeInternal(String expr) throws ELException {
/*  77 */     if (expr == null) {
/*  78 */       throw new ELException(MessageFactory.get("error.null"));
/*     */     }
/*     */     
/*  81 */     Object object = cache.get(expr);
/*  82 */     if (object == null && (object = cache2.get(expr)) == null) {
/*     */       try {
/*  84 */         object = (new ELParser(new StringReader(expr))).CompositeExpression();
/*     */ 
/*     */ 
/*     */         
/*  88 */         if (object instanceof org.jdesktop.el.impl.parser.AstCompositeExpression) {
/*  89 */           int numChildren = object.jjtGetNumChildren();
/*  90 */           if (numChildren == 1) {
/*  91 */             object = object.jjtGetChild(0);
/*     */           } else {
/*  93 */             Class<?> type = null;
/*  94 */             Node child = null;
/*  95 */             for (int i = 0; i < numChildren; i++) {
/*  96 */               child = object.jjtGetChild(i);
/*  97 */               if (!(child instanceof org.jdesktop.el.impl.parser.AstLiteralExpression))
/*     */               {
/*  99 */                 if (type == null) {
/* 100 */                   type = child.getClass();
/*     */                 }
/* 102 */                 else if (!type.equals(child.getClass())) {
/* 103 */                   throw new ELException(MessageFactory.get("error.mixed", expr));
/*     */                 } 
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 110 */         if (object instanceof org.jdesktop.el.impl.parser.AstDeferredExpression || object instanceof org.jdesktop.el.impl.parser.AstDynamicExpression)
/*     */         {
/* 112 */           object = object.jjtGetChild(0);
/*     */         }
/* 114 */         if (cache.size() > 5000) {
/* 115 */           cache2.clear();
/* 116 */           cache2.putAll(cache);
/* 117 */           cache.clear();
/*     */         } 
/* 119 */         cache.put(expr, object);
/* 120 */       } catch (ParseException pe) {
/* 121 */         throw new ELException("Error Parsing: " + expr, (Throwable)pe);
/*     */       } 
/*     */     }
/* 124 */     return (Node)object;
/*     */   }
/*     */   
/*     */   private void prepare(Node node) throws ELException {
/* 128 */     node.accept(this);
/* 129 */     if (this.fnMapper instanceof FunctionMapperFactory) {
/* 130 */       this.fnMapper = ((FunctionMapperFactory)this.fnMapper).create();
/*     */     }
/* 132 */     if (this.varMapper instanceof VariableMapperFactory) {
/* 133 */       this.varMapper = ((VariableMapperFactory)this.varMapper).create();
/*     */     }
/*     */   }
/*     */   
/*     */   private Node build() throws ELException {
/* 138 */     Node n = createNodeInternal(this.expression);
/* 139 */     prepare(n);
/* 140 */     if (n instanceof org.jdesktop.el.impl.parser.AstDeferredExpression || n instanceof org.jdesktop.el.impl.parser.AstDynamicExpression)
/*     */     {
/* 142 */       n = n.jjtGetChild(0);
/*     */     }
/* 144 */     return n;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void visit(Node node) throws ELException {
/* 153 */     if (node instanceof AstFunction) {
/*     */       
/* 155 */       AstFunction funcNode = (AstFunction)node;
/*     */       
/* 157 */       if (this.fnMapper == null) {
/* 158 */         throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */       }
/* 160 */       Method m = this.fnMapper.resolveFunction(funcNode.getPrefix(), funcNode.getLocalName());
/*     */       
/* 162 */       if (m == null) {
/* 163 */         throw new ELException(MessageFactory.get("error.fnMapper.method", funcNode.getOutputName()));
/*     */       }
/*     */       
/* 166 */       int pcnt = (m.getParameterTypes()).length;
/* 167 */       if (node.jjtGetNumChildren() != pcnt) {
/* 168 */         throw new ELException(MessageFactory.get("error.fnMapper.paramcount", funcNode.getOutputName(), "" + pcnt, "" + node.jjtGetNumChildren()));
/*     */       
/*     */       }
/*     */     }
/* 172 */     else if (node instanceof AstIdentifier && this.varMapper != null) {
/* 173 */       String variable = ((AstIdentifier)node).getImage();
/*     */ 
/*     */       
/* 176 */       this.varMapper.resolveVariable(variable);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public ValueExpression createValueExpression(Class expectedType) throws ELException {
/* 182 */     Node n = build();
/* 183 */     return (ValueExpression)new ValueExpressionImpl(this.expression, n, this.fnMapper, this.varMapper, expectedType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodExpression createMethodExpression(Class expectedReturnType, Class[] expectedParamTypes) throws ELException {
/* 189 */     Node n = build();
/* 190 */     if (n instanceof org.jdesktop.el.impl.parser.AstValue || n instanceof AstIdentifier) {
/* 191 */       return (MethodExpression)new MethodExpressionImpl(this.expression, n, this.fnMapper, this.varMapper, expectedReturnType, expectedParamTypes);
/*     */     }
/*     */     
/* 194 */     if (n instanceof org.jdesktop.el.impl.parser.AstLiteralExpression) {
/* 195 */       return (MethodExpression)new MethodExpressionLiteral(this.expression, expectedReturnType, expectedParamTypes);
/*     */     }
/*     */     
/* 198 */     throw new ELException("Not a Valid Method Expression: " + this.expression);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/ExpressionBuilder.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */