/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class PropertyPath
/*     */ {
/*     */   private PropertyPath() {}
/*     */   
/*  25 */   public String getLast() { return get(length() - 1); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static PropertyPath createPropertyPath(String path) {
/*  31 */     if (path == null) {
/*  32 */       throw new IllegalArgumentException("path must be non-null");
/*     */     }
/*     */     
/*  35 */     StringTokenizer tokenizer = new StringTokenizer(path, ".");
/*  36 */     ArrayList<String> list = new ArrayList<String>();
/*  37 */     while (tokenizer.hasMoreTokens()) {
/*  38 */       list.add(tokenizer.nextToken());
/*     */     }
/*     */     
/*  41 */     int size = list.size();
/*     */     
/*  43 */     if (size == 0)
/*  44 */       throw new IllegalArgumentException("path must be non-empty"); 
/*  45 */     if (list.size() == 1) {
/*  46 */       return new SinglePropertyPath(list.get(0));
/*     */     }
/*  48 */     String[] multi = new String[list.size()];
/*  49 */     return new MultiPropertyPath(list.toArray(multi));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/*  54 */     if (o == this) {
/*  55 */       return true;
/*     */     }
/*     */     
/*  58 */     if (o instanceof PropertyPath) {
/*  59 */       PropertyPath oPath = (PropertyPath)o;
/*     */       
/*  61 */       int length = length();
/*     */       
/*  63 */       if (length != oPath.length()) {
/*  64 */         return false;
/*     */       }
/*     */       
/*  67 */       int i = 0; if (i < length) {
/*  68 */         if (!get(i).equals(oPath.get(i))) {
/*  69 */           return false;
/*     */         }
/*     */         
/*  72 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/*  76 */     return false;
/*     */   } public abstract int length();
/*     */   public abstract String get(int paramInt);
/*     */   public int hashCode() {
/*  80 */     int result = 17;
/*  81 */     int length = length();
/*     */     
/*  83 */     for (int i = 0; i < length; i++) {
/*  84 */       result = 37 * result + get(i).hashCode();
/*     */     }
/*     */     
/*  87 */     return result;
/*     */   }
/*     */   
/*     */   public abstract String toString();
/*     */   
/*     */   static final class MultiPropertyPath extends PropertyPath {
/*     */     public MultiPropertyPath(String[] path) {
/*  94 */       this.path = path;
/*     */       
/*  96 */       for (int i = 0; i < path.length; i++) {
/*  97 */         path[i] = path[i].intern();
/*     */       }
/*     */       
/* 100 */       assert path.length > 0;
/*     */     }
/*     */     private final String[] path;
/*     */     
/* 104 */     public int length() { return this.path.length; }
/*     */ 
/*     */ 
/*     */     
/* 108 */     public String get(int index) { return this.path[index]; }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 112 */       StringBuilder builder = new StringBuilder();
/* 113 */       builder.append(this.path[0]);
/* 114 */       for (int i = 1; i < this.path.length; i++) {
/* 115 */         builder.append('.');
/* 116 */         builder.append(this.path[i]);
/*     */       } 
/* 118 */       return builder.toString();
/*     */     }
/*     */   }
/*     */   
/*     */   static final class SinglePropertyPath
/*     */     extends PropertyPath
/*     */   {
/*     */     private final String path;
/*     */     
/* 127 */     public SinglePropertyPath(String path) { this.path = path.intern(); }
/*     */ 
/*     */ 
/*     */     
/* 131 */     public int length() { return 1; }
/*     */ 
/*     */     
/*     */     public String get(int index) {
/* 135 */       if (index == 0) {
/* 136 */         return this.path;
/*     */       }
/*     */       
/* 139 */       throw new ArrayIndexOutOfBoundsException();
/*     */     }
/*     */ 
/*     */     
/* 143 */     public String getLast() { return this.path; }
/*     */ 
/*     */ 
/*     */     
/* 147 */     public String toString() { return this.path; }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/PropertyPath.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */