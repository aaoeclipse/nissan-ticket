/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.util.EventObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertyStateEvent
/*     */   extends EventObject
/*     */ {
/*  24 */   public static final Object UNREADABLE = new StringBuffer("UNREADABLE");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object sourceObject;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean valueChanged;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object oldValue;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final Object newValue;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final boolean writeableChanged;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isWriteable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyStateEvent(Property sourceProperty, Object sourceObject, boolean valueChanged, Object oldValue, Object newValue, boolean writeableChanged, boolean isWriteable) {
/*  62 */     super(sourceProperty);
/*     */     
/*  64 */     if (!writeableChanged && !valueChanged) {
/*  65 */       throw new IllegalArgumentException("Nothing has changed");
/*     */     }
/*     */     
/*  68 */     if (valueChanged && oldValue == UNREADABLE && newValue == UNREADABLE) {
/*  69 */       throw new IllegalArgumentException("Value can't change from UNREADABLE to UNREADABLE");
/*     */     }
/*     */     
/*  72 */     this.sourceObject = sourceObject;
/*  73 */     this.valueChanged = valueChanged;
/*  74 */     this.oldValue = oldValue;
/*  75 */     this.newValue = newValue;
/*  76 */     this.writeableChanged = writeableChanged;
/*  77 */     this.isWriteable = isWriteable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public final Object getSource() { return super.getSource(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  97 */   public final Property getSourceProperty() { return (Property)getSource(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public final Object getSourceObject() { return this.sourceObject; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public final boolean getValueChanged() { return this.valueChanged; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getOldValue() {
/* 131 */     if (!this.valueChanged) {
/* 132 */       throw new UnsupportedOperationException("value hasn't changed");
/*     */     }
/*     */     
/* 135 */     return this.oldValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Object getNewValue() {
/* 151 */     if (!this.valueChanged) {
/* 152 */       throw new UnsupportedOperationException("value hasn't changed");
/*     */     }
/*     */     
/* 155 */     return this.newValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 168 */   public final boolean getReadableChanged() { return (this.valueChanged && this.oldValue != this.newValue && (this.oldValue == UNREADABLE || this.newValue == UNREADABLE)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isReadable() {
/* 184 */     if (!getReadableChanged()) {
/* 185 */       throw new UnsupportedOperationException("readability hasn't changed");
/*     */     }
/*     */     
/* 188 */     return (this.newValue != UNREADABLE);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 199 */   public final boolean getWriteableChanged() { return this.writeableChanged; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean isWriteable() {
/* 214 */     if (!this.writeableChanged) {
/* 215 */       throw new UnsupportedOperationException("writeability hasn't changed");
/*     */     }
/*     */     
/* 218 */     return this.isWriteable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 231 */     StringBuffer buffer = new StringBuffer(getClass().getName());
/*     */     
/* 233 */     buffer.append(": Property ").append(getSourceProperty()).append(" changed on ").append(getSourceObject()).append(":\n");
/*     */     
/* 235 */     if (getValueChanged()) {
/* 236 */       buffer.append("    value changed from ").append(getOldValue()).append(" to ").append(getNewValue()).append('\n');
/*     */     }
/*     */     
/* 239 */     if (getReadableChanged()) {
/* 240 */       buffer.append("    readable changed from ").append(!isReadable()).append(" to ").append(isReadable()).append('\n');
/*     */     }
/*     */     
/* 243 */     if (getWriteableChanged()) {
/* 244 */       buffer.append("    writeable changed from ").append(!isWriteable()).append(" to ").append(isWriteable()).append('\n');
/*     */     }
/*     */     
/* 247 */     buffer.deleteCharAt(buffer.length() - 1);
/*     */     
/* 249 */     return buffer.toString();
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/PropertyStateEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */