/*    */ package org.jdesktop.el.impl.util;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MessageFactory
/*    */ {
/* 17 */   protected static final ResourceBundle bundle = ResourceBundle.getBundle("org.jdesktop.el.impl.Messages");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 27 */   public static String get(String key) { return bundle.getString(key); }
/*    */ 
/*    */ 
/*    */   
/* 31 */   public static String get(String key, Object obj0) { return getArray(key, new Object[] { obj0 }); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public static String get(String key, Object obj0, Object obj1) { return getArray(key, new Object[] { obj0, obj1 }); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public static String get(String key, Object obj0, Object obj1, Object obj2) { return getArray(key, new Object[] { obj0, obj1, obj2 }); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 46 */   public static String get(String key, Object obj0, Object obj1, Object obj2, Object obj3) { return getArray(key, new Object[] { obj0, obj1, obj2, obj3 }); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   public static String get(String key, Object obj0, Object obj1, Object obj2, Object obj3, Object obj4) { return getArray(key, new Object[] { obj0, obj1, obj2, obj3, obj4 }); }
/*    */ 
/*    */ 
/*    */   
/* 56 */   public static String getArray(String key, Object[] objA) { return MessageFormat.format(bundle.getString(key), objA); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/util/MessageFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */