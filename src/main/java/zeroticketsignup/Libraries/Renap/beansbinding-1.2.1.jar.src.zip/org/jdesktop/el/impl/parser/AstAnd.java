/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstAnd
/*    */   extends BooleanNode
/*    */ {
/* 20 */   public AstAnd(int id) { super(id); }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 25 */     Object obj = this.children[0].getValue(ctx);
/* 26 */     if (obj == ELContext.UNRESOLVABLE_RESULT) {
/* 27 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 29 */     Boolean b = coerceToBoolean(obj);
/* 30 */     if (!b.booleanValue()) {
/* 31 */       return b;
/*    */     }
/* 33 */     obj = this.children[1].getValue(ctx);
/* 34 */     if (obj == ELContext.UNRESOLVABLE_RESULT) {
/* 35 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 37 */     b = coerceToBoolean(obj);
/* 38 */     return b;
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstAnd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */