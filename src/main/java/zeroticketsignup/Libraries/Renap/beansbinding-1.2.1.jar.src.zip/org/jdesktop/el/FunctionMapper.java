package org.jdesktop.el;

import java.lang.reflect.Method;

public abstract class FunctionMapper {
  public abstract Method resolveFunction(String paramString1, String paramString2);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/FunctionMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */