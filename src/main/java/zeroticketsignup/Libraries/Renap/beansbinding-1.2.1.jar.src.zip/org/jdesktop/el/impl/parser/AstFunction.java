/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*     */ import org.jdesktop.el.impl.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AstFunction
/*     */   extends SimpleNode
/*     */ {
/*  25 */   protected String localName = "";
/*     */   
/*  27 */   protected String prefix = "";
/*     */ 
/*     */   
/*  30 */   public AstFunction(int id) { super(id); }
/*     */ 
/*     */ 
/*     */   
/*  34 */   public String getLocalName() { return this.localName; }
/*     */ 
/*     */   
/*     */   public String getOutputName() {
/*  38 */     if (this.prefix == null) {
/*  39 */       return this.localName;
/*     */     }
/*  41 */     return this.prefix + ":" + this.localName;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  46 */   public String getPrefix() { return this.prefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getType(EvaluationContext ctx) throws ELException {
/*  52 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */ 
/*     */     
/*  55 */     if (fnMapper == null) {
/*  56 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  58 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*  59 */     if (m == null) {
/*  60 */       throw new ELException(MessageFactory.get("error.fnMapper.method", getOutputName()));
/*     */     }
/*     */     
/*  63 */     return m.getReturnType();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(EvaluationContext ctx) throws ELException {
/*  69 */     FunctionMapper fnMapper = ctx.getFunctionMapper();
/*     */ 
/*     */     
/*  72 */     if (fnMapper == null) {
/*  73 */       throw new ELException(MessageFactory.get("error.fnMapper.null"));
/*     */     }
/*  75 */     Method m = fnMapper.resolveFunction(this.prefix, this.localName);
/*  76 */     if (m == null) {
/*  77 */       throw new ELException(MessageFactory.get("error.fnMapper.method", getOutputName()));
/*     */     }
/*     */ 
/*     */     
/*  81 */     Class[] paramTypes = m.getParameterTypes();
/*  82 */     Object[] params = null;
/*  83 */     Object result = null;
/*  84 */     int numParams = jjtGetNumChildren();
/*  85 */     if (numParams > 0) {
/*  86 */       params = new Object[numParams];
/*     */       try {
/*  88 */         for (int i = 0; i < numParams; i++) {
/*  89 */           params[i] = this.children[i].getValue(ctx);
/*  90 */           if (params[i] == ELContext.UNRESOLVABLE_RESULT) {
/*  91 */             return ELContext.UNRESOLVABLE_RESULT;
/*     */           }
/*  93 */           params[i] = coerceToType(params[i], paramTypes[i]);
/*     */         } 
/*  95 */       } catch (ELException ele) {
/*  96 */         throw new ELException(MessageFactory.get("error.function", getOutputName()), (Throwable)ele);
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 101 */       result = m.invoke(null, params);
/* 102 */     } catch (IllegalAccessException iae) {
/* 103 */       throw new ELException(MessageFactory.get("error.function", getOutputName()), iae);
/*     */     }
/* 105 */     catch (InvocationTargetException ite) {
/* 106 */       throw new ELException(MessageFactory.get("error.function", getOutputName()), ite.getCause());
/*     */     } 
/*     */     
/* 109 */     return result;
/*     */   }
/*     */ 
/*     */   
/* 113 */   public void setLocalName(String localName) { this.localName = localName; }
/*     */ 
/*     */ 
/*     */   
/* 117 */   public void setPrefix(String prefix) { this.prefix = prefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   public String toString() { return ELParserTreeConstants.jjtNodeName[this.id] + "[" + getOutputName() + "]"; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstFunction.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */