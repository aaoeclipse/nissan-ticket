/*     */ package org.jdesktop.swingbinding;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import org.jdesktop.beansbinding.AutoBinding;
/*     */ import org.jdesktop.beansbinding.Binding;
/*     */ import org.jdesktop.beansbinding.BindingListener;
/*     */ import org.jdesktop.beansbinding.Property;
/*     */ import org.jdesktop.beansbinding.PropertyStateEvent;
/*     */ import org.jdesktop.beansbinding.PropertyStateListener;
/*     */ import org.jdesktop.swingbinding.impl.AbstractColumnBinding;
/*     */ import org.jdesktop.swingbinding.impl.ListBindingManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JTableBinding<E, SS, TS>
/*     */   extends AutoBinding<SS, List<E>, TS, List>
/*     */ {
/*     */   private Property<TS, ? extends JTable> tableP;
/*     */   private ElementsProperty<TS> elementsP;
/* 210 */   private Handler handler = new Handler();
/*     */   private JTable table;
/*     */   private BindingTableModel model;
/*     */   private boolean editable = true;
/* 214 */   private List<ColumnBinding> columnBindings = new ArrayList<ColumnBinding>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JTableBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JTable> targetJTableProperty, String name) {
/* 228 */     super((strategy == AutoBinding.UpdateStrategy.READ_WRITE) ? AutoBinding.UpdateStrategy.READ : strategy, sourceObject, sourceListProperty, targetObject, (Property)new ElementsProperty(), name);
/*     */ 
/*     */     
/* 231 */     if (targetJTableProperty == null) {
/* 232 */       throw new IllegalArgumentException("target JTable property can't be null");
/*     */     }
/*     */     
/* 235 */     this.tableP = targetJTableProperty;
/* 236 */     this.elementsP = (ElementsProperty<TS>)getTargetProperty();
/*     */   }
/*     */   
/*     */   protected void bindImpl() {
/* 240 */     this.elementsP.setAccessible(isTableAccessible());
/* 241 */     this.tableP.addPropertyStateListener(getTargetObject(), this.handler);
/* 242 */     this.elementsP.addPropertyStateListener(null, this.handler);
/* 243 */     super.bindImpl();
/*     */   }
/*     */   
/*     */   protected void unbindImpl() {
/* 247 */     this.elementsP.removePropertyStateListener(null, this.handler);
/* 248 */     this.tableP.removePropertyStateListener(getTargetObject(), this.handler);
/* 249 */     this.elementsP.setAccessible(false);
/* 250 */     cleanupForLast();
/* 251 */     super.unbindImpl();
/*     */   }
/*     */ 
/*     */   
/* 255 */   private boolean isTableAccessible() { return (this.tableP.isReadable(getTargetObject()) && this.tableP.getValue(getTargetObject()) != null); }
/*     */ 
/*     */ 
/*     */   
/* 259 */   private boolean isTableAccessible(Object value) { return (value != null && value != PropertyStateEvent.UNREADABLE); }
/*     */ 
/*     */   
/*     */   private void cleanupForLast() {
/* 263 */     if (this.table == null) {
/*     */       return;
/*     */     }
/*     */     
/* 267 */     this.table.setModel(new DefaultTableModel());
/* 268 */     this.table = null;
/* 269 */     this.model.setElements(null, true);
/* 270 */     this.model = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 282 */   public void setEditable(boolean editable) { this.editable = editable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 294 */   public boolean isEditable() { return this.editable; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 312 */   public ColumnBinding addColumnBinding(Property<E, ?> columnProperty) { return addColumnBinding(columnProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColumnBinding addColumnBinding(Property<E, ?> columnProperty, String name) {
/* 331 */     throwIfBound();
/*     */     
/* 333 */     if (columnProperty == null) {
/* 334 */       throw new IllegalArgumentException("can't have null column property");
/*     */     }
/*     */     
/* 337 */     if (name == null && getName() != null) {
/* 338 */       name = getName() + ".COLUMN_BINDING";
/*     */     }
/*     */     
/* 341 */     ColumnBinding binding = new ColumnBinding(this.columnBindings.size(), columnProperty, name);
/* 342 */     this.columnBindings.add(binding);
/* 343 */     return binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 362 */   public ColumnBinding addColumnBinding(int index, Property<E, ?> columnProperty) { return addColumnBinding(index, columnProperty, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColumnBinding addColumnBinding(int index, Property<E, ?> columnProperty, String name) {
/* 382 */     throwIfBound();
/*     */     
/* 384 */     if (columnProperty == null) {
/* 385 */       throw new IllegalArgumentException("can't have null column property");
/*     */     }
/*     */     
/* 388 */     if (name == null && getName() != null) {
/* 389 */       name = getName() + ".COLUMN_BINDING";
/*     */     }
/*     */     
/* 392 */     ColumnBinding binding = new ColumnBinding(index, columnProperty, name);
/* 393 */     this.columnBindings.add(index, binding);
/* 394 */     adjustIndices(index + 1, true);
/* 395 */     return binding;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean removeColumnBinding(ColumnBinding binding) {
/* 410 */     throwIfBound();
/* 411 */     boolean retVal = this.columnBindings.remove(binding);
/*     */     
/* 413 */     if (retVal) {
/* 414 */       adjustIndices(binding.getColumn(), false);
/*     */     }
/*     */     
/* 417 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ColumnBinding removeColumnBinding(int index) {
/* 432 */     throwIfBound();
/* 433 */     ColumnBinding retVal = this.columnBindings.remove(index);
/*     */     
/* 435 */     if (retVal != null) {
/* 436 */       adjustIndices(index, false);
/*     */     }
/*     */     
/* 439 */     return retVal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 455 */   public ColumnBinding getColumnBinding(int index) { return this.columnBindings.get(index); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 470 */   public List<ColumnBinding> getColumnBindings() { return Collections.unmodifiableList(this.columnBindings); }
/*     */ 
/*     */   
/*     */   private void adjustIndices(int start, boolean up) {
/* 474 */     int size = this.columnBindings.size();
/* 475 */     for (int i = start; i < size; i++) {
/* 476 */       ColumnBinding cb = this.columnBindings.get(i);
/* 477 */       cb.adjustColumn(cb.getColumn() + (up ? 1 : -1));
/*     */     } 
/*     */   }
/*     */   
/*     */   private final class ColumnProperty
/*     */     extends Property {
/*     */     private JTableBinding<E, SS, TS>.ColumnBinding binding;
/*     */     
/* 485 */     public Class<? extends Object> getWriteType(Object source) { return (this.binding.columnClass == null) ? Object.class : (Class)this.binding.columnClass; }
/*     */     private ColumnProperty() {}
/*     */     
/*     */     public Object getValue(Object source) {
/* 489 */       if (this.binding.isBound()) {
/* 490 */         return this.binding.editingObject;
/*     */       }
/*     */       
/* 493 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     
/* 497 */     public void setValue(Object source, Object value) { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */     
/* 501 */     public boolean isReadable(Object source) { return this.binding.isBound(); }
/*     */ 
/*     */ 
/*     */     
/* 505 */     public boolean isWriteable(Object source) { return true; }
/*     */ 
/*     */ 
/*     */     
/*     */     public void addPropertyStateListener(Object source, PropertyStateListener listener) {}
/*     */ 
/*     */     
/*     */     public void removePropertyStateListener(Object source, PropertyStateListener listener) {}
/*     */ 
/*     */     
/* 515 */     public PropertyStateListener[] getPropertyStateListeners(Object source) { return new PropertyStateListener[0]; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final class ColumnBinding
/*     */     extends AbstractColumnBinding
/*     */   {
/*     */     private Class<?> columnClass;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean editable = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean editableSet;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String columnName;
/*     */ 
/*     */ 
/*     */     
/*     */     private Object editingObject;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ColumnBinding(int column, Property<E, ?> columnProperty, String name) {
/* 550 */       super(column, columnProperty, new JTableBinding.ColumnProperty(JTableBinding.this, null), name);
/* 551 */       ((JTableBinding.ColumnProperty)getTargetProperty()).binding = this;
/*     */     }
/*     */ 
/*     */     
/* 555 */     private void setEditingObject(Object editingObject) { this.editingObject = editingObject; }
/*     */ 
/*     */ 
/*     */     
/* 559 */     private void adjustColumn(int newCol) { setColumn(newCol); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ColumnBinding setColumnName(String name) {
/* 573 */       JTableBinding.this.throwIfBound();
/* 574 */       this.columnName = name;
/* 575 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ColumnBinding setColumnClass(Class<?> columnClass) {
/* 588 */       JTableBinding.this.throwIfBound();
/* 589 */       this.columnClass = columnClass;
/* 590 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 602 */     public Class<?> getColumnClass() { return (this.columnClass == null) ? Object.class : this.columnClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 616 */     public String getColumnName() { return (this.columnName == null) ? getSourceProperty().toString() : this.columnName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ColumnBinding setEditable(boolean editable) {
/* 629 */       this.editable = editable;
/* 630 */       return this;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 642 */     public boolean isEditable() { return this.editable; }
/*     */ 
/*     */ 
/*     */     
/* 646 */     private void bindUnmanaged0() { bindUnmanaged(); }
/*     */ 
/*     */ 
/*     */     
/* 650 */     private void unbindUnmanaged0() { unbindUnmanaged(); }
/*     */ 
/*     */ 
/*     */     
/* 654 */     private Binding.SyncFailure saveUnmanaged0() { return saveUnmanaged(); }
/*     */ 
/*     */ 
/*     */     
/* 658 */     private void setSourceObjectUnmanaged0(Object source) { setSourceObjectUnmanaged(source); } }
/*     */   
/*     */   private class Handler implements PropertyStateListener {
/*     */     private Handler() {}
/*     */     
/*     */     public void propertyStateChanged(PropertyStateEvent pse) {
/* 664 */       if (!pse.getValueChanged()) {
/*     */         return;
/*     */       }
/*     */       
/* 668 */       if (pse.getSourceProperty() == JTableBinding.this.tableP) {
/* 669 */         JTableBinding.this.cleanupForLast();
/*     */         
/* 671 */         boolean wasAccessible = JTableBinding.this.isTableAccessible(pse.getOldValue());
/* 672 */         boolean isAccessible = JTableBinding.this.isTableAccessible(pse.getNewValue());
/*     */         
/* 674 */         if (wasAccessible != isAccessible) {
/* 675 */           JTableBinding.this.elementsP.setAccessible(isAccessible);
/* 676 */         } else if (JTableBinding.this.elementsP.isAccessible()) {
/* 677 */           JTableBinding.this.elementsP.setValueAndIgnore(null, null);
/*     */         } 
/*     */       } else {
/* 680 */         if (((ElementsProperty.ElementsPropertyStateEvent)pse).shouldIgnore()) {
/*     */           return;
/*     */         }
/*     */         
/* 684 */         if (JTableBinding.this.table == null) {
/* 685 */           JTableBinding.this.table = (JTable)JTableBinding.this.tableP.getValue(JTableBinding.this.getTargetObject());
/* 686 */           JTableBinding.this.model = new JTableBinding.BindingTableModel();
/* 687 */           JTableBinding.this.table.setModel(JTableBinding.this.model);
/*     */         } 
/*     */         
/* 690 */         JTableBinding.this.model.setElements((List)pse.getNewValue(), true);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private final class BindingTableModel
/*     */     extends ListBindingManager
/*     */     implements TableModel
/*     */   {
/* 699 */     private final List<TableModelListener> listeners = new CopyOnWriteArrayList<TableModelListener>();
/*     */ 
/*     */     
/*     */     protected AbstractColumnBinding[] getColBindings() {
/* 703 */       AbstractColumnBinding[] bindings = new AbstractColumnBinding[JTableBinding.this.getColumnBindings().size()];
/* 704 */       bindings = (AbstractColumnBinding[])JTableBinding.this.getColumnBindings().toArray((Object[])bindings);
/* 705 */       return bindings;
/*     */     }
/*     */ 
/*     */     
/* 709 */     public int getRowCount() { return size(); }
/*     */ 
/*     */ 
/*     */     
/* 713 */     public Object getValueAt(int rowIndex, int columnIndex) { return valueAt(rowIndex, columnIndex); }
/*     */ 
/*     */     
/*     */     public void setValueAt(Object value, int rowIndex, int columnIndex) {
/* 717 */       JTableBinding<E, SS, TS>.ColumnBinding cb = JTableBinding.this.getColumnBinding(columnIndex);
/* 718 */       BindingListener[] cbListeners = cb.getBindingListeners();
/* 719 */       BindingListener[] tbListeners = JTableBinding.this.getBindingListeners();
/*     */       
/* 721 */       cb.setSourceObjectUnmanaged0(getElement(rowIndex));
/* 722 */       cb.setEditingObject(value);
/* 723 */       cb.bindUnmanaged0();
/*     */       
/* 725 */       for (BindingListener listener : tbListeners) {
/* 726 */         listener.bindingBecameBound((Binding)cb);
/*     */       }
/*     */       
/* 729 */       PropertyStateEvent pse = new PropertyStateEvent(cb.getTargetProperty(), cb.getTargetObject(), true, getValueAt(rowIndex, columnIndex), value, false, cb.getSourceProperty().isWriteable(cb.getSourceObject()));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 737 */       for (BindingListener listener : cbListeners) {
/* 738 */         listener.targetChanged((Binding)cb, pse);
/*     */       }
/*     */       
/* 741 */       for (BindingListener listener : tbListeners) {
/* 742 */         listener.targetChanged((Binding)cb, pse);
/*     */       }
/*     */       
/* 745 */       Binding.SyncFailure failure = cb.saveUnmanaged0();
/*     */       
/* 747 */       if (failure == null) {
/* 748 */         for (BindingListener listener : cbListeners) {
/* 749 */           listener.synced((Binding)cb);
/*     */         }
/*     */         
/* 752 */         for (BindingListener listener : tbListeners) {
/* 753 */           listener.synced((Binding)cb);
/*     */         }
/*     */       } else {
/* 756 */         for (BindingListener listener : cbListeners) {
/* 757 */           listener.syncFailed((Binding)cb, failure);
/*     */         }
/*     */         
/* 760 */         for (BindingListener listener : tbListeners) {
/* 761 */           listener.syncFailed((Binding)cb, failure);
/*     */         }
/*     */       } 
/*     */       
/* 765 */       cb.unbindUnmanaged0();
/*     */       
/* 767 */       for (BindingListener listener : tbListeners) {
/* 768 */         listener.bindingBecameUnbound((Binding)cb);
/*     */       }
/*     */       
/* 771 */       cb.setEditingObject(null);
/* 772 */       cb.setSourceObjectUnmanaged0(null);
/*     */     }
/*     */     
/*     */     public Class<?> getColumnClass(int columnIndex) {
/* 776 */       Class<?> klass = JTableBinding.this.getColumnBinding(columnIndex).getColumnClass();
/* 777 */       return (klass == null) ? Object.class : klass;
/*     */     }
/*     */ 
/*     */     
/* 781 */     protected void allChanged() { fireTableModelEvent(new TableModelEvent(this, 0, 2147483647)); }
/*     */ 
/*     */ 
/*     */     
/* 785 */     protected void valueChanged(int row, int column) { fireTableModelEvent(new TableModelEvent(this, row, row, column)); }
/*     */ 
/*     */     
/*     */     protected void added(int row, int length) {
/* 789 */       assert length > 0;
/*     */       
/* 791 */       fireTableModelEvent(new TableModelEvent(this, row, row + length - 1, -1, 1));
/*     */     }
/*     */     
/*     */     protected void removed(int row, int length) {
/* 795 */       assert length > 0;
/*     */       
/* 797 */       fireTableModelEvent(new TableModelEvent(this, row, row + length - 1, -1, -1));
/*     */     }
/*     */ 
/*     */     
/* 801 */     protected void changed(int row) { fireTableModelEvent(new TableModelEvent(this, row, row, -1)); }
/*     */ 
/*     */     
/*     */     public String getColumnName(int columnIndex) {
/* 805 */       JTableBinding<E, SS, TS>.ColumnBinding binding = JTableBinding.this.getColumnBinding(columnIndex);
/* 806 */       return (binding.getColumnName() == null) ? binding.getSourceProperty().toString() : binding.getColumnName();
/*     */     }
/*     */     
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 810 */       if (!JTableBinding.this.isEditable()) {
/* 811 */         return false;
/*     */       }
/*     */       
/* 814 */       JTableBinding<E, SS, TS>.ColumnBinding binding = JTableBinding.this.getColumnBinding(columnIndex);
/* 815 */       if (!binding.isEditable()) {
/* 816 */         return false;
/*     */       }
/*     */       
/* 819 */       return binding.getSourceProperty().isWriteable(getElement(rowIndex));
/*     */     }
/*     */ 
/*     */     
/* 823 */     public void addTableModelListener(TableModelListener l) { this.listeners.add(l); }
/*     */ 
/*     */ 
/*     */     
/* 827 */     public void removeTableModelListener(TableModelListener l) { this.listeners.remove(l); }
/*     */ 
/*     */     
/*     */     private void fireTableModelEvent(TableModelEvent e) {
/* 831 */       for (TableModelListener listener : this.listeners) {
/* 832 */         listener.tableChanged(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 837 */     public int getColumnCount() { return columnCount(); }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/JTableBinding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */