/*    */ package org.jdesktop.el.impl.lang;
/*    */ 
/*    */ import java.io.Externalizable;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInput;
/*    */ import java.io.ObjectOutput;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jdesktop.el.ValueExpression;
/*    */ import org.jdesktop.el.VariableMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableMapperImpl
/*    */   extends VariableMapper
/*    */   implements Externalizable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 22 */   private Map vars = new HashMap<Object, Object>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public ValueExpression resolveVariable(String variable) { return (ValueExpression)this.vars.get(variable); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public ValueExpression setVariable(String variable, ValueExpression expression) { return this.vars.put(variable, expression); }
/*    */ 
/*    */ 
/*    */   
/* 38 */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException { this.vars = (Map)in.readObject(); }
/*    */ 
/*    */ 
/*    */   
/* 42 */   public void writeExternal(ObjectOutput out) throws IOException { out.writeObject(this.vars); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/VariableMapperImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */