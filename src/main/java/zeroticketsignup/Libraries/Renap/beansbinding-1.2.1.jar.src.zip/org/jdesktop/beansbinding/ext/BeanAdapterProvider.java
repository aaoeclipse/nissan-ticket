package org.jdesktop.beansbinding.ext;

public interface BeanAdapterProvider {
  boolean providesAdapter(Class<?> paramClass, String paramString);
  
  Object createAdapter(Object paramObject, String paramString);
  
  Class<?> getAdapterClass(Class<?> paramClass);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/ext/BeanAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */