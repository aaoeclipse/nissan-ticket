/*    */ package org.jdesktop.el.impl;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ExpressionFactory;
/*    */ import org.jdesktop.el.MethodExpression;
/*    */ import org.jdesktop.el.ValueExpression;
/*    */ import org.jdesktop.el.impl.lang.ELSupport;
/*    */ import org.jdesktop.el.impl.lang.ExpressionBuilder;
/*    */ import org.jdesktop.el.impl.util.MessageFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExpressionFactoryImpl
/*    */   extends ExpressionFactory
/*    */ {
/* 33 */   public Object coerceToType(Object obj, Class type) { return ELSupport.coerceToType(obj, type); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public MethodExpression createMethodExpression(ELContext context, String expression, Class expectedReturnType, Class[] expectedParamTypes) {
/* 39 */     if (expectedParamTypes == null) {
/* 40 */       throw new NullPointerException(MessageFactory.get("error.method.nullParms"));
/*    */     }
/*    */     
/* 43 */     ExpressionBuilder builder = new ExpressionBuilder(expression, context);
/* 44 */     return builder.createMethodExpression(expectedReturnType, expectedParamTypes);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public ValueExpression createValueExpression(ELContext context, String expression, Class expectedType) {
/* 50 */     if (expectedType == null) {
/* 51 */       throw new NullPointerException(MessageFactory.get("error.value.expectedType"));
/*    */     }
/*    */     
/* 54 */     ExpressionBuilder builder = new ExpressionBuilder(expression, context);
/* 55 */     return builder.createValueExpression(expectedType);
/*    */   }
/*    */ 
/*    */   
/*    */   public ValueExpression createValueExpression(Object instance, Class expectedType) {
/* 60 */     if (expectedType == null) {
/* 61 */       throw new NullPointerException(MessageFactory.get("error.value.expectedType"));
/*    */     }
/*    */     
/* 64 */     return new ValueExpressionLiteral(instance, expectedType);
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/ExpressionFactoryImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */