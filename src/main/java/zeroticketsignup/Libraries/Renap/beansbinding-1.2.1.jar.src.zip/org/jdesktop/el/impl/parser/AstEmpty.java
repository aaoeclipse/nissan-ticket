/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstEmpty
/*    */   extends SimpleNode
/*    */ {
/* 23 */   public AstEmpty(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   public Class getType(EvaluationContext ctx) throws ELException { return Boolean.class; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 33 */     Object obj = this.children[0].getValue(ctx);
/* 34 */     if (obj == ELContext.UNRESOLVABLE_RESULT)
/* 35 */       return ELContext.UNRESOLVABLE_RESULT; 
/* 36 */     if (obj == null)
/* 37 */       return Boolean.TRUE; 
/* 38 */     if (obj instanceof String)
/* 39 */       return Boolean.valueOf((((String)obj).length() == 0)); 
/* 40 */     if (obj instanceof Object[])
/* 41 */       return Boolean.valueOf((((Object[])obj).length == 0)); 
/* 42 */     if (obj instanceof Collection)
/* 43 */       return Boolean.valueOf(((Collection)obj).isEmpty()); 
/* 44 */     if (obj instanceof Map) {
/* 45 */       return Boolean.valueOf(((Map)obj).isEmpty());
/*    */     }
/* 47 */     return Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstEmpty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */