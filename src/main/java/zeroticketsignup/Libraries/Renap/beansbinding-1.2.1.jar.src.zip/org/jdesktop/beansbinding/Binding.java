/*      */ package org.jdesktop.beansbinding;
/*      */ 
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.beans.PropertyChangeSupport;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Binding<SS, SV, TS, TV>
/*      */ {
/*      */   private String name;
/*      */   private SS sourceObject;
/*      */   private TS targetObject;
/*      */   private Property<SS, SV> sourceProperty;
/*      */   private Property<TS, TV> targetProperty;
/*      */   private Validator<? super SV> validator;
/*      */   private Converter<SV, TV> converter;
/*      */   private TV sourceNullValue;
/*      */   private SV targetNullValue;
/*      */   private TV sourceUnreadableValue;
/*      */   private boolean sourceUnreadableValueSet;
/*      */   private List<BindingListener> listeners;
/*      */   private PropertyStateListener psl;
/*      */   private boolean ignoreChange;
/*      */   private boolean isManaged;
/*      */   private boolean isBound;
/*      */   private PropertyChangeSupport changeSupport;
/*      */   
/*      */   public enum SyncFailureType
/*      */   {
/*   71 */     TARGET_UNWRITEABLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   77 */     SOURCE_UNWRITEABLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   83 */     TARGET_UNREADABLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   89 */     SOURCE_UNREADABLE,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   96 */     CONVERSION_FAILED,
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  103 */     VALIDATION_FAILED;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class SyncFailure
/*      */   {
/*      */     private Binding.SyncFailureType type;
/*      */     
/*      */     private Object reason;
/*      */     
/*  114 */     private static SyncFailure TARGET_UNWRITEABLE = new SyncFailure(Binding.SyncFailureType.TARGET_UNWRITEABLE);
/*  115 */     private static SyncFailure SOURCE_UNWRITEABLE = new SyncFailure(Binding.SyncFailureType.SOURCE_UNWRITEABLE);
/*  116 */     private static SyncFailure TARGET_UNREADABLE = new SyncFailure(Binding.SyncFailureType.TARGET_UNREADABLE);
/*  117 */     private static SyncFailure SOURCE_UNREADABLE = new SyncFailure(Binding.SyncFailureType.SOURCE_UNREADABLE);
/*      */ 
/*      */     
/*  120 */     private static SyncFailure conversionFailure(RuntimeException rte) { return new SyncFailure(rte); }
/*      */ 
/*      */ 
/*      */     
/*  124 */     private static SyncFailure validationFailure(Validator.Result result) { return new SyncFailure(result); }
/*      */ 
/*      */     
/*      */     private SyncFailure(Binding.SyncFailureType type) {
/*  128 */       if (type == Binding.SyncFailureType.CONVERSION_FAILED || type == Binding.SyncFailureType.VALIDATION_FAILED) {
/*  129 */         throw new IllegalArgumentException();
/*      */       }
/*      */       
/*  132 */       this.type = type;
/*      */     }
/*      */     
/*      */     private SyncFailure(RuntimeException exception) {
/*  136 */       this.type = Binding.SyncFailureType.CONVERSION_FAILED;
/*  137 */       this.reason = exception;
/*      */     }
/*      */     
/*      */     private SyncFailure(Validator.Result result) {
/*  141 */       this.type = Binding.SyncFailureType.VALIDATION_FAILED;
/*  142 */       this.reason = result;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  151 */     public Binding.SyncFailureType getType() { return this.type; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public RuntimeException getConversionException() {
/*  164 */       if (this.type != Binding.SyncFailureType.CONVERSION_FAILED) {
/*  165 */         throw new UnsupportedOperationException();
/*      */       }
/*      */       
/*  168 */       return (RuntimeException)this.reason;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Validator.Result getValidationResult() {
/*  181 */       if (this.type != Binding.SyncFailureType.VALIDATION_FAILED) {
/*  182 */         throw new UnsupportedOperationException();
/*      */       }
/*      */       
/*  185 */       return (Validator.Result)this.reason;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  198 */     public String toString() { return this.type + ((this.reason == null) ? "" : (": " + this.reason.toString())); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final class ValueResult<V>
/*      */   {
/*      */     private V value;
/*      */ 
/*      */     
/*      */     private Binding.SyncFailure failure;
/*      */ 
/*      */ 
/*      */     
/*  213 */     private ValueResult(V value) { this.value = value; }
/*      */ 
/*      */     
/*      */     private ValueResult(Binding.SyncFailure failure) {
/*  217 */       if (failure == null) {
/*  218 */         throw new AssertionError();
/*      */       }
/*      */       
/*  221 */       this.failure = failure;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  233 */     public boolean failed() { return (this.failure != null); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public V getValue() {
/*  246 */       if (failed()) {
/*  247 */         throw new UnsupportedOperationException();
/*      */       }
/*      */       
/*  250 */       return this.value;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Binding.SyncFailure getFailure() {
/*  263 */       if (!failed()) {
/*  264 */         throw new UnsupportedOperationException();
/*      */       }
/*      */       
/*  267 */       return this.failure;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  280 */     public String toString() { return (this.value == null) ? ("failure: " + this.failure) : ("value: " + this.value); }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Binding(SS sourceObject, Property<SS, SV> sourceProperty, TS targetObject, Property<TS, TV> targetProperty, String name) {
/*  295 */     setSourceProperty(sourceProperty);
/*  296 */     setTargetProperty(targetProperty);
/*      */     
/*  298 */     this.sourceObject = sourceObject;
/*  299 */     this.sourceProperty = sourceProperty;
/*  300 */     this.targetObject = targetObject;
/*  301 */     this.targetProperty = targetProperty;
/*  302 */     this.name = name;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setSourceProperty(Property<SS, SV> sourceProperty) {
/*  320 */     throwIfBound();
/*  321 */     if (sourceProperty == null) {
/*  322 */       throw new IllegalArgumentException("source property can't be null");
/*      */     }
/*  324 */     Property<SS, SV> old = this.sourceProperty;
/*  325 */     this.sourceProperty = sourceProperty;
/*  326 */     firePropertyChange("sourceProperty", old, sourceProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setTargetProperty(Property<TS, TV> targetProperty) {
/*  344 */     throwIfBound();
/*  345 */     if (targetProperty == null) {
/*  346 */       throw new IllegalArgumentException("target property can't be null");
/*      */     }
/*  348 */     Property<TS, TV> old = this.targetProperty;
/*  349 */     this.targetProperty = targetProperty;
/*  350 */     firePropertyChange("targetProperty", old, targetProperty);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  359 */   public final String getName() { return this.name; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  369 */   public final Property<SS, SV> getSourceProperty() { return this.sourceProperty; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  379 */   public final Property<TS, TV> getTargetProperty() { return this.targetProperty; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  389 */   public final SS getSourceObject() { return this.sourceObject; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  399 */   public final TS getTargetObject() { return this.targetObject; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSourceObject(SS sourceObject) {
/*  418 */     throwIfManaged();
/*  419 */     setSourceObjectUnmanaged(sourceObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setSourceObjectUnmanaged(SS sourceObject) {
/*  433 */     throwIfBound();
/*  434 */     SS old = this.sourceObject;
/*  435 */     this.sourceObject = sourceObject;
/*  436 */     firePropertyChange("sourceObject", old, sourceObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTargetObject(TS targetObject) {
/*  455 */     throwIfManaged();
/*  456 */     setTargetObjectUnmanaged(targetObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setTargetObjectUnmanaged(TS targetObject) {
/*  470 */     throwIfBound();
/*  471 */     TS old = this.targetObject;
/*  472 */     this.targetObject = targetObject;
/*  473 */     firePropertyChange("targetObject", old, targetObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setValidator(Validator<? super SV> validator) {
/*  493 */     throwIfBound();
/*  494 */     Validator<? super SV> old = this.validator;
/*  495 */     this.validator = validator;
/*  496 */     firePropertyChange("validator", old, validator);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  506 */   public final Validator<? super SV> getValidator() { return this.validator; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setConverter(Converter<SV, TV> converter) {
/*  527 */     throwIfBound();
/*  528 */     Converter<SV, TV> old = this.converter;
/*  529 */     this.converter = converter;
/*  530 */     firePropertyChange("converter", old, converter);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  540 */   public final Converter<SV, TV> getConverter() { return this.converter; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSourceNullValue(TV sourceNullValue) {
/*  558 */     throwIfBound();
/*  559 */     TV old = this.sourceNullValue;
/*  560 */     this.sourceNullValue = sourceNullValue;
/*  561 */     firePropertyChange("sourceNullValue", old, sourceNullValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  574 */   public final TV getSourceNullValue() { return this.sourceNullValue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setTargetNullValue(SV targetNullValue) {
/*  592 */     throwIfBound();
/*  593 */     SV old = this.targetNullValue;
/*  594 */     this.targetNullValue = targetNullValue;
/*  595 */     firePropertyChange("targetNullValue", old, targetNullValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  608 */   public final SV getTargetNullValue() { return this.targetNullValue; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setSourceUnreadableValue(TV sourceUnreadableValue) {
/*  642 */     throwIfBound();
/*      */     
/*  644 */     TV old = this.sourceUnreadableValue;
/*  645 */     boolean oldSet = this.sourceUnreadableValueSet;
/*      */     
/*  647 */     this.sourceUnreadableValue = sourceUnreadableValue;
/*  648 */     this.sourceUnreadableValueSet = true;
/*      */     
/*  650 */     firePropertyChange("sourceUnreadableValueSet", Boolean.valueOf(oldSet), Boolean.valueOf(true));
/*  651 */     firePropertyChange("sourceUnreadableValue", old, sourceUnreadableValue);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void unsetSourceUnreadableValue() {
/*  674 */     throwIfBound();
/*      */     
/*  676 */     if (isSourceUnreadableValueSet()) {
/*  677 */       TV old = this.sourceUnreadableValue;
/*      */       
/*  679 */       this.sourceUnreadableValue = null;
/*  680 */       this.sourceUnreadableValueSet = false;
/*      */       
/*  682 */       firePropertyChange("sourceUnreadableValueSet", Boolean.valueOf(true), Boolean.valueOf(false));
/*  683 */       firePropertyChange("sourceUnreadableValue", old, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  702 */   public final boolean isSourceUnreadableValueSet() { return this.sourceUnreadableValueSet; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final TV getSourceUnreadableValue() {
/*  721 */     if (!isSourceUnreadableValueSet()) {
/*  722 */       throw new UnsupportedOperationException("not set");
/*      */     }
/*      */     
/*  725 */     return this.sourceUnreadableValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addBindingListener(BindingListener listener) {
/*  737 */     if (listener == null) {
/*      */       return;
/*      */     }
/*      */     
/*  741 */     if (this.listeners == null) {
/*  742 */       this.listeners = new ArrayList<BindingListener>();
/*      */     }
/*      */     
/*  745 */     this.listeners.add(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void removeBindingListener(BindingListener listener) {
/*  759 */     if (listener == null) {
/*      */       return;
/*      */     }
/*      */     
/*  763 */     if (this.listeners != null) {
/*  764 */       this.listeners.remove(listener);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final BindingListener[] getBindingListeners() {
/*  777 */     if (this.listeners == null) {
/*  778 */       return new BindingListener[0];
/*      */     }
/*      */     
/*  781 */     BindingListener[] ret = new BindingListener[this.listeners.size()];
/*  782 */     ret = this.listeners.toArray(ret);
/*  783 */     return ret;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ValueResult<TV> getSourceValueForTarget() {
/*      */     TV value;
/*  823 */     if (!this.targetProperty.isWriteable(this.targetObject)) {
/*  824 */       return new ValueResult<TV>(TARGET_UNWRITEABLE);
/*      */     }
/*      */     
/*  827 */     if (!this.sourceProperty.isReadable(this.sourceObject)) {
/*  828 */       if (this.sourceUnreadableValueSet) {
/*  829 */         return new ValueResult<TV>(this.sourceUnreadableValue);
/*      */       }
/*  831 */       return new ValueResult<TV>(SOURCE_UNREADABLE);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  837 */     SV rawValue = this.sourceProperty.getValue(this.sourceObject);
/*      */     
/*  839 */     if (rawValue == null) {
/*  840 */       value = this.sourceNullValue;
/*      */     }
/*      */     else {
/*      */       
/*  844 */       value = convertForward(rawValue);
/*      */     } 
/*      */     
/*  847 */     return new ValueResult<TV>(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final ValueResult<SV> getTargetValueForSource() {
/*  894 */     if (!this.sourceProperty.isWriteable(this.sourceObject)) {
/*  895 */       return new ValueResult<SV>(SOURCE_UNWRITEABLE);
/*      */     }
/*      */     
/*  898 */     if (!this.targetProperty.isReadable(this.targetObject)) {
/*  899 */       return new ValueResult<SV>(TARGET_UNREADABLE);
/*      */     }
/*      */     
/*  902 */     SV value = null;
/*  903 */     TV rawValue = this.targetProperty.getValue(this.targetObject);
/*      */     
/*  905 */     if (rawValue == null) {
/*  906 */       value = this.targetNullValue;
/*      */     } else {
/*      */       try {
/*  909 */         value = convertReverse(rawValue);
/*  910 */       } catch (ClassCastException cce) {
/*  911 */         throw cce;
/*  912 */       } catch (RuntimeException rte) {
/*  913 */         return new ValueResult<SV>(SyncFailure.conversionFailure(rte));
/*      */       } 
/*      */       
/*  916 */       if (this.validator != null) {
/*  917 */         Validator.Result vr = this.validator.validate(value);
/*  918 */         if (vr != null) {
/*  919 */           return new ValueResult<SV>(SyncFailure.validationFailure(vr));
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  924 */     return new ValueResult<SV>(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void bind() {
/*  943 */     throwIfManaged();
/*  944 */     bindUnmanaged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void bindUnmanaged() {
/*  957 */     throwIfBound();
/*      */     
/*  959 */     bindImpl();
/*      */     
/*  961 */     this.psl = new PSL();
/*  962 */     this.sourceProperty.addPropertyStateListener(this.sourceObject, this.psl);
/*  963 */     this.targetProperty.addPropertyStateListener(this.targetObject, this.psl);
/*      */     
/*  965 */     this.isBound = true;
/*      */     
/*  967 */     if (this.listeners != null) {
/*  968 */       for (BindingListener listener : this.listeners) {
/*  969 */         listener.bindingBecameBound(this);
/*      */       }
/*      */     }
/*      */     
/*  973 */     firePropertyChange("bound", Boolean.valueOf(false), Boolean.valueOf(true));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void unbind() {
/* 1001 */     throwIfManaged();
/* 1002 */     unbindUnmanaged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void unbindUnmanaged() {
/* 1015 */     throwIfUnbound();
/*      */     
/* 1017 */     this.sourceProperty.removePropertyStateListener(this.sourceObject, this.psl);
/* 1018 */     this.targetProperty.removePropertyStateListener(this.targetObject, this.psl);
/* 1019 */     this.psl = null;
/*      */     
/* 1021 */     unbindImpl();
/*      */     
/* 1023 */     this.isBound = false;
/*      */     
/* 1025 */     if (this.listeners != null) {
/* 1026 */       for (BindingListener listener : this.listeners) {
/* 1027 */         listener.bindingBecameUnbound(this);
/*      */       }
/*      */     }
/*      */     
/* 1031 */     firePropertyChange("bound", Boolean.valueOf(true), Boolean.valueOf(false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1053 */   public final boolean isBound() { return this.isBound; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1067 */   protected final void setManaged(boolean isManaged) { this.isManaged = isManaged; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1084 */   public final boolean isManaged() { return this.isManaged; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void notifySynced() {
/* 1093 */     if (this.listeners == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1097 */     for (BindingListener listener : this.listeners) {
/* 1098 */       listener.synced(this);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void notifySyncFailed(SyncFailure failure) {
/* 1110 */     if (this.listeners == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1114 */     for (BindingListener listener : this.listeners) {
/* 1115 */       listener.syncFailed(this, failure);
/*      */     }
/*      */   }
/*      */   
/*      */   private final SyncFailure notifyAndReturn(SyncFailure failure) {
/* 1120 */     if (failure == null) {
/* 1121 */       notifySynced();
/*      */     } else {
/* 1123 */       notifySyncFailed(failure);
/*      */     } 
/*      */     
/* 1126 */     return failure;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1143 */   public final SyncFailure refreshAndNotify() { return notifyAndReturn(refresh()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1157 */   protected final SyncFailure refreshAndNotifyUnmanaged() { return notifyAndReturn(refreshUnmanaged()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1173 */   public final SyncFailure saveAndNotify() { return notifyAndReturn(save()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1186 */   protected final SyncFailure saveAndNotifyUnmanaged() { return notifyAndReturn(saveUnmanaged()); }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SyncFailure refresh() {
/* 1206 */     throwIfManaged();
/* 1207 */     return refreshUnmanaged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SyncFailure refreshUnmanaged() {
/* 1222 */     ValueResult<TV> vr = getSourceValueForTarget();
/* 1223 */     if (vr.failed()) {
/* 1224 */       return vr.getFailure();
/*      */     }
/*      */     
/*      */     try {
/* 1228 */       this.ignoreChange = true;
/* 1229 */       this.targetProperty.setValue(this.targetObject, vr.getValue());
/*      */     } finally {
/* 1231 */       this.ignoreChange = false;
/*      */     } 
/*      */     
/* 1234 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SyncFailure save() {
/* 1253 */     throwIfManaged();
/* 1254 */     return saveUnmanaged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final SyncFailure saveUnmanaged() {
/* 1268 */     ValueResult<SV> vr = getTargetValueForSource();
/* 1269 */     if (vr.failed()) {
/* 1270 */       return vr.getFailure();
/*      */     }
/*      */     
/*      */     try {
/* 1274 */       this.ignoreChange = true;
/* 1275 */       this.sourceProperty.setValue(this.sourceObject, vr.getValue());
/*      */     } finally {
/* 1277 */       this.ignoreChange = false;
/*      */     } 
/*      */     
/* 1280 */     return null;
/*      */   }
/*      */   
/*      */   private final Class<?> noPrimitiveType(Class<?> klass) {
/* 1284 */     if (!klass.isPrimitive()) {
/* 1285 */       return klass;
/*      */     }
/*      */     
/* 1288 */     if (klass == byte.class)
/* 1289 */       return Byte.class; 
/* 1290 */     if (klass == short.class)
/* 1291 */       return Short.class; 
/* 1292 */     if (klass == int.class)
/* 1293 */       return Integer.class; 
/* 1294 */     if (klass == long.class)
/* 1295 */       return Long.class; 
/* 1296 */     if (klass == boolean.class)
/* 1297 */       return Boolean.class; 
/* 1298 */     if (klass == char.class)
/* 1299 */       return Character.class; 
/* 1300 */     if (klass == float.class)
/* 1301 */       return Float.class; 
/* 1302 */     if (klass == double.class) {
/* 1303 */       return Double.class;
/*      */     }
/*      */     
/* 1306 */     throw new AssertionError();
/*      */   }
/*      */   
/*      */   private final TV convertForward(SV value) {
/* 1310 */     if (this.converter == null) {
/* 1311 */       Class<?> targetType = noPrimitiveType(this.targetProperty.getWriteType(this.targetObject));
/* 1312 */       return (TV)targetType.cast(Converter.defaultConvert(value, targetType));
/*      */     } 
/*      */     
/* 1315 */     return this.converter.convertForward(value);
/*      */   }
/*      */   
/*      */   private final SV convertReverse(TV value) {
/* 1319 */     if (this.converter == null) {
/* 1320 */       Class<?> sourceType = noPrimitiveType(this.sourceProperty.getWriteType(this.sourceObject));
/* 1321 */       return (SV)sourceType.cast(Converter.defaultConvert(value, sourceType));
/*      */     } 
/*      */     
/* 1324 */     return this.converter.convertReverse(value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void throwIfManaged() {
/* 1336 */     if (isManaged()) {
/* 1337 */       throw new UnsupportedOperationException("Can not call this method on a managed binding");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void throwIfBound() {
/* 1349 */     if (isBound()) {
/* 1350 */       throw new IllegalStateException("Can not call this method on a bound binding");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void throwIfUnbound() {
/* 1362 */     if (!isBound()) {
/* 1363 */       throw new IllegalStateException("Can not call this method on an unbound binding");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1377 */   public String toString() { return getClass().getName() + " [" + paramString() + "]"; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1390 */   protected String paramString() { return "name=" + getName() + ", sourceObject=" + this.sourceObject + ", sourceProperty=" + this.sourceProperty + ", targetObject=" + this.targetObject + ", targetProperty=" + this.targetProperty + ", validator=" + this.validator + ", converter=" + this.converter + ", sourceNullValue=" + this.sourceNullValue + ", targetNullValue=" + this.targetNullValue + ", sourceUnreadableValueSet=" + this.sourceUnreadableValueSet + ", sourceUnreadableValue=" + this.sourceUnreadableValue + ", bound=" + this.isBound; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sourceChanged(PropertyStateEvent pse) {
/* 1405 */     if (this.listeners != null) {
/* 1406 */       for (BindingListener listener : this.listeners) {
/* 1407 */         listener.sourceChanged(this, pse);
/*      */       }
/*      */     }
/*      */     
/* 1411 */     sourceChangedImpl(pse);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void sourceChangedImpl(PropertyStateEvent pse) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void targetChanged(PropertyStateEvent pse) {
/* 1427 */     if (this.listeners != null) {
/* 1428 */       for (BindingListener listener : this.listeners) {
/* 1429 */         listener.targetChanged(this, pse);
/*      */       }
/*      */     }
/*      */     
/* 1433 */     targetChangedImpl(pse);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void targetChangedImpl(PropertyStateEvent pse) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addPropertyChangeListener(PropertyChangeListener listener) {
/* 1479 */     if (this.changeSupport == null) {
/* 1480 */       this.changeSupport = new PropertyChangeSupport(this);
/*      */     }
/*      */     
/* 1483 */     this.changeSupport.addPropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
/* 1518 */     if (this.changeSupport == null) {
/* 1519 */       this.changeSupport = new PropertyChangeSupport(this);
/*      */     }
/*      */     
/* 1522 */     this.changeSupport.addPropertyChangeListener(propertyName, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void removePropertyChangeListener(PropertyChangeListener listener) {
/* 1536 */     if (this.changeSupport == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1540 */     this.changeSupport.removePropertyChangeListener(listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
/* 1556 */     if (this.changeSupport == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1560 */     this.changeSupport.removePropertyChangeListener(propertyName, listener);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PropertyChangeListener[] getPropertyChangeListeners() {
/* 1572 */     if (this.changeSupport == null) {
/* 1573 */       return new PropertyChangeListener[0];
/*      */     }
/*      */     
/* 1576 */     return this.changeSupport.getPropertyChangeListeners();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
/* 1590 */     if (this.changeSupport == null) {
/* 1591 */       return new PropertyChangeListener[0];
/*      */     }
/*      */     
/* 1594 */     return this.changeSupport.getPropertyChangeListeners(propertyName);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected abstract void bindImpl();
/*      */ 
/*      */   
/*      */   protected abstract void unbindImpl();
/*      */ 
/*      */   
/*      */   protected final void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
/* 1606 */     if (this.changeSupport != null)
/* 1607 */       this.changeSupport.firePropertyChange(propertyName, oldValue, newValue); 
/*      */   }
/*      */   
/*      */   private class PSL
/*      */     implements PropertyStateListener {
/*      */     public void propertyStateChanged(PropertyStateEvent pse) {
/* 1613 */       if (Binding.this.ignoreChange) {
/*      */         return;
/*      */       }
/*      */       
/* 1617 */       if (pse.getSourceProperty() == Binding.this.sourceProperty && pse.getSourceObject() == Binding.this.sourceObject) {
/* 1618 */         Binding.this.sourceChanged(pse);
/*      */       } else {
/* 1620 */         Binding.this.targetChanged(pse);
/*      */       } 
/*      */     }
/*      */     
/*      */     private PSL() {}
/*      */   }
/*      */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/Binding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */