/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstFloatingPoint
/*    */   extends SimpleNode
/*    */ {
/*    */   private Number number;
/*    */   
/* 21 */   public AstFloatingPoint(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Number getFloatingPoint() {
/* 27 */     if (this.number == null) {
/*    */       try {
/* 29 */         this.number = new Double(this.image);
/* 30 */       } catch (ArithmeticException e0) {
/* 31 */         this.number = new BigDecimal(this.image);
/*    */       } 
/*    */     }
/* 34 */     return this.number;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 39 */   public Object getValue(EvaluationContext ctx) throws ELException { return getFloatingPoint(); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 44 */   public Class getType(EvaluationContext ctx) throws ELException { return getFloatingPoint().getClass(); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstFloatingPoint.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */