/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.jdesktop.beansbinding.ext.BeanAdapterFactory;
/*     */ import org.jdesktop.el.BeanELResolver;
/*     */ import org.jdesktop.el.CompositeELResolver;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELResolver;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.MapELResolver;
/*     */ import org.jdesktop.el.VariableMapper;
/*     */ import org.jdesktop.el.impl.lang.FunctionMapperImpl;
/*     */ import org.jdesktop.el.impl.lang.VariableMapperImpl;
/*     */ 
/*     */ class TempELContext extends ELContext {
/*     */   private final CompositeELResolver resolver;
/*     */   
/*     */   public TempELContext() {
/*  24 */     this.variableMapper = (VariableMapper)new VariableMapperImpl();
/*  25 */     this.functionMapper = (FunctionMapper)new FunctionMapperImpl();
/*     */ 
/*     */     
/*  28 */     this.resolver = new CompositeELResolver();
/*     */     
/*  30 */     this.resolver.add((ELResolver)new MapELResolver());
/*  31 */     this.resolver.add((ELResolver)new BeanDelegateELResolver());
/*     */   }
/*     */   private final VariableMapper variableMapper; private final FunctionMapper functionMapper;
/*     */   
/*  35 */   public ELResolver getELResolver() { return (ELResolver)this.resolver; }
/*     */ 
/*     */ 
/*     */   
/*  39 */   public FunctionMapper getFunctionMapper() { return this.functionMapper; }
/*     */ 
/*     */ 
/*     */   
/*  43 */   public VariableMapper getVariableMapper() { return this.variableMapper; }
/*     */   
/*     */   private class BeanDelegateELResolver extends BeanELResolver { private BeanDelegateELResolver() {}
/*     */     
/*     */     public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/*  48 */       Iterator<FeatureDescriptor> superDescriptors = super.getFeatureDescriptors(context, base);
/*     */       
/*  50 */       if (base != null) {
/*  51 */         List<PropertyDescriptor> pds = BeanAdapterFactory.getAdapterPropertyDescriptors(base.getClass());
/*  52 */         if (pds.size() > 0) {
/*  53 */           Map<String, FeatureDescriptor> fdMap = new HashMap<String, FeatureDescriptor>();
/*     */           
/*  55 */           while (superDescriptors.hasNext()) {
/*  56 */             FeatureDescriptor fd = superDescriptors.next();
/*  57 */             fdMap.put(fd.getName(), fd);
/*     */           } 
/*     */           
/*  60 */           for (PropertyDescriptor pd : pds) {
/*  61 */             if (pd.getPropertyType() != null) {
/*  62 */               pd.setValue("type", pd.getPropertyType());
/*  63 */               pd.setValue("resolvableAtDesignTime", Boolean.TRUE);
/*  64 */               fdMap.put(pd.getName(), pd);
/*     */             } 
/*     */           } 
/*     */           
/*  68 */           return fdMap.values().iterator();
/*     */         } 
/*     */       } 
/*     */       
/*  72 */       return superDescriptors;
/*     */     }
/*     */     
/*     */     private Object baseOrAdapter(Object base, Object property) {
/*  76 */       if (base != null && property instanceof String) {
/*  77 */         Object adapter = BeanAdapterFactory.getAdapter(base, (String)property);
/*  78 */         if (adapter != null) {
/*  79 */           return adapter;
/*     */         }
/*     */       } 
/*     */       
/*  83 */       return base;
/*     */     }
/*     */ 
/*     */     
/*  87 */     public void setValue(ELContext context, Object base, Object property, Object val) { super.setValue(context, baseOrAdapter(base, property), property, val); }
/*     */ 
/*     */ 
/*     */     
/*  91 */     public boolean isReadOnly(ELContext context, Object base, Object property) { return super.isReadOnly(context, baseOrAdapter(base, property), property); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  96 */     public Object getValue(ELContext context, Object base, Object property) { return super.getValue(context, baseOrAdapter(base, property), property); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     public Class<?> getType(ELContext context, Object base, Object property) { return super.getType(context, baseOrAdapter(base, property), property); } }
/*     */ 
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/TempELContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */