/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListELResolver
/*     */   extends ELResolver
/*     */ {
/*  43 */   public ListELResolver() { this.isReadOnly = false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   public ListELResolver(boolean isReadOnly) { this.isReadOnly = isReadOnly; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  92 */     if (context == null) {
/*  93 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  96 */     if (base != null && base instanceof List) {
/*  97 */       context.setPropertyResolved(true);
/*  98 */       List list = (List)base;
/*  99 */       int index = toInteger(property);
/* 100 */       if (index < 0 || index >= list.size()) {
/* 101 */         throw new PropertyNotFoundException();
/*     */       }
/* 103 */       return Object.class;
/*     */     } 
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/* 142 */     if (context == null) {
/* 143 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 146 */     if (base != null && base instanceof List) {
/* 147 */       context.setPropertyResolved(true);
/* 148 */       List list = (List)base;
/* 149 */       int index = toInteger(property);
/* 150 */       if (index < 0 || index >= list.size()) {
/* 151 */         return null;
/*     */       }
/* 153 */       return list.get(index);
/*     */     } 
/* 155 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object val) {
/* 210 */     if (context == null) {
/* 211 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 214 */     if (base != null && base instanceof List) {
/* 215 */       context.setPropertyResolved(true);
/* 216 */       List<Object> list = (List)base;
/* 217 */       int index = toInteger(property);
/* 218 */       if (this.isReadOnly) {
/* 219 */         throw new PropertyNotWritableException();
/*     */       }
/*     */       try {
/* 222 */         list.set(index, val);
/* 223 */       } catch (UnsupportedOperationException ex) {
/* 224 */         throw new PropertyNotWritableException();
/* 225 */       } catch (IndexOutOfBoundsException ex) {
/* 226 */         throw new PropertyNotFoundException();
/* 227 */       } catch (ClassCastException ex) {
/* 228 */         throw ex;
/* 229 */       } catch (NullPointerException ex) {
/* 230 */         throw ex;
/* 231 */       } catch (IllegalArgumentException ex) {
/* 232 */         throw ex;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/* 237 */   private static Class<?> theUnmodifiableListClass = Collections.unmodifiableList(new ArrayList()).getClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isReadOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 284 */     if (context == null) {
/* 285 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 288 */     if (base != null && base instanceof List) {
/* 289 */       context.setPropertyResolved(true);
/* 290 */       List list = (List)base;
/* 291 */       int index = toInteger(property);
/* 292 */       if (index < 0 || index >= list.size()) {
/* 293 */         throw new PropertyNotFoundException();
/*     */       }
/* 295 */       return (list.getClass() == theUnmodifiableListClass || this.isReadOnly);
/*     */     } 
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) { return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 335 */     if (base != null && base instanceof List) {
/* 336 */       return Integer.class;
/*     */     }
/* 338 */     return null;
/*     */   }
/*     */   
/*     */   private int toInteger(Object p) {
/* 342 */     if (p instanceof Integer) {
/* 343 */       return ((Integer)p).intValue();
/*     */     }
/* 345 */     if (p instanceof Character) {
/* 346 */       return ((Character)p).charValue();
/*     */     }
/* 348 */     if (p instanceof Boolean) {
/* 349 */       return ((Boolean)p).booleanValue() ? 1 : 0;
/*     */     }
/* 351 */     if (p instanceof Number) {
/* 352 */       return ((Number)p).intValue();
/*     */     }
/* 354 */     if (p instanceof String) {
/* 355 */       return Integer.parseInt((String)p);
/*     */     }
/* 357 */     throw new IllegalArgumentException();
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ListELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */