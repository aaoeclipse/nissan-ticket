/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ResourceBundleELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*  80 */     if (context == null) {
/*  81 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  84 */     if (base instanceof ResourceBundle) {
/*  85 */       context.setPropertyResolved(true);
/*  86 */       if (property != null) {
/*     */         try {
/*  88 */           return ((ResourceBundle)base).getObject(property.toString());
/*     */         }
/*  90 */         catch (MissingResourceException e) {
/*  91 */           return "???" + property + "???";
/*     */         } 
/*     */       }
/*     */     } 
/*  95 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/* 123 */     if (context == null) {
/* 124 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 127 */     if (base instanceof ResourceBundle) {
/* 128 */       context.setPropertyResolved(true);
/*     */     }
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object value) {
/* 153 */     if (context == null) {
/* 154 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 157 */     if (base instanceof ResourceBundle) {
/* 158 */       context.setPropertyResolved(true);
/* 159 */       throw new PropertyNotWritableException("ResourceBundles are immutable");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 182 */     if (context == null) {
/* 183 */       throw new NullPointerException();
/*     */     }
/* 185 */     if (base instanceof ResourceBundle) {
/* 186 */       context.setPropertyResolved(true);
/* 187 */       return true;
/*     */     } 
/* 189 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator getFeatureDescriptors(ELContext context, Object base) {
/* 230 */     if (base instanceof ResourceBundle) {
/* 231 */       ResourceBundle bundle = (ResourceBundle)base;
/* 232 */       List<FeatureDescriptor> features = new ArrayList();
/* 233 */       String key = null;
/* 234 */       FeatureDescriptor desc = null;
/* 235 */       for (Enumeration<String> e = bundle.getKeys(); e.hasMoreElements(); ) {
/* 236 */         key = e.nextElement();
/* 237 */         desc = new FeatureDescriptor();
/* 238 */         desc.setDisplayName(key);
/* 239 */         desc.setExpert(false);
/* 240 */         desc.setHidden(false);
/* 241 */         desc.setName(key);
/* 242 */         desc.setPreferred(true);
/* 243 */         desc.setValue("type", String.class);
/* 244 */         desc.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 245 */         features.add(desc);
/*     */       } 
/* 247 */       return features.iterator();
/*     */     } 
/* 249 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 270 */     if (base instanceof ResourceBundle) {
/* 271 */       return String.class;
/*     */     }
/* 273 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ResourceBundleELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */