/*     */ package org.jdesktop.swingbinding.impl;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.jdesktop.beansbinding.Binding;
/*     */ import org.jdesktop.beansbinding.PropertyStateEvent;
/*     */ import org.jdesktop.beansbinding.PropertyStateListener;
/*     */ import org.jdesktop.observablecollections.ObservableList;
/*     */ import org.jdesktop.observablecollections.ObservableListListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ListBindingManager
/*     */   implements ObservableListListener
/*     */ {
/*  26 */   private AbstractColumnBinding[] bindings = getColBindings();
/*     */   private ReusableBinding reusableBinding;
/*     */   
/*     */   private List<ColumnDescriptionManager> createManagers(AbstractColumnBinding[] bindings) {
/*  30 */     List<ColumnDescriptionManager> managers = new ArrayList<ColumnDescriptionManager>(bindings.length);
/*     */     
/*  32 */     for (AbstractColumnBinding binding : bindings) {
/*  33 */       managers.add(new ColumnDescriptionManager(binding));
/*     */     }
/*     */     
/*  36 */     return managers;
/*     */   }
/*     */   
/*     */   private List<?> elements;
/*     */   
/*     */   public void setElements(List<?> elements, boolean sendAllChanged) {
/*  42 */     if (this.elements != null) {
/*  43 */       if (this.elements instanceof ObservableList) {
/*  44 */         ((ObservableList)this.elements).removeObservableListListener(this);
/*     */       }
/*     */       
/*  47 */       if (this.managers != null) {
/*  48 */         for (ColumnDescriptionManager manager : this.managers) {
/*  49 */           manager.stopListening();
/*     */         }
/*     */       }
/*     */     } 
/*     */     
/*  54 */     this.managers = null;
/*  55 */     this.reusableBinding = null;
/*  56 */     this.elements = (elements == null) ? Collections.emptyList() : elements;
/*     */     
/*  58 */     boolean addListeners = false;
/*     */     
/*  60 */     if (elements instanceof ObservableList) {
/*  61 */       ((ObservableList)elements).addObservableListListener(this);
/*  62 */       addListeners = !((ObservableList)elements).supportsElementPropertyChanged();
/*  63 */     } else if (elements != null) {
/*  64 */       addListeners = true;
/*     */     } 
/*     */     
/*  67 */     if (this.bindings.length != 0) {
/*  68 */       this.reusableBinding = new ReusableBinding(this.bindings[0]);
/*     */     }
/*     */     
/*  71 */     if (addListeners) {
/*  72 */       this.managers = createManagers(getColBindings());
/*  73 */       for (ColumnDescriptionManager manager : this.managers) {
/*  74 */         manager.startListening();
/*     */       }
/*     */     } 
/*     */     
/*  78 */     if (sendAllChanged)
/*  79 */       allChanged(); 
/*     */   }
/*     */   
/*     */   private List<ColumnDescriptionManager> managers;
/*     */   
/*  84 */   public final Object getElement(int index) { return this.elements.get(index); }
/*     */ 
/*     */ 
/*     */   
/*  88 */   public final List<?> getElements() { return this.elements; }
/*     */ 
/*     */ 
/*     */   
/*  92 */   public final int size() { return (this.elements == null) ? 0 : this.elements.size(); }
/*     */ 
/*     */   
/*     */   public final Object valueAt(int row, int column) {
/*  96 */     if (this.managers != null)
/*     */     {
/*  98 */       for (ColumnDescriptionManager manager : this.managers) {
/*  99 */         manager.validateBinding(row);
/*     */       }
/*     */     }
/*     */     
/* 103 */     this.reusableBinding.setBaseAndSource(this.bindings[column], this.elements.get(row));
/* 104 */     Binding.ValueResult result = this.reusableBinding.getSourceValueForTarget();
/* 105 */     return result.failed() ? null : result.getValue();
/*     */   }
/*     */ 
/*     */   
/* 109 */   public final int columnCount() { return this.bindings.length; }
/*     */ 
/*     */   
/*     */   public final void listElementsAdded(ObservableList list, int index, int length) {
/* 113 */     if (length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 117 */     if (this.managers != null) {
/* 118 */       for (ColumnDescriptionManager manager : this.managers) {
/* 119 */         manager.add(index, length);
/*     */       }
/*     */     }
/*     */     
/* 123 */     added(index, length);
/*     */   }
/*     */   
/*     */   public final void listElementsRemoved(ObservableList list, int index, List elements) {
/* 127 */     if (elements.size() == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 131 */     if (this.managers != null) {
/* 132 */       for (ColumnDescriptionManager manager : this.managers) {
/* 133 */         manager.remove(index, elements.size());
/*     */       }
/*     */     }
/*     */     
/* 137 */     removed(index, elements.size());
/*     */   }
/*     */   
/*     */   public final void listElementReplaced(ObservableList list, int index, Object oldElement) {
/* 141 */     if (this.managers != null) {
/* 142 */       for (ColumnDescriptionManager manager : this.managers) {
/* 143 */         manager.replaced(index);
/*     */       }
/*     */     }
/*     */     
/* 147 */     changed(index);
/*     */   }
/*     */ 
/*     */   
/* 151 */   public final void listElementPropertyChanged(ObservableList list, int index) { changed(index); }
/*     */   
/*     */   protected abstract AbstractColumnBinding[] getColBindings();
/*     */   
/*     */   protected abstract void allChanged();
/*     */   
/*     */   protected abstract void valueChanged(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void added(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void removed(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract void changed(int paramInt);
/*     */   
/*     */   private final class ColumnDescriptionManager {
/*     */     private final AbstractColumnBinding columnBinding;
/*     */     private List<EntryWrapper> wrappers;
/*     */     
/* 169 */     ColumnDescriptionManager(AbstractColumnBinding columnBinding) { this.columnBinding = columnBinding; }
/*     */ 
/*     */     
/*     */     public void startListening() {
/* 173 */       int size = ListBindingManager.this.elements.size();
/* 174 */       this.wrappers = new ArrayList<EntryWrapper>(size);
/* 175 */       for (int i = 0; i < size; i++) {
/* 176 */         this.wrappers.add(null);
/*     */       }
/*     */     }
/*     */     
/*     */     public void stopListening() {
/* 181 */       for (EntryWrapper wrapper : this.wrappers) {
/* 182 */         if (wrapper != null) {
/* 183 */           wrapper.stopListening();
/*     */         }
/*     */       } 
/*     */       
/* 187 */       this.wrappers = null;
/*     */     }
/*     */     
/*     */     public void validateBinding(int row) {
/* 191 */       if (this.wrappers.get(row) == null) {
/* 192 */         EntryWrapper wrapper = new EntryWrapper(ListBindingManager.this.getElement(row));
/* 193 */         this.wrappers.set(row, wrapper);
/*     */       } 
/*     */     }
/*     */     
/*     */     void wrapperChanged(EntryWrapper wrapper) {
/* 198 */       int row = this.wrappers.indexOf(wrapper);
/* 199 */       ListBindingManager.this.valueChanged(row, this.columnBinding.getColumn());
/*     */     }
/*     */     
/*     */     private void add(int index, int length) {
/* 203 */       for (int i = 0; i < length; i++) {
/* 204 */         this.wrappers.add(index, null);
/*     */       }
/*     */     }
/*     */     
/*     */     private void remove(int index, int length) {
/* 209 */       while (length-- > 0) {
/* 210 */         EntryWrapper wrapper = this.wrappers.remove(index);
/* 211 */         if (wrapper != null) {
/* 212 */           wrapper.stopListening();
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/*     */     private void replaced(int index) {
/* 218 */       EntryWrapper wrapper = this.wrappers.get(index);
/* 219 */       if (wrapper != null) {
/* 220 */         wrapper.stopListening();
/*     */       }
/* 222 */       this.wrappers.set(index, null);
/*     */     }
/*     */     
/*     */     private final class EntryWrapper implements PropertyStateListener {
/*     */       private Object source;
/*     */       
/*     */       EntryWrapper(Object source) {
/* 229 */         this.source = source;
/* 230 */         ListBindingManager.ColumnDescriptionManager.this.columnBinding.getSourceProperty().addPropertyStateListener(source, this);
/*     */       }
/*     */       
/*     */       public void stopListening() {
/* 234 */         ListBindingManager.ColumnDescriptionManager.this.columnBinding.getSourceProperty().removePropertyStateListener(this.source, this);
/* 235 */         this.source = null;
/*     */       }
/*     */       
/*     */       public void propertyStateChanged(PropertyStateEvent pse) {
/* 239 */         if (pse.getValueChanged())
/* 240 */           ListBindingManager.ColumnDescriptionManager.this.wrapperChanged(this); 
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private final class ReusableBinding
/*     */     extends Binding
/*     */   {
/* 248 */     public ReusableBinding(AbstractColumnBinding base) { super(null, base.getSourceProperty(), null, base.getTargetProperty(), null); }
/*     */ 
/*     */     
/*     */     public void setBaseAndSource(AbstractColumnBinding base, Object source) {
/* 252 */       setSourceProperty(base.getSourceProperty());
/* 253 */       setTargetProperty(base.getTargetProperty());
/* 254 */       setSourceObject(source);
/* 255 */       setConverter(base.getConverter());
/* 256 */       setSourceNullValue(base.getSourceNullValue());
/* 257 */       if (base.isSourceUnreadableValueSet()) {
/* 258 */         setSourceUnreadableValue(base.getSourceUnreadableValue());
/*     */       } else {
/* 260 */         unsetSourceUnreadableValue();
/*     */       } 
/*     */     }
/*     */     
/*     */     public final void bindImpl() {}
/*     */     
/*     */     public final void unbindImpl() {}
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/impl/ListBindingManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */