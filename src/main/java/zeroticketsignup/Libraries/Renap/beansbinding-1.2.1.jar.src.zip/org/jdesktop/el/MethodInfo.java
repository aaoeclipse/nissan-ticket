/*    */ package org.jdesktop.el;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MethodInfo
/*    */ {
/*    */   private String name;
/*    */   private Class<?> returnType;
/*    */   private Class<?>[] paramTypes;
/*    */   
/*    */   public MethodInfo(String name, Class<?> returnType, Class<?>[] paramTypes) {
/* 25 */     this.name = name;
/* 26 */     this.returnType = returnType;
/* 27 */     this.paramTypes = paramTypes;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 36 */   public String getName() { return this.name; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public Class<?> getReturnType() { return this.returnType; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 54 */   public Class<?>[] getParamTypes() { return this.paramTypes; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/MethodInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */