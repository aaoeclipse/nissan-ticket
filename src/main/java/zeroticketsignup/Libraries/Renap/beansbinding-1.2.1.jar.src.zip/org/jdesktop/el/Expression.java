/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Expression
/*     */   implements Serializable
/*     */ {
/*     */   public abstract String getExpressionString();
/*     */   
/*     */   public abstract boolean equals(Object paramObject);
/*     */   
/*     */   public abstract int hashCode();
/*     */   
/*     */   public abstract boolean isLiteralText();
/*     */   
/*     */   public static final class Result
/*     */   {
/*     */     private final Type type;
/*     */     private final Object result;
/*     */     private final List<Expression.ResolvedProperty> resolvedProperties;
/*     */     
/*     */     public enum Type
/*     */     {
/* 115 */       UNRESOLVABLE,
/* 116 */       VALUE;
/*     */     }
/*     */     
/*     */     public Result(Type type, Object result, List<Expression.ResolvedProperty> resolvedProperties) {
/* 120 */       this.type = type;
/* 121 */       this.result = result;
/* 122 */       this.resolvedProperties = resolvedProperties;
/* 123 */       if (type == null || resolvedProperties == null) {
/* 124 */         throw new NullPointerException("Type, result and resolvedProperties must be non-null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 130 */     public Type getType() { return this.type; }
/*     */ 
/*     */ 
/*     */     
/* 134 */     public Object getResult() { return this.result; }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 139 */     public List<Expression.ResolvedProperty> getResolvedProperties() { return this.resolvedProperties; }
/*     */   }
/*     */   
/*     */   public static final class ResolvedProperty
/*     */   {
/*     */     private final Object source;
/*     */     private final Object property;
/*     */     
/*     */     public ResolvedProperty(Object source, Object property) {
/* 148 */       this.source = source;
/* 149 */       this.property = property;
/* 150 */       if (source == null || property == null) {
/* 151 */         throw new IllegalArgumentException("Source and property must be non-null");
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 157 */     public Object getSource() { return this.source; }
/*     */ 
/*     */ 
/*     */     
/* 161 */     public Object getProperty() { return this.property; }
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 165 */       if (o == this) {
/* 166 */         return true;
/*     */       }
/* 168 */       if (o instanceof ResolvedProperty) {
/* 169 */         ResolvedProperty orp = (ResolvedProperty)o;
/* 170 */         return (orp.source == this.source && ((orp.property == null && this.property == null) || (orp.property != null && orp.property.equals(this.property))));
/*     */       } 
/*     */ 
/*     */       
/* 174 */       return false;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 178 */       int hash = 17;
/* 179 */       hash = 37 * hash + this.source.hashCode();
/* 180 */       hash = 37 * hash + this.property.hashCode();
/* 181 */       return hash;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/Expression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */