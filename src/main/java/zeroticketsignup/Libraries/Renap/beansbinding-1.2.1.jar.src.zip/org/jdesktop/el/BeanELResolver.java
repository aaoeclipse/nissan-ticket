/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   private boolean isReadOnly;
/*     */   private static final int SIZE = 2000;
/*  58 */   private static final Map<Class, BeanProperties> properties = (Map)new ConcurrentHashMap<Class<?>, BeanProperties>(2000);
/*     */   
/*  60 */   private static final Map<Class, BeanProperties> properties2 = (Map)new ConcurrentHashMap<Class<?>, BeanProperties>(2000);
/*     */ 
/*     */   
/*     */   protected static final class BeanProperty
/*     */   {
/*     */     private Method readMethod;
/*     */     
/*     */     private Method writeMethod;
/*     */     
/*     */     private Class baseClass;
/*     */     
/*     */     private PropertyDescriptor descriptor;
/*     */ 
/*     */     
/*     */     public BeanProperty(Class<?> baseClass, PropertyDescriptor descriptor) {
/*  75 */       this.baseClass = baseClass;
/*  76 */       this.descriptor = descriptor;
/*     */     }
/*     */ 
/*     */     
/*  80 */     public Class getPropertyType() { return this.descriptor.getPropertyType(); }
/*     */ 
/*     */ 
/*     */     
/*  84 */     public boolean isReadOnly() { return (getWriteMethod() == null); }
/*     */ 
/*     */     
/*     */     public Method getReadMethod() {
/*  88 */       if (this.readMethod == null) {
/*  89 */         this.readMethod = BeanELResolver.getMethod(this.baseClass, this.descriptor.getReadMethod());
/*     */       }
/*  91 */       return this.readMethod;
/*     */     }
/*     */     
/*     */     public Method getWriteMethod() {
/*  95 */       if (this.writeMethod == null) {
/*  96 */         this.writeMethod = BeanELResolver.getMethod(this.baseClass, this.descriptor.getWriteMethod());
/*     */       }
/*  98 */       return this.writeMethod;
/*     */     }
/*     */   }
/*     */   
/*     */   protected static final class BeanProperties
/*     */   {
/*     */     private final Class baseClass;
/*     */     private final Map<String, BeanELResolver.BeanProperty> propertyMap;
/*     */     
/*     */     public BeanProperties(Class<?> baseClass) {
/* 108 */       this.propertyMap = new HashMap<String, BeanELResolver.BeanProperty>();
/*     */ 
/*     */ 
/*     */       
/* 112 */       this.baseClass = baseClass;
/*     */       
/*     */       try {
/* 115 */         BeanInfo info = Introspector.getBeanInfo(baseClass);
/* 116 */         descriptors = info.getPropertyDescriptors();
/* 117 */       } catch (IntrospectionException ie) {
/* 118 */         throw new ELException(ie);
/*     */       } 
/* 120 */       for (PropertyDescriptor pd : descriptors) {
/* 121 */         this.propertyMap.put(pd.getName(), new BeanELResolver.BeanProperty(baseClass, pd));
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 127 */     public BeanELResolver.BeanProperty getBeanProperty(String property) { return this.propertyMap.get(property); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 135 */   public BeanELResolver() { this.isReadOnly = false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public BeanELResolver(boolean isReadOnly) { this.isReadOnly = isReadOnly; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/* 185 */     if (context == null) {
/* 186 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 189 */     if (base == null || property == null) {
/* 190 */       return null;
/*     */     }
/*     */     
/* 193 */     BeanProperty bp = getBeanProperty(context, base, property);
/* 194 */     context.setPropertyResolved(true);
/* 195 */     return bp.getPropertyType();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/*     */     Object value;
/* 235 */     if (context == null) {
/* 236 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 239 */     if (base == null || property == null) {
/* 240 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 244 */     BeanProperty bp = getBeanProperty(context, base, property); Method method;
/* 245 */     if (bp == null || (method = bp.getReadMethod()) == null) {
/* 246 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 251 */       value = method.invoke(base, new Object[0]);
/* 252 */       context.setPropertyResolved(true);
/* 253 */     } catch (ELException ex) {
/* 254 */       throw ex;
/* 255 */     } catch (InvocationTargetException ite) {
/* 256 */       throw new ELException(ite.getCause());
/* 257 */     } catch (Exception ex) {
/* 258 */       throw new ELException(ex);
/*     */     } 
/* 260 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object val) {
/* 304 */     if (context == null) {
/* 305 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 308 */     if (base == null || property == null) {
/*     */       return;
/*     */     }
/*     */     
/* 312 */     if (this.isReadOnly) {
/* 313 */       throw new PropertyNotWritableException(ELUtil.getExceptionMessageString(context, "resolverNotwritable", new Object[] { base.getClass().getName() }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 319 */     BeanProperty bp = getBeanProperty(context, base, property);
/* 320 */     Method method = bp.getWriteMethod();
/* 321 */     if (method == null) {
/* 322 */       throw new PropertyNotWritableException(ELUtil.getExceptionMessageString(context, "propertyNotWritable", new Object[] { base.getClass().getName(), property.toString() }));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 330 */       method.invoke(base, new Object[] { val });
/* 331 */       context.setPropertyResolved(true);
/* 332 */     } catch (ELException ex) {
/* 333 */       throw ex;
/* 334 */     } catch (InvocationTargetException ite) {
/* 335 */       throw new ELException(ite.getCause());
/* 336 */     } catch (Exception ex) {
/* 337 */       if (null == val) {
/* 338 */         val = "null";
/*     */       }
/* 340 */       String message = ELUtil.getExceptionMessageString(context, "setPropertyFailed", new Object[] { property.toString(), base.getClass().getName(), val });
/*     */ 
/*     */ 
/*     */       
/* 344 */       throw new ELException(message, ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 389 */     if (context == null) {
/* 390 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 393 */     if (base == null || property == null) {
/* 394 */       return false;
/*     */     }
/*     */     
/* 397 */     context.setPropertyResolved(true);
/* 398 */     if (this.isReadOnly) {
/* 399 */       return true;
/*     */     }
/*     */     
/* 402 */     BeanProperty bp = getBeanProperty(context, base, property);
/* 403 */     return bp.isReadOnly();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 436 */     if (base == null) {
/* 437 */       return null;
/*     */     }
/*     */     
/* 440 */     BeanInfo info = null;
/*     */     try {
/* 442 */       info = Introspector.getBeanInfo(base.getClass());
/* 443 */     } catch (Exception ex) {}
/*     */     
/* 445 */     if (info == null) {
/* 446 */       return null;
/*     */     }
/* 448 */     ArrayList<FeatureDescriptor> list = new ArrayList<FeatureDescriptor>((info.getPropertyDescriptors()).length);
/*     */     
/* 450 */     for (PropertyDescriptor pd : info.getPropertyDescriptors()) {
/* 451 */       if (pd.getPropertyType() != null) {
/* 452 */         pd.setValue("type", pd.getPropertyType());
/* 453 */         pd.setValue("resolvableAtDesignTime", Boolean.TRUE);
/*     */       } 
/* 455 */       list.add(pd);
/*     */     } 
/* 457 */     return list.iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 476 */     if (base == null) {
/* 477 */       return null;
/*     */     }
/*     */     
/* 480 */     return Object.class;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Method getMethod(Class cl, Method method) {
/* 493 */     if (Modifier.isPublic(cl.getModifiers())) {
/* 494 */       return method;
/*     */     }
/* 496 */     Class[] interfaces = cl.getInterfaces();
/* 497 */     for (int i = 0; i < interfaces.length; i++) {
/* 498 */       Class<?> c = interfaces[i];
/* 499 */       Method m = null;
/*     */       try {
/* 501 */         m = c.getMethod(method.getName(), method.getParameterTypes());
/* 502 */         c = m.getDeclaringClass();
/* 503 */         if ((m = getMethod(c, m)) != null)
/* 504 */           return m; 
/* 505 */       } catch (NoSuchMethodException ex) {}
/*     */     } 
/*     */     
/* 508 */     Class<?> c = cl.getSuperclass();
/* 509 */     if (c != null) {
/* 510 */       Method m = null;
/*     */       try {
/* 512 */         m = c.getMethod(method.getName(), method.getParameterTypes());
/* 513 */         c = m.getDeclaringClass();
/* 514 */         if ((m = getMethod(c, m)) != null)
/* 515 */           return m; 
/* 516 */       } catch (NoSuchMethodException ex) {}
/*     */     } 
/*     */     
/* 519 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BeanProperty getBeanProperty(ELContext context, Object base, Object prop) {
/* 526 */     String property = prop.toString();
/* 527 */     Class<?> baseClass = base.getClass();
/* 528 */     BeanProperties bps = properties.get(baseClass);
/* 529 */     if (bps == null && (bps = properties2.get(baseClass)) == null) {
/* 530 */       if (properties.size() > 2000) {
/*     */         
/* 532 */         properties2.clear();
/* 533 */         properties2.putAll(properties);
/* 534 */         properties.clear();
/*     */       } 
/* 536 */       bps = new BeanProperties(baseClass);
/* 537 */       properties.put(baseClass, bps);
/*     */     } 
/* 539 */     return bps.getBeanProperty(property);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/BeanELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */