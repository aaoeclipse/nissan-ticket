/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ValueExpression
/*     */   extends Expression
/*     */ {
/*     */   private Object source;
/*     */   
/*  67 */   public void setSource(Object source) { this.source = source; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  76 */   public Object getSource() { return this.source; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getValue(ELContext paramELContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Expression.Result getResult(ELContext context, boolean trackResolvedObjects) throws PropertyNotFoundException, ELException {
/* 103 */     Object value = getValue(context);
/* 104 */     List<Expression.ResolvedProperty> resolved = Collections.emptyList();
/* 105 */     return new Expression.Result(Expression.Result.Type.VALUE, value, resolved);
/*     */   }
/*     */   
/*     */   public abstract void setValue(ELContext paramELContext, Object paramObject);
/*     */   
/*     */   public abstract boolean isReadOnly(ELContext paramELContext);
/*     */   
/*     */   public abstract Class<?> getType(ELContext paramELContext);
/*     */   
/*     */   public abstract Class<?> getExpectedType();
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ValueExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */