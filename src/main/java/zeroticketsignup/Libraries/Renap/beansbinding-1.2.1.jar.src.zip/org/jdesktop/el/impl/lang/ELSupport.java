/*     */ package org.jdesktop.el.impl.lang;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.beans.PropertyEditorManager;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.PropertyNotFoundException;
/*     */ import org.jdesktop.el.impl.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ELSupport
/*     */ {
/*  26 */   private static final ELSupport REF = new ELSupport();
/*     */   
/*  28 */   private static final Long ZERO = new Long(0L);
/*     */ 
/*     */   
/*     */   public static final void throwUnhandled(Object base, Object property) throws ELException {
/*  32 */     if (base == null) {
/*  33 */       throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled.null", property));
/*     */     }
/*     */     
/*  36 */     throw new PropertyNotFoundException(MessageFactory.get("error.resolver.unhandled", base.getClass(), property));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int compare(Object obj0, Object obj1) throws ELException {
/*  49 */     if (obj0 == obj1 || equals(obj0, obj1)) {
/*  50 */       return 0;
/*     */     }
/*  52 */     if (isBigDecimalOp(obj0, obj1)) {
/*  53 */       BigDecimal bd0 = (BigDecimal)coerceToNumber(obj0, BigDecimal.class);
/*  54 */       BigDecimal bd1 = (BigDecimal)coerceToNumber(obj1, BigDecimal.class);
/*  55 */       return bd0.compareTo(bd1);
/*     */     } 
/*  57 */     if (isDoubleOp(obj0, obj1)) {
/*  58 */       Double d0 = (Double)coerceToNumber(obj0, Double.class);
/*  59 */       Double d1 = (Double)coerceToNumber(obj1, Double.class);
/*  60 */       return d0.compareTo(d1);
/*     */     } 
/*  62 */     if (isBigIntegerOp(obj0, obj1)) {
/*  63 */       BigInteger bi0 = (BigInteger)coerceToNumber(obj0, BigInteger.class);
/*  64 */       BigInteger bi1 = (BigInteger)coerceToNumber(obj1, BigInteger.class);
/*  65 */       return bi0.compareTo(bi1);
/*     */     } 
/*  67 */     if (isLongOp(obj0, obj1)) {
/*  68 */       Long l0 = (Long)coerceToNumber(obj0, Long.class);
/*  69 */       Long l1 = (Long)coerceToNumber(obj1, Long.class);
/*  70 */       return l0.compareTo(l1);
/*     */     } 
/*  72 */     if (obj0 instanceof String || obj1 instanceof String) {
/*  73 */       return coerceToString(obj0).compareTo(coerceToString(obj1));
/*     */     }
/*  75 */     if (obj0 instanceof Comparable) {
/*  76 */       return (obj1 != null) ? ((Comparable<Object>)obj0).compareTo(obj1) : 1;
/*     */     }
/*  78 */     if (obj1 instanceof Comparable) {
/*  79 */       return (obj0 != null) ? -((Comparable)obj1).compareTo((T)obj0) : -1;
/*     */     }
/*  81 */     throw new ELException(MessageFactory.get("error.compare", obj0, obj1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean equals(Object obj0, Object obj1) throws ELException {
/*  92 */     if (obj0 == obj1) {
/*  93 */       return true;
/*     */     }
/*  95 */     if (obj0 == null || obj1 == null) {
/*  96 */       return false;
/*     */     }
/*  98 */     if (obj0 instanceof Boolean || obj1 instanceof Boolean) {
/*  99 */       return coerceToBoolean(obj0).equals(coerceToBoolean(obj1));
/*     */     }
/* 101 */     if (obj0.getClass().isEnum()) {
/* 102 */       return obj0.equals(coerceToEnum(obj1, obj0.getClass()));
/*     */     }
/* 104 */     if (obj1.getClass().isEnum()) {
/* 105 */       return obj1.equals(coerceToEnum(obj0, obj1.getClass()));
/*     */     }
/* 107 */     if (obj0 instanceof String || obj1 instanceof String) {
/* 108 */       return coerceToString(obj0).equals(coerceToString(obj1));
/*     */     }
/* 110 */     if (isBigDecimalOp(obj0, obj1)) {
/* 111 */       BigDecimal bd0 = (BigDecimal)coerceToNumber(obj0, BigDecimal.class);
/* 112 */       BigDecimal bd1 = (BigDecimal)coerceToNumber(obj1, BigDecimal.class);
/* 113 */       return bd0.equals(bd1);
/*     */     } 
/* 115 */     if (isDoubleOp(obj0, obj1)) {
/* 116 */       Double d0 = (Double)coerceToNumber(obj0, Double.class);
/* 117 */       Double d1 = (Double)coerceToNumber(obj1, Double.class);
/* 118 */       return d0.equals(d1);
/*     */     } 
/* 120 */     if (isBigIntegerOp(obj0, obj1)) {
/* 121 */       BigInteger bi0 = (BigInteger)coerceToNumber(obj0, BigInteger.class);
/* 122 */       BigInteger bi1 = (BigInteger)coerceToNumber(obj1, BigInteger.class);
/* 123 */       return bi0.equals(bi1);
/*     */     } 
/* 125 */     if (isLongOp(obj0, obj1)) {
/* 126 */       Long l0 = (Long)coerceToNumber(obj0, Long.class);
/* 127 */       Long l1 = (Long)coerceToNumber(obj1, Long.class);
/* 128 */       return l0.equals(l1);
/*     */     } 
/* 130 */     return obj0.equals(obj1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Boolean coerceToBoolean(Object obj) throws IllegalArgumentException {
/* 140 */     if (obj == null || "".equals(obj)) {
/* 141 */       return Boolean.FALSE;
/*     */     }
/* 143 */     if (obj instanceof Boolean || obj.getClass() == boolean.class) {
/* 144 */       return (Boolean)obj;
/*     */     }
/* 146 */     if (obj instanceof String) {
/* 147 */       return Boolean.valueOf((String)obj);
/*     */     }
/*     */     
/* 150 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", obj, obj.getClass(), Boolean.class));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Enum coerceToEnum(Object obj, Class<Enum> type) throws IllegalArgumentException {
/* 156 */     if (obj == null || "".equals(obj)) {
/* 157 */       return null;
/*     */     }
/* 159 */     if (type.isInstance(obj)) {
/* 160 */       return (Enum)obj;
/*     */     }
/* 162 */     if (obj instanceof String) {
/* 163 */       return Enum.valueOf(type, (String)obj);
/*     */     }
/*     */     
/* 166 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", obj, obj.getClass(), type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Character coerceToCharacter(Object obj) throws IllegalArgumentException {
/* 172 */     if (obj == null || "".equals(obj)) {
/* 173 */       return new Character(false);
/*     */     }
/* 175 */     if (obj instanceof String) {
/* 176 */       return new Character(((String)obj).charAt(0));
/*     */     }
/* 178 */     if (ELArithmetic.isNumber(obj)) {
/* 179 */       return new Character((char)((Number)obj).shortValue());
/*     */     }
/* 181 */     Class<?> objType = obj.getClass();
/* 182 */     if (obj instanceof Character || objType == char.class) {
/* 183 */       return (Character)obj;
/*     */     }
/*     */     
/* 186 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", obj, objType, Character.class));
/*     */   }
/*     */ 
/*     */   
/*     */   public static final Number coerceToNumber(Object obj) {
/* 191 */     if (obj == null)
/* 192 */       return ZERO; 
/* 193 */     if (obj instanceof Number) {
/* 194 */       return (Number)obj;
/*     */     }
/* 196 */     String str = coerceToString(obj);
/* 197 */     if (isStringFloat(str)) {
/* 198 */       return toFloat(str);
/*     */     }
/* 200 */     return toNumber(str);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final Number coerceToNumber(Number number, Class<long> type) throws IllegalArgumentException {
/* 207 */     if (long.class == type || Long.class.equals(type)) {
/* 208 */       return new Long(number.longValue());
/*     */     }
/* 210 */     if (double.class == type || Double.class.equals(type)) {
/* 211 */       return new Double(number.doubleValue());
/*     */     }
/* 213 */     if (int.class == type || Integer.class.equals(type)) {
/* 214 */       return new Integer(number.intValue());
/*     */     }
/* 216 */     if (BigInteger.class.equals(type)) {
/* 217 */       if (number instanceof BigDecimal) {
/* 218 */         return ((BigDecimal)number).toBigInteger();
/*     */       }
/* 220 */       return BigInteger.valueOf(number.longValue());
/*     */     } 
/* 222 */     if (BigDecimal.class.equals(type)) {
/* 223 */       if (number instanceof BigInteger) {
/* 224 */         return new BigDecimal((BigInteger)number);
/*     */       }
/*     */       
/* 227 */       return new BigDecimal(number.doubleValue());
/*     */     } 
/* 229 */     if (byte.class == type || Byte.class.equals(type)) {
/* 230 */       return new Byte(number.byteValue());
/*     */     }
/* 232 */     if (short.class == type || Short.class.equals(type)) {
/* 233 */       return new Short(number.shortValue());
/*     */     }
/* 235 */     if (float.class == type || Float.class.equals(type)) {
/* 236 */       return new Float(number.floatValue());
/*     */     }
/*     */     
/* 239 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", number, number.getClass(), type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Number coerceToNumber(Object obj, Class type) throws IllegalArgumentException {
/* 245 */     if (obj == null || "".equals(obj)) {
/* 246 */       return coerceToNumber(ZERO, type);
/*     */     }
/* 248 */     if (obj instanceof String) {
/* 249 */       return coerceToNumber((String)obj, type);
/*     */     }
/* 251 */     if (ELArithmetic.isNumber(obj)) {
/* 252 */       return coerceToNumber((Number)obj, type);
/*     */     }
/*     */     
/* 255 */     Class<?> objType = obj.getClass();
/* 256 */     if (Character.class.equals(objType) || char.class == objType) {
/* 257 */       return coerceToNumber(new Short((short)((Character)obj).charValue()), type);
/*     */     }
/*     */ 
/*     */     
/* 261 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", obj, objType, type));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected static final Number coerceToNumber(String val, Class<long> type) throws IllegalArgumentException {
/* 267 */     if (long.class == type || Long.class.equals(type)) {
/* 268 */       return Long.valueOf(val);
/*     */     }
/* 270 */     if (int.class == type || Integer.class.equals(type)) {
/* 271 */       return Integer.valueOf(val);
/*     */     }
/* 273 */     if (double.class == type || Double.class.equals(type)) {
/* 274 */       return Double.valueOf(val);
/*     */     }
/* 276 */     if (BigInteger.class.equals(type)) {
/* 277 */       return new BigInteger(val);
/*     */     }
/* 279 */     if (BigDecimal.class.equals(type)) {
/* 280 */       return new BigDecimal(val);
/*     */     }
/* 282 */     if (byte.class == type || Byte.class.equals(type)) {
/* 283 */       return Byte.valueOf(val);
/*     */     }
/* 285 */     if (short.class == type || Short.class.equals(type)) {
/* 286 */       return Short.valueOf(val);
/*     */     }
/* 288 */     if (float.class == type || Float.class.equals(type)) {
/* 289 */       return Float.valueOf(val);
/*     */     }
/*     */     
/* 292 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", val, String.class, type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String coerceToString(Object obj) {
/* 301 */     if (obj == null)
/* 302 */       return ""; 
/* 303 */     if (obj instanceof String)
/* 304 */       return (String)obj; 
/* 305 */     if (obj instanceof Enum) {
/* 306 */       return ((Enum)obj).name();
/*     */     }
/* 308 */     return obj.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static final Object coerceToType(Object obj, Class<char> type) throws IllegalArgumentException {
/* 314 */     if (type == null || Object.class.equals(type)) {
/* 315 */       return obj;
/*     */     }
/* 317 */     if (String.class.equals(type)) {
/* 318 */       return coerceToString(obj);
/*     */     }
/* 320 */     if (ELArithmetic.isNumberType(type)) {
/* 321 */       return coerceToNumber(obj, type);
/*     */     }
/* 323 */     if (Character.class.equals(type) || char.class == type) {
/* 324 */       return coerceToCharacter(obj);
/*     */     }
/* 326 */     if (Boolean.class.equals(type) || boolean.class == type) {
/* 327 */       return coerceToBoolean(obj);
/*     */     }
/* 329 */     if (type.isEnum()) {
/* 330 */       return coerceToEnum(obj, type);
/*     */     }
/* 332 */     if (obj != null && type.isAssignableFrom(obj.getClass())) {
/* 333 */       return obj;
/*     */     }
/*     */ 
/*     */     
/* 337 */     if (obj == null)
/* 338 */       return null; 
/* 339 */     if (obj instanceof String) {
/* 340 */       if ("".equals(obj))
/* 341 */         return null; 
/* 342 */       PropertyEditor editor = PropertyEditorManager.findEditor(type);
/* 343 */       if (editor != null) {
/* 344 */         editor.setAsText((String)obj);
/* 345 */         return editor.getValue();
/*     */       } 
/*     */     } 
/* 348 */     throw new IllegalArgumentException(MessageFactory.get("error.convert", obj, obj.getClass(), type));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean containsNulls(Object[] obj) {
/* 357 */     for (int i = 0; i < obj.length; i++) {
/* 358 */       if (obj[0] == null) {
/* 359 */         return true;
/*     */       }
/*     */     } 
/* 362 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 367 */   public static final boolean isBigDecimalOp(Object obj0, Object obj1) { return (obj0 instanceof BigDecimal || obj1 instanceof BigDecimal); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 372 */   public static final boolean isBigIntegerOp(Object obj0, Object obj1) { return (obj0 instanceof BigInteger || obj1 instanceof BigInteger); }
/*     */ 
/*     */ 
/*     */   
/* 376 */   public static final boolean isDoubleOp(Object obj0, Object obj1) { return (obj0 instanceof Double || obj1 instanceof Double || obj0 instanceof Float || obj1 instanceof Float || (obj0 != null && (double.class == obj0.getClass() || float.class == obj0.getClass())) || (obj1 != null && (double.class == obj1.getClass() || float.class == obj1.getClass()))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 387 */   public static final boolean isDoubleStringOp(Object obj0, Object obj1) { return (isDoubleOp(obj0, obj1) || (obj0 instanceof String && isStringFloat((String)obj0)) || (obj1 instanceof String && isStringFloat((String)obj1))); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 392 */   public static final boolean isLongOp(Object obj0, Object obj1) { return (obj0 instanceof Long || obj1 instanceof Long || obj0 instanceof Integer || obj1 instanceof Integer || obj0 instanceof Character || obj1 instanceof Character || obj0 instanceof Short || obj1 instanceof Short || obj0 instanceof Byte || obj1 instanceof Byte || (obj0 != null && (long.class == obj0.getClass() || int.class == obj0.getClass() || char.class == obj0.getClass() || short.class == obj0.getClass() || byte.class == obj0.getClass())) || (obj0 != null && (long.class == obj0.getClass() || int.class == obj0.getClass() || char.class == obj0.getClass() || short.class == obj0.getClass() || byte.class == obj0.getClass()))); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean isStringFloat(String str) {
/* 415 */     int len = str.length();
/* 416 */     if (len > 1) {
/* 417 */       char c = Character.MIN_VALUE;
/* 418 */       for (int i = 0; i < len; i++) {
/* 419 */         switch (c = str.charAt(i)) {
/*     */           case 'E':
/* 421 */             return true;
/*     */           case 'e':
/* 423 */             return true;
/*     */           case '.':
/* 425 */             return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 429 */     return false;
/*     */   }
/*     */   
/*     */   public static final Number toFloat(String value) {
/*     */     try {
/* 434 */       if (Double.parseDouble(value) > Double.MAX_VALUE) {
/* 435 */         return new BigDecimal(value);
/*     */       }
/* 437 */       return new Double(value);
/*     */     }
/* 439 */     catch (NumberFormatException e0) {
/* 440 */       return new BigDecimal(value);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static final Number toNumber(String value) {
/*     */     try {
/* 446 */       return new Integer(Integer.parseInt(value));
/* 447 */     } catch (NumberFormatException e0) {
/*     */       try {
/* 449 */         return new Long(Long.parseLong(value));
/* 450 */       } catch (NumberFormatException e1) {
/* 451 */         return new BigInteger(value);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/ELSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */