/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ELUtil
/*     */ {
/*  39 */   private static ThreadLocal instance = new ThreadLocal() {
/*  40 */       protected Object initialValue() { return null; }
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Map getCurrentInstance() {
/*  51 */     Map<Object, Object> result = instance.get();
/*  52 */     if (null == result) {
/*  53 */       result = new HashMap<Object, Object>();
/*  54 */       setCurrentInstance(result);
/*     */     } 
/*  56 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   private static void setCurrentInstance(Map context) { instance.set(context); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  86 */   public static String getExceptionMessageString(ELContext context, String messageId) { return getExceptionMessageString(context, messageId, null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getExceptionMessageString(ELContext context, String messageId, Object[] params) {
/* 117 */     String result = "";
/* 118 */     Locale locale = null;
/*     */     
/* 120 */     if (null == context || null == messageId) {
/* 121 */       return result;
/*     */     }
/*     */     
/* 124 */     if (null == (locale = context.getLocale())) {
/* 125 */       locale = Locale.getDefault();
/*     */     }
/* 127 */     if (null != locale) {
/* 128 */       Map<String, ResourceBundle> threadMap = getCurrentInstance();
/* 129 */       ResourceBundle rb = null;
/* 130 */       if (null == (rb = (ResourceBundle)threadMap.get(locale.toString()))) {
/*     */         
/* 132 */         rb = ResourceBundle.getBundle("org.jdesktop.el.PrivateMessages", locale);
/*     */         
/* 134 */         threadMap.put(locale.toString(), rb);
/*     */       } 
/* 136 */       if (null != rb) {
/*     */         try {
/* 138 */           result = rb.getString(messageId);
/* 139 */           if (null != params) {
/* 140 */             result = MessageFormat.format(result, params);
/*     */           }
/* 142 */         } catch (IllegalArgumentException iae) {
/* 143 */           result = "Can't get localized message: parameters to message appear to be incorrect.  Message to format: " + messageId;
/* 144 */         } catch (MissingResourceException mre) {
/* 145 */           result = "Missing Resource in EL implementation: ???" + messageId + "???";
/* 146 */         } catch (Exception e) {
/* 147 */           result = "Exception resolving message in EL implementation: ???" + messageId + "???";
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 152 */     return result;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ELUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */