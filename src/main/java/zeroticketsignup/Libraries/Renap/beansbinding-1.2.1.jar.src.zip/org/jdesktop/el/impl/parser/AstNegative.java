/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstNegative
/*    */   extends SimpleNode
/*    */ {
/* 23 */   public AstNegative(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 28 */   public Class getType(EvaluationContext ctx) throws ELException { return Number.class; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 33 */     Object obj = this.children[0].getValue(ctx);
/*    */     
/* 35 */     if (obj == ELContext.UNRESOLVABLE_RESULT) {
/* 36 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 38 */     if (obj == null) {
/* 39 */       return new Long(0L);
/*    */     }
/* 41 */     if (obj instanceof BigDecimal) {
/* 42 */       return ((BigDecimal)obj).negate();
/*    */     }
/* 44 */     if (obj instanceof BigInteger) {
/* 45 */       return ((BigInteger)obj).negate();
/*    */     }
/* 47 */     if (obj instanceof String) {
/* 48 */       if (isStringFloat((String)obj)) {
/* 49 */         return new Double(-Double.parseDouble((String)obj));
/*    */       }
/* 51 */       return new Long(-Long.parseLong((String)obj));
/*    */     } 
/* 53 */     Class<?> type = obj.getClass();
/* 54 */     if (obj instanceof Long || long.class == type) {
/* 55 */       return new Long(-((Long)obj).longValue());
/*    */     }
/* 57 */     if (obj instanceof Double || double.class == type) {
/* 58 */       return new Double(-((Double)obj).doubleValue());
/*    */     }
/* 60 */     if (obj instanceof Integer || int.class == type) {
/* 61 */       return new Integer(-((Integer)obj).intValue());
/*    */     }
/* 63 */     if (obj instanceof Float || float.class == type) {
/* 64 */       return new Float(-((Float)obj).floatValue());
/*    */     }
/* 66 */     if (obj instanceof Short || short.class == type) {
/* 67 */       return new Short((short)-((Short)obj).shortValue());
/*    */     }
/* 69 */     if (obj instanceof Byte || byte.class == type) {
/* 70 */       return new Byte((byte)-((Byte)obj).byteValue());
/*    */     }
/* 72 */     Long num = (Long)coerceToNumber(obj, Long.class);
/* 73 */     return new Long(-num.longValue());
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstNegative.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */