package org.jdesktop.observablecollections;

import java.util.EventListener;
import java.util.List;

public interface ObservableListListener extends EventListener {
  void listElementsAdded(ObservableList paramObservableList, int paramInt1, int paramInt2);
  
  void listElementsRemoved(ObservableList paramObservableList, int paramInt, List paramList);
  
  void listElementReplaced(ObservableList paramObservableList, int paramInt, Object paramObject);
  
  void listElementPropertyChanged(ObservableList paramObservableList, int paramInt);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/observablecollections/ObservableListListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */