/*     */ package org.jdesktop.el.impl.lang;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELResolver;
/*     */ import org.jdesktop.el.Expression;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.VariableMapper;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EvaluationContext
/*     */   extends ELContext
/*     */ {
/*     */   private final ELContext elContext;
/*     */   private final FunctionMapper fnMapper;
/*     */   private final VariableMapper varMapper;
/*     */   private final Expression expression;
/*     */   private final Set<Expression.ResolvedProperty> currentIdentifierProperties;
/*     */   private final Set<Expression.ResolvedProperty> resolvedProperties;
/*     */   
/*  33 */   public EvaluationContext(ELContext elContext, FunctionMapper fnMapper, VariableMapper varMapper, Expression expression) { this(elContext, fnMapper, varMapper, expression, false); }
/*     */ 
/*     */ 
/*     */   
/*     */   public EvaluationContext(ELContext elContext, FunctionMapper fnMapper, VariableMapper varMapper, Expression expression, boolean trackResolvedProperties) {
/*  38 */     this.elContext = elContext;
/*  39 */     this.fnMapper = fnMapper;
/*  40 */     this.varMapper = varMapper;
/*  41 */     this.expression = expression;
/*  42 */     if (trackResolvedProperties) {
/*  43 */       this.resolvedProperties = new LinkedHashSet<Expression.ResolvedProperty>(1);
/*  44 */       this.currentIdentifierProperties = new LinkedHashSet<Expression.ResolvedProperty>(1);
/*     */     } else {
/*  46 */       this.resolvedProperties = null;
/*  47 */       this.currentIdentifierProperties = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  52 */   public ELContext getELContext() { return this.elContext; }
/*     */ 
/*     */ 
/*     */   
/*  56 */   public FunctionMapper getFunctionMapper() { return this.fnMapper; }
/*     */ 
/*     */ 
/*     */   
/*  60 */   public VariableMapper getVariableMapper() { return this.varMapper; }
/*     */ 
/*     */ 
/*     */   
/*  64 */   public Expression getExpression() { return this.expression; }
/*     */ 
/*     */ 
/*     */   
/*  68 */   public Object getContext(Class key) { return this.elContext.getContext(key); }
/*     */ 
/*     */ 
/*     */   
/*  72 */   public ELResolver getELResolver() { return this.elContext.getELResolver(); }
/*     */ 
/*     */ 
/*     */   
/*  76 */   public boolean isPropertyResolved() { return this.elContext.isPropertyResolved(); }
/*     */ 
/*     */ 
/*     */   
/*  80 */   public void putContext(Class key, Object contextObject) { this.elContext.putContext(key, contextObject); }
/*     */ 
/*     */ 
/*     */   
/*  84 */   public void setPropertyResolved(boolean resolved) { this.elContext.setPropertyResolved(resolved); }
/*     */ 
/*     */   
/*     */   public void clearResolvedProperties() {
/*  88 */     if (this.resolvedProperties == null) {
/*     */       return;
/*     */     }
/*     */     
/*  92 */     this.resolvedProperties.clear();
/*     */   }
/*     */   
/*     */   public void resolvedIdentifier(Object base, Object property) {
/*  96 */     if (base == null || property == null || this.resolvedProperties == null) {
/*     */       return;
/*     */     }
/*     */     
/* 100 */     this.resolvedProperties.addAll(this.currentIdentifierProperties);
/* 101 */     this.currentIdentifierProperties.clear();
/* 102 */     Expression.ResolvedProperty prop = new Expression.ResolvedProperty(base, property);
/* 103 */     this.resolvedProperties.remove(prop);
/* 104 */     this.currentIdentifierProperties.add(prop);
/*     */   }
/*     */   
/*     */   public void resolvedProperty(Object base, Object property) {
/* 108 */     if (base == null || property == null || this.resolvedProperties == null) {
/*     */       return;
/*     */     }
/*     */     
/* 112 */     Expression.ResolvedProperty prop = new Expression.ResolvedProperty(base, property);
/* 113 */     this.resolvedProperties.remove(prop);
/* 114 */     this.currentIdentifierProperties.add(prop);
/*     */   }
/*     */   
/*     */   public List<Expression.ResolvedProperty> getResolvedProperties() {
/* 118 */     if (this.resolvedProperties == null) {
/* 119 */       return null;
/*     */     }
/*     */     
/* 122 */     this.resolvedProperties.addAll(this.currentIdentifierProperties);
/* 123 */     return new ArrayList<Expression.ResolvedProperty>(this.resolvedProperties);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/EvaluationContext.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */