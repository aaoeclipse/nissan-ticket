/*    */ package org.jdesktop.beansbinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Bindings
/*    */ {
/* 31 */   public static <SS, TS, TV> AutoBinding<SS, SS, TS, TV> createAutoBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, TS targetObject, Property<TS, TV> targetProperty) { return new AutoBinding<SS, SS, TS, TV>(strategy, sourceObject, ObjectProperty.create(), targetObject, targetProperty, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public static <SS, TS, TV> AutoBinding<SS, SS, TS, TV> createAutoBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, TS targetObject, Property<TS, TV> targetProperty, String name) { return new AutoBinding<SS, SS, TS, TV>(strategy, sourceObject, ObjectProperty.create(), targetObject, targetProperty, name); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 63 */   public static <SS, SV, TS, TV> AutoBinding<SS, SV, TS, TV> createAutoBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, SV> sourceProperty, TS targetObject, Property<TS, TV> targetProperty) { return new AutoBinding<SS, SV, TS, TV>(strategy, sourceObject, sourceProperty, targetObject, targetProperty, null); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 79 */   public static <SS, SV, TS, TV> AutoBinding<SS, SV, TS, TV> createAutoBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, SV> sourceProperty, TS targetObject, Property<TS, TV> targetProperty, String name) { return new AutoBinding<SS, SV, TS, TV>(strategy, sourceObject, sourceProperty, targetObject, targetProperty, name); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/Bindings.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */