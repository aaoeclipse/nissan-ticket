/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.ELArithmetic;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstMinus
/*    */   extends ArithmeticNode
/*    */ {
/* 21 */   public AstMinus(int id) { super(id); }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 26 */     Object obj0 = this.children[0].getValue(ctx);
/* 27 */     if (obj0 == ELContext.UNRESOLVABLE_RESULT) {
/* 28 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 30 */     Object obj1 = this.children[1].getValue(ctx);
/* 31 */     if (obj1 == ELContext.UNRESOLVABLE_RESULT) {
/* 32 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 34 */     return ELArithmetic.subtract(obj0, obj1);
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstMinus.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */