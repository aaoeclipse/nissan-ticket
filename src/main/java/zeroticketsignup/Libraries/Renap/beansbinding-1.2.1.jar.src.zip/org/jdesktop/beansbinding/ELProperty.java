/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.EventSetDescriptor;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashSet;
/*     */ import java.util.IdentityHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.jdesktop.beansbinding.ext.BeanAdapterFactory;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.Expression;
/*     */ import org.jdesktop.el.ValueExpression;
/*     */ import org.jdesktop.el.impl.ExpressionFactoryImpl;
/*     */ import org.jdesktop.observablecollections.ObservableMap;
/*     */ import org.jdesktop.observablecollections.ObservableMapListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ELProperty<S, V>
/*     */   extends PropertyHelper<S, V>
/*     */ {
/*     */   private Property<S, ?> baseProperty;
/*     */   private final ValueExpression expression;
/* 159 */   private final ELContext context = new TempELContext();
/* 160 */   private IdentityHashMap<S, SourceEntry> map = new IdentityHashMap<S, SourceEntry>();
/* 161 */   private static final Object NOREAD = new Object();
/*     */   private static final boolean LOG = false;
/*     */   
/*     */   private final class SourceEntry
/*     */     implements PropertyChangeListener, ObservableMapListener, PropertyStateListener
/*     */   {
/*     */     private S source;
/*     */     private Object cachedBean;
/*     */     private Object cachedValue;
/*     */     private boolean cachedIsWriteable;
/*     */     private Class<?> cachedWriteType;
/*     */     private boolean ignoreChange;
/*     */     private Set<ELProperty.RegisteredListener> registeredListeners;
/*     */     private Set<ELProperty.RegisteredListener> lastRegisteredListeners;
/*     */     
/*     */     private SourceEntry(S source) {
/* 177 */       this.source = source;
/*     */       
/* 179 */       if (ELProperty.this.baseProperty != null) {
/* 180 */         ELProperty.this.baseProperty.addPropertyStateListener(source, this);
/*     */       }
/*     */       
/* 183 */       this.registeredListeners = new HashSet<ELProperty.RegisteredListener>(1);
/* 184 */       updateCachedBean();
/* 185 */       updateCache();
/*     */     }
/*     */     
/*     */     private void cleanup() {
/* 189 */       for (ELProperty.RegisteredListener rl : this.registeredListeners) {
/* 190 */         ELProperty.this.unregisterListener(rl, this);
/*     */       }
/*     */       
/* 193 */       if (ELProperty.this.baseProperty != null) {
/* 194 */         ELProperty.this.baseProperty.removePropertyStateListener(this.source, this);
/*     */       }
/*     */       
/* 197 */       this.cachedBean = null;
/* 198 */       this.registeredListeners = null;
/* 199 */       this.cachedValue = null;
/*     */     }
/*     */ 
/*     */     
/* 203 */     private boolean cachedIsReadable() { return (this.cachedValue != NOREAD); }
/*     */ 
/*     */ 
/*     */     
/* 207 */     private void updateCachedBean() { this.cachedBean = ELProperty.this.getBeanFromSource(this.source, true); }
/*     */ 
/*     */     
/*     */     private void updateCache() {
/* 211 */       this.lastRegisteredListeners = this.registeredListeners;
/* 212 */       this.registeredListeners = new HashSet<ELProperty.RegisteredListener>(this.lastRegisteredListeners.size());
/* 213 */       List<Expression.ResolvedProperty> resolvedProperties = null;
/*     */       
/*     */       try {
/* 216 */         ELProperty.this.expression.setSource(ELProperty.this.getBeanFromSource(this.source, true));
/* 217 */         Expression.Result result = ELProperty.this.expression.getResult(ELProperty.this.context, true);
/*     */         
/* 219 */         if (result.getType() == Expression.Result.Type.UNRESOLVABLE) {
/* 220 */           ELProperty.log("updateCache()", "expression is unresolvable");
/* 221 */           this.cachedValue = NOREAD;
/* 222 */           this.cachedIsWriteable = false;
/* 223 */           this.cachedWriteType = null;
/*     */         } else {
/* 225 */           this.cachedValue = result.getResult();
/* 226 */           this.cachedIsWriteable = !ELProperty.this.expression.isReadOnly(ELProperty.this.context);
/* 227 */           this.cachedWriteType = this.cachedIsWriteable ? ELProperty.this.expression.getType(ELProperty.this.context) : null;
/*     */         } 
/*     */         
/* 230 */         resolvedProperties = result.getResolvedProperties();
/* 231 */       } catch (ELException ele) {
/* 232 */         throw new PropertyResolutionException("Error evaluating EL expression " + ELProperty.this.expression + " on " + this.source, (Exception)ele);
/*     */       } finally {
/* 234 */         ELProperty.this.expression.setSource(null);
/*     */       } 
/*     */       
/* 237 */       for (Expression.ResolvedProperty prop : resolvedProperties) {
/* 238 */         ELProperty.this.registerListener(prop, this);
/*     */       }
/*     */ 
/*     */       
/* 242 */       for (ELProperty.RegisteredListener listener : this.lastRegisteredListeners) {
/* 243 */         ELProperty.this.unregisterListener(listener, this);
/*     */       }
/*     */       
/* 246 */       this.lastRegisteredListeners = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private void validateCache(int flag) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void propertyStateChanged(PropertyStateEvent pe) {
/* 293 */       if (!pe.getValueChanged()) {
/*     */         return;
/*     */       }
/*     */       
/* 297 */       validateCache(0);
/* 298 */       Object oldValue = this.cachedValue;
/* 299 */       boolean wasWriteable = this.cachedIsWriteable;
/* 300 */       updateCachedBean();
/* 301 */       updateCache();
/* 302 */       ELProperty.this.notifyListeners(wasWriteable, oldValue, this);
/*     */     }
/*     */     
/*     */     private void processSourceChanged() {
/* 306 */       validateCache(1);
/*     */       
/* 308 */       boolean wasWriteable = this.cachedIsWriteable;
/* 309 */       Object oldValue = this.cachedValue;
/*     */       
/* 311 */       updateCache();
/* 312 */       ELProperty.this.notifyListeners(wasWriteable, oldValue, this);
/*     */     }
/*     */     
/*     */     private void sourceChanged(Object source, String property) {
/* 316 */       if (this.ignoreChange) {
/*     */         return;
/*     */       }
/*     */       
/* 320 */       if (property != null) {
/* 321 */         property = property.intern();
/*     */       }
/*     */       
/* 324 */       for (ELProperty.RegisteredListener rl : this.registeredListeners) {
/* 325 */         if (rl.getSource() == source && (property == null || rl.getProperty() == property)) {
/* 326 */           processSourceChanged();
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 333 */     public void propertyChange(PropertyChangeEvent e) { sourceChanged(e.getSource(), e.getPropertyName()); }
/*     */ 
/*     */     
/*     */     public void mapKeyValueChanged(ObservableMap map, Object key, Object lastValue) {
/* 337 */       if (key instanceof String) {
/* 338 */         sourceChanged(map, (String)key);
/*     */       }
/*     */     }
/*     */     
/*     */     public void mapKeyAdded(ObservableMap map, Object key) {
/* 343 */       if (key instanceof String) {
/* 344 */         sourceChanged(map, (String)key);
/*     */       }
/*     */     }
/*     */     
/*     */     public void mapKeyRemoved(ObservableMap map, Object key, Object value) {
/* 349 */       if (key instanceof String) {
/* 350 */         sourceChanged(map, (String)key);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 364 */   public static final <S, V> ELProperty<S, V> create(String expression) { return new ELProperty<S, V>(null, expression); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 378 */   public static final <S, V> ELProperty<S, V> create(Property<S, ?> baseProperty, String expression) { return new ELProperty<S, V>(baseProperty, expression); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ELProperty(Property<S, ?> baseProperty, String expression) {
/* 385 */     if (expression == null || expression.length() == 0) {
/* 386 */       throw new IllegalArgumentException("expression must be non-null and non-empty");
/*     */     }
/*     */     
/*     */     try {
/* 390 */       this.expression = (new ExpressionFactoryImpl()).createValueExpression(this.context, expression, Object.class);
/* 391 */     } catch (ELException ele) {
/* 392 */       throw new PropertyResolutionException("Error creating EL expression " + expression, (Exception)ele);
/*     */     } 
/*     */     
/* 395 */     this.baseProperty = baseProperty;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<? extends V> getWriteType(S source) {
/* 409 */     SourceEntry entry = this.map.get(source);
/*     */     
/* 411 */     if (entry != null) {
/* 412 */       entry.validateCache(-1);
/*     */       
/* 414 */       if (!entry.cachedIsWriteable) {
/* 415 */         throw new UnsupportedOperationException("Unwriteable");
/*     */       }
/*     */       
/* 418 */       return (Class)entry.cachedWriteType;
/*     */     } 
/*     */     
/*     */     try {
/* 422 */       this.expression.setSource(getBeanFromSource(source, true));
/* 423 */       Expression.Result result = this.expression.getResult(this.context, false);
/*     */       
/* 425 */       if (result.getType() == Expression.Result.Type.UNRESOLVABLE) {
/* 426 */         log("getWriteType()", "expression is unresolvable");
/* 427 */         throw new UnsupportedOperationException("Unwriteable");
/*     */       } 
/*     */       
/* 430 */       if (this.expression.isReadOnly(this.context)) {
/* 431 */         log("getWriteType()", "property is unwriteable");
/* 432 */         throw new UnsupportedOperationException("Unwriteable");
/*     */       } 
/*     */       
/* 435 */       return this.expression.getType(this.context);
/* 436 */     } catch (ELException ele) {
/* 437 */       throw new PropertyResolutionException("Error evaluating EL expression " + this.expression + " on " + source, (Exception)ele);
/*     */     } finally {
/* 439 */       this.expression.setSource(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public V getValue(S source) {
/* 453 */     SourceEntry entry = this.map.get(source);
/*     */     
/* 455 */     if (entry != null) {
/* 456 */       entry.validateCache(-1);
/*     */       
/* 458 */       if (entry.cachedValue == NOREAD) {
/* 459 */         throw new UnsupportedOperationException("Unreadable");
/*     */       }
/*     */       
/* 462 */       return (V)entry.cachedValue;
/*     */     } 
/*     */     
/*     */     try {
/* 466 */       this.expression.setSource(getBeanFromSource(source, true));
/* 467 */       Expression.Result result = this.expression.getResult(this.context, false);
/*     */       
/* 469 */       if (result.getType() == Expression.Result.Type.UNRESOLVABLE) {
/* 470 */         log("getValue()", "expression is unresolvable");
/* 471 */         throw new UnsupportedOperationException("Unreadable");
/*     */       } 
/*     */       
/* 474 */       return (V)result.getResult();
/* 475 */     } catch (ELException ele) {
/* 476 */       throw new PropertyResolutionException("Error evaluating EL expression " + this.expression + " on " + source, (Exception)ele);
/*     */     } finally {
/* 478 */       this.expression.setSource(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(S source, V value) {
/* 493 */     SourceEntry entry = this.map.get(source);
/*     */     
/* 495 */     if (entry != null) {
/* 496 */       entry.validateCache(-1);
/*     */       
/* 498 */       if (!entry.cachedIsWriteable) {
/* 499 */         throw new UnsupportedOperationException("Unwritable");
/*     */       }
/*     */       
/*     */       try {
/* 503 */         entry.ignoreChange = true;
/* 504 */         this.expression.setSource(getBeanFromSource(source, false));
/* 505 */         this.expression.setValue(this.context, value);
/* 506 */       } catch (ELException ele) {
/* 507 */         throw new PropertyResolutionException("Error evaluating EL expression " + this.expression + " on " + source, (Exception)ele);
/*     */       } finally {
/* 509 */         entry.ignoreChange = false;
/* 510 */         this.expression.setSource(null);
/*     */       } 
/*     */       
/* 513 */       Object oldValue = entry.cachedValue;
/*     */       
/* 515 */       entry.updateCache();
/* 516 */       notifyListeners(entry.cachedIsWriteable, oldValue, entry);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 522 */       this.expression.setSource(getBeanFromSource(source, true));
/* 523 */       Expression.Result result = this.expression.getResult(this.context, false);
/*     */       
/* 525 */       if (result.getType() == Expression.Result.Type.UNRESOLVABLE) {
/* 526 */         log("setValue()", "expression is unresolvable");
/* 527 */         throw new UnsupportedOperationException("Unwriteable");
/*     */       } 
/*     */       
/* 530 */       if (this.expression.isReadOnly(this.context)) {
/* 531 */         log("setValue()", "property is unwriteable");
/* 532 */         throw new UnsupportedOperationException("Unwriteable");
/*     */       } 
/*     */       
/* 535 */       this.expression.setValue(this.context, value);
/* 536 */     } catch (ELException ele) {
/* 537 */       throw new PropertyResolutionException("Error evaluating EL expression " + this.expression + " on " + source, (Exception)ele);
/*     */     } finally {
/* 539 */       this.expression.setSource(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadable(S source) {
/* 553 */     SourceEntry entry = this.map.get(source);
/*     */     
/* 555 */     if (entry != null) {
/* 556 */       entry.validateCache(-1);
/* 557 */       return entry.cachedIsReadable();
/*     */     } 
/*     */     
/*     */     try {
/* 561 */       this.expression.setSource(getBeanFromSource(source, true));
/* 562 */       Expression.Result result = this.expression.getResult(this.context, false);
/*     */       
/* 564 */       if (result.getType() == Expression.Result.Type.UNRESOLVABLE) {
/* 565 */         log("isReadable()", "expression is unresolvable");
/* 566 */         return false;
/*     */       } 
/*     */       
/* 569 */       return true;
/* 570 */     } catch (ELException ele) {
/* 571 */       throw new PropertyResolutionException("Error evaluating EL expression " + this.expression + " on " + source, (Exception)ele);
/*     */     } finally {
/* 573 */       this.expression.setSource(null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWriteable(S source) {
/* 587 */     SourceEntry entry = this.map.get(source);
/*     */     
/* 589 */     if (entry != null) {
/* 590 */       entry.validateCache(-1);
/* 591 */       return entry.cachedIsWriteable;
/*     */     } 
/*     */     
/*     */     try {
/* 595 */       this.expression.setSource(getBeanFromSource(source, true));
/* 596 */       Expression.Result result = this.expression.getResult(this.context, false);
/*     */       
/* 598 */       if (result.getType() == Expression.Result.Type.UNRESOLVABLE) {
/* 599 */         log("isWriteable()", "expression is unresolvable");
/* 600 */         return false;
/*     */       } 
/*     */       
/* 603 */       if (this.expression.isReadOnly(this.context)) {
/* 604 */         log("isWriteable()", "property is unwriteable");
/* 605 */         return false;
/*     */       } 
/*     */       
/* 608 */       return true;
/* 609 */     } catch (ELException ele) {
/* 610 */       throw new PropertyResolutionException("Error evaluating EL expression " + this.expression + " on " + source, (Exception)ele);
/*     */     } finally {
/* 612 */       this.expression.setSource(null);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Object getBeanFromSource(S source, boolean logErrors) {
/* 617 */     if (this.baseProperty == null) {
/* 618 */       if (source == null && 
/* 619 */         logErrors) {
/* 620 */         log("getBeanFromSource()", "source is null");
/*     */       }
/*     */ 
/*     */       
/* 624 */       return source;
/*     */     } 
/*     */     
/* 627 */     if (!this.baseProperty.isReadable(source)) {
/* 628 */       if (logErrors) {
/* 629 */         log("getBeanFromSource()", "unreadable source property");
/*     */       }
/* 631 */       return NOREAD;
/*     */     } 
/*     */     
/* 634 */     Object bean = this.baseProperty.getValue(source);
/* 635 */     if (bean == null) {
/* 636 */       if (logErrors) {
/* 637 */         log("getBeanFromSource()", "source property returned null");
/*     */       }
/* 639 */       return null;
/*     */     } 
/*     */     
/* 642 */     return bean;
/*     */   }
/*     */   
/*     */   protected final void listeningStarted(S source) {
/* 646 */     SourceEntry entry = this.map.get(source);
/* 647 */     if (entry == null) {
/* 648 */       entry = new SourceEntry(source);
/* 649 */       this.map.put(source, entry);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected final void listeningStopped(S source) {
/* 654 */     SourceEntry entry = this.map.remove(source);
/* 655 */     if (entry != null) {
/* 656 */       entry.cleanup();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 661 */   private static boolean didValueChange(Object oldValue, Object newValue) { return (oldValue == null || newValue == null || !oldValue.equals(newValue)); }
/*     */ 
/*     */   
/*     */   private void notifyListeners(boolean wasWriteable, Object oldValue, SourceEntry entry) {
/* 665 */     PropertyStateListener[] listeners = getPropertyStateListeners(entry.source);
/*     */     
/* 667 */     if (listeners == null || listeners.length == 0) {
/*     */       return;
/*     */     }
/*     */     
/* 671 */     oldValue = toUNREADABLE(oldValue);
/* 672 */     Object newValue = toUNREADABLE(entry.cachedValue);
/* 673 */     boolean valueChanged = didValueChange(oldValue, newValue);
/* 674 */     boolean writeableChanged = (wasWriteable != entry.cachedIsWriteable);
/*     */     
/* 676 */     if (!valueChanged && !writeableChanged) {
/*     */       return;
/*     */     }
/*     */     
/* 680 */     PropertyStateEvent pse = new PropertyStateEvent(this, entry.source, valueChanged, oldValue, newValue, writeableChanged, entry.cachedIsWriteable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 688 */     firePropertyStateChange(pse);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 701 */   public String toString() { return getClass().getName() + "[" + this.expression + "]"; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static BeanInfo getBeanInfo(Object object) {
/* 708 */     assert object != null;
/*     */     
/*     */     try {
/* 711 */       return Introspector.getBeanInfo(object.getClass(), 3);
/* 712 */     } catch (IntrospectionException ie) {
/* 713 */       throw new PropertyResolutionException("Exception while introspecting " + object.getClass().getName(), ie);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static EventSetDescriptor getEventSetDescriptor(Object object) {
/* 718 */     assert object != null;
/*     */     
/* 720 */     EventSetDescriptor[] eds = getBeanInfo(object).getEventSetDescriptors();
/* 721 */     for (EventSetDescriptor ed : eds) {
/* 722 */       if (ed.getListenerType() == PropertyChangeListener.class) {
/* 723 */         return ed;
/*     */       }
/*     */     } 
/*     */     
/* 727 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object invokeMethod(Method method, Object object, Object... args) {
/* 734 */     Exception reason = null;
/*     */     
/*     */     try {
/* 737 */       return method.invoke(object, args);
/* 738 */     } catch (IllegalArgumentException ex) {
/* 739 */       reason = ex;
/* 740 */     } catch (IllegalAccessException ex) {
/* 741 */       reason = ex;
/* 742 */     } catch (InvocationTargetException ex) {
/* 743 */       reason = ex;
/*     */     } 
/*     */     
/* 746 */     throw new PropertyResolutionException("Exception invoking method " + method + " on " + object, reason);
/*     */   }
/*     */ 
/*     */   
/* 750 */   private static Object toUNREADABLE(Object src) { return (src == NOREAD) ? PropertyStateEvent.UNREADABLE : src; }
/*     */ 
/*     */   
/*     */   private void registerListener(Expression.ResolvedProperty resolved, SourceEntry entry) {
/* 754 */     Object source = resolved.getSource();
/* 755 */     Object property = resolved.getProperty();
/* 756 */     if (source != null && property instanceof String) {
/* 757 */       String sProp = (String)property;
/*     */       
/* 759 */       if (source instanceof ObservableMap) {
/* 760 */         RegisteredListener rl = new RegisteredListener(source, sProp);
/*     */         
/* 762 */         if (!entry.registeredListeners.contains(rl)) {
/* 763 */           if (!entry.lastRegisteredListeners.remove(rl)) {
/* 764 */             ((ObservableMap)source).addObservableMapListener(entry);
/*     */           }
/*     */           
/* 767 */           entry.registeredListeners.add(rl);
/*     */         } 
/* 769 */       } else if (!(source instanceof java.util.Map)) {
/* 770 */         source = getAdapter(source, sProp);
/*     */         
/* 772 */         RegisteredListener rl = new RegisteredListener(source, sProp);
/*     */         
/* 774 */         if (!entry.registeredListeners.contains(rl)) {
/* 775 */           if (!entry.lastRegisteredListeners.remove(rl)) {
/* 776 */             addPropertyChangeListener(source, entry);
/*     */           }
/*     */           
/* 779 */           entry.registeredListeners.add(rl);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void unregisterListener(RegisteredListener rl, SourceEntry entry) {
/* 786 */     Object source = rl.getSource();
/* 787 */     if (source instanceof ObservableMap) {
/* 788 */       ((ObservableMap)source).removeObservableMapListener(entry);
/* 789 */     } else if (!(source instanceof java.util.Map)) {
/* 790 */       removePropertyChangeListener(source, entry);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void addPropertyChangeListener(Object object, PropertyChangeListener listener) {
/* 798 */     EventSetDescriptor ed = getEventSetDescriptor(object);
/* 799 */     Method addPCMethod = null;
/*     */     
/* 801 */     if (ed == null || (addPCMethod = ed.getAddListenerMethod()) == null) {
/* 802 */       log("addPropertyChangeListener()", "can't add listener");
/*     */       
/*     */       return;
/*     */     } 
/* 806 */     invokeMethod(addPCMethod, object, new Object[] { listener });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void removePropertyChangeListener(Object object, PropertyChangeListener listener) {
/* 813 */     EventSetDescriptor ed = getEventSetDescriptor(object);
/* 814 */     Method removePCMethod = null;
/*     */     
/* 816 */     if (ed == null || (removePCMethod = ed.getRemoveListenerMethod()) == null) {
/* 817 */       log("removePropertyChangeListener()", "can't remove listener from source");
/*     */       
/*     */       return;
/*     */     } 
/* 821 */     invokeMethod(removePCMethod, object, new Object[] { listener });
/*     */   }
/*     */   
/*     */   private static boolean wrapsLiteral(Object o) {
/* 825 */     assert o != null;
/*     */     
/* 827 */     return (o instanceof String || o instanceof Byte || o instanceof Character || o instanceof Boolean || o instanceof Short || o instanceof Integer || o instanceof Long || o instanceof Float || o instanceof Double);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean match(Object a, Object b) {
/* 842 */     if (a == b) {
/* 843 */       return true;
/*     */     }
/*     */     
/* 846 */     if (a == null) {
/* 847 */       return false;
/*     */     }
/*     */     
/* 850 */     if (wrapsLiteral(a)) {
/* 851 */       return a.equals(b);
/*     */     }
/*     */     
/* 854 */     return false;
/*     */   }
/*     */   
/*     */   private Object getAdapter(Object o, String property) {
/* 858 */     Object adapter = null;
/* 859 */     adapter = BeanAdapterFactory.getAdapter(o, property);
/* 860 */     return (adapter == null) ? o : adapter;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void log(String method, String message) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class RegisteredListener
/*     */   {
/*     */     private final Object source;
/*     */     
/*     */     private final String property;
/*     */ 
/*     */     
/* 876 */     RegisteredListener(Object source) { this(source, null); }
/*     */ 
/*     */     
/*     */     RegisteredListener(Object source, String property) {
/* 880 */       this.source = source;
/* 881 */       if (property != null) {
/* 882 */         property = property.intern();
/*     */       }
/* 884 */       this.property = property;
/*     */     }
/*     */ 
/*     */     
/* 888 */     public Object getSource() { return this.source; }
/*     */ 
/*     */ 
/*     */     
/* 892 */     public String getProperty() { return this.property; }
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 896 */       if (obj == this) {
/* 897 */         return true;
/*     */       }
/* 899 */       if (obj instanceof RegisteredListener) {
/* 900 */         RegisteredListener orl = (RegisteredListener)obj;
/* 901 */         return (orl.source == this.source && orl.property == this.property);
/*     */       } 
/* 903 */       return false;
/*     */     }
/*     */     
/*     */     public int hashCode() {
/* 907 */       int result = 17;
/* 908 */       result = 37 * result + this.source.hashCode();
/* 909 */       if (this.property != null) {
/* 910 */         result = 37 * result + this.property.hashCode();
/*     */       }
/* 912 */       return result;
/*     */     }
/*     */ 
/*     */     
/* 916 */     public String toString() { return "RegisteredListener [ source=" + this.source + " property=" + this.property + "]"; }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/ELProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */