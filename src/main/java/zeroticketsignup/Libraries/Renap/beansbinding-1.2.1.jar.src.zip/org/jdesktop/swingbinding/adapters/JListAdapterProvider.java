/*     */ package org.jdesktop.swingbinding.adapters;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*     */ import org.jdesktop.swingbinding.impl.ListBindingManager;
/*     */ 
/*     */ 
/*     */ public final class JListAdapterProvider
/*     */   implements BeanAdapterProvider
/*     */ {
/*     */   private static final String SELECTED_ELEMENT_P = "selectedElement";
/*     */   private static final String SELECTED_ELEMENTS_P = "selectedElements";
/*     */   private static final String SELECTED_ELEMENT_IA_P = "selectedElement_IGNORE_ADJUSTING";
/*     */   private static final String SELECTED_ELEMENTS_IA_P = "selectedElements_IGNORE_ADJUSTING";
/*     */   
/*     */   public final class Adapter
/*     */     extends BeanAdapterBase
/*     */   {
/*     */     private JList list;
/*     */     private Handler handler;
/*     */     private Object cachedElementOrElements;
/*     */     
/*     */     private Adapter(JList list, String property) {
/*  32 */       super(property);
/*  33 */       this.list = list;
/*     */     }
/*     */ 
/*     */     
/*  37 */     private boolean isPlural() { return (this.property == "selectedElements" || this.property == "selectedElements_IGNORE_ADJUSTING"); }
/*     */ 
/*     */ 
/*     */     
/*  41 */     public Object getSelectedElement() { return JListAdapterProvider.getSelectedElement(this.list); }
/*     */ 
/*     */ 
/*     */     
/*  45 */     public Object getSelectedElement_IGNORE_ADJUSTING() { return getSelectedElement(); }
/*     */ 
/*     */ 
/*     */     
/*  49 */     public List<Object> getSelectedElements() { return JListAdapterProvider.getSelectedElements(this.list); }
/*     */ 
/*     */ 
/*     */     
/*  53 */     public List<Object> getSelectedElements_IGNORE_ADJUSTING() { return getSelectedElements(); }
/*     */ 
/*     */     
/*     */     protected void listeningStarted() {
/*  57 */       this.handler = new Handler();
/*  58 */       this.cachedElementOrElements = isPlural() ? getSelectedElements() : getSelectedElement();
/*     */       
/*  60 */       this.list.addPropertyChangeListener("model", this.handler);
/*  61 */       this.list.addPropertyChangeListener("selectionModel", this.handler);
/*  62 */       this.list.getSelectionModel().addListSelectionListener(this.handler);
/*     */     }
/*     */     
/*     */     protected void listeningStopped() {
/*  66 */       this.list.getSelectionModel().removeListSelectionListener(this.handler);
/*  67 */       this.list.removePropertyChangeListener("model", this.handler);
/*  68 */       this.list.removePropertyChangeListener("selectionModel", this.handler);
/*  69 */       this.cachedElementOrElements = null;
/*  70 */       this.handler = null;
/*     */     }
/*     */     
/*     */     private class Handler implements ListSelectionListener, PropertyChangeListener {
/*     */       private void listSelectionChanged() {
/*  75 */         Object oldElementOrElements = JListAdapterProvider.Adapter.this.cachedElementOrElements;
/*  76 */         JListAdapterProvider.Adapter.this.cachedElementOrElements = JListAdapterProvider.Adapter.this.isPlural() ? JListAdapterProvider.Adapter.this.getSelectedElements() : JListAdapterProvider.Adapter.this.getSelectedElement();
/*     */         
/*  78 */         JListAdapterProvider.Adapter.this.firePropertyChange(oldElementOrElements, JListAdapterProvider.Adapter.this.cachedElementOrElements);
/*     */       }
/*     */       private Handler() {}
/*     */       public void valueChanged(ListSelectionEvent e) {
/*  82 */         if ((JListAdapterProvider.Adapter.this.property == "selectedElement_IGNORE_ADJUSTING" || JListAdapterProvider.Adapter.this.property == "selectedElements_IGNORE_ADJUSTING") && e.getValueIsAdjusting()) {
/*     */           return;
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*  88 */         listSelectionChanged();
/*     */       }
/*     */       
/*     */       public void propertyChange(PropertyChangeEvent pce) {
/*  92 */         String propertyName = pce.getPropertyName();
/*     */         
/*  94 */         if (propertyName == "selectionModel") {
/*  95 */           ((ListSelectionModel)pce.getOldValue()).removeListSelectionListener(JListAdapterProvider.Adapter.this.handler);
/*  96 */           ((ListSelectionModel)pce.getNewValue()).addListSelectionListener(JListAdapterProvider.Adapter.this.handler);
/*  97 */           listSelectionChanged();
/*  98 */         } else if (propertyName == "model") {
/*  99 */           listSelectionChanged();
/*     */         } 
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static List<Object> getSelectedElements(JList list) {
/* 106 */     assert list != null;
/*     */     
/* 108 */     ListSelectionModel selectionModel = list.getSelectionModel();
/* 109 */     int min = selectionModel.getMinSelectionIndex();
/* 110 */     int max = selectionModel.getMaxSelectionIndex();
/*     */ 
/*     */ 
/*     */     
/* 114 */     if (min < 0 || max < 0) {
/* 115 */       return new ArrayList(0);
/*     */     }
/*     */     
/* 118 */     ArrayList<Object> elements = new ArrayList(max - min + 1);
/*     */     
/* 120 */     for (int i = min; i <= max; i++) {
/* 121 */       if (selectionModel.isSelectedIndex(i)) {
/* 122 */         elements.add(getElement(list, i));
/*     */       }
/*     */     } 
/*     */     
/* 126 */     return elements;
/*     */   }
/*     */   
/*     */   private static Object getSelectedElement(JList list) {
/* 130 */     assert list != null;
/*     */ 
/*     */     
/* 133 */     int index = list.getSelectionModel().getLeadSelectionIndex();
/* 134 */     index = list.getSelectionModel().isSelectedIndex(index) ? index : list.getSelectionModel().getMinSelectionIndex();
/*     */ 
/*     */     
/* 137 */     if (index == -1) {
/* 138 */       return null;
/*     */     }
/*     */     
/* 141 */     return getElement(list, index);
/*     */   }
/*     */   
/*     */   private static Object getElement(JList list, int index) {
/* 145 */     ListModel model = list.getModel();
/* 146 */     return (model instanceof ListBindingManager) ? ((ListBindingManager)model).getElement(index) : model.getElementAt(index);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean providesAdapter(Class<?> type, String property) {
/* 151 */     if (!JList.class.isAssignableFrom(type)) {
/* 152 */       return false;
/*     */     }
/*     */     
/* 155 */     property = property.intern();
/*     */     
/* 157 */     return (property == "selectedElement" || property == "selectedElement_IGNORE_ADJUSTING" || property == "selectedElements" || property == "selectedElements_IGNORE_ADJUSTING");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createAdapter(Object source, String property) {
/* 165 */     if (!providesAdapter(source.getClass(), property)) {
/* 166 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 169 */     return new Adapter((JList)source, property);
/*     */   }
/*     */ 
/*     */   
/* 173 */   public Class<?> getAdapterClass(Class<?> type) { return JList.class.isAssignableFrom(type) ? Adapter.class : null; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/JListAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */