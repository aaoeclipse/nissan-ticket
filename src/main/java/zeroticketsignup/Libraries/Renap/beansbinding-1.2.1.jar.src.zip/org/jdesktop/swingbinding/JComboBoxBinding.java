/*     */ package org.jdesktop.swingbinding;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.swing.ComboBoxModel;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.event.ListDataEvent;
/*     */ import javax.swing.event.ListDataListener;
/*     */ import org.jdesktop.beansbinding.AutoBinding;
/*     */ import org.jdesktop.beansbinding.Property;
/*     */ import org.jdesktop.beansbinding.PropertyStateEvent;
/*     */ import org.jdesktop.beansbinding.PropertyStateListener;
/*     */ import org.jdesktop.swingbinding.impl.AbstractColumnBinding;
/*     */ import org.jdesktop.swingbinding.impl.ListBindingManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JComboBoxBinding<E, SS, TS>
/*     */   extends AutoBinding<SS, List<E>, TS, List>
/*     */ {
/*     */   private Property<TS, ? extends JComboBox> comboP;
/*     */   private ElementsProperty<TS> elementsP;
/* 169 */   private Handler handler = new Handler();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JComboBox combo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private BindingComboBoxModel model;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected JComboBoxBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JComboBox> targetJComboBoxProperty, String name) {
/* 185 */     super((strategy == AutoBinding.UpdateStrategy.READ_WRITE) ? AutoBinding.UpdateStrategy.READ : strategy, sourceObject, sourceListProperty, targetObject, (Property)new ElementsProperty(), name);
/*     */ 
/*     */     
/* 188 */     if (targetJComboBoxProperty == null) {
/* 189 */       throw new IllegalArgumentException("target JComboBox property can't be null");
/*     */     }
/*     */     
/* 192 */     this.comboP = targetJComboBoxProperty;
/* 193 */     this.elementsP = (ElementsProperty<TS>)getTargetProperty();
/*     */   }
/*     */   
/*     */   protected void bindImpl() {
/* 197 */     this.elementsP.setAccessible(isComboAccessible());
/* 198 */     this.comboP.addPropertyStateListener(getTargetObject(), this.handler);
/* 199 */     this.elementsP.addPropertyStateListener(null, this.handler);
/* 200 */     super.bindImpl();
/*     */   }
/*     */   
/*     */   protected void unbindImpl() {
/* 204 */     this.elementsP.removePropertyStateListener(null, this.handler);
/* 205 */     this.comboP.removePropertyStateListener(getTargetObject(), this.handler);
/* 206 */     this.elementsP.setAccessible(false);
/* 207 */     cleanupForLast();
/* 208 */     super.unbindImpl();
/*     */   }
/*     */ 
/*     */   
/* 212 */   private boolean isComboAccessible() { return (this.comboP.isReadable(getTargetObject()) && this.comboP.getValue(getTargetObject()) != null); }
/*     */ 
/*     */ 
/*     */   
/* 216 */   private boolean isComboAccessible(Object value) { return (value != null && value != PropertyStateEvent.UNREADABLE); }
/*     */ 
/*     */   
/*     */   private void cleanupForLast() {
/* 220 */     if (this.combo == null) {
/*     */       return;
/*     */     }
/*     */     
/* 224 */     this.combo.setSelectedItem(null);
/* 225 */     this.combo.setModel(new DefaultComboBoxModel());
/* 226 */     this.model.updateElements(null, this.combo.isEditable());
/* 227 */     this.combo = null;
/* 228 */     this.model = null;
/*     */   }
/*     */   
/*     */   private class Handler implements PropertyStateListener {
/*     */     public void propertyStateChanged(PropertyStateEvent pse) {
/* 233 */       if (!pse.getValueChanged()) {
/*     */         return;
/*     */       }
/*     */       
/* 237 */       if (pse.getSourceProperty() == JComboBoxBinding.this.comboP) {
/* 238 */         JComboBoxBinding.this.cleanupForLast();
/*     */         
/* 240 */         boolean wasAccessible = JComboBoxBinding.this.isComboAccessible(pse.getOldValue());
/* 241 */         boolean isAccessible = JComboBoxBinding.this.isComboAccessible(pse.getNewValue());
/*     */         
/* 243 */         if (wasAccessible != isAccessible) {
/* 244 */           JComboBoxBinding.this.elementsP.setAccessible(isAccessible);
/* 245 */         } else if (JComboBoxBinding.this.elementsP.isAccessible()) {
/* 246 */           JComboBoxBinding.this.elementsP.setValueAndIgnore(null, null);
/*     */         } 
/*     */       } else {
/* 249 */         if (((ElementsProperty.ElementsPropertyStateEvent)pse).shouldIgnore()) {
/*     */           return;
/*     */         }
/*     */         
/* 253 */         if (JComboBoxBinding.this.combo == null) {
/* 254 */           JComboBoxBinding.this.combo = (JComboBox)JComboBoxBinding.this.comboP.getValue(JComboBoxBinding.this.getTargetObject());
/* 255 */           JComboBoxBinding.this.combo.setSelectedItem(null);
/* 256 */           JComboBoxBinding.this.model = new JComboBoxBinding.BindingComboBoxModel();
/* 257 */           JComboBoxBinding.this.combo.setModel(JComboBoxBinding.this.model);
/*     */         } 
/*     */         
/* 260 */         JComboBoxBinding.this.model.updateElements((List)pse.getNewValue(), JComboBoxBinding.this.combo.isEditable());
/*     */       } 
/*     */     }
/*     */     
/*     */     private Handler() {} }
/*     */   
/*     */   private final class BindingComboBoxModel extends ListBindingManager implements ComboBoxModel {
/* 267 */     private Object selectedItem = null;
/* 268 */     private int selectedModelIndex = -1;
/*     */ 
/*     */     
/* 271 */     private final List<ListDataListener> listeners = new CopyOnWriteArrayList<ListDataListener>();
/*     */ 
/*     */     
/*     */     public void updateElements(List<?> elements, boolean isEditable) {
/* 275 */       setElements(elements, false);
/*     */       
/* 277 */       if (!isEditable || this.selectedModelIndex != -1) {
/* 278 */         this.selectedItem = null;
/* 279 */         this.selectedModelIndex = -1;
/*     */       } 
/*     */       
/* 282 */       if (size() <= 0) {
/* 283 */         if (this.selectedModelIndex != -1) {
/* 284 */           this.selectedModelIndex = -1;
/* 285 */           this.selectedItem = null;
/*     */         }
/*     */       
/* 288 */       } else if (this.selectedItem == null) {
/* 289 */         this.selectedModelIndex = 0;
/* 290 */         this.selectedItem = getElementAt(this.selectedModelIndex);
/*     */       } 
/*     */ 
/*     */       
/* 294 */       allChanged();
/*     */     }
/*     */ 
/*     */     
/* 298 */     protected AbstractColumnBinding[] getColBindings() { return new AbstractColumnBinding[0]; }
/*     */ 
/*     */ 
/*     */     
/* 302 */     public Object getSelectedItem() { return this.selectedItem; }
/*     */ 
/*     */ 
/*     */     
/*     */     public void setSelectedItem(Object item) {
/* 307 */       if ((this.selectedItem != null && !this.selectedItem.equals(item)) || (this.selectedItem == null && item != null)) {
/* 308 */         this.selectedItem = item;
/* 309 */         contentsChanged(-1, -1);
/* 310 */         this.selectedModelIndex = -1;
/* 311 */         if (item != null) {
/* 312 */           int size = size();
/* 313 */           for (int i = 0; i < size; i++) {
/* 314 */             if (item.equals(getElementAt(i))) {
/* 315 */               this.selectedModelIndex = i;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 324 */     protected void allChanged() { contentsChanged(0, size()); }
/*     */ 
/*     */ 
/*     */     
/*     */     protected void valueChanged(int row, int column) {}
/*     */ 
/*     */ 
/*     */     
/*     */     protected void added(int index, int length) {
/* 333 */       assert length > 0;
/*     */       
/* 335 */       ListDataEvent e = new ListDataEvent(this, 1, index, index + length - 1);
/* 336 */       int size = this.listeners.size();
/* 337 */       for (int i = size - 1; i >= 0; i--) {
/* 338 */         ((ListDataListener)this.listeners.get(i)).intervalAdded(e);
/*     */       }
/*     */       
/* 341 */       if (size() == length && this.selectedItem == null) {
/* 342 */         setSelectedItem(getElementAt(0));
/*     */       }
/*     */     }
/*     */     
/*     */     protected void removed(int index, int length) {
/* 347 */       assert length > 0;
/*     */       
/* 349 */       ListDataEvent e = new ListDataEvent(this, 2, index, index + length - 1);
/* 350 */       int size = this.listeners.size();
/* 351 */       for (int i = size - 1; i >= 0; i--) {
/* 352 */         ((ListDataListener)this.listeners.get(i)).intervalRemoved(e);
/*     */       }
/*     */       
/* 355 */       if (this.selectedModelIndex >= index && this.selectedModelIndex < index + length) {
/* 356 */         if (size() == 0) {
/* 357 */           setSelectedItem(null);
/*     */         } else {
/* 359 */           setSelectedItem(getElementAt(Math.max(index - 1, 0)));
/*     */         } 
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 365 */     protected void changed(int row) { contentsChanged(row, row); }
/*     */ 
/*     */     
/*     */     private void contentsChanged(int row0, int row1) {
/* 369 */       ListDataEvent e = new ListDataEvent(this, 0, row0, row1);
/* 370 */       int size = this.listeners.size();
/* 371 */       for (int i = size - 1; i >= 0; i--) {
/* 372 */         ((ListDataListener)this.listeners.get(i)).contentsChanged(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 377 */     public Object getElementAt(int index) { return getElement(index); }
/*     */ 
/*     */ 
/*     */     
/* 381 */     public void addListDataListener(ListDataListener l) { this.listeners.add(l); }
/*     */ 
/*     */ 
/*     */     
/* 385 */     public void removeListDataListener(ListDataListener l) { this.listeners.remove(l); }
/*     */ 
/*     */ 
/*     */     
/* 389 */     public int getSize() { return size(); }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/JComboBoxBinding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */