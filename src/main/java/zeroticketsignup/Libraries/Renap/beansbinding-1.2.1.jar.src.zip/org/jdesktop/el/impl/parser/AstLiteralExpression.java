/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstLiteralExpression
/*    */   extends SimpleNode
/*    */ {
/* 19 */   public AstLiteralExpression(int id) { super(id); }
/*    */ 
/*    */ 
/*    */   
/* 23 */   public Class getType(EvaluationContext ctx) throws ELException { return String.class; }
/*    */ 
/*    */ 
/*    */   
/* 27 */   public Object getValue(EvaluationContext ctx) throws ELException { return this.image; }
/*    */ 
/*    */   
/*    */   public void setImage(String image) {
/* 31 */     if (image.indexOf('\\') == -1) {
/* 32 */       this.image = image;
/*    */       return;
/*    */     } 
/* 35 */     int size = image.length();
/* 36 */     StringBuffer buf = new StringBuffer(size);
/* 37 */     for (int i = 0; i < size; i++) {
/* 38 */       char c = image.charAt(i);
/* 39 */       if (c == '\\' && i + 1 < size) {
/* 40 */         char c1 = image.charAt(i + 1);
/* 41 */         if (c1 == '\\' || c1 == '"' || c1 == '\'' || c1 == '#' || c1 == '$') {
/*    */           
/* 43 */           c = c1;
/* 44 */           i++;
/*    */         } 
/*    */       } 
/* 47 */       buf.append(c);
/*    */     } 
/* 49 */     this.image = buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstLiteralExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */