/*    */ package org.jdesktop.beansbinding;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Validator<T>
/*    */ {
/*    */   public abstract Result validate(T paramT);
/*    */   
/*    */   public class Result
/*    */   {
/*    */     private final Object errorCode;
/*    */     private final String description;
/*    */     
/*    */     public Result(Object errorCode, String description) {
/* 37 */       this.description = description;
/* 38 */       this.errorCode = errorCode;
/*    */     }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 47 */     public Object getErrorCode() { return this.errorCode; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 56 */     public String getDescription() { return this.description; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 69 */     public String toString() { return getClass().getName() + " [" + "errorCode=" + this.errorCode + ", description=" + this.description + "]"; }
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/Validator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */