/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstLessThanEqual
/*    */   extends BooleanNode
/*    */ {
/* 20 */   public AstLessThanEqual(int id) { super(id); }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 25 */     Object obj0 = this.children[0].getValue(ctx);
/* 26 */     if (obj0 == ELContext.UNRESOLVABLE_RESULT) {
/* 27 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 29 */     Object obj1 = this.children[1].getValue(ctx);
/* 30 */     if (obj1 == ELContext.UNRESOLVABLE_RESULT) {
/* 31 */       return ELContext.UNRESOLVABLE_RESULT;
/*    */     }
/* 33 */     if (obj0 == obj1) {
/* 34 */       return Boolean.TRUE;
/*    */     }
/* 36 */     if (obj0 == null || obj1 == null) {
/* 37 */       return Boolean.FALSE;
/*    */     }
/* 39 */     return (compare(obj0, obj1) <= 0) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstLessThanEqual.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */