/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface ELParserTreeConstants
/*    */ {
/*    */   public static final int JJTCOMPOSITEEXPRESSION = 0;
/*    */   public static final int JJTLITERALEXPRESSION = 1;
/*    */   public static final int JJTDEFERREDEXPRESSION = 2;
/*    */   public static final int JJTDYNAMICEXPRESSION = 3;
/*    */   public static final int JJTVOID = 4;
/*    */   public static final int JJTCHOICE = 5;
/*    */   public static final int JJTOR = 6;
/*    */   public static final int JJTAND = 7;
/*    */   public static final int JJTEQUAL = 8;
/*    */   public static final int JJTNOTEQUAL = 9;
/*    */   public static final int JJTLESSTHAN = 10;
/*    */   public static final int JJTGREATERTHAN = 11;
/*    */   public static final int JJTLESSTHANEQUAL = 12;
/*    */   public static final int JJTGREATERTHANEQUAL = 13;
/*    */   public static final int JJTPLUS = 14;
/*    */   public static final int JJTMINUS = 15;
/*    */   public static final int JJTMULT = 16;
/*    */   public static final int JJTDIV = 17;
/*    */   public static final int JJTMOD = 18;
/*    */   public static final int JJTNEGATIVE = 19;
/*    */   public static final int JJTNOT = 20;
/*    */   public static final int JJTEMPTY = 21;
/*    */   public static final int JJTVALUE = 22;
/*    */   public static final int JJTDOTSUFFIX = 23;
/*    */   public static final int JJTBRACKETSUFFIX = 24;
/*    */   public static final int JJTIDENTIFIER = 25;
/*    */   public static final int JJTFUNCTION = 26;
/*    */   public static final int JJTTRUE = 27;
/*    */   public static final int JJTFALSE = 28;
/*    */   public static final int JJTFLOATINGPOINT = 29;
/*    */   public static final int JJTINTEGER = 30;
/*    */   public static final int JJTSTRING = 31;
/*    */   public static final int JJTNULL = 32;
/* 46 */   public static final String[] jjtNodeName = new String[] { "CompositeExpression", "LiteralExpression", "DeferredExpression", "DynamicExpression", "void", "Choice", "Or", "And", "Equal", "NotEqual", "LessThan", "GreaterThan", "LessThanEqual", "GreaterThanEqual", "Plus", "Minus", "Mult", "Div", "Mod", "Negative", "Not", "Empty", "Value", "DotSuffix", "BracketSuffix", "Identifier", "Function", "True", "False", "FloatingPoint", "Integer", "String", "Null" };
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/ELParserTreeConstants.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */