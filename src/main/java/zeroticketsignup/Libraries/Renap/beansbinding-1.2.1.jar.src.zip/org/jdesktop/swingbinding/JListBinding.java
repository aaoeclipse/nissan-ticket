/*     */ package org.jdesktop.swingbinding;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.concurrent.CopyOnWriteArrayList;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListModel;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.event.ListDataEvent;
/*     */ import javax.swing.event.ListDataListener;
/*     */ import org.jdesktop.beansbinding.AutoBinding;
/*     */ import org.jdesktop.beansbinding.ObjectProperty;
/*     */ import org.jdesktop.beansbinding.Property;
/*     */ import org.jdesktop.beansbinding.PropertyStateEvent;
/*     */ import org.jdesktop.beansbinding.PropertyStateListener;
/*     */ import org.jdesktop.swingbinding.impl.AbstractColumnBinding;
/*     */ import org.jdesktop.swingbinding.impl.ListBindingManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class JListBinding<E, SS, TS>
/*     */   extends AutoBinding<SS, List<E>, TS, List>
/*     */ {
/*     */   private Property<TS, ? extends JList> listP;
/*     */   private ElementsProperty<TS> elementsP;
/* 192 */   private Handler handler = new Handler();
/*     */ 
/*     */   
/*     */   private JList list;
/*     */ 
/*     */   
/*     */   private BindingListModel model;
/*     */ 
/*     */   
/*     */   private DetailBinding detailBinding;
/*     */ 
/*     */   
/*     */   private final Property DETAIL_PROPERTY;
/*     */ 
/*     */ 
/*     */   
/*     */   protected JListBinding(AutoBinding.UpdateStrategy strategy, SS sourceObject, Property<SS, List<E>> sourceListProperty, TS targetObject, Property<TS, ? extends JList> targetJListProperty, String name) {
/* 209 */     super((strategy == AutoBinding.UpdateStrategy.READ_WRITE) ? AutoBinding.UpdateStrategy.READ : strategy, sourceObject, sourceListProperty, targetObject, (Property)new ElementsProperty(), name);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 307 */     this.DETAIL_PROPERTY = new Property()
/*     */       {
/* 309 */         public Class<Object> getWriteType(Object source) { return Object.class; }
/*     */ 
/*     */ 
/*     */         
/* 313 */         public Object getValue(Object source) { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */         
/* 317 */         public void setValue(Object source, Object value) { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */         
/* 321 */         public boolean isReadable(Object source) { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */         
/* 325 */         public boolean isWriteable(Object source) { return true; }
/*     */ 
/*     */ 
/*     */         
/* 329 */         public void addPropertyStateListener(Object source, PropertyStateListener listener) { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */         
/* 333 */         public void removePropertyStateListener(Object source, PropertyStateListener listener) { throw new UnsupportedOperationException(); }
/*     */ 
/*     */ 
/*     */         
/* 337 */         public PropertyStateListener[] getPropertyStateListeners(Object source) { throw new UnsupportedOperationException(); }
/*     */       }; if (targetJListProperty == null)
/*     */       throw new IllegalArgumentException("target JList property can't be null");  this.listP = targetJListProperty;
/*     */     this.elementsP = (ElementsProperty<TS>)getTargetProperty();
/*     */     setDetailBinding(null);
/*     */   } protected void bindImpl() { this.elementsP.setAccessible(isListAccessible());
/*     */     this.listP.addPropertyStateListener(getTargetObject(), this.handler);
/*     */     this.elementsP.addPropertyStateListener(null, this.handler);
/*     */     super.bindImpl(); } protected void unbindImpl() { this.elementsP.removePropertyStateListener(null, this.handler);
/*     */     this.listP.removePropertyStateListener(getTargetObject(), this.handler);
/*     */     this.elementsP.setAccessible(false);
/*     */     cleanupForLast();
/*     */     super.unbindImpl(); } private boolean isListAccessible() { return (this.listP.isReadable(getTargetObject()) && this.listP.getValue(getTargetObject()) != null); } private boolean isListAccessible(Object value) { return (value != null && value != PropertyStateEvent.UNREADABLE); } private void cleanupForLast() { if (this.list == null)
/*     */       return; 
/*     */     resetListSelection();
/*     */     this.list.setModel(new DefaultListModel());
/*     */     this.list = null;
/*     */     this.model.setElements(null, true);
/*     */     this.model = null; } public DetailBinding setDetailBinding(Property<E, ?> detailProperty) { return setDetailBinding(detailProperty, null); } public DetailBinding setDetailBinding(Property<E, ?> detailProperty, String name) { throwIfBound();
/*     */     if (name == null && getName() != null)
/*     */       name = getName() + ".DETAIL_BINDING"; 
/*     */     this.detailBinding = (detailProperty == null) ? new DetailBinding((Property)ObjectProperty.create(), name) : new DetailBinding(detailProperty, name);
/*     */     return this.detailBinding; } public DetailBinding getDetailBinding() { return this.detailBinding; } public final class DetailBinding extends AbstractColumnBinding
/*     */   {
/* 361 */     private DetailBinding(Property<E, ?> detailProperty, String name) { super(0, detailProperty, JListBinding.this.DETAIL_PROPERTY, name); }
/*     */   }
/*     */   
/*     */   private class Handler implements PropertyStateListener {
/*     */     private Handler() {}
/*     */     
/*     */     public void propertyStateChanged(PropertyStateEvent pse) {
/* 368 */       if (!pse.getValueChanged()) {
/*     */         return;
/*     */       }
/*     */       
/* 372 */       if (pse.getSourceProperty() == JListBinding.this.listP) {
/* 373 */         JListBinding.this.cleanupForLast();
/*     */         
/* 375 */         boolean wasAccessible = JListBinding.this.isListAccessible(pse.getOldValue());
/* 376 */         boolean isAccessible = JListBinding.this.isListAccessible(pse.getNewValue());
/*     */         
/* 378 */         if (wasAccessible != isAccessible) {
/* 379 */           JListBinding.this.elementsP.setAccessible(isAccessible);
/* 380 */         } else if (JListBinding.this.elementsP.isAccessible()) {
/* 381 */           JListBinding.this.elementsP.setValueAndIgnore(null, null);
/*     */         } 
/*     */       } else {
/* 384 */         if (((ElementsProperty.ElementsPropertyStateEvent)pse).shouldIgnore()) {
/*     */           return;
/*     */         }
/*     */         
/* 388 */         if (JListBinding.this.list == null) {
/* 389 */           JListBinding.this.list = (JList)JListBinding.this.listP.getValue(JListBinding.this.getTargetObject());
/* 390 */           JListBinding.this.resetListSelection();
/* 391 */           JListBinding.this.model = new JListBinding.BindingListModel();
/* 392 */           JListBinding.this.list.setModel(JListBinding.this.model);
/*     */         } else {
/* 394 */           JListBinding.this.resetListSelection();
/*     */         } 
/*     */         
/* 397 */         JListBinding.this.model.setElements((List)pse.getNewValue(), true);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void resetListSelection() {
/* 403 */     ListSelectionModel selectionModel = this.list.getSelectionModel();
/* 404 */     selectionModel.setValueIsAdjusting(true);
/* 405 */     selectionModel.clearSelection();
/* 406 */     selectionModel.setAnchorSelectionIndex(-1);
/* 407 */     selectionModel.setLeadSelectionIndex(-1);
/* 408 */     selectionModel.setValueIsAdjusting(false);
/*     */   }
/*     */   
/*     */   private final class BindingListModel
/*     */     extends ListBindingManager
/*     */     implements ListModel
/*     */   {
/* 415 */     private final List<ListDataListener> listeners = new CopyOnWriteArrayList<ListDataListener>();
/*     */ 
/*     */ 
/*     */     
/* 419 */     protected AbstractColumnBinding[] getColBindings() { return new AbstractColumnBinding[] { this.this$0.getDetailBinding() }; }
/*     */ 
/*     */ 
/*     */     
/* 423 */     protected void allChanged() { contentsChanged(0, size()); }
/*     */ 
/*     */ 
/*     */     
/* 427 */     protected void valueChanged(int row, int column) { contentsChanged(row, row); }
/*     */ 
/*     */     
/*     */     protected void added(int index, int length) {
/* 431 */       assert length > 0;
/*     */       
/* 433 */       ListDataEvent e = new ListDataEvent(this, 1, index, index + length - 1);
/* 434 */       for (ListDataListener listener : this.listeners) {
/* 435 */         listener.intervalAdded(e);
/*     */       }
/*     */     }
/*     */     
/*     */     protected void removed(int index, int length) {
/* 440 */       assert length > 0;
/*     */       
/* 442 */       ListDataEvent e = new ListDataEvent(this, 2, index, index + length - 1);
/* 443 */       for (ListDataListener listener : this.listeners) {
/* 444 */         listener.intervalRemoved(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 449 */     protected void changed(int row) { contentsChanged(row, row); }
/*     */ 
/*     */     
/*     */     private void contentsChanged(int row0, int row1) {
/* 453 */       ListDataEvent e = new ListDataEvent(this, 0, row0, row1);
/* 454 */       for (ListDataListener listener : this.listeners) {
/* 455 */         listener.contentsChanged(e);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/* 460 */     public Object getElementAt(int index) { return valueAt(index, 0); }
/*     */ 
/*     */ 
/*     */     
/* 464 */     public void addListDataListener(ListDataListener l) { this.listeners.add(l); }
/*     */ 
/*     */ 
/*     */     
/* 468 */     public void removeListDataListener(ListDataListener l) { this.listeners.remove(l); }
/*     */ 
/*     */ 
/*     */     
/* 472 */     public int getSize() { return size(); }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/JListBinding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */