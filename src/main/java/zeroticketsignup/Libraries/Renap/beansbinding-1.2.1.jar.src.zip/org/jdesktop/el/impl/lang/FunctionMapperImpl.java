/*     */ package org.jdesktop.el.impl.lang;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.impl.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FunctionMapperImpl
/*     */   extends FunctionMapper
/*     */   implements Externalizable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  29 */   protected Map functions = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Method resolveFunction(String prefix, String localName) {
/*  38 */     if (this.functions != null) {
/*  39 */       Function f = (Function)this.functions.get(prefix + ":" + localName);
/*  40 */       return f.getMethod();
/*     */     } 
/*  42 */     return null;
/*     */   }
/*     */   
/*     */   public void addFunction(String prefix, String localName, Method m) {
/*  46 */     if (this.functions == null) {
/*  47 */       this.functions = new HashMap<Object, Object>();
/*     */     }
/*  49 */     Function f = new Function(prefix, localName, m);
/*  50 */     synchronized (this) {
/*  51 */       this.functions.put(prefix + ":" + localName, f);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   public void writeExternal(ObjectOutput out) throws IOException { out.writeObject(this.functions); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  71 */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException { this.functions = (Map)in.readObject(); }
/*     */ 
/*     */   
/*     */   public static class Function
/*     */     implements Externalizable
/*     */   {
/*     */     protected transient Method m;
/*     */     
/*     */     protected String owner;
/*     */     
/*     */     protected String name;
/*     */     protected String[] types;
/*     */     protected String prefix;
/*     */     protected String localName;
/*     */     
/*     */     public Function(String prefix, String localName, Method m) {
/*  87 */       if (localName == null) {
/*  88 */         throw new NullPointerException("LocalName cannot be null");
/*     */       }
/*  90 */       if (m == null) {
/*  91 */         throw new NullPointerException("Method cannot be null");
/*     */       }
/*  93 */       this.prefix = prefix;
/*  94 */       this.localName = localName;
/*  95 */       this.m = m;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Function() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void writeExternal(ObjectOutput out) throws IOException {
/* 109 */       out.writeUTF((this.prefix != null) ? this.prefix : "");
/* 110 */       out.writeUTF(this.localName);
/*     */       
/* 112 */       if (this.owner != null) {
/* 113 */         out.writeUTF(this.owner);
/*     */       } else {
/* 115 */         out.writeUTF(this.m.getDeclaringClass().getName());
/*     */       } 
/* 117 */       if (this.name != null) {
/* 118 */         out.writeUTF(this.name);
/*     */       } else {
/* 120 */         out.writeUTF(this.m.getName());
/*     */       } 
/* 122 */       if (this.types != null) {
/* 123 */         out.writeObject(this.types);
/*     */       } else {
/* 125 */         out.writeObject(ReflectionUtil.toTypeNameArray(this.m.getParameterTypes()));
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 137 */       this.prefix = in.readUTF();
/* 138 */       if ("".equals(this.prefix)) this.prefix = null; 
/* 139 */       this.localName = in.readUTF();
/* 140 */       this.owner = in.readUTF();
/* 141 */       this.name = in.readUTF();
/* 142 */       this.types = (String[])in.readObject();
/*     */     }
/*     */     
/*     */     public Method getMethod() {
/* 146 */       if (this.m == null) {
/*     */         try {
/* 148 */           Class<?> t = Class.forName(this.owner);
/* 149 */           Class[] p = ReflectionUtil.toTypeArray(this.types);
/* 150 */           this.m = t.getMethod(this.name, p);
/* 151 */         } catch (Exception e) {
/* 152 */           e.printStackTrace();
/*     */         } 
/*     */       }
/* 155 */       return this.m;
/*     */     }
/*     */     
/*     */     public boolean matches(String prefix, String localName) {
/* 159 */       if (this.prefix != null) {
/* 160 */         if (prefix == null) return false; 
/* 161 */         if (!this.prefix.equals(prefix)) return false; 
/*     */       } 
/* 163 */       return this.localName.equals(localName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object obj) {
/* 170 */       if (obj == this) {
/* 171 */         return true;
/*     */       }
/* 173 */       if (obj instanceof Function) {
/* 174 */         Function of = (Function)obj;
/* 175 */         return (of.prefix.equals(this.prefix) && of.localName.equals(this.localName));
/*     */       } 
/*     */       
/* 178 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 185 */     public int hashCode() { return (this.prefix + this.localName).hashCode(); }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/FunctionMapperImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */