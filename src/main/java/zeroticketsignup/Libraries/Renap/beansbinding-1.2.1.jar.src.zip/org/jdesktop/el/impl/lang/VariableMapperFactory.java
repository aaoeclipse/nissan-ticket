/*    */ package org.jdesktop.el.impl.lang;
/*    */ 
/*    */ import org.jdesktop.el.ValueExpression;
/*    */ import org.jdesktop.el.VariableMapper;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VariableMapperFactory
/*    */   extends VariableMapper
/*    */ {
/*    */   private final VariableMapper target;
/*    */   private VariableMapper momento;
/*    */   
/*    */   public VariableMapperFactory(VariableMapper target) {
/* 17 */     if (target == null) {
/* 18 */       throw new NullPointerException("Target VariableMapper cannot be null");
/*    */     }
/* 20 */     this.target = target;
/*    */   }
/*    */ 
/*    */   
/* 24 */   public VariableMapper create() { return this.momento; }
/*    */ 
/*    */   
/*    */   public ValueExpression resolveVariable(String variable) {
/* 28 */     ValueExpression expr = this.target.resolveVariable(variable);
/* 29 */     if (expr != null) {
/* 30 */       if (this.momento == null) {
/* 31 */         this.momento = new VariableMapperImpl();
/*    */       }
/* 33 */       this.momento.setVariable(variable, expr);
/*    */     } 
/* 35 */     return expr;
/*    */   }
/*    */ 
/*    */   
/* 39 */   public ValueExpression setVariable(String variable, ValueExpression expression) { throw new UnsupportedOperationException("Cannot Set Variables on Factory"); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/VariableMapperFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */