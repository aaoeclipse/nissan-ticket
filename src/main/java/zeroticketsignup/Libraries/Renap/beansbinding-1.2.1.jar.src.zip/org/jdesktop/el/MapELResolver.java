/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MapELResolver
/*     */   extends ELResolver
/*     */ {
/*  44 */   public MapELResolver() { this.isReadOnly = false; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   public MapELResolver(boolean isReadOnly) { this.isReadOnly = isReadOnly; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/*  90 */     if (context == null) {
/*  91 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  94 */     if (base != null && base instanceof Map) {
/*  95 */       context.setPropertyResolved(true);
/*  96 */       return Object.class;
/*     */     } 
/*  98 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/* 139 */     if (context == null) {
/* 140 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 143 */     if (base != null && base instanceof Map) {
/* 144 */       context.setPropertyResolved(true);
/* 145 */       Map map = (Map)base;
/* 146 */       return map.get(property);
/*     */     } 
/* 148 */     return null;
/*     */   }
/*     */   
/* 151 */   private static Class<?> theUnmodifiableMapClass = Collections.unmodifiableMap(new HashMap<Object, Object>()).getClass();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isReadOnly;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object val) {
/* 201 */     if (context == null) {
/* 202 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 205 */     if (base != null && base instanceof Map) {
/* 206 */       context.setPropertyResolved(true);
/* 207 */       Map<Object, Object> map = (Map)base;
/* 208 */       if (this.isReadOnly || map.getClass() == theUnmodifiableMapClass) {
/* 209 */         throw new PropertyNotWritableException();
/*     */       }
/* 211 */       map.put(property, val);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 256 */     if (context == null) {
/* 257 */       throw new NullPointerException();
/*     */     }
/*     */     
/* 260 */     if (base != null && base instanceof Map) {
/* 261 */       context.setPropertyResolved(true);
/* 262 */       Map map = (Map)base;
/* 263 */       return (this.isReadOnly || map.getClass() == theUnmodifiableMapClass);
/*     */     } 
/* 265 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) {
/* 309 */     if (base != null && base instanceof Map) {
/* 310 */       Map map = (Map)base;
/* 311 */       Iterator iter = map.keySet().iterator();
/* 312 */       List<FeatureDescriptor> list = new ArrayList<FeatureDescriptor>();
/* 313 */       while (iter.hasNext()) {
/* 314 */         Object key = iter.next();
/* 315 */         FeatureDescriptor descriptor = new FeatureDescriptor();
/* 316 */         String name = (key == null) ? null : key.toString();
/* 317 */         descriptor.setName(name);
/* 318 */         descriptor.setDisplayName(name);
/* 319 */         descriptor.setShortDescription("");
/* 320 */         descriptor.setExpert(false);
/* 321 */         descriptor.setHidden(false);
/* 322 */         descriptor.setPreferred(true);
/* 323 */         descriptor.setValue("type", (key == null) ? null : key.getClass());
/* 324 */         descriptor.setValue("resolvableAtDesignTime", Boolean.TRUE);
/* 325 */         list.add(descriptor);
/*     */       } 
/* 327 */       return list.iterator();
/*     */     } 
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 349 */     if (base != null && base instanceof Map) {
/* 350 */       return Object.class;
/*     */     }
/* 352 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/MapELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */