package org.jdesktop.el;

public abstract class VariableMapper {
  public abstract ValueExpression resolveVariable(String paramString);
  
  public abstract ValueExpression setVariable(String paramString, ValueExpression paramValueExpression);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/VariableMapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */