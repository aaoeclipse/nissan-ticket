/*     */ package org.jdesktop.el.impl;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.Expression;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.PropertyNotFoundException;
/*     */ import org.jdesktop.el.PropertyNotWritableException;
/*     */ import org.jdesktop.el.ValueExpression;
/*     */ import org.jdesktop.el.VariableMapper;
/*     */ import org.jdesktop.el.impl.lang.ELSupport;
/*     */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*     */ import org.jdesktop.el.impl.lang.ExpressionBuilder;
/*     */ import org.jdesktop.el.impl.parser.Node;
/*     */ import org.jdesktop.el.impl.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ValueExpressionImpl
/*     */   extends ValueExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class expectedType;
/*     */   private String expr;
/*     */   private FunctionMapper fnMapper;
/*     */   private VariableMapper varMapper;
/*     */   private transient Node node;
/*     */   
/*     */   public ValueExpressionImpl() {}
/*     */   
/*     */   public ValueExpressionImpl(String expr, Node node, FunctionMapper fnMapper, VariableMapper varMapper, Class expectedType) {
/* 103 */     this.expr = expr;
/* 104 */     this.node = node;
/* 105 */     this.fnMapper = fnMapper;
/* 106 */     this.varMapper = varMapper;
/* 107 */     this.expectedType = expectedType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 116 */   public boolean equals(Object obj) { return (obj instanceof ValueExpressionImpl && obj.hashCode() == hashCode()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 126 */   public Class getExpectedType() { return this.expectedType; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 140 */   public String getExpressionString() { return this.expr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node getNode() throws ELException {
/* 148 */     if (this.node == null) {
/* 149 */       this.node = ExpressionBuilder.createNode(this.expr);
/*     */     }
/* 151 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class getType(ELContext context) throws PropertyNotFoundException, ELException {
/* 161 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this);
/*     */     
/* 163 */     return getNode().getType(ctx);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context) throws PropertyNotFoundException, ELException {
/* 173 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this);
/*     */     
/* 175 */     Object value = getNode().getValue(ctx);
/* 176 */     if (this.expectedType != null) {
/* 177 */       return ELSupport.coerceToType(value, this.expectedType);
/*     */     }
/* 179 */     return value;
/*     */   }
/*     */   
/*     */   public Expression.Result getResult(ELContext context, boolean trackResolvedObjects) throws PropertyNotFoundException, ELException {
/*     */     List<Expression.ResolvedProperty> resolvedProperties;
/* 184 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this, trackResolvedObjects);
/* 185 */     Object value = getNode().getValue(ctx);
/*     */ 
/*     */ 
/*     */     
/* 189 */     if (trackResolvedObjects) {
/* 190 */       resolvedProperties = ctx.getResolvedProperties();
/*     */     } else {
/* 192 */       resolvedProperties = Collections.emptyList();
/*     */     } 
/*     */     
/* 195 */     if (value == ELContext.UNRESOLVABLE_RESULT) {
/* 196 */       return new Expression.Result(Expression.Result.Type.UNRESOLVABLE, null, resolvedProperties);
/*     */     }
/*     */     
/* 199 */     value = ELSupport.coerceToType(value, this.expectedType);
/* 200 */     return new Expression.Result(Expression.Result.Type.VALUE, value, resolvedProperties);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 209 */   public int hashCode() { return this.expr.hashCode(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isLiteralText() {
/*     */     try {
/* 219 */       return getNode() instanceof org.jdesktop.el.impl.parser.AstLiteralExpression;
/* 220 */     } catch (ELException ele) {
/* 221 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context) throws PropertyNotFoundException, ELException {
/* 232 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this);
/*     */     
/* 234 */     return getNode().isReadOnly(ctx);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 239 */     this.expr = in.readUTF();
/* 240 */     String type = in.readUTF();
/* 241 */     if (!"".equals(type)) {
/* 242 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 244 */     this.fnMapper = (FunctionMapper)in.readObject();
/* 245 */     this.varMapper = (VariableMapper)in.readObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object value) throws PropertyNotFoundException, PropertyNotWritableException, ELException {
/* 257 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this);
/*     */     
/* 259 */     getNode().setValue(ctx, value);
/*     */   }
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 263 */     out.writeUTF(this.expr);
/* 264 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/*     */     
/* 266 */     out.writeObject(this.fnMapper);
/* 267 */     out.writeObject(this.varMapper);
/*     */   }
/*     */ 
/*     */   
/* 271 */   public String toString() { return "ValueExpression[" + this.expr + "]"; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/ValueExpressionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */