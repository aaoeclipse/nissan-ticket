/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleCharStream
/*     */ {
/*     */   public static final boolean staticFlag = false;
/*     */   int bufsize;
/*     */   int available;
/*     */   int tokenBegin;
/*     */   public int bufpos;
/*     */   protected int[] bufline;
/*     */   protected int[] bufcolumn;
/*     */   protected int column;
/*     */   protected int line;
/*     */   protected boolean prevCharIsCR;
/*     */   protected boolean prevCharIsLF;
/*     */   protected Reader inputStream;
/*     */   protected char[] buffer;
/*     */   protected int maxNextCharInd;
/*     */   protected int inBuf;
/*     */   
/*     */   protected void ExpandBuff(boolean wrapAround) {
/*  37 */     char[] newbuffer = new char[this.bufsize + 2048];
/*  38 */     int[] newbufline = new int[this.bufsize + 2048];
/*  39 */     int[] newbufcolumn = new int[this.bufsize + 2048];
/*     */ 
/*     */     
/*     */     try {
/*  43 */       if (wrapAround)
/*     */       {
/*  45 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  46 */         System.arraycopy(this.buffer, 0, newbuffer, this.bufsize - this.tokenBegin, this.bufpos);
/*     */         
/*  48 */         this.buffer = newbuffer;
/*     */         
/*  50 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  51 */         System.arraycopy(this.bufline, 0, newbufline, this.bufsize - this.tokenBegin, this.bufpos);
/*  52 */         this.bufline = newbufline;
/*     */         
/*  54 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  55 */         System.arraycopy(this.bufcolumn, 0, newbufcolumn, this.bufsize - this.tokenBegin, this.bufpos);
/*  56 */         this.bufcolumn = newbufcolumn;
/*     */         
/*  58 */         this.maxNextCharInd = this.bufpos += this.bufsize - this.tokenBegin;
/*     */       }
/*     */       else
/*     */       {
/*  62 */         System.arraycopy(this.buffer, this.tokenBegin, newbuffer, 0, this.bufsize - this.tokenBegin);
/*  63 */         this.buffer = newbuffer;
/*     */         
/*  65 */         System.arraycopy(this.bufline, this.tokenBegin, newbufline, 0, this.bufsize - this.tokenBegin);
/*  66 */         this.bufline = newbufline;
/*     */         
/*  68 */         System.arraycopy(this.bufcolumn, this.tokenBegin, newbufcolumn, 0, this.bufsize - this.tokenBegin);
/*  69 */         this.bufcolumn = newbufcolumn;
/*     */         
/*  71 */         this.maxNextCharInd = this.bufpos -= this.tokenBegin;
/*     */       }
/*     */     
/*  74 */     } catch (Throwable t) {
/*     */       
/*  76 */       throw new Error(t.getMessage());
/*     */     } 
/*     */ 
/*     */     
/*  80 */     this.bufsize += 2048;
/*  81 */     this.available = this.bufsize;
/*  82 */     this.tokenBegin = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void FillBuff() throws IOException {
/*  87 */     if (this.maxNextCharInd == this.available)
/*     */     {
/*  89 */       if (this.available == this.bufsize) {
/*     */         
/*  91 */         if (this.tokenBegin > 2048) {
/*     */           
/*  93 */           this.bufpos = this.maxNextCharInd = 0;
/*  94 */           this.available = this.tokenBegin;
/*     */         }
/*  96 */         else if (this.tokenBegin < 0) {
/*  97 */           this.bufpos = this.maxNextCharInd = 0;
/*     */         } else {
/*  99 */           ExpandBuff(false);
/*     */         } 
/* 101 */       } else if (this.available > this.tokenBegin) {
/* 102 */         this.available = this.bufsize;
/* 103 */       } else if (this.tokenBegin - this.available < 2048) {
/* 104 */         ExpandBuff(true);
/*     */       } else {
/* 106 */         this.available = this.tokenBegin;
/*     */       } 
/*     */     }
/*     */     try {
/*     */       int i;
/* 111 */       if ((i = this.inputStream.read(this.buffer, this.maxNextCharInd, this.available - this.maxNextCharInd)) == -1) {
/*     */ 
/*     */         
/* 114 */         this.inputStream.close();
/* 115 */         throw new IOException();
/*     */       } 
/*     */       
/* 118 */       this.maxNextCharInd += i;
/*     */       
/*     */       return;
/* 121 */     } catch (IOException e) {
/* 122 */       this.bufpos--;
/* 123 */       backup(0);
/* 124 */       if (this.tokenBegin == -1)
/* 125 */         this.tokenBegin = this.bufpos; 
/* 126 */       throw e;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public char BeginToken() throws IOException {
/* 132 */     this.tokenBegin = -1;
/* 133 */     char c = readChar();
/* 134 */     this.tokenBegin = this.bufpos;
/*     */     
/* 136 */     return c;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void UpdateLineColumn(char c) {
/* 141 */     this.column++;
/*     */     
/* 143 */     if (this.prevCharIsLF) {
/*     */       
/* 145 */       this.prevCharIsLF = false;
/* 146 */       this.line += (this.column = 1);
/*     */     }
/* 148 */     else if (this.prevCharIsCR) {
/*     */       
/* 150 */       this.prevCharIsCR = false;
/* 151 */       if (c == '\n') {
/*     */         
/* 153 */         this.prevCharIsLF = true;
/*     */       } else {
/*     */         
/* 156 */         this.line += (this.column = 1);
/*     */       } 
/*     */     } 
/* 159 */     switch (c) {
/*     */       
/*     */       case '\r':
/* 162 */         this.prevCharIsCR = true;
/*     */         break;
/*     */       case '\n':
/* 165 */         this.prevCharIsLF = true;
/*     */         break;
/*     */       case '\t':
/* 168 */         this.column--;
/* 169 */         this.column += 8 - (this.column & 0x7);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 175 */     this.bufline[this.bufpos] = this.line;
/* 176 */     this.bufcolumn[this.bufpos] = this.column;
/*     */   }
/*     */ 
/*     */   
/*     */   public char readChar() throws IOException {
/* 181 */     if (this.inBuf > 0) {
/*     */       
/* 183 */       this.inBuf--;
/*     */       
/* 185 */       if (++this.bufpos == this.bufsize) {
/* 186 */         this.bufpos = 0;
/*     */       }
/* 188 */       return this.buffer[this.bufpos];
/*     */     } 
/*     */     
/* 191 */     if (++this.bufpos >= this.maxNextCharInd) {
/* 192 */       FillBuff();
/*     */     }
/* 194 */     char c = this.buffer[this.bufpos];
/*     */     
/* 196 */     UpdateLineColumn(c);
/* 197 */     return c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 206 */   public int getColumn() { return this.bufcolumn[this.bufpos]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   public int getLine() { return this.bufline[this.bufpos]; }
/*     */ 
/*     */ 
/*     */   
/* 219 */   public int getEndColumn() { return this.bufcolumn[this.bufpos]; }
/*     */ 
/*     */ 
/*     */   
/* 223 */   public int getEndLine() { return this.bufline[this.bufpos]; }
/*     */ 
/*     */ 
/*     */   
/* 227 */   public int getBeginColumn() { return this.bufcolumn[this.tokenBegin]; }
/*     */ 
/*     */ 
/*     */   
/* 231 */   public int getBeginLine() { return this.bufline[this.tokenBegin]; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void backup(int amount) {
/* 236 */     this.inBuf += amount;
/* 237 */     if (this.bufpos -= amount < 0)
/* 238 */       this.bufpos += this.bufsize;  } public SimpleCharStream(Reader dstream, int startline, int startcolumn, int buffersize) { this.bufpos = -1; this.column = 0;
/*     */     this.line = 1;
/*     */     this.prevCharIsCR = false;
/*     */     this.prevCharIsLF = false;
/*     */     this.maxNextCharInd = 0;
/*     */     this.inBuf = 0;
/* 244 */     this.inputStream = dstream;
/* 245 */     this.line = startline;
/* 246 */     this.column = startcolumn - 1;
/*     */     
/* 248 */     this.available = this.bufsize = buffersize;
/* 249 */     this.buffer = new char[buffersize];
/* 250 */     this.bufline = new int[buffersize];
/* 251 */     this.bufcolumn = new int[buffersize]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 257 */   public SimpleCharStream(Reader dstream, int startline, int startcolumn) { this(dstream, startline, startcolumn, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   public SimpleCharStream(Reader dstream) { this(dstream, 1, 1, 4096); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReInit(Reader dstream, int startline, int startcolumn, int buffersize) {
/* 267 */     this.inputStream = dstream;
/* 268 */     this.line = startline;
/* 269 */     this.column = startcolumn - 1;
/*     */     
/* 271 */     if (this.buffer == null || buffersize != this.buffer.length) {
/*     */       
/* 273 */       this.available = this.bufsize = buffersize;
/* 274 */       this.buffer = new char[buffersize];
/* 275 */       this.bufline = new int[buffersize];
/* 276 */       this.bufcolumn = new int[buffersize];
/*     */     } 
/* 278 */     this.prevCharIsLF = this.prevCharIsCR = false;
/* 279 */     this.tokenBegin = this.inBuf = this.maxNextCharInd = 0;
/* 280 */     this.bufpos = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 286 */   public void ReInit(Reader dstream, int startline, int startcolumn) { ReInit(dstream, startline, startcolumn, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 291 */   public void ReInit(Reader dstream) { ReInit(dstream, 1, 1, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 296 */   public SimpleCharStream(InputStream dstream, int startline, int startcolumn, int buffersize) { this(new InputStreamReader(dstream), startline, startcolumn, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 302 */   public SimpleCharStream(InputStream dstream, int startline, int startcolumn) { this(dstream, startline, startcolumn, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 307 */   public SimpleCharStream(InputStream dstream) { this(dstream, 1, 1, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 313 */   public void ReInit(InputStream dstream, int startline, int startcolumn, int buffersize) { ReInit(new InputStreamReader(dstream), startline, startcolumn, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 318 */   public void ReInit(InputStream dstream) { ReInit(dstream, 1, 1, 4096); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 323 */   public void ReInit(InputStream dstream, int startline, int startcolumn) { ReInit(dstream, startline, startcolumn, 4096); }
/*     */ 
/*     */   
/*     */   public String GetImage() {
/* 327 */     if (this.bufpos >= this.tokenBegin) {
/* 328 */       return new String(this.buffer, this.tokenBegin, this.bufpos - this.tokenBegin + 1);
/*     */     }
/* 330 */     return new String(this.buffer, this.tokenBegin, this.bufsize - this.tokenBegin) + new String(this.buffer, 0, this.bufpos + 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char[] GetSuffix(int len) {
/* 336 */     char[] ret = new char[len];
/*     */     
/* 338 */     if (this.bufpos + 1 >= len) {
/* 339 */       System.arraycopy(this.buffer, this.bufpos - len + 1, ret, 0, len);
/*     */     } else {
/*     */       
/* 342 */       System.arraycopy(this.buffer, this.bufsize - len - this.bufpos - 1, ret, 0, len - this.bufpos - 1);
/*     */       
/* 344 */       System.arraycopy(this.buffer, 0, ret, len - this.bufpos - 1, this.bufpos + 1);
/*     */     } 
/*     */     
/* 347 */     return ret;
/*     */   }
/*     */ 
/*     */   
/*     */   public void Done() {
/* 352 */     this.buffer = null;
/* 353 */     this.bufline = null;
/* 354 */     this.bufcolumn = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void adjustBeginLineColumn(int newLine, int newCol) {
/* 362 */     int len, start = this.tokenBegin;
/*     */ 
/*     */     
/* 365 */     if (this.bufpos >= this.tokenBegin) {
/*     */       
/* 367 */       len = this.bufpos - this.tokenBegin + this.inBuf + 1;
/*     */     }
/*     */     else {
/*     */       
/* 371 */       len = this.bufsize - this.tokenBegin + this.bufpos + 1 + this.inBuf;
/*     */     } 
/*     */     
/* 374 */     int i = 0, j = 0, k = 0;
/* 375 */     int nextColDiff = 0, columnDiff = 0;
/*     */ 
/*     */     
/* 378 */     while (i < len && this.bufline[j = start % this.bufsize] == this.bufline[k = ++start % this.bufsize]) {
/*     */       
/* 380 */       this.bufline[j] = newLine;
/* 381 */       nextColDiff = columnDiff + this.bufcolumn[k] - this.bufcolumn[j];
/* 382 */       this.bufcolumn[j] = newCol + columnDiff;
/* 383 */       columnDiff = nextColDiff;
/* 384 */       i++;
/*     */     } 
/*     */     
/* 387 */     if (i < len) {
/*     */       
/* 389 */       this.bufline[j] = newLine++;
/* 390 */       this.bufcolumn[j] = newCol + columnDiff;
/*     */       
/* 392 */       while (i++ < len) {
/*     */         
/* 394 */         if (this.bufline[j = start % this.bufsize] != this.bufline[++start % this.bufsize]) {
/* 395 */           this.bufline[j] = newLine++; continue;
/*     */         } 
/* 397 */         this.bufline[j] = newLine;
/*     */       } 
/*     */     } 
/*     */     
/* 401 */     this.line = this.bufline[j];
/* 402 */     this.column = this.bufcolumn[j];
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/SimpleCharStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */