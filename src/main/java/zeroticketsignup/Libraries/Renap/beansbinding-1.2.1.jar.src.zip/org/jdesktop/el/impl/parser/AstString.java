/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstString
/*    */   extends SimpleNode
/*    */ {
/*    */   private String string;
/*    */   
/* 19 */   public AstString(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getString() {
/* 25 */     if (this.string == null) {
/* 26 */       this.string = this.image.substring(1, this.image.length() - 1);
/*    */     }
/* 28 */     return this.string;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 33 */   public Class getType(EvaluationContext ctx) throws ELException { return String.class; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 38 */   public Object getValue(EvaluationContext ctx) throws ELException { return getString(); }
/*    */ 
/*    */   
/*    */   public void setImage(String image) {
/* 42 */     if (image.indexOf('\\') == -1) {
/* 43 */       this.image = image;
/*    */       return;
/*    */     } 
/* 46 */     int size = image.length();
/* 47 */     StringBuffer buf = new StringBuffer(size);
/* 48 */     for (int i = 0; i < size; i++) {
/* 49 */       char c = image.charAt(i);
/* 50 */       if (c == '\\' && i + 1 < size) {
/* 51 */         char c1 = image.charAt(i + 1);
/* 52 */         if (c1 == '\\' || c1 == '"' || c1 == '\'' || c1 == '#' || c1 == '$') {
/*    */           
/* 54 */           c = c1;
/* 55 */           i++;
/*    */         } 
/*    */       } 
/* 58 */       buf.append(c);
/*    */     } 
/* 60 */     this.image = buf.toString();
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstString.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */