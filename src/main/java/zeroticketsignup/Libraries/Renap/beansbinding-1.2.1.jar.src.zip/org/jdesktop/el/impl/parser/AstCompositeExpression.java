/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstCompositeExpression
/*    */   extends SimpleNode
/*    */ {
/* 21 */   public AstCompositeExpression(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   public Class getType(EvaluationContext ctx) throws ELException { return String.class; }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 31 */     StringBuffer sb = new StringBuffer(16);
/* 32 */     Object obj = null;
/* 33 */     if (this.children != null) {
/* 34 */       for (int i = 0; i < this.children.length; i++) {
/* 35 */         obj = this.children[i].getValue(ctx);
/* 36 */         if (obj == ELContext.UNRESOLVABLE_RESULT) {
/* 37 */           return ELContext.UNRESOLVABLE_RESULT;
/*    */         }
/* 39 */         if (obj != null) {
/* 40 */           sb.append(obj);
/*    */         }
/*    */       } 
/*    */     }
/* 44 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstCompositeExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */