/*     */ package org.jdesktop.el.impl;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import org.jdesktop.el.ELContext;
/*     */ import org.jdesktop.el.ELException;
/*     */ import org.jdesktop.el.Expression;
/*     */ import org.jdesktop.el.FunctionMapper;
/*     */ import org.jdesktop.el.MethodExpression;
/*     */ import org.jdesktop.el.MethodInfo;
/*     */ import org.jdesktop.el.MethodNotFoundException;
/*     */ import org.jdesktop.el.PropertyNotFoundException;
/*     */ import org.jdesktop.el.VariableMapper;
/*     */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*     */ import org.jdesktop.el.impl.lang.ExpressionBuilder;
/*     */ import org.jdesktop.el.impl.parser.Node;
/*     */ import org.jdesktop.el.impl.util.ReflectionUtil;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MethodExpressionImpl
/*     */   extends MethodExpression
/*     */   implements Externalizable
/*     */ {
/*     */   private Class expectedType;
/*     */   private String expr;
/*     */   private FunctionMapper fnMapper;
/*     */   private VariableMapper varMapper;
/*     */   private transient Node node;
/*     */   private Class[] paramTypes;
/*     */   
/*     */   public MethodExpressionImpl() {}
/*     */   
/*     */   public MethodExpressionImpl(String expr, Node node, FunctionMapper fnMapper, VariableMapper varMapper, Class expectedType, Class[] paramTypes) {
/* 101 */     this.expr = expr;
/* 102 */     this.node = node;
/* 103 */     this.fnMapper = fnMapper;
/* 104 */     this.varMapper = varMapper;
/* 105 */     this.expectedType = expectedType;
/* 106 */     this.paramTypes = paramTypes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   public boolean equals(Object obj) { return (obj instanceof MethodExpressionImpl && obj.hashCode() == hashCode()); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 163 */   public String getExpressionString() { return this.expr; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MethodInfo getMethodInfo(ELContext context) throws PropertyNotFoundException, MethodNotFoundException, ELException {
/* 191 */     Node n = getNode();
/* 192 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this);
/*     */     
/* 194 */     return n.getMethodInfo(ctx, this.paramTypes);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Node getNode() throws ELException {
/* 202 */     if (this.node == null) {
/* 203 */       this.node = ExpressionBuilder.createNode(this.expr);
/*     */     }
/* 205 */     return this.node;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 226 */   public int hashCode() { return this.expr.hashCode(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object invoke(ELContext context, Object[] params) throws PropertyNotFoundException, MethodNotFoundException, ELException {
/* 262 */     EvaluationContext ctx = new EvaluationContext(context, this.fnMapper, this.varMapper, (Expression)this);
/*     */     
/* 264 */     return getNode().invoke(ctx, this.paramTypes, params);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
/* 274 */     this.expr = in.readUTF();
/* 275 */     String type = in.readUTF();
/* 276 */     if (!"".equals(type)) {
/* 277 */       this.expectedType = ReflectionUtil.forName(type);
/*     */     }
/* 279 */     this.paramTypes = ReflectionUtil.toTypeArray((String[])in.readObject());
/*     */     
/* 281 */     this.fnMapper = (FunctionMapper)in.readObject();
/* 282 */     this.varMapper = (VariableMapper)in.readObject();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeExternal(ObjectOutput out) throws IOException {
/* 291 */     out.writeUTF(this.expr);
/* 292 */     out.writeUTF((this.expectedType != null) ? this.expectedType.getName() : "");
/*     */     
/* 294 */     out.writeObject(ReflectionUtil.toTypeNameArray(this.paramTypes));
/* 295 */     out.writeObject(this.fnMapper);
/* 296 */     out.writeObject(this.varMapper);
/*     */   }
/*     */ 
/*     */   
/* 300 */   public boolean isLiteralText() { return false; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/MethodExpressionImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */