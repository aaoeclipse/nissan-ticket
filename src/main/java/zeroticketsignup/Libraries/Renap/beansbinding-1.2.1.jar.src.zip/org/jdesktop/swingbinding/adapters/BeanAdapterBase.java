/*     */ package org.jdesktop.swingbinding.adapters;
/*     */ 
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.beans.PropertyChangeSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BeanAdapterBase
/*     */ {
/*     */   protected final String property;
/*     */   private PropertyChangeSupport support;
/*     */   
/*     */   protected BeanAdapterBase(String property) {
/*  18 */     assert property != null;
/*  19 */     this.property = property.intern();
/*     */   }
/*     */   
/*     */   protected void listeningStarted() {}
/*     */   
/*     */   protected void listeningStopped() {}
/*     */   
/*  26 */   protected final boolean isListening() { return (this.support == null) ? false : (((this.support.getPropertyChangeListeners()).length > 0)); }
/*     */ 
/*     */   
/*     */   public final void addPropertyChangeListener(PropertyChangeListener listener) {
/*  30 */     if (listener == null) {
/*     */       return;
/*     */     }
/*     */     
/*  34 */     boolean wasListening = isListening();
/*     */     
/*  36 */     if (this.support == null) {
/*  37 */       this.support = new PropertyChangeSupport(this);
/*     */     }
/*     */     
/*  40 */     this.support.addPropertyChangeListener(listener);
/*     */     
/*  42 */     if (!wasListening) {
/*  43 */       listeningStarted();
/*     */     }
/*     */   }
/*     */   
/*     */   public final void removePropertyChangeListener(PropertyChangeListener listener) {
/*  48 */     if (listener == null || this.support == null) {
/*     */       return;
/*     */     }
/*     */     
/*  52 */     boolean wasListening = isListening();
/*  53 */     this.support.removePropertyChangeListener(listener);
/*     */     
/*  55 */     if (wasListening && !isListening()) {
/*  56 */       listeningStopped();
/*     */     }
/*     */   }
/*     */   
/*     */   public final PropertyChangeListener[] getPropertyChangeListeners() {
/*  61 */     if (this.support == null) {
/*  62 */       return new PropertyChangeListener[0];
/*     */     }
/*     */     
/*  65 */     return this.support.getPropertyChangeListeners();
/*     */   }
/*     */   
/*     */   public final void addPropertyChangeListener(String property, PropertyChangeListener listener) {
/*  69 */     if (listener == null || property == null || property.intern() != this.property) {
/*     */       return;
/*     */     }
/*     */     
/*  73 */     boolean wasListening = isListening();
/*     */     
/*  75 */     if (this.support == null) {
/*  76 */       this.support = new PropertyChangeSupport(this);
/*     */     }
/*     */     
/*  79 */     this.support.addPropertyChangeListener(property, listener);
/*     */     
/*  81 */     if (!wasListening) {
/*  82 */       listeningStarted();
/*     */     }
/*     */   }
/*     */   
/*     */   public final void removePropertyChangeListener(String property, PropertyChangeListener listener) {
/*  87 */     if (listener == null || this.support == null || property == null || property.intern() != this.property) {
/*     */       return;
/*     */     }
/*     */     
/*  91 */     boolean wasListening = isListening();
/*  92 */     this.support.removePropertyChangeListener(property, listener);
/*     */     
/*  94 */     if (wasListening && !isListening()) {
/*  95 */       listeningStopped();
/*     */     }
/*     */   }
/*     */   
/*     */   public final PropertyChangeListener[] getPropertyChangeListeners(String property) {
/* 100 */     if (this.support == null || property == null || property.intern() != this.property) {
/* 101 */       return new PropertyChangeListener[0];
/*     */     }
/*     */     
/* 104 */     return this.support.getPropertyChangeListeners(property);
/*     */   }
/*     */   
/*     */   protected final void firePropertyChange(Object oldValue, Object newValue) {
/* 108 */     if (this.support == null) {
/*     */       return;
/*     */     }
/*     */     
/* 112 */     this.support.firePropertyChange(this.property, oldValue, newValue);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/BeanAdapterBase.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */