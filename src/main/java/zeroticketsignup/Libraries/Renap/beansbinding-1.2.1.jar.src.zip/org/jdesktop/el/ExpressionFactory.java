package org.jdesktop.el;

public abstract class ExpressionFactory {
  public abstract ValueExpression createValueExpression(ELContext paramELContext, String paramString, Class<?> paramClass);
  
  public abstract ValueExpression createValueExpression(Object paramObject, Class<?> paramClass);
  
  public abstract MethodExpression createMethodExpression(ELContext paramELContext, String paramString, Class<?> paramClass, Class<?>[] paramArrayOfClass);
  
  public abstract Object coerceToType(Object paramObject, Class<?> paramClass);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/ExpressionFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */