/*    */ package org.jdesktop.swingbinding.adapters;
/*    */ 
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JSpinner;
/*    */ import javax.swing.event.ChangeEvent;
/*    */ import javax.swing.event.ChangeListener;
/*    */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class JSpinnerAdapterProvider
/*    */   implements BeanAdapterProvider
/*    */ {
/*    */   private static final String VALUE_P = "value";
/*    */   
/*    */   public static final class Adapter
/*    */     extends BeanAdapterBase
/*    */   {
/*    */     private JSpinner spinner;
/*    */     private Handler handler;
/*    */     private Object cachedValue;
/*    */     
/*    */     private Adapter(JSpinner spinner) {
/* 26 */       super("value");
/* 27 */       this.spinner = spinner;
/*    */     }
/*    */ 
/*    */     
/* 31 */     public Object getValue() { return this.spinner.getValue(); }
/*    */ 
/*    */ 
/*    */     
/* 35 */     public void setValue(Object value) { this.spinner.setValue(value); }
/*    */ 
/*    */     
/*    */     protected void listeningStarted() {
/* 39 */       this.handler = new Handler();
/* 40 */       this.cachedValue = getValue();
/* 41 */       this.spinner.addChangeListener(this.handler);
/* 42 */       this.spinner.addPropertyChangeListener("model", this.handler);
/*    */     }
/*    */     
/*    */     protected void listeningStopped() {
/* 46 */       this.spinner.removeChangeListener(this.handler);
/* 47 */       this.spinner.removePropertyChangeListener("model", this.handler);
/* 48 */       this.handler = null;
/*    */     }
/*    */     
/*    */     private class Handler implements ChangeListener, PropertyChangeListener {
/*    */       private void spinnerValueChanged() {
/* 53 */         Object oldValue = JSpinnerAdapterProvider.Adapter.this.cachedValue;
/* 54 */         JSpinnerAdapterProvider.Adapter.this.cachedValue = JSpinnerAdapterProvider.Adapter.this.getValue();
/* 55 */         JSpinnerAdapterProvider.Adapter.this.firePropertyChange(oldValue, JSpinnerAdapterProvider.Adapter.this.cachedValue);
/*    */       }
/*    */ 
/*    */       
/* 59 */       public void stateChanged(ChangeEvent ce) { spinnerValueChanged(); }
/*    */       
/*    */       private Handler() {}
/*    */       
/* 63 */       public void propertyChange(PropertyChangeEvent pe) { spinnerValueChanged(); }
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 69 */   public boolean providesAdapter(Class<?> type, String property) { return (JSpinner.class.isAssignableFrom(type) && property == "value"); }
/*    */ 
/*    */   
/*    */   public Object createAdapter(Object source, String property) {
/* 73 */     if (!providesAdapter(source.getClass(), property)) {
/* 74 */       throw new IllegalArgumentException();
/*    */     }
/*    */     
/* 77 */     return new Adapter((JSpinner)source);
/*    */   }
/*    */ 
/*    */   
/* 81 */   public Class<?> getAdapterClass(Class<?> type) { return JSpinner.class.isAssignableFrom(type) ? Adapter.class : null; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/JSpinnerAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */