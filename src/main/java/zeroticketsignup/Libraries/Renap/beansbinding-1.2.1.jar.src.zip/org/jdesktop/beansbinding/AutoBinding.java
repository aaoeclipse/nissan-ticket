/*     */ package org.jdesktop.beansbinding;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoBinding<SS, SV, TS, TV>
/*     */   extends Binding<SS, SV, TS, TV>
/*     */ {
/*     */   private UpdateStrategy strategy;
/*     */   
/*     */   public enum UpdateStrategy
/*     */   {
/* 115 */     READ_ONCE,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     READ,
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     READ_WRITE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected AutoBinding(UpdateStrategy strategy, SS sourceObject, Property<SS, SV> sourceProperty, TS targetObject, Property<TS, TV> targetProperty, String name) {
/* 143 */     super(sourceObject, sourceProperty, targetObject, targetProperty, name);
/*     */     
/* 145 */     if (strategy == null) {
/* 146 */       throw new IllegalArgumentException("must provide update strategy");
/*     */     }
/*     */     
/* 149 */     this.strategy = strategy;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   public final UpdateStrategy getUpdateStrategy() { return this.strategy; }
/*     */ 
/*     */   
/*     */   private final void tryRefreshThenSave() {
/* 162 */     Binding.SyncFailure refreshFailure = refresh();
/* 163 */     if (refreshFailure == null) {
/* 164 */       notifySynced();
/*     */     } else {
/* 166 */       Binding.SyncFailure saveFailure = save();
/* 167 */       if (saveFailure == null) {
/* 168 */         notifySynced();
/*     */       } else {
/* 170 */         notifySyncFailed(refreshFailure);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private final void trySaveThenRefresh() {
/* 176 */     Binding.SyncFailure saveFailure = save();
/* 177 */     if (saveFailure == null) {
/* 178 */       notifySynced();
/* 179 */     } else if (saveFailure.getType() == Binding.SyncFailureType.CONVERSION_FAILED || saveFailure.getType() == Binding.SyncFailureType.VALIDATION_FAILED) {
/* 180 */       notifySyncFailed(saveFailure);
/*     */     } else {
/* 182 */       Binding.SyncFailure refreshFailure = refresh();
/* 183 */       if (refreshFailure == null) {
/* 184 */         notifySynced();
/*     */       } else {
/* 186 */         notifySyncFailed(saveFailure);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void bindImpl() {
/* 192 */     UpdateStrategy strat = getUpdateStrategy();
/*     */     
/* 194 */     if (strat == UpdateStrategy.READ_ONCE) {
/* 195 */       refreshAndNotify();
/* 196 */     } else if (strat == UpdateStrategy.READ) {
/* 197 */       refreshAndNotify();
/*     */     } else {
/* 199 */       tryRefreshThenSave();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void unbindImpl() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   protected String paramString() { return super.paramString() + ", updateStrategy=" + getUpdateStrategy(); }
/*     */ 
/*     */   
/*     */   protected void sourceChangedImpl(PropertyStateEvent pse) {
/* 219 */     if (this.strategy != UpdateStrategy.READ_ONCE)
/*     */     {
/* 221 */       if (this.strategy == UpdateStrategy.READ) {
/* 222 */         if (pse.getValueChanged()) {
/* 223 */           refreshAndNotify();
/*     */         }
/* 225 */       } else if (this.strategy == UpdateStrategy.READ_WRITE) {
/* 226 */         if (pse.getValueChanged()) {
/* 227 */           tryRefreshThenSave();
/* 228 */         } else if (pse.isWriteable()) {
/* 229 */           saveAndNotify();
/*     */         } 
/*     */       }  } 
/*     */   }
/*     */   
/*     */   protected void targetChangedImpl(PropertyStateEvent pse) {
/* 235 */     if (this.strategy != UpdateStrategy.READ_ONCE)
/*     */     {
/* 237 */       if (this.strategy == UpdateStrategy.READ) {
/* 238 */         if (pse.getWriteableChanged() && pse.isWriteable()) {
/* 239 */           refreshAndNotify();
/*     */         }
/* 241 */       } else if (this.strategy == UpdateStrategy.READ_WRITE) {
/* 242 */         if (pse.getWriteableChanged() && pse.isWriteable()) {
/* 243 */           if (pse.getValueChanged()) {
/* 244 */             tryRefreshThenSave();
/*     */           } else {
/* 246 */             refreshAndNotify();
/*     */           } 
/* 248 */         } else if (pse.getValueChanged()) {
/* 249 */           trySaveThenRefresh();
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/beansbinding/AutoBinding.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */