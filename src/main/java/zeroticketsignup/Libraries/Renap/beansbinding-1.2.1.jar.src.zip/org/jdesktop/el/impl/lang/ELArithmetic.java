/*     */ package org.jdesktop.el.impl.lang;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import org.jdesktop.el.impl.util.MessageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ELArithmetic
/*     */ {
/*     */   public static final class BigDecimalDelegate
/*     */     extends ELArithmetic
/*     */   {
/*  23 */     protected Number add(Number num0, Number num1) { return ((BigDecimal)num0).add((BigDecimal)num1); }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/*  27 */       if (num instanceof BigDecimal)
/*  28 */         return num; 
/*  29 */       if (num instanceof BigInteger)
/*  30 */         return new BigDecimal((BigInteger)num); 
/*  31 */       return new BigDecimal(num.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*  35 */     protected Number coerce(String str) { return new BigDecimal(str); }
/*     */ 
/*     */ 
/*     */     
/*  39 */     protected Number divide(Number num0, Number num1) { return ((BigDecimal)num0).divide((BigDecimal)num1, 4); }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  44 */     protected Number subtract(Number num0, Number num1) { return ((BigDecimal)num0).subtract((BigDecimal)num1); }
/*     */ 
/*     */ 
/*     */     
/*  48 */     protected Number mod(Number num0, Number num1) { return new Double(num0.doubleValue() % num1.doubleValue()); }
/*     */ 
/*     */ 
/*     */     
/*  52 */     protected Number multiply(Number num0, Number num1) { return ((BigDecimal)num0).multiply((BigDecimal)num1); }
/*     */ 
/*     */ 
/*     */     
/*  56 */     public boolean matches(Object obj0, Object obj1) { return (obj0 instanceof BigDecimal || obj1 instanceof BigDecimal); }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class BigIntegerDelegate
/*     */     extends ELArithmetic
/*     */   {
/*  63 */     protected Number add(Number num0, Number num1) { return ((BigInteger)num0).add((BigInteger)num1); }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/*  67 */       if (num instanceof BigInteger)
/*  68 */         return num; 
/*  69 */       return new BigInteger(num.toString());
/*     */     }
/*     */ 
/*     */     
/*  73 */     protected Number coerce(String str) { return new BigInteger(str); }
/*     */ 
/*     */ 
/*     */     
/*  77 */     protected Number divide(Number num0, Number num1) { return (new BigDecimal((BigInteger)num0)).divide(new BigDecimal((BigInteger)num1), 4); }
/*     */ 
/*     */ 
/*     */     
/*  81 */     protected Number multiply(Number num0, Number num1) { return ((BigInteger)num0).multiply((BigInteger)num1); }
/*     */ 
/*     */ 
/*     */     
/*  85 */     protected Number mod(Number num0, Number num1) { return ((BigInteger)num0).mod((BigInteger)num1); }
/*     */ 
/*     */ 
/*     */     
/*  89 */     protected Number subtract(Number num0, Number num1) { return ((BigInteger)num0).subtract((BigInteger)num1); }
/*     */ 
/*     */ 
/*     */     
/*  93 */     public boolean matches(Object obj0, Object obj1) { return (obj0 instanceof BigInteger || obj1 instanceof BigInteger); }
/*     */   }
/*     */ 
/*     */   
/*     */   public static final class DoubleDelegate
/*     */     extends ELArithmetic
/*     */   {
/*     */     protected Number add(Number num0, Number num1) {
/* 101 */       if (num0 instanceof BigDecimal)
/* 102 */         return ((BigDecimal)num0).add(new BigDecimal(num1.doubleValue())); 
/* 103 */       if (num1 instanceof BigDecimal) {
/* 104 */         return (new BigDecimal(num0.doubleValue())).add((BigDecimal)num1);
/*     */       }
/* 106 */       return new Double(num0.doubleValue() + num1.doubleValue());
/*     */     }
/*     */     
/*     */     protected Number coerce(Number num) {
/* 110 */       if (num instanceof Double)
/* 111 */         return num; 
/* 112 */       if (num instanceof BigInteger)
/* 113 */         return new BigDecimal((BigInteger)num); 
/* 114 */       return new Double(num.doubleValue());
/*     */     }
/*     */ 
/*     */     
/* 118 */     protected Number coerce(String str) { return new Double(str); }
/*     */ 
/*     */ 
/*     */     
/* 122 */     protected Number divide(Number num0, Number num1) { return new Double(num0.doubleValue() / num1.doubleValue()); }
/*     */ 
/*     */ 
/*     */     
/* 126 */     protected Number mod(Number num0, Number num1) { return new Double(num0.doubleValue() % num1.doubleValue()); }
/*     */ 
/*     */ 
/*     */     
/*     */     protected Number subtract(Number num0, Number num1) {
/* 131 */       if (num0 instanceof BigDecimal)
/* 132 */         return ((BigDecimal)num0).subtract(new BigDecimal(num1.doubleValue())); 
/* 133 */       if (num1 instanceof BigDecimal) {
/* 134 */         return (new BigDecimal(num0.doubleValue())).subtract((BigDecimal)num1);
/*     */       }
/* 136 */       return new Double(num0.doubleValue() - num1.doubleValue());
/*     */     }
/*     */ 
/*     */     
/*     */     protected Number multiply(Number num0, Number num1) {
/* 141 */       if (num0 instanceof BigDecimal)
/* 142 */         return ((BigDecimal)num0).multiply(new BigDecimal(num1.doubleValue())); 
/* 143 */       if (num1 instanceof BigDecimal) {
/* 144 */         return (new BigDecimal(num0.doubleValue())).multiply((BigDecimal)num1);
/*     */       }
/* 146 */       return new Double(num0.doubleValue() * num1.doubleValue());
/*     */     }
/*     */ 
/*     */     
/* 150 */     public boolean matches(Object obj0, Object obj1) { return (obj0 instanceof Double || obj1 instanceof Double || obj0 instanceof Float || obj1 instanceof Float || (obj0 != null && (double.class == obj0.getClass() || float.class == obj0.getClass())) || (obj1 != null && (double.class == obj1.getClass() || float.class == obj1.getClass())) || (obj0 instanceof String && ELSupport.isStringFloat((String)obj0)) || (obj1 instanceof String && ELSupport.isStringFloat((String)obj1))); }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final class LongDelegate
/*     */     extends ELArithmetic
/*     */   {
/* 165 */     protected Number add(Number num0, Number num1) { return new Long(num0.longValue() + num1.longValue()); }
/*     */ 
/*     */     
/*     */     protected Number coerce(Number num) {
/* 169 */       if (num instanceof Long)
/* 170 */         return num; 
/* 171 */       return new Long(num.longValue());
/*     */     }
/*     */ 
/*     */     
/* 175 */     protected Number coerce(String str) { return new Long(str); }
/*     */ 
/*     */ 
/*     */     
/* 179 */     protected Number divide(Number num0, Number num1) { return new Long(num0.longValue() / num1.longValue()); }
/*     */ 
/*     */ 
/*     */     
/* 183 */     protected Number mod(Number num0, Number num1) { return new Long(num0.longValue() % num1.longValue()); }
/*     */ 
/*     */ 
/*     */     
/* 187 */     protected Number subtract(Number num0, Number num1) { return new Long(num0.longValue() - num1.longValue()); }
/*     */ 
/*     */ 
/*     */     
/* 191 */     protected Number multiply(Number num0, Number num1) { return new Long(num0.longValue() * num1.longValue()); }
/*     */ 
/*     */ 
/*     */     
/* 195 */     public boolean matches(Object obj0, Object obj1) { return (obj0 instanceof Long || obj1 instanceof Long); }
/*     */   }
/*     */ 
/*     */   
/* 199 */   public static final BigDecimalDelegate BIGDECIMAL = new BigDecimalDelegate();
/*     */   
/* 201 */   public static final BigIntegerDelegate BIGINTEGER = new BigIntegerDelegate();
/*     */   
/* 203 */   public static final DoubleDelegate DOUBLE = new DoubleDelegate();
/*     */   
/* 205 */   public static final LongDelegate LONG = new LongDelegate();
/*     */   
/* 207 */   private static final Long ZERO = new Long(0L);
/*     */   public static final Number add(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 210 */     if (obj0 == null && obj1 == null) {
/* 211 */       return new Long(0L);
/*     */     }
/*     */ 
/*     */     
/* 215 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 216 */       delegate = BIGDECIMAL;
/* 217 */     } else if (DOUBLE.matches(obj0, obj1)) {
/* 218 */       delegate = DOUBLE;
/* 219 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 220 */       delegate = BIGINTEGER;
/*     */     } else {
/* 222 */       delegate = LONG;
/*     */     } 
/* 224 */     Number num0 = delegate.coerce(obj0);
/* 225 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 227 */     return delegate.add(num0, num1);
/*     */   }
/*     */   public static final Number mod(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 231 */     if (obj0 == null && obj1 == null) {
/* 232 */       return new Long(0L);
/*     */     }
/*     */ 
/*     */     
/* 236 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 237 */       delegate = BIGDECIMAL;
/* 238 */     } else if (DOUBLE.matches(obj0, obj1)) {
/* 239 */       delegate = DOUBLE;
/* 240 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 241 */       delegate = BIGINTEGER;
/*     */     } else {
/* 243 */       delegate = LONG;
/*     */     } 
/* 245 */     Number num0 = delegate.coerce(obj0);
/* 246 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 248 */     return delegate.mod(num0, num1);
/*     */   }
/*     */   public static final Number subtract(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 252 */     if (obj0 == null && obj1 == null) {
/* 253 */       return new Long(0L);
/*     */     }
/*     */ 
/*     */     
/* 257 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 258 */       delegate = BIGDECIMAL;
/* 259 */     } else if (DOUBLE.matches(obj0, obj1)) {
/* 260 */       delegate = DOUBLE;
/* 261 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 262 */       delegate = BIGINTEGER;
/*     */     } else {
/* 264 */       delegate = LONG;
/*     */     } 
/* 266 */     Number num0 = delegate.coerce(obj0);
/* 267 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 269 */     return delegate.subtract(num0, num1);
/*     */   }
/*     */   public static final Number divide(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 273 */     if (obj0 == null && obj1 == null) {
/* 274 */       return ZERO;
/*     */     }
/*     */ 
/*     */     
/* 278 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 279 */       delegate = BIGDECIMAL;
/* 280 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 281 */       delegate = BIGDECIMAL;
/*     */     } else {
/* 283 */       delegate = DOUBLE;
/*     */     } 
/* 285 */     Number num0 = delegate.coerce(obj0);
/* 286 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 288 */     return delegate.divide(num0, num1);
/*     */   }
/*     */   public static final Number multiply(Object obj0, Object obj1) {
/*     */     ELArithmetic delegate;
/* 292 */     if (obj0 == null && obj1 == null) {
/* 293 */       return new Long(0L);
/*     */     }
/*     */ 
/*     */     
/* 297 */     if (BIGDECIMAL.matches(obj0, obj1)) {
/* 298 */       delegate = BIGDECIMAL;
/* 299 */     } else if (DOUBLE.matches(obj0, obj1)) {
/* 300 */       delegate = DOUBLE;
/* 301 */     } else if (BIGINTEGER.matches(obj0, obj1)) {
/* 302 */       delegate = BIGINTEGER;
/*     */     } else {
/* 304 */       delegate = LONG;
/*     */     } 
/* 306 */     Number num0 = delegate.coerce(obj0);
/* 307 */     Number num1 = delegate.coerce(obj1);
/*     */     
/* 309 */     return delegate.multiply(num0, num1);
/*     */   }
/*     */ 
/*     */   
/* 313 */   public static final boolean isNumber(Object obj) { return (obj != null && isNumberType(obj.getClass())); }
/*     */ 
/*     */ 
/*     */   
/* 317 */   public static final boolean isNumberType(Class<Long> type) { return (type == Long.class || type == long.class || type == Double.class || type == double.class || type == Byte.class || type == byte.class || type == Short.class || type == short.class || type == Integer.class || type == int.class || type == Float.class || type == float.class || type == BigInteger.class || type == BigDecimal.class); }
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Number add(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Number multiply(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */ 
/*     */   
/*     */   protected abstract Number subtract(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */   
/*     */   protected abstract Number mod(Number paramNumber1, Number paramNumber2);
/*     */ 
/*     */   
/*     */   protected abstract Number coerce(Number paramNumber);
/*     */ 
/*     */   
/*     */   protected final Number coerce(Object obj) {
/* 339 */     if (isNumber(obj)) {
/* 340 */       return coerce((Number)obj);
/*     */     }
/* 342 */     if (obj instanceof String) {
/* 343 */       return coerce((String)obj);
/*     */     }
/* 345 */     if (obj == null || "".equals(obj)) {
/* 346 */       return coerce(ZERO);
/*     */     }
/*     */     
/* 349 */     Class<?> objType = obj.getClass();
/* 350 */     if (Character.class.equals(objType) || char.class == objType) {
/* 351 */       return coerce(new Short((short)((Character)obj).charValue()));
/*     */     }
/*     */     
/* 354 */     throw new IllegalArgumentException(MessageFactory.get("el.convert", obj, objType));
/*     */   }
/*     */   
/*     */   protected abstract Number coerce(String paramString);
/*     */   
/*     */   protected abstract Number divide(Number paramNumber1, Number paramNumber2);
/*     */   
/*     */   protected abstract boolean matches(Object paramObject1, Object paramObject2);
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/lang/ELArithmetic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */