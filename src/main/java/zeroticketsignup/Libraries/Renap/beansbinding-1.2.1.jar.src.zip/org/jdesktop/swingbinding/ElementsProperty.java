/*     */ package org.jdesktop.swingbinding;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.jdesktop.beansbinding.Property;
/*     */ import org.jdesktop.beansbinding.PropertyHelper;
/*     */ import org.jdesktop.beansbinding.PropertyStateEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ElementsProperty<TS>
/*     */   extends PropertyHelper<TS, List>
/*     */ {
/*     */   private boolean accessible;
/*     */   private List list;
/*     */   
/*     */   class ElementsPropertyStateEvent
/*     */     extends PropertyStateEvent
/*     */   {
/*     */     private boolean ignore;
/*     */     
/*  28 */     public ElementsPropertyStateEvent(Property sourceProperty, Object sourceObject, boolean valueChanged, Object oldValue, Object newValue, boolean writeableChanged, boolean isWriteable) { this(sourceProperty, sourceObject, valueChanged, oldValue, newValue, writeableChanged, isWriteable, false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ElementsPropertyStateEvent(Property sourceProperty, Object sourceObject, boolean valueChanged, Object oldValue, Object newValue, boolean writeableChanged, boolean isWriteable, boolean ignore) {
/*  46 */       super(sourceProperty, sourceObject, valueChanged, oldValue, newValue, writeableChanged, isWriteable);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  54 */       this.ignore = ignore;
/*     */     }
/*     */ 
/*     */     
/*  58 */     boolean shouldIgnore() { return this.ignore; }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   ElementsProperty() { super(true); }
/*     */ 
/*     */   
/*     */   public Class<List> getWriteType(TS source) {
/*  70 */     if (!this.accessible) {
/*  71 */       throw new UnsupportedOperationException("Unwriteable");
/*     */     }
/*     */     
/*  74 */     return List.class;
/*     */   }
/*     */   
/*     */   public List getValue(TS source) {
/*  78 */     if (!this.accessible) {
/*  79 */       throw new UnsupportedOperationException("Unreadable");
/*     */     }
/*     */     
/*  82 */     return this.list;
/*     */   }
/*     */   
/*     */   private void setValue0(TS source, List list, boolean ignore) {
/*  86 */     if (!this.accessible) {
/*  87 */       throw new UnsupportedOperationException("Unwriteable");
/*     */     }
/*     */     
/*  90 */     if (this.list == list) {
/*     */       return;
/*     */     }
/*     */     
/*  94 */     List old = this.list;
/*  95 */     this.list = list;
/*     */     
/*  97 */     PropertyStateEvent pse = new ElementsPropertyStateEvent((Property)this, null, true, old, list, false, true, ignore);
/*  98 */     firePropertyStateChange(pse);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 103 */   public void setValue(TS source, List list) { setValue0(source, list, false); }
/*     */ 
/*     */ 
/*     */   
/* 107 */   void setValueAndIgnore(TS source, List list) { setValue0(source, list, true); }
/*     */ 
/*     */ 
/*     */   
/* 111 */   public boolean isReadable(TS source) { return this.accessible; }
/*     */ 
/*     */ 
/*     */   
/* 115 */   public boolean isWriteable(TS source) { return this.accessible; }
/*     */ 
/*     */ 
/*     */   
/* 119 */   public String toString() { return "elements"; }
/*     */   
/*     */   void setAccessible(boolean accessible) {
/*     */     PropertyStateEvent pse;
/* 123 */     if (this.accessible == accessible) {
/*     */       return;
/*     */     }
/*     */     
/* 127 */     this.accessible = accessible;
/*     */ 
/*     */ 
/*     */     
/* 131 */     if (accessible) {
/* 132 */       pse = new ElementsPropertyStateEvent((Property)this, null, true, PropertyStateEvent.UNREADABLE, null, true, true, true);
/*     */     } else {
/* 134 */       Object old = this.list;
/* 135 */       this.list = null;
/* 136 */       pse = new ElementsPropertyStateEvent((Property)this, null, true, old, PropertyStateEvent.UNREADABLE, true, false, true);
/*     */     } 
/*     */     
/* 139 */     firePropertyStateChange(pse);
/*     */   }
/*     */ 
/*     */   
/* 143 */   boolean isAccessible() { return this.accessible; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/ElementsProperty.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */