/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELContext;
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstLessThan
/*    */   extends BooleanNode
/*    */ {
/* 20 */   public AstLessThan(int id) { super(id); }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getValue(EvaluationContext ctx) throws ELException {
/* 25 */     Object obj0 = this.children[0].getValue(ctx);
/* 26 */     if (obj0 == ELContext.UNRESOLVABLE_RESULT)
/* 27 */       return ELContext.UNRESOLVABLE_RESULT; 
/* 28 */     if (obj0 == null) {
/* 29 */       return Boolean.FALSE;
/*    */     }
/* 31 */     Object obj1 = this.children[1].getValue(ctx);
/* 32 */     if (obj1 == ELContext.UNRESOLVABLE_RESULT)
/* 33 */       return ELContext.UNRESOLVABLE_RESULT; 
/* 34 */     if (obj1 == null) {
/* 35 */       return Boolean.FALSE;
/*    */     }
/* 37 */     return (compare(obj0, obj1) < 0) ? Boolean.TRUE : Boolean.FALSE;
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstLessThan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */