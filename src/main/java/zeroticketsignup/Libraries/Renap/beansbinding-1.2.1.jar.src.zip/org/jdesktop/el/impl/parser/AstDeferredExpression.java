/*    */ package org.jdesktop.el.impl.parser;
/*    */ 
/*    */ import org.jdesktop.el.ELException;
/*    */ import org.jdesktop.el.impl.lang.EvaluationContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class AstDeferredExpression
/*    */   extends SimpleNode
/*    */ {
/* 19 */   public AstDeferredExpression(int id) { super(id); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 24 */   public Class getType(EvaluationContext ctx) throws ELException { return this.children[0].getType(ctx); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public Object getValue(EvaluationContext ctx) throws ELException { return this.children[0].getValue(ctx); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public boolean isReadOnly(EvaluationContext ctx) throws ELException { return this.children[0].isReadOnly(ctx); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 39 */   public void setValue(EvaluationContext ctx, Object value) throws ELException { this.children[0].setValue(ctx, value); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/AstDeferredExpression.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */