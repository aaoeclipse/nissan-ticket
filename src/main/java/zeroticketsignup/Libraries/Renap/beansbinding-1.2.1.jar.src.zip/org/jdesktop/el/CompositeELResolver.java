/*     */ package org.jdesktop.el;
/*     */ 
/*     */ import java.beans.FeatureDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompositeELResolver
/*     */   extends ELResolver
/*     */ {
/*     */   public void add(ELResolver elResolver) {
/*  58 */     if (elResolver == null) {
/*  59 */       throw new NullPointerException();
/*     */     }
/*     */     
/*  62 */     this.elResolvers.add(elResolver);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getValue(ELContext context, Object base, Object property) {
/* 119 */     context.setPropertyResolved(false);
/* 120 */     int i = 0, len = this.elResolvers.size();
/*     */ 
/*     */     
/* 123 */     while (i < len) {
/* 124 */       ELResolver elResolver = this.elResolvers.get(i);
/* 125 */       Object value = elResolver.getValue(context, base, property);
/* 126 */       if (context.isPropertyResolved()) {
/* 127 */         return value;
/*     */       }
/* 129 */       i++;
/*     */     } 
/* 131 */     return ELContext.UNRESOLVABLE_RESULT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getType(ELContext context, Object base, Object property) {
/* 191 */     context.setPropertyResolved(false);
/* 192 */     int i = 0, len = this.elResolvers.size();
/*     */ 
/*     */     
/* 195 */     while (i < len) {
/* 196 */       ELResolver elResolver = this.elResolvers.get(i);
/* 197 */       Class<?> type = elResolver.getType(context, base, property);
/* 198 */       if (context.isPropertyResolved()) {
/* 199 */         return type;
/*     */       }
/* 201 */       i++;
/*     */     } 
/* 203 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setValue(ELContext context, Object base, Object property, Object val) {
/* 260 */     context.setPropertyResolved(false);
/* 261 */     int i = 0, len = this.elResolvers.size();
/*     */     
/* 263 */     while (i < len) {
/* 264 */       ELResolver elResolver = this.elResolvers.get(i);
/* 265 */       elResolver.setValue(context, base, property, val);
/* 266 */       if (context.isPropertyResolved()) {
/*     */         return;
/*     */       }
/* 269 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(ELContext context, Object base, Object property) {
/* 329 */     context.setPropertyResolved(false);
/* 330 */     int i = 0, len = this.elResolvers.size();
/*     */ 
/*     */     
/* 333 */     while (i < len) {
/* 334 */       ELResolver elResolver = this.elResolvers.get(i);
/* 335 */       boolean readOnly = elResolver.isReadOnly(context, base, property);
/* 336 */       if (context.isPropertyResolved()) {
/* 337 */         return readOnly;
/*     */       }
/* 339 */       i++;
/*     */     } 
/* 341 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 373 */   public Iterator<FeatureDescriptor> getFeatureDescriptors(ELContext context, Object base) { return new CompositeIterator(this.elResolvers.iterator(), context, base); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Class<?> getCommonPropertyType(ELContext context, Object base) {
/* 399 */     Class<?> commonPropertyType = null;
/* 400 */     Iterator<ELResolver> iter = this.elResolvers.iterator();
/* 401 */     while (iter.hasNext()) {
/* 402 */       ELResolver elResolver = iter.next();
/* 403 */       Class<?> type = elResolver.getCommonPropertyType(context, base);
/* 404 */       if (type == null) {
/*     */         continue;
/*     */       }
/* 407 */       if (commonPropertyType == null) {
/* 408 */         commonPropertyType = type; continue;
/* 409 */       }  if (commonPropertyType.isAssignableFrom(type))
/*     */         continue; 
/* 411 */       if (type.isAssignableFrom(commonPropertyType)) {
/* 412 */         commonPropertyType = type;
/*     */         continue;
/*     */       } 
/* 415 */       return null;
/*     */     } 
/*     */     
/* 418 */     return commonPropertyType;
/*     */   }
/*     */   
/* 421 */   private final ArrayList<ELResolver> elResolvers = new ArrayList<ELResolver>();
/*     */ 
/*     */   
/*     */   private static class CompositeIterator
/*     */     implements Iterator<FeatureDescriptor>
/*     */   {
/*     */     Iterator<ELResolver> compositeIter;
/*     */     
/*     */     Iterator<FeatureDescriptor> propertyIter;
/*     */     
/*     */     ELContext context;
/*     */     Object base;
/*     */     
/*     */     CompositeIterator(Iterator<ELResolver> iter, ELContext context, Object base) {
/* 435 */       this.compositeIter = iter;
/* 436 */       this.context = context;
/* 437 */       this.base = base;
/*     */     }
/*     */     
/*     */     public boolean hasNext() {
/* 441 */       if (this.propertyIter == null || !this.propertyIter.hasNext()) {
/* 442 */         while (this.compositeIter.hasNext()) {
/* 443 */           ELResolver elResolver = this.compositeIter.next();
/* 444 */           this.propertyIter = elResolver.getFeatureDescriptors(this.context, this.base);
/*     */           
/* 446 */           if (this.propertyIter != null) {
/* 447 */             return this.propertyIter.hasNext();
/*     */           }
/*     */         } 
/* 450 */         return false;
/*     */       } 
/* 452 */       return this.propertyIter.hasNext();
/*     */     }
/*     */     
/*     */     public FeatureDescriptor next() {
/* 456 */       if (this.propertyIter == null || !this.propertyIter.hasNext()) {
/* 457 */         while (this.compositeIter.hasNext()) {
/* 458 */           ELResolver elResolver = this.compositeIter.next();
/* 459 */           this.propertyIter = elResolver.getFeatureDescriptors(this.context, this.base);
/*     */           
/* 461 */           if (this.propertyIter != null) {
/* 462 */             return this.propertyIter.next();
/*     */           }
/*     */         } 
/* 465 */         return null;
/*     */       } 
/* 467 */       return this.propertyIter.next();
/*     */     }
/*     */ 
/*     */     
/* 471 */     public void remove() { throw new UnsupportedOperationException(); }
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/CompositeELResolver.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */