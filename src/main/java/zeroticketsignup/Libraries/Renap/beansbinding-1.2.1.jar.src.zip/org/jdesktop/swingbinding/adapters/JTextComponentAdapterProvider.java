/*     */ package org.jdesktop.swingbinding.adapters;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.DocumentFilter;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import org.jdesktop.beansbinding.ext.BeanAdapterProvider;
/*     */ 
/*     */ public final class JTextComponentAdapterProvider
/*     */   implements BeanAdapterProvider {
/*     */   private static final String PROPERTY_BASE = "text";
/*     */   private static final String ON_ACTION_OR_FOCUS_LOST = "text_ON_ACTION_OR_FOCUS_LOST";
/*     */   private static final String ON_FOCUS_LOST = "text_ON_FOCUS_LOST";
/*     */   
/*     */   public final class Adapter
/*     */     extends BeanAdapterBase {
/*     */     private JTextComponent component;
/*     */     private Document document;
/*     */     private boolean inDocumentListener;
/*     */     
/*     */     private Adapter(JTextComponent component, String property) {
/*  33 */       super(property);
/*  34 */       this.component = component;
/*     */     }
/*     */     private boolean installedFilter; private String cachedText; private Handler handler;
/*     */     
/*  38 */     public String getText() { return this.component.getText(); }
/*     */ 
/*     */ 
/*     */     
/*  42 */     public String getText_ON_ACTION_OR_FOCUS_LOST() { return getText(); }
/*     */ 
/*     */ 
/*     */     
/*  46 */     public String getText_ON_FOCUS_LOST() { return getText(); }
/*     */ 
/*     */     
/*     */     public void setText(String text) {
/*  50 */       this.component.setText(text);
/*  51 */       this.component.setCaretPosition(0);
/*  52 */       this.cachedText = text;
/*     */     }
/*     */ 
/*     */     
/*  56 */     public void setText_ON_ACTION_OR_FOCUS_LOST(String text) { setText(text); }
/*     */ 
/*     */ 
/*     */     
/*  60 */     public void setText_ON_FOCUS_LOST(String text) { setText(text); }
/*     */ 
/*     */     
/*     */     protected void listeningStarted() {
/*  64 */       this.cachedText = this.component.getText();
/*  65 */       this.handler = new Handler();
/*  66 */       this.component.addPropertyChangeListener("document", this.handler);
/*     */       
/*  68 */       if (this.property != "text") {
/*  69 */         this.component.addFocusListener(this.handler);
/*     */       }
/*     */       
/*  72 */       if (this.property == "text_ON_ACTION_OR_FOCUS_LOST" && this.component instanceof JTextField) {
/*  73 */         ((JTextField)this.component).addActionListener(this.handler);
/*     */       }
/*     */       
/*  76 */       this.document = this.component.getDocument();
/*  77 */       installDocumentListener();
/*     */     }
/*     */ 
/*     */     
/*     */     protected void listeningStopped() {
/*  82 */       this.cachedText = null;
/*  83 */       this.component.removePropertyChangeListener("document", this.handler);
/*     */       
/*  85 */       if (this.property != "text") {
/*  86 */         this.component.removeFocusListener(this.handler);
/*     */       }
/*     */       
/*  89 */       if (this.property == "text_ON_ACTION_OR_FOCUS_LOST" && this.component instanceof JTextField) {
/*  90 */         ((JTextField)this.component).removeActionListener(this.handler);
/*     */       }
/*     */       
/*  93 */       uninstallDocumentListener();
/*  94 */       this.document = null;
/*  95 */       this.handler = null;
/*     */     }
/*     */     
/*     */     private void installDocumentListener() {
/*  99 */       if (this.property != "text") {
/*     */         return;
/*     */       }
/*     */       
/* 103 */       boolean useDocumentFilter = !(this.component instanceof javax.swing.JFormattedTextField);
/*     */       
/* 105 */       if (useDocumentFilter && this.document instanceof AbstractDocument && ((AbstractDocument)this.document).getDocumentFilter() == null) {
/*     */         
/* 107 */         ((AbstractDocument)this.document).setDocumentFilter(this.handler);
/* 108 */         this.installedFilter = true;
/*     */       } else {
/* 110 */         this.document.addDocumentListener(this.handler);
/* 111 */         this.installedFilter = false;
/*     */       } 
/*     */     }
/*     */     
/*     */     private void uninstallDocumentListener() {
/* 116 */       if (this.property != "text") {
/*     */         return;
/*     */       }
/*     */       
/* 120 */       if (this.installedFilter) {
/* 121 */         AbstractDocument ad = (AbstractDocument)this.document;
/* 122 */         if (ad.getDocumentFilter() == this.handler) {
/* 123 */           ad.setDocumentFilter(null);
/*     */         }
/*     */       } else {
/* 126 */         this.document.removeDocumentListener(this.handler);
/*     */       } 
/*     */     }
/*     */     
/*     */     private class Handler extends DocumentFilter implements ActionListener, DocumentListener, FocusListener, PropertyChangeListener {
/*     */       private Handler() {}
/*     */       
/*     */       private void updateText() {
/* 134 */         Object oldText = JTextComponentAdapterProvider.Adapter.this.cachedText;
/* 135 */         JTextComponentAdapterProvider.Adapter.this.cachedText = JTextComponentAdapterProvider.Adapter.this.getText();
/* 136 */         JTextComponentAdapterProvider.Adapter.this.firePropertyChange(oldText, JTextComponentAdapterProvider.Adapter.this.cachedText);
/*     */       }
/*     */       
/*     */       private void documentTextChanged() {
/*     */         try {
/* 141 */           JTextComponentAdapterProvider.Adapter.this.inDocumentListener = true;
/* 142 */           textChanged();
/*     */         } finally {
/* 144 */           JTextComponentAdapterProvider.Adapter.this.inDocumentListener = false;
/*     */         } 
/*     */       }
/*     */ 
/*     */       
/* 149 */       private void textChanged() { updateText(); }
/*     */ 
/*     */       
/*     */       public void propertyChange(PropertyChangeEvent pce) {
/* 153 */         JTextComponentAdapterProvider.Adapter.this.uninstallDocumentListener();
/* 154 */         JTextComponentAdapterProvider.Adapter.this.document = JTextComponentAdapterProvider.Adapter.this.component.getDocument();
/* 155 */         JTextComponentAdapterProvider.Adapter.this.installDocumentListener();
/* 156 */         updateText();
/*     */       }
/*     */ 
/*     */       
/* 160 */       public void actionPerformed(ActionEvent e) { updateText(); }
/*     */ 
/*     */       
/*     */       public void focusLost(FocusEvent e) {
/* 164 */         if (!e.isTemporary()) {
/* 165 */           updateText();
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 170 */       public void insertUpdate(DocumentEvent e) { documentTextChanged(); }
/*     */ 
/*     */ 
/*     */       
/* 174 */       public void removeUpdate(DocumentEvent e) { documentTextChanged(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public void replace(DocumentFilter.FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
/* 181 */         super.replace(fb, offset, length, text, attrs);
/* 182 */         textChanged();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/*     */       public void insertString(DocumentFilter.FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
/* 188 */         super.insertString(fb, offset, string, attr);
/* 189 */         textChanged();
/*     */       }
/*     */       
/*     */       public void remove(DocumentFilter.FilterBypass fb, int offset, int length) throws BadLocationException {
/* 193 */         super.remove(fb, offset, length);
/* 194 */         textChanged();
/*     */       }
/*     */       
/*     */       public void focusGained(FocusEvent e) {}
/*     */       
/*     */       public void changedUpdate(DocumentEvent e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean providesAdapter(Class<?> type, String property) {
/* 204 */     if (!JTextComponent.class.isAssignableFrom(type)) {
/* 205 */       return false;
/*     */     }
/*     */     
/* 208 */     property = property.intern();
/*     */     
/* 210 */     return (property == "text" || property == "text_ON_ACTION_OR_FOCUS_LOST" || property == "text_ON_FOCUS_LOST");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createAdapter(Object source, String property) {
/* 217 */     if (!providesAdapter(source.getClass(), property)) {
/* 218 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/* 221 */     return new Adapter((JTextComponent)source, property);
/*     */   }
/*     */ 
/*     */   
/* 225 */   public Class<?> getAdapterClass(Class<?> type) { return JTextComponent.class.isAssignableFrom(type) ? Adapter.class : null; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/swingbinding/adapters/JTextComponentAdapterProvider.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */