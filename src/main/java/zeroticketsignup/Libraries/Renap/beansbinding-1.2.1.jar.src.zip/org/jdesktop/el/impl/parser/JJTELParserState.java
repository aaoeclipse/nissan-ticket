/*     */ package org.jdesktop.el.impl.parser;
/*     */ 
/*     */ import java.util.Stack;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JJTELParserState
/*     */ {
/*  18 */   private Stack nodes = new Stack();
/*  19 */   private Stack marks = new Stack();
/*  20 */   private int sp = 0;
/*  21 */   private int mk = 0;
/*     */ 
/*     */   
/*     */   private boolean node_created;
/*     */ 
/*     */ 
/*     */   
/*  28 */   boolean nodeCreated() { return this.node_created; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void reset() {
/*  34 */     this.nodes.removeAllElements();
/*  35 */     this.marks.removeAllElements();
/*  36 */     this.sp = 0;
/*  37 */     this.mk = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  43 */   Node rootNode() { return this.nodes.elementAt(0); }
/*     */ 
/*     */ 
/*     */   
/*     */   void pushNode(Node n) {
/*  48 */     this.nodes.push(n);
/*  49 */     this.sp++;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Node popNode() {
/*  55 */     if (--this.sp < this.mk) {
/*  56 */       this.mk = ((Integer)this.marks.pop()).intValue();
/*     */     }
/*  58 */     return this.nodes.pop();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  63 */   Node peekNode() { return this.nodes.peek(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   int nodeArity() { return this.sp - this.mk; }
/*     */ 
/*     */ 
/*     */   
/*     */   void clearNodeScope(Node n) {
/*  74 */     while (this.sp > this.mk) {
/*  75 */       popNode();
/*     */     }
/*  77 */     this.mk = ((Integer)this.marks.pop()).intValue();
/*     */   }
/*     */ 
/*     */   
/*     */   void openNodeScope(Node n) {
/*  82 */     this.marks.push(new Integer(this.mk));
/*  83 */     this.mk = this.sp;
/*  84 */     n.jjtOpen();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeNodeScope(Node n, int num) {
/*  93 */     this.mk = ((Integer)this.marks.pop()).intValue();
/*  94 */     while (num-- > 0) {
/*  95 */       Node c = popNode();
/*  96 */       c.jjtSetParent(n);
/*  97 */       n.jjtAddChild(c, num);
/*     */     } 
/*  99 */     n.jjtClose();
/* 100 */     pushNode(n);
/* 101 */     this.node_created = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void closeNodeScope(Node n, boolean condition) {
/* 111 */     if (condition) {
/* 112 */       int a = nodeArity();
/* 113 */       this.mk = ((Integer)this.marks.pop()).intValue();
/* 114 */       while (a-- > 0) {
/* 115 */         Node c = popNode();
/* 116 */         c.jjtSetParent(n);
/* 117 */         n.jjtAddChild(c, a);
/*     */       } 
/* 119 */       n.jjtClose();
/* 120 */       pushNode(n);
/* 121 */       this.node_created = true;
/*     */     } else {
/* 123 */       this.mk = ((Integer)this.marks.pop()).intValue();
/* 124 */       this.node_created = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/beansbinding-1.2.1.jar!/org/jdesktop/el/impl/parser/JJTELParserState.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */