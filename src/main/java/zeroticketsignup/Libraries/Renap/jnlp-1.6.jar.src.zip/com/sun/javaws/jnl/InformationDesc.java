package com.sun.javaws.jnl;

import com.sun.deploy.association.AssociationDesc;
import com.sun.deploy.xml.XMLAttribute;
import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import com.sun.deploy.xml.XMLable;
import java.net.URL;

public class InformationDesc implements XMLable {
  private String _title;
  
  private String _vendor;
  
  private URL _home;
  
  private String[] _descriptions;
  
  private IconDesc[] _icons;
  
  private ShortcutDesc _shortcutHints;
  
  private AssociationDesc[] _associations;
  
  private RContentDesc[] _relatedContent;
  
  private boolean _supportOfflineOperation;
  
  public static final int DESC_DEFAULT = 0;
  
  public static final int DESC_SHORT = 1;
  
  public static final int DESC_ONELINE = 2;
  
  public static final int DESC_TOOLTIP = 3;
  
  public static final int NOF_DESC = 4;
  
  public InformationDesc(String paramString1, String paramString2, URL paramURL, String[] paramArrayOfString, IconDesc[] paramArrayOfIconDesc, ShortcutDesc paramShortcutDesc, RContentDesc[] paramArrayOfRContentDesc, AssociationDesc[] paramArrayOfAssociationDesc, boolean paramBoolean) {
    this._title = (paramString1 == null) ? "" : paramString1;
    this._vendor = (paramString2 == null) ? "" : paramString2;
    this._home = paramURL;
    if (paramArrayOfString == null)
      paramArrayOfString = new String[4]; 
    this._descriptions = paramArrayOfString;
    this._icons = paramArrayOfIconDesc;
    this._shortcutHints = paramShortcutDesc;
    this._associations = paramArrayOfAssociationDesc;
    this._relatedContent = paramArrayOfRContentDesc;
    this._supportOfflineOperation = paramBoolean;
  }
  
  public String getTitle() { return this._title; }
  
  public String getVendor() { return this._vendor; }
  
  public URL getHome() { return this._home; }
  
  public boolean supportsOfflineOperation() { return this._supportOfflineOperation; }
  
  public IconDesc[] getIcons() { return this._icons; }
  
  public ShortcutDesc getShortcut() { return this._shortcutHints; }
  
  public AssociationDesc[] getAssociations() { return this._associations; }
  
  public boolean hintsInstall() { return false; }
  
  public void setShortcut(ShortcutDesc paramShortcutDesc) { this._shortcutHints = paramShortcutDesc; }
  
  public void setAssociation(AssociationDesc paramAssociationDesc) { this._associations = new AssociationDesc[] { paramAssociationDesc }; }
  
  public RContentDesc[] getRelatedContent() { return this._relatedContent; }
  
  public String getDescription(int paramInt) { return this._descriptions[paramInt]; }
  
  public IconDesc getIconLocation(int paramInt1, int paramInt2) {
    if (this._icons == null)
      return null; 
    IconDesc iconDesc = null;
    long l = 0L;
    for (byte b = 0; b < this._icons.length; b++) {
      IconDesc iconDesc1 = this._icons[b];
      boolean bool = (paramInt2 == 5 || !iconDesc1.getSuffix().equalsIgnoreCase(".ico")) ? true : false;
      if (iconDesc1.getKind() == paramInt2 && bool) {
        if (iconDesc1.getHeight() == paramInt1 && iconDesc1.getWidth() == paramInt1)
          return iconDesc1; 
        if (iconDesc1.getHeight() == 0 && iconDesc1.getWidth() == 0) {
          if (iconDesc == null)
            iconDesc = iconDesc1; 
        } else {
          int i = iconDesc1.getHeight() + iconDesc1.getWidth() - 2 * paramInt1;
          long l1 = Math.abs(i);
          if (l == 0L || l1 < l) {
            l = l1;
            iconDesc = iconDesc1;
          } else if (l1 == l && i > 0) {
            iconDesc = iconDesc1;
          } 
        } 
      } 
    } 
    return iconDesc;
  }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("information", xMLAttributeBuilder.getAttributeList());
    xMLNodeBuilder.add("title", this._title);
    xMLNodeBuilder.add("vendor", this._vendor);
    xMLNodeBuilder.add(new XMLNode("homepage", new XMLAttribute("href", (this._home != null) ? this._home.toString() : null), null, null));
    xMLNodeBuilder.add(getDescriptionNode(0, ""));
    xMLNodeBuilder.add(getDescriptionNode(1, "short"));
    xMLNodeBuilder.add(getDescriptionNode(2, "one-line"));
    xMLNodeBuilder.add(getDescriptionNode(3, "tooltip"));
    if (this._icons != null)
      for (byte b = 0; b < this._icons.length; b++)
        xMLNodeBuilder.add(this._icons[b]);  
    if (this._shortcutHints != null)
      xMLNodeBuilder.add(this._shortcutHints); 
    if (this._associations != null)
      for (byte b = 0; b < this._associations.length; b++)
        xMLNodeBuilder.add((XMLable)this._associations[b]);  
    if (this._relatedContent != null)
      for (byte b = 0; b < this._relatedContent.length; b++)
        xMLNodeBuilder.add(this._relatedContent[b]);  
    if (this._supportOfflineOperation)
      xMLNodeBuilder.add(new XMLNode("offline-allowed", null)); 
    return xMLNodeBuilder.getNode();
  }
  
  private XMLNode getDescriptionNode(int paramInt, String paramString) {
    String str = this._descriptions[paramInt];
    if (str == null)
      return null; 
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("kind", paramString);
    return new XMLNode("description", xMLAttributeBuilder.getAttributeList(), new XMLNode(str), null);
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/InformationDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */