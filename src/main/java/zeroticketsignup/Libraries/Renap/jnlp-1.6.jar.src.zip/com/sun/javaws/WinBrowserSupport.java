package com.sun.javaws;

import com.sun.deploy.config.Config;
import com.sun.deploy.config.Platform;
import java.net.URL;

public class WinBrowserSupport extends BrowserSupport {
  public String getNS6MailCapInfo() { return null; }
  
  public OperaSupport getOperaSupport() { return new WinOperaSupport(Config.getBooleanProperty("deployment.mime.types.use.default")); }
  
  public boolean isWebBrowserSupportedImpl() { return true; }
  
  public boolean showDocumentImpl(URL paramURL) { return (paramURL == null) ? false : showDocument(paramURL.toString()); }
  
  public String getDefaultHandler(URL paramURL) { return Platform.get().getBrowserPath(); }
  
  public boolean showDocument(String paramString) { return Platform.get().showDocument(paramString); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/WinBrowserSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */