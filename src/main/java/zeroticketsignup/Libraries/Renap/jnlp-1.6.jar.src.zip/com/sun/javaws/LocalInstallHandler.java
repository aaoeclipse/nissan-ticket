package com.sun.javaws;

import com.sun.deploy.Environment;
import com.sun.deploy.association.Action;
import com.sun.deploy.association.Association;
import com.sun.deploy.association.AssociationAlreadyRegisteredException;
import com.sun.deploy.association.AssociationDesc;
import com.sun.deploy.association.AssociationNotRegisteredException;
import com.sun.deploy.association.AssociationService;
import com.sun.deploy.association.RegisterFailedException;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.OSType;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.uitoolkit.ui.ComponentRef;
import com.sun.javaws.jnl.IconDesc;
import com.sun.javaws.jnl.InformationDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.jnl.RContentDesc;
import com.sun.javaws.jnl.ShortcutDesc;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.StringTokenizer;
import javax.swing.SwingUtilities;

public abstract class LocalInstallHandler {
  private static LocalInstallHandler _installHandler;
  
  public static final int DESKTOP_INDEX = 0;
  
  public static final int MENU_INDEX = 1;
  
  public static synchronized LocalInstallHandler getInstance() {
    if (_installHandler == null)
      _installHandler = LocalInstallHandlerFactory.newInstance(); 
    return _installHandler;
  }
  
  public void install(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean1, boolean paramBoolean2, ComponentRef paramComponentRef) {
    if (paramLaunchDesc.isApplicationDescriptor()) {
      boolean bool1 = false;
      boolean bool2 = false;
      if (isLocalInstallSupported()) {
        AssociationDesc[] arrayOfAssociationDesc = paramLocalApplicationProperties.getAssociations();
        if (arrayOfAssociationDesc == null || arrayOfAssociationDesc.length <= 0) {
          AssociationDesc[] arrayOfAssociationDesc1 = paramLaunchDesc.getInformation().getAssociations();
          bool1 = (isAssociationSupported() && arrayOfAssociationDesc1 != null && arrayOfAssociationDesc1.length > 0) ? true : false;
        } else if (paramBoolean1) {
          removeAssociations(paramLaunchDesc, paramLocalApplicationProperties);
          createAssociations(paramLaunchDesc, paramLocalApplicationProperties);
        } 
        if (paramLocalApplicationProperties.isShortcutInstalled()) {
          if (!paramLocalApplicationProperties.isShortcutInstalledSystem() && paramBoolean1) {
            boolean[] arrayOfBoolean = whichShortcutsExist(paramLocalApplicationProperties);
            removeShortcuts(paramLaunchDesc, paramLocalApplicationProperties, true);
            if (!arrayOfBoolean[0] && !arrayOfBoolean[1]) {
              bool2 = true;
            } else {
              createShortcuts(paramLaunchDesc, paramLocalApplicationProperties, arrayOfBoolean);
            } 
          } 
        } else {
          bool2 = true;
        } 
      } else if (!paramLocalApplicationProperties.getAskedForInstall()) {
        try {
          performIntegration(paramComponentRef, paramLaunchDesc, paramLocalApplicationProperties, paramBoolean2, false, false);
        } catch (Throwable throwable) {
          Trace.ignored(throwable);
        } 
        paramLocalApplicationProperties.setAskedForInstall(true);
      } 
      if ((bool2 || bool1) && !paramLocalApplicationProperties.getAskedForInstall()) {
        try {
          performIntegration(paramComponentRef, paramLaunchDesc, paramLocalApplicationProperties, paramBoolean2, bool2, bool1);
        } catch (Throwable throwable) {
          Trace.ignored(throwable);
        } 
        paramLocalApplicationProperties.setAskedForInstall(true);
      } 
      if (paramBoolean1 || paramLocalApplicationProperties.getLaunchCount() <= 1)
        updateInstallPanel(paramLaunchDesc, paramLocalApplicationProperties); 
    } 
  }
  
  public void updateInstallPanel(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) {
    removeFromInstallPanel(paramLaunchDesc, paramLocalApplicationProperties, false);
    if (paramLocalApplicationProperties.isJnlpInstalled())
      registerWithInstallPanel(paramLaunchDesc, paramLocalApplicationProperties); 
  }
  
  public void uninstall(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) { uninstall(paramLaunchDesc, paramLocalApplicationProperties, false); }
  
  public void uninstall(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean) {
    removeShortcuts(paramLaunchDesc, paramLocalApplicationProperties, true);
    removeAssociations(paramLaunchDesc, paramLocalApplicationProperties);
    if (paramLocalApplicationProperties.isJnlpInstalled() || paramBoolean) {
      removeFromInstallPanel(paramLaunchDesc, paramLocalApplicationProperties, paramBoolean);
      paramLocalApplicationProperties.setJnlpInstalled(false);
    } 
  }
  
  public abstract boolean isLocalInstallSupported();
  
  public abstract boolean isAssociationSupported();
  
  protected abstract boolean isAssociationFileExtSupported(String paramString);
  
  public abstract String getAssociationOpenCommand(String paramString);
  
  public abstract String getAssociationPrintCommand(String paramString);
  
  public abstract void registerAssociationInternal(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Association paramAssociation) throws AssociationAlreadyRegisteredException, RegisterFailedException;
  
  public abstract void unregisterAssociationInternal(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Association paramAssociation) throws AssociationNotRegisteredException, RegisterFailedException;
  
  public abstract boolean hasAssociation(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Association paramAssociation);
  
  public abstract String getDefaultIconPath();
  
  public abstract boolean isShortcutExists(LocalApplicationProperties paramLocalApplicationProperties);
  
  public abstract boolean[] whichShortcutsExist(LocalApplicationProperties paramLocalApplicationProperties);
  
  protected abstract boolean createShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean[] paramArrayOfboolean);
  
  protected abstract boolean removeShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean);
  
  protected abstract boolean removePathShortcut(String paramString);
  
  public boolean updateShortcutToLatestJRE(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) { return false; }
  
  protected abstract void registerWithInstallPanel(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties);
  
  protected abstract void removeFromInstallPanel(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean);
  
  private String getJnlpLocation(LaunchDesc paramLaunchDesc) {
    String str;
    File file = ResourceProvider.get().getCachedJNLPFile(paramLaunchDesc.getCanonicalHome(), null);
    if (file != null) {
      str = file.getAbsolutePath();
    } else {
      str = paramLaunchDesc.getLocation().toString();
    } 
    return str;
  }
  
  private String getOpenActionCommand(Association paramAssociation) {
    Action action = paramAssociation.getActionByVerb("open");
    String str = null;
    if (action != null)
      str = action.getCommand(); 
    return str;
  }
  
  private boolean registerAssociation(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, String paramString1, String paramString2, String paramString3, URL paramURL) {
    Object object;
    AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
    Association association = new Association();
    boolean bool = false;
    String str1 = "";
    String str2 = null;
    if (paramString1 != null) {
      object = new StringTokenizer(paramString1);
      while (object.hasMoreTokens()) {
        String str = "." + object.nextToken();
        Trace.println("associate with ext: " + str, TraceLevel.BASIC);
        if (!isAssociationFileExtSupported(str)) {
          Trace.println("association with ext: " + str + " is not supported", TraceLevel.BASIC);
          return false;
        } 
        if (str1.isEmpty())
          str1 = str + " file"; 
        Association association1 = associationService.getFileExtensionAssociation(str);
        if (association1 != null) {
          Trace.println("associate with ext: " + str + " already EXIST", TraceLevel.BASIC);
          if (str2 == null)
            str2 = getOpenActionCommand(association1); 
          bool = true;
          if (str2 == null || !promptReplace(paramLaunchDesc, str, null, str2))
            return false; 
        } 
        association.addFileExtension(str);
      } 
    } 
    if (paramString3 != null && paramString3.length() > 0)
      str1 = paramString3; 
    if (paramString2 != null) {
      Trace.println("associate with mime: " + paramString2, TraceLevel.BASIC);
      Association association1 = associationService.getMimeTypeAssociation(paramString2);
      if ((((association1 != null) ? 1 : 0) & (!bool ? 1 : 0)) != 0) {
        Trace.println("associate with mime: " + paramString2 + " already EXIST", TraceLevel.BASIC);
        object = getOpenActionCommand(association1);
        if (object.equals(str2) && !promptReplace(paramLaunchDesc, null, paramString2, (String)object))
          return false; 
      } 
      association.setMimeType(paramString2);
    } 
    association.setName(paramLaunchDesc.getInformation().getTitle());
    association.setDescription(str1);
    if (paramURL != null) {
      object = IconUtil.getIconPath(paramURL, null);
    } else {
      object = IconUtil.getIconPath(paramLaunchDesc);
    } 
    if (object == null)
      object = getDefaultIconPath(); 
    association.setIconFileName((String)object);
    String str3 = getJnlpLocation(paramLaunchDesc);
    String str4 = getAssociationOpenCommand(str3);
    String str5 = getAssociationPrintCommand(str3);
    Trace.println("register OPEN using: " + str4, TraceLevel.BASIC);
    Action action = new Action("open", str4, "open the file");
    association.addAction(action);
    if (str5 != null) {
      Trace.println("register PRINT using: " + str5, TraceLevel.BASIC);
      action = new Action("print", str5, "print the file");
      association.addAction(action);
    } 
    try {
      registerAssociationInternal(paramLaunchDesc, paramLocalApplicationProperties, association);
    } catch (AssociationAlreadyRegisteredException associationAlreadyRegisteredException) {
      try {
        unregisterAssociationInternal(paramLaunchDesc, paramLocalApplicationProperties, association);
        registerAssociationInternal(paramLaunchDesc, paramLocalApplicationProperties, association);
      } catch (AssociationNotRegisteredException associationNotRegisteredException) {
        Trace.ignoredException((Exception)associationNotRegisteredException);
        return false;
      } catch (AssociationAlreadyRegisteredException associationAlreadyRegisteredException1) {
        Trace.ignoredException((Exception)associationAlreadyRegisteredException1);
        return false;
      } catch (RegisterFailedException registerFailedException) {
        Trace.ignoredException((Exception)registerFailedException);
        return false;
      } 
    } catch (RegisterFailedException registerFailedException) {
      Trace.ignoredException((Exception)registerFailedException);
      return false;
    } 
    return true;
  }
  
  private void unregisterAssociation(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, String paramString1, String paramString2) {
    AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
    if (paramString2 != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(paramString2);
      while (stringTokenizer.hasMoreTokens()) {
        String str = "." + stringTokenizer.nextToken();
        Association association = associationService.getFileExtensionAssociation(str);
        if (association != null) {
          association.setName(paramLaunchDesc.getInformation().getTitle());
          Trace.println("remove association with ext: " + str, TraceLevel.BASIC);
          try {
            unregisterAssociationInternal(paramLaunchDesc, paramLocalApplicationProperties, association);
          } catch (AssociationNotRegisteredException associationNotRegisteredException) {
            Trace.ignoredException((Exception)associationNotRegisteredException);
          } catch (RegisterFailedException registerFailedException) {
            Trace.ignoredException((Exception)registerFailedException);
          } 
        } 
      } 
    } 
    if (paramString1 != null) {
      Association association = associationService.getMimeTypeAssociation(paramString1);
      if (association != null) {
        association.setName(paramLaunchDesc.getInformation().getTitle());
        Trace.println("remove association with mime: " + paramString1, TraceLevel.BASIC);
        try {
          unregisterAssociationInternal(paramLaunchDesc, paramLocalApplicationProperties, association);
        } catch (AssociationNotRegisteredException associationNotRegisteredException) {
          Trace.ignoredException((Exception)associationNotRegisteredException);
        } catch (RegisterFailedException registerFailedException) {
          Trace.ignoredException((Exception)registerFailedException);
        } 
      } 
    } 
  }
  
  public void removeAssociations(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) {
    if (isAssociationSupported()) {
      AssociationDesc[] arrayOfAssociationDesc = paramLocalApplicationProperties.getAssociations();
      if (arrayOfAssociationDesc != null) {
        for (AssociationDesc associationDesc : arrayOfAssociationDesc)
          removeAssociationIfCurent(paramLaunchDesc, paramLocalApplicationProperties, associationDesc.getMimeType(), associationDesc.getExtensions()); 
        paramLocalApplicationProperties.setAssociations(null);
      } 
    } 
  }
  
  private void removeAssociationIfCurent(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, String paramString1, String paramString2) {
    String str = getAssociationOpenCommand(getJnlpLocation(paramLaunchDesc));
    AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
    Association association = associationService.getMimeTypeAssociation(paramString1);
    if (association != null) {
      String str1 = getOpenActionCommand(association);
      if (str.equals(str1)) {
        unregisterAssociation(paramLaunchDesc, paramLocalApplicationProperties, paramString1, paramString2);
      } else {
        Trace.println("Not removing association because existing command is: " + str1 + " instead of: " + str, TraceLevel.BASIC);
      } 
    } 
  }
  
  public boolean createAssociations(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) {
    if (Config.getAssociationValue() == 0)
      return false; 
    boolean bool = true;
    if (isAssociationSupported()) {
      AssociationDesc[] arrayOfAssociationDesc = paramLaunchDesc.getInformation().getAssociations();
      for (byte b = 0; arrayOfAssociationDesc != null && b < arrayOfAssociationDesc.length; b++) {
        String str1 = arrayOfAssociationDesc[b].getExtensions();
        String str2 = arrayOfAssociationDesc[b].getMimeType();
        String str3 = arrayOfAssociationDesc[b].getMimeDescription();
        URL uRL = arrayOfAssociationDesc[b].getIconUrl();
        if (registerAssociation(paramLaunchDesc, paramLocalApplicationProperties, str1, str2, str3, uRL)) {
          paramLocalApplicationProperties.addAssociation(arrayOfAssociationDesc[b]);
          save(paramLocalApplicationProperties);
        } else {
          bool = false;
        } 
      } 
    } else {
      bool = false;
    } 
    return bool;
  }
  
  public boolean performIntegration(ComponentRef paramComponentRef, LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    boolean bool1 = true;
    boolean bool2 = true;
    boolean bool3 = true;
    boolean bool4 = false;
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool8 = false;
    boolean bool9 = false;
    boolean bool10 = (paramLaunchDesc.getSecurityModel() != 0) ? true : false;
    ShortcutDesc shortcutDesc = paramLaunchDesc.getInformation().getShortcut();
    if (shortcutDesc != null) {
      if (!shortcutDesc.getDesktop() && !shortcutDesc.getMenu() && !OSType.isMac())
        paramBoolean2 = false; 
      bool9 = shortcutDesc.getInstall();
    } 
    if (paramBoolean2)
      if (paramBoolean1) {
        bool4 = (Globals.createShortcut() || Config.getShortcutValue() == 1 || Config.getShortcutValue() == 4) ? true : false;
        bool7 = false;
      } else {
        switch (Config.getShortcutValue()) {
          case 0:
            bool4 = false;
            bool7 = false;
            break;
          case 1:
            bool4 = true;
            bool7 = false;
            break;
          case 4:
            bool4 = (shortcutDesc != null) ? true : false;
            bool7 = false;
            break;
          case 3:
            bool4 = (shortcutDesc != null) ? true : false;
            bool7 = (shortcutDesc != null) ? true : false;
            break;
          default:
            bool4 = true;
            bool7 = true;
            break;
        } 
      }  
    if (paramBoolean3) {
      AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
      boolean bool = true;
      AssociationDesc[] arrayOfAssociationDesc = paramLaunchDesc.getInformation().getAssociations();
      for (byte b = 0; arrayOfAssociationDesc != null && b < arrayOfAssociationDesc.length; b++) {
        if (associationService.getMimeTypeAssociation(arrayOfAssociationDesc[b].getMimeType()) != null) {
          bool = false;
          break;
        } 
        String str = arrayOfAssociationDesc[b].getExtensions();
        StringTokenizer stringTokenizer = new StringTokenizer(str);
        while (stringTokenizer.hasMoreTokens()) {
          String str1 = "." + stringTokenizer.nextToken();
          if (associationService.getFileExtensionAssociation(str1) != null) {
            bool = false;
            break;
          } 
        } 
      } 
      if (paramBoolean1) {
        bool8 = false;
        switch (Config.getAssociationValue()) {
          case 0:
            bool5 = false;
            break;
          case 1:
            bool5 = bool;
            break;
          case 3:
            bool5 = (bool || Globals.createAssoc());
            break;
          case 4:
            bool5 = true;
            break;
          default:
            bool5 = Globals.createAssoc();
            break;
        } 
      } else {
        switch (Config.getAssociationValue()) {
          case 0:
            bool5 = false;
            bool8 = false;
            break;
          case 1:
            bool5 = bool;
            bool8 = false;
            break;
          case 3:
            bool5 = true;
            bool8 = !bool ? true : false;
            break;
          case 4:
            bool5 = true;
            bool8 = false;
            break;
          default:
            bool5 = true;
            bool8 = true;
            break;
        } 
      } 
    } 
    if (bool9)
      switch (Config.getInstallMode()) {
        case 0:
        case 1:
        case 2:
          bool6 = false;
          break;
        default:
          bool6 = true;
          break;
      }  
    if (bool7 || bool8)
      if ((!Environment.isImportMode() && bool10) || showDialog((paramComponentRef == null) ? null : paramComponentRef.get(), paramLaunchDesc, paramLocalApplicationProperties, bool4, bool5)) {
        if (bool7)
          bool4 = true; 
        if (bool8)
          bool5 = true; 
      } else {
        if (bool7)
          bool4 = false; 
        if (bool8)
          bool5 = false; 
      }  
    if (bool4)
      bool1 = installShortcuts(paramLaunchDesc, paramLocalApplicationProperties, null); 
    if (bool5)
      bool2 = createAssociations(paramLaunchDesc, paramLocalApplicationProperties); 
    if (bool6) {
      paramLocalApplicationProperties.setJnlpInstalled(true);
      updateInstallPanel(paramLaunchDesc, paramLocalApplicationProperties);
      save(paramLocalApplicationProperties);
    } 
    return (bool1 && bool2);
  }
  
  public boolean installShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) { return installShortcuts(paramLaunchDesc, paramLocalApplicationProperties, null); }
  
  private boolean installShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean[] paramArrayOfboolean) {
    boolean bool = createShortcuts(paramLaunchDesc, paramLocalApplicationProperties, paramArrayOfboolean);
    paramLocalApplicationProperties.setAskedForInstall(true);
    RContentDesc[] arrayOfRContentDesc = paramLaunchDesc.getInformation().getRelatedContent();
    if (arrayOfRContentDesc != null)
      for (RContentDesc rContentDesc : arrayOfRContentDesc) {
        URL uRL = rContentDesc.getHref();
        if (!"jar".equals(uRL.getProtocol()) && uRL.toString().endsWith(".jnlp"))
          try {
            Main.importApp(uRL.toString());
          } catch (Exception exception) {
            Trace.ignoredException(exception);
          }  
      }  
    if (bool && !paramLocalApplicationProperties.isJnlpInstalled()) {
      int i = Config.getInstallMode();
      ShortcutDesc shortcutDesc = paramLaunchDesc.getInformation().getShortcut();
      if (i == 1 || (i == 2 && shortcutDesc != null && shortcutDesc.getInstall())) {
        paramLocalApplicationProperties.setJnlpInstalled(true);
        updateInstallPanel(paramLaunchDesc, paramLocalApplicationProperties);
        save(paramLocalApplicationProperties);
      } 
    } 
    return bool;
  }
  
  private boolean showDialog(Object paramObject, LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean1, boolean paramBoolean2) {
    InformationDesc informationDesc = paramLaunchDesc.getInformation();
    IconDesc iconDesc = informationDesc.getIconLocation(48, 0);
    URL uRL = (iconDesc == null) ? null : iconDesc.getLocation();
    String str1 = (iconDesc == null) ? null : iconDesc.getVersion();
    boolean bool1 = false;
    boolean bool2 = false;
    String str2 = null;
    if (paramBoolean1) {
      ShortcutDesc shortcutDesc = informationDesc.getShortcut();
      if (shortcutDesc != null) {
        bool1 = shortcutDesc.getDesktop();
        bool2 = shortcutDesc.getMenu();
        str2 = shortcutDesc.getSubmenu();
      } else {
        bool1 = true;
        bool2 = true;
      } 
    } 
    AssociationDesc[] arrayOfAssociationDesc = paramBoolean2 ? informationDesc.getAssociations() : new AssociationDesc[0];
    AppInfo appInfo = new AppInfo(paramLaunchDesc.getLaunchType(), informationDesc.getTitle(), informationDesc.getVendor(), paramLaunchDesc.getCanonicalHome(), paramLaunchDesc.getSourceURL(), uRL, str1, bool1, bool2, str2, arrayOfAssociationDesc);
    return (ToolkitStore.getUI().showMessageDialog(paramObject, appInfo, 5, null, null, null, null, null, null, null) == 0);
  }
  
  private boolean promptReplace(LaunchDesc paramLaunchDesc, String paramString1, String paramString2, String paramString3) {
    String str1;
    if (paramString1 != null) {
      str1 = ResourceManager.getString("association.replace.ext", paramString1);
    } else {
      str1 = ResourceManager.getString("association.replace.mime", paramString2);
    } 
    String str2 = paramString3;
    String str3 = ResourceProvider.get().getCacheDir().toString();
    int i = paramString3.indexOf(str3);
    if (i >= 0) {
      String str;
      int j = paramString3.indexOf("\"", i + str3.length());
      if (j < 0)
        j = paramString3.indexOf(" ", i + str3.length()); 
      if (j >= 0) {
        str = paramString3.substring(i, j);
      } else {
        str = paramString3.substring(i);
      } 
      try {
        LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(str);
        if (launchDesc != null) {
          str2 = launchDesc.getInformation().getTitle();
          if (launchDesc.getCanonicalHome().toString().equals(paramLaunchDesc.getCanonicalHome().toString()))
            return true; 
        } 
      } catch (Exception exception) {
        return true;
      } 
    } 
    String str4 = ResourceManager.getString("association.replace.info", str2);
    String str5 = ResourceManager.getString("association.replace.title");
    String str6 = ResourceManager.getString("common.ok_btn");
    String str7 = ResourceManager.getString("common.cancel_btn");
    return (ToolkitStore.getUI().showMessageDialog(null, paramLaunchDesc.getAppInfo(), 3, str5, null, str1, str4, str6, str7, null) == 0);
  }
  
  public boolean uninstallShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) { return removeShortcuts(paramLaunchDesc, paramLocalApplicationProperties, true); }
  
  public static boolean shouldInstallOverExisting(final LaunchDesc ld) {
    final int[] result = { -1 };
    Runnable runnable = new Runnable() {
        public void run() {
          String str1 = ResourceManager.getString("install.alreadyInstalledTitle");
          String str2 = ResourceManager.getString("install.alreadyInstalled", ld.getInformation().getTitle());
          String str3 = ResourceManager.getString("common.ok_btn");
          String str4 = ResourceManager.getString("common.cancel_btn");
          result[0] = ToolkitStore.getUI().showMessageDialog(null, ld.getAppInfo(), 3, str1, null, str2, null, str3, str4, null);
        }
      };
    if (!Globals.isSilentMode())
      invokeRunnable(runnable); 
    return (arrayOfInt[0] == 0);
  }
  
  public static void invokeRunnable(Runnable paramRunnable) {
    if (SwingUtilities.isEventDispatchThread()) {
      paramRunnable.run();
    } else {
      try {
        SwingUtilities.invokeAndWait(paramRunnable);
      } catch (InterruptedException interruptedException) {
      
      } catch (InvocationTargetException invocationTargetException) {}
    } 
  }
  
  public static void save(LocalApplicationProperties paramLocalApplicationProperties) {
    try {
      paramLocalApplicationProperties.store();
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
    } 
  }
  
  public boolean addUninstallShortcut() { return (Config.getBooleanProperty("deployment.javaws.uninstall.shortcut") && !Environment.isSystemCacheMode()); }
  
  boolean removeShortcuts(String paramString) { return removePathShortcut(paramString); }
  
  void removeAssociations(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, String paramString1, String paramString2) {
    Association association = new Association();
    String str = "";
    if (paramString2 != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(paramString2);
      while (stringTokenizer.hasMoreTokens()) {
        String str1 = "." + stringTokenizer.nextToken();
        if (str.isEmpty())
          str = str1 + " file"; 
        association.addFileExtension(str1);
      } 
    } 
    if (paramString1 != null)
      association.setMimeType(paramString1); 
    association.setName(" ");
    association.setDescription(str);
    try {
      unregisterAssociationInternal(paramLaunchDesc, paramLocalApplicationProperties, association);
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
  }
  
  void reinstallShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean1, boolean paramBoolean2) {
    boolean[] arrayOfBoolean = new boolean[2];
    arrayOfBoolean[0] = paramBoolean1;
    arrayOfBoolean[1] = paramBoolean2;
    installShortcuts(paramLaunchDesc, paramLocalApplicationProperties, arrayOfBoolean);
  }
  
  void reinstallAssociations(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) { createAssociations(paramLaunchDesc, paramLocalApplicationProperties); }
  
  protected String checkTitleString(String paramString1, String paramString2, char paramChar) {
    StringBuilder stringBuilder = new StringBuilder();
    int i;
    for (i = 0; i < paramString1.length(); i += Character.charCount(j)) {
      int j = paramString1.codePointAt(i);
      if (paramString2.indexOf(j) >= 0) {
        stringBuilder.appendCodePoint(paramChar);
      } else if (!isShortCutSafe(j)) {
        stringBuilder.appendCodePoint(paramChar);
      } else {
        stringBuilder.appendCodePoint(j);
      } 
    } 
    return stringBuilder.toString();
  }
  
  private static boolean isShortCutSafe(int paramInt) { return (!Character.isIdentifierIgnorable(paramInt) && paramInt >= 32); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/LocalInstallHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */