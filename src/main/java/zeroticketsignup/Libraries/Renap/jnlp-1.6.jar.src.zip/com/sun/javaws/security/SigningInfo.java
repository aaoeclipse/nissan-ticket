package com.sun.javaws.security;

import com.sun.deploy.config.Config;
import com.sun.deploy.model.DeployCacheJarAccess;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.JARSigningException;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.JarUtil;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.CodeSigner;
import java.security.CodeSource;
import java.security.cert.CertPath;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class SigningInfo {
  private static DeployCacheJarAccess jarAccess = ResourceProvider.get().getJarAccess();
  
  private Resource ce = null;
  
  private URL location = null;
  
  private String version = null;
  
  private boolean fileInCache;
  
  private boolean jarIsEmpty;
  
  private String jarFilePath = null;
  
  private boolean wasChecked = false;
  
  public static Certificate[] toCertificateArray(List<Object> paramList) {
    Iterator<Object> iterator = paramList.iterator();
    int i = 0;
    while (iterator.hasNext()) {
      CertChain certChain = (CertChain)iterator.next();
      if (certChain instanceof CertChain) {
        i += ((CertChain)certChain).getLength();
        continue;
      } 
      return null;
    } 
    Certificate[] arrayOfCertificate = new Certificate[i];
    iterator = paramList.iterator();
    int j;
    for (j = 0; iterator.hasNext(); j += arrayOfCertificate1.length) {
      Certificate[] arrayOfCertificate1 = ((CertChain)iterator.next()).getCertificates();
      System.arraycopy(arrayOfCertificate1, 0, arrayOfCertificate, j, arrayOfCertificate1.length);
    } 
    return arrayOfCertificate;
  }
  
  private static boolean setContains(List paramList, Object paramObject) {
    if (paramList == null || paramObject == null)
      return false; 
    Iterator<CodeSigner> iterator = paramList.iterator();
    if (Config.isJavaVersionAtLeast15()) {
      CertPath certPath1 = null;
      CertPath certPath2 = ((CodeSigner)paramObject).getSignerCertPath();
      while (iterator.hasNext()) {
        certPath1 = ((CodeSigner)iterator.next()).getSignerCertPath();
        if (certPath2.equals(certPath1))
          return true; 
      } 
      return false;
    } 
    while (iterator.hasNext()) {
      if (paramObject.equals(iterator.next()))
        return true; 
    } 
    return false;
  }
  
  public static List overlapChainLists(List paramList1, List paramList2) {
    if (paramList1 == null || paramList2 == null)
      return null; 
    ArrayList<Object> arrayList = new ArrayList();
    for (Object object : paramList1) {
      if (setContains(paramList2, object))
        arrayList.add(object); 
    } 
    return arrayList.isEmpty() ? null : arrayList;
  }
  
  public static List overlapSigners(List paramList, CodeSigner[] paramArrayOfCodeSigner) {
    ArrayList<CodeSigner> arrayList = new ArrayList();
    if (paramArrayOfCodeSigner == null)
      return arrayList; 
    for (byte b = 0; b < paramArrayOfCodeSigner.length; b++) {
      if (paramList == null || setContains(paramList, paramArrayOfCodeSigner[b]))
        arrayList.add(paramArrayOfCodeSigner[b]); 
    } 
    return arrayList;
  }
  
  public static List overlapCertificateChains(List paramList, Certificate[] paramArrayOfCertificate) {
    ArrayList<CertChain> arrayList = new ArrayList();
    int i = 0;
    if (paramArrayOfCertificate == null)
      return arrayList; 
    CertChain certChain;
    while ((certChain = getAChain(paramArrayOfCertificate, i)) != null) {
      if (paramList == null || paramList.contains(certChain))
        arrayList.add(certChain); 
      i += certChain.getLength();
    } 
    return arrayList;
  }
  
  private static CertChain getAChain(Certificate[] paramArrayOfCertificate, int paramInt) {
    if (paramInt > paramArrayOfCertificate.length - 1)
      return null; 
    int i = 0;
    for (i = paramInt; i < paramArrayOfCertificate.length - 1 && ((X509Certificate)paramArrayOfCertificate[i + 1]).getSubjectDN().equals(((X509Certificate)paramArrayOfCertificate[i]).getIssuerDN()); i++);
    return new CertChain(paramArrayOfCertificate, paramInt, i);
  }
  
  public SigningInfo(URL paramURL, String paramString) {
    this.location = paramURL;
    this.version = paramString;
    boolean bool = false;
    try {
      this.jarFilePath = ResourceProvider.get().getCachedResourceFilePath(paramURL, paramString);
      this.fileInCache = true;
    } catch (IOException iOException) {
      if (paramString != null) {
        try {
          this.jarFilePath = ResourceProvider.get().getCachedResourceFilePath(paramURL, null);
          bool = true;
        } catch (IOException iOException1) {
          this.fileInCache = false;
        } 
      } else {
        this.fileInCache = false;
      } 
    } 
    if (this.fileInCache && ResourceProvider.get().canCache(null))
      this.ce = ResourceProvider.get().getCachedResource(paramURL, bool ? null : paramString); 
  }
  
  public List check() throws IOException, JARSigningException {
    List list = null;
    if (this.ce != null) {
      JarFile jarFile = this.ce.getJarFile();
      Trace.println("Validating cached jar url=" + this.ce.getURL() + " ffile=" + this.ce.getResourceFilename() + " " + jarFile, TraceLevel.SECURITY);
      list = getCommonCodeSignersForJar(jarFile);
      if (list != null && list.isEmpty()) {
        list = null;
        throw new JARSigningException(this.location, this.version, 1);
      } 
      this.wasChecked = true;
    } else {
      JarFile jarFile = null;
      try {
        JarFile jarFile1 = ResourceProvider.get().getCachedJarFile(this.location, this.version);
        if (jarFile1 == null)
          if (this.jarFilePath != null) {
            jarFile1 = new JarFile(this.jarFilePath);
            jarFile = jarFile1;
          } else {
            throw new SecurityException("Unable to get path for main jar");
          }  
        list = getCommonCodeSignersForJar(jarFile1);
        if (list != null && list.isEmpty()) {
          list = null;
          throw new JARSigningException(this.location, this.version, 1);
        } 
      } finally {
        if (jarFile != null)
          jarFile.close(); 
      } 
    } 
    return list;
  }
  
  public List getCertificates() { return (this.ce != null) ? (Config.isJavaVersionAtLeast15() ? overlapSigners(null, this.ce.getCodeSigners()) : overlapCertificateChains(null, this.ce.getCertificates())) : null; }
  
  public boolean isFileKnownToBeNotCached() { return !this.fileInCache; }
  
  public boolean isJarKnownToBeEmpty() { return this.jarIsEmpty; }
  
  List getCommonCodeSignersForJar(JarFile paramJarFile) throws IOException {
    List list = null;
    boolean bool = false;
    try {
      boolean bool1 = Config.isJavaVersionAtLeast15();
      if (jarAccess != null) {
        jarAccess.getCodeSource(paramJarFile, new URL("http:"), "/NOP");
        CodeSource[] arrayOfCodeSource = jarAccess.getCodeSources(paramJarFile, null);
        jarAccess.setEagerValidation(paramJarFile, true);
        Enumeration<String> enumeration = jarAccess.entryNames(paramJarFile, arrayOfCodeSource);
        while (enumeration.hasMoreElements() && (list == null || !list.isEmpty())) {
          String str = enumeration.nextElement();
          CodeSource codeSource = jarAccess.getCodeSource(paramJarFile, null, str);
          bool = true;
          if (bool1) {
            CodeSigner[] arrayOfCodeSigner = codeSource.getCodeSigners();
            if (arrayOfCodeSigner != null)
              list = overlapSigners(list, arrayOfCodeSigner); 
            continue;
          } 
          Certificate[] arrayOfCertificate = codeSource.getCertificates();
          if (arrayOfCertificate == null) {
            Trace.println("Found unsigned entry: " + str, TraceLevel.SECURITY);
            throw new JARSigningException(this.location, this.version, 3);
          } 
          list = overlapCertificateChains(list, arrayOfCertificate);
        } 
      } else {
        Enumeration<JarEntry> enumeration = paramJarFile.entries();
        while (enumeration.hasMoreElements() && (list == null || !list.isEmpty())) {
          byte[] arrayOfByte = new byte[8192];
          JarEntry jarEntry = enumeration.nextElement();
          if (!JarUtil.canSkipEntry(jarEntry)) {
            bool = true;
            InputStream inputStream = paramJarFile.getInputStream(jarEntry);
            while (inputStream.read(arrayOfByte, 0, arrayOfByte.length) != -1);
            inputStream.close();
            if (bool1) {
              CodeSigner[] arrayOfCodeSigner = jarEntry.getCodeSigners();
              if (arrayOfCodeSigner != null)
                list = overlapSigners(list, arrayOfCodeSigner); 
              continue;
            } 
            Certificate[] arrayOfCertificate = jarEntry.getCertificates();
            if (arrayOfCertificate == null) {
              Trace.println("Found unsigned entry: " + jarEntry.getName(), TraceLevel.SECURITY);
              throw new JARSigningException(this.location, this.version, 3);
            } 
            list = overlapCertificateChains(list, arrayOfCertificate);
          } 
        } 
      } 
    } catch (JARSigningException jARSigningException) {
      throw jARSigningException;
    } catch (IOException iOException) {
      throw new JARSigningException(this.location, this.version, 2, iOException);
    } catch (SecurityException securityException) {
      throw new JARSigningException(this.location, this.version, 2, securityException);
    } 
    this.jarIsEmpty = !bool;
    return list;
  }
  
  static class CertChain {
    Certificate[] certs;
    
    CertChain(Certificate[] param1ArrayOfCertificate, int param1Int1, int param1Int2) {
      this.certs = new Certificate[param1Int2 - param1Int1 + 1];
      for (byte b = 0; b < this.certs.length; b++)
        this.certs[b] = param1ArrayOfCertificate[param1Int1 + b]; 
    }
    
    Certificate[] getCertificates() { return this.certs; }
    
    int getLength() { return this.certs.length; }
    
    public int hashCode() { return (this.certs.length == 0) ? 0 : this.certs[0].hashCode(); }
    
    public boolean equals(Object param1Object) {
      CertChain certChain = (CertChain)param1Object;
      if (certChain == null || certChain.getLength() != getLength())
        return false; 
      for (byte b = 0; b < this.certs.length; b++) {
        if (!certChain.certs[b].equals(this.certs[b]))
          return false; 
      } 
      return true;
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/security/SigningInfo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */