package com.sun.javaws.progress;

import com.sun.deploy.uitoolkit.Applet2Adapter;
import java.util.WeakHashMap;

public class Progress {
  private static WeakHashMap map = new WeakHashMap<Object, Object>();
  
  public static synchronized PreloaderDelegate get(Applet2Adapter paramApplet2Adapter) {
    Object object = paramApplet2Adapter;
    if (paramApplet2Adapter == null)
      object = Progress.class; 
    PreloaderDelegate preloaderDelegate = (PreloaderDelegate)map.get(object);
    if (preloaderDelegate == null) {
      preloaderDelegate = new PreloaderDelegate(paramApplet2Adapter);
      map.put(object, preloaderDelegate);
    } 
    return preloaderDelegate;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/progress/Progress.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */