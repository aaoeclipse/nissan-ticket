package com.sun.javaws.ui;

import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.cache.CacheEntry;
import com.sun.deploy.config.Config;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.ui.UIFactory;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.javaws.BrowserSupport;
import com.sun.javaws.CacheUtil;
import com.sun.javaws.LocalInstallHandler;
import com.sun.javaws.Main;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.ShortcutDesc;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.StringTokenizer;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.MenuKeyEvent;
import javax.swing.event.MenuKeyListener;
import javax.swing.event.PopupMenuEvent;
import javax.swing.event.PopupMenuListener;

public class CacheViewer extends JDialog implements ListSelectionListener, PopupMenuListener {
  private final JPanel tablePanel = new JPanel(new BorderLayout());
  
  private CacheTable jnlpTable = null;
  
  private CacheTable resourceTable = null;
  
  private CacheTable importTable = null;
  
  private CacheTable sysJnlpTable = null;
  
  private CacheTable sysResourceTable = null;
  
  private CacheTable activeTable;
  
  private boolean noSeparator = false;
  
  private boolean wasDirty = false;
  
  private int leadinSpace;
  
  private int minSpace;
  
  private JComboBox viewComboBox;
  
  private JLabel viewLabel;
  
  private JToolBar toolbar;
  
  private JLabel sizeLabel = new JLabel("");
  
  private JButton runButton;
  
  private JButton removeButton;
  
  private JButton installButton;
  
  private JButton showButton;
  
  private JButton showResourceButton;
  
  private JButton homeButton;
  
  private JButton removeResourceButton;
  
  private JButton removeRemovedButton;
  
  private JButton importButton;
  
  private JButton closeButton;
  
  private JPopupMenu runPopup;
  
  private JMenuItem onlineMI;
  
  private JMenuItem offlineMI;
  
  private JPopupMenu popup;
  
  private JMenuItem runOnlineMI;
  
  private JMenuItem runOfflineMI;
  
  private JMenuItem installMI;
  
  private JMenuItem removeMI;
  
  private JMenuItem showMI;
  
  private JMenuItem showResourceMI;
  
  private JMenuItem homeMI;
  
  private JMenuItem importMI;
  
  private static final int WAIT_REMOVE = 0;
  
  private static final int WAIT_IMPORT = 1;
  
  private ImageIcon dummy = null;
  
  private static final String BOUNDS_PROPERTY_KEY = "deployment.javaws.viewer.bounds";
  
  private final int SLEEP_DELAY = 2000;
  
  private CacheViewer(JFrame paramJFrame) {
    super(paramJFrame);
    Cache.setDoIPLookup(false);
    setTitle(getResource("viewer.title"));
    addWindowListener(new WindowAdapter() {
          public void windowClosing(WindowEvent param1WindowEvent) { CacheViewer.this.exitViewer(); }
        });
    initComponents();
    this.wasDirty = Config.get().isConfigDirty();
  }
  
  private void refresh() {
    final int index = this.viewComboBox.getSelectedIndex();
    final Dimension d0 = new Dimension(this.minSpace, 0);
    final Dimension d1 = new Dimension(8, 0);
    final Dimension d2 = new Dimension(this.leadinSpace, 0);
    final Dimension d4 = new Dimension(4, 0);
    SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            JButton jButton2;
            JButton jButton1;
            Component[] arrayOfComponent = CacheViewer.this.toolbar.getComponents();
            if (arrayOfComponent.length == 0) {
              CacheViewer.this.toolbar.add(new Box.Filler(d1, d1, d1));
              CacheViewer.this.toolbar.add(CacheViewer.this.viewLabel);
              CacheViewer.this.toolbar.add(new Box.Filler(d4, d4, d4));
              CacheViewer.this.toolbar.add(CacheViewer.this.viewComboBox);
              CacheViewer.this.toolbar.add(new Box.Filler(d2, d2, d2));
            } else {
              for (int i = arrayOfComponent.length - 1; i > 4; i--)
                CacheViewer.this.toolbar.remove(i); 
            } 
            switch (index) {
              default:
                if (CacheViewer.this.jnlpTable == null)
                  CacheViewer.this.jnlpTable = new CacheTable(CacheViewer.this, 0, false); 
                CacheViewer.this.sizeLabel.setText(CacheViewer.this.jnlpTable.getSizeLabelText());
                CacheViewer.this.activeTable = CacheViewer.this.jnlpTable;
                CacheViewer.this.toolbar.add(CacheViewer.this.runButton);
                jButton1 = CacheViewer.this.runButton;
                if (CacheViewer.this.noSeparator) {
                  CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                } else {
                  CacheViewer.this.toolbar.addSeparator(d1);
                  CacheViewer.this.toolbar.add(new CacheViewer.VSeparator());
                  CacheViewer.this.toolbar.addSeparator(d1);
                } 
                CacheViewer.this.toolbar.add(CacheViewer.this.showButton);
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.installButton);
                if (CacheViewer.this.noSeparator) {
                  CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                } else {
                  CacheViewer.this.toolbar.addSeparator(d1);
                  CacheViewer.this.toolbar.add(new CacheViewer.VSeparator());
                  CacheViewer.this.toolbar.addSeparator(d1);
                } 
                CacheViewer.this.toolbar.add(CacheViewer.this.removeButton);
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.homeButton);
                CacheViewer.this.runButton.setNextFocusableComponent(CacheViewer.this.showButton);
                CacheViewer.this.showButton.setNextFocusableComponent(CacheViewer.this.installButton);
                CacheViewer.this.installButton.setNextFocusableComponent(CacheViewer.this.removeButton);
                CacheViewer.this.removeButton.setNextFocusableComponent(CacheViewer.this.homeButton);
                jButton2 = CacheViewer.this.homeButton;
                break;
              case 1:
                if (CacheViewer.this.resourceTable == null)
                  CacheViewer.this.resourceTable = new CacheTable(CacheViewer.this, 1, false); 
                CacheViewer.this.sizeLabel.setText(CacheViewer.this.resourceTable.getSizeLabelText());
                CacheViewer.this.activeTable = CacheViewer.this.resourceTable;
                CacheViewer.this.toolbar.add(CacheViewer.this.showResourceButton);
                jButton1 = CacheViewer.this.showResourceButton;
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.removeResourceButton);
                CacheViewer.this.showResourceButton.setNextFocusableComponent(CacheViewer.this.removeResourceButton);
                jButton2 = CacheViewer.this.removeResourceButton;
                break;
              case 2:
                if (CacheViewer.this.importTable == null)
                  CacheViewer.this.importTable = new CacheTable(CacheViewer.this, 2, false); 
                CacheViewer.this.sizeLabel.setText(CacheViewer.this.importTable.getSizeLabelText());
                CacheViewer.this.activeTable = CacheViewer.this.importTable;
                CacheViewer.this.toolbar.add(CacheViewer.this.importButton);
                jButton1 = CacheViewer.this.importButton;
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.removeRemovedButton);
                CacheViewer.this.importButton.setNextFocusableComponent(CacheViewer.this.removeRemovedButton);
                jButton2 = CacheViewer.this.removeRemovedButton;
                break;
              case 3:
                if (CacheViewer.this.sysJnlpTable == null)
                  CacheViewer.this.sysJnlpTable = new CacheTable(CacheViewer.this, 0, true); 
                CacheViewer.this.sizeLabel.setText(CacheViewer.this.sysJnlpTable.getSizeLabelText());
                CacheViewer.this.activeTable = CacheViewer.this.sysJnlpTable;
                CacheViewer.this.toolbar.add(CacheViewer.this.runButton);
                jButton1 = CacheViewer.this.runButton;
                if (CacheViewer.this.noSeparator) {
                  CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                } else {
                  CacheViewer.this.toolbar.addSeparator(d1);
                  CacheViewer.this.toolbar.add(new CacheViewer.VSeparator());
                  CacheViewer.this.toolbar.addSeparator(d1);
                } 
                CacheViewer.this.toolbar.add(CacheViewer.this.showButton);
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.installButton);
                if (CacheViewer.this.noSeparator) {
                  CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                } else {
                  CacheViewer.this.toolbar.addSeparator(d1);
                  CacheViewer.this.toolbar.add(new CacheViewer.VSeparator());
                  CacheViewer.this.toolbar.addSeparator(d1);
                } 
                CacheViewer.this.toolbar.add(CacheViewer.this.removeButton);
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.homeButton);
                CacheViewer.this.runButton.setNextFocusableComponent(CacheViewer.this.showButton);
                CacheViewer.this.showButton.setNextFocusableComponent(CacheViewer.this.installButton);
                CacheViewer.this.installButton.setNextFocusableComponent(CacheViewer.this.removeButton);
                CacheViewer.this.removeButton.setNextFocusableComponent(CacheViewer.this.homeButton);
                jButton2 = CacheViewer.this.homeButton;
                break;
              case 4:
                if (CacheViewer.this.sysResourceTable == null)
                  CacheViewer.this.sysResourceTable = new CacheTable(CacheViewer.this, 1, true); 
                CacheViewer.this.sizeLabel.setText(CacheViewer.this.sysResourceTable.getSizeLabelText());
                CacheViewer.this.activeTable = CacheViewer.this.sysResourceTable;
                CacheViewer.this.toolbar.add(CacheViewer.this.showResourceButton);
                jButton1 = CacheViewer.this.showResourceButton;
                CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
                CacheViewer.this.toolbar.add(CacheViewer.this.removeResourceButton);
                CacheViewer.this.showResourceButton.setNextFocusableComponent(CacheViewer.this.removeResourceButton);
                jButton2 = CacheViewer.this.removeResourceButton;
                break;
            } 
            CacheViewer.this.popup = new JPopupMenu();
            CacheViewer.this.popup.addPopupMenuListener(CacheViewer.this);
            switch (index) {
              case 0:
              case 3:
                CacheViewer.this.popup.add(CacheViewer.this.runOnlineMI);
                CacheViewer.this.popup.add(CacheViewer.this.runOfflineMI);
                CacheViewer.this.popup.addSeparator();
                CacheViewer.this.popup.add(CacheViewer.this.installMI);
                CacheViewer.this.popup.add(CacheViewer.this.removeMI);
                CacheViewer.this.popup.addSeparator();
                CacheViewer.this.popup.add(CacheViewer.this.showMI);
                CacheViewer.this.popup.add(CacheViewer.this.homeMI);
                break;
              case 1:
              case 4:
                CacheViewer.this.popup.add(CacheViewer.this.showResourceMI);
                CacheViewer.this.popup.add(CacheViewer.this.removeMI);
                break;
              case 2:
                CacheViewer.this.popup.add(CacheViewer.this.importMI);
                CacheViewer.this.popup.add(CacheViewer.this.removeMI);
                break;
            } 
            JScrollPane jScrollPane = new JScrollPane(CacheViewer.this.activeTable);
            CacheViewer.this.toolbar.add(new Box.Filler(d0, d0, d0));
            CacheViewer.this.toolbar.add(new CacheViewer.remainingSpacer());
            CacheViewer.this.toolbar.add(CacheViewer.this.sizeLabel);
            CacheViewer.this.toolbar.add(new Box.Filler(d1, d1, d1));
            CacheViewer.this.tablePanel.removeAll();
            CacheViewer.this.tablePanel.add(jScrollPane);
            CacheViewer.this.enableButtons();
            CacheViewer.this.closeButton.setNextFocusableComponent(CacheViewer.this.viewComboBox);
            CacheViewer.this.viewComboBox.setNextFocusableComponent(jButton1);
            jButton2.setNextFocusableComponent(CacheViewer.this.activeTable);
            CacheViewer.this.validate();
            CacheViewer.this.repaint();
          }
        });
  }
  
  private void initComponents() {
    JPanel jPanel1 = new JPanel(new BorderLayout());
    JPanel jPanel2 = new JPanel();
    this.toolbar = new JToolBar();
    this.toolbar.setBorderPainted(false);
    this.toolbar.setFloatable(false);
    this.toolbar.setMargin(new Insets(2, 2, 0, 0));
    this.toolbar.setRollover(true);
    String str = UIManager.getLookAndFeel().getID();
    if (str.startsWith("Windows")) {
      this.leadinSpace = 27;
      this.minSpace = 4;
      this.noSeparator = false;
    } else {
      this.leadinSpace = 30;
      this.noSeparator = true;
      if (str.startsWith("GTK")) {
        this.minSpace = 2;
      } else {
        this.minSpace = 10;
      } 
    } 
    ActionListener actionListener1 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.runApplication(true); }
      };
    ActionListener actionListener2 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.runApplication(false); }
      };
    ActionListener actionListener3 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.installApplication(); }
      };
    ActionListener actionListener4 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.importApplication(); }
      };
    ActionListener actionListener5 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.delete(); }
      };
    ActionListener actionListener6 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (CacheViewer.this.activeTable == CacheViewer.this.jnlpTable || CacheViewer.this.activeTable == CacheViewer.this.sysJnlpTable) {
            CacheViewer.this.showApplication();
          } else if (CacheViewer.this.activeTable == CacheViewer.this.resourceTable || CacheViewer.this.activeTable == CacheViewer.this.sysResourceTable) {
            CacheViewer.this.showInformation();
          } 
        }
      };
    ActionListener actionListener7 = new ActionListener() {
        public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.browseApplication(); }
      };
    this.runOnlineMI = createMI("viewer.run.online.menuitem", actionListener1);
    this.runOfflineMI = createMI("viewer.run.offline.menuitem", actionListener2);
    this.installMI = createMI("viewer.install.menuitem", actionListener3);
    this.removeMI = createMI("viewer.remove.menuitem", actionListener5);
    this.showMI = createMI("viewer.show.menuitem", actionListener6);
    this.showResourceMI = createMI("viewer.show.resource.menuitem", actionListener6);
    this.homeMI = createMI("viewer.home.menuitem", actionListener7);
    this.importMI = createMI("viewer.import.menuitem", actionListener4);
    boolean bool = (Config.getSystemCacheDirectory() != null && !Environment.isSystemCacheMode()) ? true : false;
    String[] arrayOfString = bool ? new String[5] : new String[3];
    arrayOfString[0] = getResource("viewer.view.jnlp");
    arrayOfString[1] = getResource("viewer.view.res");
    arrayOfString[2] = getResource("viewer.view.import");
    if (bool) {
      arrayOfString[3] = getResource("viewer.sys.view.jnlp");
      arrayOfString[4] = getResource("viewer.sys.view.res");
    } 
    this.viewComboBox = new JComboBox((Object[])arrayOfString) {
        public Dimension getMinimumSize() { return getPreferredSize(); }
        
        public Dimension getMaximumSize() { return getPreferredSize(); }
      };
    this.viewComboBox.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.refresh(); }
        });
    this.viewLabel = new JLabel(getResource("viewer.view.label"));
    this.runButton = createRunButton("viewer.run.online");
    this.importButton = createImageButton("viewer.import", 0);
    this.importButton.addActionListener(actionListener4);
    this.removeButton = createImageButton("viewer.remove", 0);
    this.removeButton.addActionListener(actionListener5);
    this.removeResourceButton = createImageButton("viewer.remove.res", 0);
    this.removeResourceButton.addActionListener(actionListener5);
    this.removeRemovedButton = createImageButton("viewer.remove.removed", 0);
    this.removeRemovedButton.addActionListener(actionListener5);
    this.installButton = createImageButton("viewer.install", 0);
    this.installButton.addActionListener(actionListener3);
    this.showButton = createImageButton("viewer.show", 0);
    this.showButton.addActionListener(actionListener6);
    this.showResourceButton = createImageButton("viewer.info", 0);
    this.showResourceButton.addActionListener(actionListener6);
    this.homeButton = createImageButton("viewer.home", 0);
    this.homeButton.addActionListener(actionListener7);
    this.tablePanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 6, 12));
    this.closeButton = new JButton(getResource("viewer.close"));
    this.closeButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.exitViewer(); }
        });
    addCancelAction();
    JButton jButton = new JButton(getResource("viewer.help"));
    jButton.setMnemonic(ResourceManager.getMnemonic("viewer.help"));
    jButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.help(); }
        });
    jPanel2.add(this.closeButton);
    jPanel1.add(jPanel2, "East");
    jPanel1.setBorder(BorderFactory.createEmptyBorder(0, 8, 8, 8));
    JPanel jPanel3 = new JPanel(new BorderLayout());
    jPanel3.add(this.toolbar, "Center");
    jPanel3.add(new JSeparator(), "South");
    JPanel jPanel4 = new JPanel(new BorderLayout());
    jPanel4.add(this.tablePanel, "Center");
    jPanel4.add(jPanel1, "South");
    getContentPane().add(jPanel3, "North");
    getContentPane().add(jPanel4, "Center");
    this.runPopup = new JPopupMenu();
    this.onlineMI = this.runPopup.add(getResource("viewer.run.online.mi"));
    this.onlineMI.setEnabled(false);
    this.onlineMI.setIcon(getIcon("viewer.run.online.mi.icon"));
    this.onlineMI.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.runApplication(true); }
        });
    this.offlineMI = this.runPopup.add(getResource("viewer.run.offline.mi"));
    this.offlineMI.setEnabled(false);
    this.offlineMI.setIcon(getIcon("viewer.run.offline.mi.icon"));
    this.offlineMI.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.runApplication(false); }
        });
    this.runPopup.addPopupMenuListener(this);
    this.runPopup.addMenuKeyListener(new MenuKeyListener() {
          public void menuKeyPressed(MenuKeyEvent param1MenuKeyEvent) {
            int i = param1MenuKeyEvent.getKeyCode();
            if (i == 9 || i == 39 || i == 37)
              CacheViewer.this.runPopup.setVisible(false); 
          }
          
          public void menuKeyReleased(MenuKeyEvent param1MenuKeyEvent) {}
          
          public void menuKeyTyped(MenuKeyEvent param1MenuKeyEvent) {}
        });
    this.jnlpTable = new CacheTable(this, 0, false);
    if (this.jnlpTable.getModel().getRowCount() != 0) {
      this.viewComboBox.setSelectedIndex(0);
      focusLater(this.jnlpTable);
      return;
    } 
    this.resourceTable = new CacheTable(this, 1, false);
    if (this.resourceTable.getModel().getRowCount() != 0) {
      this.viewComboBox.setSelectedIndex(1);
      focusLater(this.resourceTable);
      return;
    } 
    this.importTable = new CacheTable(this, 2, false);
    if (this.importTable.getModel().getRowCount() != 0) {
      this.viewComboBox.setSelectedIndex(2);
      focusLater(this.importTable);
      return;
    } 
    focusLater(this.closeButton);
    refresh();
  }
  
  private void focusLater(final Component component) { SwingUtilities.invokeLater(new Runnable() {
          public void run() { component.requestFocus(); }
        }); }
  
  public void addCancelAction() {
    getRootPane().getInputMap(2).put(KeyStroke.getKeyStroke(27, 0), "cancelViewer");
    getRootPane().getActionMap().put("cancelViewer", new AbstractAction() {
          public void actionPerformed(ActionEvent param1ActionEvent) { CacheViewer.this.exitViewer(); }
        });
  }
  
  public void removeCancelAction() {
    InputMap inputMap = getRootPane().getInputMap(2);
    KeyStroke keyStroke = KeyStroke.getKeyStroke(27, 0);
    if (inputMap != null) {
      inputMap.remove(keyStroke);
      getRootPane().setInputMap(2, inputMap);
    } 
  }
  
  public void popupMenuCanceled(PopupMenuEvent paramPopupMenuEvent) {}
  
  public void popupMenuWillBecomeInvisible(PopupMenuEvent paramPopupMenuEvent) { addCancelAction(); }
  
  public void popupMenuWillBecomeVisible(PopupMenuEvent paramPopupMenuEvent) { removeCancelAction(); }
  
  void runApplication() { runApplication(true); }
  
  void delete() {
    if (this.activeTable == this.jnlpTable || this.activeTable == this.sysJnlpTable) {
      removeApplications();
    } else if (this.activeTable == this.resourceTable || this.activeTable == this.sysResourceTable) {
      removeResources();
    } else if (this.activeTable == this.importTable) {
      removeRemoved();
    } 
  }
  
  void runApplication(boolean paramBoolean) {
    try {
      CacheObject cacheObject = getSelectedCacheObject();
      if (cacheObject != null) {
        LaunchDesc launchDesc = cacheObject.getLaunchDesc();
        if (launchDesc != null && launchDesc.isApplicationDescriptor() && (paramBoolean || launchDesc.getInformation().supportsOfflineOperation())) {
          String[] arrayOfString = new String[4];
          arrayOfString[0] = Environment.getJavawsCommand();
          arrayOfString[1] = paramBoolean ? "-online" : "-offline";
          arrayOfString[2] = "-localfile";
          arrayOfString[3] = cacheObject.getJnlpFile().getPath();
          Process process = Runtime.getRuntime().exec(arrayOfString);
          traceStream(process.getInputStream());
          traceStream(process.getErrorStream());
        } 
      } 
    } catch (Throwable throwable) {
      Trace.ignored(throwable);
    } 
  }
  
  void removeApplications() { removeResources(); }
  
  void importApplication() {
    if (this.activeTable == this.importTable)
      try {
        CacheObject[] arrayOfCacheObject = getSelectedCacheObjects();
        if (arrayOfCacheObject.length > 0)
          showWaitDialog(arrayOfCacheObject, 1); 
      } catch (Throwable throwable) {
        Trace.ignored(throwable);
      }  
  }
  
  void installApplication() {
    LocalInstallHandler localInstallHandler = LocalInstallHandler.getInstance();
    CacheObject cacheObject = getSelectedCacheObject();
    if (cacheObject != null && localInstallHandler.isLocalInstallSupported()) {
      LocalApplicationProperties localApplicationProperties = cacheObject.getLocalApplicationProperties();
      localApplicationProperties.refreshIfNecessary();
      if (this.activeTable == this.sysJnlpTable) {
        if (!localApplicationProperties.isShortcutInstalledSystem());
      } else if (!localApplicationProperties.isShortcutInstalled() || !localInstallHandler.isShortcutExists(localApplicationProperties)) {
        LaunchDesc launchDesc = cacheObject.getLaunchDesc();
        localInstallHandler.uninstallShortcuts(launchDesc, localApplicationProperties);
        localInstallHandler.installShortcuts(launchDesc, localApplicationProperties);
        enableButtons();
      } 
    } 
  }
  
  private void browseApplication() {
    CacheObject cacheObject = getSelectedCacheObject();
    if (cacheObject != null) {
      LaunchDesc launchDesc = cacheObject.getLaunchDesc();
      if (launchDesc != null) {
        URL uRL = launchDesc.getInformation().getHome();
        showDocument(uRL);
      } 
    } 
  }
  
  private void showApplication() {
    CacheObject cacheObject = getSelectedCacheObject();
    if (cacheObject != null) {
      LaunchDesc launchDesc = cacheObject.getLaunchDesc();
      if (launchDesc != null) {
        String str1 = launchDesc.toString();
        String str2 = getResource("common.ok_btn");
        String str3 = getResource("common.cancel_btn");
        ToolkitStore.getUI();
        ToolkitStore.getUI().showMessageDialog(this, new AppInfo(), -1, getResource("viewer.show.title"), null, str1, null, str2, str3, null);
      } 
    } 
  }
  
  void showInformation() {
    CacheObject cacheObject = getSelectedCacheObject();
    if (cacheObject != null)
      switch (cacheObject.getObjectType()) {
        case 1:
          showApplication();
          break;
        case 2:
        case 3:
          showResource(cacheObject);
          break;
        case 4:
          showImage(cacheObject);
          break;
      }  
  }
  
  void showResource(CacheObject paramCacheObject) {}
  
  void showImage(CacheObject paramCacheObject) {}
  
  void removeRemoved() {
    CacheObject[] arrayOfCacheObject = getSelectedCacheObjects();
    for (byte b = 0; b < arrayOfCacheObject.length; b++)
      Cache.removeRemovedApp(arrayOfCacheObject[b].getDeletedUrl(), arrayOfCacheObject[b].getDeletedTitle()); 
  }
  
  void removeResources() {
    try {
      CacheObject[] arrayOfCacheObject = getSelectedCacheObjects();
      showWaitDialog(arrayOfCacheObject, 0);
    } catch (Throwable throwable) {
      Trace.ignored(throwable);
    } 
  }
  
  public void showWaitDialog(final CacheObject[] co, final int type) {
    boolean bool;
    String str2;
    String str1;
    if (type == 0) {
      bool = true;
      str1 = (co.length > 1) ? "viewer.wait.remove" : "viewer.wait.remove.single";
      str2 = getResource("viewer.wait.remove.title");
    } else {
      bool = false;
      str1 = (co.length > 1) ? "viewer.wait.import" : "viewer.wait.import.single";
      str2 = getResource("viewer.wait.import.title");
    } 
    String str3 = getResource(str1);
    final CacheViewDialog dw = new CacheViewDialog();
    cacheViewDialog.initialize(this, bool);
    cacheViewDialog.setHeading(str3, false);
    cacheViewDialog.setTitle(str2);
    cacheViewDialog.setProgressBarVisible(true);
    cacheViewDialog.setIndeterminate((co.length == 1));
    cacheViewDialog.setProgressBarValue(0);
    cacheViewDialog.setVisible(true);
    Thread thread = new Thread(new Runnable() {
          public void run() {
            for (byte b = 0; b < co.length; b++) {
              try {
                if (type == 0) {
                  boolean bool = (CacheViewer.this.activeTable == CacheViewer.this.sysJnlpTable || CacheViewer.this.activeTable == CacheViewer.this.sysResourceTable) ? true : false;
                  if (bool) {
                    Environment.setSystemCacheMode(true);
                    Cache.reset();
                  } 
                  LaunchDesc launchDesc = co[b].getLaunchDesc();
                  CacheEntry cacheEntry = co[b].getCE();
                  String str1 = co[b].getNameString();
                  String str2 = co[b].getUrlString();
                  if (launchDesc == null) {
                    dw.setApplication(str1, null, str2);
                    Cache.removeAllCacheEntries(cacheEntry);
                  } else {
                    str1 = launchDesc.getInformation().getTitle();
                    String str = launchDesc.getInformation().getVendor();
                    dw.setApplication(str1, str, str2);
                    CacheUtil.remove(cacheEntry, launchDesc);
                  } 
                  if (bool) {
                    Environment.setSystemCacheMode(false);
                    Cache.reset();
                  } 
                } else {
                  String str1 = co[b].getDeletedTitle();
                  String str2 = co[b].getDeletedUrl();
                  dw.setApplication(str1, null, str2);
                  String[] arrayOfString = new String[5];
                  arrayOfString[0] = Environment.getJavawsCommand();
                  arrayOfString[1] = "-wait";
                  arrayOfString[2] = "-quiet";
                  arrayOfString[3] = "-import";
                  arrayOfString[4] = str2;
                  Process process = Runtime.getRuntime().exec(arrayOfString);
                  CacheViewer.this.traceStream(process.getInputStream());
                  CacheViewer.this.traceStream(process.getErrorStream());
                  int j = process.waitFor();
                } 
                if (!dw.isVisible())
                  break; 
                int i = (b + 1) * 100 / co.length;
                dw.setProgressBarValue(i);
              } catch (Throwable throwable) {
                Trace.ignored(throwable);
              } 
            } 
            dw.setVisible(false);
            CacheViewer.this.enableButtons();
          }
        });
    thread.start();
  }
  
  private void traceStream(final InputStream is) { (new Thread(new Runnable() {
          public void run() {
            byte[] arrayOfByte = new byte[1024];
            try {
              int i = 0;
              while (i != -1) {
                i = is.read(arrayOfByte);
                if (i <= 0 && i == 0)
                  try {
                    Thread.sleep(200L);
                  } catch (Exception exception) {} 
              } 
            } catch (Exception exception) {}
          }
        })).start(); }
  
  void help() {}
  
  private CacheObject getSelectedCacheObject() {
    int[] arrayOfInt = this.activeTable.getSelectedRows();
    return (arrayOfInt.length == 1) ? this.activeTable.getCacheObject(arrayOfInt[0]) : null;
  }
  
  private CacheObject[] getSelectedCacheObjects() {
    int[] arrayOfInt = this.activeTable.getSelectedRows();
    int i = this.activeTable.getRowCount();
    for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
      if (arrayOfInt[b1] >= i) {
        Trace.println("Bug in JTable ?, getRowCount() = " + i + " , but getSelectedRows() contains: " + arrayOfInt[b1], TraceLevel.BASIC);
        return new CacheObject[0];
      } 
    } 
    CacheObject[] arrayOfCacheObject = new CacheObject[arrayOfInt.length];
    for (byte b2 = 0; b2 < arrayOfInt.length; b2++)
      arrayOfCacheObject[b2] = this.activeTable.getCacheObject(arrayOfInt[b2]); 
    return arrayOfCacheObject;
  }
  
  private void showDocument(final URL page) { (new Thread(new Runnable() {
          public void run() { BrowserSupport.showDocument(page); }
        })).start(); }
  
  private String getResource(String paramString) { return ResourceManager.getMessage(paramString); }
  
  private Icon getDummyIcon() {
    if (this.dummy == null) {
      try {
        this.dummy = ResourceManager.getIcon("java32.image");
      } catch (Throwable throwable) {}
      if (this.dummy == null)
        this.dummy = new ImageIcon(); 
      Image image = this.dummy.getImage().getScaledInstance(20, 20, 1);
      this.dummy.setImage(image);
    } 
    return this.dummy;
  }
  
  private Icon getIcon(String paramString) {
    try {
      return ResourceManager.getIcon(paramString);
    } catch (Throwable throwable) {
      return getDummyIcon();
    } 
  }
  
  public JButton createRunButton(String paramString) {
    final JButton b = createImageButton(paramString, 8);
    jButton.addMouseListener(new MouseAdapter() {
          boolean clicked = false;
          
          Timer t;
          
          public void mouseClicked(MouseEvent param1MouseEvent) {
            if (!CacheViewer.this.runPopup.isVisible())
              this.clicked = true; 
          }
          
          public void mousePressed(MouseEvent param1MouseEvent) {
            this.clicked = false;
            this.t = new Timer(500, new ActionListener() {
                  public void actionPerformed(ActionEvent param2ActionEvent) {
                    if (!CacheViewer.null.this.clicked && CacheViewer.this.runButton.isEnabled()) {
                      CacheViewer.this.runPopup.show(b, 0, b.getHeight());
                      b.getModel().setPressed(false);
                    } 
                  }
                });
            this.t.setRepeats(false);
            this.t.start();
          }
        });
    jButton.addKeyListener(new KeyAdapter() {
          public void keyPressed(KeyEvent param1KeyEvent) {
            if (param1KeyEvent.getKeyCode() == 40 || param1KeyEvent.getKeyCode() == 225) {
              Timer timer = new Timer(50, new ActionListener() {
                    public void actionPerformed(ActionEvent param2ActionEvent) {
                      if (!CacheViewer.this.runPopup.isVisible() && CacheViewer.this.runButton.isEnabled())
                        CacheViewer.this.runPopup.show(b, 0, b.getHeight()); 
                    }
                  });
              timer.setRepeats(false);
              timer.start();
            } 
          }
        });
    jButton.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) {
            if (!CacheViewer.this.runPopup.isVisible())
              CacheViewer.this.runApplication(); 
          }
        });
    return jButton;
  }
  
  private JButton createImageButton(String paramString, int paramInt) {
    final int w = 32 + paramInt;
    JButton jButton = new JButton() {
        public Dimension getPreferredSize() { return new Dimension(w, 32); }
        
        public Dimension getMinimumSize() { return new Dimension(w, 32); }
        
        public Dimension getMaximumSize() { return new Dimension(w, 32); }
      };
    setButtonIcons(jButton, paramString + ".icon");
    jButton.setToolTipText(getResource(paramString + ".tooltip"));
    return jButton;
  }
  
  private void setButtonIcons(JButton paramJButton, String paramString) {
    ImageIcon[] arrayOfImageIcon = ResourceManager.getIcons(paramString);
    paramJButton.setIcon((arrayOfImageIcon[0] != null) ? arrayOfImageIcon[0] : getDummyIcon());
    if (arrayOfImageIcon[1] != null)
      paramJButton.setPressedIcon(arrayOfImageIcon[1]); 
    if (arrayOfImageIcon[2] != null)
      paramJButton.setDisabledIcon(arrayOfImageIcon[2]); 
    if (arrayOfImageIcon[3] != null)
      paramJButton.setRolloverIcon(arrayOfImageIcon[3]); 
  }
  
  private JMenuItem createMI(String paramString, ActionListener paramActionListener) {
    JMenuItem jMenuItem = new JMenuItem(ResourceManager.getMessage(paramString));
    int i = ResourceManager.getMnemonic(paramString);
    if (i > 0)
      jMenuItem.setMnemonic(i); 
    jMenuItem.addActionListener(paramActionListener);
    return jMenuItem;
  }
  
  private void exitViewer() {
    Rectangle rectangle = getBounds();
    Config.setStringProperty("deployment.javaws.viewer.bounds", "" + rectangle.x + "," + rectangle.y + "," + rectangle.width + "," + rectangle.height);
    if (!this.wasDirty)
      Config.get().storeIfNeeded(); 
    setVisible(false);
    dispose();
  }
  
  public void valueChanged(ListSelectionEvent paramListSelectionEvent) { enableButtons(); }
  
  public void popupApplicationMenu(Component paramComponent, int paramInt1, int paramInt2) {
    CacheObject cacheObject = getSelectedCacheObject();
    if (cacheObject != null)
      this.popup.show(paramComponent, paramInt1, paramInt2); 
  }
  
  private boolean canWriteSys() {
    String str = Config.getSystemCacheDirectory();
    if (str != null)
      try {
        File file = new File(str);
        return file.canWrite();
      } catch (Exception exception) {} 
    return false;
  }
  
  public void enableButtons() {
    CacheObject[] arrayOfCacheObject = getSelectedCacheObjects();
    boolean bool1 = (arrayOfCacheObject.length == 1) ? true : false;
    boolean bool2 = (arrayOfCacheObject.length > 0) ? true : false;
    boolean bool3 = (this.activeTable != this.sysResourceTable && this.activeTable != this.sysJnlpTable) ? true : false;
    this.showButton.setEnabled(bool1);
    this.showMI.setEnabled(bool1);
    this.removeRemovedButton.setEnabled((bool2 && bool3));
    this.importButton.setEnabled(bool2);
    this.importMI.setEnabled(bool2);
    this.removeButton.setEnabled((bool2 && (bool3 || canWriteSys())));
    this.removeMI.setEnabled((bool2 && bool3));
    this.removeResourceButton.setEnabled((bool2 && (bool3 || canWriteSys())));
    this.runButton.setEnabled(false);
    this.runOnlineMI.setEnabled(false);
    this.runOfflineMI.setEnabled(false);
    this.installButton.setEnabled(false);
    this.installMI.setEnabled(false);
    this.homeButton.setEnabled(false);
    this.homeMI.setEnabled(false);
    this.showResourceButton.setEnabled(false);
    this.showResourceMI.setEnabled(false);
    this.onlineMI.setEnabled(false);
    this.offlineMI.setEnabled(false);
    if (bool1) {
      LaunchDesc launchDesc = arrayOfCacheObject[0].getLaunchDesc();
      if (launchDesc != null) {
        if (launchDesc.isApplicationDescriptor()) {
          this.runButton.setEnabled(true);
          this.onlineMI.setEnabled(true);
          this.runOnlineMI.setEnabled(true);
          setButtonIcons(this.runButton, "viewer.run.online.icon");
          this.runButton.setToolTipText(getResource("viewer.run.online.tooltip"));
          if (launchDesc.getInformation().supportsOfflineOperation()) {
            this.runButton.setEnabled(true);
            this.offlineMI.setEnabled(true);
            this.runOfflineMI.setEnabled(true);
            if (launchDesc.getLocation() == null) {
              setButtonIcons(this.runButton, "viewer.run.offline.icon");
              this.runButton.setToolTipText(getResource("viewer.run.offline.tooltip"));
            } 
          } 
          LocalInstallHandler localInstallHandler = LocalInstallHandler.getInstance();
          if (localInstallHandler.isLocalInstallSupported()) {
            LocalApplicationProperties localApplicationProperties = arrayOfCacheObject[0].getLocalApplicationProperties();
            localApplicationProperties.refreshIfNecessary();
            if (!localInstallHandler.isShortcutExists(localApplicationProperties) && this.activeTable == this.jnlpTable) {
              ShortcutDesc shortcutDesc = launchDesc.getInformation().getShortcut();
              if (shortcutDesc == null || shortcutDesc.getMenu() || shortcutDesc.getDesktop()) {
                this.installButton.setEnabled(true);
                this.installMI.setEnabled(true);
              } 
            } 
          } 
        } 
        if (launchDesc.getInformation().getHome() != null) {
          this.homeButton.setEnabled(true);
          this.homeMI.setEnabled(true);
        } 
        this.showResourceButton.setEnabled(true);
        this.showResourceMI.setEnabled(true);
      } 
    } 
    this.activeTable.setEnabled((this.activeTable.getRowCount() > 0));
  }
  
  private void startWatchers() { (new Thread(new Runnable() {
          public void run() {
            long l1 = Cache.getLastAccessed(false);
            long l2 = Cache.getLastAccessed(true);
            long l3 = 0L;
            String str = Cache.getRemovePath();
            File file = new File(str);
            if (file != null && file.exists())
              l3 = file.lastModified(); 
            do {
              try {
                Thread.sleep(2000L);
              } catch (InterruptedException interruptedException) {
                Trace.ignored(interruptedException);
              } 
              long l4 = Cache.getLastAccessed(false);
              long l5 = Cache.getLastAccessed(true);
              long l6 = 0L;
              if (file != null && file.exists())
                l6 = file.lastModified(); 
              if (l4 != l1) {
                l1 = l4;
                SwingUtilities.invokeLater(new Runnable() {
                      public void run() {
                        if (CacheViewer.this.jnlpTable != null)
                          CacheViewer.this.jnlpTable.reset(); 
                        if (CacheViewer.this.resourceTable != null)
                          CacheViewer.this.resourceTable.reset(); 
                        CacheViewer.this.enableButtons();
                        CacheViewer.this.sizeLabel.setText(CacheViewer.this.activeTable.getSizeLabelText());
                      }
                    });
              } 
              if (l5 != l2) {
                l2 = l5;
                SwingUtilities.invokeLater(new Runnable() {
                      public void run() {
                        if (CacheViewer.this.sysJnlpTable != null)
                          CacheViewer.this.sysJnlpTable.reset(); 
                        if (CacheViewer.this.sysResourceTable != null)
                          CacheViewer.this.sysResourceTable.reset(); 
                        CacheViewer.this.enableButtons();
                        CacheViewer.this.sizeLabel.setText(CacheViewer.this.activeTable.getSizeLabelText());
                      }
                    });
              } 
              if (l6 == l3)
                continue; 
              l3 = l6;
              SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                      if (CacheViewer.this.importTable != null)
                        CacheViewer.this.importTable.reset(); 
                      CacheViewer.this.enableButtons();
                    }
                  });
            } while (CacheViewer.this.isShowing());
          }
        })).start(); }
  
  public static void showCacheViewer(JFrame paramJFrame) {
    Cache.reset();
    Main.initializeExecutionEnvironment();
    CacheViewer cacheViewer = new CacheViewer(paramJFrame);
    cacheViewer.setModal(true);
    String str = Config.getStringProperty("deployment.javaws.viewer.bounds");
    if (str != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(str, ",");
      int[] arrayOfInt = new int[4];
      byte b;
      for (b = 0; b < 4; b++) {
        if (stringTokenizer.hasMoreTokens()) {
          String str1 = stringTokenizer.nextToken();
          try {
            arrayOfInt[b] = Integer.parseInt(str1);
          } catch (NumberFormatException numberFormatException) {}
        } 
      } 
      if (b == 4)
        cacheViewer.setBounds(arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3]); 
    } else {
      cacheViewer.setBounds(100, 100, 720, 360);
      UIFactory.placeWindow(cacheViewer);
    } 
    cacheViewer.startWatchers();
    cacheViewer.setVisible(true);
  }
  
  class VSeparator extends JSeparator {
    public VSeparator() { super(1); }
    
    public Dimension getPreferredSize() {
      Dimension dimension = getUI().getPreferredSize(this);
      dimension.height = 20;
      return dimension;
    }
    
    public Dimension getMaximumSize() { return getPreferredSize(); }
  }
  
  private class remainingSpacer extends JComponent {
    private remainingSpacer() {}
    
    public Dimension getPreferredSize() {
      Dimension dimension = super.getPreferredSize();
      Container container = getParent();
      int i = container.getWidth();
      int j = 0;
      Component[] arrayOfComponent = container.getComponents();
      for (byte b = 0; b < arrayOfComponent.length; b++) {
        if (!equals(arrayOfComponent[b])) {
          Dimension dimension1 = arrayOfComponent[b].getPreferredSize();
          j += dimension1.width;
        } 
      } 
      if (i > j)
        dimension.width = i - j; 
      return dimension;
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/CacheViewer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */