package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;

public class JNLParseException extends LaunchDescException {
  private String _msg;
  
  private int _line;
  
  private String _launchDescSource;
  
  public JNLParseException(String paramString1, Exception paramException, String paramString2, int paramInt) {
    super(paramException);
    this._msg = paramString2;
    this._line = paramInt;
    this._launchDescSource = paramString1;
  }
  
  public int getLine() { return this._line; }
  
  public String getRealMessage() { return !isSignedLaunchDesc() ? ResourceManager.getString("launch.error.parse", this._line) : ResourceManager.getString("launch.error.parse-signedjnlp", this._line); }
  
  public String getLaunchDescSource() { return this._launchDescSource; }
  
  public String toString() { return "JNLParseException[ " + getMessage() + "]"; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/JNLParseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */