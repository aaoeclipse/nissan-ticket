package com.sun.jnlp;

import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.javaws.util.JNLPUtils;
import java.awt.print.PageFormat;
import java.awt.print.Pageable;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.PrintService;

public final class PrintServiceImpl implements PrintService {
  private static PrintServiceImpl _sharedInstance = null;
  
  private static ApiDialog _apiDialog = new ApiDialog();
  
  private PageFormat _pageFormat = null;
  
  public static synchronized PrintServiceImpl getInstance() {
    if (_sharedInstance == null)
      _sharedInstance = new PrintServiceImpl(); 
    return _sharedInstance;
  }
  
  public PageFormat getDefaultPage() { return AccessController.doPrivileged(new PrivilegedAction<PageFormat>() {
          public PageFormat run() {
            PrinterJob printerJob = PrinterJob.getPrinterJob();
            return (printerJob != null) ? printerJob.defaultPage() : null;
          }
        }); }
  
  public PageFormat showPageFormatDialog(final PageFormat page) { return AccessController.doPrivileged(new PrivilegedAction<PageFormat>() {
          public PageFormat run() {
            PrinterJob printerJob = PrinterJob.getPrinterJob();
            if (printerJob != null) {
              PrintServiceImpl.this._pageFormat = printerJob.pageDialog(page);
              return PrintServiceImpl.this._pageFormat;
            } 
            return null;
          }
        }); }
  
  public synchronized boolean print(Pageable paramPageable) { return doPrinting(null, paramPageable); }
  
  public synchronized boolean print(Printable paramPrintable) { return doPrinting(paramPrintable, null); }
  
  private boolean doPrinting(final Printable painter, final Pageable document) { return !askUser() ? false : ((Boolean)AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Boolean run() {
            final PrinterJob sysPrinterJob = PrinterJob.getPrinterJob();
            if (printerJob == null)
              return Boolean.FALSE; 
            if (document != null) {
              printerJob.setPageable(document);
            } else if (PrintServiceImpl.this._pageFormat == null) {
              printerJob.setPrintable(painter);
            } else {
              printerJob.setPrintable(painter, PrintServiceImpl.this._pageFormat);
            } 
            if (printerJob.printDialog()) {
              Thread thread = new Thread(new Runnable() {
                    public void run() {
                      try {
                        sysPrinterJob.print();
                      } catch (PrinterException printerException) {
                        Trace.ignoredException(printerException);
                      } 
                    }
                  });
              thread.start();
              return Boolean.TRUE;
            } 
            return Boolean.FALSE;
          }
        })).booleanValue(); }
  
  private synchronized boolean askUser() { return CheckServicePermission.hasPrintAccessPermissions() ? true : requestPrintPermission(); }
  
  public static boolean requestPrintPermission() {
    final LocalApplicationProperties lap = JNLPUtils.getLocalApplicationProperties();
    if (localApplicationProperties != null) {
      String str = localApplicationProperties.get("jnlp.api.always.PrintService.print");
      if (str != null)
        return true; 
    } 
    ApiDialog.DialogResult dialogResult = _apiDialog.askUser(ResourceManager.getString("api.print.title"), ResourceManager.getString("api.print.message"), ResourceManager.getString("api.print.always"));
    if (dialogResult == ApiDialog.DialogResult.ALWAYS)
      AccessController.doPrivileged(new PrivilegedAction<Void>() {
            public Void run() {
              lap.put("jnlp.api.always.PrintService.print", "skip");
              try {
                lap.store();
              } catch (Throwable throwable) {
                Trace.ignored(throwable);
              } 
              return null;
            }
          }); 
    return (dialogResult == ApiDialog.DialogResult.OK || dialogResult == ApiDialog.DialogResult.ALWAYS);
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/PrintServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */