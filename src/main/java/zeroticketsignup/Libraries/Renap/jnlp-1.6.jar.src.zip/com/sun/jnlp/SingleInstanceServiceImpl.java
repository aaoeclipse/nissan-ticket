package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.si.DeploySIListener;
import com.sun.deploy.si.SingleInstanceImpl;
import com.sun.deploy.si.SingleInstanceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.javaws.Globals;
import com.sun.javaws.JnlpxArgs;
import com.sun.javaws.Main;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.jnl.ApplicationDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.XMLFormat;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.SingleInstanceListener;
import javax.jnlp.SingleInstanceService;

public final class SingleInstanceServiceImpl extends SingleInstanceImpl implements SingleInstanceService {
  private static SingleInstanceServiceImpl _sharedInstance = null;
  
  private static boolean listenerExists = false;
  
  public static synchronized SingleInstanceServiceImpl getInstance() {
    if (_sharedInstance == null)
      _sharedInstance = new SingleInstanceServiceImpl(); 
    return _sharedInstance;
  }
  
  public synchronized void addSingleInstanceListener(SingleInstanceListener paramSingleInstanceListener) {
    if (paramSingleInstanceListener == null)
      return; 
    final LaunchDesc ld = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
    URL uRL = launchDesc.getCanonicalHome();
    int i = uRL.toString().lastIndexOf('?');
    if (i != -1)
      try {
        uRL = new URL(uRL.toString().substring(0, i));
      } catch (MalformedURLException malformedURLException) {
        Trace.ignoredException(malformedURLException);
      }  
    final String jnlpUrlString = uRL.toString();
    if (!listenerExists)
      AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
              if (SingleInstanceManager.isServerRunning(jnlpUrlString)) {
                String[] arrayOfString = Globals.getApplicationArgs();
                if (arrayOfString != null) {
                  ApplicationDesc applicationDesc = ld.getApplicationDescriptor();
                  if (applicationDesc != null)
                    applicationDesc.setArguments(arrayOfString); 
                } 
                if (SingleInstanceManager.connectToServer(ld.toString()))
                  try {
                    Main.systemExit(0);
                  } catch (ExitException exitException) {
                    Trace.println("systemExit: " + exitException, TraceLevel.BASIC);
                    Trace.ignoredException((Exception)exitException);
                  }  
              } 
              return null;
            }
          }); 
    addSingleInstanceListener(new TransferListener(paramSingleInstanceListener), str);
    listenerExists = true;
  }
  
  public void removeSingleInstanceListener(SingleInstanceListener paramSingleInstanceListener) { removeSingleInstanceListener(new TransferListener(paramSingleInstanceListener)); }
  
  public boolean isSame(String paramString1, String paramString2) {
    LaunchDesc launchDesc = null;
    try {
      launchDesc = XMLFormat.parse(paramString1.getBytes(), null, null, null);
    } catch (Exception exception) {
      Trace.ignoredException(exception);
    } 
    if (launchDesc != null) {
      URL uRL = launchDesc.getCanonicalHome();
      int i = uRL.toString().lastIndexOf('?');
      if (i != -1)
        try {
          uRL = new URL(uRL.toString().substring(0, i));
        } catch (MalformedURLException malformedURLException) {
          Trace.ignoredException(malformedURLException);
        }  
      String str = uRL.toString() + Platform.get().getSessionSpecificString();
      Trace.println("GOT: " + str, TraceLevel.BASIC);
      if (paramString2.equals(str))
        return true; 
    } 
    return false;
  }
  
  public String[] getArguments(String paramString1, String paramString2) {
    LaunchDesc launchDesc = null;
    try {
      launchDesc = XMLFormat.parse(paramString1.getBytes(), null, null, null);
    } catch (Exception exception) {
      Trace.ignoredException(exception);
    } 
    return (launchDesc != null) ? (launchDesc.isApplication() ? launchDesc.getApplicationDescriptor().getArguments() : super.getArguments(paramString1, paramString2)) : new String[0];
  }
  
  private class TransferListener implements DeploySIListener {
    SingleInstanceListener _sil;
    
    public TransferListener(SingleInstanceListener param1SingleInstanceListener) { this._sil = param1SingleInstanceListener; }
    
    public void newActivation(String[] param1ArrayOfString) {
      if (param1ArrayOfString.length == 2) {
        String str1 = SingleInstanceManager.getOpenPrintFilePath();
        String str2 = SingleInstanceManager.getActionName();
        if (str1 != null && str2 != null && (str2.equals("-open") || str2.equals("-print")) && str1.equals(param1ArrayOfString[1]) && str2.equals(param1ArrayOfString[0])) {
          JnlpxArgs.getFileReadWriteList().add(param1ArrayOfString[1]);
          SingleInstanceManager.setOpenPrintFilePath(null);
          SingleInstanceManager.setActionName(null);
        } 
      } 
      this._sil.newActivation(param1ArrayOfString);
    }
    
    public Object getSingleInstanceListener() { return this._sil; }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/SingleInstanceServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */