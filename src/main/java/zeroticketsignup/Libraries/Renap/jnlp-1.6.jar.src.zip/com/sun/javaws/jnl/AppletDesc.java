package com.sun.javaws.jnl;

import com.sun.deploy.xml.XMLAttribute;
import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import com.sun.deploy.xml.XMLable;
import com.sun.javaws.HtmlOptions;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

public class AppletDesc implements XMLable {
  private String _name;
  
  private String _appletClass;
  
  private String _progressClass;
  
  private URL _documentBase;
  
  private int _width;
  
  private int _height;
  
  private Properties _params;
  
  public AppletDesc(String paramString1, String paramString2, URL paramURL, int paramInt1, int paramInt2, Properties paramProperties, String paramString3) {
    this._name = paramString1;
    this._appletClass = paramString2;
    this._progressClass = paramString3;
    this._documentBase = paramURL;
    this._width = paramInt1;
    this._height = paramInt2;
    this._params = paramProperties;
    if (HtmlOptions.get() != null) {
      Properties properties = HtmlOptions.get().getParameters();
      if (properties != null)
        this._params.putAll(properties); 
    } 
  }
  
  public String getName() { return this._name; }
  
  public String getAppletClass() { return this._appletClass; }
  
  public String getProgressClass() { return this._progressClass; }
  
  public URL getDocumentBase() { return this._documentBase; }
  
  public int getWidth() { return this._width; }
  
  public int getHeight() { return this._height; }
  
  public Properties getParameters() { return this._params; }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("name", this._name);
    xMLAttributeBuilder.add("main-class", this._appletClass);
    xMLAttributeBuilder.add("progress-class", this._progressClass);
    xMLAttributeBuilder.add("documentbase", this._documentBase);
    xMLAttributeBuilder.add("width", this._width);
    xMLAttributeBuilder.add("height", this._height);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("applet-desc", xMLAttributeBuilder.getAttributeList());
    if (this._params != null) {
      Enumeration<Object> enumeration = this._params.keys();
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        String str2 = this._params.getProperty(str1);
        xMLNodeBuilder.add(new XMLNode("param", new XMLAttribute("name", str1, new XMLAttribute("value", str2)), null, null));
      } 
    } 
    return xMLNodeBuilder.getNode();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/AppletDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */