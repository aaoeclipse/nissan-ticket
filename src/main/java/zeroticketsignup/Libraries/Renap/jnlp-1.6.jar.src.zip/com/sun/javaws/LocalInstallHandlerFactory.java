package com.sun.javaws;

public class LocalInstallHandlerFactory {
  public static LocalInstallHandler newInstance() { return new WinInstallHandler(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/LocalInstallHandlerFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */