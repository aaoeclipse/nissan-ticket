package com.sun.javaws.jnl;

import com.sun.deploy.config.Config;
import com.sun.deploy.util.OrderedHashSet;
import com.sun.deploy.util.Property;
import com.sun.deploy.util.URLUtil;
import com.sun.deploy.util.VersionString;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

public class ResourcesDesc implements ResourceType {
  private final List<ResourceType> _list = new CopyOnWriteArrayList<ResourceType>();
  
  private volatile LaunchDesc _parent = null;
  
  private volatile boolean _pack200Enabled = false;
  
  private volatile boolean _versionEnabled = false;
  
  private volatile int _concurrentDownloads = 0;
  
  public void setPack200Enabled() { this._pack200Enabled = true; }
  
  public void setVersionEnabled() { this._versionEnabled = true; }
  
  public boolean isPack200Enabled() { return Config.isJavaVersionAtLeast15() ? this._pack200Enabled : false; }
  
  public boolean isVersionEnabled() { return this._versionEnabled; }
  
  public void setConcurrentDownloads(int paramInt) { this._concurrentDownloads = paramInt; }
  
  public int getConcurrentDownloads() { return (this._concurrentDownloads <= 0) ? Property.CONCURRENT_DOWNLOADS_DEF : ((this._concurrentDownloads > 10) ? 10 : this._concurrentDownloads); }
  
  public LaunchDesc getParent() { return this._parent; }
  
  void setParent(LaunchDesc paramLaunchDesc) {
    this._parent = paramLaunchDesc;
    for (byte b = 0; b < this._list.size(); b++) {
      JREDesc jREDesc = (JREDesc)this._list.get(b);
      if (jREDesc instanceof JREDesc) {
        JREDesc jREDesc1 = jREDesc;
        if (jREDesc1.getNestedResources() != null)
          jREDesc1.getNestedResources().setParent(paramLaunchDesc); 
      } 
    } 
  }
  
  public void addResource(ResourceType paramResourceType) {
    if (paramResourceType != null)
      this._list.add(paramResourceType); 
  }
  
  boolean isEmpty() { return this._list.isEmpty(); }
  
  public JARDesc[] getLocalJarDescs() {
    ArrayList<JARDesc> arrayList = new ArrayList(this._list.size());
    for (ResourceType resourceType : this._list) {
      if (resourceType instanceof JARDesc)
        arrayList.add((JARDesc)resourceType); 
    } 
    return arrayList.toArray(new JARDesc[arrayList.size()]);
  }
  
  public ExtensionDesc[] getExtensionDescs() {
    final ArrayList extList = new ArrayList();
    visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) { ResourcesDesc.this.addExtToList(extList); }
        });
    return (ExtensionDesc[])arrayList.toArray((Object[])new ExtensionDesc[arrayList.size()]);
  }
  
  public JARDesc[] getEagerOrAllJarDescs(boolean paramBoolean) {
    final HashSet<String> eagerParts = new HashSet();
    if (!paramBoolean)
      visit(new ResourceVisitor() {
            public void visitJARDesc(JARDesc param1JARDesc) {
              if (!param1JARDesc.isLazyDownload() && param1JARDesc.getPartName() != null)
                eagerParts.add(param1JARDesc.getPartName()); 
            }
          }); 
    ArrayList<JARDesc> arrayList = new ArrayList();
    addJarsToList(arrayList, hashSet, paramBoolean, true);
    return arrayList.toArray(new JARDesc[arrayList.size()]);
  }
  
  private void addExtToList(final List<ExtensionDesc> list) { visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (param1ExtensionDesc.getExtensionDesc() != null) {
              param1ExtensionDesc.getExtensionDesc().getMainJar();
              ResourcesDesc resourcesDesc = param1ExtensionDesc.getExtensionDesc().getResources();
              if (resourcesDesc != null)
                resourcesDesc.addExtToList(list); 
            } 
            list.add(param1ExtensionDesc);
          }
        }); }
  
  private void addJarsToList(final List<JARDesc> list, final Set<String> includeParts, final boolean includeAll, final boolean includeEager) { visit(new ResourceVisitor() {
          public void visitJARDesc(JARDesc param1JARDesc) {
            if (includeAll || (includeEager && !param1JARDesc.isLazyDownload()) || includeParts.contains(param1JARDesc.getPartName()))
              list.add(param1JARDesc); 
          }
          
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            Set<String> set = param1ExtensionDesc.getExtensionPackages(includeParts, includeEager);
            if (param1ExtensionDesc.getExtensionDesc() != null) {
              ResourcesDesc resourcesDesc = param1ExtensionDesc.getExtensionDesc().getResources();
              if (resourcesDesc != null)
                resourcesDesc.addJarsToList(list, set, includeAll, includeEager); 
            } 
          }
        }); }
  
  public JARDesc[] getPartJars(String[] paramArrayOfString) {
    HashSet<String> hashSet = new HashSet();
    for (String str : paramArrayOfString)
      hashSet.add(str); 
    ArrayList<JARDesc> arrayList = new ArrayList();
    addJarsToList(arrayList, hashSet, false, false);
    return arrayList.toArray(new JARDesc[arrayList.size()]);
  }
  
  public JARDesc[] getPartJars(String paramString) { return getPartJars(new String[] { paramString }); }
  
  public JARDesc[] getResource(final URL location, final String version) {
    final JARDesc[] resources = new JARDesc[1];
    visit(new ResourceVisitor() {
          public void visitJARDesc(JARDesc param1JARDesc) {
            if (URLUtil.sameURLs(param1JARDesc.getLocation(), location)) {
              VersionString versionString = (param1JARDesc.getVersion() != null) ? new VersionString(param1JARDesc.getVersion()) : null;
              if (version == null && versionString == null) {
                resources[0] = param1JARDesc;
              } else if (versionString.contains(version)) {
                resources[0] = param1JARDesc;
              } 
            } 
          }
        });
    return (arrayOfJARDesc[0] == null) ? null : ((arrayOfJARDesc[0].getPartName() != null) ? getPartJars(arrayOfJARDesc[0].getPartName()) : arrayOfJARDesc);
  }
  
  public JARDesc[] getExtensionPart(URL paramURL, String paramString, String[] paramArrayOfString) {
    ExtensionDesc extensionDesc = findExtension(paramURL, paramString);
    if (extensionDesc == null)
      return null; 
    ResourcesDesc resourcesDesc = extensionDesc.getExtensionResources();
    return (resourcesDesc == null) ? null : resourcesDesc.getPartJars(paramArrayOfString);
  }
  
  private ExtensionDesc findExtension(final URL location, final String version) {
    final ExtensionDesc[] ea = new ExtensionDesc[1];
    visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (ea[0] == null)
              if (URLUtil.sameURLs(param1ExtensionDesc.getLocation(), location) && (version == null || (new VersionString(version)).contains(param1ExtensionDesc.getVersion()))) {
                ea[0] = param1ExtensionDesc;
              } else {
                LaunchDesc launchDesc = param1ExtensionDesc.getExtensionDesc();
                if (launchDesc != null && launchDesc.getResources() != null)
                  ea[0] = launchDesc.getResources().findExtension(location, version); 
              }  
          }
        });
    return arrayOfExtensionDesc[0];
  }
  
  public JARDesc getProgressJar() {
    final JARDesc[] results = new JARDesc[2];
    arrayOfJARDesc[0] = null;
    visit(new ResourceVisitor() {
          public void visitJARDesc(JARDesc param1JARDesc) {
            if (param1JARDesc.isProgressJar())
              results[0] = param1JARDesc; 
          }
        });
    return arrayOfJARDesc[0];
  }
  
  protected JARDesc getMainJar() {
    final JARDesc[] results = new JARDesc[2];
    visit(new ResourceVisitor() {
          public void visitJARDesc(JARDesc param1JARDesc) {
            if (param1JARDesc.isJavaFile()) {
              if (results[0] == null)
                results[0] = param1JARDesc; 
              if (param1JARDesc.isMainJarFile())
                results[1] = param1JARDesc; 
            } 
          }
          
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (results[1] == null && !param1ExtensionDesc.isInstaller()) {
              LaunchDesc launchDesc = param1ExtensionDesc.getExtensionDesc();
              if (launchDesc != null && launchDesc.isLibrary()) {
                ResourcesDesc resourcesDesc = launchDesc.getResources();
                if (resourcesDesc != null)
                  resourcesDesc.visit(this); 
              } 
            } 
          }
        });
    JARDesc jARDesc1 = arrayOfJARDesc[0];
    JARDesc jARDesc2 = arrayOfJARDesc[1];
    return (this._parent.isLibrary() || jARDesc2 == null) ? jARDesc1 : jARDesc2;
  }
  
  public JARDesc[] getPart(final String name) {
    final ArrayList jarList = new ArrayList();
    visit(new ResourceVisitor() {
          public void visitJARDesc(JARDesc param1JARDesc) {
            if (name.equals(param1JARDesc.getPartName()))
              jarList.add(param1JARDesc); 
          }
        });
    return (JARDesc[])arrayList.toArray((Object[])new JARDesc[arrayList.size()]);
  }
  
  public JARDesc[] getExtensionPart(final URL url, final String version, final String part) {
    final JARDesc[][] jdss = new JARDesc[1][];
    visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (URLUtil.sameURLs(param1ExtensionDesc.getLocation(), url))
              if (version == null) {
                if (param1ExtensionDesc.getVersion() == null && param1ExtensionDesc.getExtensionResources() != null)
                  jdss[0] = param1ExtensionDesc.getExtensionResources().getPart(part); 
              } else if (version.equals(param1ExtensionDesc.getVersion()) && param1ExtensionDesc.getExtensionResources() != null) {
                jdss[0] = param1ExtensionDesc.getExtensionResources().getPart(part);
              }  
          }
        });
    return arrayOfJARDesc[0];
  }
  
  public Properties getResourceProperties() {
    final Properties props = new Properties();
    visit(new ResourceVisitor() {
          public void visitPropertyDesc(PropertyDesc param1PropertyDesc) { props.setProperty(param1PropertyDesc.getKey(), param1PropertyDesc.getValue()); }
        });
    return properties;
  }
  
  public List<Property> getResourcePropertyList() {
    final OrderedHashSet orderedProperties = new OrderedHashSet();
    visit(new ResourceVisitor() {
          public void visitPropertyDesc(PropertyDesc param1PropertyDesc) { orderedProperties.add(new Property(param1PropertyDesc.getKey(), param1PropertyDesc.getValue())); }
        });
    return orderedHashSet.toList();
  }
  
  public PackageInformation getPackageInformation(String paramString) {
    paramString = paramString.replace('/', '.');
    if (paramString.endsWith(".class"))
      paramString = paramString.substring(0, paramString.length() - 6); 
    return visitPackageElements(getParent(), paramString);
  }
  
  public boolean isPackagePart(final String part) {
    final boolean[] result = { false };
    visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (!param1ExtensionDesc.isInstaller()) {
              LaunchDesc launchDesc = param1ExtensionDesc.getExtensionDesc();
              if (!result[0] && launchDesc != null && launchDesc.isLibrary() && launchDesc.getResources() != null)
                result[0] = launchDesc.getResources().isPackagePart(part); 
            } 
          }
          
          public void visitPackageDesc(PackageDesc param1PackageDesc) {
            if (param1PackageDesc.getPart().equals(part))
              result[0] = true; 
          }
        });
    return arrayOfBoolean[0];
  }
  
  private static PackageInformation visitPackageElements(final LaunchDesc ld, final String name) {
    final PackageInformation[] result = new PackageInformation[1];
    ld.getResources().visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (!param1ExtensionDesc.isInstaller()) {
              LaunchDesc launchDesc = param1ExtensionDesc.getExtensionDesc();
              if (result[0] == null && launchDesc != null && launchDesc.isLibrary() && launchDesc.getResources() != null)
                result[0] = ResourcesDesc.visitPackageElements(launchDesc, name); 
            } 
          }
          
          public void visitPackageDesc(PackageDesc param1PackageDesc) {
            if (result[0] == null && param1PackageDesc.match(name))
              result[0] = new ResourcesDesc.PackageInformation(ld, param1PackageDesc.getPart()); 
          }
        });
    return arrayOfPackageInformation[0];
  }
  
  public void visit(ResourceVisitor paramResourceVisitor) {
    for (byte b = 0; b < this._list.size(); b++) {
      ResourceType resourceType = this._list.get(b);
      resourceType.visit(paramResourceVisitor);
    } 
  }
  
  public XMLNode asXML() {
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("resources", null);
    for (byte b = 0; b < this._list.size(); b++) {
      ResourceType resourceType = this._list.get(b);
      xMLNodeBuilder.add(resourceType);
    } 
    return xMLNodeBuilder.getNode();
  }
  
  public void addNested(ResourcesDesc paramResourcesDesc) {
    if (paramResourcesDesc != null)
      paramResourcesDesc.visit(new ResourceVisitor() {
            public void visitJARDesc(JARDesc param1JARDesc) { ResourcesDesc.this._list.add(param1JARDesc); }
            
            public void visitPropertyDesc(PropertyDesc param1PropertyDesc) { ResourcesDesc.this._list.add(param1PropertyDesc); }
            
            public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) { ResourcesDesc.this._list.add(param1ExtensionDesc); }
          }); 
  }
  
  public ResourcesDesc clone() {
    ResourcesDesc resourcesDesc = new ResourcesDesc();
    resourcesDesc._concurrentDownloads = this._concurrentDownloads;
    resourcesDesc._pack200Enabled = this._pack200Enabled;
    resourcesDesc._versionEnabled = this._versionEnabled;
    resourcesDesc._parent = this._parent;
    resourcesDesc._list.addAll(this._list);
    return resourcesDesc;
  }
  
  public static class PackageInformation {
    private LaunchDesc _launchDesc;
    
    private String _part;
    
    PackageInformation(LaunchDesc param1LaunchDesc, String param1String) {
      this._launchDesc = param1LaunchDesc;
      this._part = param1String;
    }
    
    public LaunchDesc getLaunchDesc() { return this._launchDesc; }
    
    public String getPart() { return this._part; }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/ResourcesDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */