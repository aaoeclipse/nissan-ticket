package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;
import com.sun.javaws.jnl.LaunchDesc;

public class NoLocalJREException extends JNLPException {
  private String _message;
  
  public NoLocalJREException(LaunchDesc paramLaunchDesc, String paramString, boolean paramBoolean) {
    super(ResourceManager.getString("launch.error.category.config"), paramLaunchDesc);
    if (paramBoolean) {
      this._message = ResourceManager.getString("launch.error.wont.download.jre", paramString);
    } else {
      this._message = ResourceManager.getString("launch.error.cant.download.jre", paramString);
    } 
  }
  
  public String getRealMessage() { return this._message; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/NoLocalJREException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */