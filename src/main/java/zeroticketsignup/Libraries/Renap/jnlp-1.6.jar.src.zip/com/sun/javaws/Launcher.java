package com.sun.javaws;

import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.Preloader;
import com.sun.applet2.preloader.event.AppInitEvent;
import com.sun.applet2.preloader.event.ConfigEvent;
import com.sun.applet2.preloader.event.DownloadEvent;
import com.sun.applet2.preloader.event.InitEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.config.OSType;
import com.sun.deploy.config.Platform;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.FailedDownloadException;
import com.sun.deploy.net.offline.DeployOfflineManager;
import com.sun.deploy.pings.Pings;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.security.BlockedException;
import com.sun.deploy.security.DeployManifestChecker;
import com.sun.deploy.security.SecureStaticVersioning;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.deploy.si.SingleInstanceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.uitoolkit.ui.ComponentRef;
import com.sun.deploy.util.JVMParameters;
import com.sun.deploy.util.PerfLogger;
import com.sun.deploy.util.SessionState;
import com.sun.deploy.util.SystemUtils;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.exceptions.JreExecException;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.exceptions.MissingFieldException;
import com.sun.javaws.exceptions.OfflineLaunchException;
import com.sun.javaws.jnl.AppletDesc;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.JREDesc;
import com.sun.javaws.jnl.JREMatcher;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.jnl.ResourcesDesc;
import com.sun.javaws.progress.PreloaderDelegate;
import com.sun.javaws.progress.Progress;
import com.sun.javaws.security.AppContextUtil;
import com.sun.javaws.security.AppPolicy;
import com.sun.javaws.security.JNLPSignedResourcesHelper;
import com.sun.javaws.security.JavaWebStartSecurity;
import com.sun.javaws.ui.ApplicationIconGenerator;
import com.sun.javaws.ui.LaunchErrorDialog;
import com.sun.javaws.ui.SplashScreen;
import com.sun.javaws.util.JavawsConsoleController;
import com.sun.javaws.util.JfxHelper;
import com.sun.jnlp.AppletContainer;
import com.sun.jnlp.AppletContainerCallback;
import com.sun.jnlp.BasicServiceImpl;
import com.sun.jnlp.ExtensionInstallerServiceImpl;
import com.sun.jnlp.JNLPClassLoader;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.CodeSource;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import sun.awt.AppContext;

public class Launcher implements Runnable {
  private LaunchDesc _initialLaunchDesc;
  
  protected LaunchDesc _launchDesc;
  
  protected String[] _args;
  
  protected boolean _exit = true;
  
  private JAuthenticator _ja;
  
  private LocalApplicationProperties _lap = null;
  
  private JNLPClassLoader _jnlpClassLoader = null;
  
  private JREInfo _jreInfo = null;
  
  private boolean _isRelaunch = false;
  
  private boolean _isCached = false;
  
  private boolean _disableCustomPreloader = false;
  
  boolean securityManagerDiabledForTests = false;
  
  private boolean _shownDownloadWindow = false;
  
  public Launcher(LaunchDesc paramLaunchDesc) { this._initialLaunchDesc = paramLaunchDesc; }
  
  public void launch(String[] paramArrayOfString, boolean paramBoolean) {
    this._args = paramArrayOfString;
    this._exit = paramBoolean;
    if (!Environment.isImportMode() && this._initialLaunchDesc.getCanonicalHome() != null && SingleInstanceManager.isServerRunning(this._initialLaunchDesc.getCanonicalHome().toString())) {
      String[] arrayOfString = Globals.getApplicationArgs();
      if (arrayOfString == null && HtmlOptions.get() != null)
        arrayOfString = HtmlOptions.get().getHtmlApplicationArgs(); 
      if (arrayOfString != null && arrayOfString.length > 0 && this._initialLaunchDesc.getApplicationDescriptor() != null)
        this._initialLaunchDesc.getApplicationDescriptor().setArguments(arrayOfString); 
      if (SingleInstanceManager.connectToServer(this._initialLaunchDesc.toString())) {
        Trace.println("Exiting (launched in the other instance)", TraceLevel.BASIC);
        try {
          ToolkitStore.get().dispose();
        } catch (Exception exception) {
          Trace.ignoredException(exception);
        } 
        return;
      } 
    } 
    if (prepareToLaunch()) {
      String str = Platform.get().getSystemJavawsPath();
      File file = ResourceProvider.get().getCachedJNLPFile(this._launchDesc.getCanonicalHome(), null);
      try {
        String str1 = null;
        if (file != null) {
          str1 = file.getCanonicalPath();
        } else if (this._launchDesc.getLocation() != null) {
          str1 = this._launchDesc.getLocation().toString();
        } 
        (new String[2])[0] = str;
        (new String[2])[1] = str1;
        String[] arrayOfString = (str1 == null) ? null : new String[2];
        Platform.get().getAutoUpdater().checkForUpdate(arrayOfString);
      } catch (IOException iOException) {
        Trace.ignored(iOException);
        Platform.get().getAutoUpdater().checkForUpdate(null);
      } 
      if (useAppletLifecycle())
        return; 
      (new Thread(Main.getLaunchThreadGroup(), this, "javawsApplicationMain")).start();
    } else if (!Environment.isImportMode()) {
      LaunchErrorDialog.show(Progress.get(null).getOwner(), new Exception(ResourceManager.getString("launch.error.category.unexpected")), true);
    } 
  }
  
  public void run() {
    try {
      doLaunchApp();
    } catch (Throwable throwable1) {
      ExitException exitException = null;
      Throwable throwable2 = throwable1.getCause();
      if (throwable2 != null && throwable2 instanceof ExitException) {
        exitException = (ExitException)throwable2;
      } else if (throwable1 instanceof ExitException) {
        exitException = (ExitException)throwable1;
      } else {
        exitException = new ExitException(throwable1, 3);
      } 
      boolean bool = (exitException.getReason() == 0 || throwable1 instanceof BlockedException) ? false : true;
      if (bool && this._launchDesc != null && this._launchDesc.isApplication()) {
        URL uRL = this._launchDesc.getCanonicalHome();
        SecureStaticVersioning.resetAcceptedVersion(uRL, this._launchDesc.getAppInfo());
      } 
      if (exitException.getReason() == 3) {
        if (this._launchDesc != null && this._launchDesc.getUpdater().isBackgroundUpdateRunning() && this._lap != null) {
          this._lap.setForceUpdateCheck(true);
          try {
            this._lap.store();
          } catch (Exception exception) {}
        } 
        LaunchErrorDialog.show(Progress.get(null).getOwner(), exitException.getException(), this._exit);
      } 
      if (this._exit)
        try {
          Main.systemExit(bool);
        } catch (ExitException exitException1) {
          Trace.println("systemExit: " + exitException1, TraceLevel.BASIC);
          Trace.ignoredException((Exception)exitException1);
        }  
    } 
  }
  
  private boolean isImport() { return (Environment.isImportMode() || (this._launchDesc != null && this._launchDesc.isLibrary())); }
  
  boolean prepareToLaunch() {
    PerfLogger.setTime("Start: prepareToLaunch()");
    PerfLogger.setTime("setting tryOffline");
    boolean bool = (Cache.isCacheEnabled() && (this._initialLaunchDesc.getUpdate().isBackgroundCheck() || DeployOfflineManager.isForcedOffline() || JnlpxArgs.getIsRelaunch())) ? true : false;
    PerfLogger.setTime(" tryOffline = " + bool);
    try {
      if (!bool && DeployOfflineManager.isForcedOffline())
        throw new CacheUpdateRequiredException("Forced offline mode!"); 
      boolean bool1 = prepareToLaunch(bool);
      PerfLogger.setTime("End: prepareToLaunch()");
      return bool1;
    } catch (CacheUpdateRequiredException cacheUpdateRequiredException) {
      Trace.println(ResourceManager.getMessage("launch.error.cache") + " [" + cacheUpdateRequiredException.getMessage() + "]", TraceLevel.BASIC);
      if (bool)
        if (DeployOfflineManager.isForcedOffline()) {
          DeployOfflineManager.setForcedOffline(false);
          if (!DeployOfflineManager.askUserGoOnline(this._initialLaunchDesc.getLocation())) {
            DeployOfflineManager.setForcedOffline(true);
            Trace.println("User chose not to go online and we can not not start in offline mode");
            LaunchErrorDialog.show(Progress.get(null).getOwner(), (Throwable)new OfflineLaunchException(0), this._exit);
            return false;
          } 
        } else if (!JnlpxArgs.getIsRelaunch()) {
          this._initialLaunchDesc = LaunchDescFactory.tryUpdateDescriptor(this._initialLaunchDesc);
        }  
      try {
        boolean bool1 = prepareToLaunch(false);
        PerfLogger.setTime("End: prepareToLaunch()");
        return bool1;
      } catch (CacheUpdateRequiredException cacheUpdateRequiredException1) {
        Trace.println("Unexpected exception: " + cacheUpdateRequiredException1);
        return false;
      } 
    } 
  }
  
  private boolean canRelaunch() {
    if (this._isRelaunch) {
      Trace.println("JAVAWS: Relaunch ignored: relaunched already", TraceLevel.BASIC);
      return false;
    } 
    return true;
  }
  
  private boolean prepareToLaunch(boolean paramBoolean) throws CacheUpdateRequiredException {
    PerfLogger.setTime("Start: prepareToLaunch1()");
    try {
      Object object;
      Trace.println("prepareToLaunch: offlineOnly=" + paramBoolean, TraceLevel.NETWORK);
      PerfLogger.setTime("Begin updateFinalLaunchDesc");
      boolean bool1 = updateFinalLaunchDesc(this._initialLaunchDesc, 0, paramBoolean);
      if (this._launchDesc != null && this._launchDesc.isFXApp())
        ToolkitStore.setToolkitType(11); 
      ToolkitStore.get().getAppContext().put("deploy-main-class", this._launchDesc.getMainClassName());
      removeTempJnlpFile(this._launchDesc);
      if (bool1 && this._launchDesc.isApplicationDescriptor()) {
        Resource resource = ResourceProvider.get().getCachedResource(this._launchDesc.getCanonicalHome(), null);
        File file = (resource != null) ? resource.getDataFile() : null;
        boolean bool = (this._launchDesc.getLocation() != null) ? true : false;
        boolean bool3 = JnlpxArgs.shouldRemoveArgumentFile();
        if (Cache.isCacheEnabled() && (bool || bool3) && this._args != null && file != null)
          this._args[0] = file.getPath(); 
      } 
      PerfLogger.setTime("End updateFinalLaunchDesc");
      boolean bool2 = this._launchDesc.isInstaller();
      this._isRelaunch = JnlpxArgs.getIsRelaunch();
      URL uRL1 = this._launchDesc.getCanonicalHome();
      if (!bool2 && !this._launchDesc.isLibrary()) {
        this._lap = Cache.getLocalApplicationProperties(uRL1);
        if (paramBoolean && this._lap != null && this._lap.forceUpdateCheck())
          throw new CacheUpdateRequiredException("Need to update: force update set in LAP"); 
      } 
      if (bool1 && this._lap != null && Cache.isCacheEnabled() && this._lap.isShortcutInstalled() && LocalInstallHandler.getInstance() != null && LocalInstallHandler.getInstance().isShortcutExists(this._lap))
        notifyLocalInstallHandler(this._launchDesc, this._lap, Globals.isSilentMode(), bool1, Progress.get(null).getOwnerRef()); 
      URL uRL2 = this._launchDesc.getLocation();
      if (uRL2 != null)
        Cache.removeRemovedApp(uRL2.toString(), this._launchDesc.getInformation().getTitle()); 
      Trace.println("isUpdated: " + bool1, TraceLevel.NETWORK);
      if (this._launchDesc.getResources() != null)
        Globals.getDebugOptionsFromProperties(this._launchDesc.getResources().getResourceProperties()); 
      if (Config.getBooleanProperty("deployment.security.authenticator")) {
        this._ja = JAuthenticator.getInstance(Progress.get(null).getOwnerRef());
        Authenticator.setDefault((Authenticator)this._ja);
      } 
      if (this._lap != null) {
        object = LaunchDescFactory.getDerivedCodebase();
        if (object != null)
          this._lap.setCodebase(object.toString()); 
        if (this._args != null && this._args.length > 0) {
          String str1 = LaunchDescFactory.filterUrlFile(this._args[0].toLowerCase());
          if (str1.startsWith("http://") || str1.startsWith("https://"))
            this._lap.setOriginalURL(this._args[0]); 
        } 
        try {
          this._lap.store();
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        } 
        String str = this._lap.getOriginalURL();
        if (str != null && this._launchDesc.getSourceURL() == null)
          try {
            this._launchDesc.setSourceURL(new URL(str));
          } catch (MalformedURLException malformedURLException) {} 
      } 
      if (useAppletLifecycle()) {
        object = this._launchDesc.getDocumentBase().toString() + ": " + this._launchDesc.getArgumentsString();
      } else {
        URL uRL = this._launchDesc.getCodebase();
        object = (uRL != null) ? (uRL.toString() + ": ") : ("(no codebase): " + this._launchDesc.getMainClassName() + " " + this._launchDesc.getArgumentsString());
      } 
      if (this._launchDesc.getSourceURL() != null)
        object = object + " sourceURL=" + this._launchDesc.getSourceURL(); 
      Config.getHooks().storeAppName((String)object);
      if (useAppletLifecycle() && !isImport()) {
        launchAppUsingAppletLifecycle(this._launchDesc);
        return true;
      } 
      prepareAllResources(this._launchDesc, this._args, bool1, paramBoolean);
    } catch (CacheUpdateRequiredException cacheUpdateRequiredException) {
      throw cacheUpdateRequiredException;
    } catch (Throwable throwable) {
      ExitException exitException = (throwable instanceof ExitException) ? (ExitException)throwable : new ExitException(throwable, 3);
      boolean bool = (exitException.getReason() == 0 || throwable instanceof BlockedException) ? false : true;
      if (!(throwable instanceof BlockedException))
        if (exitException.getReason() == 3) {
          Trace.ignored(throwable);
          Object object = (exitException.getException() == null) ? exitException : exitException.getException();
          LaunchErrorDialog.show(Progress.get(null).getOwner(), (Throwable)object, this._exit);
        } else if (exitException.getReason() == 6) {
          Trace.ignored(throwable);
          LaunchErrorDialog.show(Progress.get(null).getOwner(), (Throwable)exitException, this._exit);
        } else {
          Trace.ignored(throwable);
        }  
      if (!bool) {
        Trace.println("Exiting", TraceLevel.BASIC);
      } else {
        Trace.ignoredException((Exception)exitException);
      } 
      if (this._exit)
        try {
          Main.systemExit(bool);
        } catch (ExitException exitException1) {
          Trace.println("systemExit: " + exitException1, TraceLevel.BASIC);
          Trace.ignoredException((Exception)exitException1);
        }  
      PerfLogger.setTime("End: prepareToLaunch1()");
      return false;
    } 
    PerfLogger.setTime("End: prepareToLaunch1()");
    return true;
  }
  
  private boolean useAppletLifecycle() { return (this._launchDesc == null) ? false : ((this._launchDesc.getLaunchType() == 6 || this._launchDesc.getLaunchType() == 2)); }
  
  private void launchAppUsingAppletLifecycle(LaunchDesc paramLaunchDesc) throws ExitException, IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
    Environment.setJavawsAppletLifecycle(true);
    if (paramLaunchDesc.getResources() == null)
      handleJnlpFileException(paramLaunchDesc, (Exception)new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.noappresources", paramLaunchDesc.getSpecVersion()), null)); 
    executeApplet(paramLaunchDesc, null, Progress.get(null), this._lap, paramLaunchDesc.getCodebase().toString(), paramLaunchDesc.getDocumentBase().toString(), true);
  }
  
  protected boolean updateFinalLaunchDesc(LaunchDesc paramLaunchDesc, int paramInt, boolean paramBoolean) throws ExitException, CacheUpdateRequiredException {
    int i = ResourceProvider.get().incrementInternalUse();
    try {
      URL uRL1 = paramLaunchDesc.getLocation();
      if (uRL1 == null) {
        this._launchDesc = paramLaunchDesc;
        if (paramLaunchDesc.getCanonicalHome() == null)
          return false; 
        LaunchDesc launchDesc = LaunchDownload.updateLaunchDescInCache(paramLaunchDesc);
        return (paramLaunchDesc == launchDesc);
      } 
      URL uRL2 = deriveCodebase(uRL1);
      boolean bool = SystemUtils.isPathFromCache(this._args[0]);
      Resource resource = ResourceProvider.get().getResource(uRL1, null, false, 1, null);
      File file = (resource != null) ? resource.getDataFile() : null;
      if (!paramBoolean && bool) {
        LaunchDesc launchDesc = LaunchDownload.getUpdatedLaunchDesc(uRL1, null, false);
        if (launchDesc == null) {
          this._launchDesc = paramLaunchDesc;
          return false;
        } 
        URL uRL = launchDesc.getLocation();
        if (uRL == null || (!uRL.toString().equals(uRL1.toString()) && paramInt == 0)) {
          ResourceProvider.get().markRetired(resource, false);
          return updateFinalLaunchDesc(launchDesc, ++paramInt, false);
        } 
        this._launchDesc = launchDesc;
        return true;
      } 
      if (file != null) {
        boolean bool1 = false;
        if (!paramBoolean) {
          resource = ResourceProvider.get().getResource(uRL1, null, true, 1, null);
          file = (resource != null) ? resource.getDataFile() : null;
          bool1 = true;
        } 
        try {
          this._launchDesc = LaunchDescFactory.buildDescriptor(file, uRL2, null, uRL1);
        } catch (LaunchDescException launchDescException) {
          this._launchDesc = LaunchDescFactory.buildDescriptor(file);
          if (this._launchDesc == null)
            throw launchDescException; 
        } 
        LaunchDesc launchDesc = null;
        if (!paramLaunchDesc.hasIdenticalContent(this._launchDesc)) {
          if (paramInt == 0 && paramBoolean)
            throw new CacheUpdateRequiredException("Given JNLP is newer than cached copy!"); 
          Trace.println("Launch copy is different than cached, force update", TraceLevel.BASIC);
          launchDesc = LaunchDownload.getUpdatedLaunchDesc(uRL1, null, true);
        } 
        if (launchDesc != null) {
          this._launchDesc = launchDesc;
          URL uRL4 = this._launchDesc.getLocation();
          if (uRL4 == null || (!uRL4.toString().equals(uRL1.toString()) && paramInt == 0)) {
            ResourceProvider.get().markRetired(resource, paramBoolean);
            return updateFinalLaunchDesc(this._launchDesc, ++paramInt, paramBoolean);
          } 
          return true;
        } 
        if (bool1)
          return true; 
        Cache.removeRemovedApp(uRL1.toString(), this._launchDesc.getInformation().getTitle());
        URL uRL = this._launchDesc.getLocation();
        if (uRL == null || (!uRL.toString().equals(uRL1.toString()) && paramInt == 0)) {
          ResourceProvider.get().markRetired(resource, false);
          return updateFinalLaunchDesc(this._launchDesc, ++paramInt, paramBoolean);
        } 
        return false;
      } 
      if (paramBoolean)
        throw new CacheUpdateRequiredException("Missing from the cache: " + uRL1); 
      if (Cache.isCacheEnabled()) {
        resource = ResourceProvider.get().getResource(uRL1, null, true, 1, null);
        file = (resource != null) ? resource.getDataFile() : null;
        if (file != null) {
          this._launchDesc = LaunchDescFactory.buildDescriptor(file, uRL2, null, uRL1);
          URL uRL = this._launchDesc.getLocation();
          if (uRL == null || (!uRL.toString().equals(uRL1.toString()) && paramInt == 0)) {
            ResourceProvider.get().markRetired(resource, false);
            return updateFinalLaunchDesc(this._launchDesc, ++paramInt, paramBoolean);
          } 
          return true;
        } 
        throw new Exception("cache failed for" + uRL1);
      } 
      this._launchDesc = LaunchDescFactory.buildDescriptor(uRL1, uRL2);
      URL uRL3 = this._launchDesc.getLocation();
      if (uRL3 != null && !uRL3.toString().equals(uRL1.toString()) && paramInt == 0)
        return updateFinalLaunchDesc(this._launchDesc, ++paramInt, paramBoolean); 
      return false;
    } catch (CacheUpdateRequiredException cacheUpdateRequiredException) {
      throw cacheUpdateRequiredException;
    } catch (Exception exception) {
      throw new ExitException(exception, 3);
    } finally {
      ResourceProvider.get().decrementInternalUse(i);
    } 
  }
  
  private URL deriveCodebase(URL paramURL) {
    try {
      return new URL(paramURL.toString().substring(0, paramURL.toString().lastIndexOf("/") + 1));
    } catch (MalformedURLException malformedURLException) {
      Trace.ignoredException(malformedURLException);
      return null;
    } 
  }
  
  private void removeTempJnlpFile(LaunchDesc paramLaunchDesc) {
    File file = null;
    if (paramLaunchDesc.isApplicationDescriptor())
      file = ResourceProvider.get().getCachedJNLPFile(paramLaunchDesc.getCanonicalHome(), null); 
    if (file == null)
      return; 
    if (this._args != null && file != null && JnlpxArgs.shouldRemoveArgumentFile()) {
      (new File(this._args[0])).delete();
      JnlpxArgs.setShouldRemoveArgumentFile(String.valueOf(false));
      this._args[0] = file.getPath();
    } 
  }
  
  static String getCurrentJavaFXVersion() {
    URL uRL = null;
    try {
      uRL = new URL("http://dl.javafx.com/javafx-rt.jnlp");
    } catch (MalformedURLException malformedURLException) {}
    Resource resource = ResourceProvider.get().getCachedResource(uRL, null);
    LaunchDesc launchDesc = null;
    String str = "XX";
    if (resource != null) {
      try {
        launchDesc = LaunchDescFactory.buildDescriptor(resource.getDataFile(), null, null, uRL);
      } catch (Exception exception) {}
      str = launchDesc.getVersion();
    } 
    return str;
  }
  
  static String getRequestedJavaFXVersion(LaunchDesc paramLaunchDesc) {
    String str = "XX";
    if (paramLaunchDesc != null)
      str = paramLaunchDesc.getVersion(); 
    return str;
  }
  
  void prepareAllResources(final LaunchDesc ld, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2) throws ExitException, CacheUpdateRequiredException {
    PerfLogger.setTime("Start: prepareAllResources()");
    ArrayList<File> arrayList = new ArrayList();
    boolean bool = prepareLaunchFile(ld, paramArrayOfString, paramBoolean2, arrayList);
    prepareSecurity(ld);
    final PreloaderDelegate preloader = Progress.get(null);
    final JNLPSignedResourcesHelper signingHelper = new JNLPSignedResourcesHelper(ld);
    if (!paramBoolean2) {
      prepareEnvironment(ld);
      if (!Globals.isSilentMode() && !paramBoolean2) {
        boolean bool1 = (!ld.getUpdate().isBackgroundCheck() && !ld.getUpdate().isPromptPolicy() && !this._isRelaunch) ? true : false;
        boolean bool2 = (!this._isCached || bool1) ? true : false;
        Runnable runnable1 = new Runnable() {
            public void run() {
              SplashScreen.hide();
              try {
                boolean bool = signingHelper.checkSignedResources((Preloader)Progress.get(null), true);
                Trace.println("Security check for progress jars: allSigned=" + bool, TraceLevel.SECURITY);
              } catch (Exception exception) {
                throw new RuntimeException(exception);
              } 
              if (Launcher.this.disableCustomPreloader(ld))
                preloader.setPreloaderClass(null); 
              preloader.initPreloader((ClassLoader)Launcher.this._jnlpClassLoader, Main.getLaunchThreadGroup());
            }
          };
        Runnable runnable2 = new Runnable() {
            public void run() {
              preloader.setPreloaderClass(null);
              SplashScreen.hide();
              preloader.initPreloader((ClassLoader)Launcher.this._jnlpClassLoader, Main.getLaunchThreadGroup());
            }
          };
        (new LaunchDownload(ld)).prepareCustomProgress(preloaderDelegate, jNLPSignedResourcesHelper, runnable1, runnable2, bool2);
      } 
    } 
    prepareResources(ld, paramArrayOfString, paramBoolean1, paramBoolean2, bool, arrayList, jNLPSignedResourcesHelper);
    if (paramBoolean2) {
      prepareEnvironment(ld);
      preloaderDelegate.setPreloaderClass(ld.getProgressClassName());
      preloaderDelegate.initPreloader((ClassLoader)this._jnlpClassLoader, Main.getLaunchThreadGroup());
    } 
    PerfLogger.setTime("End: prepareAllResources()");
  }
  
  private boolean prepareLaunchFile(LaunchDesc paramLaunchDesc, String[] paramArrayOfString, boolean paramBoolean, ArrayList<File> paramArrayList) throws ExitException, CacheUpdateRequiredException {
    boolean bool1 = false;
    if (paramLaunchDesc.getResources() == null)
      handleJnlpFileException(paramLaunchDesc, (Exception)new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.noappresources", paramLaunchDesc.getSpecVersion()), null)); 
    if (!isImport() && paramLaunchDesc.isLibrary()) {
      LaunchDescException launchDescException = new LaunchDescException(paramLaunchDesc, "Internal Error: !isImport() && ld.isLibrary()", null);
      handleJnlpFileException(paramLaunchDesc, (Exception)launchDescException);
    } 
    boolean bool2 = paramLaunchDesc.isInstaller();
    JNLPException.setDefaultLaunchDesc(paramLaunchDesc);
    JREInfo jREInfo = JREInfo.getHomeJRE();
    Trace.println("Launcher: isInstaller: " + bool2 + ", isRelaunch: " + this._isRelaunch + ", isImport(): " + isImport() + ", java.home:" + Environment.getJavaHome() + ", Running JRE: " + jREInfo, TraceLevel.BASIC);
    Trace.println("JREInfos", TraceLevel.BASIC);
    JREInfo.traceJREs();
    if (jREInfo == null) {
      LaunchDescException launchDescException = new LaunchDescException(paramLaunchDesc, "Internal Error: no running JRE", null);
      handleJnlpFileException(paramLaunchDesc, (Exception)launchDescException);
    } 
    if (!paramLaunchDesc.getInformation().supportsOfflineOperation() && DeployOfflineManager.isGlobalOffline() == true)
      throw new ExitException((Throwable)new OfflineLaunchException(1), 3); 
    PerfLogger.setTime("  - Start: LaunchDownload.isInCache(ld)");
    LaunchDownload launchDownload = new LaunchDownload(paramLaunchDesc);
    if ((this._isRelaunch || paramLaunchDesc.getUpdate().isBackgroundCheck() || paramLaunchDesc.getUpdate().isPromptPolicy()) && (this._lap == null || !this._lap.forceUpdateCheck()))
      this._isCached = launchDownload.isInCache(); 
    PerfLogger.setTime("  - End: LaunchDownload.isInCache(ld)");
    if (!this._isCached && !paramBoolean) {
      try {
        launchDownload.downloadExtensions(null, 0, paramArrayList);
        bool1 = true;
      } catch (Exception exception) {
        if (!paramLaunchDesc.getInformation().supportsOfflineOperation() || !launchDownload.isInCache())
          throw new ExitException(exception, 3); 
        Trace.ignoredException(exception);
      } 
    } else {
      bool1 = this._isCached;
    } 
    if (!bool1) {
      if (!paramLaunchDesc.getInformation().supportsOfflineOperation() || !launchDownload.isInCache())
        throw new CacheUpdateRequiredException("Some of required resources are not cached."); 
      bool1 = true;
    } 
    JREMatcher jREMatcher = paramLaunchDesc.getJREMatcher();
    JVMParameters jVMParameters = jREMatcher.getSelectedJVMParameters();
    this._jreInfo = jREMatcher.getSelectedJREInfo();
    JREDesc jREDesc = jREMatcher.getSelectedJREDesc();
    if ((this._jreInfo == null && jREDesc == null) || null == jVMParameters) {
      Trace.println(jREMatcher.toString());
      LaunchDescException launchDescException = new LaunchDescException(paramLaunchDesc, "Internal Error: Internal error, jreMatcher uninitialized", null);
      handleJnlpFileException(paramLaunchDesc, (Exception)launchDescException);
    } 
    if (!paramLaunchDesc.isJRESpecified()) {
      LaunchDescException launchDescException = new LaunchDescException(paramLaunchDesc, "Internal Error: !isJRESpecified()", null);
      handleJnlpFileException(paramLaunchDesc, (Exception)launchDescException);
    } 
    URL uRL = paramLaunchDesc.getCanonicalHome();
    if (uRL == null) {
      LaunchDescException launchDescException = new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.nomainjar"), null);
      throw new ExitException((Throwable)launchDescException, 3);
    } 
    if (bool2) {
      this._lap = Cache.getLocalApplicationProperties(paramArrayOfString[0]);
      if (this._lap == null || !Environment.isInstallMode())
        handleJnlpFileException(paramLaunchDesc, (Exception)new MissingFieldException(paramLaunchDesc.getSource(), "<application-desc>|<applet-desc>")); 
      uRL = this._lap.getLocation();
    } else if (!paramLaunchDesc.isLibrary()) {
      this._lap = Cache.getLocalApplicationProperties(uRL);
    } 
    Trace.println("LaunchDesc location: " + uRL, TraceLevel.BASIC);
    return bool1;
  }
  
  private void prepareEnvironment(LaunchDesc paramLaunchDesc) throws ExitException {
    if (isImport() && !paramLaunchDesc.isInstaller())
      return; 
    AppPolicy appPolicy = AppPolicy.createInstance(paramLaunchDesc.getCanonicalHome().getHost());
    this._jnlpClassLoader = JNLPClassLoader.createClassLoader(paramLaunchDesc, appPolicy);
    try {
      String str = "http";
      URL uRL = paramLaunchDesc.getCanonicalHome();
      if (uRL.getProtocol().equalsIgnoreCase("file") && uRL.getHost().equals(""))
        str = "file"; 
      BasicServiceImpl.initialize(paramLaunchDesc.getCodebase(), BrowserSupport.isWebBrowserSupported(), str);
      if (paramLaunchDesc.getLaunchType() == 4) {
        String str1 = this._lap.getInstallDirectory();
        if (str1 == null) {
          str1 = Cache.getNewExtensionInstallDirectory();
          this._lap.setInstallDirectory(str1);
        } 
        ExtensionInstallerServiceImpl.initialize(paramLaunchDesc.isSecure() ? null : str1, this._lap, (Preloader)Progress.get(null));
      } 
    } catch (Throwable throwable) {
      throw new ExitException(throwable, 3);
    } 
    if (!this.securityManagerDiabledForTests)
      System.setSecurityManager((SecurityManager)new JavaWebStartSecurity()); 
  }
  
  void disableSecurityManagerForTests() { this.securityManagerDiabledForTests = true; }
  
  private boolean isJfxSupportSatisfied(LaunchDesc paramLaunchDesc) { return !paramLaunchDesc.needFX() ? true : ((paramLaunchDesc.isFXApp() && !ToolkitStore.isUsingPreferredToolkit(11, 0)) ? false : JfxHelper.isJfxSupportSatisfied(null, paramLaunchDesc)); }
  
  protected void relaunch(JREDesc paramJREDesc, LaunchDesc paramLaunchDesc, String[] paramArrayOfString, JVMParameters paramJVMParameters, boolean paramBoolean) throws ExitException {
    if (!canRelaunch())
      return; 
    if (OSType.isMac()) {
      String str1 = paramLaunchDesc.getInformation().getTitle();
      if (str1 != null)
        System.setProperty("macosx.jnlpx.dock.name", str1); 
      String str2 = IconUtil.getIconPath(paramLaunchDesc);
      if (str2 == null)
        str2 = Platform.get().getDefaultIconPath(); 
      if (str2 != null)
        System.setProperty("macosx.jnlpx.dock.icon", str2); 
    } 
    long l1 = paramJREDesc.getMinHeap();
    long l2 = paramJREDesc.getMaxHeap();
    HtmlOptions htmlOptions = HtmlOptions.get();
    if (htmlOptions != null)
      try {
        File file1 = File.createTempFile("jnl", ".tmp");
        htmlOptions.export(new FileOutputStream(file1));
        paramArrayOfString = new String[2];
        paramArrayOfString[0] = "-nocodebase";
        paramArrayOfString[1] = file1.getAbsolutePath();
      } catch (IOException iOException) {
        throw new ExitException("Failed to relaunch. Can not save launch file.", iOException);
      }  
    File file = SessionState.save();
    if (file != null)
      System.setProperty("jnlpx.session.data", file.getAbsolutePath()); 
    try {
      if (paramBoolean) {
        JVMParameters jVMParameters = new JVMParameters();
        jVMParameters.setIncludeExtendedASCIIValues(true);
        jVMParameters.parse(paramJREDesc.getVmArgs());
        paramJVMParameters.addArguments(jVMParameters);
      } 
      paramArrayOfString = insertApplicationArgs(paramArrayOfString);
      Process process = JnlpxArgs.execProgram(this._jreInfo, paramArrayOfString, l1, l2, paramJVMParameters, paramBoolean, paramLaunchDesc.needFX());
      if (Platform.get().getRunInNativeSandbox())
        try {
          process.waitFor();
        } catch (InterruptedException interruptedException) {
          Trace.ignoredException(interruptedException);
        }  
    } catch (IOException iOException) {
      throw new ExitException((Throwable)new JreExecException(this._jreInfo.getPath(), iOException), 3);
    } 
    if (JnlpxArgs.shouldRemoveArgumentFile())
      JnlpxArgs.setShouldRemoveArgumentFile(String.valueOf(false)); 
    throw new ExitException(null, 0);
  }
  
  private boolean runInNativeSandbox(LaunchDesc paramLaunchDesc) {
    if (Platform.get().isNativeSandbox())
      return false; 
    DeploymentRuleSet deploymentRuleSet = paramLaunchDesc.getMainDeploymentRuleSet();
    if (deploymentRuleSet != null && !deploymentRuleSet.allowNativeSandbox())
      return false; 
    ArrayList<LaunchDesc> arrayList = new ArrayList();
    JNLPSignedResourcesHelper.addExtensions(arrayList, paramLaunchDesc);
    for (byte b = 0; b < arrayList.size(); b++) {
      LaunchDesc launchDesc = arrayList.get(b);
      if (launchDesc.getSecurityModel() != 0) {
        ResourcesDesc resourcesDesc = launchDesc.getResources();
        if (resourcesDesc != null) {
          JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
          if (arrayOfJARDesc != null && arrayOfJARDesc.length != 0)
            return false; 
        } 
      } 
    } 
    return true;
  }
  
  private boolean disableCustomPreloader(LaunchDesc paramLaunchDesc) {
    if (this._disableCustomPreloader) {
      Trace.println("Custom preloader: disabled", TraceLevel.PRELOADER);
      return true;
    } 
    if (runInNativeSandbox(paramLaunchDesc)) {
      Trace.println("Custom preloader: disabled", TraceLevel.PRELOADER);
      return true;
    } 
    if (this._lap != null && this._lap.getEnableCustomPreloader()) {
      Trace.println("Custom preloader: enabled", TraceLevel.PRELOADER);
      return false;
    } 
    if (Platform.get().isNativeSandbox()) {
      Trace.println("Custom preloader: enabled", TraceLevel.PRELOADER);
      return false;
    } 
    DeploymentRuleSet deploymentRuleSet = paramLaunchDesc.getMainDeploymentRuleSet();
    if (deploymentRuleSet != null && !deploymentRuleSet.allowNativeSandbox()) {
      Trace.println("Custom preloader: enabled", TraceLevel.PRELOADER);
      return false;
    } 
    ArrayList<LaunchDesc> arrayList = new ArrayList();
    JNLPSignedResourcesHelper.addExtensions(arrayList, paramLaunchDesc);
    boolean bool1 = false;
    boolean bool2 = false;
    for (byte b = 0; b < arrayList.size(); b++) {
      LaunchDesc launchDesc = arrayList.get(b);
      if (launchDesc.getSecurityModel() == 0) {
        bool2 = true;
      } else {
        bool1 = true;
      } 
      if (bool1 && bool2) {
        this._disableCustomPreloader = true;
        break;
      } 
    } 
    if (this._disableCustomPreloader) {
      Trace.println("Custom preloader: disabled", TraceLevel.PRELOADER);
    } else {
      Trace.println("Custom preloader: enabled", TraceLevel.PRELOADER);
    } 
    return this._disableCustomPreloader;
  }
  
  private void prepareResources(LaunchDesc paramLaunchDesc, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, ArrayList<File> paramArrayList, JNLPSignedResourcesHelper paramJNLPSignedResourcesHelper) throws ExitException, CacheUpdateRequiredException {
    PerfLogger.setTime("  - Start: prepareResources");
    boolean bool1 = paramLaunchDesc.isInstaller();
    boolean bool2 = (this._isCached && DeployOfflineManager.isGlobalOffline()) ? true : false;
    boolean bool3 = ((!isImport() && this._jreInfo == null) || bool1) ? true : false;
    boolean bool4 = (!this._isCached || bool3);
    if (bool4 && bool2)
      throw new ExitException((Throwable)new OfflineLaunchException(0), 3); 
    boolean bool5 = bool4;
    if (!bool2)
      if (this._lap != null && this._lap.forceUpdateCheck()) {
        Trace.println("Forced update check in LAP, do full update", TraceLevel.BASIC);
        bool5 = true;
      } else if (!paramBoolean2 && !paramLaunchDesc.getUpdate().isBackgroundCheck() && paramLaunchDesc.getUpdate().getPolicy() == 0) {
        bool5 = true;
      } else if (!paramBoolean2) {
        try {
          bool5 = paramLaunchDesc.getUpdater().isUpdateAvailable();
        } catch (Exception exception) {
          throw new ExitException(exception, 3);
        } 
        if (bool5 && paramLaunchDesc.getUpdate().getPolicy() != 0) {
          this._isCached = (new LaunchDownload(paramLaunchDesc)).isInCache();
          if (this._isCached)
            bool4 = bool3; 
        } 
        if (paramLaunchDesc.getUpdater().isCheckAborted())
          throw new ExitException((Throwable)new LaunchDescException(paramLaunchDesc, "User rejected cert - aborted", null), 4); 
      }  
    Trace.println("Offline mode: " + bool2 + "\nIsInCache: " + this._isCached + "\nforceUpdate: " + bool4 + "\nneedUpdate: " + bool5 + "\nIsInstaller: " + bool1, TraceLevel.BASIC);
    if (bool5 && !bool4)
      bool4 = paramLaunchDesc.getUpdater().needUpdatePerPolicy(Progress.get(null)); 
    if (bool4 && bool2)
      throw new ExitException((Throwable)new OfflineLaunchException(0), 3); 
    if (bool4) {
      PerfLogger.setTime("    - Start: Update Check");
      try {
        downloadResources(paramLaunchDesc, paramArrayList, paramBoolean3, bool1);
      } catch (ExitException exitException) {
        debugt((Throwable)exitException);
        if (Environment.isJavaFXInstallInitiated()) {
          Throwable throwable = exitException.getException();
          if (throwable instanceof FailedDownloadException) {
            String str1 = ((FailedDownloadException)throwable).getLocation().toString();
            Pings.sendJFXPing("jfxic", getCurrentJavaFXVersion(), getRequestedJavaFXVersion(paramLaunchDesc), 3, str1);
          } else {
            Pings.sendJFXPing("jfxic", getCurrentJavaFXVersion(), getRequestedJavaFXVersion(paramLaunchDesc), 2, null);
          } 
        } 
        throw exitException;
      } 
      if (this._lap != null && this._lap.forceUpdateCheck()) {
        this._lap.setForceUpdateCheck(false);
        try {
          this._lap.store();
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        } 
      } 
      PerfLogger.setTime("    - End: Update Check");
    } 
    PreloaderDelegate preloaderDelegate = Progress.get(null);
    try {
      preloaderDelegate.handleEvent((PreloaderEvent)new DownloadEvent(1, paramLaunchDesc.getLocation(), null, null, 1L, 1L, 100));
    } catch (CancelException cancelException) {
      throw new ExitException((Throwable)cancelException, 3);
    } 
    try {
      preloaderDelegate.waitTillLoaded();
    } catch (JNLPException jNLPException) {
      debugt((Throwable)jNLPException);
      throw new ExitException((Throwable)jNLPException, 3);
    } catch (IOException iOException) {
      debugt(iOException);
      LaunchDownload launchDownload = new LaunchDownload(paramLaunchDesc);
      if (paramLaunchDesc.getInformation().supportsOfflineOperation() && launchDownload.isInCache(paramBoolean3)) {
        Trace.ignoredException(iOException);
      } else {
        throw new ExitException(iOException, 3);
      } 
    } 
    ApplicationIconGenerator.generate(paramLaunchDesc, paramBoolean1);
    if (!isImport() && !paramArrayList.isEmpty()) {
      if (bool1);
      JnlpxArgs.executeInstallers(paramArrayList, (Preloader)Progress.get(null));
    } 
    if (!Globals.isSilentMode() && paramLaunchDesc.isInstaller())
      try {
        Progress.get(null).handleEvent((PreloaderEvent)new ConfigEvent(3, paramLaunchDesc.getAppInfo()));
        Progress.get(null).handleEvent((PreloaderEvent)new InitEvent(2));
      } catch (CancelException cancelException) {
        throw new ExitException((Throwable)cancelException, 3);
      }  
    JREMatcher jREMatcher = paramLaunchDesc.getJREMatcher();
    JVMParameters jVMParameters = jREMatcher.getSelectedJVMParameters();
    this._jreInfo = jREMatcher.getSelectedJREInfo();
    JREDesc jREDesc = jREMatcher.getSelectedJREDesc();
    if (isImport()) {
      try {
        Progress.get(null).handleEvent((PreloaderEvent)new InitEvent(5));
      } catch (CancelException cancelException) {
        throw new ExitException((Throwable)cancelException, 3);
      } 
      boolean bool = (LaunchDownload.isJnlpCached(paramLaunchDesc) && paramBoolean1) ? true : false;
      notifyLocalInstallHandler(paramLaunchDesc, this._lap, Globals.isSilentMode(), bool, null);
      if (Environment.isJavaFXInstallInitiated())
        Pings.sendJFXPing("jfxic", getCurrentJavaFXVersion(), getRequestedJavaFXVersion(paramLaunchDesc), 0, null); 
      Trace.println("Exiting after import", TraceLevel.BASIC);
      throw new ExitException(null, 0);
    } 
    if (!paramLaunchDesc.isValidSpecificationVersion()) {
      JNLPException.setDefaultLaunchDesc(paramLaunchDesc);
      handleJnlpFileException(paramLaunchDesc, (Exception)new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.badjnlversion", paramLaunchDesc.getSpecVersion()), null));
    } 
    boolean bool6 = false;
    try {
      PerfLogger.setTime("    - Start: checkSignedLaunchDesc");
      paramJNLPSignedResourcesHelper.checkSignedLaunchDesc();
      PerfLogger.setTime("    - End: checkSignedLaunchDesc");
      PerfLogger.setTime("    - Start: checkSignedResources");
      bool6 = paramJNLPSignedResourcesHelper.checkSignedResources((Preloader)Progress.get(null), false);
      PerfLogger.setTime("    - End: checkSignedResources");
      bool6 = (bool6 && paramLaunchDesc.isSigned());
      if (this._disableCustomPreloader) {
        this._lap.setEnableCustomPreloader(true);
        this._lap.store();
      } 
    } catch (JNLPException jNLPException) {
      debugt((Throwable)jNLPException);
      throw new ExitException((Throwable)jNLPException, 3);
    } catch (IOException iOException) {
      debugt(iOException);
      throw new ExitException(iOException, 3);
    } 
    SplashScreen.generateCustomSplash(paramLaunchDesc, paramBoolean1);
    DeploymentRuleSet deploymentRuleSet = paramLaunchDesc.getMainDeploymentRuleSet();
    try {
      if (this._jreInfo == null) {
        SecureStaticVersioning.useLatest(paramLaunchDesc.getAppInfo(), deploymentRuleSet, jREDesc.getVersion(), 2);
        this._jreInfo = paramLaunchDesc.selectJRE(true);
        jREMatcher = paramLaunchDesc.getJREMatcher();
        jREDesc = jREMatcher.getSelectedJREDesc();
        jVMParameters = jREMatcher.getSelectedJVMParameters();
      } else if (!SecureStaticVersioning.canUse(paramLaunchDesc.getAppInfo(), deploymentRuleSet, this._jreInfo.getProduct())) {
        this._jreInfo = paramLaunchDesc.selectJRE(true);
        jREMatcher = paramLaunchDesc.getJREMatcher();
        jREDesc = jREMatcher.getSelectedJREDesc();
        jVMParameters = jREMatcher.getSelectedJVMParameters();
      } 
    } catch (BlockedException blockedException) {
      debugt((Throwable)blockedException);
      throw new ExitException((Throwable)blockedException, 0);
    } 
    if (Trace.isEnabled(TraceLevel.BASIC)) {
      Trace.println("passing security checks; secureArgs:" + paramLaunchDesc.isSecureJVMArgs() + ", allSigned:" + bool6, TraceLevel.BASIC);
      Trace.println("trusted app: " + (!paramLaunchDesc.isSecure() ? 1 : 0) + ", -secure=" + Globals.isSecureMode(), TraceLevel.BASIC);
      Trace.println(jREMatcher.toString(), TraceLevel.BASIC);
    } 
    boolean bool7 = jREMatcher.isRunningJVMSatisfying(bool6);
    boolean bool8 = runInNativeSandbox(paramLaunchDesc);
    if (!bool7 || !isJfxSupportSatisfied(paramLaunchDesc) || bool8 || this._disableCustomPreloader) {
      if (bool8) {
        Platform.get().setRunInNativeSandbox(true);
      } else {
        Platform.get().setRunInNativeSandbox(false);
        if (this._disableCustomPreloader)
          Platform.get().checkAndUpdateSandboxWindow(true); 
      } 
      relaunch(jREDesc, paramLaunchDesc, paramArrayOfString, jVMParameters, bool6);
    } 
    String str = " - " + paramLaunchDesc.getInformation().getTitle();
    JavawsConsoleController.getInstance().setTitle("console.caption", str);
    JavawsConsoleController.getInstance().showConsoleIfEnabled();
    JnlpxArgs.removeArgumentFile(paramArrayOfString[0]);
    if (Cache.isCacheEnabled() && ((LocalInstallHandler.getInstance() != null && !LocalInstallHandler.getInstance().isShortcutExists(this._lap)) || Globals.isIconImageUpdated())) {
      notifyLocalInstallHandler(paramLaunchDesc, this._lap, Globals.isSilentMode(), (paramBoolean1 || Globals.isIconImageUpdated()), Progress.get(null).getOwnerRef());
      if (Globals.isIconImageUpdated())
        Globals.setIconImageUpdated(false); 
    } 
    PerfLogger.setTime("  - End prepareResources()");
    Trace.println("continuing launch in this VM", TraceLevel.BASIC);
    Config.getHooks().confirmAppRun();
  }
  
  private void debugt(Throwable paramThrowable) {
    if (paramThrowable != null) {
      Trace.println("\nThrowable : " + paramThrowable, TraceLevel.BASIC);
      Trace.ignored(paramThrowable);
      debugt(paramThrowable.getCause());
    } 
  }
  
  private String[] insertApplicationArgs(String[] paramArrayOfString) {
    String[] arrayOfString1 = Globals.getApplicationArgs();
    if (arrayOfString1 == null)
      return paramArrayOfString; 
    String[] arrayOfString2 = new String[arrayOfString1.length + paramArrayOfString.length];
    byte b1;
    for (b1 = 0; b1 < arrayOfString1.length; b1++)
      arrayOfString2[b1] = arrayOfString1[b1]; 
    for (byte b2 = 0; b2 < paramArrayOfString.length; b2++)
      arrayOfString2[b1++] = paramArrayOfString[b2]; 
    return arrayOfString2;
  }
  
  private void doLaunchApp() throws ExitException {
    AppContextUtil.createApplicationAppContext();
    JNLPClassLoader jNLPClassLoader = this._jnlpClassLoader;
    Thread.currentThread().setContextClassLoader((ClassLoader)jNLPClassLoader);
    ToolkitStore.get().setContextClassLoader((ClassLoader)jNLPClassLoader);
    String str1 = this._launchDesc.getInformation().getTitle();
    AppContext.getAppContext().put("deploy.trust.decider.app.name", str1);
    this._launchDesc.storeVersionsInAppContext();
    String str2 = null;
    Class<?> clazz = null;
    try {
      str2 = LaunchDownload.getMainClassName(this._launchDesc);
      Trace.println("Main-class: " + str2, TraceLevel.BASIC);
      if (str2 == null)
        throw new ClassNotFoundException(str2); 
      ToolkitStore.get().getAppContext().put("deploy-main-class", str2);
      if (!Config.checkPackageAccess(str2, Config.getNoPermissionACC())) {
        SecurityException securityException = new SecurityException("Bad package name of main-class");
        throw new ExitException(securityException, 3);
      } 
      Progress.get(null).handleEvent((PreloaderEvent)new AppInitEvent(1));
      clazz = jNLPClassLoader.loadClass(str2);
      Class[] arrayOfClass = { (new String[0]).getClass() };
      Method method = clazz.getMethod("main", arrayOfClass);
      Class<?> clazz1 = method.getDeclaringClass();
      if (clazz1 != clazz) {
        ClassLoader classLoader1 = clazz1.getClassLoader();
        ClassLoader classLoader2 = ClassLoader.getSystemClassLoader();
        ClassLoader classLoader3;
        for (classLoader3 = classLoader1; classLoader3 != null && classLoader3.getParent() != null; classLoader3 = classLoader3.getParent());
        if (classLoader1 == classLoader2 || classLoader1 == classLoader3)
          throw new ClassNotFoundException(str2); 
      } 
      if (getClass().getPackage().equals(clazz.getPackage()))
        throw new ClassNotFoundException(str2); 
      ClassLoader classLoader = clazz.getClassLoader();
      if (classLoader != jNLPClassLoader && classLoader != jNLPClassLoader.getParent()) {
        SecurityException securityException = new SecurityException("Bad main-class name");
        throw new ExitException(securityException, 3);
      } 
      CodeSource codeSource = clazz.getProtectionDomain().getCodeSource();
      if (codeSource != null) {
        DeploymentRuleSet deploymentRuleSet = this._launchDesc.getMainDeploymentRuleSet();
        if (codeSource.getCertificates() != null)
          DeployManifestChecker.verifyMainJar(deploymentRuleSet, codeSource.getLocation(), !this._launchDesc.isSecure(), this._launchDesc.getAppInfo()); 
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      throw new ExitException(classNotFoundException, 3);
    } catch (IOException iOException) {
      throw new ExitException(iOException, 3);
    } catch (JNLPException jNLPException) {
      throw new ExitException((Throwable)jNLPException, 3);
    } catch (Exception exception1) {
      Exception exception2 = exception1;
      while (exception2 != null) {
        if (exception2 instanceof ExitException)
          throw (ExitException)exception2; 
        Throwable throwable = exception2.getCause();
      } 
      throw new ExitException(exception1, 3);
    } catch (Throwable throwable) {
      throw new ExitException(throwable, 3);
    } 
    try {
      if (Globals.TCKHarnessRun)
        Main.tckprintln("JNLP Launching"); 
      PerfLogger.setTime("calling executeMainClass ...");
      executeMainClass(this._launchDesc, this._lap, clazz, Progress.get(null));
    } catch (SecurityException securityException) {
      throw new ExitException(securityException, 3);
    } catch (InvocationTargetException invocationTargetException) {
      Trace.ignored(invocationTargetException);
      Throwable throwable = invocationTargetException;
      while (throwable.getCause() != null)
        throwable = throwable.getCause(); 
      throw new ExitException(throwable, 3);
    } catch (NoSuchMethodException noSuchMethodException) {
      throw new ExitException(noSuchMethodException, 3);
    } catch (Throwable throwable) {
      throw new ExitException(throwable, 3);
    } 
    if (this._launchDesc.getLaunchType() == 4)
      throw new ExitException(null, 0); 
  }
  
  private void downloadResources(LaunchDesc paramLaunchDesc, ArrayList<File> paramArrayList, boolean paramBoolean1, boolean paramBoolean2) throws ExitException {
    LaunchDownload launchDownload = new LaunchDownload(paramLaunchDesc);
    try {
      if (!this._shownDownloadWindow && !Globals.isSilentMode()) {
        this._shownDownloadWindow = true;
        PreloaderDelegate preloaderDelegate = Progress.get(null);
        preloaderDelegate.handleEvent((PreloaderEvent)new ConfigEvent(3, paramLaunchDesc.getAppInfo()));
        if (!paramBoolean2)
          preloaderDelegate.handleEvent((PreloaderEvent)new InitEvent(4)); 
      } 
      if (!paramBoolean1)
        launchDownload.downloadExtensions((Preloader)Progress.get(null), 0, paramArrayList); 
      LaunchDownload.checkJNLPSecurity(paramLaunchDesc);
      boolean bool = Environment.isImportMode();
      launchDownload.downloadEagerorAll(bool, (Preloader)Progress.get(null), false);
    } catch (SecurityException securityException) {
      throw new ExitException(securityException, 3);
    } catch (JNLPException jNLPException) {
      throw new ExitException((Throwable)jNLPException, 3);
    } catch (Exception exception) {
      if (paramLaunchDesc.getInformation().supportsOfflineOperation() && launchDownload.isInCache(paramBoolean1)) {
        Trace.ignoredException(exception);
      } else {
        throw new ExitException(exception, 3);
      } 
    } 
  }
  
  public void prepareSecurity(LaunchDesc paramLaunchDesc) throws ExitException {
    try {
      LaunchDownload.checkJNLPSecurity(paramLaunchDesc);
    } catch (SecurityException securityException) {
      throw new ExitException(securityException, 3);
    } catch (JNLPException jNLPException) {
      throw new ExitException((Throwable)jNLPException, 3);
    } 
  }
  
  public static void notifyLocalInstallHandler(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean1, boolean paramBoolean2, ComponentRef paramComponentRef) {
    if (paramLocalApplicationProperties == null)
      return; 
    URL uRL = LaunchDescFactory.getDerivedCodebase();
    if (uRL != null)
      paramLocalApplicationProperties.setCodebase(uRL.toString()); 
    paramLocalApplicationProperties.setLastAccessed(new Date());
    if (!Environment.isImportMode() && !paramLaunchDesc.isLibrary())
      paramLocalApplicationProperties.incrementLaunchCount(); 
    LocalInstallHandler localInstallHandler = LocalInstallHandler.getInstance();
    if (localInstallHandler != null)
      localInstallHandler.install(paramLaunchDesc, paramLocalApplicationProperties, paramBoolean2, paramBoolean1, paramComponentRef); 
    try {
      paramLocalApplicationProperties.store();
    } catch (IOException iOException) {
      Trace.println("Couldn't save LAP: " + iOException, TraceLevel.BASIC);
    } 
  }
  
  private void executeMainClass(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Class paramClass, PreloaderDelegate paramPreloaderDelegate) throws IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException {
    if (paramLaunchDesc.getLaunchType() == 2) {
      String str1 = null;
      String str2 = null;
      boolean bool = false;
      if (paramLocalApplicationProperties != null) {
        str1 = paramLocalApplicationProperties.getCodebase();
        str2 = paramLocalApplicationProperties.getDocumentBase();
        bool = paramLocalApplicationProperties.isDraggedApplet();
      } 
      boolean bool1 = (!bool && (str1 == null || str2 == null)) ? true : false;
      if (bool1) {
        AppletDesc appletDesc = paramLaunchDesc.getAppletDescriptor();
        URL uRL1 = BasicServiceImpl.getInstance().getCodeBase();
        URL uRL2 = appletDesc.getDocumentBase();
        if (uRL2 == null)
          uRL2 = uRL1; 
        str1 = (uRL1 != null) ? uRL1.toString() : null;
        str2 = (uRL2 != null) ? uRL2.toString() : null;
        if (str2 == null)
          str2 = paramLaunchDesc.getCanonicalHome().toString(); 
      } 
      executeApplet(paramLaunchDesc, paramClass, paramPreloaderDelegate, paramLocalApplicationProperties, str1, str2, bool1);
    } else {
      paramLaunchDesc.getUpdater().startBackgroundUpdateOpt();
      executeApplication(paramLaunchDesc, paramLocalApplicationProperties, paramClass, paramPreloaderDelegate);
    } 
  }
  
  private void executeApplication(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Class paramClass, PreloaderDelegate paramPreloaderDelegate) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
    PerfLogger.setTime("Begin executeApplication");
    String[] arrayOfString = null;
    if (paramLaunchDesc.getLaunchType() == 4) {
      arrayOfString = new String[1];
      arrayOfString[0] = paramLocalApplicationProperties.isExtensionInstalled() ? "uninstall" : "install";
      paramLocalApplicationProperties.setExtensionInstalled(false);
      paramLocalApplicationProperties.setRebootNeeded(false);
      try {
        paramLocalApplicationProperties.store();
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } 
    } else {
      SplashScreen.hide();
      arrayOfString = null;
      if (!paramLaunchDesc.isFXApp()) {
        if (!paramLaunchDesc.isSigned() && HtmlOptions.get() != null)
          arrayOfString = HtmlOptions.get().getHtmlApplicationArgs(); 
        if (arrayOfString == null)
          arrayOfString = paramLaunchDesc.getApplicationDescriptor().getArguments(); 
      } 
      String[] arrayOfString1 = Globals.getApplicationArgs();
      if (arrayOfString1 != null)
        arrayOfString = arrayOfString1; 
    } 
    Object[] arrayOfObject = { arrayOfString };
    Class[] arrayOfClass = { (new String[0]).getClass() };
    Method method = paramClass.getMethod("main", arrayOfClass);
    if (!Modifier.isStatic(method.getModifiers()))
      throw new NoSuchMethodException(ResourceManager.getString("launch.error.nonstaticmainmethod")); 
    method.setAccessible(true);
    PerfLogger.setTime("End executeApplication (invoking App main)");
    PerfLogger.outputLog();
    try {
      Progress.get(null).handleEvent((PreloaderEvent)new AppInitEvent(2));
    } catch (CancelException cancelException) {}
    method.invoke(null, arrayOfObject);
  }
  
  private void executeApplet(LaunchDesc paramLaunchDesc, Class<Applet> paramClass, PreloaderDelegate paramPreloaderDelegate, LocalApplicationProperties paramLocalApplicationProperties, String paramString1, String paramString2, boolean paramBoolean) throws IllegalAccessException, InstantiationException, NoSuchMethodException, InvocationTargetException {
    try {
      Class<?> clazz = null;
      clazz = Class.forName("sun.plugin2.applet.viewer.JNLP2Viewer");
      SplashScreen.hide();
      Class[] arrayOfClass = { (new String[0]).getClass() };
      final Method mainMethod = clazz.getMethod("main", arrayOfClass);
      method.setAccessible(true);
      URL uRL = paramLaunchDesc.getCanonicalHome();
      File file = null;
      try {
        String str = ResourceProvider.get().getCachedResourceFilePath(uRL, null);
        if (str != null)
          file = new File(str); 
      } catch (Exception exception) {
        if (Trace.isEnabled(TraceLevel.CACHE))
          Trace.ignored(exception); 
      } 
      if (file != null) {
        String[] arrayOfString = null;
        if (!paramBoolean) {
          String str = SingleInstanceManager.getActionName();
          if (str != null && (str.equals("-open") || str.equals("-print"))) {
            arrayOfString = new String[3];
            arrayOfString[0] = str;
            arrayOfString[1] = SingleInstanceManager.getOpenPrintFilePath();
            arrayOfString[2] = file.toString();
          } else if (paramLocalApplicationProperties.isDraggedApplet()) {
            arrayOfString = new String[2];
            arrayOfString[0] = "-draggedApplet";
            arrayOfString[1] = file.toString();
          } else {
            arrayOfString = new String[1];
            arrayOfString[0] = file.toString();
          } 
        } else {
          arrayOfString = new String[5];
          arrayOfString[0] = "-codebase";
          arrayOfString[1] = paramString1;
          arrayOfString[2] = "-documentbase";
          arrayOfString[3] = paramString2;
          arrayOfString[4] = file.toString();
        } 
        final Object[] wrappedArgs = { arrayOfString };
        DeployOfflineManager.setForcedOffline(false);
        final Throwable[] e = new Throwable[1];
        arrayOfThrowable[0] = null;
        try {
          Thread thread = new Thread(Main.getMainThreadGroup(), new Runnable() {
                public void run() {
                  try {
                    mainMethod.invoke(null, wrappedArgs);
                  } catch (Throwable throwable) {
                    e[0] = throwable;
                  } 
                }
              });
          thread.start();
          thread.join();
        } catch (InterruptedException interruptedException) {
          interruptedException.printStackTrace();
        } finally {
          if (arrayOfThrowable[0] != null)
            throw new RuntimeException(arrayOfThrowable[0]); 
        } 
      } 
    } catch (ClassNotFoundException classNotFoundException) {
      paramLaunchDesc.getUpdater().startBackgroundUpdateOpt();
      AppletDesc appletDesc = paramLaunchDesc.getAppletDescriptor();
      int i = appletDesc.getWidth();
      int j = appletDesc.getHeight();
      Applet applet = null;
      applet = paramClass.newInstance();
      SplashScreen.hide();
      final JFrame mainFrame = new JFrame();
      boolean bool = BrowserSupport.isWebBrowserSupported();
      AppletContainerCallback appletContainerCallback = new AppletContainerCallback() {
          public void showDocument(URL param1URL) { BrowserSupport.showDocument(param1URL); }
          
          public void relativeResize(Dimension param1Dimension) {
            Dimension dimension = mainFrame.getSize();
            dimension.width += param1Dimension.width;
            dimension.height += param1Dimension.height;
            mainFrame.setSize(dimension);
          }
        };
      URL uRL1 = BasicServiceImpl.getInstance().getCodeBase();
      URL uRL2 = appletDesc.getDocumentBase();
      if (uRL2 == null)
        uRL2 = uRL1; 
      final AppletContainer ac = new AppletContainer(appletContainerCallback, applet, appletDesc.getName(), uRL2, uRL1, i, j, appletDesc.getParameters());
      jFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent param1WindowEvent) { ac.stopApplet(); }
          });
      jFrame.setTitle(paramLaunchDesc.getInformation().getTitle());
      Container container = jFrame.getContentPane();
      container.setLayout(new BorderLayout());
      container.add("Center", (Component)appletContainer);
      jFrame.pack();
      Dimension dimension = appletContainer.getPreferredFrameSize(jFrame);
      jFrame.setSize(dimension);
      jFrame.getRootPane().revalidate();
      jFrame.getRootPane().repaint();
      jFrame.setResizable(false);
      if (!jFrame.isVisible())
        SwingUtilities.invokeLater(new Runnable() {
              public void run() { mainFrame.setVisible(true); }
            }); 
      appletContainer.startApplet();
    } 
  }
  
  private void handleJnlpFileException(LaunchDesc paramLaunchDesc, Exception paramException) throws ExitException {
    Resource resource = ResourceProvider.get().getCachedResource(paramLaunchDesc.getCanonicalHome(), null);
    if (resource != null)
      ResourceProvider.get().markRetired(resource, false); 
    throw new ExitException(paramException, 3);
  }
  
  class CacheUpdateRequiredException extends Exception {
    private static final long serialVersionUID = 1L;
    
    public CacheUpdateRequiredException(String param1String) { super(param1String); }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/Launcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */