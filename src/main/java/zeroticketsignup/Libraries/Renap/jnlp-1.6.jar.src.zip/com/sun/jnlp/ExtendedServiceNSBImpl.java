package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import java.io.File;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.ExtendedService;
import javax.jnlp.FileContents;

public final class ExtendedServiceNSBImpl implements ExtendedService {
  private final ExtendedServiceImpl service;
  
  public ExtendedServiceNSBImpl(ExtendedServiceImpl paramExtendedServiceImpl) { this.service = paramExtendedServiceImpl; }
  
  public FileContents openFile(File paramFile) throws IOException {
    if (paramFile == null)
      return null; 
    final File file = new File(paramFile.getPath());
    if (!Platform.get().getNativeSandboxBroker().openFile(file.getAbsolutePath()))
      return null; 
    FileContents fileContents = (FileContents)AccessController.doPrivileged(new PrivilegedAction() {
          public Object run() {
            try {
              ExtendedServiceNSBImpl.this.service;
              return new FileContentsImpl(file, ExtendedServiceImpl.DEFAULT_FILESIZE);
            } catch (IOException null) {
              return null;
            } 
          }
        });
    if (fileContents instanceof IOException)
      throw (IOException)fileContents; 
    return fileContents;
  }
  
  public FileContents[] openFiles(File[] paramArrayOfFile) throws IOException {
    if (paramArrayOfFile == null || paramArrayOfFile.length <= 0)
      return null; 
    final File[] files = new File[paramArrayOfFile.length];
    for (byte b1 = 0; b1 < paramArrayOfFile.length; b1++)
      arrayOfFile[b1] = new File(paramArrayOfFile[b1].getPath()); 
    String[] arrayOfString = new String[arrayOfFile.length];
    for (byte b2 = 0; b2 < arrayOfFile.length; b2++)
      arrayOfString[b2] = arrayOfFile[b2].getAbsolutePath(); 
    if (!Platform.get().getNativeSandboxBroker().openFiles(arrayOfString))
      return null; 
    Object[] arrayOfObject = AccessController.doPrivileged(new PrivilegedAction<Object[]>() {
          public Object[] run() {
            FileContents[] arrayOfFileContents = new FileContents[files.length];
            try {
              for (byte b = 0; b < files.length; b++) {
                ExtendedServiceNSBImpl.this.service;
                arrayOfFileContents[b] = new FileContentsImpl(files[b], ExtendedServiceImpl.DEFAULT_FILESIZE);
              } 
            } catch (IOException iOException) {
              arrayOfFileContents[0] = (FileContents)iOException;
            } 
            return (Object[])arrayOfFileContents;
          }
        });
    if (arrayOfObject[0] instanceof IOException)
      throw (IOException)arrayOfObject[0]; 
    return (FileContents[])arrayOfObject;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/ExtendedServiceNSBImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */