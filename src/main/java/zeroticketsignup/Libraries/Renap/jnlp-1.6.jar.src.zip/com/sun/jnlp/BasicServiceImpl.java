package com.sun.jnlp;

import com.sun.deploy.Environment;
import com.sun.deploy.config.Config;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.DownloadEngine;
import com.sun.deploy.net.offline.DeployOfflineManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.PerfLogger;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.BrowserSupport;
import com.sun.javaws.jnl.LaunchDesc;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.BasicService;
import sun.awt.DesktopBrowse;

public final class BasicServiceImpl implements BasicService {
  private URL _codebase = null;
  
  private String _codebaseProtocol = null;
  
  private boolean _isWebBrowserSupported;
  
  private static BasicServiceImpl _sharedInstance = null;
  
  private BasicServiceImpl(URL paramURL, boolean paramBoolean, String paramString) {
    this._codebaseProtocol = paramString;
    this._codebase = paramURL;
    this._isWebBrowserSupported = paramBoolean;
    if (Config.isJavaVersionAtLeast16())
      try {
        DesktopBrowse.setInstance(new BasicServiceBrowser());
      } catch (IllegalStateException illegalStateException) {
        if (Config.getDeployDebug())
          illegalStateException.printStackTrace(System.out); 
      } catch (Throwable throwable) {
        Trace.ignored(throwable);
      }  
  }
  
  public static BasicServiceImpl getInstance() { return _sharedInstance; }
  
  public static void initialize(URL paramURL, boolean paramBoolean, String paramString) {
    if (_sharedInstance == null)
      _sharedInstance = new BasicServiceImpl(paramURL, paramBoolean, paramString); 
  }
  
  public URL getCodeBase() { return this._codebase; }
  
  public boolean isOffline() { return DeployOfflineManager.isGlobalOffline(); }
  
  private boolean isFileProtocolCodebase() { return (this._codebaseProtocol != null && this._codebaseProtocol.equalsIgnoreCase("file")); }
  
  private boolean isValidURL(URL paramURL) {
    LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
    URL uRL = launchDesc.getMainJarURL();
    return !(uRL != null && !URLUtil.checkDocumentURL(uRL, paramURL));
  }
  
  static boolean isArgumentOkay(String paramString) {
    for (byte b = 0; b < paramString.length(); b++) {
      char c = paramString.charAt(b);
      if (' ' >= c || c >= '~')
        return false; 
      if (c == '\\' || c == '"')
        return false; 
    } 
    return true;
  }
  
  public boolean showDocument(URL paramURL) {
    if (paramURL == null)
      return false; 
    try {
      paramURL.toURI();
    } catch (URISyntaxException uRISyntaxException) {
      uRISyntaxException.printStackTrace();
      return false;
    } 
    if (!URLUtil.checkDocumentURL(this._codebase, paramURL))
      return false; 
    if (Config.isJavaVersionAtLeast16()) {
      DesktopBrowse desktopBrowse = DesktopBrowse.getInstance();
      if (desktopBrowse != null && !(desktopBrowse instanceof BasicServiceBrowser)) {
        if (!isWebBrowserSupported())
          return false; 
        try {
          paramURL = new URL(this._codebase, paramURL.toString());
          if (!isArgumentOkay(paramURL.toString()))
            return false; 
          if (!isValidURL(paramURL))
            return false; 
        } catch (MalformedURLException malformedURLException) {}
        desktopBrowse.browse(paramURL);
        return true;
      } 
    } 
    return showDocumentHelper(paramURL);
  }
  
  private boolean showDocumentHelper(final URL url) {
    boolean bool1 = url.toString().toLowerCase().endsWith(".jnlp");
    boolean bool2 = ResourceProvider.get().isCached(url, null);
    if (bool1 || bool2) {
      Boolean bool3 = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
            public Object run() {
              if (DownloadEngine.isJnlpURL(url))
                try {
                  Resource resource = ResourceProvider.get().getResource(url, null, false, 1, null);
                  String str = (resource != null) ? resource.getResourceFilename() : null;
                  if (str != null && BasicServiceImpl.isArgumentOkay(str)) {
                    String[] arrayOfString = new String[3];
                    arrayOfString[0] = Environment.getJavawsCommand();
                    arrayOfString[1] = "-Xnosplash";
                    arrayOfString[2] = str;
                    Runtime.getRuntime().exec(arrayOfString);
                    return new Boolean(true);
                  } 
                } catch (Exception exception) {
                  Trace.ignored(exception);
                }  
              return new Boolean(false);
            }
          });
      if (bool3 != null && bool3.booleanValue() == true)
        return true; 
    } 
    if (!isWebBrowserSupported())
      return false; 
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            URL uRL = url;
            try {
              URL uRL1 = new URL(BasicServiceImpl.this._codebase, uRL.toString());
              if (!BasicServiceImpl.isArgumentOkay(uRL1.toString()))
                return new Boolean(false); 
              if (!BasicServiceImpl.this.isValidURL(uRL1))
                return new Boolean(false); 
              uRL = uRL1;
            } catch (MalformedURLException malformedURLException) {}
            return new Boolean(BrowserSupport.showDocument(uRL));
          }
        });
    return (bool == null) ? false : bool.booleanValue();
  }
  
  public boolean isWebBrowserSupported() {
    PerfLogger.setEndTime("BasicService.isWebBrowserSupported called");
    PerfLogger.outputLog();
    return this._isWebBrowserSupported;
  }
  
  public void logPerfStartMessage(String paramString) { PerfLogger.setStartTime(paramString); }
  
  public void logPerfEndMessage(String paramString) { PerfLogger.setEndTime(paramString); }
  
  public void logPerfTime(String paramString) { PerfLogger.setTime(paramString); }
  
  private class BasicServiceBrowser extends DesktopBrowse {
    private BasicServiceBrowser() {}
    
    public void browse(URL param1URL) { BasicServiceImpl.this.showDocument(param1URL); }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/BasicServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */