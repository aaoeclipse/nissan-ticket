package com.sun.javaws;

import com.sun.deploy.Environment;
import com.sun.deploy.trace.Trace;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Locale;
import java.util.Properties;

public class Globals {
  static final String JNLP_VERSION = "1.7.0";
  
  private static boolean _isSilentMode = false;
  
  private static boolean _isQuietMode = false;
  
  private static boolean _isSecureMode = false;
  
  private static boolean _isReverseMode = false;
  
  private static String[] _applicationArgs = null;
  
  private static boolean _createShortcut = false;
  
  private static boolean _createAssoc = false;
  
  private static boolean _showPrompts = false;
  
  private static boolean _isIconImageUpdated = false;
  
  public static String BootClassPath = "NONE";
  
  public static String JCOV = "NONE";
  
  public static boolean TraceDefault = true;
  
  public static boolean TraceBasic = false;
  
  public static boolean TraceNetwork = false;
  
  public static boolean TraceSecurity = false;
  
  public static boolean TraceCache = false;
  
  public static boolean TraceExtensions = false;
  
  public static boolean TraceTemp = false;
  
  public static String LogToHost = null;
  
  public static boolean SupportJREinstallation = true;
  
  public static boolean OverrideSystemClassLoader = true;
  
  public static boolean TCKHarnessRun = false;
  
  public static boolean TCKResponse = false;
  
  public static final String JAVA_STARTED = "Java Started";
  
  public static final String JNLP_LAUNCHING = "JNLP Launching";
  
  public static final String NEW_VM_STARTING = "JVM Starting";
  
  public static final String JAVA_SHUTDOWN = "JVM Shutdown";
  
  public static final String CACHE_CLEAR_OK = "Cache Clear Success";
  
  public static final String CACHE_CLEAR_FAILED = "Cache Clear Failed";
  
  private static final Locale defaultLocale = Locale.getDefault();
  
  private static final String defaultLocaleString = getDefaultLocale().toString();
  
  private static boolean _isNoCodebaseMode = false;
  
  public static String getDefaultLocaleString() { return defaultLocaleString; }
  
  public static Locale getDefaultLocale() { return defaultLocale; }
  
  public static boolean isShortcutMode() { return _createShortcut; }
  
  public static boolean createShortcut() { return _createShortcut; }
  
  public static boolean createAssoc() { return _createAssoc; }
  
  public static boolean showPrompts() { return _showPrompts; }
  
  public static boolean isNoCodebaseMode() { return _isNoCodebaseMode; }
  
  public static void setNoCodebaseMode(boolean paramBoolean) { _isNoCodebaseMode = paramBoolean; }
  
  public static boolean isSilentMode() { return (_isQuietMode || (_isSilentMode && (Environment.isImportMode() || Environment.isInstallMode()))); }
  
  public static boolean isQuietMode() { return _isQuietMode; }
  
  public static boolean isReverseMode() { return (_isReverseMode && Environment.isImportMode()); }
  
  public static boolean isIconImageUpdated() { return _isIconImageUpdated; }
  
  public static void setIconImageUpdated(boolean paramBoolean) { _isIconImageUpdated = paramBoolean; }
  
  public static boolean isSecureMode() { return _isSecureMode; }
  
  public static String[] getApplicationArgs() { return _applicationArgs; }
  
  public static void setCreateShortcut(boolean paramBoolean) { _createShortcut = paramBoolean; }
  
  public static void setCreateAssoc(boolean paramBoolean) { _createAssoc = paramBoolean; }
  
  public static void setShowPrompts(boolean paramBoolean) { _showPrompts = paramBoolean; }
  
  public static void setSilentMode(boolean paramBoolean) { _isSilentMode = paramBoolean; }
  
  public static void setQuietMode(boolean paramBoolean) { _isQuietMode = paramBoolean; }
  
  public static void setReverseMode(boolean paramBoolean) { _isReverseMode = paramBoolean; }
  
  public static void setSecureMode(boolean paramBoolean) { _isSecureMode = paramBoolean; }
  
  public static void setApplicationArgs(String[] paramArrayOfString) { _applicationArgs = paramArrayOfString; }
  
  public static String getBuildID() {
    String str = null;
    InputStream inputStream = Globals.class.getResourceAsStream("/build.id");
    if (inputStream != null) {
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
      try {
        str = bufferedReader.readLine();
      } catch (IOException iOException) {}
    } 
    return (str == null || str.length() == 0) ? "<internal>" : str;
  }
  
  public static String getComponentName() { return "javaws-11.111.2.14"; }
  
  public static String getUserAgent() { return "JNLP/1.7.0 javaws/11.111.2.14 (" + getBuildID() + ") Java/" + System.getProperty("java.version"); }
  
  public static String[] parseOptions(String[] paramArrayOfString) {
    readOptionFile();
    ArrayList<String> arrayList = new ArrayList();
    byte b = 0;
    boolean bool = false;
    while (b < paramArrayOfString.length) {
      String str = paramArrayOfString[b++];
      if (str.startsWith("-XX:") && !bool) {
        parseOption(str.substring(4), false);
      } else {
        arrayList.add(str);
      } 
      if (!str.startsWith("-"))
        bool = true; 
    } 
    setTCKOptions();
    String[] arrayOfString = new String[arrayList.size()];
    return arrayList.toArray(arrayOfString);
  }
  
  public static void getDebugOptionsFromProperties(Properties paramProperties) {
    for (byte b = 0;; b++) {
      String str = paramProperties.getProperty("javaws.debug." + b);
      if (str == null)
        return; 
      parseOption(str, true);
    } 
  }
  
  private static void setTCKOptions() {
    if (TCKHarnessRun == true && LogToHost == null)
      Trace.println("Warning: LogHost = null"); 
  }
  
  private static void parseOption(String paramString, boolean paramBoolean) {
    String str2;
    String str1;
    int i = paramString.indexOf('=');
    if (i == -1) {
      str1 = paramString;
      str2 = null;
    } else {
      str1 = paramString.substring(0, i);
      str2 = paramString.substring(i + 1);
    } 
    if (str1.length() > 0 && (str1.startsWith("-") || str1.startsWith("+"))) {
      str1 = str1.substring(1);
      str2 = paramString.startsWith("+") ? "true" : "false";
    } 
    if (paramBoolean && !str1.startsWith("x") && !str1.startsWith("Trace"))
      str1 = null; 
    if (str1 != null)
      setOption(str1, str2); 
  }
  
  private static boolean setOption(String paramString1, String paramString2) {
    Class<?> clazz = (new String()).getClass();
    boolean bool = true;
    try {
      Field field = (new Globals()).getClass().getDeclaredField(paramString1);
      if ((field.getModifiers() & 0x8) == 0)
        return false; 
      Class<?> clazz1 = field.getType();
      if (clazz1 == clazz) {
        field.set(null, paramString2);
      } else if (clazz1 == boolean.class) {
        field.setBoolean(null, Boolean.valueOf(paramString2).booleanValue());
      } else if (clazz1 == int.class) {
        field.setInt(null, Integer.parseInt(paramString2));
      } else if (clazz1 == float.class) {
        field.setFloat(null, Float.parseFloat(paramString2));
      } else if (clazz1 == double.class) {
        field.setDouble(null, Double.parseDouble(paramString2));
      } else if (clazz1 == long.class) {
        field.setLong(null, Long.parseLong(paramString2));
      } else {
        return false;
      } 
    } catch (IllegalAccessException illegalAccessException) {
      return false;
    } catch (NoSuchFieldException noSuchFieldException) {
      return false;
    } 
    return bool;
  }
  
  private static void readOptionFile() {
    FileInputStream fileInputStream;
    try {
      fileInputStream = new FileInputStream(System.getProperty("user.home") + File.separator + ".javawsrc");
    } catch (FileNotFoundException fileNotFoundException) {
      return;
    } 
    try {
      Properties properties = new Properties();
      properties.load(fileInputStream);
      Enumeration<?> enumeration = properties.propertyNames();
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        String str2 = properties.getProperty(str1);
        parseOption(str1 + "=" + str2, false);
      } 
    } catch (IOException iOException) {}
  }
  
  public static String getJavawsVersion() {
    int i = "11.111.2.14".indexOf("-");
    return (i > 0) ? "11.111.2.14".substring(0, i) : "11.111.2.14";
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/Globals.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */