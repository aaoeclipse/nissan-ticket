package com.sun.javaws;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class OperaPreferences {
  private static final String OPERA_ENCODING = "UTF-8";
  
  private static final char OPEN_BRACKET = '[';
  
  private static final char CLOSE_BRACKET = ']';
  
  private static final char SEPARATOR = '=';
  
  private static final int DEFAULT_SIZE = 16384;
  
  private static final int DEFAULT_SECTION_COUNT = 20;
  
  private ArrayList sections = null;
  
  public void load(InputStream paramInputStream) throws IOException {
    InputStreamReader inputStreamReader = new InputStreamReader(paramInputStream, "UTF-8");
    BufferedReader bufferedReader = new BufferedReader(inputStreamReader, 16384);
    String str1 = "";
    for (String str2 = bufferedReader.readLine(); str2 != null; str2 = bufferedReader.readLine()) {
      if (str2.length() > 0)
        if (str2.charAt(0) == '[') {
          str1 = str2.substring(1, str2.indexOf(']'));
        } else {
          String str3 = null;
          String str4 = null;
          int i = str2.indexOf('=');
          if (i >= 0) {
            str3 = str2.substring(0, i);
            str4 = str2.substring(i + 1);
          } else {
            str3 = str2;
          } 
          put(str1, str3, str4);
        }  
    } 
  }
  
  public void store(OutputStream paramOutputStream) throws IOException {
    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(paramOutputStream, "UTF-8");
    PrintWriter printWriter = new PrintWriter(outputStreamWriter, true);
    printWriter.println(toString());
  }
  
  public boolean containsSection(String paramString) { return (indexOf(paramString) >= 0); }
  
  public boolean containsKey(String paramString1, String paramString2) {
    int i = indexOf(paramString1);
    return (i < 0) ? false : ((PreferenceSection)this.sections.get(i)).contains(paramString2);
  }
  
  public String get(String paramString1, String paramString2) {
    int i = indexOf(paramString1);
    PreferenceSection.PreferenceEntry preferenceEntry = (i < 0) ? null : ((PreferenceSection)this.sections.get(i)).get(paramString2);
    return (preferenceEntry == null) ? null : preferenceEntry.getValue();
  }
  
  public String put(String paramString1, String paramString2, String paramString3) {
    int i = indexOf(paramString1);
    PreferenceSection preferenceSection = null;
    if (i < 0) {
      preferenceSection = new PreferenceSection(paramString1);
      this.sections.add(preferenceSection);
    } else {
      preferenceSection = this.sections.get(i);
    } 
    return preferenceSection.put(paramString2, paramString3);
  }
  
  public PreferenceSection remove(String paramString) {
    int i = indexOf(paramString);
    return (i < 0) ? null : this.sections.remove(i);
  }
  
  public String remove(String paramString1, String paramString2) {
    int i = indexOf(paramString1);
    return (i < 0) ? null : ((PreferenceSection)this.sections.get(i)).remove(paramString2);
  }
  
  public Iterator iterator(String paramString) {
    int i = indexOf(paramString);
    return (i < 0) ? (new PreferenceSection(paramString)).iterator() : ((PreferenceSection)this.sections.get(i)).iterator();
  }
  
  public Iterator iterator() { return new OperaPreferencesIterator(); }
  
  public boolean equals(Object paramObject) {
    boolean bool = false;
    if (paramObject instanceof OperaPreferences) {
      OperaPreferences operaPreferences = (OperaPreferences)paramObject;
      ListIterator<PreferenceSection> listIterator1 = this.sections.listIterator();
      ListIterator<PreferenceSection> listIterator2 = operaPreferences.sections.listIterator();
      while (listIterator1.hasNext() && listIterator2.hasNext()) {
        PreferenceSection preferenceSection1 = listIterator1.next();
        PreferenceSection preferenceSection2 = listIterator2.next();
        if (!preferenceSection1.equals(preferenceSection2))
          // Byte code: goto -> 117 
      } 
      if (!listIterator1.hasNext() && !listIterator2.hasNext())
        bool = true; 
    } 
    return bool;
  }
  
  public int hashCode() { return this.sections.hashCode(); }
  
  public String toString() {
    StringBuffer stringBuffer = new StringBuffer();
    ListIterator<PreferenceSection> listIterator = this.sections.listIterator();
    while (listIterator.hasNext()) {
      PreferenceSection preferenceSection = listIterator.next();
      stringBuffer.append(preferenceSection);
    } 
    return stringBuffer.toString();
  }
  
  public OperaPreferences() { this.sections = new ArrayList(20); }
  
  private int indexOf(String paramString) {
    byte b = 0;
    byte b1 = -1;
    ListIterator<PreferenceSection> listIterator = this.sections.listIterator();
    while (listIterator.hasNext()) {
      PreferenceSection preferenceSection = listIterator.next();
      if (preferenceSection != null && preferenceSection.getName().equalsIgnoreCase(paramString)) {
        b1 = b;
        break;
      } 
      b++;
    } 
    return b1;
  }
  
  private class OperaPreferencesIterator implements Iterator {
    private Iterator i = OperaPreferences.this.sections.listIterator();
    
    public boolean hasNext() { return this.i.hasNext(); }
    
    public Object next() { return ((OperaPreferences.PreferenceSection)this.i.next()).getName(); }
    
    public void remove() { this.i.remove(); }
  }
  
  private class PreferenceSection {
    private String name;
    
    private HashMap entries;
    
    private volatile int modified;
    
    private PreferenceEntry start;
    
    private PreferenceEntry end;
    
    public String getName() { return this.name; }
    
    public boolean contains(String param1String) { return this.entries.containsKey(param1String); }
    
    public String put(String param1String1, String param1String2) {
      PreferenceEntry preferenceEntry = (PreferenceEntry)this.entries.get(param1String1);
      String str = null;
      if (preferenceEntry == null) {
        preferenceEntry = new PreferenceEntry(param1String1, param1String2);
        if (this.end == null) {
          this.start = preferenceEntry;
          this.end = preferenceEntry;
        } else {
          this.end.add(preferenceEntry);
          this.end = preferenceEntry;
        } 
        this.entries.put(preferenceEntry.getKey(), preferenceEntry);
        this.modified++;
      } else {
        str = preferenceEntry.getValue();
        preferenceEntry.setValue(param1String2);
      } 
      return str;
    }
    
    public PreferenceEntry get(String param1String) { return (PreferenceEntry)this.entries.get(param1String); }
    
    public String remove(String param1String) {
      PreferenceEntry preferenceEntry = (PreferenceEntry)this.entries.get(param1String);
      String str = null;
      if (preferenceEntry != null) {
        str = preferenceEntry.getValue();
        removeEntry(preferenceEntry);
      } 
      return str;
    }
    
    public Iterator iterator() { return new PreferenceEntryIterator(this.start); }
    
    public boolean equals(Object param1Object) {
      boolean bool = false;
      if (param1Object instanceof PreferenceSection) {
        PreferenceSection preferenceSection = (PreferenceSection)param1Object;
        if (this.name == preferenceSection.name || (this.name != null && this.name.equals(preferenceSection.name))) {
          Iterator<PreferenceEntry> iterator1 = iterator();
          Iterator<PreferenceEntry> iterator2 = preferenceSection.iterator();
          while (iterator1.hasNext() && iterator2.hasNext()) {
            PreferenceEntry preferenceEntry1 = iterator1.next();
            PreferenceEntry preferenceEntry2 = iterator2.next();
            if (!preferenceEntry1.equals(preferenceEntry2))
              // Byte code: goto -> 143 
          } 
          if (!iterator1.hasNext() && !iterator2.hasNext())
            bool = true; 
        } 
      } 
      return bool;
    }
    
    public int hashCode() { return this.entries.hashCode(); }
    
    public String toString() {
      StringBuffer stringBuffer = new StringBuffer(this.entries.size() * 80);
      if (this.name != null && this.name.length() > 0)
        stringBuffer.append('[').append(this.name).append(']').append(System.getProperty("line.separator")); 
      for (PreferenceEntry preferenceEntry : this)
        stringBuffer.append(preferenceEntry).append(System.getProperty("line.separator")); 
      stringBuffer.append(System.getProperty("line.separator"));
      return stringBuffer.toString();
    }
    
    public PreferenceSection(String param1String) {
      this.name = param1String;
      this.entries = new HashMap<Object, Object>();
      this.modified = 0;
      this.start = null;
      this.end = null;
    }
    
    private void removeEntry(PreferenceEntry param1PreferenceEntry) {
      if (param1PreferenceEntry == this.start)
        this.start = param1PreferenceEntry.getNext(); 
      if (param1PreferenceEntry == this.end)
        this.end = param1PreferenceEntry.getPrevious(); 
      param1PreferenceEntry.remove();
      this.entries.remove(param1PreferenceEntry.getKey());
      this.modified++;
    }
    
    private class PreferenceEntry {
      private final String key;
      
      private String value;
      
      private PreferenceEntry previous;
      
      private PreferenceEntry next;
      
      public String getKey() { return this.key; }
      
      public String getValue() { return this.value; }
      
      public void setValue(String param2String) { this.value = param2String; }
      
      public void add(PreferenceEntry param2PreferenceEntry) {
        if (this.next != null) {
          this.next.add(param2PreferenceEntry);
        } else {
          this.next = param2PreferenceEntry;
          param2PreferenceEntry.previous = this;
        } 
      }
      
      public void remove() {
        if (this.previous != null)
          this.previous.next = this.next; 
        if (this.next != null)
          this.next.previous = this.previous; 
        this.previous = null;
        this.next = null;
      }
      
      public PreferenceEntry getPrevious() { return this.previous; }
      
      public PreferenceEntry getNext() { return this.next; }
      
      public boolean equals(Object param2Object) {
        boolean bool = false;
        if (param2Object instanceof PreferenceEntry) {
          PreferenceEntry preferenceEntry = (PreferenceEntry)param2Object;
          String str1 = getKey();
          String str2 = preferenceEntry.getKey();
          if (str1 == str2 || (str1 != null && str1.equals(str2))) {
            String str3 = getValue();
            String str4 = preferenceEntry.getValue();
            if (str3 == str4 || (str3 != null && str3.equals(str4)))
              bool = true; 
          } 
        } 
        return bool;
      }
      
      public int hashCode() { return (this.key == null) ? 0 : this.key.hashCode(); }
      
      public String toString() {
        StringBuffer stringBuffer = new StringBuffer(((this.key == null) ? 0 : this.key.length()) + ((this.value == null) ? 0 : this.value.length()) + 1);
        if (this.key != null && this.value != null) {
          stringBuffer.append(this.key).append('=').append(this.value);
        } else if (this.key != null) {
          stringBuffer.append(this.key);
        } else if (this.value != null) {
          stringBuffer.append(this.value);
        } 
        return stringBuffer.toString();
      }
      
      public PreferenceEntry(String param2String1, String param2String2) {
        this.key = param2String1;
        this.value = param2String2;
        this.previous = null;
        this.next = null;
      }
    }
    
    private class PreferenceEntryIterator implements Iterator {
      private OperaPreferences.PreferenceSection.PreferenceEntry next;
      
      private OperaPreferences.PreferenceSection.PreferenceEntry current;
      
      private int expectedModified;
      
      public boolean hasNext() { return (this.next != null); }
      
      public Object next() {
        if (OperaPreferences.PreferenceSection.this.modified != this.expectedModified)
          throw new ConcurrentModificationException(); 
        if (this.next == null)
          throw new NoSuchElementException(); 
        this.current = this.next;
        this.next = this.next.getNext();
        return this.current;
      }
      
      public void remove() {
        if (this.current == null)
          throw new IllegalStateException(); 
        if (OperaPreferences.PreferenceSection.this.modified != this.expectedModified)
          throw new ConcurrentModificationException(); 
        OperaPreferences.PreferenceSection.this.removeEntry(this.current);
        this.current = null;
        this.expectedModified = OperaPreferences.PreferenceSection.this.modified;
      }
      
      public PreferenceEntryIterator(OperaPreferences.PreferenceSection.PreferenceEntry param2PreferenceEntry) {
        this.next = param2PreferenceEntry;
        this.current = null;
        this.expectedModified = OperaPreferences.PreferenceSection.this.modified;
      }
    }
  }
  
  private class PreferenceEntry {
    private final String key;
    
    private String value;
    
    private PreferenceEntry previous;
    
    private PreferenceEntry next;
    
    public String getKey() { return this.key; }
    
    public String getValue() { return this.value; }
    
    public void setValue(String param1String) { this.value = param1String; }
    
    public void add(PreferenceEntry param1PreferenceEntry) {
      if (this.next != null) {
        this.next.add(param1PreferenceEntry);
      } else {
        this.next = param1PreferenceEntry;
        param1PreferenceEntry.previous = this;
      } 
    }
    
    public void remove() {
      if (this.previous != null)
        this.previous.next = this.next; 
      if (this.next != null)
        this.next.previous = this.previous; 
      this.previous = null;
      this.next = null;
    }
    
    public PreferenceEntry getPrevious() { return this.previous; }
    
    public PreferenceEntry getNext() { return this.next; }
    
    public boolean equals(Object param1Object) {
      boolean bool = false;
      if (param1Object instanceof PreferenceEntry) {
        PreferenceEntry preferenceEntry = (PreferenceEntry)param1Object;
        String str1 = getKey();
        String str2 = preferenceEntry.getKey();
        if (str1 == str2 || (str1 != null && str1.equals(str2))) {
          String str3 = getValue();
          String str4 = preferenceEntry.getValue();
          if (str3 == str4 || (str3 != null && str3.equals(str4)))
            bool = true; 
        } 
      } 
      return bool;
    }
    
    public int hashCode() { return (this.key == null) ? 0 : this.key.hashCode(); }
    
    public String toString() {
      StringBuffer stringBuffer = new StringBuffer(((this.key == null) ? 0 : this.key.length()) + ((this.value == null) ? 0 : this.value.length()) + 1);
      if (this.key != null && this.value != null) {
        stringBuffer.append(this.key).append('=').append(this.value);
      } else if (this.key != null) {
        stringBuffer.append(this.key);
      } else if (this.value != null) {
        stringBuffer.append(this.value);
      } 
      return stringBuffer.toString();
    }
    
    public PreferenceEntry(String param1String1, String param1String2) {
      this.key = param1String1;
      this.value = param1String2;
      this.previous = null;
      this.next = null;
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/OperaPreferences.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */