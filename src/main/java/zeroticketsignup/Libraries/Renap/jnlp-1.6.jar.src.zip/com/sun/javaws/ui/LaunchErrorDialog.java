package com.sun.javaws.ui;

import com.sun.deploy.Environment;
import com.sun.deploy.config.Config;
import com.sun.deploy.net.DownloadException;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.uitoolkit.ui.ConsoleController;
import com.sun.deploy.uitoolkit.ui.ConsoleWindow;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import com.sun.deploy.util.PerfLogger;
import com.sun.javaws.Globals;
import com.sun.javaws.Main;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.util.JavawsConsoleController;
import java.io.PrintWriter;
import java.io.StringWriter;

public class LaunchErrorDialog {
  private static String getMoreInfo(Throwable paramThrowable) {
    StringBuffer stringBuffer = new StringBuffer();
    String str1 = "<split>";
    JNLPException jNLPException = null;
    DownloadException downloadException = null;
    Throwable throwable = null;
    if (paramThrowable instanceof JNLPException) {
      jNLPException = (JNLPException)paramThrowable;
      throwable = jNLPException.getWrappedException();
    } else if (paramThrowable instanceof DownloadException) {
      downloadException = (DownloadException)paramThrowable;
      throwable = downloadException.getWrappedException();
    } else if (paramThrowable instanceof ExitException) {
      throwable = ((ExitException)paramThrowable).getException();
    } 
    stringBuffer.append(getErrorDescription(paramThrowable));
    String str2 = null;
    String str3 = null;
    if (jNLPException != null) {
      str2 = jNLPException.getLaunchDescSource();
      if (str2 == null) {
        LaunchDesc launchDesc = JNLPException.getDefaultLaunchDesc();
        if (launchDesc != null)
          str2 = launchDesc.getSource(); 
      } 
    } else if (JNLPException.getDefaultLaunchDesc() != null) {
      str2 = JNLPException.getDefaultLaunchDesc().getSource();
    } 
    if (JNLPException.getDefaultLaunchDesc() != null)
      str3 = JNLPException.getDefaultLaunchDesc().getSource(); 
    if (str3 != null && str3.equals(str2))
      str3 = null; 
    if (str2 != null) {
      stringBuffer.append(str1);
      stringBuffer.append(ResourceManager.getString("launcherrordialog.jnlpTab"));
      stringBuffer.append(str1);
      stringBuffer.append(filter(str2));
    } 
    if (str3 != null) {
      stringBuffer.append(str1);
      stringBuffer.append(ResourceManager.getString("launcherrordialog.jnlpMainTab"));
      stringBuffer.append(str1);
      stringBuffer.append(filter(str3));
    } 
    if (paramThrowable != null) {
      StringWriter stringWriter = new StringWriter();
      PrintWriter printWriter = new PrintWriter(stringWriter);
      paramThrowable.printStackTrace(printWriter);
      stringBuffer.append(str1);
      stringBuffer.append(ResourceManager.getString("launcherrordialog.exceptionTab"));
      stringBuffer.append(str1);
      stringBuffer.append(stringWriter.toString());
    } 
    if (throwable != null) {
      StringWriter stringWriter = new StringWriter();
      PrintWriter printWriter = new PrintWriter(stringWriter);
      throwable.printStackTrace(printWriter);
      stringBuffer.append(str1);
      stringBuffer.append(ResourceManager.getString("launcherrordialog.wrappedExceptionTab"));
      stringBuffer.append(str1);
      stringBuffer.append(stringWriter.toString());
    } 
    JavawsConsoleController javawsConsoleController = JavawsConsoleController.getInstance();
    ConsoleWindow consoleWindow = ToolkitStore.getUI().getConsole((ConsoleController)javawsConsoleController);
    javawsConsoleController.setConsole(consoleWindow);
    if (consoleWindow != null) {
      stringBuffer.append(str1);
      stringBuffer.append(ResourceManager.getString("launcherrordialog.consoleTab"));
      try {
        stringBuffer.append(str1);
        stringBuffer.append(consoleWindow.getRecentLog());
      } catch (Exception exception) {
        Trace.ignored(exception);
      } 
    } 
    return stringBuffer.toString();
  }
  
  private static String filter(String paramString) { return (paramString.length() > 10240) ? (paramString.substring(0, 10239) + "\njnlp file truncated after 10K\n") : paramString; }
  
  public static void show(final Object owner, final Throwable throwable, boolean paramBoolean) {
    SplashScreen.hide();
    System.err.println("#### Java Web Start Error:");
    System.err.println("#### " + getMessage(throwable));
    if (Config.getDeployDebug())
      throwable.printStackTrace(); 
    boolean bool = (!Globals.TCKHarnessRun && !Globals.isSilentMode()) ? true : false;
    if (throwable instanceof ExitException && ((ExitException)throwable).getReason() == 0)
      bool = false; 
    if (bool) {
      DeploySysAction deploySysAction = new DeploySysAction() {
          public Object execute() {
            Throwable throwable = throwable;
            try {
              String str1 = null;
              String str2 = LaunchErrorDialog.getErrorCategory(throwable);
              PerfLogger.setTime("showing error dialog");
              PerfLogger.outputLog();
              if (throwable instanceof JNLPException) {
                str1 = ((JNLPException)throwable).getBriefMessage();
              } else if (throwable instanceof ExitException) {
                ExitException exitException = (ExitException)throwable;
                if (exitException.getReason() == 6) {
                  str1 = exitException.getMessage();
                  throwable = exitException.getException();
                } 
              } 
              if (str1 == null)
                if (Environment.isImportMode()) {
                  if (Environment.isInstallMode()) {
                    str1 = ResourceManager.getString("launcherrordialog.uninstall.brief.message");
                  } else {
                    str1 = ResourceManager.getString("launcherrordialog.import.brief.message");
                  } 
                } else {
                  str1 = ResourceManager.getString("launcherrordialog.brief.message");
                }  
              AppInfo appInfo = (LaunchErrorDialog.getLaunchDesc() == null) ? new AppInfo() : LaunchErrorDialog.getLaunchDesc().getAppInfo();
              String str3 = ResourceManager.getString("launcherrordialog.brief.ok");
              String str4 = ResourceManager.getString("launcherrordialog.brief.details");
              String str5 = ResourceManager.getString("error.default.title", str2);
              ToolkitStore.getUI();
              ToolkitStore.getUI().showMessageDialog(owner, appInfo, 0, str5, null, str1, LaunchErrorDialog.getMoreInfo(throwable), str3, str4, null);
            } catch (Exception exception) {
              Trace.ignored(exception);
            } 
            return null;
          }
        };
      DeploySysRun.execute(deploySysAction, null);
    } 
    if (paramBoolean)
      try {
        Main.systemExit(-1);
      } catch (ExitException exitException) {
        Trace.println("systemExit: " + exitException, TraceLevel.BASIC);
        Trace.ignoredException((Exception)exitException);
      }  
  }
  
  private static String getErrorCategory(Throwable paramThrowable) {
    String str = ResourceManager.getString("launch.error.category.unexpected");
    if (paramThrowable instanceof JNLPException) {
      JNLPException jNLPException = (JNLPException)paramThrowable;
      str = jNLPException.getCategory();
    } else if (paramThrowable instanceof SecurityException || paramThrowable instanceof java.security.GeneralSecurityException) {
      str = ResourceManager.getString("launch.error.category.security");
    } else if (paramThrowable instanceof OutOfMemoryError) {
      str = ResourceManager.getString("launch.error.category.memory");
    } else if (paramThrowable instanceof DownloadException) {
      str = ResourceManager.getString("launch.error.category.download");
    } 
    return str;
  }
  
  private static String getErrorDescription(Throwable paramThrowable) {
    String str = getMessage(paramThrowable);
    if (str == null)
      str = ResourceManager.getString("launcherrordialog.genericerror", paramThrowable.getClass().getName()); 
    return str;
  }
  
  private static String getMessage(Throwable paramThrowable) { return (paramThrowable instanceof Exception) ? paramThrowable.getMessage() : (paramThrowable.getClass().getName() + ": " + paramThrowable.getMessage()); }
  
  private static LaunchDesc getLaunchDesc() { return JNLPException.getDefaultLaunchDesc(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/LaunchErrorDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */