package com.sun.jnlp;

import com.sun.deploy.association.Association;
import com.sun.deploy.association.AssociationDesc;
import com.sun.deploy.association.AssociationNotRegisteredException;
import com.sun.deploy.association.RegisterFailedException;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.ResourceProvider;
import com.sun.javaws.LocalInstallHandler;
import com.sun.javaws.jnl.InformationDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.ShortcutDesc;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.IntegrationService;

public final class IntegrationServiceImpl implements IntegrationService {
  private JNLPClassLoaderIf jnlpClassLoader;
  
  private static final String TSPECIALS = "()<>@,;:\\\"/[]?=";
  
  public IntegrationServiceImpl(JNLPClassLoaderIf paramJNLPClassLoaderIf) { this.jnlpClassLoader = paramJNLPClassLoaderIf; }
  
  public boolean requestShortcut(boolean paramBoolean1, boolean paramBoolean2, String paramString) {
    final boolean anyShortcuts = (paramBoolean1 || paramBoolean2) ? true : false;
    final LaunchDesc ld = this.jnlpClassLoader.getLaunchDesc();
    InformationDesc informationDesc = launchDesc.getInformation();
    informationDesc.setShortcut(new ShortcutDesc(true, false, paramBoolean1, paramBoolean2, paramString));
    final LocalInstallHandler lih = LocalInstallHandler.getInstance();
    final LocalApplicationProperties lap = getLocalApplicationProperties(launchDesc);
    Boolean bool1 = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            boolean bool = false;
            if (lih.isLocalInstallSupported()) {
              bool = lih.performIntegration(null, ld, lap, false, true, false);
              try {
                lap.store();
              } catch (Exception exception) {}
            } else {
              bool = !anyShortcuts;
            } 
            return Boolean.valueOf(bool);
          }
        });
    return bool1.booleanValue();
  }
  
  public boolean hasDesktopShortcut() { return hasShortcut(0); }
  
  public boolean hasMenuShortcut() { return hasShortcut(1); }
  
  private boolean hasShortcut(int paramInt) {
    LaunchDesc launchDesc = this.jnlpClassLoader.getLaunchDesc();
    final LocalInstallHandler lih = LocalInstallHandler.getInstance();
    final LocalApplicationProperties lap = getLocalApplicationProperties(launchDesc);
    boolean[] arrayOfBoolean = AccessController.doPrivileged(new PrivilegedAction<boolean>() {
          public Object run() { return lih.whichShortcutsExist(lap); }
        });
    return arrayOfBoolean[paramInt];
  }
  
  private LocalApplicationProperties getLocalApplicationProperties(final LaunchDesc ld) { return AccessController.doPrivileged(new PrivilegedAction<LocalApplicationProperties>() {
          public Object run() {
            URL uRL = ld.getCanonicalHome();
            return ResourceProvider.get().getLocalApplicationProperties(uRL, null, true);
          }
        }); }
  
  public boolean removeShortcuts() {
    final LaunchDesc ld = this.jnlpClassLoader.getLaunchDesc();
    final LocalInstallHandler lih = LocalInstallHandler.getInstance();
    final LocalApplicationProperties lap = getLocalApplicationProperties(launchDesc);
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            boolean bool = lih.uninstallShortcuts(ld, lap);
            try {
              lap.store();
            } catch (Exception exception) {}
            return Boolean.valueOf(bool);
          }
        });
    return bool.booleanValue();
  }
  
  public boolean requestAssociation(String paramString, String[] paramArrayOfString) {
    validateAssociationArguments(paramString, paramArrayOfString);
    final LaunchDesc ld = this.jnlpClassLoader.getLaunchDesc();
    InformationDesc informationDesc = launchDesc.getInformation();
    AssociationDesc associationDesc = createAssociationDesc(paramString, paramArrayOfString);
    informationDesc.setAssociation(associationDesc);
    final LocalApplicationProperties lap = getLocalApplicationProperties(launchDesc);
    final LocalInstallHandler lih = LocalInstallHandler.getInstance();
    return ((Boolean)AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            boolean bool = false;
            if (lih.isAssociationSupported())
              bool = lih.performIntegration(null, ld, lap, false, false, true); 
            return Boolean.valueOf(bool);
          }
        })).booleanValue();
  }
  
  public boolean hasAssociation(String paramString, String[] paramArrayOfString) {
    validateAssociationArguments(paramString, paramArrayOfString);
    final LaunchDesc ld = this.jnlpClassLoader.getLaunchDesc();
    final LocalApplicationProperties lap = getLocalApplicationProperties(launchDesc);
    final Association association = createAssociation(paramString, paramArrayOfString);
    final LocalInstallHandler lih = LocalInstallHandler.getInstance();
    return ((Boolean)AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() { return Boolean.valueOf(lih.hasAssociation(ld, lap, association)); }
        })).booleanValue();
  }
  
  public boolean removeAssociation(String paramString, String[] paramArrayOfString) {
    validateAssociationArguments(paramString, paramArrayOfString);
    final LaunchDesc ld = this.jnlpClassLoader.getLaunchDesc();
    final LocalApplicationProperties lap = getLocalApplicationProperties(launchDesc);
    final Association association = createAssociation(paramString, paramArrayOfString);
    final LocalInstallHandler lih = LocalInstallHandler.getInstance();
    return ((Boolean)AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            Boolean bool = Boolean.TRUE;
            if (lih.isAssociationSupported())
              try {
                lih.unregisterAssociationInternal(ld, lap, association);
              } catch (AssociationNotRegisteredException associationNotRegisteredException) {
                bool = Boolean.FALSE;
              } catch (RegisterFailedException registerFailedException) {
                bool = Boolean.FALSE;
              }  
            return bool;
          }
        })).booleanValue();
  }
  
  private void validateAssociationArguments(String paramString, String[] paramArrayOfString) {
    validateMimeType(paramString);
    validateExtensions(paramArrayOfString);
  }
  
  private void validateExtensions(String[] paramArrayOfString) {
    if (paramArrayOfString == null || paramArrayOfString.length == 0)
      throw new IllegalArgumentException("Null or empty extensions array not allowed"); 
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      String str = paramArrayOfString[b];
      if (str == null)
        throw new IllegalArgumentException("Null extension not allowed"); 
      if (str.equals(""))
        throw new IllegalArgumentException("Empty extension not allowed"); 
    } 
  }
  
  private void validateMimeType(String paramString) {
    String str2;
    String str1;
    if (paramString == null)
      throw new IllegalArgumentException("Null mimetype not allowed"); 
    int i = paramString.indexOf('/');
    int j = paramString.indexOf(';');
    if (i < 0 && j < 0)
      throw new IllegalArgumentException("Unable to find a sub type."); 
    if (i < 0 && j >= 0)
      throw new IllegalArgumentException("Unable to find a sub type."); 
    if (i >= 0 && j < 0) {
      str1 = paramString.substring(0, i).trim().toLowerCase();
      str2 = paramString.substring(i + 1).trim().toLowerCase();
    } else if (i < j) {
      str1 = paramString.substring(0, i).trim().toLowerCase();
      str2 = paramString.substring(i + 1, j).trim().toLowerCase();
    } else {
      throw new IllegalArgumentException("Unable to find a sub type.");
    } 
    if (!isValidToken(str1))
      throw new IllegalArgumentException("Primary type is invalid."); 
    if (!isValidToken(str2))
      throw new IllegalArgumentException("Sub type is invalid."); 
  }
  
  private boolean isValidToken(String paramString) {
    int i = paramString.length();
    if (i > 0) {
      for (byte b = 0; b < i; b++) {
        char c = paramString.charAt(b);
        if (!isTokenChar(c))
          return false; 
      } 
      return true;
    } 
    return false;
  }
  
  private static boolean isTokenChar(char paramChar) { return (paramChar > ' ' && paramChar < '' && "()<>@,;:\\\"/[]?=".indexOf(paramChar) < 0); }
  
  private Association createAssociation(String paramString, String[] paramArrayOfString) {
    Association association = new Association();
    association.setMimeType(paramString);
    for (byte b = 0; b < paramArrayOfString.length; b++)
      association.addFileExtension(paramArrayOfString[b]); 
    LaunchDesc launchDesc = this.jnlpClassLoader.getLaunchDesc();
    association.setName(getAssociationDescription(launchDesc));
    return association;
  }
  
  private AssociationDesc createAssociationDesc(String paramString, String[] paramArrayOfString) {
    StringBuilder stringBuilder = new StringBuilder();
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      stringBuilder.append(paramArrayOfString[b]);
      if (b < paramArrayOfString.length - 1)
        stringBuilder.append(' '); 
    } 
    LaunchDesc launchDesc = this.jnlpClassLoader.getLaunchDesc();
    return new AssociationDesc(stringBuilder.toString(), paramString, getAssociationDescription(launchDesc), null);
  }
  
  private String getAssociationDescription(LaunchDesc paramLaunchDesc) { return paramLaunchDesc.getInformation().getTitle(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/IntegrationServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */