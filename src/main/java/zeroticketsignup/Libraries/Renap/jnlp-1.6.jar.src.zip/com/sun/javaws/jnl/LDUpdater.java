package com.sun.javaws.jnl;

import com.sun.applet2.preloader.Preloader;
import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.offline.DeployOfflineManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.javaws.Globals;
import com.sun.javaws.Launcher;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.FailedDownloadingResourceException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.progress.PreloaderDelegate;
import com.sun.javaws.ui.UpdateDialog;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class LDUpdater {
  private LaunchDesc _ld = null;
  
  private boolean _updateAvailable;
  
  private boolean _updateDownloaded;
  
  private boolean _updateChecked;
  
  private boolean _checkAborted;
  
  private boolean _checkFaulted;
  
  private LocalApplicationProperties _lap = null;
  
  private volatile Thread backgroundUpdateThread = null;
  
  private Exception _exception = null;
  
  private int _numTasks = 0;
  
  private int _numTasksMax = 0;
  
  private boolean _checkDone;
  
  private RapidUpdateCheckerQueue queue = null;
  
  private static final String APPCONTEXT_LD_KEY = "deploy-mainlaunchdescinappcontext";
  
  private static int sequenceNumber = 0;
  
  public LDUpdater(LaunchDesc paramLaunchDesc) {
    this._ld = paramLaunchDesc;
    setMainLaunchDescInAppContext();
  }
  
  public boolean isCheckAborted() { return this._checkAborted; }
  
  public boolean isUpdateAvailable() throws Exception {
    boolean bool = Environment.isJavaWebStart();
    return this._ld.isHttps() ? isUpdateAvailable(bool, true, false) : isUpdateAvailable(bool, true, true);
  }
  
  private boolean isUpdateAvailable(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws Exception {
    synchronized (this) {
      if (this._updateChecked)
        return this._updateAvailable; 
    } 
    try {
      if (this._ld.isApplicationDescriptor()) {
        startUpdateCheck(paramBoolean1, paramBoolean2, paramBoolean3);
      } else {
        this._updateAvailable = updateCheck(paramBoolean1, paramBoolean2, paramBoolean3);
      } 
      synchronized (this) {
        this._updateChecked = true;
        this._updateDownloaded = !this._updateAvailable;
      } 
      if (this._ld.isInstaller() && this._updateAvailable && ResourceProvider.get().isBackgroundUpdateRequest())
        setForceUpdateCheck(); 
    } catch (Exception exception) {
      Trace.ignored(exception);
      throw exception;
    } 
    return this._updateAvailable;
  }
  
  public boolean isUpdateDownloaded() { return this._updateDownloaded; }
  
  public void downloadUpdate(boolean paramBoolean) throws Exception {
    if (this._updateAvailable)
      download(paramBoolean); 
    synchronized (this) {
      this._updateAvailable = false;
      this._updateDownloaded = true;
    } 
  }
  
  private void startUpdateCheck(final boolean checkIcon, final boolean checkLazy, final boolean rapidCheck) throws Exception {
    if (this._lap == null)
      this._lap = Cache.getLocalApplicationProperties(this._ld.getCanonicalHome()); 
    int i = this._ld.getUpdate().getCheck();
    if (i == 2)
      return; 
    int j = Config.getIntProperty("deployment.javaws.update.timeout");
    final boolean[] results = new boolean[4];
    (new Thread(new Runnable() {
          public void run() {
            boolean bool1 = false;
            boolean bool2 = false;
            boolean bool = false;
            boolean bool3 = false;
            try {
              if (LDUpdater.this.updateCheck(checkIcon, checkLazy, rapidCheck)) {
                bool1 = true;
                LDUpdater.this.setForceUpdateCheck();
              } 
              bool2 = true;
            } catch (FailedDownloadingResourceException failedDownloadingResourceException) {
              if (LDUpdater.this._ld.isHttps()) {
                Throwable throwable = failedDownloadingResourceException.getWrappedException();
                if (throwable != null && throwable instanceof javax.net.ssl.SSLHandshakeException)
                  bool3 = true; 
              } 
              Trace.ignored((Throwable)failedDownloadingResourceException);
              bool = LDUpdater.this.checkException((Exception)failedDownloadingResourceException);
            } catch (Exception exception) {
              Trace.ignored(exception);
              bool = LDUpdater.this.checkException(exception);
            } 
            synchronized (results) {
              results[0] = bool1;
              results[1] = bool2;
              results[2] = bool;
              results[3] = bool3;
              results.notifyAll();
            } 
          }
        }"" + this._ld.getLocation())).start();
    synchronized (arrayOfBoolean) {
      while (!arrayOfBoolean[1] && !arrayOfBoolean[2] && !arrayOfBoolean[3]) {
        try {
          arrayOfBoolean.wait(j);
        } catch (InterruptedException interruptedException) {
          Trace.ignored(interruptedException);
        } 
        if (i == 1 && !this._ld.isHttps())
          break; 
      } 
      this._checkFaulted = arrayOfBoolean[2];
      this._checkAborted = arrayOfBoolean[3];
      this._updateAvailable = arrayOfBoolean[0];
    } 
    if (this._checkFaulted)
      throw this._exception; 
  }
  
  public synchronized boolean isBackgroundUpdateRunning() { return (null != this.backgroundUpdateThread); }
  
  public void startBackgroundUpdateOpt() {
    if (!Cache.isCacheEnabled() || DeployOfflineManager.isForcedOffline())
      return; 
    if (!this._ld.getUpdate().isBackgroundCheck())
      return; 
    if (null != this.backgroundUpdateThread)
      return; 
    startBackgroundUpdate();
  }
  
  public boolean needUpdatePerPolicy(PreloaderDelegate paramPreloaderDelegate) throws ExitException {
    boolean bool = false;
    switch (this._ld.getUpdate().getPolicy()) {
      default:
        bool = true;
        break;
      case 1:
        bool = UpdateDialog.showUpdateDialog(this._ld, (Preloader)paramPreloaderDelegate);
        if (!bool)
          Trace.println("User chose not to update", TraceLevel.CACHE); 
        break;
      case 2:
        bool = UpdateDialog.showUpdateDialog(this._ld, (Preloader)paramPreloaderDelegate);
        if (!bool) {
          Trace.println("Exiting after user chose not to update", TraceLevel.BASIC);
          throw new ExitException((Throwable)new LaunchDescException(this._ld, "User cancelled mandatory update - aborted", null), 3);
        } 
        break;
    } 
    if (!bool && this._lap.forceUpdateCheck())
      resetForceUpdateCheck(); 
    return bool;
  }
  
  public boolean needUpdatePerPolicy() throws ExitException { return needUpdatePerPolicy(null); }
  
  private synchronized void startBackgroundUpdate() { startBackgroundUpdate(5000L); }
  
  protected synchronized void startBackgroundUpdate(final long delayMillis) {
    if (null != this.backgroundUpdateThread)
      return; 
    Trace.println("LDUpdater: started background update check", TraceLevel.NETWORK);
    final ArrayList backgroundList = buildBackgroundDownloadList();
    ResourceProvider.get().storeAppContextBackgroundList(arrayList);
    this.backgroundUpdateThread = new Thread(new Runnable() {
          public void run() {
            try {
              ResourceProvider.get().setBackgroundUpdateRequest(true);
              try {
                Thread.sleep(delayMillis);
              } catch (InterruptedException interruptedException) {}
              boolean bool = false;
              if (LDUpdater.this.updateCheck(false, true, false))
                try {
                  LDUpdater.this.download(true);
                } catch (Exception exception) {
                  bool = true;
                  Trace.println("LDUpdater: exception in background update download, set force update check to true", TraceLevel.NETWORK);
                  Trace.ignoredException(exception);
                  LDUpdater.this.setForceUpdateCheck();
                }  
              if (!bool)
                LDUpdater.this.resetForceUpdateCheck(); 
            } catch (Exception exception) {
              Trace.ignoredException(exception);
            } finally {
              LDUpdater.this.backgroundUpdateEnd(backgroundList);
            } 
          }
        });
    this.backgroundUpdateThread.setName("Background Update Thread");
    this.backgroundUpdateThread.setPriority(1);
    this.backgroundUpdateThread.setDaemon(true);
    this.backgroundUpdateThread.start();
  }
  
  protected void backgroundUpdateEnd(List paramList) {
    ResourceProvider.get().clearAppContextBackgroundList(paramList);
    synchronized (this) {
      this._updateAvailable = false;
      this._updateDownloaded = true;
    } 
  }
  
  private boolean updateCheck(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws Exception {
    if (paramBoolean3 && this.queue == null) {
      this.queue = getQueue();
      if (this.queue == null)
        paramBoolean3 = false; 
    } 
    if (paramBoolean3) {
      URL uRL1 = this._ld.getLocation();
      if (uRL1 != null) {
        incrementTaskNum();
        this.queue.enqueue(new RapidUpdateChecker(uRL1, 0));
      } 
      ResourcesDesc resourcesDesc1 = this._ld.getResources();
      if (resourcesDesc1 != null) {
        JARDesc[] arrayOfJARDesc1 = resourcesDesc1.getLocalJarDescs();
        for (byte b3 = 0; b3 < arrayOfJARDesc1.length; b3++) {
          if (paramBoolean2 || !arrayOfJARDesc1[b3].isLazyDownload()) {
            incrementTaskNum();
            this.queue.enqueue(new RapidUpdateChecker(arrayOfJARDesc1[b3], 1));
          } 
        } 
        if (paramBoolean1) {
          IconDesc[] arrayOfIconDesc = this._ld.getInformation().getIcons();
          if (arrayOfIconDesc != null)
            for (byte b = 0; b < arrayOfIconDesc.length; b++) {
              incrementTaskNum();
              this.queue.enqueue(new RapidUpdateChecker(arrayOfIconDesc[b], 2));
            }  
        } 
        ArrayList<ExtensionDesc> arrayList1 = new ArrayList();
        getAllExtensions(resourcesDesc1, arrayList1);
        for (byte b4 = 0; b4 < arrayList1.size(); b4++) {
          LaunchDesc launchDesc = ((ExtensionDesc)arrayList1.get(b4)).getExtensionDesc();
          incrementTaskNum();
          (new Thread(new RapidUpdateChecker(launchDesc, 3), "Rapid Update Checker- " + nextSequenceNumber())).start();
        } 
      } 
      synchronized (this) {
        while (!this._checkDone && !this._updateAvailable) {
          try {
            wait();
          } catch (InterruptedException interruptedException) {
            Trace.ignored(interruptedException);
            break;
          } 
        } 
      } 
      stopQueue();
      if (!this._updateAvailable && this._exception != null)
        throw this._exception; 
      return this._updateAvailable;
    } 
    URL uRL = this._ld.getLocation();
    if (uRL != null)
      try {
        if (ResourceProvider.get().isUpdateAvailable(uRL, null))
          return true; 
      } catch (IOException iOException) {
        throw new FailedDownloadingResourceException(uRL, null, iOException);
      }  
    ResourcesDesc resourcesDesc = this._ld.getResources();
    if (resourcesDesc == null)
      return false; 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
    for (byte b1 = 0; b1 < arrayOfJARDesc.length; b1++) {
      if ((paramBoolean2 || !arrayOfJARDesc[b1].isLazyDownload()) && arrayOfJARDesc[b1].getUpdater().isUpdateAvailable())
        return true; 
    } 
    if (paramBoolean1) {
      IconDesc[] arrayOfIconDesc = this._ld.getInformation().getIcons();
      if (arrayOfIconDesc != null)
        for (byte b = 0; b < arrayOfIconDesc.length; b++) {
          URL uRL1 = arrayOfIconDesc[b].getLocation();
          String str = arrayOfIconDesc[b].getVersion();
          try {
            if (ResourceProvider.get().isUpdateAvailable(uRL1, str))
              Globals.setIconImageUpdated(true); 
          } catch (IOException iOException) {
            throw new FailedDownloadingResourceException(uRL1, null, iOException);
          } 
        }  
    } 
    ArrayList<ExtensionDesc> arrayList = new ArrayList();
    getAllExtensions(resourcesDesc, arrayList);
    for (byte b2 = 0; b2 < arrayList.size(); b2++) {
      LaunchDesc launchDesc = ((ExtensionDesc)arrayList.get(b2)).getExtensionDesc();
      try {
        if (launchDesc.getUpdater().isUpdateAvailable(paramBoolean1, paramBoolean2, paramBoolean3))
          return true; 
      } catch (NullPointerException nullPointerException) {
        Trace.ignored(nullPointerException);
      } 
    } 
    return false;
  }
  
  private void getAllExtensions(ResourcesDesc paramResourcesDesc, final ArrayList list) { paramResourcesDesc.visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) { list.add(param1ExtensionDesc); }
        }); }
  
  private void download(boolean paramBoolean) throws Exception, JNLPException {
    int i = ResourceProvider.get().incrementInternalUse();
    try {
      _download(paramBoolean);
    } finally {
      ResourceProvider.get().decrementInternalUse(i);
    } 
  }
  
  private void _download(boolean paramBoolean) throws Exception, JNLPException {
    URL uRL = this._ld.getLocation();
    boolean bool = ResourceProvider.get().isUpdateAvailable(uRL, null);
    if (bool) {
      Resource resource = ResourceProvider.get().downloadUpdate(uRL, null);
      File file = resource.getDataFile();
      if (!this._ld.hasIdenticalContent(file))
        this._ld = LaunchDescFactory.buildDescriptor(file, this._ld.getCodebase(), uRL, uRL); 
      LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(uRL);
      if (localApplicationProperties != null)
        Launcher.notifyLocalInstallHandler(this._ld, localApplicationProperties, true, true, null); 
    } 
    ResourcesDesc resourcesDesc = this._ld.getResources();
    if (resourcesDesc == null)
      return; 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
    ArrayList<JARDesc> arrayList = new ArrayList();
    if (paramBoolean) {
      arrayList.addAll(Arrays.asList(arrayOfJARDesc));
    } else {
      for (byte b = 0; b < arrayOfJARDesc.length; b++) {
        if (!arrayOfJARDesc[b].isLazyDownload())
          arrayList.add(arrayOfJARDesc[b]); 
      } 
    } 
    ArrayList<Resource> arrayList1 = new ArrayList();
    for (byte b1 = 0; b1 < arrayList.size(); b1++) {
      JARDesc jARDesc = arrayList.get(b1);
      if (jARDesc.getUpdater().isUpdateAvailable()) {
        Resource resource = jARDesc.getUpdater().downloadUpdate();
        if (resource != null)
          arrayList1.add(resource); 
      } 
    } 
    ResourceProvider.get().markReady(arrayList1.toArray(new Resource[arrayList1.size()]));
    IconDesc iconDesc = this._ld.getInformation().getIconLocation(48, 0);
    if (iconDesc != null)
      try {
        ResourceProvider.get().getResource(iconDesc.getLocation(), iconDesc.getVersion());
        Trace.println("Downloaded " + iconDesc.getLocation(), TraceLevel.NETWORK);
      } catch (Exception exception) {
        Trace.ignored(exception);
      }  
    ExtensionDesc[] arrayOfExtensionDesc = resourcesDesc.getExtensionDescs();
    for (byte b2 = 0; b2 < arrayOfExtensionDesc.length; b2++) {
      LaunchDesc launchDesc = arrayOfExtensionDesc[b2].getExtensionDesc();
      URL uRL1 = launchDesc.getLocation();
      try {
        if (launchDesc.getUpdater().isUpdateAvailable(false, paramBoolean, false))
          launchDesc.getUpdater().downloadUpdate(paramBoolean); 
      } catch (NullPointerException nullPointerException) {
        Trace.ignored(nullPointerException);
      } catch (IOException iOException) {
        throw new FailedDownloadingResourceException(uRL1, null, iOException);
      } 
    } 
  }
  
  private void setForceUpdateCheck() {
    if (this._lap != null && !this._lap.forceUpdateCheck()) {
      this._lap.setForceUpdateCheck(true);
      try {
        this._lap.store();
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } 
    } 
  }
  
  private void resetForceUpdateCheck() {
    if (this._lap != null && this._lap.forceUpdateCheck()) {
      this._lap.setForceUpdateCheck(false);
      try {
        this._lap.store();
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } 
    } 
  }
  
  private ArrayList buildBackgroundDownloadList() {
    ArrayList<String> arrayList = new ArrayList();
    try {
      URL uRL = this._ld.getLocation();
      if (uRL != null)
        arrayList.add(uRL.toString()); 
      ResourcesDesc resourcesDesc = this._ld.getResources();
      if (resourcesDesc != null) {
        ExtensionDesc[] arrayOfExtensionDesc = resourcesDesc.getExtensionDescs();
        for (byte b = 0; b < arrayOfExtensionDesc.length; b++) {
          URL uRL1 = arrayOfExtensionDesc[b].getLocation();
          if (uRL1 != null)
            arrayList.add(uRL1.toString()); 
        } 
        JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(true);
        if (arrayOfJARDesc != null)
          for (byte b1 = 0; b1 < arrayOfJARDesc.length; b1++) {
            URL uRL1 = arrayOfJARDesc[b1].getLocation();
            if (uRL1 != null)
              arrayList.add(uRL1.toString()); 
          }  
        IconDesc[] arrayOfIconDesc = this._ld.getInformation().getIcons();
        if (arrayOfIconDesc != null)
          for (byte b1 = 0; b1 < arrayOfIconDesc.length; b1++) {
            URL uRL1 = arrayOfIconDesc[b1].getLocation();
            if (uRL1 != null)
              arrayList.add(uRL1.toString()); 
          }  
      } 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
    return arrayList;
  }
  
  private static int nextSequenceNumber() {
    synchronized (LDUpdater.class) {
      return ++sequenceNumber;
    } 
  }
  
  private LDUpdater getMainLDUpdater() {
    if (this._ld.isApplicationDescriptor())
      return this._ld.getUpdater(); 
    LaunchDesc launchDesc = getMainLaunchDescFromAppContext();
    return (null != launchDesc) ? launchDesc.getUpdater() : null;
  }
  
  private RapidUpdateCheckerQueue getQueue() {
    if (!this._ld.isApplicationDescriptor()) {
      LDUpdater lDUpdater = getMainLDUpdater();
      return (lDUpdater != null) ? lDUpdater.getQueue() : null;
    } 
    if (this.queue == null) {
      int i = getNumTasksMax();
      this.queue = new RapidUpdateCheckerQueue(i);
      (new Thread(this.queue, "Rapid Update Checker Queue")).start();
    } 
    return this.queue;
  }
  
  private void stopQueue() {
    if (!this._ld.isApplicationDescriptor())
      return; 
    if (this.queue != null)
      this.queue.stop(); 
  }
  
  private int getNumTasksMax() {
    if (this._numTasksMax != 0)
      return this._numTasksMax; 
    if (this._ld.isApplicationDescriptor()) {
      this._numTasksMax = this._ld.getResources().getConcurrentDownloads();
      return this._numTasksMax;
    } 
    LaunchDesc launchDesc = getMainLaunchDescFromAppContext();
    return (launchDesc != null) ? launchDesc.getUpdater().getNumTasksMax() : 4;
  }
  
  private void setMainLaunchDescInAppContext() {
    if (this._ld.isApplicationDescriptor())
      ToolkitStore.get().getAppContext().put("deploy-mainlaunchdescinappcontext", this._ld); 
  }
  
  private LaunchDesc getMainLaunchDescFromAppContext() {
    Object object = ToolkitStore.get().getAppContext().get("deploy-mainlaunchdescinappcontext");
    return (null != object) ? (LaunchDesc)object : null;
  }
  
  private synchronized void incrementTaskNum() { this._numTasks++; }
  
  private synchronized void notifyUpdate(boolean paramBoolean) {
    if (paramBoolean) {
      this._updateAvailable = true;
      notifyAll();
    } else if (--this._numTasks == 0) {
      this._checkDone = true;
      notifyAll();
    } 
  }
  
  private synchronized void notifyException(Exception paramException) {
    if (this._ld != null && this._ld.getInformation().supportsOfflineOperation()) {
      Trace.ignoredException(paramException);
      return;
    } 
    if (this._exception == null)
      this._exception = paramException; 
  }
  
  private boolean checkException(Exception paramException) {
    if (this._ld.getUpdate().getCheck() == 1 && this._ld.getInformation().supportsOfflineOperation() && paramException instanceof JNLPException) {
      Throwable throwable = ((JNLPException)paramException).getWrappedException();
      if (throwable instanceof IOException)
        return false; 
    } 
    return true;
  }
  
  private class RapidUpdateChecker implements Runnable {
    private static final int HOME_URL = 0;
    
    private static final int JAR_DESC = 1;
    
    private static final int ICON_DESC = 2;
    
    private static final int EXT_LD = 3;
    
    private Object target;
    
    private int type;
    
    private boolean update = false;
    
    private RapidUpdateChecker(Object param1Object, int param1Int) {
      this.target = param1Object;
      this.type = param1Int;
    }
    
    public void run() {
      try {
        LaunchDesc launchDesc;
        String str;
        URL uRL2;
        IconDesc iconDesc;
        JARDesc jARDesc;
        URL uRL1;
        switch (this.type) {
          case 0:
            uRL1 = (URL)this.target;
            Trace.println("LDUpdater: update check for " + uRL1, TraceLevel.NETWORK);
            try {
              this.update = ResourceProvider.get().isUpdateAvailable(uRL1, null);
            } catch (IOException iOException) {
              throw new FailedDownloadingResourceException(uRL1, null, iOException);
            } 
            break;
          case 1:
            jARDesc = (JARDesc)this.target;
            Trace.println("LDUpdater: update check for " + jARDesc.getLocation(), TraceLevel.NETWORK);
            this.update = jARDesc.getUpdater().isUpdateAvailable();
            break;
          case 2:
            iconDesc = (IconDesc)this.target;
            uRL2 = iconDesc.getLocation();
            str = iconDesc.getVersion();
            try {
              if (ResourceProvider.get().isUpdateAvailable(uRL2, str))
                Globals.setIconImageUpdated(true); 
            } catch (IOException iOException) {
              throw new FailedDownloadingResourceException(uRL2, null, iOException);
            } 
            break;
          case 3:
            launchDesc = (LaunchDesc)this.target;
            Trace.println("LDUpdater: update check for " + launchDesc.getLocation(), TraceLevel.NETWORK);
            this.update = launchDesc.getUpdater().isUpdateAvailable();
            break;
        } 
      } catch (Exception exception) {
        LDUpdater.this.notifyException(exception);
      } finally {
        LDUpdater.this.notifyUpdate(this.update);
        LDUpdater.this.queue.decreaseNumTasks();
      } 
    }
  }
  
  private class RapidUpdateCheckerQueue implements Runnable {
    private static final String RAPID_CHECK_THREAD_NAME = "Rapid Update Checker- ";
    
    private volatile boolean shouldStop;
    
    private final Object lock = new Object();
    
    private LinkedList workQueue = new LinkedList();
    
    private int nThreads = 0;
    
    private int nThreadsMax;
    
    private RapidUpdateCheckerQueue(int param1Int) { this.nThreadsMax = param1Int; }
    
    private void enqueue(Runnable param1Runnable) {
      synchronized (this.lock) {
        this.workQueue.add(param1Runnable);
        this.lock.notifyAll();
      } 
    }
    
    private void stop() {
      this.shouldStop = true;
      synchronized (this.lock) {
        this.lock.notifyAll();
      } 
    }
    
    public void run() {
      try {
        while (!this.shouldStop) {
          synchronized (this.lock) {
            while (!this.shouldStop && this.workQueue.isEmpty()) {
              try {
                this.lock.wait();
              } catch (InterruptedException interruptedException) {
                interruptedException.printStackTrace();
              } 
            } 
          } 
          while (!this.shouldStop && !this.workQueue.isEmpty()) {
            Runnable runnable = null;
            synchronized (this.lock) {
              runnable = this.workQueue.removeFirst();
            } 
            synchronized (this) {
              while (this.nThreads >= this.nThreadsMax) {
                try {
                  wait();
                } catch (InterruptedException interruptedException) {
                  interruptedException.printStackTrace();
                } 
              } 
              this.nThreads++;
            } 
            (new Thread(runnable, "Rapid Update Checker- " + LDUpdater.nextSequenceNumber())).start();
          } 
        } 
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
    }
    
    private synchronized void decreaseNumTasks() {
      this.nThreads--;
      notifyAll();
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/LDUpdater.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */