package com.sun.javaws;

import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.cache.DeployCacheHandler;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.config.Platform;
import com.sun.deploy.config.WebStartConfig;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceObject;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.nativesandbox.NativeSandboxJNLPService;
import com.sun.deploy.net.cookie.DeployCookieSelector;
import com.sun.deploy.net.offline.DeployOfflineManager;
import com.sun.deploy.net.proxy.DeployProxySelector;
import com.sun.deploy.net.proxy.StaticProxyManager;
import com.sun.deploy.panel.ControlPanel;
import com.sun.deploy.pings.Pings;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.deploy.services.ServiceManager;
import com.sun.deploy.si.SingleInstanceManager;
import com.sun.deploy.trace.FileTraceListener;
import com.sun.deploy.trace.LoggerTraceListener;
import com.sun.deploy.trace.SocketTraceListener;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.trace.TraceListener;
import com.sun.deploy.ui.UIFactory;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.uitoolkit.ui.ComponentRef;
import com.sun.deploy.uitoolkit.ui.ConsoleController;
import com.sun.deploy.uitoolkit.ui.ConsoleTraceListener;
import com.sun.deploy.uitoolkit.ui.ConsoleWindow;
import com.sun.deploy.util.DeploySysRun;
import com.sun.deploy.util.DeployUIManager;
import com.sun.deploy.util.DialogListener;
import com.sun.deploy.util.JVMParameters;
import com.sun.deploy.util.PerfLogger;
import com.sun.deploy.util.SecurityBaseline;
import com.sun.deploy.util.SessionState;
import com.sun.deploy.util.SystemUtils;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.exceptions.CacheAccessException;
import com.sun.javaws.exceptions.CouldNotLoadArgumentException;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.FailedDownloadingResourceException;
import com.sun.javaws.exceptions.InvalidArgumentException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.exceptions.JNLParseException;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.security.AppContextUtil;
import com.sun.javaws.ui.JavawsSysRun;
import com.sun.javaws.ui.LaunchErrorDialog;
import com.sun.javaws.ui.SplashScreen;
import com.sun.javaws.util.JavawsConsoleController;
import com.sun.javaws.util.JavawsDialogListener;
import com.sun.jnlp.JNLPClassLoader;
import com.sun.jnlp.JnlpLookupStub;
import com.sun.jnlp.NativeSandboxJNLPServiceImpl;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import javax.jnlp.ServiceManager;
import javax.jnlp.ServiceManagerStub;
import sun.misc.BASE64Decoder;

public class Main {
  private static boolean _isViewer = false;
  
  private static boolean _silent = false;
  
  private static boolean _environmentInitialized = false;
  
  private static boolean _baselineUpdate = false;
  
  private static ThreadGroup _mainTG = null;
  
  private static ThreadGroup _systemTG;
  
  private static ThreadGroup _securityTG;
  
  private static ClassLoader _secureContextClassLoader;
  
  private static ThreadGroup _launchTG;
  
  private static String _tempfile = null;
  
  private static DataInputStream _tckStream = null;
  
  private static boolean _verbose = false;
  
  private static boolean uninstall = false;
  
  private static boolean includeInstalled = false;
  
  private static boolean _fix = false;
  
  private static boolean _fixShortcut = false;
  
  private static boolean _fixPermissions = false;
  
  public static void main(final String[] args) {
    try {
      PerfLogger.setBaseTimeString(System.getProperty("jnlp.start.time"));
      PerfLogger.setStartTime("Java Web Start started");
      PerfLogger.setTime("Starting Main");
      Environment.setEnvironmentType(1);
      Platform.get().loadDeployNativeLib();
      PerfLogger.setTime("  - returned from Platform.get();");
      for (String str : args) {
        if ("-notWebJava".equals(str))
          Environment.setIsWebJava(false); 
      } 
      Config.get();
      PerfLogger.setTime("  - returned from Config.get();");
      Config.setInstance((Config)new WebStartConfig());
      PerfLogger.setTime("  - back from Config.setInstance(new WebStartConfig());");
      URL.setURLStreamHandlerFactory(null);
      _secureContextClassLoader = Thread.currentThread().getContextClassLoader();
      Thread.currentThread().setContextClassLoader((ClassLoader)JNLPClassLoader.createClassLoader());
      String str1 = System.getProperty("java.protocol.handler.pkgs");
      String str2 = "com.sun.javaws.net.protocol";
      str2 = str2 + "|com.sun.deploy.net.protocol";
      if (str1 != null) {
        System.setProperty("java.protocol.handler.pkgs", str1 + "|" + str2);
      } else {
        System.setProperty("java.protocol.handler.pkgs", str2);
      } 
      System.setProperty("javawebstart.version", "javaws-11.111.2.14");
      AppContextUtil.createMainAppContext();
      PerfLogger.setTime("Start Toolkit init");
      ToolkitStore.get().warmup();
      PerfLogger.setTime("End Toolkit init");
      initializeThreadGroups();
      try {
        DeployCacheHandler.reset();
      } catch (Throwable throwable) {}
      (new Thread(_securityTG, new Runnable() {
            public void run() {
              AppContextUtil.createSecurityAppContext();
              Thread.currentThread().setContextClassLoader(Main.getSecureContextClassLoader());
              try {
                Main.continueInSecureThread(args);
              } catch (Throwable throwable) {
                throwable.printStackTrace();
              } 
              Trace.flush();
            }
          },  "Java Web Start Main Thread")).start();
    } catch (Throwable throwable) {
      LaunchErrorDialog.show(null, throwable, true);
    } 
  }
  
  private static void continueInSecureThread(String[] paramArrayOfString) {
    if (System.getProperty("jnlpx.session.data") != null) {
      SessionState.init(System.getProperty("jnlpx.session.data"));
      System.setProperty("jnlpx.session.data", "");
    } 
    String[] arrayOfString = Globals.parseOptions(paramArrayOfString);
    DeployUIManager.setLookAndFeel();
    arrayOfString = parseArgs(arrayOfString);
    if (arrayOfString.length > 0) {
      _tempfile = arrayOfString[arrayOfString.length - 1];
    } else if (!_fix && !uninstall && !_isViewer && !_baselineUpdate && !Environment.isSystemCacheMode()) {
      LaunchErrorDialog.show(null, (Throwable)new InvalidArgumentException(paramArrayOfString), true);
    } 
    if (!_isViewer) {
      PerfLogger.setTime("Start initTrace");
      initTrace();
      PerfLogger.setTime("End initTrace");
    } 
    boolean bool = Cache.canWrite();
    if (Environment.isSystemCacheMode() && (Config.getSystemCacheDirectory() == null || !bool))
      if (Environment.isImportMode() && Globals.isSilentMode()) {
        Environment.setSystemCacheMode(false);
      } else {
        LaunchErrorDialog.show(null, (Throwable)new CacheAccessException(true), true);
      }  
    if (Environment.isImportMode() && !ResourceProvider.get().canCache(null))
      if (Globals.isSilentMode()) {
        try {
          systemExit(-1);
        } catch (ExitException exitException) {
          Trace.println("systemExit: " + exitException, TraceLevel.BASIC);
          Trace.ignoredException((Exception)exitException);
        } 
      } else {
        LaunchErrorDialog.show(null, (Throwable)new CacheAccessException(Environment.isSystemCacheMode(), true), true);
      }  
    Config.validateSystemCacheDirectory();
    if (bool || _isViewer) {
      setupBrowser();
      PerfLogger.setTime("Start JnlpxArgs.verify");
      JnlpxArgs.verify();
      PerfLogger.setTime("End JnlpxArgs.verify");
      initializeExecutionEnvironment();
      PerfLogger.setTime("End InitializeExecutionEnv");
      if (uninstall) {
        uninstallCache(includeInstalled, (arrayOfString.length > 0) ? arrayOfString[0] : null);
      } else if (_fixShortcut) {
        fixShortcuts();
      } else if (_fixPermissions) {
        fixPermissions();
      } else {
        Cache6UpgradeHelper.getInstance();
        if (DeployOfflineManager.isGlobalOffline()) {
          JnlpxArgs.SetIsOffline();
          DeployOfflineManager.setForcedOffline(true);
        } 
        if (Environment.isSystemCacheMode()) {
          CacheUpdateHelper.systemUpdateCheck();
        } else if (Config.getBooleanProperty("deployment.javaws.cache.update") && CacheUpdateHelper.updateCache()) {
          Config.setBooleanProperty("deployment.javaws.cache.update", false);
          Config.get().storeIfNeeded();
        } 
        if (_baselineUpdate) {
          SecurityBaseline.forceBaselineUpdate();
        } else if (!_isViewer) {
          if (Globals.TCKHarnessRun) {
            Environment.setGlobalException(true);
            tckprintln("Java Started");
          } 
          if (arrayOfString.length > 0)
            if (Environment.isImportMode()) {
              for (byte b = 0; b < arrayOfString.length; b++) {
                int i;
                if (b == 0) {
                  i = arrayOfString.length - 1;
                } else {
                  i = b - 1;
                } 
                boolean bool1 = (b == arrayOfString.length - 1) ? true : false;
                PerfLogger.setTime("calling launchApp for import ...");
                launchApp(arrayOfString[i], bool1);
                Environment.setJavaFxInstallMode(0);
              } 
            } else {
              PerfLogger.setTime("calling launchApp ...");
              if (arrayOfString.length != 1) {
                JnlpxArgs.removeArgumentFile(arrayOfString[arrayOfString.length - 1]);
                LaunchErrorDialog.show(null, (Throwable)new InvalidArgumentException(arrayOfString), true);
                return;
              } 
              DeploymentRuleSet.initialize();
              launchApp(arrayOfString[0], true);
            }  
        } else {
          if (arrayOfString.length > 0)
            JnlpxArgs.removeArgumentFile(arrayOfString[0]); 
          PerfLogger.setEndTime("Calling Application viewer");
          PerfLogger.outputLog();
          try {
            String str = _silent ? "-store" : "-viewer";
            String[] arrayOfString1 = new String[1];
            arrayOfString1[0] = str;
            launchJavaControlPanel(arrayOfString1);
          } catch (Exception exception) {
            LaunchErrorDialog.show(null, exception, true);
          } 
        } 
      } 
    } else {
      LaunchErrorDialog.show(null, (Throwable)new CacheAccessException(Environment.isSystemCacheMode()), true);
    } 
    Trace.flush();
    SplashScreen.hide();
  }
  
  private static void validateJavaFxUrl(String paramString, boolean paramBoolean) {
    if (!Environment.allowAltJavaFxRuntimeURL() && !"http://dl.javafx.com/javafx-cache.jnlp".equals(paramString))
      LaunchErrorDialog.show(null, new Exception("Incorrect URL for JavaFX preload or auto-update"), paramBoolean); 
  }
  
  public static void launchApp(String paramString, boolean paramBoolean) {
    Config.get().updateJREs();
    if (Environment.isImportMode() && Environment.getJavaFxInstallMode() != 0)
      validateJavaFxUrl(paramString, paramBoolean); 
    LaunchDesc launchDesc = null;
    try {
      JREInfo jREInfo = JREInfo.getHomeJRE();
      if (jREInfo == null)
        throw new ExitException(new Exception("Internal Error: no running JRE"), 3); 
      String str = System.getProperty("jnlp.application.href");
      if (str != null) {
        File file = new File(paramString);
        if (!file.exists())
          paramString = str; 
      } 
      URL uRL = LaunchDescFactory.getDocBase();
      if (HtmlOptions.get() != null)
        launchDesc = fromEmbedded(paramString, uRL, HtmlOptions.get().getEmbedded()); 
      if (launchDesc == null)
        if (uRL != null) {
          launchDesc = LaunchDescFactory.buildDescriptor(paramString, (URL)null, uRL, true);
        } else {
          launchDesc = LaunchDescFactory.buildDescriptor(paramString);
        }  
      try {
        URL uRL1 = new URL(paramString);
        if (launchDesc.getRealLocation() == null || (Environment.isImportMode() && !URLUtil.sameURLs(uRL1, launchDesc.getRealLocation()))) {
          Resource resource = ResourceProvider.get().getCachedResource(uRL1, null);
          if (resource != null)
            ResourceProvider.get().markRetired(resource, true); 
        } 
      } catch (MalformedURLException malformedURLException) {}
    } catch (IOException iOException) {
      JnlpxArgs.removeArgumentFile(paramString);
      Object object = new CouldNotLoadArgumentException(paramString, iOException);
      if (iOException instanceof javax.net.ssl.SSLException || (iOException.getMessage() != null && iOException.getMessage().toLowerCase().indexOf("https") != -1))
        try {
          object = new FailedDownloadingResourceException(new URL(paramString), null, iOException);
        } catch (MalformedURLException malformedURLException) {
          Trace.ignoredException(malformedURLException);
        }  
      if (Environment.isImportMode() && Environment.getJavaFxInstallMode() != 0)
        Pings.sendJFXPing("jfxic", Launcher.getCurrentJavaFXVersion(), "XX", 3, paramString); 
      LaunchErrorDialog.show(null, (Throwable)object, paramBoolean);
      return;
    } catch (JNLParseException jNLParseException) {
      JnlpxArgs.removeArgumentFile(paramString);
      LaunchErrorDialog.show(null, (Throwable)jNLParseException, paramBoolean);
      return;
    } catch (LaunchDescException launchDescException) {
      Trace.println("Error parsing " + paramString + ". Try to parse again with codebase from LAP", TraceLevel.BASIC);
      try {
        launchDesc = LaunchDescFactory.buildDescriptor(new File(paramString));
        if (launchDesc == null)
          throw launchDescException; 
      } catch (Exception exception) {
        JnlpxArgs.removeArgumentFile(paramString);
        LaunchErrorDialog.show(null, (Throwable)launchDescException, paramBoolean);
        return;
      } 
    } catch (Exception exception) {
      Trace.ignoredException(exception);
      JnlpxArgs.removeArgumentFile(paramString);
      LaunchErrorDialog.show(null, exception, paramBoolean);
      return;
    } 
    if (Environment.isImportMode())
      Environment.setImportModeCodebase(launchDesc.getCodebase()); 
    if (launchDesc.getLaunchType() == 5) {
      String[] arrayOfString;
      JnlpxArgs.removeArgumentFile(paramString);
      String str = launchDesc.getInternalCommand();
      if (str != null && !str.equals("player") && !str.equals("viewer")) {
        arrayOfString = new String[2];
        arrayOfString[0] = "-tab";
        arrayOfString[1] = launchDesc.getInternalCommand();
      } else {
        arrayOfString = new String[1];
        arrayOfString[0] = "-viewer";
      } 
      launchJavaControlPanel(arrayOfString);
    } else if (Config.get().isValid()) {
      String[] arrayOfString = new String[1];
      arrayOfString[0] = paramString;
      (new Launcher(launchDesc)).launch(arrayOfString, paramBoolean);
    } else {
      LaunchErrorDialog.show(null, (Throwable)new LaunchDescException(launchDesc, ResourceManager.getString("enterprize.cfg.mandatory", Config.get().getEnterpriseString()), null), paramBoolean);
    } 
  }
  
  private static LaunchDesc fromEmbedded(String paramString1, URL paramURL, String paramString2) {
    if (paramString2 == null)
      return null; 
    try {
      URL uRL = null;
      try {
        uRL = new URL(paramString1);
      } catch (MalformedURLException malformedURLException) {}
      BASE64Decoder bASE64Decoder = new BASE64Decoder();
      byte[] arrayOfByte = bASE64Decoder.decodeBuffer(paramString2);
      return LaunchDownload.updateLaunchDescInCache(LaunchDescFactory.buildDescriptor(arrayOfByte, paramURL, paramURL, uRL), paramURL, paramURL);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
  
  static void importApp(String paramString) {
    boolean bool1 = Environment.isImportMode();
    Environment.setImportMode(true);
    boolean bool2 = Globals.isSilentMode();
    Globals.setSilentMode(true);
    boolean bool3 = Globals.isShortcutMode();
    Globals.setCreateShortcut(true);
    launchApp(paramString, false);
    Environment.setImportMode(bool1);
    Globals.setSilentMode(bool2);
    Globals.setCreateShortcut(bool3);
  }
  
  private static void launchJavaControlPanel(String[] paramArrayOfString) {
    SplashScreen.hide();
    ControlPanel.main(paramArrayOfString);
  }
  
  private static void uninstallCache(boolean paramBoolean, String paramString) {
    int i = -1;
    try {
      i = uninstall(paramBoolean, paramString);
    } catch (Exception exception) {
      LaunchErrorDialog.show(null, exception, (!Globals.isSilentMode() || Globals.isQuietMode()));
    } 
    _tempfile = null;
    try {
      systemExit(i);
    } catch (ExitException exitException) {
      Trace.println("systemExit: " + exitException, TraceLevel.BASIC);
      Trace.ignoredException((Exception)exitException);
    } 
  }
  
  private static void fixShortcuts() { CacheUtil.fixShortcut(); }
  
  private static void fixPermissions() { Platform.get().getUserHome(); }
  
  private static Date parseDate(String paramString) {
    Date date = null;
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yy hh:mm a");
    try {
      date = simpleDateFormat.parse(paramString);
    } catch (ParseException parseException1) {
      ParseException parseException2 = new ParseException(parseException1.getMessage() + " " + ResourceManager.getString("launch.error.dateformat"), parseException1.getErrorOffset());
      LaunchErrorDialog.show(null, parseException2, true);
    } 
    return date;
  }
  
  private static String[] parseArgs(String[] paramArrayOfString) {
    ArrayList<String> arrayList = new ArrayList();
    for (byte b1 = 0; b1 < paramArrayOfString.length; b1++) {
      if (!paramArrayOfString[b1].startsWith("-")) {
        arrayList.add(paramArrayOfString[b1]);
      } else if (paramArrayOfString[b1].equals("-offline")) {
        JnlpxArgs.SetIsOffline();
        DeployOfflineManager.setForcedOffline(true);
      } else if (!paramArrayOfString[b1].equals("-online") && !paramArrayOfString[b1].equals("-Xnosplash")) {
        if (paramArrayOfString[b1].equals("-installer")) {
          Environment.setInstallMode(true);
        } else if (paramArrayOfString[b1].equals("-uninstall")) {
          uninstall = true;
          includeInstalled = true;
          Environment.setInstallMode(true);
          Environment.setImportMode(true);
        } else if (paramArrayOfString[b1].equals("-clearcache")) {
          uninstall = true;
          includeInstalled = false;
          Environment.setInstallMode(true);
          Environment.setImportMode(true);
        } else if (paramArrayOfString[b1].equals("-import")) {
          Environment.setImportMode(true);
        } else if (paramArrayOfString[b1].equals("-quiet")) {
          Globals.setQuietMode(true);
        } else if (paramArrayOfString[b1].equals("-silent")) {
          _silent = true;
          Globals.setSilentMode(true);
        } else if (paramArrayOfString[b1].equals("-reverse")) {
          Globals.setReverseMode(true);
        } else if (paramArrayOfString[b1].equals("-javafx")) {
          Environment.setJavaFxInstallMode(1);
        } else if (paramArrayOfString[b1].equals("-javafxau")) {
          Environment.setJavaFxInstallMode(2);
        } else if (paramArrayOfString[b1].equals("-shortcut")) {
          Globals.setCreateShortcut(true);
          if (_fix)
            _fixShortcut = true; 
        } else if (paramArrayOfString[b1].equals("-association")) {
          Globals.setCreateAssoc(true);
        } else if (paramArrayOfString[b1].equals("-prompt")) {
          Globals.setShowPrompts(true);
        } else if (paramArrayOfString[b1].equals("-nocodebase")) {
          Globals.setNoCodebaseMode(true);
          if (b1 + 1 < paramArrayOfString.length) {
            String str1 = paramArrayOfString[++b1];
            String str2 = null;
            File file = new File(str1);
            try {
              HtmlOptions htmlOptions = HtmlOptions.create(new FileInputStream(file));
              LaunchDescFactory.setDocBase(htmlOptions.getDocBase());
              str2 = htmlOptions.getAbsoluteHref(LaunchDescFactory.getDerivedCodebase());
            } catch (IOException iOException) {
              LaunchErrorDialog.show(null, new Throwable("Launch file error", iOException), true);
            } finally {
              try {
                Trace.println("Remove LaunchPropFile: " + str1, TraceLevel.BASIC);
                file.delete();
              } catch (Exception exception) {
                Trace.ignored(exception);
              } 
            } 
            if (str2 != null)
              arrayList.add(str2); 
          } 
        } else if (paramArrayOfString[b1].equals("-docbase")) {
          if (b1 + 1 < paramArrayOfString.length) {
            String str = paramArrayOfString[++b1];
            try {
              LaunchDescFactory.setDocBase(new URL(str));
            } catch (MalformedURLException malformedURLException) {
              Trace.ignoredException(malformedURLException);
            } 
          } 
        } else if (paramArrayOfString[b1].equals("-codebase")) {
          if (b1 + 1 < paramArrayOfString.length) {
            String str = paramArrayOfString[++b1];
            try {
              new URL(str);
            } catch (MalformedURLException malformedURLException) {
              LaunchErrorDialog.show(null, malformedURLException, true);
            } 
            Environment.setImportModeCodebaseOverride(str);
          } 
        } else if (paramArrayOfString[b1].equals("-timestamp")) {
          if (b1 + 1 < paramArrayOfString.length) {
            String str = paramArrayOfString[++b1];
            Date date = parseDate(str);
            if (date != null)
              Environment.setImportModeTimestamp(date); 
          } 
        } else if (paramArrayOfString[b1].equals("-expiration")) {
          if (b1 + 1 < paramArrayOfString.length) {
            String str = paramArrayOfString[++b1];
            Date date = parseDate(str);
            if (date != null)
              Environment.setImportModeExpiration(date); 
          } 
        } else if (paramArrayOfString[b1].equals("-system")) {
          Environment.setSystemCacheMode(true);
          Cache.resetSystemCache();
        } else if (paramArrayOfString[b1].equals("-secure")) {
          Globals.setSecureMode(true);
        } else if (paramArrayOfString[b1].equals("-open") || paramArrayOfString[b1].equals("-print")) {
          if (b1 + 1 < paramArrayOfString.length) {
            String[] arrayOfString1 = new String[2];
            arrayOfString1[0] = paramArrayOfString[b1++];
            arrayOfString1[1] = paramArrayOfString[b1];
            Globals.setApplicationArgs(arrayOfString1);
            SingleInstanceManager.setActionName(arrayOfString1[0]);
            SingleInstanceManager.setOpenPrintFilePath(arrayOfString1[1]);
          } 
        } else if (paramArrayOfString[b1].equals("-viewer")) {
          _isViewer = true;
        } else if (paramArrayOfString[b1].equals("-verbose")) {
          _verbose = true;
        } else if (paramArrayOfString[b1].equals("-SSVBaselineUpdate")) {
          _baselineUpdate = true;
        } else if (!paramArrayOfString[b1].equals("-notWebJava")) {
          if (paramArrayOfString[b1].equals("-fix")) {
            _fix = true;
          } else if (paramArrayOfString[b1].equals("-permissions")) {
            if (_fix)
              _fixPermissions = true; 
          } else {
            Trace.println("unsupported option: " + paramArrayOfString[b1], TraceLevel.BASIC);
          } 
        } 
      } 
    } 
    String[] arrayOfString = new String[arrayList.size()];
    for (byte b2 = 0; b2 < arrayOfString.length; b2++)
      arrayOfString[b2] = arrayList.get(b2); 
    return arrayOfString;
  }
  
  private static void initTrace() {
    Trace.redirectStdioStderr();
    Trace.resetTraceLevel();
    Trace.clearTraceListeners();
    Trace.setInitialTraceLevel(Globals.TCKHarnessRun);
    if (_verbose || Globals.TraceBasic)
      Trace.setEnabled(TraceLevel.BASIC, true); 
    if (_verbose || Globals.TraceNetwork)
      Trace.setEnabled(TraceLevel.NETWORK, true); 
    if (_verbose || Globals.TraceCache)
      Trace.setEnabled(TraceLevel.CACHE, true); 
    if (_verbose || Globals.TraceSecurity)
      Trace.setEnabled(TraceLevel.SECURITY, true); 
    if (_verbose || Globals.TraceExtensions)
      Trace.setEnabled(TraceLevel.EXTENSIONS, true); 
    if (_verbose || Globals.TraceTemp)
      Trace.setEnabled(TraceLevel.TEMP, true); 
    PerfLogger.setTime("Start setup Console");
    if (Config.getStringProperty("deployment.console.startup.mode").equals("SHOW") && !ToolkitStore.get().isHeadless() && !Globals.isQuietMode()) {
      JavawsConsoleController javawsConsoleController1 = JavawsConsoleController.getInstance();
      ConsoleTraceListener consoleTraceListener = new ConsoleTraceListener();
      ConsoleWindow consoleWindow = ToolkitStore.getUI().getConsole((ConsoleController)javawsConsoleController1);
      javawsConsoleController1.setConsole(consoleWindow);
      consoleTraceListener.setConsole(consoleWindow);
      Trace.addTraceListener((TraceListener)consoleTraceListener);
      consoleWindow.clear();
    } 
    PerfLogger.setTime("End setup Console");
    SocketTraceListener socketTraceListener = initSocketTrace();
    if (socketTraceListener != null)
      Trace.addTraceListener((TraceListener)socketTraceListener); 
    FileTraceListener fileTraceListener = initFileTrace();
    if (fileTraceListener != null)
      Trace.addTraceListener((TraceListener)fileTraceListener); 
    JavawsConsoleController javawsConsoleController = JavawsConsoleController.getInstance();
    if (Config.getBooleanProperty("deployment.log")) {
      File file = null;
      try {
        boolean bool = false;
        String str = Config.getStringProperty("deployment.javaws.logFileName");
        File file1 = new File(Config.getLogDirectory());
        if (str != null && !"".equals(str)) {
          file = new File(str);
          if (file.isDirectory()) {
            file = null;
          } else {
            bool = true;
          } 
        } 
        LoggerTraceListener loggerTraceListener = LoggerTraceListener.getOrCreateSharedInstance("com.sun.deploy", file, file1, "javaws", ".log", bool);
        if (loggerTraceListener != null) {
          loggerTraceListener.getLogger().setLevel(Level.ALL);
          javawsConsoleController.setLogger(loggerTraceListener.getLogger());
          Trace.addTraceListener((TraceListener)loggerTraceListener);
        } 
      } catch (SecurityException securityException) {
        Trace.println("can not create log file in directory: " + Config.getLogDirectory(), TraceLevel.BASIC);
      } 
    } 
  }
  
  private static FileTraceListener initFileTrace() {
    if (Config.getBooleanProperty("deployment.trace")) {
      File file = null;
      String str1 = Config.getLogDirectory();
      String str2 = Config.getStringProperty("deployment.javaws.traceFileName");
      boolean bool = false;
      try {
        if (str2 != null && !"".equals(str2) && str2.compareToIgnoreCase("TEMP") != 0) {
          file = new File(str2);
          if (!file.isDirectory()) {
            int i = str2.lastIndexOf(File.separator);
            if (i != -1)
              str1 = str2.substring(0, i); 
            bool = true;
          } else {
            file = null;
          } 
        } 
        return FileTraceListener.getOrCreateSharedInstance(file, new File(str1), "javaws", ".trace", true, bool);
      } catch (Exception exception) {
        Trace.println("cannot create trace file in Directory: " + str1, TraceLevel.BASIC);
      } 
    } 
    return null;
  }
  
  private static SocketTraceListener initSocketTrace() {
    if (Globals.LogToHost != null) {
      byte b;
      String str1 = Globals.LogToHost;
      boolean bool = false;
      int i = 0;
      if (str1.charAt(0) == '[' && (i = str1.indexOf('\001', 93)) != -1) {
        bool = true;
      } else {
        i = str1.indexOf(":");
      } 
      String str2 = str1.substring(bool, i);
      if (str2 == null)
        return null; 
      try {
        String str = str1.substring(str1.lastIndexOf(':') + 1);
        b = Integer.parseInt(str);
      } catch (NumberFormatException numberFormatException) {
        b = -1;
      } 
      if (b < 0)
        return null; 
      SocketTraceListener socketTraceListener = new SocketTraceListener(str2, b);
      Socket socket = socketTraceListener.getSocket();
      if (Globals.TCKResponse && socket != null)
        try {
          _tckStream = new DataInputStream(socket.getInputStream());
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        }  
      return socketTraceListener;
    } 
    return null;
  }
  
  private static int uninstall(boolean paramBoolean, String paramString) {
    if (paramString == null) {
      Trace.println("Uninstall all!", TraceLevel.BASIC);
      CacheUtil.remove(paramBoolean);
      if (Globals.TCKHarnessRun)
        tckprintln("Cache Clear Success"); 
    } else {
      Trace.println("Uninstall: " + paramString, TraceLevel.BASIC);
      LaunchDesc launchDesc = null;
      try {
        launchDesc = LaunchDescFactory.buildDescriptor(paramString);
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } catch (JNLPException jNLPException) {
        Trace.ignoredException((Exception)jNLPException);
      } 
      if (launchDesc != null) {
        Object object = launchDesc.getInformation().getTitle();
        String str1 = ResourceManager.getString("uninstall.app.prompt.title");
        String str2 = ResourceManager.getString("uninstall.app.prompt.message", (String)object);
        String str3 = ResourceManager.getString("common.ok_btn");
        String str4 = ResourceManager.getString("common.cancel_btn");
        ToolkitStore.getUI();
        ToolkitStore.getUI();
        if (Globals.showPrompts() && ToolkitStore.getUI().showMessageDialog(null, launchDesc.getAppInfo(), 3, str1, null, str2, null, str3, str4, null) != 0) {
          Trace.println("Uninstall canceled by user.", TraceLevel.BASIC);
          return 0;
        } 
        object = null;
        ResourceObject resourceObject = ResourceProvider.get().getResourceObject(paramString);
        if ((launchDesc.isInstaller() || launchDesc.isLibrary()) && resourceObject != null) {
          LocalApplicationProperties localApplicationProperties = ResourceProvider.get().getLocalApplicationProperties(resourceObject.getResourceURL(), resourceObject.getResourceVersion(), true);
        } else {
          object = ResourceProvider.get().getLocalApplicationProperties(launchDesc.getCanonicalHome(), null, true);
        } 
        if (object != null) {
          File file;
          str2 = null;
          try {
            file = new File(paramString);
            if (!file.exists()) {
              URL uRL = new URL(paramString);
              file = ResourceProvider.get().getCachedJNLPFile(uRL, null);
            } 
          } catch (Exception exception) {
            Trace.ignored(exception);
          } 
          if (file != null && file.exists())
            CacheUtil.remove(file, launchDesc, new ArrayList()); 
          if (Globals.TCKHarnessRun)
            tckprintln("Cache Clear Success"); 
          return 0;
        } 
      } 
      Trace.println("Error uninstalling!", TraceLevel.BASIC);
      if (Globals.TCKHarnessRun)
        tckprintln("Cache Clear Failed"); 
      if (!Globals.isSilentMode() || Globals.isQuietMode()) {
        SplashScreen.hide();
        String str1 = ResourceManager.getMessage("uninstall.failedMessageTitle");
        String str2 = ResourceManager.getMessage("uninstall.failedMessage");
        String str3 = ResourceManager.getString("common.ok_btn");
        String str4 = ResourceManager.getString("common.detail.button");
        ToolkitStore.getUI();
        ToolkitStore.getUI().showMessageDialog(null, null, 0, str1, null, str2, null, str3, str4, null);
      } 
    } 
    return 0;
  }
  
  private static void setupBrowser() {
    if (Config.getBooleanProperty("deployment.capture.mime.types")) {
      setupNS6();
      setupOpera();
      Config.setBooleanProperty("deployment.capture.mime.types", false);
    } 
  }
  
  private static void setupOpera() {
    OperaSupport operaSupport = BrowserSupport.getInstance().getOperaSupport();
    if (operaSupport != null && operaSupport.isInstalled())
      operaSupport.enableJnlp(new File(Platform.get().getSystemJavawsPath()), Config.getBooleanProperty("deployment.update.mime.types")); 
  }
  
  private static void setupNS6() {
    String str1 = null;
    str1 = BrowserSupport.getInstance().getNS6MailCapInfo();
    String str2 = "user_pref(\"browser.helperApps.neverAsk.openFile\", \"application%2Fx-java-jnlp-file\");\n";
    File file = null;
    String str3 = Platform.get().getMozillaUserProfileDirectory();
    if (str3 != null)
      file = new File(str3 + File.separator + "prefs.js"); 
    if (file == null)
      return; 
    FileInputStream fileInputStream = null;
    try {
      boolean bool2;
      String str4 = null;
      fileInputStream = new FileInputStream(file);
      BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
      String str5 = "";
      boolean bool1 = true;
      if (str1 == null) {
        bool2 = false;
      } else {
        bool2 = true;
      } 
      while (true) {
        try {
          str4 = bufferedReader.readLine();
          if (str4 == null) {
            fileInputStream.close();
            break;
          } 
          str5 = str5 + str4 + "\n";
          if (str4.indexOf("x-java-jnlp-file") != -1)
            bool1 = false; 
          if (str1 != null && str4.indexOf(".mime.types") != -1)
            bool2 = false; 
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        } 
      } 
      if (!bool1 && !bool2)
        return; 
      if (bool1)
        str5 = str5 + str2; 
      if (str1 != null && bool2)
        str5 = str5 + str1; 
      FileOutputStream fileOutputStream = new FileOutputStream(file);
      try {
        fileOutputStream.write(str5.getBytes());
        fileOutputStream.close();
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } 
    } catch (FileNotFoundException fileNotFoundException) {
      Trace.ignoredException(fileNotFoundException);
      String str = "";
      if (str1 != null)
        str = str + str1; 
      str = str + str2;
      try {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        fileOutputStream.write(str.getBytes());
        fileOutputStream.close();
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } 
    } 
  }
  
  public static void initializeExecutionEnvironment() {
    if (_environmentInitialized)
      return; 
    _environmentInitialized = true;
    boolean bool1 = (Config.getOSName().indexOf("Windows") != -1) ? true : false;
    boolean bool2 = (Config.getOSName().indexOf("OS X") != -1) ? true : false;
    boolean bool = Config.isJavaVersionAtLeast15();
    Environment.setUserAgent(Globals.getUserAgent());
    if (bool1) {
      if (bool) {
        ServiceManager.setService(33024);
      } else {
        ServiceManager.setService(16640);
      } 
    } else if (bool2) {
      ServiceManager.setService(40960);
    } else if (bool) {
      ServiceManager.setService(36864);
    } else {
      ServiceManager.setService(20480);
    } 
    Properties properties = System.getProperties();
    properties.put("http.auth.serializeRequests", "true");
    if (Config.installDeployRMIClassLoaderSpi())
      properties.put("java.rmi.server.RMIClassLoaderSpi", "com.sun.jnlp.JNLPRMIClassLoaderSpi"); 
    String str1 = (String)properties.get("java.protocol.handler.pkgs");
    if (str1 != null) {
      properties.put("java.protocol.handler.pkgs", str1 + "|com.sun.deploy.net.protocol");
    } else {
      properties.put("java.protocol.handler.pkgs", "com.sun.deploy.net.protocol");
    } 
    properties.setProperty("javawebstart.version", Globals.getComponentName());
    try {
      PerfLogger.setTime("Start DeployProxySelector.reset");
      DeployProxySelector.reset();
      PerfLogger.setTime("End DeployProxySelector.reset");
      DeployCookieSelector.reset();
    } catch (Throwable throwable) {
      StaticProxyManager.reset();
    } 
    DeployOfflineManager.reset();
    if (Config.getBooleanProperty("deployment.security.authenticator")) {
      JAuthenticator jAuthenticator = JAuthenticator.getInstance((ComponentRef)null);
      Authenticator.setDefault((Authenticator)jAuthenticator);
    } 
    ServiceManager.setServiceManagerStub((ServiceManagerStub)new JnlpLookupStub());
    if (Config.useNativeSandbox(null) && !Platform.get().isNativeSandbox())
      Platform.get().setNativeSandboxJNLPService((NativeSandboxJNLPService)new NativeSandboxJNLPServiceImpl()); 
    Config.setupPackageAccessRestriction();
    UIFactory.setDialogListener((DialogListener)new JavawsDialogListener());
    SystemUtils.setHttpsProtocols(properties);
    JVMParameters jVMParameters = new JVMParameters();
    long l = JnlpxArgs.getMaxHeapSize();
    if (l <= 0L)
      l = JVMParameters.getDefaultHeapSize(); 
    jVMParameters.setMaxHeapSize(l);
    l = JnlpxArgs.getInitialHeapSize();
    if (l > 0L && l != JVMParameters.getDefaultHeapSize())
      jVMParameters.parse("-Xms" + JVMParameters.unparseMemorySpec(l)); 
    String str2 = JnlpxArgs.getVMArgs();
    if (str2 != null)
      jVMParameters.addEncodedArguments(str2, true, false, true); 
    jVMParameters.setDefault(true);
    JVMParameters.setRunningJVMParameters(jVMParameters);
    if (Trace.isEnabled(TraceLevel.BASIC))
      Trace.println("Running JVMParams: " + jVMParameters + "\n\t-> " + JVMParameters.getRunningJVMParameters(), TraceLevel.BASIC); 
  }
  
  public static void systemExit(int paramInt) throws ExitException {
    try {
      JnlpxArgs.removeArgumentFile(_tempfile);
      SplashScreen.hide();
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
    Trace.flush();
    if ((!_environmentInitialized && Environment.isJavaPlugin()) || "true".equals(System.getProperty("junit.in.progress"))) {
      ExitException exitException = new ExitException(new RuntimeException("exit(" + paramInt + ")"), 4);
      throw exitException;
    } 
    System.exit(paramInt);
  }
  
  public static boolean isViewer() { return _isViewer; }
  
  public static ThreadGroup getLaunchThreadGroup() { return _launchTG; }
  
  public static ThreadGroup getSecurityThreadGroup() { return _securityTG; }
  
  public static ClassLoader getSecureContextClassLoader() { return _secureContextClassLoader; }
  
  static ThreadGroup getMainThreadGroup() { return _mainTG; }
  
  private static void initializeThreadGroups() {
    if (_mainTG == null)
      _mainTG = Thread.currentThread().getThreadGroup(); 
    if (_securityTG == null) {
      _systemTG = Thread.currentThread().getThreadGroup();
      while (_systemTG.getParent() != null)
        _systemTG = _systemTG.getParent(); 
      _securityTG = new ThreadGroup(_systemTG, "javawsSecurityThreadGroup");
      DeploySysRun.setOverride((DeploySysRun)new JavawsSysRun());
      _launchTG = new ThreadGroup(_systemTG, "javawsApplicationThreadGroup");
    } 
  }
  
  public static synchronized void tckprintln(String paramString) {
    long l = System.currentTimeMillis();
    Trace.println("##TCKHarnesRun##:" + l + ":" + Runtime.getRuntime().hashCode() + ":" + Thread.currentThread() + ":" + paramString);
    if (_tckStream != null)
      try {
        while (_tckStream.readLong() < l);
      } catch (IOException iOException) {
        System.err.println("Warning:Exceptions occurred, while logging to logSocket");
        iOException.printStackTrace(System.err);
      }  
    Trace.flush();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/Main.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */