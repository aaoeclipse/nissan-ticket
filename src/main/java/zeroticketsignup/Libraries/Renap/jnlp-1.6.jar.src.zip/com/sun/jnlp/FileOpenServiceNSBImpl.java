package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import com.sun.deploy.util.Waiter;
import java.io.File;
import java.io.IOException;
import javax.jnlp.FileContents;
import javax.jnlp.FileOpenService;

public final class FileOpenServiceNSBImpl implements FileOpenService {
  private final FileOpenServiceImpl service;
  
  public FileOpenServiceNSBImpl(FileOpenServiceImpl paramFileOpenServiceImpl) { this.service = paramFileOpenServiceImpl; }
  
  public FileContents openFileDialog(final String pathHint, final String[] extensions) throws IOException {
    if (!this.service.askUser())
      return null; 
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception { return DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = Platform.get().getNativeSandboxBroker().openFileDialog(pathHint, extensions);
                  if (str == null)
                    return null; 
                  File file = new File(str);
                  if (file != null)
                    try {
                      FileOpenServiceImpl._fileSaveServiceImpl.setLastPath(file.getPath());
                      return new FileContentsImpl(file, FileSaveServiceImpl.computeMaxLength(file.length()));
                    } catch (IOException iOException) {} 
                  return null;
                }
              }null); }
      };
    try {
      return (FileContents)Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
  
  public FileContents[] openMultiFileDialog(final String pathHint, final String[] extensions) throws IOException {
    if (!this.service.askUser())
      return null; 
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception { return DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String[] arrayOfString = Platform.get().getNativeSandboxBroker().openMultiFileDialog(pathHint, extensions);
                  if (arrayOfString == null)
                    return null; 
                  if (arrayOfString != null && arrayOfString.length > 0) {
                    FileContents[] arrayOfFileContents = new FileContents[arrayOfString.length];
                    for (byte b = 0; b < arrayOfString.length; b++) {
                      try {
                        File file = new File(arrayOfString[b]);
                        arrayOfFileContents[b] = new FileContentsImpl(file, FileSaveServiceImpl.computeMaxLength(file.length()));
                      } catch (IOException iOException) {}
                    } 
                    return arrayOfFileContents;
                  } 
                  return null;
                }
              }null); }
      };
    try {
      return (FileContents[])Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/FileOpenServiceNSBImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */