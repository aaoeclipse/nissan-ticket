package com.sun.javaws.jnl;

import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.javaws.exceptions.FailedDownloadingResourceException;
import com.sun.javaws.exceptions.JNLPException;
import java.io.IOException;
import java.net.URL;

public class JARUpdater {
  private JARDesc _jar = null;
  
  private boolean _updateChecked = false;
  
  private boolean _updateAvailable = false;
  
  public JARUpdater(JARDesc paramJARDesc) { this._jar = paramJARDesc; }
  
  public synchronized boolean isUpdateAvailable() throws Exception {
    if (!this._updateChecked) {
      Trace.println("JARUpdater: update check for " + this._jar.getLocation().toString(), TraceLevel.NETWORK);
      try {
        this._updateAvailable = updateCheck();
        this._updateChecked = true;
      } catch (Exception exception) {
        Trace.ignored(exception);
        throw exception;
      } 
    } 
    return this._updateAvailable;
  }
  
  Resource downloadUpdate() throws Exception {
    if (isUpdateAvailable()) {
      Resource resource = download();
      synchronized (this) {
        this._updateAvailable = false;
      } 
      return resource;
    } 
    return null;
  }
  
  private boolean updateCheck() throws JNLPException {
    URL uRL = this._jar.getLocation();
    String str = this._jar.getVersion();
    boolean bool = false;
    if (str != null)
      return false; 
    try {
      bool = ResourceProvider.get().isUpdateAvailable(uRL, str, getDownloadType(), null);
    } catch (IOException iOException) {
      ResourcesDesc resourcesDesc = this._jar.getParent();
      LaunchDesc launchDesc = (resourcesDesc == null) ? null : resourcesDesc.getParent();
      throw new FailedDownloadingResourceException(launchDesc, uRL, null, iOException);
    } 
    return bool;
  }
  
  private Resource download() throws JNLPException {
    int i = getDownloadType();
    URL uRL = this._jar.getLocation();
    String str = this._jar.getVersion();
    try {
      return ResourceProvider.get().downloadUpdate(uRL, str, i, false);
    } catch (IOException iOException) {
      throw new FailedDownloadingResourceException(uRL, str, iOException);
    } 
  }
  
  private int getDownloadType() {
    int i = 256;
    if (this._jar.isNativeLib())
      i |= 0x10; 
    if (this._jar.isPack200Enabled())
      i |= 0x1000; 
    return i;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/JARUpdater.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */