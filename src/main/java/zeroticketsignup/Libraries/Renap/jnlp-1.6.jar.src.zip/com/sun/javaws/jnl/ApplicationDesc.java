package com.sun.javaws.jnl;

import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import com.sun.deploy.xml.XMLable;

public class ApplicationDesc implements XMLable {
  private String _mainClass;
  
  private String _progressClass;
  
  private String[] _arguments;
  
  public ApplicationDesc(String paramString1, String paramString2, String[] paramArrayOfString) {
    this._mainClass = paramString1;
    this._progressClass = paramString2;
    this._arguments = paramArrayOfString;
  }
  
  public String getMainClass() { return this._mainClass; }
  
  public String getProgressClass() { return this._progressClass; }
  
  public String[] getArguments() { return this._arguments; }
  
  public void setArguments(String[] paramArrayOfString) { this._arguments = paramArrayOfString; }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("main-class", this._mainClass);
    xMLAttributeBuilder.add("progress-class", this._progressClass);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("application-desc", xMLAttributeBuilder.getAttributeList());
    if (this._arguments != null)
      for (byte b = 0; b < this._arguments.length; b++)
        xMLNodeBuilder.add(new XMLNode("argument", null, new XMLNode(this._arguments[b]), null));  
    return xMLNodeBuilder.getNode();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/ApplicationDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */