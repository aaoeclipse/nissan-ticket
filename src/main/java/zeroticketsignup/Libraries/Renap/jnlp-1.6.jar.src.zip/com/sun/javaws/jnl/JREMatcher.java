package com.sun.javaws.jnl;

import com.sun.deploy.config.JREInfo;
import com.sun.deploy.config.NativePlatform;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.JVMParameters;
import com.sun.deploy.util.ParameterUtil;
import com.sun.deploy.util.SecurityBaseline;
import com.sun.deploy.util.VersionString;
import java.io.File;
import java.net.URL;

public class JREMatcher {
  private static final boolean DEBUG = Trace.isEnabled(TraceLevel.RULESET);
  
  private JREDesc selectedJREDesc;
  
  private JREDesc runningJREDesc;
  
  private JREInfo selectedJREInfo;
  
  private boolean matchComplete;
  
  private boolean matchSecureComplete;
  
  private boolean matchVersion;
  
  private boolean matchJVMArgs;
  
  private boolean matchSecureJVMArgs;
  
  private long selectedMaxHeap;
  
  private long selectedInitHeap;
  
  private JVMParameters selectedJVMArgs;
  
  private JREDesc drsDesc;
  
  private int selectionResult;
  
  private boolean matchToJnlpFound;
  
  private boolean matchToDRSFound;
  
  private boolean secureOnly;
  
  public JREMatcher() { setDRSVersion(null, false); }
  
  public void setDRSVersion(String paramString, boolean paramBoolean) {
    if (paramString != null) {
      this.drsDesc = new JREDesc(paramString, paramBoolean);
    } else {
      this.drsDesc = null;
    } 
    reset(null);
  }
  
  public boolean hasBeenRun() { return (null != this.selectedJVMArgs); }
  
  public void beginTraversal(LaunchDesc paramLaunchDesc) {
    reset(paramLaunchDesc);
    if (DEBUG)
      Trace.println("\tMatch: beginTraversal"); 
  }
  
  private void reset(LaunchDesc paramLaunchDesc) {
    this.matchComplete = false;
    this.matchSecureComplete = false;
    this.matchVersion = false;
    this.matchJVMArgs = false;
    this.matchSecureJVMArgs = false;
    this.selectedInitHeap = -1L;
    this.selectedJREDesc = null;
    this.runningJREDesc = null;
    this.selectedJREInfo = null;
    if (null == paramLaunchDesc) {
      this.selectedMaxHeap = -1L;
      this.selectedJVMArgs = null;
    } else {
      this.selectedMaxHeap = JVMParameters.getDefaultHeapSize();
      this.selectedJVMArgs = new JVMParameters();
    } 
    this.matchToJnlpFound = false;
    this.matchToDRSFound = false;
    this.selectionResult = 0;
  }
  
  public int getSelectionResult() { return this.selectionResult; }
  
  public JREInfo getSelectedJREInfo() { return this.selectedJREInfo; }
  
  public JREDesc getSelectedJREDesc() { return this.selectedJREDesc; }
  
  public JREDesc getRunningJREDesc() { return this.runningJREDesc; }
  
  public void setRunningJREDesc(JREDesc paramJREDesc) { this.runningJREDesc = paramJREDesc; }
  
  public JVMParameters getSelectedJVMParameters() { return this.selectedJVMArgs; }
  
  public long getSelectedInitHeapSize() { return this.selectedInitHeap; }
  
  public long getSelectedMaxHeapSize() { return this.selectedMaxHeap; }
  
  public boolean isRunningJVMSatisfying(boolean paramBoolean) {
    if (this.secureOnly) {
      String str = System.getProperty("java.version");
      if (!SecurityBaseline.satisfiesSecurityBaseline(str))
        return false; 
    } 
    return (this.selectedJREInfo != null && !hasRunningVMRequiredArgs(this.selectedJREInfo)) ? false : (paramBoolean ? this.matchComplete : this.matchSecureComplete);
  }
  
  private boolean hasRunningVMRequiredArgs(JREInfo paramJREInfo) { return ParameterUtil.hasRunningVMRequiredArgs(paramJREInfo.getVmArgs()); }
  
  public boolean isRunningJVMVersionSatisfying() { return this.matchVersion; }
  
  public boolean isRunningJVMArgsSatisfying(boolean paramBoolean) { return paramBoolean ? this.matchJVMArgs : this.matchSecureJVMArgs; }
  
  public void digest(JREDesc paramJREDesc, JREInfo paramJREInfo) {
    if (DEBUG)
      Trace.println("Match: digest selected JREDesc: " + paramJREDesc + ", JREInfo: " + paramJREInfo); 
    this.selectedJREDesc = paramJREDesc;
    this.selectedJREInfo = paramJREInfo;
    long l = paramJREDesc.getMaxHeap();
    if (l > this.selectedMaxHeap) {
      this.selectedMaxHeap = l;
      if (DEBUG)
        Trace.println("\tMatch: selecting maxHeap: " + l); 
    } else if (DEBUG) {
      Trace.println("\tMatch: ignoring maxHeap: " + l);
    } 
    l = paramJREDesc.getMinHeap();
    if (l > this.selectedInitHeap) {
      this.selectedInitHeap = l;
      if (DEBUG)
        Trace.println("\tMatch: selecting InitHeap: " + l); 
    } else if (DEBUG) {
      Trace.println("\tMatch: ignoring InitHeap: " + l);
    } 
    if (DEBUG)
      Trace.println("\tMatch: digesting vmargs: " + paramJREDesc.getVmArgs()); 
    this.selectedJVMArgs.parse(paramJREDesc.getVmArgs());
    if (DEBUG)
      Trace.println("\tMatch: digested vmargs: " + this.selectedJVMArgs); 
    l = this.selectedJVMArgs.getMaxHeapSize();
    if (l > this.selectedMaxHeap) {
      this.selectedMaxHeap = l;
      if (DEBUG)
        Trace.println("\tMatch: selecting maxHeap(2): " + l); 
    } 
    this.selectedJVMArgs.setMaxHeapSize(JVMParameters.getDefaultHeapSize());
    if (DEBUG)
      Trace.println("\tMatch: JVM args after accumulation: " + this.selectedJVMArgs); 
    if (paramJREInfo != null) {
      this.selectionResult = 1;
    } else {
      if (this.drsDesc != null)
        calculateMatchesToDRS(); 
      if (this.matchToJnlpFound && !this.matchToDRSFound) {
        this.selectionResult = 3;
      } else if (!this.matchToJnlpFound && this.matchToDRSFound) {
        this.selectionResult = 2;
      } else {
        this.selectionResult = 4;
      } 
    } 
  }
  
  private void calculateMatchesToDRS() {
    JREInfo[] arrayOfJREInfo = JREInfo.getValidSorted();
    if (arrayOfJREInfo != null)
      for (byte b = 0; b < arrayOfJREInfo.length; b++) {
        if (isDRSVersionMatch(arrayOfJREInfo[b], this.drsDesc))
          this.matchToDRSFound = true; 
      }  
  }
  
  public static String getJREVersionFromDRS(DeploymentRuleSet paramDeploymentRuleSet) {
    JREDesc jREDesc = new JREDesc(paramDeploymentRuleSet.getVersionString(), paramDeploymentRuleSet.isVersionForced());
    JREInfo[] arrayOfJREInfo = JREInfo.getValidSorted();
    if (arrayOfJREInfo != null)
      for (byte b = 0; b < arrayOfJREInfo.length; b++) {
        if (isDRSVersionMatch(arrayOfJREInfo[b], jREDesc))
          return arrayOfJREInfo[b].getProduct(); 
      }  
    return null;
  }
  
  public void digest(ResourcesDesc paramResourcesDesc) {
    if (paramResourcesDesc != null) {
      this.selectedJVMArgs.addProperties(paramResourcesDesc.getResourcePropertyList());
      if (DEBUG) {
        LaunchDesc launchDesc = paramResourcesDesc.getParent();
        if (launchDesc != null)
          Trace.println("\tMatch: digest LaunchDesc: " + launchDesc.getLocation()); 
        Trace.println("\tMatch: digest properties: " + paramResourcesDesc.getResourcePropertyList());
        Trace.println("\tMatch: JVM args: " + this.selectedJVMArgs);
      } 
    } 
  }
  
  public void endTraversal(LaunchDesc paramLaunchDesc) {
    if (DEBUG)
      Trace.println("\tMatch: endTraversal .."); 
    if (paramLaunchDesc.isApplicationDescriptor() && null == this.selectedJREDesc)
      throw new IllegalArgumentException("selectedJREDesc null"); 
    if (this.selectedInitHeap > 0L && this.selectedInitHeap != JVMParameters.getDefaultHeapSize())
      this.selectedJVMArgs.parse("-Xms" + JVMParameters.unparseMemorySpec(this.selectedInitHeap)); 
    this.selectedJVMArgs.setMaxHeapSize(this.selectedMaxHeap);
    if (this.selectedJREInfo == null)
      return; 
    this.matchVersion = isVersionMatch(paramLaunchDesc, this.selectedJREInfo);
    JVMParameters jVMParameters = JVMParameters.getRunningJVMParameters();
    if (jVMParameters == null) {
      if (Trace.isEnabled(TraceLevel.BASIC))
        Trace.println("\t Match: Running JVM is not set: want:<" + this.selectedJVMArgs + ">", TraceLevel.BASIC); 
      this.matchJVMArgs = false;
      this.matchSecureJVMArgs = false;
    } else if (jVMParameters.satisfies(this.selectedJVMArgs)) {
      if (DEBUG)
        Trace.println("\t Match: Running JVM args match: have:<" + jVMParameters + ">  satisfy want:<" + this.selectedJVMArgs + ">"); 
      this.matchJVMArgs = true;
      this.matchSecureJVMArgs = true;
    } else if (jVMParameters.satisfiesSecure(this.selectedJVMArgs)) {
      if (DEBUG)
        Trace.println("\t Match: Running JVM args match the secure subset: have:<" + jVMParameters + ">  satisfy want:<" + this.selectedJVMArgs + ">"); 
      this.matchJVMArgs = false;
      this.matchSecureJVMArgs = true;
    } else {
      if (DEBUG)
        Trace.println("\t Match: Running JVM args mismatch: have:<" + jVMParameters + "> !satisfy want:<" + this.selectedJVMArgs + ">"); 
      this.matchJVMArgs = false;
      this.matchSecureJVMArgs = false;
    } 
    this.matchComplete = (this.matchVersion && this.matchJVMArgs);
    this.matchSecureComplete = (this.matchVersion && this.matchSecureJVMArgs);
  }
  
  private static boolean isPlatformMatch(JREInfo paramJREInfo, JREDesc paramJREDesc) {
    VersionString versionString = new VersionString(paramJREDesc.getVersion());
    return (isArchMatch(paramJREInfo, paramJREDesc) && versionString.contains(paramJREInfo.getPlatform()));
  }
  
  private static boolean isProductMatch(JREInfo paramJREInfo, JREDesc paramJREDesc, boolean paramBoolean) {
    String str = paramJREInfo.getProduct();
    if (paramBoolean) {
      int i = str.indexOf("-");
      str = (i > 0) ? str.substring(0, i) : str;
    } 
    VersionString versionString = new VersionString(paramJREDesc.getVersion());
    URL uRL = paramJREDesc.getHref();
    boolean bool = (uRL == null || paramJREInfo.getLocation().equals(uRL.toString())) ? true : false;
    return bool ? ((isArchMatch(paramJREInfo, paramJREDesc) && versionString.contains(str))) : false;
  }
  
  private static boolean isArchMatch(JREInfo paramJREInfo, JREDesc paramJREDesc) {
    String[] arrayOfString = paramJREDesc.getArchList();
    if (arrayOfString == null)
      return true; 
    for (String str : arrayOfString) {
      NativePlatform nativePlatform = new NativePlatform(null, str);
      if (paramJREInfo.getNativePlatform().match(nativePlatform))
        return true; 
    } 
    return false;
  }
  
  protected boolean isDefaultVersionMatch(JREInfo paramJREInfo, JREDesc paramJREDesc) { return this.secureOnly ? SecurityBaseline.satisfiesSecurityBaseline(paramJREInfo.getProduct()) : ((paramJREDesc.getVersionType() == 0) ? isProductMatch(paramJREInfo, paramJREDesc, false) : isPlatformMatch(paramJREInfo, paramJREDesc)); }
  
  public boolean isVersionMatch(JREInfo paramJREInfo, JREDesc paramJREDesc) {
    if (!paramJREInfo.isFakeJRE() && !(new File(paramJREInfo.getPath())).exists())
      return false; 
    if (this.drsDesc != null && this.drsDesc.isVersionForced()) {
      if (isDRSVersionMatch(paramJREInfo, this.drsDesc)) {
        this.matchToJnlpFound = true;
        return true;
      } 
      return false;
    } 
    if (!isDefaultVersionMatch(paramJREInfo, paramJREDesc))
      return false; 
    if (this.drsDesc != null) {
      this.matchToJnlpFound = true;
      return isDRSVersionMatch(paramJREInfo, this.drsDesc);
    } 
    return true;
  }
  
  private static boolean isDRSVersionMatch(JREInfo paramJREInfo, JREDesc paramJREDesc) {
    if (paramJREDesc.isSecure()) {
      if (paramJREDesc.getVersion() == null)
        return SecurityBaseline.satisfiesBaselineStrictly(paramJREInfo.getProduct()); 
      String str = SecurityBaseline.getBaselineVersion(paramJREDesc.getVersion());
      return SecurityBaseline.satisfiesBaselineStrictly(paramJREInfo.getProduct(), str);
    } 
    return (paramJREDesc.getVersionType() == 0) ? isProductMatch(paramJREInfo, paramJREDesc, true) : isPlatformMatch(paramJREInfo, paramJREDesc);
  }
  
  public boolean isVersionMatch(LaunchDesc paramLaunchDesc, JREInfo paramJREInfo) {
    if (this.secureOnly)
      return SecurityBaseline.satisfiesSecurityBaseline(paramJREInfo.getProduct()); 
    if (!paramJREInfo.isArchMatch()) {
      Trace.println("Selected other architecture", TraceLevel.BASIC);
      return false;
    } 
    JREInfo jREInfo = paramLaunchDesc.getHomeJRE();
    if (!jREInfo.getProductVersion().match(paramJREInfo.getProductVersion())) {
      if (DEBUG)
        Trace.println("\tMatch: Running JREInfo Version mismatches: " + jREInfo.getProductVersion() + " != " + paramJREInfo.getProductVersion()); 
      return false;
    } 
    if (DEBUG)
      Trace.println("\tMatch: Running JREInfo Version    match: " + jREInfo.getProductVersion() + " == " + paramJREInfo.getProductVersion()); 
    return true;
  }
  
  public void setSecureOnly(boolean paramBoolean) {
    if (this.secureOnly != paramBoolean) {
      reset(null);
      this.secureOnly = paramBoolean;
    } 
  }
  
  public boolean getSecureOnly() { return this.secureOnly; }
  
  public String toString() { return "JREMatcher: \n  JREDesc:    " + getSelectedJREDesc() + "\n  JREInfo:    " + getSelectedJREInfo() + "\n  Init Heap:  " + getSelectedInitHeapSize() + "\n  Max  Heap:  " + getSelectedMaxHeapSize() + "\n  Satisfying: " + isRunningJVMSatisfying(true) + ", " + isRunningJVMSatisfying(false) + "\n  SatisfyingVersion: " + isRunningJVMVersionSatisfying() + "\n  SatisfyingJVMArgs: " + isRunningJVMArgsSatisfying(true) + ", " + isRunningJVMSatisfying(false) + "\n  SatisfyingSecure: " + isRunningJVMSatisfying(true) + "\n  Selected JVMParam: " + getSelectedJVMParameters() + "\n  Running  JVMParam: " + JVMParameters.getRunningJVMParameters(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/JREMatcher.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */