package com.sun.jnlp;

import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.Platform;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.jnl.LaunchDesc;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import javax.jnlp.FileContents;
import javax.jnlp.PersistenceService;

public final class PersistenceServiceImpl implements PersistenceService {
  private static final int MUFFIN_TAG_INDEX = 0;
  
  private static final int MUFFIN_MAXSIZE_INDEX = 1;
  
  private static final long GIGABYTE = 1073741824L;
  
  private static final long GLOBAL_LIMIT = 4294967296L;
  
  private static PersistenceService _sharedInstance = null;
  
  private long _appLimit = -1L;
  
  private final ApiDialog _apiDialog = new ApiDialog();
  
  private PersistenceServiceImpl() {
    long l = Config.getIntProperty("deployment.javaws.muffin.max") * 1024L;
    if (l > 4294967296L)
      l = 4294967296L; 
    this._appLimit = l;
  }
  
  public static synchronized PersistenceService getInstance() {
    initialize();
    return _sharedInstance;
  }
  
  public static synchronized void initialize() {
    if (_sharedInstance == null)
      if (Platform.get().isNativeSandbox()) {
        _sharedInstance = new PersistenceServiceNSBImpl(new PersistenceServiceImpl());
      } else {
        _sharedInstance = new PersistenceServiceImpl();
      }  
  }
  
  long getLength(URL paramURL) throws MalformedURLException, IOException {
    checkAccess(paramURL);
    return Cache.getMuffinSize(paramURL);
  }
  
  long getMaxLength(final URL url) throws MalformedURLException, IOException {
    long l = 0L;
    try {
      l = ((Long)AccessController.doPrivileged(new PrivilegedExceptionAction<Long>() {
            public Long run() throws IOException {
              long[] arrayOfLong = Cache.getMuffinAttributes(url);
              return (arrayOfLong == null) ? Long.valueOf(-1L) : Long.valueOf(arrayOfLong[1]);
            }
          })).longValue();
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
    return l;
  }
  
  long setMaxLength(final URL url, long paramLong) throws MalformedURLException, IOException {
    long l1 = 0L;
    checkAccess(url);
    if ((l1 = checkSetMaxSize(url, paramLong)) < 0L)
      return -1L; 
    final long f_newmaxsize = l1;
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
            public Void run() throws MalformedURLException, IOException {
              Cache.putMuffinAttributes(url, PersistenceServiceImpl.this.getTag(url), f_newmaxsize);
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
    return l1;
  }
  
  private long checkSetMaxSize(final URL url, long paramLong) throws IOException {
    URL[] arrayOfURL = null;
    try {
      arrayOfURL = AccessController.doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction<URL[]>() {
            public URL[] run() throws IOException { return Cache.getAccessibleMuffins(url); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
    long l1 = 0L;
    if (arrayOfURL != null)
      for (byte b = 0; b < arrayOfURL.length; b++) {
        if (arrayOfURL[b] != null) {
          URL uRL = arrayOfURL[b];
          if (!uRL.equals(url)) {
            long l = 0L;
            try {
              l = getMaxLength(uRL);
            } catch (IOException iOException) {}
            l1 += l;
          } 
        } 
      }  
    long l2 = this._appLimit - l1;
    return (paramLong > l2) ? reconcileMaxSize(paramLong, l1, this._appLimit) : paramLong;
  }
  
  private long reconcileMaxSize(long paramLong1, long paramLong2, long paramLong3) {
    long l = paramLong1 + paramLong2;
    if (l < paramLong1 || l > 4294967296L)
      return paramLong3 - paramLong2; 
    boolean bool = CheckServicePermission.hasFileAccessPermissions();
    if (bool || askUser(l, paramLong3)) {
      this._appLimit = l;
      return paramLong1;
    } 
    return paramLong3 - paramLong2;
  }
  
  public long create(final URL url, long paramLong) throws MalformedURLException, IOException {
    checkAccess(url);
    long l1 = 0L;
    long l2 = -1L;
    if ((l2 = checkSetMaxSize(url, paramLong)) < 0L)
      return 0L; 
    final long pass_newmaxsize = l2;
    try {
      l1 = ((Long)AccessController.doPrivileged(new PrivilegedExceptionAction<Long>() {
            public Long run() throws MalformedURLException, IOException {
              Cache.createMuffinEntry(url, 0, pass_newmaxsize);
              return Long.valueOf(pass_newmaxsize);
            }
          })).longValue();
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
    return l1;
  }
  
  public FileContents get(final URL url) throws MalformedURLException, IOException {
    checkAccess(url);
    File file = null;
    try {
      file = AccessController.doPrivileged(new PrivilegedExceptionAction<File>() {
            public File run() throws MalformedURLException, IOException { return Cache.getMuffinFile(url); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
    if (file == null)
      throw new FileNotFoundException(url.toString()); 
    return new FileContentsImpl(file, this, url, getMaxLength(url));
  }
  
  String get(String paramString) throws MalformedURLException, IOException {
    final URL url = new URL(paramString);
    checkAccess(uRL);
    File file = null;
    try {
      file = AccessController.doPrivileged(new PrivilegedExceptionAction<File>() {
            public File run() throws MalformedURLException, IOException { return Cache.getMuffinFile(url); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
    if (file == null)
      throw new FileNotFoundException(uRL.toString()); 
    return file.getAbsolutePath();
  }
  
  public void delete(final URL url) throws MalformedURLException, IOException {
    checkAccess(url);
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
            public Void run() throws MalformedURLException, IOException {
              Cache.removeMuffinEntry(url);
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
  }
  
  public String[] getNames(URL paramURL) throws MalformedURLException, IOException {
    String[] arrayOfString = null;
    final URL pathUrl = URLUtil.asPathURL(paramURL);
    checkAccess(uRL);
    try {
      arrayOfString = AccessController.doPrivileged((PrivilegedExceptionAction)new PrivilegedExceptionAction<String[]>() {
            public String[] run() throws MalformedURLException, IOException { return Cache.getMuffinNames(pathUrl); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
    return arrayOfString;
  }
  
  public int getTag(final URL url) throws MalformedURLException, IOException {
    Integer integer = null;
    checkAccess(url);
    try {
      integer = AccessController.doPrivileged(new PrivilegedExceptionAction<Integer>() {
            public Integer run() throws MalformedURLException, IOException {
              long[] arrayOfLong = Cache.getMuffinAttributes(url);
              if (arrayOfLong == null)
                throw new MalformedURLException(); 
              return Integer.valueOf((int)arrayOfLong[0]);
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
    return integer.intValue();
  }
  
  public void setTag(final URL url, final int tag) throws MalformedURLException, IOException {
    checkAccess(url);
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
            public Void run() throws MalformedURLException, IOException {
              Cache.putMuffinAttributes(url, tag, PersistenceServiceImpl.this.getMaxLength(url));
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      Exception exception = privilegedActionException.getException();
      if (exception instanceof IOException)
        throw (IOException)exception; 
      if (exception instanceof MalformedURLException)
        throw (MalformedURLException)exception; 
    } 
  }
  
  private boolean askUser(final long requested, final long currentLimit) {
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Boolean run() {
            String str1 = ResourceManager.getString("api.persistence.title");
            String str2 = ResourceManager.getString("api.persistence.message");
            String str3 = ResourceManager.getString("api.persistence.detail", new Long(requested), new Long(currentLimit));
            ApiDialog.DialogResult dialogResult = PersistenceServiceImpl.this._apiDialog.askUser(str1, str2, null, null, str3, false);
            if (dialogResult == ApiDialog.DialogResult.OK || dialogResult == ApiDialog.DialogResult.ALWAYS) {
              long l = Math.min(4294967296L, (requested + 1023L) / 1024L);
              Config.setIntProperty("deployment.javaws.muffin.max", (int)l);
              Config.get().storeIfNeeded();
              return Boolean.valueOf(true);
            } 
            return Boolean.valueOf(false);
          }
        });
    return bool.booleanValue();
  }
  
  protected void checkAccess(URL paramURL) throws MalformedURLException {
    if (paramURL == null)
      throw new MalformedURLException("URL is null"); 
    LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
    if (launchDesc != null && launchDesc.getSecurityModel() == 0) {
      URL uRL = launchDesc.getMainJarURL();
      if (uRL != null) {
        if (paramURL == null || !uRL.getHost().equals(paramURL.getHost()))
          throwAccessDenied(paramURL); 
        String str = paramURL.getFile();
        if (str == null)
          throwAccessDenied(paramURL); 
        int i = str.lastIndexOf('/');
        if (i == -1)
          return; 
        if (!uRL.getFile().startsWith(str.substring(0, i + 1)))
          throwAccessDenied(paramURL); 
      } 
    } 
  }
  
  private void throwAccessDenied(URL paramURL) throws MalformedURLException { throw new MalformedURLException(ResourceManager.getString("api.persistence.accessdenied", paramURL.toString())); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/PersistenceServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */