package com.sun.jnlp;

import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.javaws.Main;
import com.sun.javaws.exceptions.ExitException;
import java.applet.Applet;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.applet.AudioClip;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Insets;
import java.io.InputStream;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;

public final class AppletContainer extends JPanel {
  final AppletContainerCallback callback;
  
  final Applet applet;
  
  final String appletName;
  
  final URL documentBase;
  
  final URL codeBase;
  
  final Properties parameters;
  
  final boolean[] isActive = new boolean[] { false };
  
  int appletWidth;
  
  int appletHeight;
  
  final JLabel statusLabel = new JLabel("");
  
  static PrivilegedAction loadImageActionDummy = new LoadImageAction(null);
  
  public AppletContainer(AppletContainerCallback paramAppletContainerCallback, Applet paramApplet, String paramString, URL paramURL1, URL paramURL2, int paramInt1, int paramInt2, Properties paramProperties) {
    this.callback = paramAppletContainerCallback;
    this.applet = paramApplet;
    this.appletName = paramString;
    this.documentBase = paramURL1;
    this.codeBase = paramURL2;
    this.parameters = paramProperties;
    this.isActive[0] = false;
    this.appletWidth = paramInt1;
    this.appletHeight = paramInt2;
    AppletContainerContext appletContainerContext = new AppletContainerContext();
    AppletContainerStub appletContainerStub = new AppletContainerStub(appletContainerContext);
    paramApplet.setStub(appletContainerStub);
    this.statusLabel.setBorder(new EtchedBorder());
    this.statusLabel.setText("Loading...");
    setLayout(new BorderLayout());
    add("Center", paramApplet);
    add("South", this.statusLabel);
    Dimension dimension = new Dimension(this.appletWidth, this.appletHeight + (int)this.statusLabel.getPreferredSize().getHeight());
    setPreferredSize(dimension);
  }
  
  public Applet getApplet() { return this.applet; }
  
  public void setStatus(String paramString) { this.statusLabel.setText(paramString); }
  
  public void resizeApplet(int paramInt1, int paramInt2) {
    if (paramInt1 < 0 || paramInt2 < 0)
      return; 
    int i = paramInt1 - this.appletWidth;
    int j = paramInt2 - this.appletHeight;
    Dimension dimension1 = getSize();
    Dimension dimension2 = new Dimension((int)dimension1.getWidth() + i, (int)dimension1.getHeight() + j);
    setSize(dimension2);
    this.callback.relativeResize(new Dimension(i, j));
    this.appletWidth = paramInt1;
    this.appletHeight = paramInt2;
  }
  
  public Dimension getPreferredFrameSize(Frame paramFrame) {
    Insets insets = paramFrame.getInsets();
    int i = this.appletWidth + insets.left + insets.right;
    int j = this.appletHeight + this.statusLabel.getHeight() + insets.top + insets.bottom;
    return new Dimension(i, j);
  }
  
  public void startApplet() {
    ImageCache.initialize();
    new AppletAudioClip();
    (new Thread() {
        public void run() {
          try {
            AppletContainer.this.setStatus("Initializing Applet");
            AppletContainer.this.applet.init();
            try {
              AppletContainer.this.isActive[0] = true;
              AppletContainer.this.applet.start();
              AppletContainer.this.setStatus("Applet running...");
            } catch (Throwable throwable) {
              AppletContainer.this.setStatus("Failed to start Applet: " + throwable.toString());
              throwable.printStackTrace(System.out);
              AppletContainer.this.isActive[0] = false;
            } 
          } catch (Throwable throwable) {
            AppletContainer.this.setStatus("Failed to initialize: " + throwable.toString());
            throwable.printStackTrace(System.out);
          } 
        }
      }).start();
  }
  
  public void stopApplet() {
    this.applet.stop();
    this.applet.destroy();
    try {
      Main.systemExit(0);
    } catch (ExitException exitException) {
      Trace.println("systemExit: " + exitException, TraceLevel.BASIC);
      Trace.ignoredException((Exception)exitException);
    } 
  }
  
  static void showApplet(AppletContainerCallback paramAppletContainerCallback, final Applet applet, String paramString, URL paramURL1, URL paramURL2, int paramInt1, int paramInt2, Properties paramProperties) {
    JFrame jFrame = new JFrame("Applet Window");
    final AppletContainer container = new AppletContainer(paramAppletContainerCallback, applet, paramString, paramURL1, paramURL2, paramInt1, paramInt2, paramProperties);
    jFrame.getContentPane().setLayout(new BorderLayout());
    jFrame.getContentPane().add("Center", appletContainer);
    jFrame.pack();
    jFrame.setVisible(true);
    SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            try {
              container.setStatus("Initializing Applet");
              applet.init();
              applet.start();
              container.setStatus("Applet Running");
            } catch (Throwable throwable) {
              container.setStatus("Failed to start Applet");
            } 
          }
        });
  }
  
  class AppletContainerContext implements AppletContext {
    public Applet getApplet(String param1String) { return param1String.equals(AppletContainer.this.appletName) ? AppletContainer.this.applet : null; }
    
    public Enumeration getApplets() {
      Vector<Applet> vector = new Vector();
      vector.add(AppletContainer.this.applet);
      return vector.elements();
    }
    
    public AudioClip getAudioClip(URL param1URL) { return AppletAudioClip.get(param1URL); }
    
    public Image getImage(URL param1URL) {
      AppletContainer.LoadImageAction loadImageAction = new AppletContainer.LoadImageAction(param1URL);
      return AccessController.doPrivileged(loadImageAction);
    }
    
    public void showDocument(final URL url) { AccessController.doPrivileged(new PrivilegedAction() {
            public Object run() {
              Thread thread = new Thread() {
                  public void run() { AppletContainer.this.callback.showDocument(url); }
                };
              thread.start();
              return null;
            }
          }); }
    
    public void showDocument(URL param1URL, String param1String) { showDocument(param1URL); }
    
    public void showStatus(String param1String) { AppletContainer.this.statusLabel.setText(param1String); }
    
    public void setStream(String param1String, InputStream param1InputStream) {}
    
    public InputStream getStream(String param1String) { return null; }
    
    public Iterator getStreamKeys() { return null; }
  }
  
  final class AppletContainerStub implements AppletStub {
    AppletContext context;
    
    AppletContainerStub(AppletContext param1AppletContext) { this.context = param1AppletContext; }
    
    public void appletResize(int param1Int1, int param1Int2) { AppletContainer.this.resizeApplet(param1Int1, param1Int2); }
    
    public AppletContext getAppletContext() { return this.context; }
    
    public URL getCodeBase() { return AppletContainer.this.codeBase; }
    
    public URL getDocumentBase() { return AppletContainer.this.documentBase; }
    
    public String getParameter(String param1String) { return AppletContainer.this.parameters.getProperty(param1String); }
    
    public boolean isActive() { return AppletContainer.this.isActive[0]; }
  }
  
  static class LoadImageAction implements PrivilegedAction {
    URL _url;
    
    public LoadImageAction(URL param1URL) { this._url = param1URL; }
    
    public Object run() { return ImageCache.getImage(this._url); }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/AppletContainer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */