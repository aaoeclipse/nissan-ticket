package com.sun.javaws.ui;

import com.sun.deploy.cache.Cache;
import com.sun.deploy.cache.CacheEntry;
import com.sun.deploy.resources.ResourceManager;
import com.sun.javaws.CacheUtil;
import com.sun.javaws.jnl.LaunchDesc;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

class CacheTable extends JTable {
  private static final TableCellRenderer defaultRenderer = new DefaultTableCellRenderer();
  
  static final int JNLP_ROW_HEIGHT = 36;
  
  static final int RESOURCE_ROW_HEIGHT = 26;
  
  static final int JNLP_TYPE = 0;
  
  static final int RESOURCE_TYPE = 1;
  
  static final int DELETED_TYPE = 2;
  
  private final CacheViewer viewer;
  
  private final int tableType;
  
  private final boolean isSystem;
  
  public CacheTable(CacheViewer paramCacheViewer, int paramInt, boolean paramBoolean) {
    this.viewer = paramCacheViewer;
    this.tableType = paramInt;
    this.isSystem = paramBoolean;
    setShowGrid(false);
    setIntercellSpacing(new Dimension(0, 0));
    setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
    byte b = (this.tableType == 0) ? 36 : 26;
    setRowHeight(b);
    setPreferredScrollableViewportSize(new Dimension(640, 280));
    addMouseListener(new MouseAdapter() {
          public void mousePressed(MouseEvent param1MouseEvent) {
            if (param1MouseEvent.isPopupTrigger()) {
              int i = param1MouseEvent.getY();
              int j = i / CacheTable.this.getRowHeight();
              if (j < CacheTable.this.getModel().getRowCount()) {
                CacheTable.this.getSelectionModel().clearSelection();
                CacheTable.this.getSelectionModel().addSelectionInterval(j, j);
                CacheTable.this.viewer.popupApplicationMenu(CacheTable.this, param1MouseEvent.getX(), i);
              } 
            } 
          }
          
          public void mouseReleased(MouseEvent param1MouseEvent) {
            if (param1MouseEvent.isPopupTrigger()) {
              int i = param1MouseEvent.getY();
              int j = i / CacheTable.this.getRowHeight();
              if (j < CacheTable.this.getModel().getRowCount()) {
                CacheTable.this.getSelectionModel().clearSelection();
                CacheTable.this.getSelectionModel().addSelectionInterval(j, j);
                CacheTable.this.viewer.popupApplicationMenu(CacheTable.this, param1MouseEvent.getX(), i);
              } 
            } 
          }
          
          public void mouseClicked(MouseEvent param1MouseEvent) {
            Point point = param1MouseEvent.getPoint();
            if (param1MouseEvent.getClickCount() == 2 && (CacheTable.this.getSelectedRows()).length == 1 && param1MouseEvent.getButton() == 1) {
              int i = CacheTable.this.getColumnModel().getColumnIndexAtX(point.x);
              if (CacheTable.this.getSelectedRow() == CacheTable.this.rowAtPoint(point) && i < 3)
                if (CacheTable.this.tableType == 0) {
                  CacheTable.this.viewer.runApplication();
                } else if (CacheTable.this.tableType == 2) {
                  CacheTable.this.viewer.importApplication();
                } else {
                  CacheTable.this.viewer.showInformation();
                }  
            } 
          }
        });
    addKeyListener(new KeyAdapter() {
          public void keyPressed(KeyEvent param1KeyEvent) {
            int i = param1KeyEvent.getKeyCode();
            int j = param1KeyEvent.getModifiers();
            if (i == 121 && (j & true) != 0) {
              int k = CacheTable.this.getRowHeight() * CacheTable.this.getSelectedRow() + 6;
              int m = 100;
              if (CacheTable.this.getModel() instanceof CacheTable.CacheTableModel) {
                CacheTable.CacheTableModel cacheTableModel = (CacheTable.CacheTableModel)CacheTable.this.getModel();
                m = cacheTableModel.getPreferredWidth(0);
              } 
              int n = 2 * m / 3;
              CacheTable.this.viewer.popupApplicationMenu(CacheTable.this, n, k);
            } else if (i == 10) {
              boolean bool = ((j & 0x2) == 0) ? true : false;
              if (CacheTable.this.tableType == 0) {
                CacheTable.this.viewer.runApplication(bool);
              } else if (CacheTable.this.tableType == 2) {
                CacheTable.this.viewer.importApplication();
              } else {
                CacheTable.this.viewer.showInformation();
              } 
              param1KeyEvent.consume();
            } else if (i == 127 || i == 8) {
              CacheTable.this.viewer.delete();
            } 
          }
        });
    reset();
  }
  
  public String getSizeLabelText() {
    long l1 = Cache.getCacheSize(this.isSystem);
    long l2 = getInstalledSize(this.isSystem);
    long l3 = l1 - l2;
    String str1 = getSizeString(l2);
    String str2 = getSizeString(l3);
    return this.isSystem ? ResourceManager.getString("viewer.size.system", str1, str2) : ResourceManager.getString("viewer.size", str1, str2);
  }
  
  private String getSizeString(long paramLong) {
    String str;
    if (paramLong > 10240L) {
      str = " " + ResourceManager.getString("viewer.measure.units.kb", String.valueOf(paramLong / 1024L));
    } else {
      str = " " + (paramLong / 1024L) + "." + ResourceManager.getString("viewer.measure.units.kb", String.valueOf(paramLong % 1024L / 102L));
    } 
    return str;
  }
  
  private long getInstalledSize(boolean paramBoolean) {
    ArrayList arrayList = CacheUtil.getInstalledResources(paramBoolean);
    Iterator<File> iterator = arrayList.iterator();
    long l = 0L;
    while (iterator.hasNext()) {
      CacheEntry cacheEntry = Cache.getCacheEntryFromFile(iterator.next());
      if (cacheEntry != null)
        l += cacheEntry.getSize(); 
    } 
    return l;
  }
  
  public void reset() {
    getSelectionModel().clearSelection();
    getSelectionModel().removeListSelectionListener(this.viewer);
    TableModel tableModel = getModel();
    if (tableModel instanceof CacheTableModel)
      ((CacheTableModel)tableModel).removeMouseListenerFromHeaderInTable(this); 
    CacheTableModel cacheTableModel = new CacheTableModel(this.tableType, this.isSystem);
    setModel(cacheTableModel);
    for (byte b = 0; b < getModel().getColumnCount(); b++) {
      TableColumn tableColumn = getColumnModel().getColumn(b);
      tableColumn.setHeaderRenderer(new CacheTableHeaderRenderer());
      int i = cacheTableModel.getPreferredWidth(b);
      tableColumn.setPreferredWidth(i);
      tableColumn.setMinWidth(i);
    } 
    setDefaultRenderer(JLabel.class, cacheTableModel);
    cacheTableModel.addMouseListenerToHeaderInTable(this);
    getSelectionModel().addListSelectionListener(this.viewer);
    getSelectionModel().clearSelection();
  }
  
  public CacheObject getCacheObject(int paramInt) { return ((CacheTableModel)getModel()).getCacheObject(paramInt); }
  
  public String[] getAllHrefs() {
    ArrayList<String> arrayList = new ArrayList();
    TableModel tableModel = getModel();
    if (tableModel instanceof CacheTableModel)
      for (byte b = 0; b < tableModel.getRowCount(); b++) {
        String str = ((CacheTableModel)tableModel).getRowHref(b);
        if (str != null)
          arrayList.add(str); 
      }  
    return arrayList.toArray(new String[0]);
  }
  
  public boolean getScrollableTracksViewportHeight() { return (getParent() instanceof JViewport) ? ((((JViewport)getParent()).getHeight() > (getPreferredSize()).height)) : false; }
  
  private class CacheTableHeaderRenderer extends DefaultTableCellRenderer {
    private CacheTableHeaderRenderer() {}
    
    public Component getTableCellRendererComponent(JTable param1JTable, Object param1Object, boolean param1Boolean1, boolean param1Boolean2, int param1Int1, int param1Int2) {
      if (param1JTable != null) {
        JTableHeader jTableHeader = param1JTable.getTableHeader();
        if (jTableHeader != null) {
          setForeground(jTableHeader.getForeground());
          setBackground(jTableHeader.getBackground());
          setFont(jTableHeader.getFont());
        } 
      } 
      setText((param1Object == null) ? "" : param1Object.toString());
      setBorder(UIManager.getBorder("TableHeader.cellBorder"));
      setHorizontalAlignment(0);
      String str = CacheObject.getHeaderToolTipText(param1Int2, CacheTable.this.tableType);
      if (str != null && str.length() > 0)
        setToolTipText(str); 
      return this;
    }
  }
  
  private class CacheTableModel extends AbstractTableModel implements TableCellRenderer {
    private boolean isSystem;
    
    private int tableType;
    
    private CacheObject[] rows;
    
    private int sortColumn;
    
    private boolean sortAscending;
    
    private MouseListener mouseListener = null;
    
    public CacheTableModel(int param1Int, boolean param1Boolean) {
      this.tableType = param1Int;
      this.isSystem = param1Boolean;
      this.rows = new CacheObject[0];
      this.sortColumn = -1;
      this.sortAscending = true;
      refresh();
      fireTableDataChanged();
    }
    
    public Component getTableCellRendererComponent(JTable param1JTable, Object param1Object, boolean param1Boolean1, boolean param1Boolean2, int param1Int1, int param1Int2) {
      if (param1Object instanceof Component) {
        Component component = (Component)param1Object;
        if (param1Boolean1) {
          component.setForeground(param1JTable.getSelectionForeground());
          component.setBackground(param1JTable.getSelectionBackground());
        } else {
          component.setForeground(param1JTable.getForeground());
          component.setBackground(param1JTable.getBackground());
        } 
        CacheObject.hasFocus(component, param1Boolean2);
        return component;
      } 
      return defaultRenderer.getTableCellRendererComponent(param1JTable, param1Object, param1Boolean1, param1Boolean2, param1Int1, param1Int2);
    }
    
    private boolean isEntryIPEqual(CacheObject param1CacheObject1, CacheObject param1CacheObject2) {
      String str1 = param1CacheObject1.getCodebaseIP();
      String str2 = param1CacheObject2.getCodebaseIP();
      return ((str1 == null && str2 == null) || (str1 != null && str1.equals(str2)) || (str2 != null && str2.equals(str1)));
    }
    
    private boolean validateEntry(ArrayList<CacheObject> param1ArrayList, CacheObject param1CacheObject) {
      for (byte b = 0; b < param1ArrayList.size(); b++) {
        CacheObject cacheObject = param1ArrayList.get(b);
        if (cacheObject.getUrlString().equals(param1CacheObject.getUrlString()) && !isEntryIPEqual(cacheObject, param1CacheObject))
          return false; 
      } 
      return true;
    }
    
    public void refresh() {
      Cache.removeDuplicateEntries(false);
      ArrayList<CacheObject> arrayList = new ArrayList();
      if (this.tableType == 0) {
        for (File file1 : Cache.getJnlpCacheEntries(this.isSystem)) {
          File file2 = new File(file1.getPath() + ".idx");
          CacheEntry cacheEntry = Cache.getCacheEntryFromFile(file2);
          if (cacheEntry != null && cacheEntry.isValidEntry()) {
            CacheObject cacheObject = new CacheObject(cacheEntry, this, this.tableType);
            LaunchDesc launchDesc = cacheObject.getLaunchDesc();
            if (launchDesc != null && launchDesc.isApplicationDescriptor() && validateEntry(arrayList, cacheObject))
              arrayList.add(cacheObject); 
          } 
        } 
      } else if (this.tableType == 1) {
        File[] arrayOfFile = Cache.getCacheEntries(this.isSystem);
        for (byte b = 0; b < arrayOfFile.length; b++) {
          CacheEntry cacheEntry = Cache.getCacheEntryFromFile(arrayOfFile[b]);
          if (cacheEntry != null && cacheEntry.isValidEntry()) {
            CacheObject cacheObject = new CacheObject(cacheEntry, this, this.tableType);
            if (validateEntry(arrayList, cacheObject))
              arrayList.add(cacheObject); 
          } 
        } 
      } else if (this.tableType == 2) {
        Properties properties = Cache.getRemovedApps();
        Enumeration<?> enumeration = properties.propertyNames();
        while (enumeration.hasMoreElements()) {
          String str1 = (String)enumeration.nextElement();
          String str2 = properties.getProperty(str1);
          arrayList.add(new CacheObject(str2, str1, this));
        } 
      } 
      this.rows = arrayList.toArray(new CacheObject[0]);
      if (this.sortColumn != -1)
        sort(); 
    }
    
    CacheObject getCacheObject(int param1Int) { return this.rows[param1Int]; }
    
    public Object getValueAt(int param1Int1, int param1Int2) { return this.rows[param1Int1].getObject(param1Int2); }
    
    public int getRowCount() { return this.rows.length; }
    
    public String getRowHref(int param1Int) { return this.rows[param1Int].getHref(); }
    
    public int getColumnCount() { return CacheObject.getColumnCount(this.tableType); }
    
    public boolean isCellEditable(int param1Int1, int param1Int2) { return this.rows[param1Int1].isEditable(param1Int2); }
    
    public Class getColumnClass(int param1Int) { return CacheObject.getClass(param1Int, this.tableType); }
    
    public String getColumnName(int param1Int) { return CacheObject.getColumnName(param1Int, this.tableType); }
    
    public void setValueAt(Object param1Object, int param1Int1, int param1Int2) { this.rows[param1Int1].setValue(param1Int2, param1Object); }
    
    public int getPreferredWidth(int param1Int) { return CacheObject.getPreferredWidth(param1Int, this.tableType); }
    
    public void removeMouseListenerFromHeaderInTable(JTable param1JTable) {
      if (this.mouseListener != null)
        param1JTable.getTableHeader().removeMouseListener(this.mouseListener); 
    }
    
    public void addMouseListenerToHeaderInTable(JTable param1JTable) {
      final JTable tableView = param1JTable;
      jTable.setColumnSelectionAllowed(false);
      final ListSelectionModel lsm = jTable.getSelectionModel();
      this.mouseListener = new MouseAdapter() {
          public void mouseClicked(MouseEvent param2MouseEvent) {
            TableColumnModel tableColumnModel = tableView.getColumnModel();
            int i = tableColumnModel.getColumnIndexAtX(param2MouseEvent.getX());
            int j = lsm.getMinSelectionIndex();
            lsm.clearSelection();
            int k = tableView.convertColumnIndexToModel(i);
            if (param2MouseEvent.getClickCount() == 1 && k >= 0) {
              int m = param2MouseEvent.getModifiers() & true;
              CacheTable.CacheTableModel.this.sortAscending = (m == 0);
              CacheTable.CacheTableModel.this.sortColumn = k;
              CacheTable.CacheTableModel.this.runSort(lsm, j);
            } 
          }
        };
      jTable.getTableHeader().addMouseListener(this.mouseListener);
    }
    
    public void sort() {
      boolean bool = false;
      if (this.sortAscending) {
        for (byte b = 0; b < getRowCount(); b++) {
          for (int i = b + 1; i < getRowCount(); i++) {
            if (this.rows[b].compareColumns(this.rows[i], this.sortColumn) > 0) {
              bool = true;
              CacheObject cacheObject = this.rows[b];
              this.rows[b] = this.rows[i];
              this.rows[i] = cacheObject;
            } 
          } 
        } 
      } else {
        for (byte b = 0; b < getRowCount(); b++) {
          for (int i = b + 1; i < getRowCount(); i++) {
            if (this.rows[i].compareColumns(this.rows[b], this.sortColumn) > 0) {
              bool = true;
              CacheObject cacheObject = this.rows[b];
              this.rows[b] = this.rows[i];
              this.rows[i] = cacheObject;
            } 
          } 
        } 
      } 
      if (bool)
        fireTableDataChanged(); 
    }
    
    private void runSort(final ListSelectionModel lsm, final int selected) { (new Thread(new Runnable() {
            public void run() {
              CacheObject cacheObject = null;
              if (selected >= 0)
                cacheObject = CacheTable.CacheTableModel.this.rows[selected]; 
              CacheTable.CacheTableModel.this.sort();
              if (cacheObject != null)
                for (byte b = 0; b < CacheTable.CacheTableModel.this.rows.length; b++) {
                  if (CacheTable.CacheTableModel.this.rows[b] == cacheObject) {
                    lsm.clearSelection();
                    lsm.addSelectionInterval(b, b);
                    break;
                  } 
                }  
            }
          })).start(); }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/CacheTable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */