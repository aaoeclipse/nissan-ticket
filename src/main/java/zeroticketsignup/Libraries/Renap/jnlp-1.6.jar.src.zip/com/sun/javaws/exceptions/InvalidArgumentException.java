package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;

public class InvalidArgumentException extends JNLPException {
  private String[] _arguments;
  
  public InvalidArgumentException(String[] paramArrayOfString) {
    super(ResourceManager.getString("launch.error.category.arguments"));
    this._arguments = paramArrayOfString;
  }
  
  public String getRealMessage() {
    StringBuffer stringBuffer = new StringBuffer("{");
    for (byte b = 0; b < this._arguments.length; b++) {
      stringBuffer.append(this._arguments[b]);
      if (b < this._arguments.length - 1)
        stringBuffer.append(", "); 
    } 
    stringBuffer.append(" }");
    return ResourceManager.getString("launch.error.toomanyargs", stringBuffer.toString());
  }
  
  public String getField() { return getMessage(); }
  
  public String toString() { return "InvalidArgumentException[ " + getRealMessage() + "]"; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/InvalidArgumentException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */