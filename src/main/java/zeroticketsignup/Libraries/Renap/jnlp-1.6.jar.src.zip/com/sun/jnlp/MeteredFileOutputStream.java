package com.sun.jnlp;

import com.sun.deploy.resources.ResourceManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

final class MeteredFileOutputStream extends OutputStream {
  static String _message = null;
  
  private final FileContentsImpl _contents;
  
  private long _written = 0L;
  
  private final FileOutputStream _fis;
  
  MeteredFileOutputStream(File paramFile, boolean paramBoolean, FileContentsImpl paramFileContentsImpl) throws IOException {
    this._fis = new FileOutputStream(paramFile.getAbsolutePath(), paramBoolean);
    this._contents = paramFileContentsImpl;
    this._written = paramFile.length();
    if (_message == null)
      _message = ResourceManager.getString("api.persistence.filesizemessage"); 
  }
  
  public void write(int paramInt) throws IOException {
    checkWrite(1);
    this._fis.write(paramInt);
    this._written++;
  }
  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    checkWrite(paramInt2);
    this._fis.write(paramArrayOfbyte, paramInt1, paramInt2);
    this._written += paramInt2;
  }
  
  public void write(byte[] paramArrayOfbyte) throws IOException { write(paramArrayOfbyte, 0, paramArrayOfbyte.length); }
  
  public void close() throws IOException {
    this._fis.close();
    super.close();
  }
  
  public void flush() throws IOException {
    this._fis.flush();
    super.flush();
  }
  
  private void checkWrite(int paramInt) throws IOException {
    if (paramInt < 0 || this._contents.getMaxLength() - this._written < paramInt)
      throw new IOException(_message); 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/MeteredFileOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */