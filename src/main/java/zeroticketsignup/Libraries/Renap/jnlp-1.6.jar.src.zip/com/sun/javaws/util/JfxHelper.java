package com.sun.javaws.util;

import com.sun.deploy.config.JREInfo;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.util.VersionID;
import com.sun.deploy.util.VersionString;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.jnl.JREDesc;
import com.sun.javaws.jnl.JavaFXRuntimeDesc;
import com.sun.javaws.jnl.LaunchDesc;
import java.lang.reflect.Method;

public class JfxHelper {
  public static final VersionID JRE_MINIMUM_VER = new VersionID("1.7.0_06");
  
  public static final String[] SUPPORTTED_OS = new String[] { "Windows", "Linux", "Mac OS X" };
  
  private static VersionID currentVersion = null;
  
  private static boolean detectionCompleted = false;
  
  public static boolean isCompatibleRuntime(JREInfo paramJREInfo1, JREInfo paramJREInfo2) { return (paramJREInfo1.getFXVersion() == null && paramJREInfo2.getFXVersion() == null) ? true : (!(paramJREInfo1.getProductVersion().isGreaterThan(paramJREInfo2.getProductVersion()) || paramJREInfo1.getFXVersion().isGreaterThan(paramJREInfo2.getFXVersion()))); }
  
  public static boolean isJfxSupportSatisfied(ClassLoader paramClassLoader, LaunchDesc paramLaunchDesc) {
    JavaFXRuntimeDesc javaFXRuntimeDesc = paramLaunchDesc.getJavaFXRuntimeDescriptor();
    if (null == javaFXRuntimeDesc && !paramLaunchDesc.isFXApp())
      return true; 
    String str = (null == javaFXRuntimeDesc) ? "2.2+" : javaFXRuntimeDesc.getVersion();
    return isJfxSupportSatisfied(paramClassLoader, str);
  }
  
  public static boolean isJfxSupportSatisfied(ClassLoader paramClassLoader, String paramString) {
    if (null == paramString || paramString.length() == 0)
      paramString = "2.2+"; 
    VersionString versionString = new VersionString(paramString);
    VersionID versionID = getCurrentJfxVersion(paramClassLoader);
    return (null == versionID) ? false : versionString.contains(versionID);
  }
  
  public static VersionID getCurrentJfxVersion(ClassLoader paramClassLoader) {
    if (!detectionCompleted)
      synchronized (JfxHelper.class) {
        if (!detectionCompleted) {
          try {
            if (null == paramClassLoader)
              paramClassLoader = Thread.currentThread().getContextClassLoader(); 
            Class<?> clazz = paramClassLoader.loadClass("com.sun.javafx.runtime.VersionInfo");
            Method method = clazz.getMethod("getVersion", null);
            String str = (String)method.invoke(null, null);
            currentVersion = new VersionID(str);
          } catch (Exception exception) {
            currentVersion = null;
          } 
          if (null == currentVersion) {
            String str = System.getProperty("jnlp.fx");
            if (str != null) {
              str = str.trim();
              currentVersion = new VersionID(str);
            } 
          } 
          detectionCompleted = true;
        } 
      }  
    return currentVersion;
  }
  
  static void reset() { detectionCompleted = false; }
  
  public static boolean isSupportedJreVersion(VersionID paramVersionID) { return !JRE_MINIMUM_VER.isGreaterThan(paramVersionID); }
  
  public static boolean isSupportedOS(String paramString) {
    for (byte b = 0; b < SUPPORTTED_OS.length; b++) {
      if (SUPPORTTED_OS[b].indexOf(paramString) != -1)
        return true; 
    } 
    return false;
  }
  
  public static void validateJfxRequest(LaunchDesc paramLaunchDesc, JREInfo paramJREInfo) throws LaunchDescException {
    if (!isSupportedOS(paramJREInfo.getOSName())) {
      String str = ResourceManager.getString("launch.error.jfx.os", paramJREInfo.getOSName());
      throw new LaunchDescException(paramLaunchDesc, str, null);
    } 
    VersionID versionID = paramJREInfo.getProductVersion();
    if (!isSupportedJreVersion(versionID)) {
      String str = ResourceManager.getString("launch.error.jfx.jre", JRE_MINIMUM_VER.toString(), versionID.toString());
      throw new LaunchDescException(paramLaunchDesc, str, null);
    } 
  }
  
  public static void validateJfxRequest(LaunchDesc paramLaunchDesc, JREDesc paramJREDesc) throws LaunchDescException {
    VersionID versionID = new VersionID(paramJREDesc.getVersion());
    if (!isSupportedJreVersion(versionID) && !versionID.match(JRE_MINIMUM_VER)) {
      String str = ResourceManager.getString("launch.error.jfx.jre", JRE_MINIMUM_VER.toString(), versionID.toString());
      throw new LaunchDescException(paramLaunchDesc, str, null);
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/util/JfxHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */