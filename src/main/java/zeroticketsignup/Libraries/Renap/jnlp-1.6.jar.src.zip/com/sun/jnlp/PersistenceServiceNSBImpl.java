package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javax.jnlp.FileContents;
import javax.jnlp.PersistenceService;

public final class PersistenceServiceNSBImpl implements PersistenceService {
  private final PersistenceServiceImpl service;
  
  public PersistenceServiceNSBImpl(PersistenceServiceImpl paramPersistenceServiceImpl) { this.service = paramPersistenceServiceImpl; }
  
  public long create(URL paramURL, long paramLong) throws MalformedURLException, IOException { return Platform.get().getNativeSandboxBroker().createMuffin(paramURL.toExternalForm(), paramLong); }
  
  public FileContents get(URL paramURL) throws MalformedURLException, IOException, FileNotFoundException {
    String str = Platform.get().getNativeSandboxBroker().getMuffin(paramURL.toExternalForm());
    File file = new File(str);
    return new FileContentsImpl(file, this.service, paramURL, this.service.getMaxLength(paramURL));
  }
  
  public void delete(URL paramURL) throws MalformedURLException, IOException { Platform.get().getNativeSandboxBroker().deleteMuffin(paramURL.toExternalForm()); }
  
  public String[] getNames(URL paramURL) throws MalformedURLException, IOException { return this.service.getNames(paramURL); }
  
  public int getTag(URL paramURL) throws MalformedURLException, IOException { return this.service.getTag(paramURL); }
  
  public void setTag(URL paramURL, int paramInt) throws MalformedURLException, IOException { Platform.get().getNativeSandboxBroker().setMuffinTag(paramURL.toExternalForm(), paramInt); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/PersistenceServiceNSBImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */