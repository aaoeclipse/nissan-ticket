package com.sun.javaws;

import java.awt.Component;

public abstract class ExtensionInstallHandler {
  private static ExtensionInstallHandler _installHandler;
  
  public static synchronized ExtensionInstallHandler getInstance() {
    if (_installHandler == null)
      _installHandler = ExtensionInstallHandlerFactory.newInstance(); 
    return _installHandler;
  }
  
  public abstract boolean doPreRebootActions(Component paramComponent);
  
  public abstract boolean doReboot();
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ExtensionInstallHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */