package com.sun.javaws.jnl;

import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.cache.CacheEntry;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.DownloadEngine;
import com.sun.deploy.net.HttpRequest;
import com.sun.deploy.net.HttpResponse;
import com.sun.deploy.net.HttpUtils;
import com.sun.deploy.net.offline.DeployOfflineManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.Base64Wrapper;
import com.sun.deploy.util.SystemUtils;
import com.sun.deploy.util.URLUtil;
import com.sun.deploy.xml.XMLNode;
import com.sun.javaws.exceptions.BadFieldException;
import com.sun.javaws.exceptions.JNLParseException;
import com.sun.javaws.exceptions.MissingFieldException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.zip.GZIPInputStream;

public class LaunchDescFactory {
  private static final boolean DEBUG = false;
  
  private static final int BUFFER_SIZE = 8192;
  
  private static URL derivedCodebase = null;
  
  private static URL docbase = null;
  
  public static void setDocBase(URL paramURL) { docbase = paramURL; }
  
  public static URL getDocBase() { return docbase; }
  
  public static URL getDerivedCodebase() {
    if (docbase != null && derivedCodebase == null)
      try {
        derivedCodebase = new URL(docbase.toString().substring(0, docbase.toString().lastIndexOf("/") + 1));
      } catch (MalformedURLException malformedURLException) {
        Trace.ignoredException(malformedURLException);
      }  
    return derivedCodebase;
  }
  
  public static LaunchDesc buildDescriptor(byte[] paramArrayOfbyte, URL paramURL1, URL paramURL2, URL paramURL3) throws IOException, BadFieldException, MissingFieldException, JNLParseException { return XMLFormat.parse(paramArrayOfbyte, paramURL1, paramURL2, paramURL3); }
  
  public static LaunchDesc buildDescriptor(byte[] paramArrayOfbyte, URL paramURL1, URL paramURL2) throws IOException, BadFieldException, MissingFieldException, JNLParseException { return buildDescriptor(paramArrayOfbyte, paramURL1, paramURL2, null); }
  
  public static LaunchDesc buildDescriptor(File paramFile, URL paramURL1, URL paramURL2, URL paramURL3) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    URL uRL = (paramURL3 != null) ? paramURL3 : getOriginalURL();
    try {
      return buildDescriptor(SystemUtils.readBytes(new FileInputStream(paramFile), paramFile.length()), paramURL1, paramURL2, uRL);
    } catch (FileNotFoundException fileNotFoundException) {
      if (uRL == null)
        throw fileNotFoundException; 
      return buildDescriptor(uRL, paramURL2);
    } 
  }
  
  private static LaunchDesc buildDescriptor(File paramFile, LocalApplicationProperties paramLocalApplicationProperties, URL paramURL1, URL paramURL2) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    String str1 = paramLocalApplicationProperties.getDocumentBase();
    String str2 = paramLocalApplicationProperties.getCodebase();
    String str3 = paramLocalApplicationProperties.getOriginalURL();
    if (str2 != null)
      try {
        paramURL1 = new URL(str2);
      } catch (MalformedURLException malformedURLException) {} 
    if (str1 != null)
      try {
        paramURL2 = new URL(str1);
      } catch (MalformedURLException malformedURLException) {} 
    URL uRL = null;
    if (str3 != null)
      try {
        uRL = new URL(str3);
      } catch (MalformedURLException malformedURLException) {} 
    return buildDescriptor(paramFile, paramURL1, paramURL2, uRL);
  }
  
  public static LaunchDesc buildDescriptor(File paramFile) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(paramFile.getPath());
    if (localApplicationProperties != null)
      return buildDescriptor(paramFile, localApplicationProperties, null, null); 
    String str = getOriginalFilename();
    if (str != null) {
      File file = new File(str);
      URL uRL = null;
      try {
        String str1 = file.getAbsoluteFile().getParent();
        if (str1.startsWith(File.separator))
          str1 = str1.substring(1, str1.length()); 
        uRL = new URL("file:/" + str1 + File.separator);
      } catch (MalformedURLException malformedURLException) {
        Trace.ignoredException(malformedURLException);
      } 
      if (uRL != null) {
        URL uRL1 = new URL(uRL.toString() + file.getName());
        LaunchDesc launchDesc = buildDescriptor(paramFile, uRL, null, uRL1);
        derivedCodebase = uRL;
        return launchDesc;
      } 
    } 
    return null;
  }
  
  public static LaunchDesc buildDescriptor(URL paramURL1, URL paramURL2) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    int i = ResourceProvider.get().incrementInternalUse();
    try {
      return _buildDescriptor(paramURL1, paramURL2);
    } finally {
      ResourceProvider.get().decrementInternalUse(i);
    } 
  }
  
  private static LaunchDesc _buildDescriptor(URL paramURL1, URL paramURL2) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    File file;
    Resource resource = null;
    IOException iOException = null;
    try {
      file = ResourceProvider.get().getResource(paramURL1, null).getDataFile();
    } catch (IOException iOException1) {
      if (iOException1 instanceof java.net.UnknownHostException || iOException1 instanceof com.sun.deploy.net.FailedDownloadException || iOException1 instanceof java.net.ConnectException || iOException1 instanceof java.net.SocketException) {
        Trace.ignoredException(iOException1);
        iOException = iOException1;
        file = ResourceProvider.get().getCachedJNLPFile(paramURL1, null);
        if (file == null && DeployOfflineManager.isForcedOffline())
          throw iOException1; 
      } else {
        throw iOException1;
      } 
    } 
    URL uRL1 = URLUtil.asPathURL(URLUtil.getBase(paramURL1));
    if (file != null && file.exists()) {
      if (Environment.getImportModeCodebaseOverride() != null)
        uRL1 = new URL(Environment.getImportModeCodebaseOverride()); 
      URL uRL = DownloadEngine.getKnownRedirectFinalURL(paramURL1);
      LaunchDesc launchDesc1 = buildDescriptor(file, uRL1, paramURL2, (uRL != null) ? uRL : paramURL1);
      if (launchDesc1 == null)
        return null; 
      if (launchDesc1.getLaunchType() == 5)
        ResourceProvider.get().markRetired(resource, false); 
      if (iOException != null && !launchDesc1.getInformation().supportsOfflineOperation())
        throw iOException; 
      derivedCodebase = uRL1;
      return launchDesc1;
    } 
    HttpRequest httpRequest = DownloadEngine.getHttpRequestImpl();
    HttpResponse httpResponse = httpRequest.doGetRequest(paramURL1);
    Object object = httpResponse.getInputStream();
    int i = httpResponse.getContentLength();
    String str = httpResponse.getContentEncoding();
    if (str != null && str.indexOf("gzip") >= 0)
      object = new GZIPInputStream((InputStream)object, 8192); 
    URL uRL2 = HttpUtils.getFinalRedirectedURL(httpResponse);
    LaunchDesc launchDesc = buildDescriptor(SystemUtils.readBytes((InputStream)object, i), uRL1, paramURL2, (uRL2 != null) ? uRL2 : paramURL1);
    object.close();
    return launchDesc;
  }
  
  private static LaunchDesc buildDescriptorFromCache(URL paramURL1, URL paramURL2) throws BadFieldException, MissingFieldException, JNLParseException {
    try {
      File file = ResourceProvider.get().getCachedJNLPFile(paramURL1, null);
      if (file != null) {
        URL uRL = URLUtil.asPathURL(URLUtil.getBase(paramURL1));
        return buildDescriptor(file, uRL, paramURL2, paramURL1);
      } 
    } catch (IOException iOException) {}
    return null;
  }
  
  public static LaunchDesc buildDescriptorFromCache(String paramString, URL paramURL1, URL paramURL2) throws BadFieldException, MissingFieldException, JNLParseException {
    LaunchDesc launchDesc = null;
    try {
      File file = new File(paramString);
      if (file.isFile())
        launchDesc = buildDescriptor(file, paramURL1, paramURL2, getOriginalURL()); 
      if (launchDesc != null)
        return launchDesc; 
    } catch (Exception exception) {}
    try {
      URL uRL = new URL(paramString);
      if (paramString.endsWith(".jarjnlp")) {
        launchDesc = buildNoHrefDescriptorFromCache(uRL, paramURL1, paramURL2);
      } else {
        launchDesc = buildDescriptorFromCache(uRL, paramURL2);
      } 
      if (launchDesc != null)
        return launchDesc; 
    } catch (Exception exception) {}
    if (paramURL1 != null)
      try {
        URL uRL = new URL(paramURL1, paramString);
        launchDesc = buildDescriptorFromCache(uRL, paramURL2);
        if (launchDesc != null)
          return launchDesc; 
      } catch (Exception exception) {} 
    if (paramURL1 == null && paramURL2 != null)
      try {
        URL uRL = new URL(URLUtil.getBase(paramURL2), paramString);
        launchDesc = buildDescriptorFromCache(uRL, paramURL2);
        if (launchDesc != null)
          return launchDesc; 
      } catch (Exception exception) {} 
    return null;
  }
  
  private static LaunchDesc buildNoHrefDescriptorFromCache(URL paramURL1, URL paramURL2, URL paramURL3) throws BadFieldException, MissingFieldException, JNLParseException {
    try {
      if (paramURL2 == null)
        paramURL2 = URLUtil.asPathURL(URLUtil.getBase(paramURL1)); 
      CacheEntry cacheEntry = (CacheEntry)ResourceProvider.get().getCachedResource(paramURL1, null);
      if (cacheEntry == null)
        return null; 
      LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(cacheEntry);
      return (localApplicationProperties != null) ? buildDescriptor(cacheEntry.getDataFile(), localApplicationProperties, paramURL2, paramURL3) : buildDescriptor(cacheEntry.getDataFile(), paramURL2, paramURL3, paramURL1);
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  public static LaunchDesc buildDescriptor(String paramString, URL paramURL1, URL paramURL2, boolean paramBoolean) throws BadFieldException, MissingFieldException, JNLParseException {
    URL uRL = null;
    try {
      uRL = new URL(paramString);
    } catch (MalformedURLException malformedURLException) {}
    if (uRL != null)
      try {
        LaunchDesc launchDesc = buildDescriptor(uRL, paramURL2);
        if (paramBoolean)
          Trace.println("   JNLP Ref (absolute): " + uRL); 
        return launchDesc;
      } catch (BadFieldException badFieldException) {
        throw badFieldException;
      } catch (MissingFieldException missingFieldException) {
        throw missingFieldException;
      } catch (JNLParseException jNLParseException) {
        throw jNLParseException;
      } catch (Exception exception) {
        if (paramBoolean)
          Trace.ignored(exception); 
      }  
    if (paramURL1 != null) {
      try {
        uRL = new URL(paramURL1, paramString);
      } catch (MalformedURLException malformedURLException) {
        uRL = null;
      } 
      if (uRL != null)
        try {
          LaunchDesc launchDesc = buildDescriptor(uRL, paramURL2);
          if (paramBoolean)
            Trace.println(" JNLP Ref (codebase + ref): " + uRL); 
          return launchDesc;
        } catch (BadFieldException badFieldException) {
          throw badFieldException;
        } catch (MissingFieldException missingFieldException) {
          throw missingFieldException;
        } catch (JNLParseException jNLParseException) {
          throw jNLParseException;
        } catch (Exception exception) {
          if (paramBoolean)
            Trace.ignored(exception); 
        }  
    } 
    if (paramURL1 == null && paramURL2 != null) {
      try {
        uRL = new URL(URLUtil.getBase(paramURL2), paramString);
      } catch (MalformedURLException malformedURLException) {
        uRL = null;
      } 
      if (uRL != null)
        try {
          LaunchDesc launchDesc = buildDescriptor(uRL, paramURL2);
          if (paramBoolean)
            Trace.println("   JNLP Ref (documentbase + ref): " + uRL); 
          return launchDesc;
        } catch (BadFieldException badFieldException) {
          throw badFieldException;
        } catch (MissingFieldException missingFieldException) {
          throw missingFieldException;
        } catch (JNLParseException jNLParseException) {
          throw jNLParseException;
        } catch (Exception exception) {
          if (paramBoolean)
            Trace.ignored(exception); 
        }  
    } 
    if (paramBoolean)
      Trace.println("   JNLP Ref (...): NULL !"); 
    return null;
  }
  
  public static LaunchDesc buildDescriptor(String paramString) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    try {
      String str = filterUrlFile(paramString);
      int i = str.indexOf(",");
      if (str.startsWith("data:") && i > 0 && i < str.length() - 1) {
        Trace.println("Embedded data: URI:" + paramString, TraceLevel.BASIC);
        return buildDescriptor(Base64Wrapper.decodeFromString(str.substring(i)), null, null);
      } 
      URL uRL = new URL(str);
      try {
        LaunchDesc launchDesc = buildDescriptorFromCache(uRL, null);
        if (launchDesc != null) {
          if (launchDesc.getLocation() != null)
            return launchDesc; 
          Resource resource = ResourceProvider.get().getCachedResource(uRL, null);
          if (resource != null)
            ResourceProvider.get().markRetired(resource, true); 
        } 
      } catch (Exception exception) {}
      return buildDescriptor(uRL, null);
    } catch (MalformedURLException malformedURLException) {
      File file = new File(paramString);
      try {
        FileInputStream fileInputStream = new FileInputStream(paramString);
        long l = file.length();
        if (l > 1048576L)
          throw new IOException("File too large"); 
        if (Environment.isImportMode()) {
          String str = file.getParent();
          if (Environment.getImportModeCodebaseOverride() == null && str != null)
            try {
              URL uRL = new URL("file", null, URLUtil.encodePath(str));
              Environment.setImportModeCodebaseOverride(uRL.toString());
            } catch (MalformedURLException malformedURLException1) {
              Trace.ignoredException(malformedURLException1);
            }  
        } 
        return buildDescriptor(SystemUtils.readBytes(fileInputStream, (int)l), null, null, file.toURI().toURL());
      } catch (FileNotFoundException fileNotFoundException) {
        URL uRL = getOriginalURL();
        if (uRL == null)
          throw fileNotFoundException; 
        return buildDescriptor(uRL, null);
      } 
    } 
  }
  
  public static String filterUrlFile(String paramString) { return paramString.startsWith("jnlps://") ? paramString.replaceFirst("jnlps", "https") : (paramString.startsWith("jnlp://") ? paramString.replaceFirst("jnlp", "http") : (paramString.startsWith("jnlp:") ? paramString.substring("jnlp:".length()) : paramString)); }
  
  private static String getOriginalFilename() {
    String str = System.getProperty("jnlpx.origFilenameArg");
    return (str != null) ? filterUrlFile(str) : null;
  }
  
  private static URL getOriginalURL() {
    String str = getOriginalFilename();
    if (str != null)
      try {
        return new URL(str);
      } catch (MalformedURLException malformedURLException) {} 
    return null;
  }
  
  public static LaunchDesc buildInternalLaunchDesc(XMLNode paramXMLNode, String paramString) { return new LaunchDesc("0.1", null, null, null, null, 1, null, null, null, 5, null, null, null, null, null, (paramString == null) ? paramXMLNode.getName() : paramString, paramXMLNode, null); }
  
  public static LaunchDesc tryUpdateDescriptor(LaunchDesc paramLaunchDesc) {
    URL uRL = paramLaunchDesc.getSourceURL();
    try {
      if (uRL != null)
        return buildDescriptor(uRL, null); 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
    return paramLaunchDesc;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/LaunchDescFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */