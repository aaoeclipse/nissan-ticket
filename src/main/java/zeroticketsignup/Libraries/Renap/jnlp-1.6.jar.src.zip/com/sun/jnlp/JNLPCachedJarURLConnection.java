package com.sun.jnlp;

import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceObject;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.BasicHttpRequest;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.net.protocol.jar.Handler;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.Attributes;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import sun.net.www.protocol.jar.Handler;
import sun.net.www.protocol.jar.JarURLConnection;

public class JNLPCachedJarURLConnection extends JarURLConnection {
  private URL _jarFileURL = null;
  
  private String _entryName;
  
  private JarEntry _jarEntry;
  
  private JarFile _jarFile;
  
  private String _contentType;
  
  private boolean _useCachedJar = false;
  
  private Map headerFields = null;
  
  public JNLPCachedJarURLConnection(URL paramURL, Handler paramHandler) throws MalformedURLException, IOException {
    super(paramURL, (Handler)paramHandler);
    getJarFileURL();
    this._entryName = getEntryName();
  }
  
  public String getHeaderField(String paramString) {
    if (paramString == null)
      return null; 
    try {
      connect();
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
    } 
    if (this.headerFields != null && BasicHttpRequest.isHeaderFieldCached(paramString)) {
      List<String> list = (List)this.headerFields.get(paramString.toLowerCase());
      return (list != null) ? list.get(0) : null;
    } 
    return super.getHeaderField(paramString);
  }
  
  public synchronized URL getJarFileURL() {
    if (this._jarFile instanceof ResourceObject) {
      URL uRL = ((ResourceObject)this._jarFile).getResourceURL();
      if (uRL != null)
        return uRL; 
    } 
    return getJarFileURLInternal();
  }
  
  private URL getJarFileURLInternal() {
    if (this._jarFileURL == null)
      this._jarFileURL = super.getJarFileURL(); 
    return this._jarFileURL;
  }
  
  public JarFile getJarFile() throws IOException {
    connect();
    if (ResourceProvider.get().isInternalUse())
      return this._jarFile; 
    try {
      return AccessController.doPrivileged(new PrivilegedExceptionAction<JarFile>() {
            public Object run() throws Exception {
              if (JNLPCachedJarURLConnection.this._jarFile instanceof ResourceObject)
                return ((ResourceObject)JNLPCachedJarURLConnection.this._jarFile).clone(); 
              String str = JNLPCachedJarURLConnection.this._jarFile.getName();
              if ((new File(str)).exists()) {
                JarFile jarFile = new JarFile(str);
                Manifest manifest = jarFile.getManifest();
                if (manifest != null)
                  manifest.getMainAttributes().remove(Attributes.Name.CLASS_PATH); 
                return jarFile;
              } 
              return JNLPCachedJarURLConnection.this._jarFile;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw new IOException(privilegedActionException.getCause().getMessage());
    } 
  }
  
  private JarFile getJarFileInternal() throws IOException {
    connect();
    return this._jarFile;
  }
  
  public JarEntry getJarEntry() throws IOException {
    connect();
    return this._jarEntry;
  }
  
  public void connect() throws IOException {
    if (!this.connected) {
      this._jarFile = JNLPClassLoaderUtil.getInstance().getJarFile(this._jarFileURL);
      if (this._jarFile != null) {
        this._useCachedJar = true;
      } else {
        super.connect();
        this._jarFile = super.getJarFile();
      } 
      JARDesc jARDesc = JNLPClassLoaderUtil.getInstance().getJarDescFromURL(this._jarFileURL);
      if (jARDesc != null) {
        Resource resource = ResourceProvider.get().getCachedResource(jARDesc.getLocation(), jARDesc.getVersion());
        Map map = (resource != null) ? resource.getHeaders() : null;
        if (map != null) {
          this.headerFields = new HashMap<Object, Object>();
          this.headerFields = map;
        } 
      } 
      if (this._entryName != null) {
        this._jarEntry = this._jarFile.getJarEntry(this._entryName);
        if (this._jarEntry == null)
          throw new FileNotFoundException("JAR entry " + this._entryName + " not found in " + this._jarFile.getName()); 
      } 
      this.connected = true;
    } 
  }
  
  public InputStream getInputStream() throws IOException {
    connect();
    if (this._useCachedJar) {
      Object object = null;
      if (this._entryName == null)
        throw new IOException("no entry name specified"); 
      if (this._jarEntry == null)
        throw new FileNotFoundException("JAR entry " + this._entryName + " not found in " + this._jarFile.getName()); 
      return this._jarFile.getInputStream(this._jarEntry);
    } 
    return super.getInputStream();
  }
  
  public Object getContent() throws IOException {
    connect();
    return (this._useCachedJar && this._entryName == null) ? getJarFile() : super.getContent();
  }
  
  public String getContentType() {
    try {
      connect();
    } catch (IOException iOException) {}
    if (this._useCachedJar) {
      if (this._contentType == null) {
        if (this._entryName == null) {
          this._contentType = "x-java/jar";
        } else {
          try {
            connect();
            InputStream inputStream = getJarFileInternal().getInputStream(this._jarEntry);
            this._contentType = guessContentTypeFromStream(new BufferedInputStream(inputStream));
            inputStream.close();
          } catch (IOException iOException) {}
        } 
        if (this._contentType == null)
          this._contentType = guessContentTypeFromName(this._entryName); 
        if (this._contentType == null)
          this._contentType = "content/unknown"; 
      } 
    } else {
      this._contentType = super.getContentType();
    } 
    return this._contentType;
  }
  
  public int getContentLength() {
    try {
      connect();
    } catch (IOException iOException) {
      return super.getContentLength();
    } 
    return this._useCachedJar ? ((this._jarEntry != null) ? (int)this._jarEntry.getSize() : -1) : super.getContentLength();
  }
  
  public URL getURL() {
    URL uRL = getJarFileURL();
    if (uRL != null)
      try {
        return URLUtil.getJarEntryURL(uRL, this._entryName);
      } catch (MalformedURLException malformedURLException) {} 
    return super.getURL();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/JNLPCachedJarURLConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */