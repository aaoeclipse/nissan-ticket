package com.sun.javaws.security;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.CodeSigner;
import java.security.cert.Certificate;
import java.util.jar.Manifest;

public abstract class Resource {
  public abstract String getName();
  
  public abstract URL getURL();
  
  public abstract URL getCodeSourceURL();
  
  public abstract InputStream getInputStream() throws IOException;
  
  public abstract int getContentLength() throws IOException;
  
  public byte[] getBytes() throws IOException {
    byte[] arrayOfByte;
    InputStream inputStream = getInputStream();
    int i = getContentLength();
    try {
      if (i != -1) {
        arrayOfByte = new byte[i];
        while (i > 0) {
          int j = inputStream.read(arrayOfByte, arrayOfByte.length - i, i);
          if (j == -1)
            throw new IOException("unexpected EOF"); 
          i -= j;
        } 
      } else {
        arrayOfByte = new byte[1024];
        int j = 0;
        while ((i = inputStream.read(arrayOfByte, j, arrayOfByte.length - j)) != -1) {
          j += i;
          if (j >= arrayOfByte.length) {
            byte[] arrayOfByte1 = new byte[j * 2];
            System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, j);
            arrayOfByte = arrayOfByte1;
          } 
        } 
        if (j != arrayOfByte.length) {
          byte[] arrayOfByte1 = new byte[j];
          System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, j);
          arrayOfByte = arrayOfByte1;
        } 
      } 
    } finally {
      inputStream.close();
    } 
    return arrayOfByte;
  }
  
  public Manifest getManifest() throws IOException { return null; }
  
  public Certificate[] getCertificates() { return null; }
  
  public CodeSigner[] getCodeSigners() { return null; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/security/Resource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */