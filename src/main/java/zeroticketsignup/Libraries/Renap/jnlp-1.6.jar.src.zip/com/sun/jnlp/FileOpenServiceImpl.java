package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import com.sun.deploy.util.Waiter;
import com.sun.javaws.util.JNLPUtils;
import java.io.File;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.FileContents;
import javax.jnlp.FileOpenService;

public final class FileOpenServiceImpl implements FileOpenService {
  static FileOpenService _sharedInstance = null;
  
  static FileSaveServiceImpl _fileSaveServiceImpl;
  
  private final ApiDialog _apiDialog;
  
  private FileOpenServiceImpl(FileSaveServiceImpl paramFileSaveServiceImpl) {
    _fileSaveServiceImpl = paramFileSaveServiceImpl;
    this._apiDialog = new ApiDialog();
  }
  
  public static synchronized FileOpenService getInstance() {
    if (_sharedInstance == null)
      if (Platform.get().isNativeSandbox()) {
        _sharedInstance = new FileOpenServiceNSBImpl(new FileOpenServiceImpl(new FileSaveServiceImpl()));
      } else {
        _sharedInstance = new FileOpenServiceImpl((FileSaveServiceImpl)FileSaveServiceImpl.getInstance());
      }  
    return _sharedInstance;
  }
  
  public FileContents openFileDialog(final String pathHint, final String[] extensions) throws IOException {
    if (!askUser())
      return null; 
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception { return DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = pathHint;
                  if (str == null)
                    str = FileOpenServiceImpl._fileSaveServiceImpl.getLastPath(); 
                  File[] arrayOfFile = ToolkitStore.getUI().showFileChooser(str, extensions, 8, false, null);
                  if (arrayOfFile[0] != null)
                    try {
                      FileOpenServiceImpl._fileSaveServiceImpl.setLastPath(arrayOfFile[0].getPath());
                      return new FileContentsImpl(arrayOfFile[0], FileSaveServiceImpl.computeMaxLength(arrayOfFile[0].length()));
                    } catch (IOException iOException) {} 
                  return null;
                }
              }null); }
      };
    try {
      return (FileContents)Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
  
  String openFileDialogNSB(final String pathHint, final String[] extensions) throws IOException {
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception { return DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = pathHint;
                  if (str == null)
                    str = FileOpenServiceImpl._fileSaveServiceImpl.getLastPath(); 
                  File[] arrayOfFile = ToolkitStore.getUI().showFileChooser(str, extensions, 8, false, null);
                  if (arrayOfFile[0] != null) {
                    FileOpenServiceImpl._fileSaveServiceImpl.setLastPath(arrayOfFile[0].getPath());
                    return arrayOfFile[0].getAbsolutePath();
                  } 
                  return null;
                }
              }null); }
      };
    try {
      return (String)Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
  
  public FileContents[] openMultiFileDialog(final String pathHint, final String[] extensions) throws IOException {
    if (!askUser())
      return null; 
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception { return DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = pathHint;
                  if (str == null)
                    str = FileOpenServiceImpl._fileSaveServiceImpl.getLastPath(); 
                  File[] arrayOfFile = ToolkitStore.getUI().showFileChooser(str, extensions, 8, true, null);
                  if (arrayOfFile != null && arrayOfFile.length > 0) {
                    FileContents[] arrayOfFileContents = new FileContents[arrayOfFile.length];
                    for (byte b = 0; b < arrayOfFile.length; b++) {
                      try {
                        arrayOfFileContents[b] = new FileContentsImpl(arrayOfFile[b], FileSaveServiceImpl.computeMaxLength(arrayOfFile[b].length()));
                        FileOpenServiceImpl._fileSaveServiceImpl.setLastPath(arrayOfFile[b].getPath());
                      } catch (IOException iOException) {}
                    } 
                    return arrayOfFileContents;
                  } 
                  return null;
                }
              }null); }
      };
    try {
      return (FileContents[])Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
  
  String[] openMultiFileDialogNSB(final String pathHint, final String[] extentions) throws IOException {
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception { return DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = pathHint;
                  if (str == null)
                    str = FileOpenServiceImpl._fileSaveServiceImpl.getLastPath(); 
                  File[] arrayOfFile = ToolkitStore.getUI().showFileChooser(str, extentions, 8, true, null);
                  if (arrayOfFile != null && arrayOfFile.length > 0) {
                    String[] arrayOfString = new String[arrayOfFile.length];
                    for (byte b = 0; b < arrayOfFile.length; b++) {
                      arrayOfString[b] = arrayOfFile[b].getAbsolutePath();
                      FileOpenServiceImpl._fileSaveServiceImpl.setLastPath(arrayOfFile[b].getPath());
                    } 
                    return arrayOfString;
                  } 
                  return null;
                }
              }null); }
      };
    try {
      return (String[])Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return null;
    } 
  }
  
  synchronized boolean askUser() {
    if (CheckServicePermission.hasFileAccessPermissions())
      return true; 
    final LocalApplicationProperties lap = JNLPUtils.getLocalApplicationProperties();
    if (localApplicationProperties != null) {
      String str = localApplicationProperties.get("jnlp.api.always.FileOpenService.open");
      if (str != null)
        return true; 
    } 
    ApiDialog.DialogResult dialogResult = this._apiDialog.askUser(ResourceManager.getString("api.file.open.title"), ResourceManager.getString("api.file.open.message"), ResourceManager.getString("api.file.open.always"));
    if (dialogResult == ApiDialog.DialogResult.ALWAYS)
      AccessController.doPrivileged(new PrivilegedAction<Void>() {
            public Void run() {
              lap.put("jnlp.api.always.FileOpenService.open", "skip");
              try {
                lap.store();
              } catch (Throwable throwable) {
                Trace.ignored(throwable);
              } 
              return null;
            }
          }); 
    return (dialogResult == ApiDialog.DialogResult.OK || dialogResult == ApiDialog.DialogResult.ALWAYS);
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/FileOpenServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */