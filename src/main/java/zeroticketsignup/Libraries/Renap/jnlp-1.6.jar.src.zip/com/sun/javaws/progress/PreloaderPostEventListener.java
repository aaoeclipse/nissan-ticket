package com.sun.javaws.progress;

import com.sun.applet2.preloader.event.PreloaderEvent;

public interface PreloaderPostEventListener {
  void eventHandled(PreloaderEvent paramPreloaderEvent);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/progress/PreloaderPostEventListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */