package com.sun.jnlp;

import com.sun.applet2.preloader.Preloader;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LaunchDesc;
import java.io.IOException;
import java.net.URL;
import java.util.jar.JarFile;
import javax.jnlp.BasicService;
import javax.jnlp.ClipboardService;
import javax.jnlp.DownloadService;
import javax.jnlp.DownloadService2;
import javax.jnlp.ExtendedService;
import javax.jnlp.ExtensionInstallerService;
import javax.jnlp.FileOpenService;
import javax.jnlp.FileSaveService;
import javax.jnlp.IntegrationService;
import javax.jnlp.PersistenceService;
import javax.jnlp.PrintService;
import javax.jnlp.SingleInstanceService;

public interface JNLPClassLoaderIf {
  URL getResource(String paramString);
  
  URL findResource(String paramString);
  
  LaunchDesc getLaunchDesc();
  
  JARDesc getJarDescFromURL(URL paramURL);
  
  int getDefaultSecurityModel();
  
  JarFile getJarFile(URL paramURL) throws IOException;
  
  void addResource(URL paramURL, String paramString1, String paramString2);
  
  DeploymentRuleSet getDeploymentRuleSet(URL paramURL);
  
  BasicService getBasicService();
  
  FileOpenService getFileOpenService();
  
  FileSaveService getFileSaveService();
  
  ExtensionInstallerService getExtensionInstallerService();
  
  DownloadService getDownloadService();
  
  ClipboardService getClipboardService();
  
  PrintService getPrintService();
  
  PersistenceService getPersistenceService();
  
  ExtendedService getExtendedService();
  
  SingleInstanceService getSingleInstanceService();
  
  IntegrationService getIntegrationService();
  
  DownloadService2 getDownloadService2();
  
  Preloader getPreloader();
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/JNLPClassLoaderIf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */