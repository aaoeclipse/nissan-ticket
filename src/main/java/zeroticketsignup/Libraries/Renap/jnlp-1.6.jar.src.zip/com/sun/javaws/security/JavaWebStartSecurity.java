package com.sun.javaws.security;

import com.sun.deploy.config.Config;
import com.sun.deploy.net.CrossDomainXML;
import com.sun.javaws.Main;
import com.sun.jnlp.ApiDialog;
import com.sun.jnlp.JNLPClassLoaderIf;
import com.sun.jnlp.PrintServiceImpl;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.Permission;
import java.security.PrivilegedAction;
import java.security.ProtectionDomain;

public class JavaWebStartSecurity extends SecurityManager {
  static final Field facc;
  
  static final Field fcontext;
  
  private ApiDialog _connect;
  
  private ApiDialog _accept;
  
  private JNLPClassLoaderIf currentJNLPClassLoader() {
    Class[] arrayOfClass = getClassContext();
    byte b;
    for (b = 0; b < arrayOfClass.length; b++) {
      final ClassLoader currentLoader = arrayOfClass[b].getClassLoader();
      if (classLoader1 instanceof JNLPClassLoaderIf)
        return (JNLPClassLoaderIf)classLoader1; 
    } 
    ClassLoader classLoader;
    for (classLoader = Thread.currentThread().getContextClassLoader(); classLoader != null; classLoader = classLoader.getParent()) {
      if (classLoader instanceof JNLPClassLoaderIf)
        return (JNLPClassLoaderIf)classLoader; 
    } 
    for (b = 0; b < arrayOfClass.length; b++) {
      final ClassLoader currentLoader = arrayOfClass[b].getClassLoader();
      if (classLoader1 instanceof URLClassLoader) {
        classLoader = AccessController.doPrivileged(new PrivilegedAction<ClassLoader>() {
              public Object run() {
                AccessControlContext accessControlContext = null;
                ProtectionDomain[] arrayOfProtectionDomain = null;
                try {
                  accessControlContext = (AccessControlContext)JavaWebStartSecurity.facc.get(currentLoader);
                  if (accessControlContext == null)
                    return null; 
                  arrayOfProtectionDomain = (ProtectionDomain[])JavaWebStartSecurity.fcontext.get(accessControlContext);
                  if (arrayOfProtectionDomain == null)
                    return null; 
                } catch (Exception exception) {
                  throw new UnsupportedOperationException(exception);
                } 
                for (byte b = 0; b < arrayOfProtectionDomain.length; b++) {
                  ClassLoader classLoader = arrayOfProtectionDomain[b].getClassLoader();
                  if (classLoader instanceof com.sun.jnlp.JNLPClassLoader)
                    return classLoader; 
                } 
                return null;
              }
            });
        if (classLoader != null)
          return (JNLPClassLoaderIf)classLoader; 
      } 
    } 
    return (JNLPClassLoaderIf)null;
  }
  
  public Class[] getExecutionStackContext() { return getClassContext(); }
  
  public void checkPrintJobAccess() {
    try {
      super.checkPrintJobAccess();
    } catch (SecurityException securityException) {
      if (PrintServiceImpl.requestPrintPermission())
        return; 
      throw securityException;
    } 
  }
  
  public void checkConnect(String paramString, int paramInt) { checkConnectHelper(paramString, paramInt, null, false, getClassContext()); }
  
  public void checkConnect(String paramString, int paramInt, Object paramObject) { checkConnectHelper(paramString, paramInt, paramObject, true, getClassContext()); }
  
  private void checkConnectHelper(String paramString, int paramInt, Object paramObject, boolean paramBoolean, Class[] paramArrayOfClass) {
    URL uRL = null;
    boolean bool = (paramInt < 0) ? paramInt : true;
    if (bool == -2 || bool == -3)
      try {
        uRL = new URL(paramString);
        paramString = uRL.getHost();
        paramInt = uRL.getPort();
        if (paramInt == -1)
          paramInt = uRL.getDefaultPort(); 
      } catch (MalformedURLException malformedURLException) {} 
    if (CrossDomainXML.quickCheck(paramArrayOfClass, paramString, paramInt))
      return; 
    try {
      if (paramBoolean) {
        super.checkConnect(paramString, paramInt, paramObject);
      } else {
        super.checkConnect(paramString, paramInt);
      } 
    } catch (SecurityException securityException) {
      if (CrossDomainXML.check(paramArrayOfClass, uRL, paramString, paramInt, (bool == -2)))
        return; 
      if (this._connect == null)
        this._connect = new ApiDialog(); 
      if (this._connect.askConnect(paramString))
        return; 
      throw securityException;
    } 
  }
  
  public void checkPermission(Permission paramPermission) {
    if (Config.isJavaVersionAtLeast18() && paramPermission instanceof java.net.URLPermission) {
      checkURLPermissionHelper(paramPermission, null, false, getClassContext());
      return;
    } 
    super.checkPermission(paramPermission);
  }
  
  public void checkPermission(Permission paramPermission, Object paramObject) {
    if (Config.isJavaVersionAtLeast18() && paramPermission instanceof java.net.URLPermission) {
      checkURLPermissionHelper(paramPermission, paramObject, true, getClassContext());
      return;
    } 
    super.checkPermission(paramPermission, paramObject);
  }
  
  private void checkURLPermissionHelper(Permission paramPermission, Object paramObject, boolean paramBoolean, Class[] paramArrayOfClass) {
    URL uRL = null;
    String str = null;
    int i = -1;
    try {
      uRL = new URL(paramPermission.getName());
      str = uRL.getHost();
      i = uRL.getPort();
      if (i == -1)
        i = uRL.getDefaultPort(); 
    } catch (MalformedURLException malformedURLException) {}
    if (uRL == null || str == null || i < 0) {
      if (paramBoolean) {
        super.checkPermission(paramPermission, paramObject);
      } else {
        super.checkPermission(paramPermission);
      } 
      return;
    } 
    if (CrossDomainXML.quickCheck(paramArrayOfClass, str, i))
      return; 
    try {
      if (paramBoolean) {
        super.checkPermission(paramPermission, paramObject);
      } else {
        super.checkPermission(paramPermission);
      } 
    } catch (SecurityException securityException) {
      if (CrossDomainXML.check(paramArrayOfClass, uRL, str, i, false))
        return; 
      if (this._connect == null)
        this._connect = new ApiDialog(); 
      if (this._connect.askConnect(str))
        return; 
      throw securityException;
    } 
  }
  
  public void checkAccept(String paramString, int paramInt) {
    try {
      super.checkAccept(paramString, paramInt);
    } catch (SecurityException securityException) {
      if (this._accept == null)
        this._accept = new ApiDialog(); 
      if (this._accept.askAccept(paramString))
        return; 
      throw securityException;
    } 
  }
  
  public ThreadGroup getThreadGroup() {
    JNLPClassLoaderIf jNLPClassLoaderIf = currentJNLPClassLoader();
    return (jNLPClassLoaderIf != null) ? Main.getLaunchThreadGroup() : null;
  }
  
  static  {
    try {
      facc = URLClassLoader.class.getDeclaredField("acc");
      facc.setAccessible(true);
      fcontext = AccessControlContext.class.getDeclaredField("context");
      fcontext.setAccessible(true);
    } catch (NoSuchFieldException noSuchFieldException) {
      throw new UnsupportedOperationException(noSuchFieldException);
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/security/JavaWebStartSecurity.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */