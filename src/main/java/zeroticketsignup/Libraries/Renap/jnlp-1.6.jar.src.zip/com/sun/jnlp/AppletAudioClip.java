package com.sun.jnlp;

import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import java.applet.AudioClip;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.security.AccessController;
import java.security.Permission;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Map;

final class AppletAudioClip implements AudioClip {
  private static Constructor acConstructor = null;
  
  private URL url = null;
  
  private AudioClip audioClip = null;
  
  private static Map audioClips = new HashMap<Object, Object>();
  
  public AppletAudioClip() {}
  
  public AppletAudioClip(URL paramURL) {
    this.url = paramURL;
    try {
      InputStream inputStream = paramURL.openStream();
      createAppletAudioClip(inputStream);
    } catch (IOException iOException) {
      Trace.println("IOException creating AppletAudioClip" + iOException, TraceLevel.BASIC);
    } 
  }
  
  public static synchronized AudioClip get(URL paramURL) {
    checkConnect(paramURL);
    AudioClip audioClip1 = (AudioClip)audioClips.get(paramURL);
    if (audioClip1 == null) {
      audioClip1 = new AppletAudioClip(paramURL);
      audioClips.put(paramURL, audioClip1);
    } 
    return audioClip1;
  }
  
  void createAppletAudioClip(InputStream paramInputStream) throws IOException {
    if (acConstructor == null) {
      Trace.println("Initializing AudioClip constructor.", TraceLevel.BASIC);
      try {
        acConstructor = AccessController.doPrivileged(new PrivilegedExceptionAction<Constructor>() {
              public Object run() throws NoSuchMethodException, SecurityException, ClassNotFoundException {
                Class<?> clazz = null;
                try {
                  clazz = Class.forName("com.sun.media.sound.JavaSoundAudioClip", true, ClassLoader.getSystemClassLoader());
                  Trace.println("Loaded JavaSoundAudioClip", TraceLevel.BASIC);
                } catch (ClassNotFoundException classNotFoundException) {
                  clazz = Class.forName("sun.audio.SunAudioClip", true, null);
                  Trace.println("Loaded SunAudioClip", TraceLevel.BASIC);
                } 
                Class[] arrayOfClass = new Class[1];
                arrayOfClass[0] = Class.forName("java.io.InputStream");
                return clazz.getConstructor(arrayOfClass);
              }
            });
      } catch (PrivilegedActionException privilegedActionException) {
        Trace.println("Got a PrivilegedActionException: " + privilegedActionException.getException(), TraceLevel.BASIC);
        throw new IOException("Failed to get AudioClip constructor: " + privilegedActionException.getException());
      } 
    } 
    try {
      Object[] arrayOfObject = { paramInputStream };
      this.audioClip = acConstructor.newInstance(arrayOfObject);
    } catch (Exception exception) {
      throw new IOException("Failed to construct the AudioClip: " + exception);
    } 
  }
  
  private static void checkConnect(URL paramURL) {
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null)
      try {
        Permission permission = paramURL.openConnection().getPermission();
        if (permission != null) {
          securityManager.checkPermission(permission);
        } else {
          securityManager.checkConnect(paramURL.getHost(), paramURL.getPort());
        } 
      } catch (IOException iOException) {
        securityManager.checkConnect(paramURL.getHost(), paramURL.getPort());
      }  
  }
  
  public synchronized void play() {
    if (this.audioClip != null)
      this.audioClip.play(); 
  }
  
  public synchronized void loop() {
    if (this.audioClip != null)
      this.audioClip.loop(); 
  }
  
  public synchronized void stop() {
    if (this.audioClip != null)
      this.audioClip.stop(); 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/AppletAudioClip.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */