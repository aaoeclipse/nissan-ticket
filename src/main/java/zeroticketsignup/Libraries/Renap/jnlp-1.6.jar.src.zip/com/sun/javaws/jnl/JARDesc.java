package com.sun.javaws.jnl;

import com.sun.deploy.config.Config;
import com.sun.deploy.ref.CodeRef;
import com.sun.deploy.util.URLUtil;
import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import java.net.URL;

public class JARDesc implements ResourceType {
  private URL _location;
  
  private String _locationString;
  
  private String _version;
  
  private int _size;
  
  private boolean _isNativeLib;
  
  private boolean _isLazyDownload;
  
  private boolean _isProgressDownload;
  
  private boolean _isMainFile;
  
  private String _part;
  
  private ResourcesDesc _parent;
  
  private JARUpdater _updater = null;
  
  private boolean _pack200Enabled = false;
  
  private boolean _versionEnabled = false;
  
  public JARDesc(URL paramURL, String paramString1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString2, int paramInt, ResourcesDesc paramResourcesDesc) { this(paramURL, paramString1, paramBoolean1, paramBoolean2, paramBoolean3, paramString2, paramInt, paramResourcesDesc, false); }
  
  public JARDesc(URL paramURL, String paramString1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString2, int paramInt, ResourcesDesc paramResourcesDesc, boolean paramBoolean4) {
    this._location = paramURL;
    this._locationString = URLUtil.toNormalizedString(paramURL);
    this._version = paramString1;
    this._isMainFile = paramBoolean2;
    this._isLazyDownload = (paramBoolean1 && !this._isMainFile);
    this._isNativeLib = paramBoolean3;
    this._part = paramString2;
    this._size = paramInt;
    this._parent = paramResourcesDesc;
    this._isProgressDownload = paramBoolean4;
  }
  
  public void setPack200Enabled() { this._pack200Enabled = true; }
  
  public void setVersionEnabled() { this._versionEnabled = true; }
  
  public boolean isPack200Enabled() { return Config.isJavaVersionAtLeast15() ? this._pack200Enabled : false; }
  
  public boolean isVersionEnabled() { return this._versionEnabled; }
  
  public boolean isNativeLib() { return this._isNativeLib; }
  
  public boolean isJavaFile() { return !this._isNativeLib; }
  
  public boolean isProgressJar() { return this._isProgressDownload; }
  
  public URL getLocation() { return this._location; }
  
  public String getLocationString() { return this._locationString; }
  
  public String getVersion() { return this._version; }
  
  public boolean isLazyDownload() { return this._isLazyDownload; }
  
  public void setLazyDownload(boolean paramBoolean) { this._isLazyDownload = paramBoolean; }
  
  public boolean isMainJarFile() { return this._isMainFile; }
  
  public String getPartName() { return this._part; }
  
  public int getSize() { return this._size; }
  
  public ResourcesDesc getParent() { return this._parent; }
  
  public void visit(ResourceVisitor paramResourceVisitor) { paramResourceVisitor.visitJARDesc(this); }
  
  public synchronized JARUpdater getUpdater() {
    if (this._updater == null)
      this._updater = new JARUpdater(this); 
    return this._updater;
  }
  
  public CodeRef getCodeRef() { return new CodeRef(getLocation(), getVersion(), false, isPack200Enabled()); }
  
  public XMLNode asXML() {
    null = null;
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("href", this._location);
    xMLAttributeBuilder.add("version", this._version);
    xMLAttributeBuilder.add("part", this._part);
    xMLAttributeBuilder.add("download", isProgressJar() ? "progress" : (isLazyDownload() ? "lazy" : "eager"));
    xMLAttributeBuilder.add("main", isMainJarFile() ? "true" : "false");
    String str = this._isNativeLib ? "nativelib" : "jar";
    return new XMLNode(str, xMLAttributeBuilder.getAttributeList());
  }
  
  public String toString() { return "JARDesc[" + this._locationString + ":" + this._version + "]"; }
  
  public boolean equals(Object paramObject) {
    if (!(paramObject instanceof JARDesc))
      return false; 
    if (this == paramObject)
      return true; 
    JARDesc jARDesc = (JARDesc)paramObject;
    return (getVersion() != null) ? ((getVersion().equals(jARDesc.getVersion()) && this._locationString.equals(jARDesc._locationString))) : ((jARDesc.getVersion() == null && this._locationString.equals(jARDesc._locationString)));
  }
  
  public int hashCode() {
    int i = 0;
    if (getVersion() != null)
      i = getVersion().hashCode(); 
    if (this._locationString != null)
      i ^= this._locationString.hashCode(); 
    return i;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/JARDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */