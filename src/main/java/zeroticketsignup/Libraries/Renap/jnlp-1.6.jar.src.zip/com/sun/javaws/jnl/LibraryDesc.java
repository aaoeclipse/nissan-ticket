package com.sun.javaws.jnl;

import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import com.sun.deploy.xml.XMLable;

public class LibraryDesc implements XMLable {
  String _progressClass;
  
  public LibraryDesc(String paramString) { this._progressClass = paramString; }
  
  public String getProgressClass() { return this._progressClass; }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("progress-class", this._progressClass);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("component-desc", xMLAttributeBuilder.getAttributeList());
    return xMLNodeBuilder.getNode();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/LibraryDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */