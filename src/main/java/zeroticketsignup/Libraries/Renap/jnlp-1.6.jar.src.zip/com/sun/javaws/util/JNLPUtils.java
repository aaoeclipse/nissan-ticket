package com.sun.javaws.util;

import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.ui.AppInfo;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.ResourcesDesc;
import com.sun.jnlp.JNLPClassLoaderUtil;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class JNLPUtils {
  public static void sortResourcesForClasspath(ResourcesDesc paramResourcesDesc, List<JARDesc> paramList1, List<JARDesc> paramList2) {
    ArrayList<JARDesc> arrayList1 = new ArrayList();
    ArrayList<JARDesc> arrayList2 = new ArrayList();
    ArrayList<JARDesc> arrayList3 = new ArrayList();
    HashSet<JARDesc> hashSet = new HashSet();
    JARDesc[] arrayOfJARDesc = paramResourcesDesc.getEagerOrAllJarDescs(true);
    hashSet.addAll(paramList1);
    byte b;
    for (b = 0; b < arrayOfJARDesc.length; b++) {
      if (!arrayOfJARDesc[b].isNativeLib())
        if (arrayOfJARDesc[b].isProgressJar()) {
          addLoadedJarsEntry(hashSet, paramList1, arrayOfJARDesc[b]);
        } else if (arrayOfJARDesc[b].isMainJarFile()) {
          arrayList2.add(arrayOfJARDesc[b]);
        } else if (!arrayOfJARDesc[b].isLazyDownload()) {
          arrayList3.add(arrayOfJARDesc[b]);
        } else if (!paramResourcesDesc.isPackagePart(arrayOfJARDesc[b].getPartName())) {
          arrayList1.add(arrayOfJARDesc[b]);
        } else {
          paramList2.add(arrayOfJARDesc[b]);
        }  
    } 
    for (b = 0; b < arrayList2.size(); b++)
      addLoadedJarsEntry(hashSet, paramList1, arrayList2.get(b)); 
    for (b = 0; b < arrayList3.size(); b++)
      addLoadedJarsEntry(hashSet, paramList1, arrayList3.get(b)); 
    for (b = 0; b < arrayList1.size(); b++)
      addLoadedJarsEntry(hashSet, paramList1, arrayList1.get(b)); 
  }
  
  public static LocalApplicationProperties getLocalApplicationProperties() {
    LocalApplicationProperties localApplicationProperties = null;
    AppInfo appInfo = JNLPClassLoaderUtil.getInstance().getLaunchDesc().getAppInfo();
    if (appInfo != null)
      localApplicationProperties = ResourceProvider.get().getLocalApplicationProperties(appInfo.getLapURL(), null, true); 
    return localApplicationProperties;
  }
  
  private static void addLoadedJarsEntry(Set<JARDesc> paramSet, List<JARDesc> paramList, JARDesc paramJARDesc) {
    if (!paramSet.contains(paramJARDesc)) {
      paramList.add(paramJARDesc);
      paramSet.add(paramJARDesc);
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/util/JNLPUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */