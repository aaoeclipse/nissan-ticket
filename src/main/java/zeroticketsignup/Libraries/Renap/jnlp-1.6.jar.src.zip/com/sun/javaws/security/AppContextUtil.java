package com.sun.javaws.security;

import com.sun.deploy.appcontext.AppContext;
import com.sun.deploy.uitoolkit.ToolkitStore;

public class AppContextUtil {
  private static AppContext _mainAppContext = null;
  
  private static AppContext _securityAppContext = null;
  
  private static AppContext _applicationAppContext = null;
  
  public static void createMainAppContext() {
    if (_mainAppContext == null)
      _mainAppContext = createAppContext(); 
  }
  
  public static void createSecurityAppContext() {
    if (_securityAppContext == null)
      _securityAppContext = createAppContext(); 
  }
  
  public static void createApplicationAppContext() {
    if (_applicationAppContext == null)
      _applicationAppContext = createAppContext(); 
  }
  
  private static AppContext createAppContext() {
    AppContext appContext = ToolkitStore.get().getAppContext();
    if (appContext == null) {
      ToolkitStore.get().createAppContext();
      appContext = ToolkitStore.get().getAppContext();
    } 
    return appContext;
  }
  
  public static boolean isSecurityAppContext() { return ToolkitStore.get().getAppContext().equals(_securityAppContext); }
  
  public static boolean isMainAppContext() { return ToolkitStore.get().getAppContext().equals(_mainAppContext); }
  
  public static boolean isApplicationAppContext() { return ToolkitStore.get().getAppContext().equals(_applicationAppContext); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/security/AppContextUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */