package com.sun.javaws.jnl;

import com.sun.deploy.config.Config;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.GeneralUtil;
import com.sun.deploy.util.VersionString;
import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import java.net.URL;

public class JREDesc implements ResourceType {
  private String _version;
  
  private int _versionType;
  
  public static final int PRODUCT_VERSION = 0;
  
  public static final int PLATFORM_VERSION = 1;
  
  private boolean _isSecure;
  
  private boolean _isForced;
  
  private long _maxHeap;
  
  private long _minHeap;
  
  private String _vmargs;
  
  private URL _href;
  
  private ResourcesDesc _resourceDesc;
  
  private LaunchDesc _extensioDesc;
  
  private boolean _invalidPlatform;
  
  private String _archList;
  
  public JREDesc(String paramString1, long paramLong1, long paramLong2, String paramString2, URL paramURL, ResourcesDesc paramResourcesDesc, String paramString3) {
    this._version = paramString1;
    this._versionType = (paramURL != null) ? 0 : 1;
    this._maxHeap = paramLong2;
    this._minHeap = paramLong1;
    this._vmargs = paramString2;
    this._href = paramURL;
    this._resourceDesc = paramResourcesDesc;
    this._extensioDesc = null;
    this._invalidPlatform = false;
    this._isSecure = false;
    this._isForced = false;
    this._archList = paramString3;
    if (paramURL == null) {
      VersionString versionString = new VersionString(paramString1);
      String[] arrayOfString = { "1.9", "1.8", "1.7", "1.6", "1.5", "1.4", "1.3" };
      for (byte b = 0; b < arrayOfString.length; b++) {
        if (versionString.contains(arrayOfString[b]))
          return; 
      } 
      Trace.println("WARNING - specified JRE version, " + paramString1 + " is invalid platform version", TraceLevel.BASIC);
      this._invalidPlatform = true;
    } 
  }
  
  public JREDesc(String paramString, boolean paramBoolean) {
    this._versionType = 0;
    if (paramString.equals("SECURE")) {
      this._isSecure = true;
      this._version = null;
    } else if (paramString.startsWith("SECURE-")) {
      this._isSecure = true;
      this._version = paramString.substring(7);
    } else {
      this._isSecure = false;
      this._version = paramString;
    } 
    this._isForced = paramBoolean;
  }
  
  public String toString() { return "JREDesc[version " + this._version + ", versionType=" + this._versionType + ", secure=" + this._isSecure + ", heap=" + this._minHeap + "-" + this._maxHeap + ", args=" + this._vmargs + ", href=" + this._href + ", " + this._resourceDesc + ", " + this._extensioDesc + "]"; }
  
  public String[] getArchList() { return GeneralUtil.getStringList(this._archList); }
  
  public int getVersionType() { return this._versionType; }
  
  public boolean isSecure() { return this._isSecure; }
  
  public boolean isVersionForced() { return this._isForced; }
  
  public String getVersion() { return this._version; }
  
  public URL getHref() { return this._href; }
  
  public long getMinHeap() { return this._minHeap; }
  
  public long getMaxHeap() { return this._maxHeap; }
  
  public String getVmArgs() { return this._vmargs; }
  
  public ResourcesDesc getNestedResources() { return this._resourceDesc; }
  
  public LaunchDesc getExtensionDesc() { return this._extensioDesc; }
  
  public void setExtensionDesc(LaunchDesc paramLaunchDesc) { this._extensioDesc = paramLaunchDesc; }
  
  public void visit(ResourceVisitor paramResourceVisitor) { paramResourceVisitor.visitJREDesc(this); }
  
  public String getSource() {
    if (this._href != null)
      return this._href.getHost(); 
    try {
      URL uRL = new URL(Config.getStringProperty("deployment.javaws.installURL"));
      return uRL.getHost();
    } catch (Throwable throwable) {
      Trace.ignored(throwable);
      return "";
    } 
  }
  
  public boolean isInvalidPlatform() { return this._invalidPlatform; }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    if (this._archList != null)
      xMLAttributeBuilder.add("arch", this._archList); 
    if (this._minHeap > 0L)
      xMLAttributeBuilder.add("initial-heap-size", this._minHeap); 
    if (this._maxHeap > 0L)
      xMLAttributeBuilder.add("max-heap-size", this._maxHeap); 
    if (this._vmargs != null)
      xMLAttributeBuilder.add("java-vm-args", this._vmargs); 
    xMLAttributeBuilder.add("href", this._href);
    if (this._version != null)
      xMLAttributeBuilder.add("version", this._version); 
    XMLNode xMLNode = (this._extensioDesc != null) ? this._extensioDesc.asXML() : null;
    if (this._resourceDesc != null)
      xMLNode = this._resourceDesc.asXML(); 
    return new XMLNode("java", xMLAttributeBuilder.getAttributeList(), xMLNode, null);
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/JREDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */