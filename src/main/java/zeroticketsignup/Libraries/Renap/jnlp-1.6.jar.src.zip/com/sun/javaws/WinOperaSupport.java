package com.sun.javaws;

import com.sun.deploy.config.Config;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.WinRegistry;
import java.io.File;
import java.io.IOException;

public class WinOperaSupport extends OperaSupport {
  private static final String OPERA_SUBKEY = "Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Opera.exe";
  
  private static final String OPERA_PATH = "Path";
  
  private static final String USER_HOME = "user.home";
  
  private static final String USER_DATA_INFIX = "Application Data" + File.separator + "Opera";
  
  private static final String USER_DATA_POSTFIX = "Profile";
  
  private static final String SYSTEM_PREFERENCES = "OperaDef6.ini";
  
  private static final String MULTI_USER_SECTION = "System";
  
  private static final String MULTI_USER_KEY = "Multi User";
  
  public boolean isInstalled() { return (getInstallPath().length() != 0); }
  
  public void enableJnlp(File paramFile, boolean paramBoolean) {
    String str = getInstallPath();
    if (str.length() > 0)
      try {
        File file1 = new File(str);
        File file2 = enableSystemJnlp(file1, paramFile);
        if (file2 == null) {
          file2 = new File(file1, "opera6.ini");
          if (!file2.exists()) {
            file2 = new File(file1, "opera.ini");
            if (!file2.exists())
              file2 = new File(Config.getOSHome(), "opera.ini"); 
          } 
        } 
        enableJnlp(null, file2, paramFile, paramBoolean);
      } catch (Exception exception) {
        Trace.ignoredException(exception);
      }  
  }
  
  public WinOperaSupport(boolean paramBoolean) { super(paramBoolean); }
  
  private File enableSystemJnlp(File paramFile1, File paramFile2) throws IOException {
    OperaPreferences operaPreferences = null;
    File file1 = null;
    File file2 = null;
    file1 = new File(paramFile1, "OperaDef6.ini");
    operaPreferences = getPreferences(file1);
    if (operaPreferences != null) {
      boolean bool = true;
      enableJnlp(operaPreferences, file1, paramFile2, true);
      if (operaPreferences.containsKey("System", "Multi User")) {
        String str = operaPreferences.get("System", "Multi User").trim();
        str = str.substring(0, str.indexOf(' '));
        try {
          int i = Integer.decode(str).intValue();
          if (i == 0) {
            bool = false;
            Trace.println("Multi-user support is turned off in the Opera system preference file (" + file1.getAbsolutePath() + ").", TraceLevel.BASIC);
          } 
        } catch (NumberFormatException numberFormatException) {
          bool = false;
          Trace.println("The Opera system preference file (" + file1.getAbsolutePath() + ") has '" + "Multi User" + "=" + str + "' in the " + "System" + " section, so multi-user support is not enabled.", TraceLevel.BASIC);
        } 
      } 
      if (bool == true) {
        StringBuffer stringBuffer = new StringBuffer(512);
        stringBuffer.append(System.getProperty("user.home")).append(File.separator).append(USER_DATA_INFIX).append(File.separator).append(paramFile1.getName()).append(File.separator).append("Profile").append(File.separator).append("opera6.ini");
        file2 = new File(stringBuffer.toString());
      } 
    } 
    return file2;
  }
  
  private String getInstallPath() {
    String str = WinRegistry.getString(-2147483646, "Software\\Microsoft\\Windows\\CurrentVersion\\App Paths\\Opera.exe", "Path");
    return (str != null) ? str : "";
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/WinOperaSupport.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */