package com.sun.jnlp;

import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.Preloader;
import com.sun.applet2.preloader.event.ConfigEvent;
import com.sun.applet2.preloader.event.InitEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.javaws.CacheUtil;
import com.sun.javaws.LaunchDownload;
import com.sun.javaws.jnl.ExtensionDesc;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.jnl.ResourceVisitor;
import com.sun.javaws.jnl.ResourcesDesc;
import com.sun.javaws.progress.CustomProgress2PreloaderAdapter;
import com.sun.javaws.progress.PreloaderDelegate;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.Arrays;
import java.util.jar.JarFile;
import javax.jnlp.DownloadService;
import javax.jnlp.DownloadServiceListener;

public final class DownloadServiceImpl implements DownloadService {
  private static DownloadServiceImpl _sharedInstance = null;
  
  private DownloadServiceListener _defaultProgressHelper = null;
  
  static synchronized void reset() { _sharedInstance = null; }
  
  public static synchronized DownloadServiceImpl getInstance() {
    initialize();
    return _sharedInstance;
  }
  
  public static synchronized void initialize() {
    if (_sharedInstance == null)
      _sharedInstance = new DownloadServiceImpl(); 
  }
  
  public DownloadServiceListener getDefaultProgressWindow() {
    if (this._defaultProgressHelper == null)
      this._defaultProgressHelper = AccessController.doPrivileged(new PrivilegedAction<DownloadServiceListener>() {
            public Object run() {
              Preloader preloader = ToolkitStore.get().getDefaultPreloader();
              try {
                preloader.handleEvent((PreloaderEvent)new ConfigEvent(3, JNLPClassLoaderUtil.getInstance().getLaunchDesc().getAppInfo()));
                preloader.handleEvent((PreloaderEvent)new InitEvent(1));
              } catch (CancelException cancelException) {
                Trace.ignoredException((Exception)cancelException);
              } 
              return new PreloaderDelegate(preloader);
            }
          }); 
    return this._defaultProgressHelper;
  }
  
  public boolean isResourceCached(final URL ref, final String version) {
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() { return (DownloadServiceImpl.this.isResourceValid(ref, version) && ResourceProvider.get().isCached(ref, version)) ? Boolean.TRUE : Boolean.FALSE; }
        });
    return bool.booleanValue();
  }
  
  public boolean isPartCached(String paramString) { return isPartCached(new String[] { paramString }); }
  
  public boolean isPartCached(final String[] parts) {
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
            ResourcesDesc resourcesDesc = launchDesc.getResources();
            if (resourcesDesc == null)
              return Boolean.FALSE; 
            JARDesc[] arrayOfJARDesc = resourcesDesc.getPartJars(parts);
            return new Boolean(DownloadServiceImpl.this.isJARInCache(arrayOfJARDesc, true));
          }
        });
    return bool.booleanValue();
  }
  
  public boolean isExtensionPartCached(URL paramURL, String paramString1, String paramString2) { return isExtensionPartCached(paramURL, paramString1, new String[] { paramString2 }); }
  
  public boolean isExtensionPartCached(final URL ref, final String version, final String[] parts) {
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() {
            LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
            ResourcesDesc resourcesDesc = launchDesc.getResources();
            if (resourcesDesc == null)
              return Boolean.FALSE; 
            JARDesc[] arrayOfJARDesc = resourcesDesc.getExtensionPart(ref, version, parts);
            return new Boolean(DownloadServiceImpl.this.isJARInCache(arrayOfJARDesc, true));
          }
        });
    return bool.booleanValue();
  }
  
  public void loadResource(final URL ref, final String version, final DownloadServiceListener progress) throws IOException {
    Trace.println(getClass().getName() + ".loadResource(" + ref + "," + progress.getClass().getName() + ")");
    if (isResourceValid(ref, version))
      try {
        AccessController.doPrivileged(new PrivilegedExceptionAction() {
              public Object run() throws IOException {
                CustomProgress2PreloaderAdapter customProgress2PreloaderAdapter = new CustomProgress2PreloaderAdapter(progress);
                PreloaderDelegate preloaderDelegate = DownloadServiceImpl.this.getProgressHelper(customProgress2PreloaderAdapter);
                int i = ResourceProvider.get().incrementInternalUse();
                try {
                  if (ref.toString().endsWith(".jar")) {
                    JNLPClassLoaderIf jNLPClassLoaderIf = JNLPClassLoaderUtil.getInstance();
                    jNLPClassLoaderIf.addResource(ref, version, null);
                    if (!DownloadServiceImpl.this.isResourceCached(ref, version))
                      LaunchDownload.downloadResource(jNLPClassLoaderIf.getLaunchDesc(), ref, version, (Preloader)preloaderDelegate, true); 
                  } else {
                    Resource resource = ResourceProvider.get().getResource(ref, version);
                    if (resource.isJNLPFile())
                      DownloadServiceImpl.this.loadResourceRecursivly(resource, progress); 
                  } 
                } catch (Exception exception) {
                  throw new IOException(exception.getMessage());
                } finally {
                  preloaderDelegate.forceFlushForTCK();
                  ResourceProvider.get().decrementInternalUse(i);
                } 
                return null;
              }
            });
      } catch (PrivilegedActionException privilegedActionException) {
        throw (IOException)privilegedActionException.getException();
      }  
  }
  
  private void loadResourceRecursivly(Resource paramResource, final DownloadServiceListener progress) {
    try {
      File file = new File(paramResource.getResourceFilename());
      URL uRL = new URL(paramResource.getURL());
      LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(file, null, null, uRL);
      ResourcesDesc resourcesDesc = launchDesc.getResources();
      if (resourcesDesc != null)
        resourcesDesc.visit(new ResourceVisitor() {
              public void visitJARDesc(JARDesc param1JARDesc) {
                try {
                  DownloadServiceImpl.this.loadResource(param1JARDesc.getLocation(), param1JARDesc.getVersion(), progress);
                } catch (IOException iOException) {
                  Trace.ignored(iOException);
                } 
              }
              
              public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
                try {
                  DownloadServiceImpl.this.loadResource(param1ExtensionDesc.getLocation(), param1ExtensionDesc.getVersion(), progress);
                } catch (IOException iOException) {
                  Trace.ignored(iOException);
                } 
              }
            }); 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
  }
  
  public void loadPart(String paramString, DownloadServiceListener paramDownloadServiceListener) throws IOException { loadPart(new String[] { paramString }, paramDownloadServiceListener); }
  
  public void loadPart(final String[] parts, final DownloadServiceListener progress) throws IOException {
    Trace.println(getClass().getName() + ".loadPart(" + Arrays.asList(parts) + "," + progress.getClass().getName() + ")", TraceLevel.TEMP);
    if (isPartCached(parts))
      return; 
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
              CustomProgress2PreloaderAdapter customProgress2PreloaderAdapter = new CustomProgress2PreloaderAdapter(progress);
              PreloaderDelegate preloaderDelegate = DownloadServiceImpl.this.getProgressHelper(customProgress2PreloaderAdapter);
              try {
                LaunchDownload.downloadParts(JNLPClassLoaderUtil.getInstance().getLaunchDesc(), parts, (Preloader)preloaderDelegate, true);
              } catch (Exception exception) {
                throw new IOException(exception.getMessage());
              } finally {
                preloaderDelegate.forceFlushForTCK();
              } 
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
  }
  
  public void loadExtensionPart(URL paramURL, String paramString1, String paramString2, DownloadServiceListener paramDownloadServiceListener) throws IOException { loadExtensionPart(paramURL, paramString1, new String[] { paramString2 }, paramDownloadServiceListener); }
  
  public void loadExtensionPart(final URL ref, final String version, final String[] parts, final DownloadServiceListener progress) throws IOException {
    try {
      Trace.println(getClass().getName() + ".loadExtensionPart(" + Arrays.asList(parts) + "," + progress.getClass().getName() + ")");
      AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
              CustomProgress2PreloaderAdapter customProgress2PreloaderAdapter = new CustomProgress2PreloaderAdapter(progress);
              PreloaderDelegate preloaderDelegate = DownloadServiceImpl.this.getProgressHelper(customProgress2PreloaderAdapter);
              try {
                LaunchDownload.downloadExtensionPart(JNLPClassLoaderUtil.getInstance().getLaunchDesc(), ref, version, parts, (Preloader)preloaderDelegate, true);
              } catch (Exception exception) {
                throw new IOException(exception.getMessage());
              } finally {
                preloaderDelegate.forceFlushForTCK();
              } 
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
  }
  
  public void removeResource(final URL ref, final String version) throws IOException {
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
              if (DownloadServiceImpl.this.isResourceValid(ref, version)) {
                if (ref.toString().endsWith("jnlp"))
                  CacheUtil.remove(Cache.getCacheEntry(ref, version)); 
                Resource resource = ResourceProvider.get().getCachedResource(ref, version);
                if (resource != null)
                  ResourceProvider.get().markRetired(resource, true); 
              } 
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
  }
  
  public void removePart(String paramString) throws IOException { removePart(new String[] { paramString }); }
  
  public void removePart(final String[] parts) throws IOException {
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
              LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
              ResourcesDesc resourcesDesc = launchDesc.getResources();
              if (resourcesDesc == null)
                return null; 
              JARDesc[] arrayOfJARDesc = resourcesDesc.getPartJars(parts);
              DownloadServiceImpl.this.removeJARFromCache(arrayOfJARDesc);
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
  }
  
  public void removeExtensionPart(URL paramURL, String paramString1, String paramString2) throws IOException { removeExtensionPart(paramURL, paramString1, new String[] { paramString2 }); }
  
  public void removeExtensionPart(final URL ref, final String version, final String[] parts) throws IOException {
    try {
      AccessController.doPrivileged(new PrivilegedExceptionAction() {
            public Object run() throws IOException {
              LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
              ResourcesDesc resourcesDesc = launchDesc.getResources();
              if (resourcesDesc == null)
                return null; 
              JARDesc[] arrayOfJARDesc = resourcesDesc.getExtensionPart(ref, version, parts);
              DownloadServiceImpl.this.removeJARFromCache(arrayOfJARDesc);
              return null;
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
  }
  
  private void removeJARFromCache(JARDesc[] paramArrayOfJARDesc) throws IOException {
    if (paramArrayOfJARDesc == null)
      return; 
    if (paramArrayOfJARDesc.length == 0)
      return; 
    for (byte b = 0; b < paramArrayOfJARDesc.length; b++) {
      Resource resource = ResourceProvider.get().getCachedResource(paramArrayOfJARDesc[b].getLocation(), paramArrayOfJARDesc[b].getVersion());
      ResourceProvider.get().markRetired(resource, true);
    } 
  }
  
  private boolean isJARInCache(JARDesc[] paramArrayOfJARDesc, boolean paramBoolean) {
    if (paramArrayOfJARDesc == null)
      return false; 
    if (paramArrayOfJARDesc.length == 0)
      return false; 
    boolean bool = true;
    for (byte b = 0; b < paramArrayOfJARDesc.length; b++) {
      JarFile jarFile = ResourceProvider.get().getCachedJarFile(paramArrayOfJARDesc[b].getLocation(), paramArrayOfJARDesc[b].getVersion());
      if (jarFile != null) {
        if (!paramBoolean)
          return true; 
      } else {
        bool = false;
      } 
    } 
    return bool;
  }
  
  private boolean isResourceValid(URL paramURL, String paramString) {
    LaunchDesc launchDesc = JNLPClassLoaderUtil.getInstance().getLaunchDesc();
    JARDesc[] arrayOfJARDesc = launchDesc.getResources().getEagerOrAllJarDescs(true);
    if (launchDesc.getSecurityModel() != 0)
      return true; 
    for (byte b = 0; b < arrayOfJARDesc.length; b++) {
      if (paramURL.toString().equals(arrayOfJARDesc[b].getLocation().toString()) && (paramString == null || paramString.equals(arrayOfJARDesc[b].getVersion())))
        return true; 
    } 
    URL uRL = launchDesc.getMainJarURL();
    return (uRL != null && paramURL != null && paramURL.toString().startsWith(uRL.toString()));
  }
  
  private PreloaderDelegate getProgressHelper(CustomProgress2PreloaderAdapter paramCustomProgress2PreloaderAdapter) { return new PreloaderDelegate((Preloader)paramCustomProgress2PreloaderAdapter); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/DownloadServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */