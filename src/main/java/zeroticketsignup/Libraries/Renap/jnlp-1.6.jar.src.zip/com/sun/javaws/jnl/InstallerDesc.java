package com.sun.javaws.jnl;

import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import com.sun.deploy.xml.XMLable;

public class InstallerDesc implements XMLable {
  private String _mainClass;
  
  public InstallerDesc(String paramString) { this._mainClass = paramString; }
  
  public String getMainClass() { return this._mainClass; }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("main-class", this._mainClass);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("installer-desc", xMLAttributeBuilder.getAttributeList());
    return xMLNodeBuilder.getNode();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/InstallerDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */