package com.sun.jnlp;

import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import sun.awt.image.URLImageSource;

class ImageCache {
  private static Map images = null;
  
  static synchronized Image getImage(URL paramURL) {
    Image image = (Image)images.get(paramURL);
    if (image == null) {
      image = Toolkit.getDefaultToolkit().createImage(new URLImageSource(paramURL));
      images.put(paramURL, image);
    } 
    return image;
  }
  
  public static void initialize() { images = new HashMap<Object, Object>(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/ImageCache.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */