package com.sun.javaws.exceptions;

public class ExitException extends Exception {
  private int _reason;
  
  private Throwable _throwable;
  
  private String _msg;
  
  public static final int OK = 0;
  
  public static final int REBOOT = 1;
  
  public static final int JRE_MISMATCH = 2;
  
  public static final int LAUNCH_ERROR = 3;
  
  public static final int LAUNCH_ABORT_SILENT = 4;
  
  public static final int LAUNCH_SINGLETON = 5;
  
  public static final int LAUNCH_ERROR_MESSAGE = 6;
  
  public ExitException(String paramString, Throwable paramThrowable, int paramInt) {
    this._msg = paramString;
    this._throwable = paramThrowable;
    this._reason = paramInt;
  }
  
  public ExitException(String paramString, Throwable paramThrowable) { this(paramString, paramThrowable, 6); }
  
  public ExitException(Throwable paramThrowable, int paramInt) { this(null, paramThrowable, paramInt); }
  
  public Throwable getException() { return this._throwable; }
  
  public int getReason() { return this._reason; }
  
  public boolean isErrorException() { return (this._reason != 0 && this._reason != 5); }
  
  public boolean isSilentException() { return (this._reason == 0 || this._reason >= 4); }
  
  public String getMessage() { return (this._msg != null) ? this._msg : ((this._throwable != null && this._throwable.getMessage() != null) ? this._throwable.getMessage() : toString()); }
  
  public String toString() {
    String str = "ExitException[ " + getReason() + "]";
    if (this._throwable != null)
      str = str + this._throwable.toString(); 
    return str;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/ExitException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */