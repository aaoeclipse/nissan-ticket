package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;
import java.net.URL;

public class CanceledDownloadException extends DownloadException {
  public CanceledDownloadException(URL paramURL, String paramString) { super(paramURL, paramString); }
  
  public String getRealMessage() { return ResourceManager.getString("launch.error.canceledloadingresource", getResourceString()); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/CanceledDownloadException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */