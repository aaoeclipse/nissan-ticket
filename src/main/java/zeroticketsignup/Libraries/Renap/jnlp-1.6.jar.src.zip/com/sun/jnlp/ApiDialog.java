package com.sun.jnlp;

import com.sun.deploy.config.Config;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.ToolkitStore;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashSet;

public final class ApiDialog {
  private HashSet<String> _connect = new HashSet<String>();
  
  private HashSet<String> _connectNo = new HashSet<String>();
  
  private HashSet<String> _accept = new HashSet<String>();
  
  private HashSet<String> _acceptNo = new HashSet<String>();
  
  public boolean askConnect(String paramString) {
    if (this._connect.contains(paramString))
      return true; 
    if (this._connectNo.contains(paramString))
      return false; 
    String str1 = ResourceManager.getString("api.ask.host.title");
    String str2 = ResourceManager.getString("api.ask.connect", paramString);
    DialogResult dialogResult = askUser(str1, str2, null);
    if (dialogResult == DialogResult.OK || dialogResult == DialogResult.ALWAYS) {
      this._connect.add(paramString);
      try {
        String str = InetAddress.getByName(paramString).getHostAddress();
        this._connect.add(str);
      } catch (UnknownHostException unknownHostException) {
        Trace.ignored(unknownHostException);
      } 
      return true;
    } 
    this._connectNo.add(paramString);
    return false;
  }
  
  public boolean askAccept(String paramString) {
    if (this._accept.contains(paramString))
      return true; 
    if (this._acceptNo.contains(paramString))
      return false; 
    try {
      paramString = InetAddress.getByName(paramString).getHostAddress();
    } catch (UnknownHostException unknownHostException) {
      Trace.ignored(unknownHostException);
    } 
    if (this._accept.contains(paramString))
      return true; 
    if (this._acceptNo.contains(paramString))
      return false; 
    String str1 = ResourceManager.getString("api.ask.host.title");
    String str2 = ResourceManager.getString("api.ask.accept", paramString);
    DialogResult dialogResult = askUser(str1, str2, null);
    if (dialogResult == DialogResult.OK || dialogResult == DialogResult.ALWAYS) {
      this._accept.add(paramString);
      return true;
    } 
    this._acceptNo.add(paramString);
    return false;
  }
  
  DialogResult askUser(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, boolean paramBoolean) {
    if (!Config.getBooleanProperty("deployment.security.sandbox.jnlp.enhanced"))
      return DialogResult.CANCEL; 
    AppInfo appInfo = JNLPClassLoaderUtil.getInstance().getLaunchDesc().getAppInfo();
    appInfo.setVendor(null);
    int i = ToolkitStore.getUI().showMessageDialog(null, appInfo, 7, paramString1, null, paramString2, paramString4, paramString5, paramString3, null);
    return toDialogResult(i);
  }
  
  DialogResult askUser(String paramString1, String paramString2, String paramString3) { return askUser(paramString1, paramString2, paramString3, null, null, false); }
  
  private static DialogResult toDialogResult(int paramInt) { return (0 == paramInt) ? DialogResult.OK : ((2 == paramInt) ? DialogResult.ALWAYS : DialogResult.CANCEL); }
  
  public enum DialogResult {
    OK, ALWAYS, CANCEL;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/ApiDialog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */