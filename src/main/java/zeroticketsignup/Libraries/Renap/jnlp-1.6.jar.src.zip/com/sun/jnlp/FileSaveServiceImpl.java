package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import com.sun.deploy.util.Waiter;
import com.sun.javaws.util.JNLPUtils;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.FileContents;
import javax.jnlp.FileSaveService;

public final class FileSaveServiceImpl implements FileSaveService {
  static FileSaveService _sharedInstance = null;
  
  private ApiDialog _apiDialog = new ApiDialog();
  
  private String _lastPath;
  
  public static synchronized FileSaveService getInstance() {
    if (_sharedInstance == null)
      if (Platform.get().isNativeSandbox()) {
        _sharedInstance = new FileSaveServiceNSBImpl(new FileSaveServiceImpl());
      } else {
        _sharedInstance = new FileSaveServiceImpl();
      }  
    return _sharedInstance;
  }
  
  String getLastPath() { return this._lastPath; }
  
  void setLastPath(String paramString) { this._lastPath = paramString; }
  
  public FileContents saveAsFileDialog(String paramString, String[] paramArrayOfString, FileContents paramFileContents) throws IOException { return saveFileDialog(paramString, paramArrayOfString, paramFileContents.getInputStream(), paramFileContents.getName()); }
  
  public FileContents saveFileDialog(final String pathHint, final String[] extensions, final InputStream stream, final String filename) throws IOException {
    if (!askUser())
      return null; 
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception {
          Object object = DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = pathHint;
                  if (str == null)
                    str = FileSaveServiceImpl.this.getLastPath(); 
                  File[] arrayOfFile = ToolkitStore.getUI().showFileChooser(str, extensions, 9, false, filename);
                  if (arrayOfFile[0] != null)
                    try {
                      byte[] arrayOfByte = new byte[8192];
                      BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(arrayOfFile[0]));
                      BufferedInputStream bufferedInputStream = new BufferedInputStream(stream);
                      int i;
                      for (i = bufferedInputStream.read(arrayOfByte); i != -1; i = bufferedInputStream.read(arrayOfByte))
                        bufferedOutputStream.write(arrayOfByte, 0, i); 
                      bufferedOutputStream.close();
                      FileSaveServiceImpl.this.setLastPath(arrayOfFile[0].getPath());
                      return new FileContentsImpl(arrayOfFile[0], FileSaveServiceImpl.computeMaxLength(arrayOfFile[0].length()));
                    } catch (IOException iOException) {
                      Trace.ignored(iOException);
                      return iOException;
                    }  
                  return null;
                }
              }null);
          if (object instanceof IOException)
            throw (IOException)object; 
          return object;
        }
      };
    try {
      return (FileContents)Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      if (exception instanceof IOException)
        throw (IOException)exception; 
      Trace.ignored(exception);
      return null;
    } 
  }
  
  String saveFileDialogNSB(final String pathHint, final String[] extensions, final String filename) throws IOException {
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception {
          Object object = DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = pathHint;
                  if (str == null)
                    str = FileSaveServiceImpl.this.getLastPath(); 
                  File[] arrayOfFile = ToolkitStore.getUI().showFileChooser(str, extensions, 9, false, filename);
                  return (arrayOfFile[0] != null) ? arrayOfFile[0].getAbsolutePath() : null;
                }
              }null);
          if (object instanceof IOException)
            throw (IOException)object; 
          return object;
        }
      };
    try {
      return (String)Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      if (exception instanceof IOException)
        throw (IOException)exception; 
      Trace.ignored(exception);
      return null;
    } 
  }
  
  synchronized boolean askUser() {
    if (CheckServicePermission.hasFileAccessPermissions())
      return true; 
    final LocalApplicationProperties lap = JNLPUtils.getLocalApplicationProperties();
    if (localApplicationProperties != null) {
      String str = localApplicationProperties.get("jnlp.api.always.FileSaveService.save");
      if (str != null)
        return true; 
    } 
    ApiDialog.DialogResult dialogResult = this._apiDialog.askUser(ResourceManager.getString("api.file.save.title"), ResourceManager.getString("api.file.save.message"), ResourceManager.getString("api.file.save.always"));
    if (dialogResult == ApiDialog.DialogResult.ALWAYS)
      AccessController.doPrivileged(new PrivilegedAction<Void>() {
            public Void run() {
              lap.put("jnlp.api.always.FileSaveService.save", "skip");
              try {
                lap.store();
              } catch (Throwable throwable) {
                Trace.ignored(throwable);
              } 
              return null;
            }
          }); 
    return (dialogResult == ApiDialog.DialogResult.OK || dialogResult == ApiDialog.DialogResult.ALWAYS);
  }
  
  static long computeMaxLength(long paramLong) { return paramLong * 3L; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/FileSaveServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */