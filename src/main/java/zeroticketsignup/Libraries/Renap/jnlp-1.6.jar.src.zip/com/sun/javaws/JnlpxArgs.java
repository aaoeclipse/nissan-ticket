package com.sun.javaws;

import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.Preloader;
import com.sun.applet2.preloader.event.ConfigEvent;
import com.sun.applet2.preloader.event.InitEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.config.Platform;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.ArgumentParsingUtil;
import com.sun.deploy.util.GeneralUtil;
import com.sun.deploy.util.JVMParameters;
import com.sun.deploy.util.ParameterUtil;
import com.sun.deploy.util.Property;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.jnl.JREDesc;
import com.sun.javaws.jnl.JREMatcher;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import java.awt.Component;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;

public class JnlpxArgs {
  public static final String ARG_JVM = "jnlpx.jvm";
  
  public static final String ARG_SPLASHPORT = "jnlpx.splashport";
  
  public static final String ARG_REMOVE = "jnlpx.remove";
  
  public static final String ARG_OFFLINE = "jnlpx.offline";
  
  public static final String ARG_HEAPSIZE = "jnlpx.heapsize";
  
  public static final String ARG_VMARGS = "jnlpx.vmargs";
  
  public static final String ARG_HOME = "jnlpx.home";
  
  public static final String ARG_RELAUNCH = "jnlpx.relaunch";
  
  public static final String ARG_SESSION_DATA = "jnlpx.session.data";
  
  public static final String ARG_ORIGFILE_NAME = "jnlpx.origFilenameArg";
  
  public static final String ARG_DOCK_NAME = "macosx.jnlpx.dock.name";
  
  public static final String ARG_DOCK_ICON = "macosx.jnlpx.dock.icon";
  
  private static File _currentJVMCommand = null;
  
  private static final String JAVAWS_JAR = "javaws.jar";
  
  private static final String DEPLOY_JAR = "deploy.jar";
  
  private static final String PLUGIN_JAR = "plugin.jar";
  
  private static final Vector fileReadWriteList = new Vector();
  
  public static boolean _verbose = false;
  
  public static int getSplashPort() {
    try {
      return Integer.parseInt(System.getProperty("jnlpx.splashport", "-1"));
    } catch (NumberFormatException numberFormatException) {
      return -1;
    } 
  }
  
  public static String getVMArgs() { return System.getProperty("jnlpx.vmargs"); }
  
  public static boolean getIsRelaunch() { return getBooleanProperty("jnlpx.relaunch"); }
  
  public static File getJVMCommand() {
    if (_currentJVMCommand == null) {
      String str = System.getProperty("jnlpx.jvm", "").trim();
      if (str.startsWith("X"))
        str = JREInfo.getDefaultJavaPath(); 
      if (str.startsWith("\""))
        str = str.substring(1); 
      if (str.endsWith("\""))
        str = str.substring(0, str.length() - 1); 
      _currentJVMCommand = new File(str);
    } 
    return _currentJVMCommand;
  }
  
  public static boolean shouldRemoveArgumentFile() { return getBooleanProperty("jnlpx.remove"); }
  
  public static void setShouldRemoveArgumentFile(String paramString) { System.setProperty("jnlpx.remove", paramString); }
  
  public static boolean isOffline() { return getBooleanProperty("jnlpx.offline"); }
  
  public static void SetIsOffline() { System.setProperty("jnlpx.offline", "true"); }
  
  public static String getHeapSize() { return System.getProperty("jnlpx.heapsize"); }
  
  public static void setVerbose(boolean paramBoolean) { _verbose = paramBoolean; }
  
  public static long getInitialHeapSize() {
    String str1 = getHeapSize();
    if (str1 == null)
      return -1L; 
    String str2 = str1.substring(str1.lastIndexOf('=') + 1);
    String str3 = str2.substring(0, str2.lastIndexOf(','));
    return GeneralUtil.heapValToLong(str3);
  }
  
  public static long getMaxHeapSize() {
    String str1 = getHeapSize();
    if (str1 == null)
      return -1L; 
    String str2 = str1.substring(str1.lastIndexOf('=') + 1);
    String str3 = str2.substring(str2.lastIndexOf(',') + 1, str2.length());
    return GeneralUtil.heapValToLong(str3);
  }
  
  private static boolean heapSizesValid(long paramLong1, long paramLong2) { return (paramLong1 != -1L || paramLong2 != -1L); }
  
  static List getArgumentList(String paramString, long paramLong1, long paramLong2, JVMParameters paramJVMParameters, List paramList, boolean paramBoolean1, boolean paramBoolean2, int paramInt, File paramFile) {
    String str6;
    String str1 = "-Djnlpx.heapsize=NULL,NULL";
    if (heapSizesValid(paramLong1, paramLong2))
      str1 = "-Djnlpx.heapsize=" + paramLong1 + "," + paramLong2; 
    String str2 = getVMArgs();
    if (str2 != null && !str2.isEmpty()) {
      paramJVMParameters = paramJVMParameters.copy();
      paramJVMParameters.addEncodedArguments(str2, true, false, true);
    } 
    String str3 = System.getProperty("macosx.jnlpx.dock.icon");
    String str4 = System.getProperty("macosx.jnlpx.dock.name");
    String str5 = System.getProperty("jnlpx.session.data");
    System.setProperty("jnlpx.session.data", "");
    String str7 = Environment.getForcedBootClassPath();
    if (str7 == null) {
      str6 = "-Xbootclasspath/a:" + paramFile + File.separator + "lib" + File.separator + "javaws.jar" + File.pathSeparator + paramFile + File.separator + "lib" + File.separator + "deploy.jar" + File.pathSeparator + paramFile + File.separator + "lib" + File.separator + "plugin.jar";
    } else {
      str6 = "-Xbootclasspath/p:" + str7;
    } 
    String str8 = paramBoolean2 ? "-Djnlp.fx=2.2+" : "";
    String str9 = "-Djnlp.tk=" + (paramBoolean2 ? "jfx" : "awt");
    String str10 = System.getProperty("jnlpx.origFilenameArg");
    String[] arrayOfString = { 
        str6, str8, str9, "-classpath", paramFile + File.separator + "lib" + File.separator + "deploy.jar", null, (str3 != null) ? ("-Xdock:icon=" + str3) : "", (str4 != null) ? ("-Xdock:name=" + str4) : "", "-Djnlpx.jvm=" + paramString, "-Djnlpx.splashport=" + getSplashPort(), 
        "-Djnlpx.home=" + paramFile + File.separator + "bin", "-Djnlpx.remove=" + (shouldRemoveArgumentFile() ? "true" : "false"), "-Djnlpx.offline=" + (isOffline() ? "true" : "false"), "-Djnlpx.relaunch=true", "-Djnlpx.session.data=" + ((str5 != null) ? str5 : ""), str1, "-Djava.security.policy=" + getPolicyURLString(paramFile), "-DtrustProxy=true", "-Xverify:remote", (str10 == null) ? "" : ("-Djnlpx.origFilenameArg=" + str10), 
        useJCOV(), useBootClassPath(), useJpiProfile(), useDebugMode(), useDebugVMMode(), paramBoolean2 ? "" : "-Dsun.awt.warmup=true", "-Djava.security.manager", "com.sun.javaws.Main", paramBoolean1 ? "-secure" : "", _verbose ? "-verbose" : "", 
        setTCKHarnessOption(), Environment.isWebJava() ? "" : "-notWebJava", useLogToHost() };
    for (byte b1 = 0; b1 < arrayOfString.length; b1++) {
      if (arrayOfString[b1] != null)
        paramInt -= arrayOfString[b1].length() + 1; 
    } 
    List<String> list = paramJVMParameters.getCommandLineArguments(false, false, true, paramBoolean1, false, paramInt / 2 - 20);
    list = ParameterUtil.mergeArgs(list, paramList, 1);
    String str11 = ArgumentParsingUtil.encodeArgumentList(list);
    paramInt -= str11.length();
    Property property = new Property("jnlpx.vmargs", str11);
    String str12 = property.toString();
    if (paramInt < str12.length()) {
      Trace.println("JnlpxArgs.getArgumentList: Internal Error:  remaining custArgsMaxLen: " + paramInt + " < vmArgsPropertyStr.length: " + str12.length() + " dropping vmArgsPropertyStr");
      str12 = null;
    } 
    for (byte b2 = 0; b2 < arrayOfString.length; b2++) {
      if (arrayOfString[b2] == null) {
        if (str12 != null) {
          list.add(str12);
          str12 = null;
        } 
      } else if (arrayOfString[b2].length() > 0) {
        list.add(arrayOfString[b2]);
      } 
    } 
    return list;
  }
  
  static String getPolicyURLString(File paramFile) {
    String str1 = paramFile + File.separator + "lib" + File.separator + "security" + File.separator + "javaws.policy";
    String str2 = str1;
    try {
      URL uRL = new URL("file", "", str1);
      str2 = uRL.toString();
    } catch (Exception exception) {}
    return str2;
  }
  
  public static String useLogToHost() { return (Globals.LogToHost != null) ? ("-XX:LogToHost=" + Globals.LogToHost) : ""; }
  
  public static String setTCKHarnessOption() { return (Globals.TCKHarnessRun == true) ? "-XX:TCKHarnessRun=true" : ""; }
  
  public static String useBootClassPath() { return Globals.BootClassPath.equals("NONE") ? "" : ("-Xbootclasspath" + Globals.BootClassPath); }
  
  public static String useJpiProfile() {
    String str = System.getProperty("javaplugin.user.profile");
    return (str != null) ? ("-Djavaplugin.user.profile=" + str) : "";
  }
  
  public static String useJCOV() { return Globals.JCOV.equals("NONE") ? "" : ("-Xrunjcov:file=" + Globals.JCOV); }
  
  public static String useDebugMode() { return Config.isDebugMode() ? "-Ddeploy.debugMode=true" : ""; }
  
  public static String useDebugVMMode() { return Config.isDebugVMMode() ? "-Ddeploy.useDebugJavaVM=true" : ""; }
  
  public static void removeArgumentFile(String paramString) {
    if (shouldRemoveArgumentFile() && paramString != null)
      (new File(paramString)).delete(); 
  }
  
  public static void verify() {
    if (Trace.isEnabled(TraceLevel.BASIC)) {
      Trace.println("Java part started", TraceLevel.BASIC);
      Trace.println("jnlpx.jvm: " + getJVMCommand(), TraceLevel.BASIC);
      Trace.println("jnlpx.splashport: " + getSplashPort(), TraceLevel.BASIC);
      Trace.println("jnlpx.remove: " + shouldRemoveArgumentFile(), TraceLevel.BASIC);
      Trace.println("jnlpx.heapsize: " + getHeapSize(), TraceLevel.BASIC);
    } 
  }
  
  private static boolean getBooleanProperty(String paramString) {
    String str = System.getProperty(paramString, "false");
    return (str != null && str.equals("true"));
  }
  
  public static Vector getFileReadWriteList() { return fileReadWriteList; }
  
  protected static Process execProgram(JREInfo paramJREInfo, String[] paramArrayOfString, long paramLong1, long paramLong2, JVMParameters paramJVMParameters, boolean paramBoolean) throws IOException { return execProgram(paramJREInfo, paramArrayOfString, paramLong1, paramLong2, paramJVMParameters, paramBoolean, false); }
  
  public static Process execProgram(JREInfo paramJREInfo, String[] paramArrayOfString, long paramLong1, long paramLong2, JVMParameters paramJVMParameters, boolean paramBoolean1, boolean paramBoolean2) throws IOException {
    String str1;
    File file;
    if (paramJREInfo.isArchMatch()) {
      JREInfo jREInfo = JREInfo.getHomeJRE();
      file = Environment.getDeploymentHome();
      boolean bool = false;
    } else {
      JREInfo jREInfo = JREInfo.getCompatibleHomeJRE();
      file = jREInfo.getDeploymentHome();
      boolean bool = true;
    } 
    String str2 = paramJREInfo.getPath();
    if (Config.isDebugMode() && Config.isDebugVMMode()) {
      str1 = paramJREInfo.getDebugJavaPath();
    } else {
      str1 = paramJREInfo.getPath();
    } 
    if (str1 == null || str2 == null || str1.length() == 0 || str2.length() == 0 || file == null)
      throw new IllegalArgumentException("must exist"); 
    int i = Config.getMaxCommandLineLength();
    for (byte b = 0; b < paramArrayOfString.length; b++) {
      if (paramArrayOfString[b] != null)
        i -= paramArrayOfString[b].length() + 1; 
    } 
    i -= str1.length() + 1;
    String str3 = paramJREInfo.getVmArgs();
    List list = ArgumentParsingUtil.parseCommandLine(str3);
    List<? extends String> list1 = getArgumentList(str2, paramLong1, paramLong2, paramJVMParameters, list, paramBoolean1, paramBoolean2, i, file);
    List<String> list2 = new ArrayList();
    if (Config.useSecureLaunch(paramJREInfo)) {
      String str = Platform.get().findSecureLauncher(file);
      list2.add(str);
    } else {
      list2.add(str1);
    } 
    list2.addAll(list1);
    list2.addAll(Arrays.asList(paramArrayOfString));
    if (Trace.isEnabled(TraceLevel.BASIC)) {
      Trace.println("Launching new JRE version: " + paramJREInfo, TraceLevel.BASIC);
      Trace.println("\t jvmParams: " + paramJVMParameters, TraceLevel.BASIC);
      for (byte b1 = 0; b1 < list2.size(); b1++)
        Trace.println("cmd " + b1 + " : " + list2.get(b1), TraceLevel.BASIC); 
    } 
    if (Globals.TCKHarnessRun)
      Main.tckprintln("JVM Starting"); 
    Trace.flush();
    if (Config.useSecureLaunch(paramJREInfo)) {
      list2 = ArgumentParsingUtil.getSecureLaunchArgs(paramJREInfo, list2, paramBoolean1 ? paramJVMParameters : null, true, true);
      for (byte b1 = 0; b1 < list2.size(); b1++)
        Trace.println("secure cmds " + b1 + " : " + list2.get(b1), TraceLevel.BASIC); 
    } 
    ProcessBuilder processBuilder = new ProcessBuilder(list2);
    return Platform.get().startProcessBuilder(processBuilder);
  }
  
  public static void executeInstallers(ArrayList<File> paramArrayList, Preloader paramPreloader) throws ExitException {
    if (paramPreloader.getOwner() != null)
      try {
        paramPreloader.handleEvent((PreloaderEvent)new InitEvent(2));
      } catch (CancelException cancelException) {} 
    for (byte b = 0; b < paramArrayList.size(); b++) {
      File file = paramArrayList.get(b);
      try {
        LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(file, null, null, null);
        LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(file.getPath());
        localApplicationProperties.setExtensionInstalled(false);
        localApplicationProperties.store();
        Trace.println("Installing extension: " + file, TraceLevel.EXTENSIONS);
        String[] arrayOfString = { "-installer", file.getAbsolutePath() };
        JREInfo jREInfo = launchDesc.selectJRE(false);
        if (jREInfo == null) {
          paramPreloader.handleEvent((PreloaderEvent)new ConfigEvent(6));
          LaunchDescException launchDescException = new LaunchDescException(launchDesc, ResourceManager.getString("launch.error.missingjreversion"), null);
          throw new ExitException((Throwable)launchDescException, 3);
        } 
        boolean bool = shouldRemoveArgumentFile();
        setShouldRemoveArgumentFile("false");
        JREMatcher jREMatcher = launchDesc.getJREMatcher();
        JVMParameters jVMParameters = jREMatcher.getSelectedJVMParameters();
        JREDesc jREDesc = jREMatcher.getSelectedJREDesc();
        long l1 = jREDesc.getMinHeap();
        long l2 = jREDesc.getMaxHeap();
        Process process = execProgram(jREInfo, arrayOfString, l1, l2, jVMParameters, false);
        paramPreloader.handleEvent((PreloaderEvent)new ConfigEvent(6));
        EatInput.eatInput(process.getErrorStream());
        EatInput.eatInput(process.getInputStream());
        process.waitFor();
        setShouldRemoveArgumentFile(String.valueOf(bool));
        localApplicationProperties.refresh();
        if (localApplicationProperties.isRebootNeeded()) {
          boolean bool1 = false;
          ExtensionInstallHandler extensionInstallHandler = ExtensionInstallHandler.getInstance();
          if (extensionInstallHandler != null && extensionInstallHandler.doPreRebootActions((Component)paramPreloader.getOwner()))
            bool1 = true; 
          localApplicationProperties.setExtensionInstalled(true);
          localApplicationProperties.setRebootNeeded(false);
          localApplicationProperties.store();
          if (bool1 && extensionInstallHandler.doReboot())
            throw new ExitException(null, 1); 
        } 
        if (!localApplicationProperties.isExtensionInstalled()) {
          paramPreloader.handleEvent((PreloaderEvent)new ConfigEvent(6));
          throw new ExitException((Throwable)new LaunchDescException(launchDesc, ResourceManager.getString("Launch.error.installfailed"), null), 3);
        } 
      } catch (JNLPException jNLPException) {
        try {
          paramPreloader.handleEvent((PreloaderEvent)new ConfigEvent(6));
        } catch (CancelException cancelException) {}
        throw new ExitException((Throwable)jNLPException, 3);
      } catch (IOException iOException) {
        try {
          paramPreloader.handleEvent((PreloaderEvent)new ConfigEvent(6));
        } catch (CancelException cancelException) {}
        throw new ExitException(iOException, 3);
      } catch (InterruptedException interruptedException) {
        try {
          paramPreloader.handleEvent((PreloaderEvent)new ConfigEvent(6));
        } catch (CancelException cancelException) {}
        throw new ExitException(interruptedException, 3);
      } 
    } 
  }
  
  public static void executeUninstallers(ArrayList<File> paramArrayList) throws ExitException {
    for (byte b = 0; b < paramArrayList.size(); b++) {
      File file = paramArrayList.get(b);
      try {
        LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(file, null, null, null);
        LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(file.getPath());
        Trace.println("uninstalling extension: " + file, TraceLevel.EXTENSIONS);
        if (!launchDesc.isInstaller())
          throw new ExitException(null, 3); 
        String[] arrayOfString = { "-silent", "-installer", file.getAbsolutePath() };
        JREInfo jREInfo = launchDesc.selectJRE(false);
        if (jREInfo == null) {
          LaunchDescException launchDescException = new LaunchDescException(launchDesc, ResourceManager.getString("launch.error.missingjreversion"), null);
          throw new ExitException((Throwable)launchDescException, 3);
        } 
        JREMatcher jREMatcher = launchDesc.getJREMatcher();
        JVMParameters jVMParameters = jREMatcher.getSelectedJVMParameters();
        JREDesc jREDesc = jREMatcher.getSelectedJREDesc();
        long l1 = jREDesc.getMinHeap();
        long l2 = jREDesc.getMaxHeap();
        Process process = execProgram(jREInfo, arrayOfString, l1, l2, jVMParameters, false);
        EatInput.eatInput(process.getErrorStream());
        EatInput.eatInput(process.getInputStream());
        process.waitFor();
        localApplicationProperties.refresh();
        if (localApplicationProperties.isRebootNeeded()) {
          boolean bool = false;
          ExtensionInstallHandler extensionInstallHandler = ExtensionInstallHandler.getInstance();
          if (extensionInstallHandler != null && extensionInstallHandler.doPreRebootActions(null))
            bool = true; 
          localApplicationProperties.setRebootNeeded(false);
          localApplicationProperties.setExtensionInstalled(false);
          localApplicationProperties.store();
          if (bool && extensionInstallHandler.doReboot())
            throw new ExitException(null, 1); 
        } 
      } catch (JNLPException jNLPException) {
        throw new ExitException((Throwable)jNLPException, 3);
      } catch (IOException iOException) {
        throw new ExitException(iOException, 3);
      } catch (InterruptedException interruptedException) {
        throw new ExitException(interruptedException, 3);
      } 
    } 
  }
  
  private static String sizeString(long paramLong) { return (paramLong > 1048576L) ? ("" + (paramLong / 1048576L) + "Mb") : ("" + paramLong + "bytes"); }
  
  private static class EatInput implements Runnable {
    private InputStream _is;
    
    EatInput(InputStream param1InputStream) { this._is = param1InputStream; }
    
    public void run() {
      byte[] arrayOfByte = new byte[1024];
      try {
        for (int i = 0; i != -1; i = this._is.read(arrayOfByte));
      } catch (IOException iOException) {}
    }
    
    private static void eatInput(InputStream param1InputStream) {
      EatInput eatInput = new EatInput(param1InputStream);
      (new Thread(eatInput)).start();
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/JnlpxArgs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */