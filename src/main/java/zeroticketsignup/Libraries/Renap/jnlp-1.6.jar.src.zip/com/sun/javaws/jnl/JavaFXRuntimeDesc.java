package com.sun.javaws.jnl;

import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import java.net.URL;

public class JavaFXRuntimeDesc implements ResourceType {
  private URL _href;
  
  private String _vs;
  
  public JavaFXRuntimeDesc(String paramString, URL paramURL) {
    this._vs = paramString;
    this._href = paramURL;
  }
  
  public String getVersion() { return this._vs; }
  
  public URL getDownloadURL() { return this._href; }
  
  public void visit(ResourceVisitor paramResourceVisitor) { paramResourceVisitor.visitJFXDesc(this); }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("version", this._vs);
    xMLAttributeBuilder.add("href", this._href);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("javafx-runtime", xMLAttributeBuilder.getAttributeList());
    return xMLNodeBuilder.getNode();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/JavaFXRuntimeDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */