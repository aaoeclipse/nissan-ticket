package com.sun.javaws;

import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.cache.CacheEntry;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.exceptions.BadFieldException;
import com.sun.javaws.jnl.ExtensionDesc;
import com.sun.javaws.jnl.IconDesc;
import com.sun.javaws.jnl.InformationDesc;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.jnl.RContentDesc;
import com.sun.javaws.jnl.ResourcesDesc;
import com.sun.javaws.ui.ApplicationIconGenerator;
import com.sun.javaws.ui.SplashScreen;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

public class CacheUtil {
  public static void fixShortcut() {
    ArrayList arrayList = Cache.getJnlpCacheEntries(Environment.isSystemCacheMode());
    for (File file : arrayList) {
      LaunchDesc launchDesc = null;
      try {
        launchDesc = LaunchDescFactory.buildDescriptor(file, null, null, null);
      } catch (Exception exception) {
        Trace.println("Cached jnlp file has no codebase", TraceLevel.CACHE);
        try {
          launchDesc = LaunchDescFactory.buildDescriptor(file);
        } catch (Exception exception1) {
          Trace.ignoredException(exception);
        } 
      } 
      if (launchDesc != null) {
        CacheEntry cacheEntry = null;
        File file1 = new File(file.getPath() + ".idx");
        if (file1.exists()) {
          cacheEntry = Cache.getCacheEntryFromFile(file1);
        } else {
          cacheEntry = Cache.getCacheEntry(launchDesc.getCanonicalHome(), null);
        } 
        if (cacheEntry != null) {
          LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(cacheEntry);
          InformationDesc informationDesc = launchDesc.getInformation();
          LocalInstallHandler localInstallHandler = LocalInstallHandler.getInstance();
          if (localInstallHandler != null) {
            localInstallHandler.updateShortcutToLatestJRE(launchDesc, localApplicationProperties);
            continue;
          } 
          return;
        } 
      } 
    } 
  }
  
  public static void remove(boolean paramBoolean) {
    ArrayList arrayList2;
    ArrayList arrayList1 = Cache.getJnlpCacheEntries(Environment.isSystemCacheMode());
    if (paramBoolean) {
      arrayList2 = new ArrayList();
    } else {
      arrayList2 = getExcludedCacheEntries(arrayList1.iterator());
    } 
    for (File file : arrayList1) {
      LaunchDesc launchDesc = null;
      try {
        launchDesc = LaunchDescFactory.buildDescriptor(file, null, null, null);
      } catch (Exception exception) {
        Trace.println("Cached jnlp file has no codebase", TraceLevel.CACHE);
        try {
          launchDesc = LaunchDescFactory.buildDescriptor(file);
        } catch (Exception exception1) {
          Trace.ignoredException(exception);
        } 
      } 
      if (launchDesc != null)
        remove(file, launchDesc, arrayList2); 
    } 
    if (Globals.isShortcutMode())
      return; 
    File[] arrayOfFile = Cache.getCacheEntries(Environment.isSystemCacheMode());
    for (byte b = 0; b < arrayOfFile.length; b++) {
      CacheEntry cacheEntry = Cache.getCacheEntryFromFile(arrayOfFile[b]);
      if (cacheEntry != null) {
        if (!arrayList2.contains(cacheEntry.getIndexFile()))
          Cache.removeCacheEntry(cacheEntry); 
      } else {
        arrayOfFile[b].delete();
      } 
    } 
    if (paramBoolean)
      try {
        Cache.removeAllMuffins();
        Cache.removeAllLapFiles();
      } catch (Exception exception) {
        Trace.ignored(exception);
      }  
  }
  
  public static ArrayList getInstalledResources(boolean paramBoolean) { return getExcludedCacheEntries(Cache.getJnlpCacheEntries(paramBoolean).iterator()); }
  
  public static ArrayList getExcludedCacheEntries(Iterator<File> paramIterator) {
    ArrayList arrayList = new ArrayList() {
        public boolean add(Object param1Object) {
          if (!contains(param1Object))
            super.add(param1Object); 
          return true;
        }
      };
    while (paramIterator.hasNext()) {
      File file1 = paramIterator.next();
      File file2 = new File(file1.getPath() + ".idx");
      LaunchDesc launchDesc = null;
      if (file2.exists()) {
        try {
          launchDesc = LaunchDescFactory.buildDescriptor(file1, null, null, null);
        } catch (BadFieldException badFieldException) {
          try {
            CacheEntry cacheEntry1 = Cache.getCacheEntryFromFile(file2);
            launchDesc = LaunchDescFactory.buildDescriptor(cacheEntry1.getDataFile(), URLUtil.getBase(new URL(cacheEntry1.getURL())), null, new URL(cacheEntry1.getURL()));
          } catch (Exception exception) {
            Trace.ignoredException(exception);
          } 
        } catch (Exception exception) {
          Trace.ignoredException(exception);
        } 
        CacheEntry cacheEntry = Cache.getCacheEntryFromFile(file2);
        if (launchDesc != null && cacheEntry != null) {
          LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(cacheEntry);
          if (localApplicationProperties != null && localApplicationProperties.isJnlpInstalled())
            markResourcesInstalled(file2, launchDesc, cacheEntry, arrayList); 
        } 
      } 
    } 
    return arrayList;
  }
  
  private static void markResourcesInstalled(File paramFile, LaunchDesc paramLaunchDesc, CacheEntry paramCacheEntry, ArrayList<File> paramArrayList) {
    paramArrayList.add(paramFile);
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc != null) {
      JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
      if (arrayOfJARDesc != null)
        for (int i = arrayOfJARDesc.length - 1; i >= 0; i--) {
          URL uRL = arrayOfJARDesc[i].getLocation();
          String str = arrayOfJARDesc[i].getVersion();
          CacheEntry cacheEntry = Cache.getCacheEntry(uRL, str);
          if (cacheEntry != null)
            paramArrayList.add(cacheEntry.getIndexFile()); 
        }  
      ExtensionDesc[] arrayOfExtensionDesc = resourcesDesc.getExtensionDescs();
      if (arrayOfExtensionDesc != null)
        for (int i = arrayOfExtensionDesc.length - 1; i >= 0; i--) {
          ExtensionDesc extensionDesc = arrayOfExtensionDesc[i];
          CacheEntry cacheEntry = Cache.getCacheEntry(extensionDesc.getLocation(), extensionDesc.getVersion());
          if (cacheEntry != null)
            try {
              LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(cacheEntry.getDataFile(), null, null, null);
              if (launchDesc != null)
                markResourcesInstalled(cacheEntry.getIndexFile(), launchDesc, cacheEntry, paramArrayList); 
            } catch (Exception exception) {
              Trace.ignored(exception);
            }  
        }  
    } 
    InformationDesc informationDesc = paramLaunchDesc.getInformation();
    if (informationDesc != null) {
      IconDesc[] arrayOfIconDesc = informationDesc.getIcons();
      if (arrayOfIconDesc != null)
        for (byte b = 0; b < arrayOfIconDesc.length; b++) {
          URL uRL = arrayOfIconDesc[b].getLocation();
          if (uRL != null) {
            String str = arrayOfIconDesc[b].getVersion();
            CacheEntry cacheEntry = Cache.getCacheEntry(uRL, str);
            if (cacheEntry != null)
              paramArrayList.add(cacheEntry.getIndexFile()); 
          } 
        }  
      RContentDesc[] arrayOfRContentDesc = informationDesc.getRelatedContent();
      if (arrayOfRContentDesc != null)
        for (byte b = 0; b < arrayOfRContentDesc.length; b++) {
          URL uRL = arrayOfRContentDesc[b].getIcon();
          if (uRL != null) {
            CacheEntry cacheEntry = Cache.getCacheEntry(uRL, null);
            if (cacheEntry != null)
              paramArrayList.add(cacheEntry.getIndexFile()); 
          } 
        }  
    } 
  }
  
  public static void remove(CacheEntry paramCacheEntry) {
    try {
      LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(paramCacheEntry.getDataFile(), null, null, null);
      remove(paramCacheEntry, launchDesc);
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
  }
  
  public static void remove(File paramFile, LaunchDesc paramLaunchDesc, ArrayList paramArrayList) {
    File file = new File(paramFile.getPath() + ".idx");
    if (file.exists()) {
      CacheEntry cacheEntry = Cache.getCacheEntryFromFile(file);
      if (cacheEntry != null) {
        if (!paramArrayList.contains(file))
          remove(cacheEntry, paramLaunchDesc); 
      } else {
        file.delete();
        paramFile.delete();
      } 
    } else if (paramFile.exists() && ResourceProvider.get().getCacheDir().equals(paramFile.getParentFile())) {
      paramFile.delete();
    } else {
      CacheEntry cacheEntry = Cache.getCacheEntry(paramLaunchDesc.getCanonicalHome(), null);
      if (cacheEntry != null && !paramArrayList.contains(cacheEntry.getIndexFile()))
        remove(cacheEntry, paramLaunchDesc); 
    } 
  }
  
  public static void remove(CacheEntry paramCacheEntry, LaunchDesc paramLaunchDesc) {
    LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(paramCacheEntry);
    InformationDesc informationDesc = paramLaunchDesc.getInformation();
    LocalInstallHandler localInstallHandler = LocalInstallHandler.getInstance();
    if (localInstallHandler != null && paramLaunchDesc.isApplicationDescriptor())
      localInstallHandler.uninstall(paramLaunchDesc, localApplicationProperties, true); 
    if (Globals.isShortcutMode())
      return; 
    if (paramLaunchDesc.isApplicationDescriptor() && paramLaunchDesc.getLocation() != null)
      Cache.saveRemovedApp(paramLaunchDesc.getLocation(), informationDesc.getTitle()); 
    localApplicationProperties.refresh();
    if (localApplicationProperties.isExtensionInstalled() && paramLaunchDesc.isInstaller()) {
      ArrayList<File> arrayList = new ArrayList();
      arrayList.add(paramCacheEntry.getDataFile());
      try {
        String str = localApplicationProperties.getInstallDirectory();
        JnlpxArgs.executeUninstallers(arrayList);
        JREInfo.removeJREsIn(str);
      } catch (Exception exception) {
        Trace.ignoredException(exception);
      } 
    } 
    SplashScreen.removeCustomSplash(paramLaunchDesc);
    ApplicationIconGenerator.removeCustomIcon(paramLaunchDesc);
    if (informationDesc != null) {
      IconDesc[] arrayOfIconDesc = informationDesc.getIcons();
      if (arrayOfIconDesc != null)
        for (byte b = 0; b < arrayOfIconDesc.length; b++) {
          URL uRL = arrayOfIconDesc[b].getLocation();
          String str = arrayOfIconDesc[b].getVersion();
          removeEntries(uRL, str);
        }  
      RContentDesc[] arrayOfRContentDesc = informationDesc.getRelatedContent();
      if (arrayOfRContentDesc != null)
        for (byte b = 0; b < arrayOfRContentDesc.length; b++) {
          URL uRL = arrayOfRContentDesc[b].getIcon();
          if (uRL != null)
            removeEntries(uRL, null); 
        }  
    } 
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc != null) {
      JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
      if (arrayOfJARDesc != null)
        for (int i = arrayOfJARDesc.length - 1; i >= 0; i--) {
          URL uRL = arrayOfJARDesc[i].getLocation();
          String str = arrayOfJARDesc[i].getVersion();
          removeEntries(uRL, str);
        }  
      ExtensionDesc[] arrayOfExtensionDesc = resourcesDesc.getExtensionDescs();
      if (arrayOfExtensionDesc != null)
        for (int i = arrayOfExtensionDesc.length - 1; i >= 0; i--) {
          ExtensionDesc extensionDesc = arrayOfExtensionDesc[i];
          CacheEntry cacheEntry = Cache.getCacheEntry(extensionDesc.getLocation(), extensionDesc.getVersion());
          if (cacheEntry != null)
            try {
              LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(cacheEntry.getDataFile(), null, null, null);
              if (launchDesc != null && launchDesc.isInstaller())
                remove(cacheEntry, launchDesc); 
            } catch (Exception exception) {
              Trace.ignored(exception);
            }  
        }  
    } 
    String str1 = paramCacheEntry.getURL();
    String str2 = paramCacheEntry.getVersion();
    try {
      URL uRL = new URL(str1);
      if (uRL != null)
        removeEntries(uRL, str2); 
    } catch (MalformedURLException malformedURLException) {
      Trace.ignored(malformedURLException);
    } 
    Cache.removeLoadedProperties(str1);
  }
  
  private static void removeEntries(URL paramURL, String paramString) {
    if (paramURL != null) {
      CacheEntry cacheEntry = Cache.getCacheEntry(paramURL, paramString);
      Cache.removeAllCacheEntries(cacheEntry);
    } 
  }
  
  static File getCachedFileNative(URL paramURL) {
    if (paramURL.getProtocol().equals("jar")) {
      String str = paramURL.getPath();
      int i = str.indexOf("!/");
      if (i > 0)
        try {
          String str1 = str.substring(i + 2);
          URL uRL = new URL(str.substring(0, i));
          String str2 = ResourceProvider.get().getLibraryDirForJar(str1, uRL, null);
          if (str2 != null)
            return new File(str2, str1); 
        } catch (MalformedURLException malformedURLException) {
          Trace.ignored(malformedURLException);
        } catch (IOException iOException) {
          Trace.ignored(iOException);
        }  
      return null;
    } 
    Resource resource = ResourceProvider.get().getCachedResource(paramURL, null);
    return (resource != null) ? resource.getDataFile() : null;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/CacheUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */