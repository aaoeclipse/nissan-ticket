package com.sun.jnlp;

import java.awt.Dimension;
import java.net.URL;

public interface AppletContainerCallback {
  void showDocument(URL paramURL);
  
  void relativeResize(Dimension paramDimension);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/AppletContainerCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */