package com.sun.javaws.jnl;

import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.util.SystemUtils;
import com.sun.deploy.xml.XMLNode;
import com.sun.javaws.exceptions.BadFieldException;
import com.sun.javaws.exceptions.MissingFieldException;
import java.net.MalformedURLException;
import java.net.URL;

public class XMLUtils {
  public static int getIntAttribute(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3, int paramInt) throws BadFieldException {
    String str = getAttribute(paramXMLNode, paramString2, paramString3);
    if (str == null)
      return paramInt; 
    try {
      return Integer.parseInt(str);
    } catch (NumberFormatException numberFormatException) {
      throw new BadFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3, str);
    } 
  }
  
  public static int getRequiredWHAttribute(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3, int paramInt) throws BadFieldException, MissingFieldException {
    String str = getAttribute(paramXMLNode, paramString2, paramString3);
    if (str == null)
      throw new MissingFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3); 
    try {
      return SystemUtils.parsePercent(str, paramInt);
    } catch (NumberFormatException numberFormatException) {
      throw new BadFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3, str);
    } 
  }
  
  public static String getAttribute(XMLNode paramXMLNode, String paramString1, String paramString2) throws BadFieldException { return getAttribute(paramXMLNode, paramString1, paramString2, null); }
  
  public static String getRequiredAttributeEmptyOK(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3) throws MissingFieldException {
    String str = null;
    XMLNode xMLNode = findElementPath(paramXMLNode, paramString2);
    if (xMLNode != null)
      str = xMLNode.getAttribute(paramString3); 
    if (str == null)
      throw new MissingFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3); 
    return str;
  }
  
  public static String getClassName(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3, boolean paramBoolean) throws BadFieldException, MissingFieldException {
    String str = null;
    if (paramBoolean) {
      str = getRequiredAttribute(paramString1, paramXMLNode, paramString2, paramString3);
    } else {
      str = getAttribute(paramXMLNode, paramString2, paramString3);
    } 
    if (str != null && str.endsWith(".class")) {
      int i = str.lastIndexOf(".class");
      String str1 = str.substring(0, i);
      Trace.println("invalid class cname in jnlp file: " + str + " - using " + str1 + " instead", TraceLevel.BASIC);
      return str1;
    } 
    return str;
  }
  
  public static String getRequiredAttribute(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3) throws MissingFieldException, BadFieldException {
    String str = getAttribute(paramXMLNode, paramString2, paramString3, null);
    if (str == null)
      throw new MissingFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3); 
    str = str.trim();
    return (str.length() == 0) ? null : str;
  }
  
  public static String getAttribute(XMLNode paramXMLNode, String paramString1, String paramString2, String paramString3) throws BadFieldException {
    XMLNode xMLNode = findElementPath(paramXMLNode, paramString1);
    if (xMLNode == null)
      return paramString3; 
    String str = xMLNode.getAttribute(paramString2);
    if (str != null && str.contains("\000")) {
      Trace.println("invalid " + paramString2 + ": " + str + " - it contains null", TraceLevel.SECURITY);
      throw new BadFieldException("", paramString1 + paramString2, str);
    } 
    return (str == null || str.length() == 0) ? paramString3 : str;
  }
  
  public static URL getAttributeURL(String paramString1, URL paramURL, XMLNode paramXMLNode, String paramString2, String paramString3) throws BadFieldException {
    String str = getAttribute(paramXMLNode, paramString2, paramString3);
    if (str == null)
      return null; 
    try {
      if (str.startsWith("jar:")) {
        int i = str.indexOf("!/");
        if (i > 0) {
          String str1 = str.substring(i);
          String str2 = str.substring(4, i);
          URL uRL = (paramURL == null) ? new URL(str2) : new URL(paramURL, str2);
          return new URL("jar:" + uRL.toString() + str1);
        } 
      } 
      return (paramURL == null) ? new URL(str) : new URL(paramURL, str);
    } catch (MalformedURLException malformedURLException) {
      if (malformedURLException.getMessage().indexOf("https") != -1)
        throw new BadFieldException(paramString1, "<jnlp>", "https"); 
      throw new BadFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3, str);
    } 
  }
  
  public static URL getAttributeURL(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3) throws BadFieldException { return getAttributeURL(paramString1, null, paramXMLNode, paramString2, paramString3); }
  
  public static URL getRequiredURL(String paramString1, URL paramURL, XMLNode paramXMLNode, String paramString2, String paramString3) throws BadFieldException, MissingFieldException {
    URL uRL = getAttributeURL(paramString1, paramURL, paramXMLNode, paramString2, paramString3);
    if (uRL == null)
      throw new MissingFieldException(paramString1, getPathString(paramXMLNode) + paramString2 + paramString3); 
    return uRL;
  }
  
  public static URL getRequiredURL(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3) throws BadFieldException, MissingFieldException { return getRequiredURL(paramString1, null, paramXMLNode, paramString2, paramString3); }
  
  public static boolean isElementPath(XMLNode paramXMLNode, String paramString) { return (findElementPath(paramXMLNode, paramString) != null); }
  
  public static URL getElementURL(String paramString1, XMLNode paramXMLNode, String paramString2) throws BadFieldException {
    String str = getElementContents(paramXMLNode, paramString2);
    try {
      return new URL(str);
    } catch (MalformedURLException malformedURLException) {
      throw new BadFieldException(paramString1, getPathString(paramXMLNode) + paramString2, str);
    } 
  }
  
  public static String getPathString(XMLNode paramXMLNode) { return (paramXMLNode == null || !paramXMLNode.isElement()) ? "" : (getPathString(paramXMLNode.getParent()) + "<" + paramXMLNode.getName() + ">"); }
  
  public static String getElementContentsWithAttribute(XMLNode paramXMLNode, String paramString1, String paramString2, String paramString3, String paramString4) throws BadFieldException, MissingFieldException {
    XMLNode xMLNode = getElementWithAttribute(paramXMLNode, paramString1, paramString2, paramString3);
    return (xMLNode == null) ? paramString4 : getElementContents(xMLNode, "", paramString4);
  }
  
  public static URL getAttributeURLWithAttribute(String paramString1, XMLNode paramXMLNode, String paramString2, String paramString3, String paramString4, String paramString5, URL paramURL) throws BadFieldException, MissingFieldException {
    XMLNode xMLNode = getElementWithAttribute(paramXMLNode, paramString2, paramString3, paramString4);
    if (xMLNode == null)
      return paramURL; 
    URL uRL = getAttributeURL(paramString1, xMLNode, "", paramString5);
    return (uRL == null) ? paramURL : uRL;
  }
  
  public static XMLNode getElementWithAttribute(XMLNode paramXMLNode, String paramString1, final String attr, final String val) throws BadFieldException, MissingFieldException {
    final XMLNode[] result = { null };
    visitElements(paramXMLNode, paramString1, new ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws BadFieldException, MissingFieldException {
            if (result[0] == null && param1XMLNode.getAttribute(attr).equals(val))
              result[0] = param1XMLNode; 
          }
        });
    return arrayOfXMLNode[0];
  }
  
  public static String getElementContents(XMLNode paramXMLNode, String paramString) { return getElementContents(paramXMLNode, paramString, null); }
  
  public static String getElementContents(XMLNode paramXMLNode, String paramString1, String paramString2) {
    XMLNode xMLNode1 = findElementPath(paramXMLNode, paramString1);
    if (xMLNode1 == null)
      return paramString2; 
    XMLNode xMLNode2 = xMLNode1.getNested();
    return (xMLNode2 != null && !xMLNode2.isElement()) ? xMLNode2.getName() : paramString2;
  }
  
  public static XMLNode findElementPath(XMLNode paramXMLNode, String paramString) {
    if (paramXMLNode == null)
      return null; 
    if (paramString == null || paramString.length() == 0)
      return paramXMLNode; 
    int i = paramString.indexOf('>');
    if (paramString.charAt(0) != '<')
      throw new IllegalArgumentException("bad path. Missing begin tag"); 
    if (i == -1)
      throw new IllegalArgumentException("bad path. Missing end tag"); 
    String str1 = paramString.substring(1, i);
    String str2 = paramString.substring(i + 1);
    return findElementPath(findChildElement(paramXMLNode, str1), str2);
  }
  
  public static XMLNode findChildElement(XMLNode paramXMLNode, String paramString) {
    for (XMLNode xMLNode = paramXMLNode.getNested(); xMLNode != null; xMLNode = xMLNode.getNext()) {
      if (xMLNode.isElement() && xMLNode.getName().equals(paramString))
        return xMLNode; 
    } 
    return null;
  }
  
  public static void visitElements(XMLNode paramXMLNode, String paramString, ElementVisitor paramElementVisitor) throws BadFieldException, MissingFieldException {
    int i = paramString.lastIndexOf('<');
    if (i == -1)
      throw new IllegalArgumentException("bad path. Must contain atleast one tag"); 
    if (paramString.length() == 0 || paramString.charAt(paramString.length() - 1) != '>')
      throw new IllegalArgumentException("bad path. Must end with a >"); 
    String str1 = paramString.substring(0, i);
    String str2 = paramString.substring(i + 1, paramString.length() - 1);
    XMLNode xMLNode1 = findElementPath(paramXMLNode, str1);
    if (xMLNode1 == null)
      return; 
    for (XMLNode xMLNode2 = xMLNode1.getNested(); xMLNode2 != null; xMLNode2 = xMLNode2.getNext()) {
      if (xMLNode2.isElement() && xMLNode2.getName().equals(str2))
        paramElementVisitor.visitElement(xMLNode2); 
    } 
  }
  
  public static void visitChildrenElements(XMLNode paramXMLNode, ElementVisitor paramElementVisitor) throws BadFieldException, MissingFieldException {
    for (XMLNode xMLNode = paramXMLNode.getNested(); xMLNode != null; xMLNode = xMLNode.getNext()) {
      if (xMLNode.isElement())
        paramElementVisitor.visitElement(xMLNode); 
    } 
  }
  
  public static abstract class ElementVisitor {
    public abstract void visitElement(XMLNode param1XMLNode) throws BadFieldException, MissingFieldException;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/XMLUtils.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */