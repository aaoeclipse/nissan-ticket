package com.sun.javaws.progress;

import com.sun.applet2.Applet2Context;
import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.Preloader;
import com.sun.applet2.preloader.event.AppletInitEvent;
import com.sun.applet2.preloader.event.DownloadErrorEvent;
import com.sun.applet2.preloader.event.DownloadEvent;
import com.sun.applet2.preloader.event.ErrorEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import javax.jnlp.DownloadServiceListener;

public class CustomProgress2PreloaderAdapter extends Preloader {
  private DownloadServiceListener _ds = null;
  
  private boolean seenUserDeclined = false;
  
  public CustomProgress2PreloaderAdapter(DownloadServiceListener paramDownloadServiceListener) {
    Trace.println("Adapt DownloadServiceListener [" + paramDownloadServiceListener.getClass() + "] to Preloader ", TraceLevel.PRELOADER);
    this._ds = paramDownloadServiceListener;
  }
  
  public CustomProgress2PreloaderAdapter(DownloadServiceListener paramDownloadServiceListener, Applet2Context paramApplet2Context) {
    super(paramApplet2Context);
    Trace.println("Wrap DownloadServiceListener [" + paramDownloadServiceListener.getClass() + "] as Preloader with appletcontext", TraceLevel.PRELOADER);
    this._ds = paramDownloadServiceListener;
  }
  
  public Object getOwner() { return null; }
  
  public boolean handleEvent(PreloaderEvent paramPreloaderEvent) throws CancelException {
    try {
      AppletInitEvent appletInitEvent;
      ErrorEvent errorEvent;
      DownloadEvent downloadEvent;
      switch (paramPreloaderEvent.getType()) {
        case 3:
          downloadEvent = (DownloadEvent)paramPreloaderEvent;
          if (this._ds != null) {
            switch (downloadEvent.getDownloadType()) {
              case 0:
                this._ds.progress(downloadEvent.getURL(), downloadEvent.getVersion(), downloadEvent.getCompletedCount(), downloadEvent.getTotalCount(), downloadEvent.getOverallPercentage());
                return true;
              case 1:
                this._ds.validating(downloadEvent.getURL(), downloadEvent.getVersion(), downloadEvent.getCompletedCount(), downloadEvent.getTotalCount(), downloadEvent.getOverallPercentage());
                return true;
              case 2:
                this._ds.upgradingArchive(downloadEvent.getURL(), downloadEvent.getVersion(), downloadEvent.getOverallPercentage(), downloadEvent.getOverallPercentage());
                return true;
            } 
            return false;
          } 
          return false;
        case 6:
          errorEvent = (ErrorEvent)paramPreloaderEvent;
          if (this._ds != null && errorEvent instanceof DownloadErrorEvent)
            this._ds.downloadFailed(errorEvent.getLocation(), ((DownloadErrorEvent)errorEvent).getVersion()); 
          if (this._ds == null && this.ctx != null && this.ctx.getHost() != null)
            this.ctx.getHost().showError(errorEvent.getValue(), errorEvent.getException(), this.seenUserDeclined); 
          return true;
        case 7:
          this.seenUserDeclined = true;
          return false;
        case 5:
          appletInitEvent = (AppletInitEvent)paramPreloaderEvent;
          if (this.ctx != null && this.ctx.getHost() != null)
            switch (appletInitEvent.getSubtype()) {
              case 3:
              case 6:
                this.ctx.getHost().showApplet();
                break;
            }  
          return false;
      } 
      Trace.println("Preloader Adapter skips event " + paramPreloaderEvent, TraceLevel.PRELOADER);
      return false;
    } catch (Throwable throwable) {
      throw new CancelException("Got " + throwable + " from download service listener. Treat as Cancel.");
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/progress/CustomProgress2PreloaderAdapter.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */