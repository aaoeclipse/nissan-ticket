package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.nativesandbox.NativeSandboxBroker;
import com.sun.deploy.resources.ResourceManager;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import javax.jnlp.FileContents;
import javax.jnlp.JNLPRandomAccessFile;

public final class JNLPRandomAccessFileNSBImpl implements JNLPRandomAccessFile {
  private FileContents _contents = null;
  
  private final String _file;
  
  private String _message = null;
  
  private NativeSandboxBroker broker = null;
  
  JNLPRandomAccessFileNSBImpl(File paramFile, String paramString, FileContents paramFileContents) throws IOException {
    this._contents = paramFileContents;
    if (!paramString.equals("rw"))
      throw new IllegalArgumentException("Only \"rw\" mode is supported"); 
    if (this._contents == null)
      throw new IllegalArgumentException("FileContents can not be null"); 
    if (paramFile == null)
      throw new IllegalArgumentException("File can not be null"); 
    this._file = paramFile.getAbsolutePath();
    this.broker = Platform.get().getNativeSandboxBroker();
    if (this.broker == null)
      throw new IllegalArgumentException("Broker can not be null"); 
    if (this._message == null)
      this._message = ResourceManager.getString("api.persistence.filesizemessage"); 
  }
  
  public void close() throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(0, this._file);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
  }
  
  public long length() throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(2, this._file);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
    return rAF2.getLongValue();
  }
  
  public long getFilePointer() throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(1, this._file);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
    return rAF2.getLongValue();
  }
  
  private DataInputStream getDIS(int paramInt) throws EOFException, IOException {
    if (paramInt <= 0)
      throw new IOException("b.length <= 0"); 
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(1, this._file);
    rAF1.setLongValue(paramInt);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getEOFException() != null)
      throw new EOFException(rAF2.getEOFException()); 
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
    ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(rAF2.getData());
    return new DataInputStream(byteArrayInputStream);
  }
  
  private RAFDataOutputStream getDOS() {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    return new RAFDataOutputStream(byteArrayOutputStream);
  }
  
  private void sendDOS(RAFDataOutputStream paramRAFDataOutputStream) throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(9, this._file);
    rAF1.setData(paramRAFDataOutputStream.toByteArray());
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
  }
  
  public int read() throws IOException { return getDIS(4).read(); }
  
  public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException { return getDIS(paramInt2).read(paramArrayOfbyte, paramInt1, paramInt2); }
  
  public int read(byte[] paramArrayOfbyte) throws IOException { return getDIS(paramArrayOfbyte.length).read(paramArrayOfbyte); }
  
  public void readFully(byte[] paramArrayOfbyte) throws IOException { getDIS(paramArrayOfbyte.length).readFully(paramArrayOfbyte); }
  
  public void readFully(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException { getDIS(paramArrayOfbyte.length).readFully(paramArrayOfbyte, paramInt1, paramInt2); }
  
  public int skipBytes(int paramInt) throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(8, this._file);
    rAF1.setLongValue(paramInt);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
    return (int)rAF2.getLongValue();
  }
  
  public boolean readBoolean() throws IOException { return getDIS(1).readBoolean(); }
  
  public byte readByte() throws IOException { return getDIS(1).readByte(); }
  
  public int readUnsignedByte() throws IOException { return getDIS(1).readUnsignedByte(); }
  
  public short readShort() throws IOException { return getDIS(2).readShort(); }
  
  public int readUnsignedShort() throws IOException { return getDIS(2).readUnsignedShort(); }
  
  public char readChar() throws IOException { return getDIS(1).readChar(); }
  
  public int readInt() throws IOException { return getDIS(4).readInt(); }
  
  public long readLong() throws IOException { return getDIS(8).readLong(); }
  
  public float readFloat() throws IOException { return getDIS(4).readFloat(); }
  
  public double readDouble() throws IOException { return getDIS(8).readDouble(); }
  
  public String readLine() throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(4, this._file);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getEOFException() != null)
      throw new EOFException(rAF2.getEOFException()); 
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
    return rAF2.getString();
  }
  
  public String readUTF() throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(5, this._file);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getEOFException() != null)
      throw new EOFException(rAF2.getEOFException()); 
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
    return rAF2.getString();
  }
  
  public void seek(long paramLong) throws IOException {
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(6, this._file);
    rAF1.setLongValue(paramLong);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
  }
  
  public void setLength(long paramLong) throws IOException {
    if (paramLong > this._contents.getMaxLength())
      throw new IOException(this._message); 
    NativeSandboxBroker.RAF rAF1 = new NativeSandboxBroker.RAF(7, this._file);
    rAF1.setLongValue(paramLong);
    NativeSandboxBroker.RAF rAF2 = this.broker.sendRAF(rAF1);
    if (rAF2.getIOException() != null)
      throw new IOException(rAF2.getIOException()); 
  }
  
  public void write(int paramInt) throws IOException {
    checkWrite(1);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.write(paramInt);
    sendDOS(rAFDataOutputStream);
  }
  
  public void write(byte[] paramArrayOfbyte) throws IOException {
    if (paramArrayOfbyte != null)
      checkWrite(paramArrayOfbyte.length); 
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.write(paramArrayOfbyte);
    sendDOS(rAFDataOutputStream);
  }
  
  public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
    checkWrite(paramInt2);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.write(paramArrayOfbyte, paramInt1, paramInt2);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeBoolean(boolean paramBoolean) throws IOException {
    checkWrite(1);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeBoolean(paramBoolean);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeByte(int paramInt) throws IOException {
    checkWrite(1);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeByte(paramInt);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeShort(int paramInt) throws IOException {
    checkWrite(2);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeShort(paramInt);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeChar(int paramInt) throws IOException {
    checkWrite(2);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeChar(paramInt);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeInt(int paramInt) throws IOException {
    checkWrite(4);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeInt(paramInt);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeLong(long paramLong) throws IOException {
    checkWrite(8);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeLong(paramLong);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeFloat(float paramFloat) throws IOException {
    checkWrite(4);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeFloat(paramFloat);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeDouble(double paramDouble) throws IOException {
    checkWrite(8);
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeDouble(paramDouble);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeBytes(String paramString) throws IOException {
    if (paramString != null)
      checkWrite(paramString.length()); 
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeBytes(paramString);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeChars(String paramString) throws IOException {
    if (paramString != null)
      checkWrite(paramString.length() * 2); 
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeChars(paramString);
    sendDOS(rAFDataOutputStream);
  }
  
  public void writeUTF(String paramString) throws IOException {
    if (paramString != null)
      checkWrite(getUTFLen(paramString)); 
    RAFDataOutputStream rAFDataOutputStream = getDOS();
    rAFDataOutputStream.writeUTF(paramString);
    sendDOS(rAFDataOutputStream);
  }
  
  private int getUTFLen(String paramString) {
    int i = paramString.length();
    char[] arrayOfChar = new char[i];
    paramString.getChars(0, i, arrayOfChar, 0);
    byte b1 = 2;
    for (byte b2 = 0; b2 < i; b2++) {
      char c = arrayOfChar[b2];
      if (c >= '\001' && c <= '') {
        b1++;
      } else if (c > '߿') {
        b1 += 3;
      } else {
        b1 += 2;
      } 
    } 
    return b1;
  }
  
  private void checkWrite(int paramInt) throws IOException {
    if (paramInt < 0 || this._contents.getMaxLength() - getFilePointer() < paramInt)
      throw new IOException(this._message); 
  }
  
  private class RAFDataOutputStream extends DataOutputStream {
    private final ByteArrayOutputStream baos;
    
    public RAFDataOutputStream(ByteArrayOutputStream param1ByteArrayOutputStream) {
      super(param1ByteArrayOutputStream);
      this.baos = param1ByteArrayOutputStream;
    }
    
    public byte[] toByteArray() { return this.baos.toByteArray(); }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/JNLPRandomAccessFileNSBImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */