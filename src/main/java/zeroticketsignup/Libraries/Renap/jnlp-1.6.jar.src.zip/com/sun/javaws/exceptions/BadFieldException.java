package com.sun.javaws.exceptions;

import com.sun.deploy.cache.Cache;
import com.sun.deploy.resources.ResourceManager;

public class BadFieldException extends LaunchDescException {
  private String _field;
  
  private String _value;
  
  private String _launchDescSource;
  
  public BadFieldException(String paramString1, String paramString2, String paramString3) {
    this._value = paramString3;
    this._field = paramString2;
    this._launchDescSource = paramString1;
  }
  
  public String getField() { return getMessage(); }
  
  public String getValue() { return this._value; }
  
  public String getRealMessage() { return !Cache.isCacheEnabled() ? ResourceManager.getString("launch.error.badfield.nocache") : (getValue().equals("https") ? (ResourceManager.getString("launch.error.badfield", this._field, this._value) + "\n" + ResourceManager.getString("launch.error.badfield.https")) : (!isSignedLaunchDesc() ? ResourceManager.getString("launch.error.badfield", this._field, this._value) : ResourceManager.getString("launch.error.badfield-signedjnlp", this._field, this._value))); }
  
  public String getLaunchDescSource() { return this._launchDescSource; }
  
  public String toString() { return getValue().equals("https") ? ("BadFieldException[ " + getRealMessage() + "]") : ("BadFieldException[ " + getField() + "," + getValue() + "]"); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/BadFieldException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */