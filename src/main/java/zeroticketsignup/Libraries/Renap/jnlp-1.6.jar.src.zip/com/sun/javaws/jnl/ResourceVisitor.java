package com.sun.javaws.jnl;

public class ResourceVisitor {
  public void visitJARDesc(JARDesc paramJARDesc) {}
  
  public void visitPropertyDesc(PropertyDesc paramPropertyDesc) {}
  
  public void visitPackageDesc(PackageDesc paramPackageDesc) {}
  
  public void visitExtensionDesc(ExtensionDesc paramExtensionDesc) {}
  
  public void visitJREDesc(JREDesc paramJREDesc) {}
  
  public void visitJFXDesc(JavaFXRuntimeDesc paramJavaFXRuntimeDesc) {}
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/ResourceVisitor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */