package com.sun.javaws.jnl;

import com.sun.deploy.config.JREInfo;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class LaunchSelection {
  private static final String anyJREVersion = "0+";
  
  protected static JREInfo selectJRE(LaunchDesc paramLaunchDesc, JREMatcher paramJREMatcher) {
    synchronized (paramJREMatcher) {
      if (!paramJREMatcher.hasBeenRun()) {
        paramJREMatcher.beginTraversal(paramLaunchDesc);
        ResourcesDesc resourcesDesc = paramLaunchDesc.getRawResources();
        if (resourcesDesc != null) {
          ResourcesDesc resourcesDesc1 = new ResourcesDesc();
          resourcesDesc1.addNested(resourcesDesc);
          selectJREDescHelper(paramLaunchDesc, paramJREMatcher);
          JREDesc jREDesc = paramJREMatcher.getSelectedJREDesc();
          if (jREDesc != null)
            resourcesDesc1.addNested(jREDesc.getNestedResources()); 
          if (!paramLaunchDesc.isInstaller())
            collectJVMProperties(resourcesDesc1, paramJREMatcher); 
        } 
        paramJREMatcher.endTraversal(paramLaunchDesc);
      } 
      return paramJREMatcher.getSelectedJREInfo();
    } 
  }
  
  protected static boolean addNestedResourcesForRunningJRE(LaunchDesc paramLaunchDesc) {
    boolean bool = false;
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc != null) {
      JREMatcher jREMatcher = new JREMatcher();
      jREMatcher.beginTraversal(paramLaunchDesc);
      selectJREDescHelper(paramLaunchDesc, jREMatcher);
      JREDesc jREDesc = jREMatcher.getRunningJREDesc();
      if (jREDesc != null) {
        resourcesDesc.addNested(jREDesc.getNestedResources());
        bool = true;
      } 
      jREMatcher.endTraversal(paramLaunchDesc);
    } 
    return bool;
  }
  
  private static void selectJREDescHelper(final LaunchDesc ld, JREMatcher paramJREMatcher) {
    ResourcesDesc resourcesDesc = ld.getResources();
    if (resourcesDesc == null)
      return; 
    final ArrayList<JREDesc> listJREDesc = new ArrayList();
    resourcesDesc.visit(new ResourceVisitor() {
          public void visitJREDesc(JREDesc param1JREDesc) {
            if (ld.isLibrary()) {
              Trace.println("JNLP JREDesc in Component ignored: " + ld.getLocation(), TraceLevel.BASIC);
            } else {
              listJREDesc.add(param1JREDesc);
            } 
          }
        });
    JREDesc jREDesc = null;
    JREInfo jREInfo = null;
    boolean bool = false;
    for (JREDesc jREDesc1 : arrayList) {
      if (jREInfo == null || !bool) {
        JREInfo jREInfo1 = selectJRE(jREDesc1, paramJREMatcher, ld.needFX());
        if (jREInfo1 != null) {
          jREInfo = jREInfo1;
          jREDesc = jREDesc1;
        } 
      } 
      if (paramJREMatcher.getRunningJREDesc() == null && paramJREMatcher.isVersionMatch(JREInfo.getHomeJRE(), jREDesc1)) {
        paramJREMatcher.setRunningJREDesc(jREDesc1);
        bool = true;
      } 
    } 
    if (jREInfo == null)
      if (arrayList.isEmpty()) {
        jREDesc = new JREDesc("0+", -1L, -1L, null, null, new ResourcesDesc(), null);
        resourcesDesc.addResource(jREDesc);
        jREInfo = selectJRE(jREDesc, paramJREMatcher, ld.needFX());
      } else {
        jREDesc = arrayList.get(0);
      }  
    paramJREMatcher.digest(jREDesc, jREInfo);
  }
  
  private static void collectJVMProperties(ResourcesDesc paramResourcesDesc, JREMatcher paramJREMatcher) {
    if (paramResourcesDesc == null)
      return; 
    paramJREMatcher.digest(paramResourcesDesc);
    final ArrayList listExtDesc = new ArrayList();
    paramResourcesDesc.visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) { listExtDesc.add(param1ExtensionDesc); }
        });
    for (ExtensionDesc extensionDesc : arrayList) {
      LaunchDesc launchDesc = extensionDesc.getExtensionDesc();
      if (launchDesc != null && !launchDesc.isInstaller())
        collectJVMProperties(launchDesc.getResources(), paramJREMatcher); 
    } 
  }
  
  public static JREInfo selectJRE(URL paramURL, String paramString) {
    JREDesc jREDesc = new JREDesc(paramString, -1L, -1L, null, paramURL, new ResourcesDesc(), null);
    return selectJRE(jREDesc, new JREMatcher(), false);
  }
  
  public static JREInfo selectJRE(JREDesc paramJREDesc, JREMatcher paramJREMatcher, boolean paramBoolean) {
    JREInfo[] arrayOfJREInfo = JREInfo.getValidSorted();
    if (arrayOfJREInfo == null)
      return null; 
    for (byte b = 0; b < arrayOfJREInfo.length; b++) {
      if (arrayOfJREInfo[b].isEnabled() && paramJREMatcher.isVersionMatch(arrayOfJREInfo[b], paramJREDesc) && (!paramBoolean || arrayOfJREInfo[b].getJfxRuntime() != null))
        return arrayOfJREInfo[b]; 
    } 
    JREInfo jREInfo = JREInfo.getHomeJRE();
    return (paramJREMatcher.isVersionMatch(jREInfo, paramJREDesc) && (!paramBoolean || jREInfo.getJfxRuntime() != null)) ? jREInfo : null;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/LaunchSelection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */