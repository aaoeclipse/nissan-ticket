package com.sun.javaws.security;

import com.sun.applet2.preloader.Preloader;
import com.sun.deploy.config.Config;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.JARSigningException;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.security.CachedCertificatesHelper;
import com.sun.deploy.security.SandboxSecurity;
import com.sun.deploy.security.TrustDecider;
import com.sun.deploy.security.TrustRecorder;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.exceptions.JNLPSigningException;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.exceptions.UnsignedAccessViolationException;
import com.sun.javaws.jnl.ExtensionDesc;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.jnl.ResourceVisitor;
import com.sun.javaws.jnl.ResourcesDesc;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.URL;
import java.security.CodeSigner;
import java.security.CodeSource;
import java.security.GeneralSecurityException;
import java.security.cert.CertPath;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class JNLPSignedResourcesHelper {
  static final String SIGNED_JNLP_FILE_REMOVED_AFTER_SIGNING = "Signed jnlp file removed after signing.";
  
  static final boolean DEBUG = (Config.getDeployDebug() || Config.getPluginDebug());
  
  LaunchDesc mainDesc = null;
  
  private Thread warmupValidationThread = null;
  
  private boolean warmupOk = true;
  
  private static final String SIGNED_JNLP_ENTRY = "JNLP-INF/APPLICATION.JNLP";
  
  private static final String SIGNED_JNLP_TEMPLATE = "JNLP-INF/APPLICATION_TEMPLATE.JNLP";
  
  public JNLPSignedResourcesHelper(LaunchDesc paramLaunchDesc) {
    this.mainDesc = paramLaunchDesc;
    AppPolicy.createInstance(this.mainDesc.getCanonicalHome().getHost());
  }
  
  public synchronized void warmup() {
    if (this.warmupOk) {
      WarmupValidator warmupValidator = new WarmupValidator();
      this.warmupValidationThread = new Thread(warmupValidator);
      this.warmupValidationThread.setDaemon(true);
      this.warmupValidationThread.start();
    } 
  }
  
  public void checkSignedLaunchDesc() throws IOException, JNLPException { checkSignedLaunchDesc(null, null); }
  
  public void checkSignedLaunchDesc(URL paramURL1, URL paramURL2) throws IOException, JNLPException {
    ArrayList<LaunchDesc> arrayList = new ArrayList();
    addExtensions(arrayList, this.mainDesc);
    for (byte b = 0; b < arrayList.size(); b++) {
      LaunchDesc launchDesc = arrayList.get(b);
      checkSignedLaunchDescHelper(launchDesc, paramURL1, paramURL2);
    } 
  }
  
  synchronized void ensureWarmupFinished() {
    if (this.warmupValidationThread != null) {
      try {
        this.warmupValidationThread.join();
      } catch (InterruptedException interruptedException) {
        interruptedException.printStackTrace();
      } 
      this.warmupValidationThread = null;
      this.warmupOk = false;
    } 
  }
  
  public boolean checkSignedResources(Preloader paramPreloader, boolean paramBoolean) throws IOException, JNLPException, ExitException {
    if (TrustRecorder.isAllSigned(this.mainDesc.getCanonicalHome())) {
      Config.getHooks().trackUsage(this.mainDesc.getAppInfo(), this.mainDesc.getMainDeploymentRuleSet());
      return true;
    } 
    if (TrustRecorder.isNotAllSigned(this.mainDesc.getCanonicalHome()))
      return false; 
    ensureWarmupFinished();
    boolean bool = true;
    ArrayList<LaunchDesc> arrayList = new ArrayList();
    addExtensions(arrayList, this.mainDesc);
    for (byte b = 0; b < arrayList.size(); b++) {
      LaunchDesc launchDesc = arrayList.get(b);
      launchDesc.setParentURL(this.mainDesc.getParentURL());
      bool = (checkSignedResourcesHelper(launchDesc, paramPreloader, paramBoolean) && bool) ? true : false;
    } 
    if (!paramBoolean)
      TrustRecorder.recordAllSigned(this.mainDesc.getCanonicalHome(), bool); 
    return bool;
  }
  
  public static void addExtensions(final ArrayList<LaunchDesc> list, LaunchDesc paramLaunchDesc) {
    if (paramLaunchDesc == null)
      return; 
    list.add(paramLaunchDesc);
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc != null)
      resourcesDesc.visit(new ResourceVisitor() {
            public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
              if (!param1ExtensionDesc.isInstaller())
                JNLPSignedResourcesHelper.addExtensions(list, param1ExtensionDesc.getExtensionDesc()); 
            }
          }); 
  }
  
  private void checkSignedLaunchDescHelper(LaunchDesc paramLaunchDesc, URL paramURL1, URL paramURL2) throws IOException, JNLPException {
    byte[] arrayOfByte1 = null;
    byte[] arrayOfByte2 = null;
    JNLPSigningException jNLPSigningException = null;
    try {
      arrayOfByte2 = getSignedJNLPFile(paramLaunchDesc, true);
      if (arrayOfByte2 != null)
        try {
          paramLaunchDesc.checkSigningTemplate(arrayOfByte2);
          if (DEBUG)
            Trace.println("Signed JNLP Template matches LaunchDesc", TraceLevel.SECURITY); 
          return;
        } catch (JNLPSigningException jNLPSigningException1) {
          if (DEBUG)
            Trace.println("Signed JNLP Template fails to match ld", TraceLevel.SECURITY); 
          jNLPSigningException = jNLPSigningException1;
        }  
      arrayOfByte1 = getSignedJNLPFile(paramLaunchDesc, false);
      if (arrayOfByte1 == null) {
        if (jNLPSigningException != null)
          throw jNLPSigningException; 
      } else {
        if (Arrays.equals("Signed jnlp file removed after signing.".getBytes(), arrayOfByte1))
          throw new JNLPSigningException(paramLaunchDesc, "Signed jnlp file removed after signing."); 
        LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(arrayOfByte1, paramURL1, paramURL2, paramLaunchDesc.getLocation());
        if (Trace.isEnabled(TraceLevel.SECURITY)) {
          Trace.println("Downloaded JNLP file: ", TraceLevel.SECURITY);
          Trace.println(paramLaunchDesc.toString(), TraceLevel.SECURITY);
          Trace.println("Signed JNLP file: ", TraceLevel.SECURITY);
          Trace.println(launchDesc.toString(), TraceLevel.SECURITY);
        } 
        paramLaunchDesc.checkSigning(launchDesc);
        return;
      } 
    } catch (LaunchDescException launchDescException) {
      launchDescException.setIsSignedLaunchDesc();
      throw launchDescException;
    } catch (IOException iOException) {
      throw iOException;
    } catch (JNLPException jNLPException) {
      throw jNLPException;
    } 
    if (paramLaunchDesc.getCachedCertificates() != null && paramLaunchDesc.getCachedCertificates()[0].isSignedJNLP())
      throw new JNLPSigningException(paramLaunchDesc, null); 
  }
  
  public static boolean hasProgressResources(ResourcesDesc paramResourcesDesc) {
    JARDesc[] arrayOfJARDesc = paramResourcesDesc.getLocalJarDescs();
    for (byte b = 0; b < arrayOfJARDesc.length; b++) {
      if (arrayOfJARDesc[b].isProgressJar())
        return true; 
    } 
    return false;
  }
  
  private static boolean performSecurityCheckForSandbox(LaunchDesc paramLaunchDesc, Preloader paramPreloader, CodeSource paramCodeSource, boolean paramBoolean) throws ExitException {
    AppInfo appInfo = paramLaunchDesc.getAppInfo();
    try {
      if (paramBoolean)
        appInfo.setPermissionAttrOverride(); 
      SandboxSecurity.isPermissionGranted(paramCodeSource, appInfo, paramLaunchDesc.getMainDeploymentRuleSet(), paramPreloader);
    } catch (SecurityException securityException) {
      throw new ExitException(securityException.getMessage(), securityException, 0);
    } finally {
      appInfo.unsetPermissionAttrOverride();
    } 
    return paramLaunchDesc.isSecureJVMArgs();
  }
  
  private static boolean checkSignedResourcesHelper(LaunchDesc paramLaunchDesc, Preloader paramPreloader, boolean paramBoolean) throws IOException, JNLPException, ExitException {
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return true; 
    if (paramBoolean && !hasProgressResources(resourcesDesc))
      return true; 
    CodeSource codeSource = null;
    if (paramLaunchDesc.isSecure()) {
      codeSource = getMainJarCodeSource(paramLaunchDesc, paramBoolean);
      if (codeSource == null || codeSource.getCertificates() == null || !Config.isJavaVersionAtLeast16())
        return performSecurityCheckForSandbox(paramLaunchDesc, paramPreloader, codeSource, paramBoolean); 
    } 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
    final AtomicBoolean allSigned = new AtomicBoolean(true);
    final AtomicBoolean anySkipped = new AtomicBoolean(false);
    final AtomicBoolean sameCert = new AtomicBoolean(true);
    final AtomicBoolean nonEmptyJarFound = new AtomicBoolean(true);
    final AtomicReference<Object> certChainsRef = new AtomicReference<Object>(null);
    URL uRL = paramLaunchDesc.getCanonicalHome();
    final AtomicInteger jarsCached = new AtomicInteger(0);
    final AtomicReference<Object> unsigned = new AtomicReference<Object>(null);
    SigningInfo signingInfo = null;
    if (DEBUG)
      Trace.println("Validating signatures for " + paramLaunchDesc.getLocation() + " " + paramLaunchDesc.getSourceURL(), TraceLevel.SECURITY); 
    if (paramLaunchDesc.getLocation() != null) {
      URL uRL1 = paramLaunchDesc.getSourceURL();
      if (uRL1 == null)
        uRL1 = paramLaunchDesc.getLocation(); 
      signingInfo = new SigningInfo(uRL1, paramLaunchDesc.getVersion());
    } 
    SigningInfo[] arrayOfSigningInfo = new SigningInfo[arrayOfJARDesc.length];
    boolean bool1 = false;
    boolean bool2 = false;
    for (byte b1 = 0; !bool2 && b1 < arrayOfJARDesc.length; b1++) {
      JARDesc jARDesc = arrayOfJARDesc[b1];
      arrayOfSigningInfo[b1] = new SigningInfo(jARDesc.getLocation(), jARDesc.getVersion());
      if (DEBUG)
        Trace.println("Round 1 (" + b1 + " out of " + arrayOfJARDesc.length + "):" + jARDesc.getLocationString(), TraceLevel.SECURITY); 
      if (arrayOfSigningInfo[b1].isFileKnownToBeNotCached()) {
        if (DEBUG)
          Trace.println("    Skip: " + jARDesc.getLocationString(), TraceLevel.SECURITY); 
        atomicBoolean2.set(true);
      } else {
        bool2 = true;
        if (DEBUG)
          Trace.println("Entry [" + jARDesc.getLocationString() + "] is not prevalidated. Revert to full validation of this JAR.", TraceLevel.SECURITY); 
      } 
    } 
    atomicBoolean4.set(false);
    final AtomicReference<Object> exceptionRef = new AtomicReference<Object>(null);
    final AtomicReference<LaunchDesc> ldRef = new AtomicReference<LaunchDesc>(paramLaunchDesc);
    ArrayList<Callable> arrayList = new ArrayList();
    for (byte b2 = 0; b2 < arrayOfJARDesc.length; b2++) {
      final AtomicReference<JARDesc> jdsRef = new AtomicReference<JARDesc>(arrayOfJARDesc[b2]);
      final AtomicReference<SigningInfo> sInfoRef = new AtomicReference<SigningInfo>(arrayOfSigningInfo[b2]);
      Callable callable = new Callable() {
          public Object call() {
            if (exceptionRef.get() != null || !allSigned.get() || !sameCert.get())
              return null; 
            JARDesc jARDesc = jdsRef.get();
            SigningInfo signingInfo = sInfoRef.get();
            if (signingInfo == null)
              signingInfo = new SigningInfo(jARDesc.getLocation(), jARDesc.getVersion()); 
            if (signingInfo.isFileKnownToBeNotCached()) {
              if (JNLPSignedResourcesHelper.DEBUG)
                Trace.println("    Skip " + jARDesc.getLocationString(), TraceLevel.SECURITY); 
              anySkipped.set(true);
              return null;
            } 
            List list = null;
            try {
              list = signingInfo.check();
            } catch (IOException iOException) {
              exceptionRef.compareAndSet(null, iOException);
              return null;
            } 
            if (signingInfo.isJarKnownToBeEmpty())
              return null; 
            nonEmptyJarFound.set(true);
            if (list == null) {
              synchronized (allSigned) {
                if (allSigned.get()) {
                  allSigned.set(false);
                  unsigned.set(jARDesc.getLocation());
                } 
              } 
              if (((LaunchDesc)ldRef.get()).getSecurityModel() != 0) {
                Resource resource = ResourceProvider.get().getCachedResource(jARDesc.getLocation(), jARDesc.getVersion());
                ResourceProvider.get().markRetired(resource, true);
              } 
              return null;
            } 
            if (!certChainsRef.compareAndSet(null, list)) {
              List list1 = null;
              synchronized (certChainsRef) {
                certChainsRef.set(SigningInfo.overlapChainLists(list, certChainsRef.get()));
                list1 = certChainsRef.get();
              } 
              if (JNLPSignedResourcesHelper.DEBUG)
                Trace.println("Have " + ((list1 == null) ? 0 : list1.size()) + " common certificates after processing " + jARDesc.getLocationString(), TraceLevel.SECURITY); 
              if (list1 == null) {
                sameCert.set(false);
                if (((LaunchDesc)ldRef.get()).getSecurityModel() != 0) {
                  Resource resource = ResourceProvider.get().getCachedResource(jARDesc.getLocation(), jARDesc.getVersion());
                  ResourceProvider.get().markRetired(resource, true);
                } 
              } 
            } 
            jarsCached.incrementAndGet();
            return null;
          }
        };
      arrayList.add(callable);
    } 
    if (arrayList.size() > 0) {
      ExecutorService executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
      try {
        executorService.invokeAll((Collection)arrayList);
      } catch (InterruptedException interruptedException) {
        executorService.shutdownNow();
        throw new RuntimeException(interruptedException);
      } 
      executorService.shutdown();
    } 
    if (!atomicBoolean3.get())
      throw new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.singlecertviolation"), null); 
    if (atomicReference3.get() != null)
      throw new RuntimeException((Throwable)atomicReference3.get()); 
    if (!paramLaunchDesc.isSecure()) {
      if (!atomicBoolean1.get())
        throw new UnsignedAccessViolationException(paramLaunchDesc, (URL)atomicReference2.get(), true); 
      List list1 = (List)atomicReference1.get();
      List list2 = normalizeCertificateList(list1);
      if (paramLaunchDesc.getCachedCertificates() != null) {
        CachedCertificatesHelper[] arrayOfCachedCertificatesHelper = paramLaunchDesc.getCachedCertificates();
        for (byte b = 0; b < arrayOfCachedCertificatesHelper.length; b++)
          checkCachedChain(paramLaunchDesc, list2, arrayOfCachedCertificatesHelper[b].getCertPath()); 
      } 
      if (atomicInteger.get() > 0) {
        CodeSource codeSource1 = null;
        JARDesc jARDesc = paramLaunchDesc.getMainJar();
        URL uRL1 = (jARDesc != null) ? jARDesc.getLocation() : paramLaunchDesc.getCanonicalHome();
        if (Config.isJavaVersionAtLeast15()) {
          codeSource1 = new CodeSource(uRL1, (CodeSigner[])list1.toArray((Object[])new CodeSigner[list1.size()]));
        } else {
          codeSource1 = new CodeSource(uRL1, (Certificate[])list2.toArray((Object[])new Certificate[list2.size()]));
        } 
        long l = AppPolicy.getInstance().grantUnrestrictedAccess(paramLaunchDesc, paramLaunchDesc.getMainDeploymentRuleSet(), codeSource1, paramPreloader, paramBoolean);
        bool1 = true;
      } else {
        bool1 = true;
      } 
    } else {
      return performSecurityCheckForSandbox(paramLaunchDesc, paramPreloader, codeSource, paramBoolean);
    } 
    if (bool1 && !atomicBoolean2.get() && atomicBoolean4.get())
      paramLaunchDesc.setTrusted(); 
    if (DEBUG)
      Trace.println("LD - All JAR files signed: " + uRL, TraceLevel.BASIC); 
    return atomicBoolean1.get();
  }
  
  static byte[] getSignedJNLPFile(LaunchDesc paramLaunchDesc, boolean paramBoolean) throws IOException, JNLPException {
    if (paramLaunchDesc.getResources() == null || paramLaunchDesc.isLibrary())
      return null; 
    JARDesc jARDesc = paramLaunchDesc.getMainJar();
    return (jARDesc == null) ? null : getSignedJNLPBits(jARDesc.getLocation(), jARDesc.getVersion(), paramBoolean);
  }
  
  public static byte[] getSignedJNLPBits(URL paramURL, String paramString, boolean paramBoolean) throws IOException {
    String str = paramBoolean ? "JNLP-INF/APPLICATION_TEMPLATE.JNLP" : "JNLP-INF/APPLICATION.JNLP";
    JarFile jarFile = null;
    try {
      jarFile = new JarFile(ResourceProvider.get().getCachedResourceFilePath(paramURL, paramString), false);
      JarEntry jarEntry = jarFile.getJarEntry(str);
      if (jarEntry == null) {
        Enumeration<JarEntry> enumeration = jarFile.entries();
        while (enumeration.hasMoreElements() && jarEntry == null) {
          JarEntry jarEntry1 = enumeration.nextElement();
          if (jarEntry1.getName().equalsIgnoreCase(str))
            jarEntry = jarEntry1; 
        } 
      } 
      if (jarEntry == null) {
        if (hasSigningEntryForFile(jarFile, str)) {
          Trace.println("Signed jnlp file: " + str + "was removed from jar file: " + paramURL, TraceLevel.SECURITY);
          return "Signed jnlp file removed after signing.".getBytes();
        } 
        return null;
      } 
      byte[] arrayOfByte = new byte[(int)jarEntry.getSize()];
      DataInputStream dataInputStream = new DataInputStream(jarFile.getInputStream(jarEntry));
      dataInputStream.readFully(arrayOfByte, 0, (int)jarEntry.getSize());
      dataInputStream.close();
      return arrayOfByte;
    } finally {
      if (jarFile != null)
        jarFile.close(); 
    } 
  }
  
  private static boolean hasSigningEntryForFile(JarFile paramJarFile, String paramString) {
    Enumeration<JarEntry> enumeration = paramJarFile.entries();
    while (enumeration.hasMoreElements()) {
      JarEntry jarEntry = enumeration.nextElement();
      String str = jarEntry.getName().toUpperCase(Locale.ENGLISH);
      if (str.startsWith("META-INF/") && str.endsWith(".SF"))
        try {
          Manifest manifest = new Manifest(paramJarFile.getInputStream(jarEntry));
          for (String str1 : manifest.getEntries().keySet()) {
            if (paramString.equalsIgnoreCase(str1))
              return true; 
          } 
        } catch (IOException iOException) {
          Trace.ignored(iOException);
        }  
    } 
    return false;
  }
  
  static void checkCachedChain(LaunchDesc paramLaunchDesc, List paramList, CertPath paramCertPath) throws LaunchDescException {
    if (paramList == null)
      return; 
    List<? extends Certificate> list = paramCertPath.getCertificates();
    for (byte b = 0; b < list.size(); b++) {
      Certificate certificate = list.get(b);
      if (!paramList.contains(certificate))
        throw new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.unmatched.embedded.cert"), null); 
    } 
  }
  
  static List normalizeCertificateList(List<CodeSigner> paramList) {
    ArrayList<Certificate> arrayList = new ArrayList();
    if (paramList != null)
      for (byte b = 0; b < paramList.size(); b++) {
        if (Config.isJavaVersionAtLeast15() && paramList.get(b) instanceof CodeSigner) {
          CodeSigner codeSigner = paramList.get(b);
          CertPath certPath = codeSigner.getSignerCertPath();
          if (certPath != null)
            arrayList.addAll(certPath.getCertificates()); 
        } else if (paramList.get(b) instanceof SigningInfo.CertChain) {
          SigningInfo.CertChain certChain = (SigningInfo.CertChain)paramList.get(b);
          arrayList.addAll(Arrays.asList(certChain.getCertificates()));
        } 
      }  
    return Collections.unmodifiableList(arrayList);
  }
  
  private static CodeSource getMainJarCodeSource(LaunchDesc paramLaunchDesc, boolean paramBoolean) {
    Certificate[] arrayOfCertificate = null;
    CodeSigner[] arrayOfCodeSigner = null;
    JARDesc jARDesc = null;
    if (paramBoolean) {
      jARDesc = paramLaunchDesc.getResources().getProgressJar();
    } else {
      jARDesc = paramLaunchDesc.getMainJar();
    } 
    if (jARDesc != null)
      try {
        SigningInfo signingInfo = new SigningInfo(jARDesc.getLocation(), jARDesc.getVersion());
        if (Config.isJavaVersionAtLeast15()) {
          List list = signingInfo.check();
          if (list == null)
            throw new JARSigningException(jARDesc.getLocation(), jARDesc.getVersion(), 3); 
          arrayOfCodeSigner = (CodeSigner[])list.toArray((Object[])new CodeSigner[list.size()]);
        } else {
          List list = normalizeCertificateList(signingInfo.check());
          arrayOfCertificate = (Certificate[])list.toArray((Object[])new Certificate[list.size()]);
        } 
      } catch (SecurityException securityException) {
        throw securityException;
      } catch (Exception exception) {
        Trace.println("Treat jar as unsigned due to exception: " + exception, TraceLevel.SECURITY);
      }  
    return Config.isJavaVersionAtLeast15() ? new CodeSource((jARDesc != null) ? jARDesc.getLocation() : paramLaunchDesc.getCanonicalHome(), arrayOfCodeSigner) : new CodeSource((jARDesc != null) ? jARDesc.getLocation() : paramLaunchDesc.getCanonicalHome(), arrayOfCertificate);
  }
  
  class WarmupValidator implements Runnable {
    public void run() {
      if (JNLPSignedResourcesHelper.DEBUG)
        Trace.println("Staring warmup validation", TraceLevel.SECURITY); 
      ArrayList<LaunchDesc> arrayList = new ArrayList();
      JNLPSignedResourcesHelper.addExtensions(arrayList, JNLPSignedResourcesHelper.this.mainDesc);
      for (byte b = 0; b < arrayList.size(); b++) {
        LaunchDesc launchDesc = arrayList.get(b);
        try {
          processSingleDesc(launchDesc);
        } catch (Exception exception) {
          Trace.ignored(exception);
        } 
      } 
    }
    
    private void processSingleDesc(LaunchDesc param1LaunchDesc) throws GeneralSecurityException, IOException {
      CachedCertificatesHelper[] arrayOfCachedCertificatesHelper = param1LaunchDesc.getCachedCertificates();
      if (arrayOfCachedCertificatesHelper != null)
        for (byte b = 0; b < arrayOfCachedCertificatesHelper.length; b++) {
          X509Certificate[] arrayOfX509Certificate = arrayOfCachedCertificatesHelper[b].getCertPath().getCertificates().toArray(new X509Certificate[0]);
          CodeSource codeSource = new CodeSource(param1LaunchDesc.getCanonicalHome(), (Certificate[])arrayOfX509Certificate);
          TrustDecider.validateChainForWarmup(arrayOfX509Certificate, codeSource, b, param1LaunchDesc.getAppInfo(), param1LaunchDesc.getMainDeploymentRuleSet());
        }  
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/security/JNLPSignedResourcesHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */