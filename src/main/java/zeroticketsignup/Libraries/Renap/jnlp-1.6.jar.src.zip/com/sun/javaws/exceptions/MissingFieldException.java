package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;

public class MissingFieldException extends LaunchDescException {
  private String _field;
  
  private String _launchDescSource;
  
  public MissingFieldException(String paramString1, String paramString2) {
    this._field = paramString2;
    this._launchDescSource = paramString1;
  }
  
  public String getRealMessage() { return !isSignedLaunchDesc() ? ResourceManager.getString("launch.error.missingfield", this._field) : ResourceManager.getString("launch.error.missingfield-signedjnlp", this._field); }
  
  public String getField() { return getMessage(); }
  
  public String getLaunchDescSource() { return this._launchDescSource; }
  
  public String toString() { return "MissingFieldException[ " + getField() + "]"; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/MissingFieldException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */