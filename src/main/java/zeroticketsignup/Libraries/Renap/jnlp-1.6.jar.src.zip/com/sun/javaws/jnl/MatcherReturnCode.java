package com.sun.javaws.jnl;

public class MatcherReturnCode {
  public static final int RESULT_UNDEFINED = 0;
  
  public static final int MATCH_FOUND = 1;
  
  public static final int NO_MATCH_TO_JNLP_FOUND = 2;
  
  public static final int NO_MATCH_TO_DRS_FOUND = 3;
  
  public static final int NO_MATCH_TO_JNLP_AND_DRS_FOUND = 4;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/MatcherReturnCode.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */