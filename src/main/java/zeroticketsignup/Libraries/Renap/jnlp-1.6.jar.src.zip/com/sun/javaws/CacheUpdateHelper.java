package com.sun.javaws;

import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.Platform;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.ui.CacheUpdateProgressDialog;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

public class CacheUpdateHelper {
  private static final char DIRECTORY_TYPE = 'D';
  
  private static final char TEMP_TYPE = 'X';
  
  private static final char VERSION_TYPE = 'V';
  
  private static final char INDIRECT_TYPE = 'I';
  
  private static final char RESOURCE_TYPE = 'R';
  
  private static final char APPLICATION_TYPE = 'A';
  
  private static final char EXTENSION_TYPE = 'E';
  
  private static final char MUFFIN_TYPE = 'P';
  
  private static final char MAIN_FILE_TAG = 'M';
  
  private static final char NATIVELIB_FILE_TAG = 'N';
  
  private static final char TIMESTAMP_FILE_TAG = 'T';
  
  private static final char CERTIFICATE_FILE_TAG = 'C';
  
  private static final char LAP_FILE_TAG = 'L';
  
  private static final char MAPPED_IMAGE_FILE_TAG = 'B';
  
  private static final char MUFFIN_ATTR_FILE_TAG = 'U';
  
  private static final String MUFFIN_PREFIX = "PM";
  
  private static final String MUFFIN_ATTRIBUTE_PREFIX = "PU";
  
  private static final String APP_PREFIX = "AM";
  
  private static final String EXT_PREFIX = "XM";
  
  private static final String LAP_PREFIX = "AL";
  
  private static final String JAR_PREFIX = "RM";
  
  private static final String NATIVE_PREFIX = "RN";
  
  private static final String DIR_PREFIX = "DM";
  
  private static final DateFormat _df = DateFormat.getDateTimeInstance();
  
  private static final LocalInstallHandler _lih = LocalInstallHandler.getInstance();
  
  public static boolean updateCache() {
    String str = Config.getOldJavawsCacheDir();
    File file1 = new File(str);
    File file2 = ResourceProvider.get().getCacheDir();
    try {
      if (file1.exists() && file1.isDirectory() && !file1.equals(file2)) {
        CacheUpdateProgressDialog.showProgress(0, 100);
        Cache.setCleanupEnabled(false);
        File file3 = new File(file1, "splash");
        File file4 = new File(file2, "splash");
        copyDir(file3, file4);
        File file5 = new File(file1, "muffins");
        if (file5.exists() && file5.isDirectory()) {
          File[] arrayOfFile = findFiles(file5, "PM");
          for (byte b = 0; b < arrayOfFile.length; b++) {
            try {
              String str1 = arrayOfFile[b].getName().substring(2);
              File file = new File(arrayOfFile[b].getParentFile(), "PU" + str1);
              if (file.exists()) {
                long[] arrayOfLong = getMuffinAttributes(file);
                URL uRL = deriveURL(file5, arrayOfFile[b], null);
                if (uRL != null)
                  Cache.insertMuffin(uRL, arrayOfFile[b], (int)arrayOfLong[0], arrayOfLong[1]); 
              } 
            } catch (Exception exception) {
              Trace.ignored(exception);
            } 
          } 
        } 
        File file6 = new File(file1, "removed.apps");
        if (file6.exists()) {
          File file = new File(file2, "removed.apps");
          try {
            Cache.copyFile(file6, file);
          } catch (IOException iOException) {
            Trace.ignored(iOException);
          } 
        } 
        File[] arrayOfFile1 = findFiles(file1, "AM");
        File[] arrayOfFile2 = findFiles(file1, "XM");
        File[] arrayOfFile3 = findFiles(file1, "RM");
        File[] arrayOfFile4 = findFiles(file1, "RN");
        int i = arrayOfFile1.length + arrayOfFile2.length + arrayOfFile3.length + arrayOfFile4.length;
        byte b1 = 0;
        byte b2;
        for (b2 = 0; b2 < arrayOfFile1.length; b2++) {
          updateJnlpFile(arrayOfFile1[b2], file1, file2, false);
          CacheUpdateProgressDialog.showProgress(++b1, i);
        } 
        for (b2 = 0; b2 < arrayOfFile2.length; b2++) {
          updateJnlpFile(arrayOfFile2[b2], file1, file2, true);
          CacheUpdateProgressDialog.showProgress(++b1, i);
        } 
        for (b2 = 0; b2 < arrayOfFile3.length; b2++) {
          String str1 = arrayOfFile3[b2].getParent();
          String str2 = arrayOfFile3[b2].getName();
          String str3 = str2.replaceFirst("RM", "RN");
          boolean bool = (new File(str1, str3)).exists();
          updateJarFile(arrayOfFile3[b2], file1, file2, bool);
          CacheUpdateProgressDialog.showProgress(++b1, i);
        } 
      } 
    } catch (com.sun.deploy.ui.CacheUpdateProgressDialog.CanceledException canceledException) {
    
    } catch (Throwable throwable) {
      Trace.ignored(throwable);
    } finally {
      CacheUpdateProgressDialog.dismiss();
      Cache.setCleanupEnabled(true);
    } 
    Config.setStringProperty("deployment.javaws.cachedir", null);
    return true;
  }
  
  private static void updateJnlpFile(File paramFile1, File paramFile2, File paramFile3, boolean paramBoolean) {
    String[] arrayOfString = new String[1];
    URL uRL = deriveURL(paramFile2, paramFile1, arrayOfString);
    if (uRL != null)
      try {
        long l = getTimeStamp(paramFile1);
        boolean bool = true;
        Cache.insertFile(paramFile1, bool, uRL, arrayOfString[0], l, 0L);
        String str = paramFile1.getName().substring(2);
        File file = new File(paramFile1.getParentFile(), "AL" + str);
        if (file.exists()) {
          Properties properties = new Properties();
          BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
          properties.load(bufferedInputStream);
          bufferedInputStream.close();
          updateLapFile(paramFile1, properties, uRL, arrayOfString[0], paramBoolean);
        } 
      } catch (Exception exception) {
        Trace.ignored(exception);
      }  
  }
  
  private static void updateJarFile(File paramFile1, File paramFile2, File paramFile3, boolean paramBoolean) {
    String[] arrayOfString = new String[1];
    URL uRL = deriveURL(paramFile2, paramFile1, arrayOfString);
    if (uRL != null)
      try {
        long l = getTimeStamp(paramFile1);
        int i = 256;
        if (paramBoolean)
          i |= 0x10; 
        Cache.insertFile(paramFile1, i, uRL, arrayOfString[0], l, 0L);
      } catch (Exception exception) {
        Trace.ignored(exception);
      }  
  }
  
  private static void updateLapFile(File paramFile, Properties paramProperties, URL paramURL, String paramString, boolean paramBoolean) {
    LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(paramURL, paramString, !paramBoolean);
    String str1 = paramProperties.getProperty("_default.lastAccessed");
    Date date = new Date();
    if (str1 != null)
      try {
        date = _df.parse(str1);
      } catch (Exception exception) {} 
    localApplicationProperties.setLastAccessed(date);
    String str2 = paramProperties.getProperty("_default.launchCount");
    if (str2 != null && str2 != "0")
      localApplicationProperties.incrementLaunchCount(); 
    localApplicationProperties.setAskedForInstall(true);
    String str3 = paramProperties.getProperty("_default.locallyInstalled");
    String str4 = paramProperties.getProperty("_default.title");
    if (str4 != null)
      Platform.get().addRemoveProgramsRemove(str4, false); 
    String str5 = paramProperties.getProperty("_default.mime.types.");
    String str6 = paramProperties.getProperty("_default.extensions.");
    try {
      if (paramBoolean) {
        if (str3 != null);
      } else {
        LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(paramFile, URLUtil.getBase(paramURL), null, paramURL);
        if (str3 != null && str3.equalsIgnoreCase("true")) {
          boolean bool1 = false;
          boolean bool2 = false;
          String str = paramProperties.getProperty("windows.installedDesktopShortcut");
          if (str != null)
            bool2 = _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("windows.installedStartMenuShortcut");
          if (str != null)
            bool1 = _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("windows.uninstalledStartMenuShortcut");
          if (str != null)
            _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("windows.RContent.shortcuts");
          if (str != null)
            _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("unix.installedDesktopShortcut");
          if (str != null)
            bool2 = _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("unix.installedDirectoryFile");
          if (str != null)
            _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("unix.gnome.installedStartMenuShortcut");
          if (str != null)
            bool1 = _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("unix.gnome.installedUninstallShortcut");
          if (str != null)
            _lih.removeShortcuts(str); 
          str = paramProperties.getProperty("unix.gnome.installedRCShortcut");
          if (str != null)
            _lih.removeShortcuts(str); 
          if (bool2 || bool1)
            _lih.reinstallShortcuts(launchDesc, localApplicationProperties, bool2, bool1); 
        } 
        if (str5 != null || str6 != null) {
          _lih.removeAssociations(launchDesc, localApplicationProperties, str5, str6);
          _lih.reinstallAssociations(launchDesc, localApplicationProperties);
        } 
        _lih.removeFromInstallPanel(launchDesc, localApplicationProperties, false);
        _lih.registerWithInstallPanel(launchDesc, localApplicationProperties);
      } 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } finally {
      try {
        localApplicationProperties.store();
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      } 
    } 
  }
  
  private static long getTimeStamp(File paramFile) {
    try {
      String str = paramFile.getName();
      if (str.charAt(1) == 'M') {
        str = str.replaceFirst("M", "T");
        File file = new File(paramFile.getParentFile(), str);
        BufferedReader bufferedReader = null;
        try {
          FileInputStream fileInputStream = new FileInputStream(file);
          bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
          String str1 = bufferedReader.readLine();
        } catch (IOException iOException) {
          return 0L;
        } finally {
          try {
            if (bufferedReader != null)
              bufferedReader.close(); 
          } catch (IOException iOException) {
            Trace.ignoredException(iOException);
          } 
        } 
      } 
    } catch (Exception exception) {}
    return 0L;
  }
  
  private static URL deriveURL(File paramFile1, File paramFile2, String[] paramArrayOfString) {
    String str = paramFile2.toString().substring(paramFile1.toString().length() + 1);
    StringTokenizer stringTokenizer = new StringTokenizer(str, File.separator);
    try {
      String str1 = stringTokenizer.nextToken();
      if (str1.equals("http") || str1.equals("https")) {
        String str2 = "/";
        String str3 = stringTokenizer.nextToken().substring(1);
        int i = (new Integer(stringTokenizer.nextToken().substring(1))).intValue();
        String str4 = stringTokenizer.nextToken();
        if (str4.startsWith("V")) {
          paramArrayOfString[0] = str4.substring(1);
          str4 = stringTokenizer.nextToken();
        } 
        while (str4.startsWith("DM")) {
          str2 = str2 + str4.substring(2) + "/";
          str4 = stringTokenizer.nextToken();
        } 
        str2 = str2 + str4.substring(2);
        if (i == 80)
          i = -1; 
        return new URL(str1, str3, i, str2);
      } 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
    return null;
  }
  
  private static void copyDir(File paramFile1, File paramFile2) {
    if (paramFile1.exists() && paramFile1.isDirectory()) {
      paramFile2.mkdirs();
      File[] arrayOfFile = paramFile1.listFiles();
      for (byte b = 0; b < arrayOfFile.length; b++) {
        File file = new File(paramFile2, arrayOfFile[b].getName());
        if (arrayOfFile[b].isDirectory()) {
          copyDir(arrayOfFile[b], file);
        } else if (!file.exists()) {
          try {
            Cache.copyFile(arrayOfFile[b], file);
          } catch (IOException iOException) {
            Trace.ignored(iOException);
          } 
        } 
      } 
    } 
  }
  
  private static File[] findFiles(File paramFile, final String prefix) {
    ArrayList<File> arrayList = new ArrayList();
    String[] arrayOfString = paramFile.list(new FilenameFilter() {
          public boolean accept(File param1File, String param1String) {
            try {
              if ((new File(param1File, param1String)).isDirectory())
                return !param1String.startsWith("RN"); 
            } catch (Exception exception) {
              return false;
            } 
            return param1String.startsWith(prefix);
          }
        });
    for (byte b = 0; b < arrayOfString.length; b++) {
      if (arrayOfString[b].startsWith(prefix)) {
        arrayList.add(new File(paramFile, arrayOfString[b]));
      } else {
        File file = new File(paramFile, arrayOfString[b]);
        File[] arrayOfFile = findFiles(file, prefix);
        for (byte b1 = 0; b1 < arrayOfFile.length; b1++)
          arrayList.add(arrayOfFile[b1]); 
      } 
    } 
    return arrayList.toArray(new File[0]);
  }
  
  private static long[] getMuffinAttributes(File paramFile) throws IOException {
    BufferedReader bufferedReader = null;
    long l1 = -1L;
    long l2 = -1L;
    try {
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
      String str = bufferedReader.readLine();
      try {
        l1 = Integer.parseInt(str);
      } catch (NumberFormatException numberFormatException) {
        throw new IOException(numberFormatException.getMessage());
      } 
      str = bufferedReader.readLine();
      try {
        l2 = Long.parseLong(str);
      } catch (NumberFormatException numberFormatException) {
        throw new IOException(numberFormatException.getMessage());
      } 
    } finally {
      if (bufferedReader != null)
        bufferedReader.close(); 
    } 
    return new long[] { l1, l2 };
  }
  
  public static boolean systemUpdateCheck() {
    if (!Environment.isSystemCacheMode())
      return false; 
    long l = Cache.getLastAccessed(true);
    if (l > 0L)
      return false; 
    String str = Config.getSystemCacheDirectory();
    File file1 = new File(str, "javaws");
    File file2 = new File(str, Cache.getCacheVersionString());
    if (!file1.exists() || !file1.isDirectory())
      return false; 
    try {
      CacheUpdateProgressDialog.setSystemCache(true);
      CacheUpdateProgressDialog.showProgress(0, 100);
      Cache.setCleanupEnabled(false);
      File[] arrayOfFile1 = findFiles(file1, "AM");
      File[] arrayOfFile2 = findFiles(file1, "XM");
      File[] arrayOfFile3 = findFiles(file1, "RM");
      File[] arrayOfFile4 = findFiles(file1, "RN");
      int i = arrayOfFile1.length + arrayOfFile2.length + arrayOfFile3.length + arrayOfFile4.length;
      byte b1 = 0;
      byte b2;
      for (b2 = 0; b2 < arrayOfFile1.length; b2++) {
        updateJnlpFile(arrayOfFile1[b2], file1, file2, false);
        CacheUpdateProgressDialog.showProgress(++b1, i);
      } 
      for (b2 = 0; b2 < arrayOfFile2.length; b2++) {
        updateJnlpFile(arrayOfFile2[b2], file1, file2, true);
        CacheUpdateProgressDialog.showProgress(++b1, i);
      } 
      for (b2 = 0; b2 < arrayOfFile3.length; b2++) {
        String str1 = arrayOfFile3[b2].getParent();
        String str2 = arrayOfFile3[b2].getName();
        String str3 = str2.replaceFirst("RM", "RN");
        boolean bool = (new File(str1, str3)).exists();
        updateJarFile(arrayOfFile3[b2], file1, file2, bool);
        CacheUpdateProgressDialog.showProgress(++b1, i);
      } 
    } catch (com.sun.deploy.ui.CacheUpdateProgressDialog.CanceledException canceledException) {
    
    } catch (Throwable throwable) {
      Trace.ignored(throwable);
    } finally {
      CacheUpdateProgressDialog.dismiss();
      Cache.setCleanupEnabled(true);
    } 
    return true;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/CacheUpdateHelper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */