package com.sun.jnlp;

import com.sun.deploy.config.Config;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;

public class JNLPClassLoaderUtil {
  public static JNLPClassLoaderIf getInstance() {
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    if (classLoader instanceof JNLPClassLoaderIf)
      return (JNLPClassLoaderIf)classLoader; 
    JNLPClassLoaderIf jNLPClassLoaderIf = JNLPClassLoader.getInstance();
    if (jNLPClassLoaderIf == null && Config.getDeployDebug())
      Trace.println("JNLPClassLoaderUtil: couldn't find a valid JNLPClassLoaderIf", TraceLevel.NETWORK); 
    return jNLPClassLoaderIf;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/JNLPClassLoaderUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */