package com.sun.javaws;

import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.WinRegistry;
import java.awt.Component;

public class WinExtensionInstallHandler extends ExtensionInstallHandler {
  private static final String KEY_RUNONCE = "Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce";
  
  public boolean doPreRebootActions(Component paramComponent) {
    String str1 = ResourceManager.getString("common.ok_btn");
    String str2 = ResourceManager.getString("common.cancel_btn");
    ToolkitStore.getUI();
    int i = ToolkitStore.getUI().showMessageDialog(paramComponent, null, 3, ResourceManager.getString("extensionInstall.rebootTitle"), null, ResourceManager.getString("extensionInstall.rebootMessage"), null, str1, str2, null);
    ToolkitStore.getUI();
    return (i == 0);
  }
  
  public boolean doReboot() { return WinRegistry.doReboot(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/WinExtensionInstallHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */