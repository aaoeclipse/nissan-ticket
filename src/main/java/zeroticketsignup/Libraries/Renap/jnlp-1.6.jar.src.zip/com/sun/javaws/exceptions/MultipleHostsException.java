package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;

public class MultipleHostsException extends JNLPException {
  public MultipleHostsException() { super(ResourceManager.getString("launch.error.category.security")); }
  
  public String getRealMessage() { return ResourceManager.getString("launch.error.multiplehostsreferences"); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/MultipleHostsException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */