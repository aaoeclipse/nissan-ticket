package com.sun.javaws;

import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.Preloader;
import com.sun.applet2.preloader.event.DownloadErrorEvent;
import com.sun.applet2.preloader.event.DownloadEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.deploy.Environment;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.model.DownloadDelegate;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.perf.DeployPerfUtil;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.security.DeployManifestChecker;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.exceptions.BadFieldException;
import com.sun.javaws.exceptions.FailedDownloadingResourceException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.exceptions.JNLParseException;
import com.sun.javaws.exceptions.LaunchDescException;
import com.sun.javaws.exceptions.MissingFieldException;
import com.sun.javaws.exceptions.MultipleHostsException;
import com.sun.javaws.exceptions.NativeLibViolationException;
import com.sun.javaws.jnl.ExtensionDesc;
import com.sun.javaws.jnl.IconDesc;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LDUpdater;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import com.sun.javaws.jnl.ResourceVisitor;
import com.sun.javaws.jnl.ResourcesDesc;
import com.sun.javaws.progress.PreloaderDelegate;
import com.sun.javaws.security.JNLPSignedResourcesHelper;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.WeakHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class LaunchDownload {
  private final LaunchDesc ld;
  
  public static final String APPCONTEXT_THREADPOOL_KEY = "deploy-launchdownloadthreadpoolinappcontext";
  
  public LaunchDownload(LaunchDesc paramLaunchDesc) { this.ld = paramLaunchDesc; }
  
  public static LaunchDesc updateLaunchDescInCache(LaunchDesc paramLaunchDesc) { return updateLaunchDescInCache(paramLaunchDesc, null, null); }
  
  public static LaunchDesc updateLaunchDescInCache(LaunchDesc paramLaunchDesc, URL paramURL1, URL paramURL2) {
    if (!Cache.isCacheEnabled())
      return paramLaunchDesc; 
    boolean bool = (paramLaunchDesc.getLocation() == null) ? true : false;
    URL uRL = bool ? paramLaunchDesc.getCanonicalHome() : paramLaunchDesc.getLocation();
    try {
      File file = ResourceProvider.get().getCachedJNLPFile(uRL, null);
      if (file == null) {
        Cache.createOrUpdateCacheEntry(uRL, paramLaunchDesc.getBytes());
        URL uRL1 = paramLaunchDesc.getSourceURL();
        if (uRL1 != null && uRL != null && !uRL1.toString().equals(uRL.toString())) {
          Resource resource = ResourceProvider.get().getCachedResource(uRL1, null);
          if (resource != null)
            ResourceProvider.get().markRetired(resource, false); 
        } 
        return paramLaunchDesc;
      } 
      Trace.println("Loaded descriptor from cache at: " + uRL, TraceLevel.BASIC);
      LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(file, paramURL1, paramURL2, null);
      if (paramLaunchDesc.hasIdenticalContent(launchDesc))
        return launchDesc; 
      Cache.createOrUpdateCacheEntry(uRL, paramLaunchDesc.getBytes());
      return paramLaunchDesc;
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
    } catch (BadFieldException badFieldException) {
      Trace.ignoredException((Exception)badFieldException);
    } catch (MissingFieldException missingFieldException) {
      Trace.ignoredException((Exception)missingFieldException);
    } catch (JNLParseException jNLParseException) {
      Trace.ignoredException((Exception)jNLParseException);
    } 
    return paramLaunchDesc;
  }
  
  static LaunchDesc getUpdatedLaunchDesc(URL paramURL1, URL paramURL2, boolean paramBoolean) throws JNLPException, IOException {
    boolean bool;
    ResourceProvider resourceProvider = ResourceProvider.get();
    if (paramURL1 == null)
      return null; 
    Resource resource = resourceProvider.getCachedResource(paramURL1, null);
    if (resource != null) {
      try {
        if (paramBoolean) {
          bool = resourceProvider.checkUpdateAvailable(paramURL1, resource, 1, null);
        } else {
          bool = resourceProvider.isUpdateAvailable(paramURL1, null);
        } 
      } catch (IOException iOException) {
        Trace.ignored(iOException);
        bool = false;
      } 
    } else {
      bool = true;
    } 
    if (!bool) {
      Trace.println("Update JNLP: no update for: " + paramURL1, TraceLevel.BASIC);
      return null;
    } 
    Trace.println("Update JNLP: " + paramURL1 + ", thisCodebase: " + paramURL2, TraceLevel.BASIC);
    File file = null;
    int i = ResourceProvider.get().incrementInternalUse();
    try {
      Resource resource1 = resourceProvider.downloadUpdate(paramURL1, null);
      file = resource1.getDataFile();
    } catch (FileNotFoundException fileNotFoundException) {
      Trace.ignoredException(fileNotFoundException);
    } finally {
      ResourceProvider.get().decrementInternalUse(i);
    } 
    if (file != null) {
      LaunchDesc launchDesc = null;
      try {
        return LaunchDescFactory.buildDescriptor(file, paramURL2, paramURL1, paramURL1);
      } catch (LaunchDescException launchDescException) {
        launchDesc = LaunchDescFactory.buildDescriptor(file);
        if (launchDesc == null)
          throw launchDescException; 
        return launchDesc;
      } 
    } 
    return LaunchDescFactory.buildDescriptor(paramURL1, paramURL1);
  }
  
  public static boolean isJnlpCached(LaunchDesc paramLaunchDesc) {
    try {
      return ResourceProvider.get().isCached(paramLaunchDesc.getCanonicalHome(), null);
    } catch (Exception exception) {
      Trace.ignored(exception);
      return false;
    } 
  }
  
  public boolean isInCache() { return isInCache(false); }
  
  public boolean isInCache(boolean paramBoolean) {
    ResourcesDesc resourcesDesc = this.ld.getResources();
    if (resourcesDesc == null)
      return true; 
    try {
      if (this.ld.getLocation() != null && !ResourceProvider.get().isCached(this.ld.getLocation(), null))
        return false; 
      if (!paramBoolean) {
        boolean bool1 = getCachedExtensions();
        if (!bool1)
          return false; 
      } 
      boolean bool = Environment.isImportMode();
      JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(bool);
      for (byte b = 0; b < arrayOfJARDesc.length; b++) {
        JARDesc jARDesc = arrayOfJARDesc[b];
        Resource resource = ResourceProvider.get().getCachedResource(jARDesc.getLocation(), jARDesc.getVersion());
        if (resource == null)
          return false; 
        if (checkJarFileCorrupted(resource))
          return false; 
      } 
    } catch (JNLPException jNLPException) {
      Trace.ignoredException((Exception)jNLPException);
      return false;
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
      return false;
    } 
    return true;
  }
  
  private static boolean isUpdateAvailable(LaunchDesc paramLaunchDesc) throws JNLPException {
    try {
      return (new LDUpdater(paramLaunchDesc)).isUpdateAvailable();
    } catch (Exception exception) {
      if (exception instanceof JNLPException)
        throw (JNLPException)exception; 
      if (exception.getCause() instanceof JNLPException)
        throw (JNLPException)exception.getCause(); 
      throw new FailedDownloadingResourceException(paramLaunchDesc.getLocation(), null, exception);
    } 
  }
  
  private boolean checkJarFileCorrupted(Resource paramResource) {
    if (paramResource == null || paramResource.getDataFile() == null)
      return true; 
    JarFile jarFile = null;
    try {
      jarFile = new JarFile(paramResource.getDataFile());
      return false;
    } catch (Exception exception) {
      Trace.ignored(exception);
      ResourceProvider.get().markRetired(paramResource, false);
      return true;
    } finally {
      if (jarFile != null)
        try {
          jarFile.close();
        } catch (Exception exception) {} 
    } 
  }
  
  public void downloadExtensions(Preloader paramPreloader, int paramInt, ArrayList paramArrayList) throws IOException, JNLPException { downloadExtensionsHelper(paramPreloader, paramInt, false, paramArrayList); }
  
  public boolean getCachedExtensions() throws IOException, JNLPException { return downloadExtensionsHelper(null, 0, true, null); }
  
  private boolean downloadExtensionsHelper(Preloader paramPreloader, int paramInt, boolean paramBoolean, ArrayList paramArrayList) throws IOException, JNLPException {
    int i = ResourceProvider.get().incrementInternalUse();
    try {
      return _downloadExtensionsHelper(paramPreloader, paramInt, paramBoolean, paramArrayList);
    } finally {
      ResourceProvider.get().decrementInternalUse(i);
    } 
  }
  
  private boolean _downloadExtensionsHelper(Preloader paramPreloader, int paramInt, boolean paramBoolean, ArrayList<File> paramArrayList) throws IOException, JNLPException {
    ResourcesDesc resourcesDesc = this.ld.getResources();
    if (resourcesDesc == null)
      return true; 
    String str = JREInfo.getKnownPlatforms();
    final ArrayList<ExtensionDesc> list = new ArrayList();
    resourcesDesc.visit(new ResourceVisitor() {
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) { list.add(param1ExtensionDesc); }
        });
    paramInt += arrayList.size();
    for (byte b = 0; b < arrayList.size(); b++) {
      ExtensionDesc extensionDesc = arrayList.get(b);
      String str1 = extensionDesc.getName();
      if (str1 == null) {
        str1 = extensionDesc.getLocation().toString();
        int i = str1.lastIndexOf('/');
        if (i > 0)
          str1 = str1.substring(i + 1, str1.length()); 
      } 
      paramInt--;
      if (paramPreloader != null)
        paramPreloader.handleEvent((PreloaderEvent)new DownloadEvent(0, extensionDesc.getLocation(), extensionDesc.getVersion(), str1, paramInt, arrayList.size(), arrayList.size())); 
      Resource resource = ResourceProvider.get().getJreResource(extensionDesc.getLocation(), extensionDesc.getVersion(), !paramBoolean, false, JREInfo.getKnownPlatforms());
      File file = (resource != null) ? resource.getDataFile() : null;
      Trace.println("Downloaded extension: " + extensionDesc.getLocation() + "\n\tcodebase: " + extensionDesc.getCodebase() + "\n\tld parentCodebase: " + this.ld.getCodebase() + "\n\tfile: " + file, TraceLevel.NETWORK);
      if (file == null)
        return false; 
      LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(file, extensionDesc.getCodebase(), extensionDesc.getLocation(), extensionDesc.getLocation());
      boolean bool = false;
      if (launchDesc.getLaunchType() == 3) {
        bool = true;
      } else if (launchDesc.getLaunchType() == 4) {
        LocalApplicationProperties localApplicationProperties = Cache.getLocalApplicationProperties(extensionDesc.getLocation(), extensionDesc.getVersion(), false);
        bool = !localApplicationProperties.isExtensionInstalled() ? true : false;
        if (paramArrayList != null && (isUpdateAvailable(launchDesc) || bool))
          paramArrayList.add(file); 
        if (paramBoolean && bool)
          return false; 
      } else {
        throw new MissingFieldException(launchDesc.getSource(), "<component-desc>|<installer-desc>");
      } 
      if (bool) {
        extensionDesc.setExtensionDesc(launchDesc);
        LaunchDownload launchDownload = new LaunchDownload(launchDesc);
        boolean bool1 = launchDownload.downloadExtensionsHelper(paramPreloader, paramInt, paramBoolean, paramArrayList);
        if (!bool1)
          return false; 
      } 
    } 
    return true;
  }
  
  public static void downloadResource(LaunchDesc paramLaunchDesc, URL paramURL, String paramString, Preloader paramPreloader, boolean paramBoolean) throws IOException, JNLPException {
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return; 
    int i = resourcesDesc.getConcurrentDownloads();
    JARDesc[] arrayOfJARDesc = resourcesDesc.getResource(paramURL, paramString);
    downloadJarFiles(arrayOfJARDesc, paramPreloader, paramBoolean, i);
  }
  
  public static void downloadParts(LaunchDesc paramLaunchDesc, String[] paramArrayOfString, Preloader paramPreloader, boolean paramBoolean) throws IOException, JNLPException {
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return; 
    int i = resourcesDesc.getConcurrentDownloads();
    JARDesc[] arrayOfJARDesc = resourcesDesc.getPartJars(paramArrayOfString);
    downloadJarFiles(arrayOfJARDesc, paramPreloader, paramBoolean, i);
  }
  
  public static void downloadExtensionPart(LaunchDesc paramLaunchDesc, URL paramURL, String paramString, String[] paramArrayOfString, Preloader paramPreloader, boolean paramBoolean) throws IOException, JNLPException {
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return; 
    int i = resourcesDesc.getConcurrentDownloads();
    JARDesc[] arrayOfJARDesc = resourcesDesc.getExtensionPart(paramURL, paramString, paramArrayOfString);
    downloadJarFiles(arrayOfJARDesc, paramPreloader, paramBoolean, i);
  }
  
  public void downloadEagerorAll(boolean paramBoolean1, Preloader paramPreloader, boolean paramBoolean2) throws IOException, JNLPException {
    ResourcesDesc resourcesDesc = this.ld.getResources();
    if (resourcesDesc == null)
      return; 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(paramBoolean1);
    if (!paramBoolean1) {
      JARDesc[] arrayOfJARDesc1 = resourcesDesc.getEagerOrAllJarDescs(true);
      if (arrayOfJARDesc1.length != arrayOfJARDesc.length) {
        HashSet hashSet = new HashSet(Arrays.asList((Object[])arrayOfJARDesc));
        byte b1 = 0;
        for (byte b2 = 0; b2 < arrayOfJARDesc1.length; b2++) {
          URL uRL = arrayOfJARDesc1[b2].getLocation();
          String str = arrayOfJARDesc1[b2].getVersion();
          if (!hashSet.contains(arrayOfJARDesc1[b2]) && ResourceProvider.get().isCached(uRL, str)) {
            b1++;
          } else {
            arrayOfJARDesc1[b2] = null;
          } 
        } 
        if (b1 > 0) {
          JARDesc[] arrayOfJARDesc2 = new JARDesc[arrayOfJARDesc.length + b1];
          System.arraycopy(arrayOfJARDesc, 0, arrayOfJARDesc2, 0, arrayOfJARDesc.length);
          int j = arrayOfJARDesc.length;
          for (byte b = 0; b < arrayOfJARDesc1.length; b++) {
            if (arrayOfJARDesc1[b] != null)
              arrayOfJARDesc2[j++] = arrayOfJARDesc1[b]; 
          } 
          arrayOfJARDesc = arrayOfJARDesc2;
        } 
      } 
    } 
    int i = this.ld.getResources().getConcurrentDownloads();
    Trace.println("LaunchDownload: concurrent downloads from LD: " + i, TraceLevel.NETWORK);
    downloadJarFiles(arrayOfJARDesc, paramPreloader, paramBoolean2, i);
    IconDesc iconDesc = this.ld.getInformation().getIconLocation(48, 0);
    if (iconDesc != null) {
      int j = ResourceProvider.get().incrementInternalUse();
      try {
        ResourceProvider.get().getResource(iconDesc.getLocation(), iconDesc.getVersion(), true, 1, null);
        Trace.println("Downloaded " + iconDesc.getLocation(), TraceLevel.NETWORK);
      } catch (Exception exception) {
        Trace.ignored(exception);
      } finally {
        ResourceProvider.get().decrementInternalUse(j);
      } 
    } 
  }
  
  public static void reverse(JARDesc[] paramArrayOfJARDesc) {
    byte b = 0;
    for (int i = paramArrayOfJARDesc.length - 1; b < i; i--) {
      JARDesc jARDesc = paramArrayOfJARDesc[b];
      paramArrayOfJARDesc[b] = paramArrayOfJARDesc[i];
      paramArrayOfJARDesc[i] = jARDesc;
      b++;
    } 
  }
  
  public static int getDownloadType(JARDesc paramJARDesc) {
    int i = 256;
    if (paramJARDesc.isNativeLib())
      i |= 0x10; 
    if (paramJARDesc.isPack200Enabled())
      i |= 0x1000; 
    if (paramJARDesc.isVersionEnabled())
      i |= 0x10000; 
    return i;
  }
  
  public void prepareCustomProgress(PreloaderDelegate paramPreloaderDelegate, JNLPSignedResourcesHelper paramJNLPSignedResourcesHelper, Runnable paramRunnable1, Runnable paramRunnable2, boolean paramBoolean) { prepareCustomProgress(paramPreloaderDelegate, paramJNLPSignedResourcesHelper, paramRunnable1, paramRunnable2, paramBoolean, true); }
  
  void prepareCustomProgress(final PreloaderDelegate delegate, final JNLPSignedResourcesHelper signingHelper, final Runnable okAction, final Runnable failAction, final boolean doUpdate, boolean paramBoolean2) {
    DeployPerfUtil.put("begining of prepareCustomProgress()");
    delegate.setPreloaderClass(this.ld.getProgressClassName());
    delegate.markLoadingStarted();
    Runnable runnable = new Runnable() {
        public void run() {
          try {
            if (doUpdate)
              LaunchDownload.this.downloadProgressJars(delegate); 
            if (okAction != null)
              okAction.run(); 
            delegate.markLoaded(null);
            signingHelper.warmup();
          } catch (Exception exception) {
            if (exception instanceof RuntimeException)
              exception = (exception.getCause() instanceof Exception) ? (Exception)exception.getCause() : exception; 
            Trace.println("Error preparing preloader : " + exception, TraceLevel.PRELOADER);
            Trace.ignored(exception);
            delegate.markLoaded(exception);
            if (failAction != null)
              failAction.run(); 
          } 
        }
      };
    if (paramBoolean2) {
      Thread thread = new Thread(runnable, "Loading Custom Progress");
      thread.setDaemon(true);
      thread.start();
    } else {
      runnable.run();
    } 
  }
  
  void downloadProgressJars(PreloaderDelegate paramPreloaderDelegate) throws IOException, JNLPException {
    ExecutorService executorService = null;
    List<Future<?>> list = null;
    ResourcesDesc resourcesDesc = this.ld.getResources();
    if (resourcesDesc == null)
      return; 
    executorService = getThreadPool(2);
    if (executorService == null)
      return; 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(false);
    ArrayList<DownloadTask> arrayList = new ArrayList(2);
    for (byte b = 0; b < arrayOfJARDesc.length; b++) {
      JARDesc jARDesc = arrayOfJARDesc[b];
      if (jARDesc.isProgressJar()) {
        DownloadTask downloadTask = new DownloadTask(jARDesc.getLocation(), null, jARDesc.getVersion(), null, true, getDownloadType(jARDesc), null, null, null);
        if (!arrayList.contains(downloadTask))
          arrayList.add(downloadTask); 
      } 
    } 
    if (arrayList.size() > 0) {
      try {
        list = executorService.invokeAll((Collection)arrayList);
      } catch (InterruptedException interruptedException) {
        Trace.ignored(interruptedException);
        executorService.shutdownNow();
      } 
      executorService.shutdown();
      validateResults(list, arrayList, null);
    } 
  }
  
  private static void downloadJarFiles(JARDesc[] paramArrayOfJARDesc, Preloader paramPreloader, boolean paramBoolean, int paramInt) throws JNLPException, IOException {
    if (paramArrayOfJARDesc == null)
      return; 
    DeployPerfUtil.put("LaunchDownload.downloadJarFiles - begin");
    if (Globals.isReverseMode())
      reverse(paramArrayOfJARDesc); 
    long l = 0L;
    DownloadCallbackHelper downloadCallbackHelper = DownloadCallbackHelper.get(paramPreloader);
    byte b1 = 0;
    boolean bool = true;
    byte b2;
    for (b2 = 0; b2 < paramArrayOfJARDesc.length; b2++) {
      int i = paramArrayOfJARDesc[b2].getSize();
      if (!paramArrayOfJARDesc[b2].isProgressJar())
        if (i > 0) {
          b1++;
          l += i;
        } else {
          bool = false;
        }  
    } 
    b2 = 0;
    for (byte b3 = 0; b3 < paramArrayOfJARDesc.length; b3++) {
      int i = paramArrayOfJARDesc[b3].getSize();
      if (!paramArrayOfJARDesc[b3].isProgressJar()) {
        if (i <= 0) {
          downloadCallbackHelper.register(paramArrayOfJARDesc[b3].getLocation().toString(), paramArrayOfJARDesc[b3].getVersion(), 0, 1.0D);
        } else if (i > 0) {
          downloadCallbackHelper.register(paramArrayOfJARDesc[b3].getLocation().toString(), paramArrayOfJARDesc[b3].getVersion(), i, 0.5D + (i * b1) / l);
        } 
        b2++;
      } 
    } 
    if (!bool)
      l = -1L; 
    Trace.println("Total size to download: " + l, TraceLevel.NETWORK);
    if (l == 0L)
      return; 
    downloadCallbackHelper.setTotalSize(l);
    downloadCallbackHelper.setNumOfJars(paramArrayOfJARDesc.length);
    int[] arrayOfInt = new int[1];
    arrayOfInt[0] = 0;
    ExecutorService executorService = getThreadPool(paramInt);
    if (executorService != null) {
      ToolkitStore.get().getAppContext().put("deploy-launchdownloadthreadpoolinappcontext", executorService);
      downloadCallbackHelper.setNumOfJars(b2);
    } 
    ArrayList<DownloadTask> arrayList = new ArrayList(paramArrayOfJARDesc.length);
    for (byte b4 = 0; b4 < paramArrayOfJARDesc.length; b4++) {
      JARDesc jARDesc = paramArrayOfJARDesc[b4];
      int i = ResourceProvider.get().incrementInternalUse();
      try {
        int j = getDownloadType(jARDesc);
        if (executorService == null) {
          Resource resource = ResourceProvider.get().getResource(jARDesc.getLocation(), jARDesc.getVersion(), true, j, downloadCallbackHelper);
          arrayOfInt[0] = arrayOfInt[0] + 1;
          downloadCallbackHelper.setJarsDone(arrayOfInt[0]);
          if (Cache.isCacheEnabled() && resource == null && !Environment.isImportMode())
            throw new FailedDownloadingResourceException(null, jARDesc.getLocation(), jARDesc.getVersion(), null); 
        } else if (!jARDesc.isProgressJar()) {
          DownloadTask downloadTask = new DownloadTask(jARDesc.getLocation(), null, jARDesc.getVersion(), downloadCallbackHelper, true, j, paramPreloader, arrayOfInt, downloadCallbackHelper);
          if (!arrayList.contains(downloadTask))
            arrayList.add(downloadTask); 
        } 
      } catch (JNLPException jNLPException) {
        if (paramPreloader != null)
          paramPreloader.handleEvent((PreloaderEvent)new DownloadErrorEvent(jARDesc.getLocation(), jARDesc.getVersion())); 
        throw jNLPException;
      } finally {
        ResourceProvider.get().decrementInternalUse(i);
      } 
    } 
    List<Future<?>> list = null;
    try {
      if (executorService != null)
        list = executorService.invokeAll((Collection)arrayList); 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
    if (executorService != null) {
      ToolkitStore.get().getAppContext().remove("deploy-launchdownloadthreadpoolinappcontext");
      executorService.shutdown();
      validateResults(list, arrayList, paramPreloader);
    } 
    DeployPerfUtil.put("LaunchDownload.downloadJarFiles - end");
  }
  
  private static void validateResults(List paramList, ArrayList<DownloadTask> paramArrayList, Preloader paramPreloader) throws IOException, JNLPException {
    if (paramList != null) {
      byte b = 0;
      for (Future future : paramList) {
        URL uRL = ((DownloadTask)paramArrayList.get(b)).getURL();
        String str = ((DownloadTask)paramArrayList.get(b)).getVersion();
        b++;
        try {
          future.get();
        } catch (ExecutionException executionException) {
          Throwable throwable = executionException.getCause();
          if (null != throwable) {
            if (throwable instanceof IOException) {
              if (paramPreloader != null)
                paramPreloader.handleEvent((PreloaderEvent)new DownloadErrorEvent(uRL, str, throwable)); 
              throw (IOException)throwable;
            } 
            if (throwable instanceof JNLPException) {
              if (paramPreloader != null)
                paramPreloader.handleEvent((PreloaderEvent)new DownloadErrorEvent(uRL, str)); 
              throw (JNLPException)throwable;
            } 
            throw new IOException("JNLP Jar download failure.");
          } 
        } catch (InterruptedException interruptedException) {
          Trace.ignored(interruptedException);
        } 
      } 
    } 
  }
  
  private static synchronized void notifyProgress(DownloadCallbackHelper paramDownloadCallbackHelper, int[] paramArrayOfint, URL paramURL) {
    if (paramArrayOfint != null && paramDownloadCallbackHelper != null) {
      paramArrayOfint[0] = paramArrayOfint[0] + 1;
      Trace.println("Download Progress: jarsDone: " + paramArrayOfint[0], TraceLevel.NETWORK);
      paramDownloadCallbackHelper.jarDone(paramURL);
      paramDownloadCallbackHelper.setJarsDone(paramArrayOfint[0]);
    } 
  }
  
  private static ExecutorService getThreadPool(int paramInt) { return Config.isJavaVersionAtLeast15() ? Executors.newFixedThreadPool(paramInt, new ThreadFactory() {
          public Thread newThread(Runnable param1Runnable) {
            Thread thread = new Thread(param1Runnable);
            thread.setDaemon(true);
            return thread;
          }
        }) : null; }
  
  public static void checkJNLPSecurity(LaunchDesc paramLaunchDesc) throws MultipleHostsException, NativeLibViolationException {
    boolean[] arrayOfBoolean1 = new boolean[1];
    boolean[] arrayOfBoolean2 = new boolean[1];
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return; 
    JARDesc jARDesc = paramLaunchDesc.getMainJar();
    if (jARDesc == null)
      return; 
    checkJNLPSecurityHelper(paramLaunchDesc, jARDesc.getLocation().getHost(), arrayOfBoolean2, arrayOfBoolean1);
    if (arrayOfBoolean2[0])
      throw new MultipleHostsException(); 
    if (arrayOfBoolean1[0])
      throw new NativeLibViolationException(); 
  }
  
  private static void checkJNLPSecurityHelper(LaunchDesc paramLaunchDesc, final String host, final boolean[] hostViolation, final boolean[] nativeLibViolation) {
    if (paramLaunchDesc.getSecurityModel() != 0)
      return; 
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return; 
    resourcesDesc.visit(new ResourceVisitor() {
          public void visitJARDesc(JARDesc param1JARDesc) {
            String str = param1JARDesc.getLocation().getHost();
            hostViolation[0] = (hostViolation[0] || !host.equals(str));
            nativeLibViolation[0] = (nativeLibViolation[0] || param1JARDesc.isNativeLib());
          }
          
          public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
            if (!hostViolation[0] && !nativeLibViolation[0]) {
              LaunchDesc launchDesc = param1ExtensionDesc.getExtensionDesc();
              String str = param1ExtensionDesc.getLocation().getHost();
              if (launchDesc != null && launchDesc.getSecurityModel() == 0 && !hostViolation[0])
                LaunchDownload.checkJNLPSecurityHelper(launchDesc, str, hostViolation, nativeLibViolation); 
            } 
          }
        });
  }
  
  public static long getCachedSize(LaunchDesc paramLaunchDesc) {
    long l = 0L;
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    if (resourcesDesc == null)
      return l; 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(true);
    for (byte b = 0; b < arrayOfJARDesc.length; b++) {
      Resource resource = ResourceProvider.get().getCachedResource(arrayOfJARDesc[b].getLocation(), arrayOfJARDesc[b].getVersion());
      if (resource != null)
        l += resource.getSize(); 
    } 
    IconDesc[] arrayOfIconDesc = paramLaunchDesc.getInformation().getIcons();
    if (arrayOfIconDesc != null)
      for (byte b1 = 0; b1 < arrayOfIconDesc.length; b1++) {
        Resource resource = ResourceProvider.get().getCachedResource(arrayOfIconDesc[b1].getLocation(), arrayOfIconDesc[b1].getVersion());
        if (resource != null)
          l += resource.getSize(); 
      }  
    return l;
  }
  
  static String getMainClassName(LaunchDesc paramLaunchDesc) throws IOException, JNLPException, LaunchDescException {
    String str = null;
    str = paramLaunchDesc.getMainClassName();
    if (str != null && str.length() == 0)
      str = null; 
    if (paramLaunchDesc.getResources() == null)
      return null; 
    JARDesc jARDesc = paramLaunchDesc.getMainJar();
    if (jARDesc == null)
      return null; 
    JarFile jarFile = null;
    Manifest manifest = null;
    try {
      jarFile = new JarFile(ResourceProvider.get().getCachedJNLPFile(jARDesc.getLocation(), jARDesc.getVersion()), false);
      if (jarFile != null && paramLaunchDesc.getLaunchType() != 2) {
        manifest = jarFile.getManifest();
        if (manifest != null)
          str = DeployManifestChecker.verifyMainClass(str, manifest.getMainAttributes()); 
      } 
      if (str == null)
        throw new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.nomainclassspec"), null); 
      String str1 = (manifest == null) ? null : manifest.getMainAttributes().getValue(Attributes.Name.MAIN_CLASS);
      if (str1 == null)
        return str; 
      String str2 = str.replace('.', '/') + ".class";
      if (jarFile.getEntry(str2) == null)
        throw new LaunchDescException(paramLaunchDesc, ResourceManager.getString("launch.error.nomainclass", str, jARDesc.getLocation().toString()), null); 
      return str;
    } finally {
      if (jarFile != null)
        jarFile.close(); 
    } 
  }
  
  public static boolean inCache(JARDesc paramJARDesc) { return ResourceProvider.get().isCached(paramJARDesc.getLocation(), paramJARDesc.getVersion()); }
  
  private static class DownloadCallbackHelper implements DownloadDelegate {
    Preloader _preloader;
    
    long _totalSize = -1L;
    
    final ArrayList _records;
    
    int _numOfJars = 1;
    
    int _jarsDone = 0;
    
    private static WeakHashMap helpers = new WeakHashMap<Object, Object>();
    
    private DownloadCallbackHelper(Preloader param1Preloader) {
      this._preloader = param1Preloader;
      this._records = new ArrayList();
    }
    
    static DownloadCallbackHelper get(Preloader param1Preloader) {
      DownloadCallbackHelper downloadCallbackHelper = (DownloadCallbackHelper)helpers.get(param1Preloader);
      if (downloadCallbackHelper == null) {
        downloadCallbackHelper = new DownloadCallbackHelper(param1Preloader);
        helpers.put(param1Preloader, downloadCallbackHelper);
      } 
      return downloadCallbackHelper;
    }
    
    public void register(String param1String1, String param1String2, int param1Int, double param1Double) {
      LaunchDownload.ProgressRecord progressRecord = getProgressRecord(param1String1);
      if (progressRecord == null) {
        progressRecord = new LaunchDownload.ProgressRecord(param1String1, param1String2, param1Int);
        progressRecord.setWeight(param1Double);
        synchronized (this._records) {
          this._records.add(progressRecord);
        } 
      } else {
        progressRecord.setWeight(param1Double);
        progressRecord.setSize(param1Int);
      } 
    }
    
    public void setTotalSize(long param1Long) { this._totalSize = param1Long; }
    
    public void setNumOfJars(int param1Int) { this._numOfJars = param1Int; }
    
    public void setJarsDone(int param1Int) { this._jarsDone = param1Int; }
    
    public void downloading(URL param1URL, String param1String, int param1Int1, int param1Int2, boolean param1Boolean) throws CancelException {
      if (this._preloader != null) {
        String str = param1URL.toString();
        LaunchDownload.ProgressRecord progressRecord = getProgressRecord(str);
        if (progressRecord == null) {
          progressRecord = new LaunchDownload.ProgressRecord(str, param1String, param1Int2);
          synchronized (this._records) {
            this._records.add(progressRecord);
          } 
        } else {
          progressRecord.setSize(param1Int2);
        } 
        progressRecord.downloadProgress(param1Int1);
        int i = getOverallPercent();
        this._preloader.handleEvent((PreloaderEvent)new DownloadEvent(0, param1URL, param1String, null, param1Int1, param1Int2, i));
      } 
    }
    
    public void patching(URL param1URL, String param1String, int param1Int) throws CancelException {
      if (this._preloader != null) {
        String str = param1URL.toString();
        LaunchDownload.ProgressRecord progressRecord = getProgressRecord(str);
        if (progressRecord != null) {
          progressRecord.patchProgress(param1Int);
          int i = getOverallPercent();
          this._preloader.handleEvent((PreloaderEvent)new DownloadEvent(2, param1URL, param1String, null, param1Int, 100L, i));
        } 
      } 
    }
    
    public void validating(URL param1URL, int param1Int1, int param1Int2) throws CancelException {
      if (this._preloader != null) {
        String str = param1URL.toString();
        LaunchDownload.ProgressRecord progressRecord = getProgressRecord(str);
        if (progressRecord != null) {
          progressRecord.cacheTotalElements(param1Int2);
          progressRecord.validateProgress(param1Int1, param1Int2);
          int i = getOverallPercent();
          this._preloader.handleEvent((PreloaderEvent)new DownloadEvent(1, param1URL, null, null, param1Int1, param1Int2, i));
        } 
      } 
    }
    
    public LaunchDownload.ProgressRecord getProgressRecord(String param1String) {
      synchronized (this._records) {
        for (LaunchDownload.ProgressRecord progressRecord : this._records) {
          if (param1String != null && param1String.equals(progressRecord.getUrl()))
            return progressRecord; 
        } 
      } 
      return null;
    }
    
    public int getOverallPercent() {
      double d1 = 0.0D;
      double d2 = 0.0D;
      synchronized (this._records) {
        for (LaunchDownload.ProgressRecord progressRecord : this._records) {
          d1 += progressRecord.getPercent() * progressRecord.getWeight();
          d2 += progressRecord.getWeight();
        } 
      } 
      int i = (int)(d1 * 100.0D / d2);
      if (i > 100)
        i = 100; 
      return i;
    }
    
    public void downloadFailed(URL param1URL, String param1String) {
      if (this._preloader != null)
        try {
          this._preloader.handleEvent((PreloaderEvent)new DownloadErrorEvent(param1URL, param1String));
        } catch (CancelException cancelException) {} 
    }
    
    void jarDone(URL param1URL) {
      if (this._preloader != null) {
        String str = param1URL.toString();
        LaunchDownload.ProgressRecord progressRecord = getProgressRecord(str);
        if (progressRecord != null && progressRecord.getPercent() < 1.0D) {
          progressRecord.markComplete();
          int i = getOverallPercent();
          try {
            this._preloader.handleEvent((PreloaderEvent)new DownloadEvent(1, param1URL, null, null, progressRecord.getCachedTotalElements(), progressRecord.getCachedTotalElements(), i));
          } catch (CancelException cancelException) {}
        } 
      } 
    }
  }
  
  private static class DownloadTask implements Callable {
    private URL url;
    
    private int downloadType;
    
    private String resourceID;
    
    private String versionString;
    
    private DownloadDelegate dd;
    
    private final boolean doDownload;
    
    private Preloader dp;
    
    private int[] counterBox;
    
    private LaunchDownload.DownloadCallbackHelper dch;
    
    public DownloadTask(URL param1URL, String param1String1, String param1String2, DownloadDelegate param1DownloadDelegate, boolean param1Boolean, int param1Int, Preloader param1Preloader, int[] param1ArrayOfint, LaunchDownload.DownloadCallbackHelper param1DownloadCallbackHelper) {
      this.url = param1URL;
      this.downloadType = param1Int;
      this.resourceID = param1String1;
      this.versionString = param1String2;
      this.dd = param1DownloadDelegate;
      this.doDownload = param1Boolean;
      this.dp = param1Preloader;
      this.counterBox = param1ArrayOfint;
      this.dch = param1DownloadCallbackHelper;
    }
    
    public URL getURL() { return this.url; }
    
    public String getVersion() { return this.versionString; }
    
    public int hashCode() { return (this.url == null) ? 0 : this.url.hashCode(); }
    
    public String toString() { return this.url.toString() + ((this.versionString != null) ? (":" + this.versionString) : ""); }
    
    public boolean equals(Object param1Object) {
      if (param1Object instanceof DownloadTask) {
        DownloadTask downloadTask = (DownloadTask)param1Object;
        URL uRL = downloadTask.getURL();
        String str = downloadTask.getVersion();
        if (this.url.toString().equals(uRL.toString())) {
          if (this.versionString == null && str == null)
            return true; 
          if (this.versionString != null && str != null && this.versionString.equals(str))
            return true; 
        } 
      } 
      return false;
    }
    
    public Object call() throws IOException, JNLPException {
      int i = ResourceProvider.get().incrementInternalUse();
      try {
        Resource resource = ResourceProvider.get().getResource(this.url, this.versionString, this.doDownload, this.downloadType, this.dch);
        URL uRL = (resource != null) ? URLUtil.fileToURL(resource.getDataFile()) : null;
        if (Cache.isCacheEnabled() && uRL == null && !Environment.isImportMode())
          throw new FailedDownloadingResourceException(null, this.url, this.versionString, null); 
        LaunchDownload.notifyProgress(this.dch, this.counterBox, this.url);
      } finally {
        ResourceProvider.get().decrementInternalUse(i);
      } 
      return null;
    }
  }
  
  private static class ProgressRecord {
    private String _url;
    
    private String _ver;
    
    private int _size;
    
    private double _percent;
    
    private int _totalElements = 1;
    
    private double _weight;
    
    public ProgressRecord(String param1String1, String param1String2, int param1Int) {
      this._url = param1String1;
      this._ver = param1String2;
      this._size = param1Int;
      this._weight = 1.0D;
      this._percent = 0.0D;
    }
    
    void cacheTotalElements(int param1Int) { this._totalElements = param1Int; }
    
    int getCachedTotalElements() { return this._totalElements; }
    
    void setWeight(double param1Double) { this._weight = param1Double; }
    
    void setSize(int param1Int) { this._size = param1Int; }
    
    double getPercent() { return this._percent; }
    
    String getUrl() { return this._url; }
    
    public int hashCode() {
      null = 7;
      return 79 * null + ((this._url != null) ? this._url.hashCode() : 0);
    }
    
    public boolean equals(Object param1Object) { return this._url.equals(((ProgressRecord)param1Object)._url); }
    
    double getWeight() { return this._weight; }
    
    void downloadProgress(int param1Int) {
      if (this._size != 0) {
        this._percent = param1Int / this._size * 0.8D;
      } else {
        this._percent = 0.8D;
      } 
    }
    
    void patchProgress(int param1Int) { this._percent = param1Int / 100.0D * 0.1D + 0.8D; }
    
    void validateProgress(int param1Int1, int param1Int2) {
      if (param1Int2 != 0) {
        this._percent = param1Int1 / param1Int2 * 0.05D + 0.9D;
      } else {
        this._percent = 0.95D;
      } 
    }
    
    private void markComplete() { this._percent = 1.0D; }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/LaunchDownload.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */