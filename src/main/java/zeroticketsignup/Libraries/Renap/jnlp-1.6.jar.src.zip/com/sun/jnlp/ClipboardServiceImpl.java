package com.sun.jnlp;

import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.javaws.util.JNLPUtils;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.ClipboardService;

public final class ClipboardServiceImpl implements ClipboardService {
  private static ClipboardServiceImpl _sharedInstance = null;
  
  private Clipboard _sysClipboard = null;
  
  private ApiDialog _readDialog = null;
  
  private ApiDialog _writeDialog = null;
  
  private ClipboardServiceImpl() {
    this._readDialog = new ApiDialog();
    this._writeDialog = new ApiDialog();
    Toolkit toolkit = Toolkit.getDefaultToolkit();
    if (toolkit != null)
      this._sysClipboard = toolkit.getSystemClipboard(); 
  }
  
  public static synchronized ClipboardServiceImpl getInstance() {
    if (_sharedInstance == null)
      _sharedInstance = new ClipboardServiceImpl(); 
    return _sharedInstance;
  }
  
  public Transferable getContents() { return !askUser(false) ? null : AccessController.doPrivileged(new PrivilegedAction<Transferable>() {
          public Transferable run() { return ClipboardServiceImpl.this._sysClipboard.getContents(null); }
        }); }
  
  public void setContents(final Transferable contents) {
    if (!askUser(true))
      return; 
    AccessController.doPrivileged(new PrivilegedAction<Void>() {
          public Void run() {
            if (contents != null) {
              DataFlavor[] arrayOfDataFlavor = contents.getTransferDataFlavors();
              if (arrayOfDataFlavor == null || arrayOfDataFlavor[0] == null)
                return null; 
              try {
                if (contents.getTransferData(arrayOfDataFlavor[0]) == null)
                  return null; 
              } catch (IOException iOException) {
                Trace.ignoredException(iOException);
              } catch (UnsupportedFlavorException unsupportedFlavorException) {
                Trace.ignoredException(unsupportedFlavorException);
              } 
            } 
            ClipboardServiceImpl.this._sysClipboard.setContents(contents, null);
            return null;
          }
        });
  }
  
  private synchronized boolean askUser(boolean paramBoolean) {
    if (!hasClipboard())
      return false; 
    if (CheckServicePermission.hasClipboardPermissions())
      return true; 
    String str3 = ResourceManager.getString("api.clipboard.title");
    if (paramBoolean) {
      String str4 = ResourceManager.getString("api.clipboard.message.write");
      String str5 = ResourceManager.getString("api.clipboard.write.always");
      return askUser(this._writeDialog, str3, str4, str5, "jnlp.api.always.ClipboardService.write");
    } 
    String str1 = ResourceManager.getString("api.clipboard.message.read");
    String str2 = ResourceManager.getString("api.clipboard.read.always");
    return askUser(this._readDialog, str3, str1, str2, "jnlp.api.always.ClipboardService.read");
  }
  
  private static boolean askUser(ApiDialog paramApiDialog, String paramString1, String paramString2, String paramString3, final String key) {
    final LocalApplicationProperties lap = JNLPUtils.getLocalApplicationProperties();
    if (localApplicationProperties != null) {
      String str = localApplicationProperties.get(key);
      if (str != null)
        return true; 
    } 
    ApiDialog.DialogResult dialogResult = paramApiDialog.askUser(paramString1, paramString2, paramString3);
    if (dialogResult == ApiDialog.DialogResult.ALWAYS)
      AccessController.doPrivileged(new PrivilegedAction<Void>() {
            public Void run() {
              lap.put(key, "skip");
              try {
                lap.store();
              } catch (Throwable throwable) {
                Trace.ignored(throwable);
              } 
              return null;
            }
          }); 
    return (dialogResult == ApiDialog.DialogResult.OK || dialogResult == ApiDialog.DialogResult.ALWAYS);
  }
  
  private boolean hasClipboard() { return (this._sysClipboard != null); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/ClipboardServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */