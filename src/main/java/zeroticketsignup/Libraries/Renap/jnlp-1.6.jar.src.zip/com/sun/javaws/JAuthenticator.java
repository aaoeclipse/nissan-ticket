package com.sun.javaws;

import com.sun.deploy.config.Config;
import com.sun.deploy.security.DeployAuthenticator;
import com.sun.deploy.uitoolkit.ui.ComponentRef;
import java.net.PasswordAuthentication;

public class JAuthenticator extends DeployAuthenticator {
  private static JAuthenticator _instance;
  
  private boolean _challanging = false;
  
  private boolean _cancel = false;
  
  public static synchronized JAuthenticator getInstance(ComponentRef paramComponentRef) {
    if (_instance == null)
      _instance = new JAuthenticator(); 
    _instance.setParentComponent(paramComponentRef);
    return _instance;
  }
  
  protected synchronized PasswordAuthentication getPasswordAuthentication() {
    PasswordAuthentication passwordAuthentication = null;
    if (Config.getBooleanProperty("deployment.security.authenticator")) {
      this._challanging = true;
      passwordAuthentication = super.getPasswordAuthentication();
      this._challanging = false;
    } 
    return passwordAuthentication;
  }
  
  public boolean isChallanging() { return this._challanging; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/JAuthenticator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */