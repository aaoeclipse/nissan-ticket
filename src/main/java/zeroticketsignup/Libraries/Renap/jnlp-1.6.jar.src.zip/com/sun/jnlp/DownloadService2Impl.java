package com.sun.jnlp;

import com.sun.deploy.cache.Cache;
import com.sun.deploy.cache.CacheEntry;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.DownloadEngine;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.LaunchDescFactory;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import javax.jnlp.DownloadService2;

public class DownloadService2Impl implements DownloadService2 {
  private static DownloadService2Impl instance;
  
  private static ResourceSpecAccess resourceSpecAccess;
  
  public static synchronized DownloadService2 getInstance() {
    if (instance == null)
      instance = new DownloadService2Impl(); 
    return instance;
  }
  
  public static void setResourceSpecAccess(ResourceSpecAccess paramResourceSpecAccess) { resourceSpecAccess = paramResourceSpecAccess; }
  
  public DownloadService2.ResourceSpec[] getCachedResources(final DownloadService2.ResourceSpec spec) {
    validateResourceSpec(spec);
    final ArrayList matchingResources = new ArrayList();
    AccessController.doPrivileged(new PrivilegedAction() {
          public Object run() {
            DownloadService2Impl.this.getCachedResourcesImpl(spec, matchingResources);
            return null;
          }
        });
    return (DownloadService2.ResourceSpec[])arrayList.toArray((Object[])new DownloadService2.ResourceSpec[arrayList.size()]);
  }
  
  private void getCachedResourcesImpl(DownloadService2.ResourceSpec paramResourceSpec, ArrayList<DownloadService2.ResourceSpec> paramArrayList) {
    File[] arrayOfFile = Cache.getCacheEntries(false);
    for (File file : arrayOfFile) {
      CacheEntry cacheEntry = Cache.getCacheEntryFromFile(file);
      if (matches(cacheEntry, paramResourceSpec))
        paramArrayList.add(toResourceSpec(cacheEntry)); 
    } 
  }
  
  private boolean matches(CacheEntry paramCacheEntry, DownloadService2.ResourceSpec paramResourceSpec) {
    if (paramCacheEntry == null || paramCacheEntry.getURL() == null || paramCacheEntry.getURL().trim().length() == 0)
      return false; 
    boolean bool = false;
    String str = paramResourceSpec.getUrl();
    if (str != null) {
      String str1 = paramResourceSpec.getVersion();
      String str2 = paramCacheEntry.getVersion();
      int i = paramResourceSpec.getType();
      boolean bool1 = (i == 0 || i == getResourceType(paramCacheEntry)) ? true : false;
      boolean bool2 = ((str1 == null && str2 == null) || (str1 != null && str2 != null && str2.matches(str1))) ? true : false;
      bool = (paramCacheEntry.getURL().matches(str) && bool2 && bool1) ? true : false;
    } 
    return bool;
  }
  
  private DownloadService2.ResourceSpec toResourceSpec(CacheEntry paramCacheEntry) {
    DownloadService2.ResourceSpec resourceSpec = new DownloadService2.ResourceSpec(paramCacheEntry.getURL(), paramCacheEntry.getVersion(), getResourceType(paramCacheEntry));
    resourceSpecAccess.setSize(resourceSpec, paramCacheEntry.getSize());
    resourceSpecAccess.setLastModified(resourceSpec, paramCacheEntry.getLastModified());
    resourceSpecAccess.setExpirationDate(resourceSpec, paramCacheEntry.getExpirationDate());
    return resourceSpec;
  }
  
  private int getResourceType(CacheEntry paramCacheEntry) {
    String str1 = paramCacheEntry.getURL();
    String str2 = getLowerNameExtension(str1);
    byte b = 0;
    if (paramCacheEntry.isJNLPFile()) {
      try {
        URL uRL = new URL(str1);
        LaunchDesc launchDesc = LaunchDescFactory.buildDescriptor(paramCacheEntry.getDataFile(), URLUtil.getBase(uRL), null, uRL);
        if (launchDesc.isApplication()) {
          b = 1;
        } else if (launchDesc.isApplet()) {
          b = 2;
        } else if (launchDesc.isInstaller() || launchDesc.isLibrary()) {
          b = 3;
        } 
      } catch (Exception exception) {}
    } else if (paramCacheEntry.isJarFile()) {
      b = 4;
    } else if (str2.endsWith("png") || str2.endsWith("gif") || str2.endsWith("jpeg") || str2.endsWith("jpg") || str2.endsWith("ico")) {
      b = 5;
    } else if (str2.endsWith("class")) {
      b = 6;
    } 
    return b;
  }
  
  private String getLowerNameExtension(String paramString) {
    if (paramString.indexOf('?') != -1)
      paramString = paramString.substring(0, paramString.indexOf('?')); 
    while (paramString.charAt(paramString.length() - 1) == '/')
      paramString = paramString.substring(0, paramString.length() - 1); 
    return paramString.toLowerCase();
  }
  
  public DownloadService2.ResourceSpec[] getUpdateAvailableResources(DownloadService2.ResourceSpec paramResourceSpec) {
    validateResourceSpec(paramResourceSpec);
    DownloadService2.ResourceSpec[] arrayOfResourceSpec1 = getCachedResources(paramResourceSpec);
    ArrayList<DownloadService2.ResourceSpec> arrayList = new ArrayList();
    for (byte b1 = 0; b1 < arrayOfResourceSpec1.length; b1++) {
      URL uRL;
      DownloadService2.ResourceSpec resourceSpec = arrayOfResourceSpec1[b1];
      try {
        uRL = new URL(resourceSpec.getUrl());
      } catch (MalformedURLException malformedURLException) {
        InternalError internalError = new InternalError(malformedURLException);
        throw internalError;
      } 
      try {
        if (resourceSpec.getVersion() == null) {
          if (ResourceProvider.get().isUpdateAvailable(uRL, null))
            arrayList.add(resourceSpec); 
        } else {
          String str = DownloadEngine.getAvailableVersion(uRL, "0+", false, null);
          if (!ResourceProvider.get().isCached(uRL, str))
            arrayList.add(resourceSpec); 
        } 
      } catch (IOException iOException) {}
    } 
    DownloadService2.ResourceSpec[] arrayOfResourceSpec2 = new DownloadService2.ResourceSpec[arrayList.size()];
    for (byte b2 = 0; b2 < arrayList.size(); b2++)
      arrayOfResourceSpec2[b2] = arrayList.get(b2); 
    return arrayOfResourceSpec2;
  }
  
  private void validateResourceSpec(DownloadService2.ResourceSpec paramResourceSpec) {
    if (paramResourceSpec == null)
      throw new IllegalArgumentException("ResourceSpec is null"); 
    String str = paramResourceSpec.getUrl();
    int i = paramResourceSpec.getType();
    if (str == null)
      throw new IllegalArgumentException("ResourceSpec has null url"); 
    if (str.isEmpty())
      throw new IllegalArgumentException("ResourceSpec has empty url"); 
    if (i < 0 || i > 6)
      throw new IllegalArgumentException("ResourceSpec has invalue type"); 
  }
  
  public static interface ResourceSpecAccess {
    void setSize(DownloadService2.ResourceSpec param1ResourceSpec, long param1Long);
    
    void setLastModified(DownloadService2.ResourceSpec param1ResourceSpec, long param1Long);
    
    void setExpirationDate(DownloadService2.ResourceSpec param1ResourceSpec, long param1Long);
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/DownloadService2Impl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */