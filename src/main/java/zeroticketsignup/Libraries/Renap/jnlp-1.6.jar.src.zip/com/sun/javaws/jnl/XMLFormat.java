package com.sun.javaws.jnl;

import com.sun.deploy.Environment;
import com.sun.deploy.association.AssociationDesc;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.security.CachedCertificatesHelper;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.UIFactory;
import com.sun.deploy.util.GeneralUtil;
import com.sun.deploy.util.URLUtil;
import com.sun.deploy.xml.CustomParser;
import com.sun.deploy.xml.XMLAttribute;
import com.sun.deploy.xml.XMLEncoding;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLParser;
import com.sun.javaws.Globals;
import com.sun.javaws.exceptions.BadFieldException;
import com.sun.javaws.exceptions.JNLParseException;
import com.sun.javaws.exceptions.MissingFieldException;
import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import org.xml.sax.SAXParseException;

public class XMLFormat {
  public static XMLNode parseBits(byte[] paramArrayOfbyte) throws JNLParseException {
    String str = decode(paramArrayOfbyte).trim();
    try {
      return (new XMLParser(str)).parse();
    } catch (SAXParseException sAXParseException) {
      try {
        return (new CustomParser(str)).parse();
      } catch (Exception exception) {
        throw new JNLParseException(str, sAXParseException, "exception parsing jnlp file", sAXParseException.getLineNumber());
      } 
    } catch (Exception exception) {
      throw new JNLParseException(str, exception, "exception parsing jnlp file", 0);
    } 
  }
  
  private static String decode(byte[] paramArrayOfbyte) throws JNLParseException {
    try {
      return XMLEncoding.decodeXML(paramArrayOfbyte);
    } catch (Exception exception) {
      throw new JNLParseException(null, exception, "exception determining encoding of jnlp file", 0);
    } 
  }
  
  public static LaunchDesc parse(byte[] paramArrayOfbyte, URL paramURL1, URL paramURL2, URL paramURL3) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    String str = decode(paramArrayOfbyte).trim();
    XMLNode xMLNode = null;
    JNLParseException jNLParseException = null;
    SAXParseException sAXParseException = null;
    try {
      xMLNode = (new XMLParser(str)).parse();
    } catch (SAXParseException sAXParseException1) {
      sAXParseException = sAXParseException1;
      jNLParseException = new JNLParseException(str, sAXParseException1, "exception parsing jnlp file", sAXParseException1.getLineNumber());
      try {
        xMLNode = (new CustomParser(str)).parse();
      } catch (Exception exception) {
        throw jNLParseException;
      } 
    } catch (Exception exception) {
      throw new JNLParseException(str, exception, "exception parsing jnlp file", 0);
    } 
    try {
      LaunchDesc launchDesc = process(xMLNode, str, paramURL1, paramURL2, paramURL3);
      if (sAXParseException != null)
        Trace.println("-----------\nWARNING: the jnlp file is invalid and will be blocked in a future release.\nException: " + sAXParseException + "\n-----------"); 
      return launchDesc;
    } catch (JNLParseException jNLParseException1) {
      if (jNLParseException != null)
        throw jNLParseException; 
      throw jNLParseException1;
    } catch (BadFieldException badFieldException) {
      if (jNLParseException != null)
        throw jNLParseException; 
      throw badFieldException;
    } catch (MissingFieldException missingFieldException) {
      if (jNLParseException != null)
        throw jNLParseException; 
      throw missingFieldException;
    } catch (IOException iOException) {
      if (jNLParseException != null)
        throw jNLParseException; 
      throw iOException;
    } 
  }
  
  private static LaunchDesc process(XMLNode paramXMLNode, String paramString, URL paramURL1, URL paramURL2, URL paramURL3) throws IOException, BadFieldException, MissingFieldException, JNLParseException {
    InformationDesc informationDesc = null;
    ResourcesDesc resourcesDesc = null;
    UpdateDesc updateDesc = null;
    ApplicationDesc applicationDesc = null;
    AppletDesc appletDesc = null;
    JavaFXAppDesc javaFXAppDesc = null;
    LibraryDesc libraryDesc = null;
    InstallerDesc installerDesc = null;
    String str1 = null;
    if (paramXMLNode == null || paramXMLNode.getName() == null)
      throw new JNLParseException(paramString, null, null, 0); 
    if (paramXMLNode.getName().equals("player") || paramXMLNode.getName().equals("viewer")) {
      String str = XMLUtils.getAttribute(paramXMLNode, null, "tab");
      return LaunchDescFactory.buildInternalLaunchDesc(paramXMLNode, str);
    } 
    if (!paramXMLNode.getName().equals("jnlp"))
      throw new MissingFieldException(paramString, "<jnlp>"); 
    String str2 = XMLUtils.getAttribute(paramXMLNode, "", "spec", "1.0+");
    String str3 = XMLUtils.getAttribute(paramXMLNode, "", "version");
    URL uRL1 = URLUtil.asPathURL(XMLUtils.getAttributeURL(paramString, paramURL1, paramXMLNode, "", "codebase"));
    if (uRL1 == null && paramURL1 != null)
      uRL1 = paramURL1; 
    URL uRL2 = XMLUtils.getAttributeURL(paramString, uRL1, paramXMLNode, "<applet-desc>", "documentbase");
    if (uRL2 == null)
      uRL2 = XMLUtils.getAttributeURL(paramString, uRL1, paramXMLNode, "<applet-desc>", "documentBase"); 
    if (paramURL2 != null)
      uRL2 = paramURL2; 
    URL uRL3 = XMLUtils.getAttributeURL(paramString, uRL1, paramXMLNode, "", "href");
    byte b1 = 0;
    CachedCertificatesHelper[] arrayOfCachedCertificatesHelper = null;
    if (XMLUtils.isElementPath(paramXMLNode, "<security><all-permissions>")) {
      b1 = 1;
      arrayOfCachedCertificatesHelper = buildCachedCertificates(paramXMLNode);
    } else if (XMLUtils.isElementPath(paramXMLNode, "<security><j2ee-application-client-permissions>")) {
      b1 = 2;
      arrayOfCachedCertificatesHelper = buildCachedCertificates(paramXMLNode);
    } 
    if (XMLUtils.isElementPath(paramXMLNode, "<javafx-desc>"))
      javaFXAppDesc = buildFXAppDesc(paramString, paramXMLNode, "<javafx-desc>"); 
    byte b2 = 0;
    if (XMLUtils.isElementPath(paramXMLNode, "<application-desc>")) {
      b2 = 1;
      applicationDesc = buildApplicationDesc(paramString, paramXMLNode);
    } else if (XMLUtils.isElementPath(paramXMLNode, "<component-desc>")) {
      b2 = 3;
      libraryDesc = buildLibraryDesc(paramString, paramXMLNode);
    } else if (XMLUtils.isElementPath(paramXMLNode, "<installer-desc>")) {
      if (!Cache.isCacheEnabled())
        throw new BadFieldException(paramString, "<installer-desc>", ""); 
      b2 = 4;
      installerDesc = buildInstallerDesc(paramString, uRL1, paramXMLNode);
    } else if (XMLUtils.isElementPath(paramXMLNode, "<applet-desc>")) {
      b2 = 2;
      appletDesc = buildAppletDesc(paramString, uRL1, uRL2, paramXMLNode);
    } else if (javaFXAppDesc != null) {
      b2 = 6;
    } else {
      throw new MissingFieldException(paramString, "<jnlp>(<application-desc>|<applet-desc>|<installer-desc>|<component-desc>)");
    } 
    updateDesc = getUpdateDesc(paramXMLNode);
    informationDesc = buildInformationDesc(paramString, uRL1, paramXMLNode);
    resourcesDesc = buildResourcesDesc(paramString, uRL1, paramXMLNode, false);
    URL uRL4 = (b2 == 3) ? paramURL3 : uRL3;
    LaunchDesc launchDesc = new LaunchDesc(str2, uRL1, uRL4, str3, informationDesc, b1, arrayOfCachedCertificatesHelper, updateDesc, resourcesDesc, b2, applicationDesc, appletDesc, javaFXAppDesc, libraryDesc, installerDesc, str1, paramXMLNode, paramString);
    setSourceURL(launchDesc, paramURL3);
    if (Trace.isEnabled(TraceLevel.TEMP))
      Trace.println("returning LaunchDesc from XMLFormat.parse():\n" + launchDesc, TraceLevel.TEMP); 
    return launchDesc;
  }
  
  private static InformationDesc combineInformationDesc(InformationDesc paramInformationDesc1, InformationDesc paramInformationDesc2) {
    if (paramInformationDesc1 == null)
      return paramInformationDesc2; 
    if (paramInformationDesc2 == null)
      return paramInformationDesc1; 
    String str1 = (paramInformationDesc1.getTitle() != null) ? paramInformationDesc1.getTitle() : paramInformationDesc2.getTitle();
    String str2 = (paramInformationDesc1.getVendor() != null) ? paramInformationDesc1.getVendor() : paramInformationDesc2.getVendor();
    URL uRL = (paramInformationDesc1.getHome() != null) ? paramInformationDesc1.getHome() : paramInformationDesc2.getHome();
    String[] arrayOfString = new String[4];
    for (byte b = 0; b < arrayOfString.length; b++)
      arrayOfString[b] = (paramInformationDesc1.getDescription(b) != null) ? paramInformationDesc1.getDescription(b) : paramInformationDesc2.getDescription(b); 
    ArrayList arrayList = new ArrayList();
    if (paramInformationDesc2.getIcons() != null)
      arrayList.addAll(Arrays.asList(paramInformationDesc2.getIcons())); 
    if (paramInformationDesc1.getIcons() != null)
      arrayList.addAll(Arrays.asList(paramInformationDesc1.getIcons())); 
    IconDesc[] arrayOfIconDesc = new IconDesc[arrayList.size()];
    arrayOfIconDesc = (IconDesc[])arrayList.toArray((Object[])arrayOfIconDesc);
    boolean bool = (paramInformationDesc1.supportsOfflineOperation() || paramInformationDesc2.supportsOfflineOperation()) ? true : false;
    ShortcutDesc shortcutDesc = (paramInformationDesc1.getShortcut() != null) ? paramInformationDesc1.getShortcut() : paramInformationDesc2.getShortcut();
    AssociationDesc[] arrayOfAssociationDesc = (AssociationDesc[])addArrays((Object[])paramInformationDesc1.getAssociations(), (Object[])paramInformationDesc2.getAssociations());
    RContentDesc[] arrayOfRContentDesc = (RContentDesc[])addArrays((Object[])paramInformationDesc1.getRelatedContent(), (Object[])paramInformationDesc2.getRelatedContent());
    return new InformationDesc(str1, str2, uRL, arrayOfString, arrayOfIconDesc, shortcutDesc, arrayOfRContentDesc, arrayOfAssociationDesc, bool);
  }
  
  private static InformationDesc buildInformationDesc(final String source, final URL codebase, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList<InformationDesc> list = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<information>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws BadFieldException, MissingFieldException {
            String[] arrayOfString1 = GeneralUtil.getStringList(XMLUtils.getAttribute(param1XMLNode, "", "os", null));
            String[] arrayOfString2 = GeneralUtil.getStringList(XMLUtils.getAttribute(param1XMLNode, "", "arch", null));
            String[] arrayOfString3 = GeneralUtil.getStringList(XMLUtils.getAttribute(param1XMLNode, "", "locale", null));
            if (GeneralUtil.prefixMatchStringList(arrayOfString1, Config.getOSFullName()) && GeneralUtil.prefixMatchArch(arrayOfString2) && XMLFormat.matchDefaultLocale(arrayOfString3)) {
              String str1 = XMLUtils.getElementContents(param1XMLNode, "<title>");
              String str2 = XMLUtils.getElementContents(param1XMLNode, "<vendor>");
              URL uRL = XMLUtils.getAttributeURL(source, codebase, param1XMLNode, "<homepage>", "href");
              String[] arrayOfString = new String[4];
              arrayOfString[0] = XMLUtils.getElementContentsWithAttribute(param1XMLNode, "<description>", "kind", "", null);
              arrayOfString[2] = XMLUtils.getElementContentsWithAttribute(param1XMLNode, "<description>", "kind", "one-line", null);
              arrayOfString[1] = XMLUtils.getElementContentsWithAttribute(param1XMLNode, "<description>", "kind", "short", null);
              arrayOfString[3] = XMLUtils.getElementContentsWithAttribute(param1XMLNode, "<description>", "kind", "tooltip", null);
              IconDesc[] arrayOfIconDesc = XMLFormat.getIconDescs(source, codebase, param1XMLNode);
              ShortcutDesc shortcutDesc = XMLFormat.getShortcutDesc(param1XMLNode);
              RContentDesc[] arrayOfRContentDesc = XMLFormat.getRContentDescs(source, codebase, param1XMLNode);
              AssociationDesc[] arrayOfAssociationDesc = XMLFormat.getAssociationDesc(source, codebase, param1XMLNode);
              list.add(new InformationDesc(str1, str2, uRL, arrayOfString, arrayOfIconDesc, shortcutDesc, arrayOfRContentDesc, arrayOfAssociationDesc, XMLUtils.isElementPath(param1XMLNode, "<offline-allowed>")));
            } 
          }
        });
    InformationDesc informationDesc = new InformationDesc(null, null, null, null, null, null, null, null, false);
    for (byte b = 0; b < arrayList.size(); b++) {
      InformationDesc informationDesc1 = arrayList.get(b);
      informationDesc = combineInformationDesc(informationDesc1, informationDesc);
    } 
    return informationDesc;
  }
  
  private static Object[] addArrays(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2) {
    if (paramArrayOfObject1 == null)
      return paramArrayOfObject2; 
    if (paramArrayOfObject2 == null)
      return paramArrayOfObject1; 
    ArrayList<Object> arrayList = new ArrayList();
    byte b = 0;
    while (b < paramArrayOfObject1.length)
      arrayList.add(paramArrayOfObject1[b++]); 
    b = 0;
    while (b < paramArrayOfObject2.length)
      arrayList.add(paramArrayOfObject2[b++]); 
    return arrayList.toArray(paramArrayOfObject1);
  }
  
  public static boolean matchDefaultLocale(String[] paramArrayOfString) { return GeneralUtil.matchLocale(paramArrayOfString, Globals.getDefaultLocale()); }
  
  static ResourcesDesc buildResourcesDesc(final String source, final URL codebase, XMLNode paramXMLNode, final boolean ignoreJres) throws MissingFieldException, BadFieldException {
    final ResourcesDesc rdesc = new ResourcesDesc();
    XMLUtils.visitElements(paramXMLNode, "<resources>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String[] arrayOfString1 = GeneralUtil.getStringList(XMLUtils.getAttribute(param1XMLNode, "", "os", null));
            final String arch = XMLUtils.getAttribute(param1XMLNode, "", "arch", null);
            String[] arrayOfString2 = GeneralUtil.getStringList(XMLUtils.getAttribute(param1XMLNode, "", "locale", null));
            if (GeneralUtil.prefixMatchStringList(arrayOfString1, Config.getOSFullName()) && XMLFormat.matchDefaultLocale(arrayOfString2))
              XMLUtils.visitChildrenElements(param1XMLNode, new XMLUtils.ElementVisitor() {
                    public void visitElement(XMLNode param2XMLNode) throws MissingFieldException, BadFieldException { XMLFormat.handleResourceElement(source, codebase, param2XMLNode, rdesc, ignoreJres, arch); }
                  }); 
          }
        });
    if (!resourcesDesc.isEmpty()) {
      boolean bool1 = resourcesDesc.isPack200Enabled();
      boolean bool2 = resourcesDesc.isVersionEnabled();
      if (bool1 || bool2) {
        JARDesc[] arrayOfJARDesc = resourcesDesc.getLocalJarDescs();
        for (byte b = 0; b < arrayOfJARDesc.length; b++) {
          JARDesc jARDesc = arrayOfJARDesc[b];
          if (bool1)
            jARDesc.setPack200Enabled(); 
          if (bool2)
            jARDesc.setVersionEnabled(); 
        } 
      } 
    } 
    return resourcesDesc.isEmpty() ? null : resourcesDesc;
  }
  
  private static IconDesc[] getIconDescs(final String source, final URL codebase, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList answer = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<icon>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getAttribute(param1XMLNode, "", "kind", "");
            URL uRL = XMLUtils.getRequiredURL(source, codebase, param1XMLNode, "", "href");
            String str2 = XMLUtils.getAttribute(param1XMLNode, "", "version", null);
            int i = XMLUtils.getIntAttribute(source, param1XMLNode, "", "height", 0);
            int j = XMLUtils.getIntAttribute(source, param1XMLNode, "", "width", 0);
            int k = XMLUtils.getIntAttribute(source, param1XMLNode, "", "depth", 0);
            byte b = 0;
            if (str1.equals("selected")) {
              b = 1;
            } else if (str1.equals("disabled")) {
              b = 2;
            } else if (str1.equals("rollover")) {
              b = 3;
            } else if (str1.equals("splash")) {
              b = 4;
            } else if (str1.equals("shortcut")) {
              b = 5;
            } 
            answer.add(new IconDesc(uRL, str2, i, j, k, b));
          }
        });
    return (IconDesc[])arrayList.toArray((Object[])new IconDesc[arrayList.size()]);
  }
  
  private static ShortcutDesc getShortcutDesc(XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList<ShortcutDesc> shortcuts = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<shortcut>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getAttribute(param1XMLNode, "", "online", "true");
            boolean bool1 = str1.equalsIgnoreCase("true");
            String str2 = XMLUtils.getAttribute(param1XMLNode, "", "install", "false");
            boolean bool2 = str2.equalsIgnoreCase("true");
            boolean bool3 = XMLUtils.isElementPath(param1XMLNode, "<desktop>");
            boolean bool4 = XMLUtils.isElementPath(param1XMLNode, "<menu>");
            String str3 = XMLUtils.getAttribute(param1XMLNode, "<menu>", "submenu");
            shortcuts.add(new ShortcutDesc(bool1, bool2, bool3, bool4, str3));
          }
        });
    return (arrayList.size() > 0) ? arrayList.get(0) : null;
  }
  
  private static CachedCertificatesHelper[] buildCachedCertificates(XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList certs = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<security><details>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getAttribute(param1XMLNode, "", "signedjnlp");
            boolean bool = "true".equalsIgnoreCase(str1);
            String str2 = XMLUtils.getAttribute(param1XMLNode, "<certificate-path>", "timestamp");
            String str3 = XMLUtils.getElementContents(param1XMLNode, "<certificate-path>");
            Date date = (str2 == null) ? null : new Date(Long.parseLong(str2));
            CachedCertificatesHelper cachedCertificatesHelper = CachedCertificatesHelper.create(date, str3, bool);
            if (cachedCertificatesHelper != null)
              certs.add(cachedCertificatesHelper); 
          }
        });
    return (arrayList.size() > 0) ? (CachedCertificatesHelper[])arrayList.toArray((Object[])new CachedCertificatesHelper[0]) : null;
  }
  
  private static UpdateDesc getUpdateDesc(XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList<UpdateDesc> updates = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<update>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getAttribute(param1XMLNode, "", "check", "timeout");
            String str2 = XMLUtils.getAttribute(param1XMLNode, "", "policy", "always");
            updates.add(new UpdateDesc(str1, str2));
          }
        });
    return (arrayList.size() > 0) ? arrayList.get(0) : new UpdateDesc("timeout", "always");
  }
  
  private static AssociationDesc[] getAssociationDesc(final String source, final URL codebase, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList answer = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<association>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getAttribute(param1XMLNode, "", "extensions");
            String str2 = XMLUtils.getAttribute(param1XMLNode, "", "mime-type");
            String str3 = XMLUtils.getElementContents(param1XMLNode, "<description>");
            URL uRL = XMLUtils.getAttributeURL(source, codebase, param1XMLNode, "<icon>", "href");
            if (str1 == null && str2 == null)
              throw new MissingFieldException(source, "<association>(<extensions><mime-type>)"); 
            if (str1 == null)
              throw new MissingFieldException(source, "<association><extensions>"); 
            if (str2 == null)
              throw new MissingFieldException(source, "<association><mime-type>"); 
            if ("gnome".equals(System.getProperty("sun.desktop"))) {
              str1 = str1.toLowerCase();
              str2 = str2.toLowerCase();
            } 
            answer.add(new AssociationDesc(str1, str2, str3, uRL));
          }
        });
    return (AssociationDesc[])arrayList.toArray((Object[])new AssociationDesc[arrayList.size()]);
  }
  
  private static RContentDesc[] getRContentDescs(final String source, final URL codebase, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    final ArrayList answer = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<related-content>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            URL uRL1 = XMLUtils.getRequiredURL(source, codebase, param1XMLNode, "", "href");
            String str1 = XMLUtils.getElementContents(param1XMLNode, "<title>");
            String str2 = XMLUtils.getElementContents(param1XMLNode, "<description>");
            URL uRL2 = XMLUtils.getAttributeURL(source, codebase, param1XMLNode, "<icon>", "href");
            answer.add(new RContentDesc(uRL1, str1, str2, uRL2));
          }
        });
    return (RContentDesc[])arrayList.toArray((Object[])new RContentDesc[arrayList.size()]);
  }
  
  private static void handleResourceElement(String paramString1, URL paramURL, XMLNode paramXMLNode, ResourcesDesc paramResourcesDesc, boolean paramBoolean, String paramString2) throws MissingFieldException, BadFieldException {
    String str = paramXMLNode.getName();
    boolean bool = GeneralUtil.prefixMatchArch(GeneralUtil.getStringList(paramString2));
    if (bool && (str.equals("jar") || str.equals("nativelib"))) {
      URL uRL = XMLUtils.getRequiredURL(paramString1, paramURL, paramXMLNode, "", "href");
      String str1 = XMLUtils.getAttribute(paramXMLNode, "", "version", null);
      String str2 = XMLUtils.getAttribute(paramXMLNode, "", "download");
      String str3 = XMLUtils.getAttribute(paramXMLNode, "", "main");
      String str4 = XMLUtils.getAttribute(paramXMLNode, "", "part");
      int i = XMLUtils.getIntAttribute(paramString1, paramXMLNode, "", "size", 0);
      boolean bool1 = str.equals("nativelib");
      if (!Cache.isCacheEnabled() && bool1)
        throw new BadFieldException(paramString1, "nativelib", uRL.toString()); 
      boolean bool2 = "lazy".equalsIgnoreCase(str2);
      boolean bool3 = "progress".equalsIgnoreCase(str2);
      boolean bool4 = "true".equalsIgnoreCase(str3);
      JARDesc jARDesc = null;
      if (Environment.isImportMode() && Environment.getImportModeCodebaseOverride() != null) {
        String str5 = XMLUtils.getAttribute(paramXMLNode, "", "href");
        if (uRL.toString().endsWith("/")) {
          File file = null;
          try {
            URI uRI = new URI(Environment.getImportModeCodebaseOverride().replace("\\", "/") + str5);
            file = new File(uRI);
            if (file != null && file.isDirectory()) {
              File[] arrayOfFile = file.listFiles();
              for (byte b = 0; b < arrayOfFile.length; b++) {
                try {
                  URL uRL1 = new URL(uRL.toString() + arrayOfFile[b].getName());
                  jARDesc = new JARDesc(uRL1, str1, bool2, bool4, bool1, str4, i, paramResourcesDesc, bool3);
                  paramResourcesDesc.addResource(jARDesc);
                } catch (MalformedURLException malformedURLException) {
                  Trace.ignoredException(malformedURLException);
                } 
              } 
            } 
          } catch (URISyntaxException uRISyntaxException) {
            Trace.ignoredException(uRISyntaxException);
          } 
        } else {
          try {
            URL uRL1 = new URL(Environment.getImportModeCodebaseOverride());
            URL uRL2 = new URL(uRL1, str5);
            jARDesc = new JARDesc(uRL2, str1, bool2, bool4, bool1, str4, i, paramResourcesDesc, bool3);
            paramResourcesDesc.addResource(jARDesc);
          } catch (MalformedURLException malformedURLException) {
            Trace.ignoredException(malformedURLException);
          } 
        } 
      } else {
        jARDesc = new JARDesc(uRL, str1, bool2, bool4, bool1, str4, i, paramResourcesDesc, bool3);
        paramResourcesDesc.addResource(jARDesc);
      } 
    } else if (bool && str.equals("property")) {
      String str1 = XMLUtils.getRequiredAttribute(paramString1, paramXMLNode, "", "name");
      String str2 = XMLUtils.getRequiredAttributeEmptyOK(paramString1, paramXMLNode, "", "value");
      if (str1.equals("jnlp.versionEnabled") && str2.equalsIgnoreCase("true")) {
        paramResourcesDesc.setVersionEnabled();
      } else if (str1.equals("jnlp.packEnabled") && str2.equalsIgnoreCase("true")) {
        paramResourcesDesc.setPack200Enabled();
      } else if (str1.equals("jnlp.concurrentDownloads")) {
        if (str2 != null) {
          int i = 0;
          try {
            i = Integer.parseInt(str2.trim());
          } catch (NumberFormatException numberFormatException) {}
          paramResourcesDesc.setConcurrentDownloads(i);
        } 
      } else {
        paramResourcesDesc.addResource(new PropertyDesc(str1, str2));
      } 
    } else if (bool && str.equals("package")) {
      String str1 = XMLUtils.getRequiredAttribute(paramString1, paramXMLNode, "", "name");
      String str2 = XMLUtils.getRequiredAttribute(paramString1, paramXMLNode, "", "part");
      String str3 = XMLUtils.getAttribute(paramXMLNode, "", "recursive", "false");
      boolean bool1 = "true".equals(str3);
      paramResourcesDesc.addResource(new PackageDesc(str1, str2, bool1));
    } else if (bool && str.equals("extension")) {
      String str1 = XMLUtils.getAttribute(paramXMLNode, "", "name");
      URL uRL = XMLUtils.getRequiredURL(paramString1, paramURL, paramXMLNode, "", "href");
      String str2 = XMLUtils.getAttribute(paramXMLNode, "", "version", null);
      ExtDownloadDesc[] arrayOfExtDownloadDesc = getExtDownloadDescs(paramString1, paramXMLNode);
      paramResourcesDesc.addResource(new ExtensionDesc(str1, uRL, str2, arrayOfExtDownloadDesc));
    } else if ((str.equals("java") || str.equals("j2se")) && !paramBoolean && JREInfo.archMatchStringList(GeneralUtil.getStringList(paramString2))) {
      String str1 = XMLUtils.getRequiredAttribute(paramString1, paramXMLNode, "", "version");
      URL uRL = XMLUtils.getAttributeURL(paramString1, paramURL, paramXMLNode, "", "href");
      String str2 = XMLUtils.getAttribute(paramXMLNode, "", "initial-heap-size");
      String str3 = XMLUtils.getAttribute(paramXMLNode, "", "max-heap-size");
      String str4 = XMLUtils.getAttribute(paramXMLNode, "", "java-vm-args");
      long l1 = -1L;
      long l2 = -1L;
      l1 = GeneralUtil.heapValToLong(str2);
      l2 = GeneralUtil.heapValToLong(str3);
      ResourcesDesc resourcesDesc = buildResourcesDesc(paramString1, paramURL, paramXMLNode, true);
      JREDesc jREDesc = new JREDesc(str1, l1, l2, str4, uRL, resourcesDesc, paramString2);
      paramResourcesDesc.addResource(jREDesc);
    } else if (str.equals("javafx-runtime")) {
      String str1 = XMLUtils.getRequiredAttribute(paramString1, paramXMLNode, "", "version");
      URL uRL = XMLUtils.getAttributeURL(paramString1, paramURL, paramXMLNode, "", "href");
      paramResourcesDesc.addResource(new JavaFXRuntimeDesc(str1, uRL));
    } 
  }
  
  private static ExtDownloadDesc[] getExtDownloadDescs(final String source, XMLNode paramXMLNode) throws BadFieldException, MissingFieldException {
    final ArrayList al = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<ext-download>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getRequiredAttribute(source, param1XMLNode, "", "ext-part");
            String str2 = XMLUtils.getAttribute(param1XMLNode, "", "part");
            String str3 = XMLUtils.getAttribute(param1XMLNode, "", "download", "eager");
            boolean bool = "lazy".equals(str3);
            al.add(new ExtDownloadDesc(str1, str2, bool));
          }
        });
    ExtDownloadDesc[] arrayOfExtDownloadDesc = new ExtDownloadDesc[arrayList.size()];
    return (ExtDownloadDesc[])arrayList.toArray((Object[])arrayOfExtDownloadDesc);
  }
  
  private static ApplicationDesc buildApplicationDesc(final String source, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    String str1 = XMLUtils.getClassName(source, paramXMLNode, "<application-desc>", "main-class", false);
    String str2 = XMLUtils.getClassName(source, paramXMLNode, "<application-desc>", "progress-class", false);
    final ArrayList al1 = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<application-desc><argument>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str = XMLUtils.getElementContents(param1XMLNode, "", null);
            if (str == null)
              throw new BadFieldException(source, XMLUtils.getPathString(param1XMLNode), ""); 
            al1.add(str);
          }
        });
    String[] arrayOfString = new String[arrayList.size()];
    arrayOfString = (String[])arrayList.toArray((Object[])arrayOfString);
    return new ApplicationDesc(str1, str2, arrayOfString);
  }
  
  private static JavaFXAppDesc buildFXAppDesc(final String source, XMLNode paramXMLNode, String paramString2) throws MissingFieldException, BadFieldException {
    String str1 = XMLUtils.getClassName(source, paramXMLNode, paramString2, "main-class", true);
    String str2 = XMLUtils.getClassName(source, paramXMLNode, paramString2, "preloader-class", false);
    final ArrayList al1 = new ArrayList();
    XMLUtils.visitElements(paramXMLNode, "<javafx-desc><argument>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str = XMLUtils.getElementContents(param1XMLNode, "", null);
            if (str == null)
              throw new BadFieldException(source, XMLUtils.getPathString(param1XMLNode), ""); 
            al1.add(str);
          }
        });
    String[] arrayOfString = null;
    if (!arrayList.isEmpty()) {
      arrayOfString = new String[arrayList.size()];
      arrayOfString = (String[])arrayList.toArray((Object[])arrayOfString);
    } 
    final Properties params = new Properties();
    XMLUtils.visitElements(paramXMLNode, "<javafx-desc><param>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getRequiredAttribute(source, param1XMLNode, "", "name");
            String str2 = XMLUtils.getRequiredAttributeEmptyOK(source, param1XMLNode, "", "value");
            params.setProperty(str1, str2);
          }
        });
    return new JavaFXAppDesc(str1, str2, arrayOfString, properties);
  }
  
  private static LibraryDesc buildLibraryDesc(String paramString, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    String str = XMLUtils.getClassName(paramString, paramXMLNode, "<component-desc>", "progress-class", false);
    return new LibraryDesc(str);
  }
  
  private static InstallerDesc buildInstallerDesc(String paramString, URL paramURL, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    String str = XMLUtils.getClassName(paramString, paramXMLNode, "<installer-desc>", "main-class", false);
    return new InstallerDesc(str);
  }
  
  private static AppletDesc buildAppletDesc(final String source, URL paramURL1, URL paramURL2, XMLNode paramXMLNode) throws MissingFieldException, BadFieldException {
    String str1 = XMLUtils.getClassName(source, paramXMLNode, "<applet-desc>", "main-class", true);
    String str2 = XMLUtils.getClassName(source, paramXMLNode, "<applet-desc>", "progress-class", false);
    String str3 = XMLUtils.getRequiredAttribute(source, paramXMLNode, "<applet-desc>", "name");
    Rectangle rectangle = UIFactory.getMouseScreenBounds();
    int i = XMLUtils.getRequiredWHAttribute(source, paramXMLNode, "<applet-desc>", "width", (int)rectangle.getWidth());
    int j = XMLUtils.getRequiredWHAttribute(source, paramXMLNode, "<applet-desc>", "height", (int)rectangle.getHeight());
    if (i <= 0)
      throw new BadFieldException(source, XMLUtils.getPathString(paramXMLNode) + "<applet-desc>width", (new Integer(i)).toString()); 
    if (j <= 0)
      throw new BadFieldException(source, XMLUtils.getPathString(paramXMLNode) + "<applet-desc>height", (new Integer(j)).toString()); 
    final Properties params = new Properties();
    XMLUtils.visitElements(paramXMLNode, "<applet-desc><param>", new XMLUtils.ElementVisitor() {
          public void visitElement(XMLNode param1XMLNode) throws MissingFieldException, BadFieldException {
            String str1 = XMLUtils.getRequiredAttribute(source, param1XMLNode, "", "name");
            String str2 = XMLUtils.getRequiredAttributeEmptyOK(source, param1XMLNode, "", "value");
            params.setProperty(str1, str2);
          }
        });
    return new AppletDesc(str3, str1, paramURL2, i, j, properties, str2);
  }
  
  public static boolean isBlacklisted(XMLNode paramXMLNode) {
    if (paramXMLNode == null)
      return false; 
    if (paramXMLNode.getName() != null)
      if (paramXMLNode.getName().equals("java") || paramXMLNode.getName().equals("j2se")) {
        for (XMLAttribute xMLAttribute = paramXMLNode.getAttributes(); xMLAttribute != null; xMLAttribute = xMLAttribute.getNext()) {
          if (xMLAttribute.getName().equals("java-vm-args")) {
            String str = xMLAttribute.getValue();
            if (str != null && str.indexOf("*") >= 0) {
              Trace.println("Blacklisted - a = " + xMLAttribute, TraceLevel.SECURITY);
              return true;
            } 
          } 
        } 
      } else if (paramXMLNode.getName().equals("property")) {
        for (XMLAttribute xMLAttribute = paramXMLNode.getAttributes(); xMLAttribute != null; xMLAttribute = xMLAttribute.getNext()) {
          String str = xMLAttribute.getValue();
          if (str != null && str.indexOf("*") >= 0) {
            Trace.println("Blacklisted - a = " + xMLAttribute, TraceLevel.SECURITY);
            return true;
          } 
        } 
      }  
    return isBlacklisted(paramXMLNode.getNested()) ? true : (isBlacklisted(paramXMLNode.getNext()));
  }
  
  private static void setSourceURL(LaunchDesc paramLaunchDesc, URL paramURL) {
    File file = null;
    if (paramURL != null)
      if (!paramLaunchDesc.isApplicationDescriptor()) {
        paramLaunchDesc.setSourceURL(paramURL);
      } else if ("file".equalsIgnoreCase(paramURL.getProtocol())) {
        try {
          file = new File(paramURL.toURI());
        } catch (URISyntaxException uRISyntaxException) {
          file = new File(paramURL.getPath());
        } 
      } else {
        paramLaunchDesc.setSourceURL(paramURL);
      }  
    if (file != null && !Cache.isFileWithinCache(file)) {
      URL uRL = paramLaunchDesc.getCodebase();
      if (uRL != null && "file".equals(uRL.getProtocol()))
        paramLaunchDesc.setSourceURL(paramURL); 
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/XMLFormat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */