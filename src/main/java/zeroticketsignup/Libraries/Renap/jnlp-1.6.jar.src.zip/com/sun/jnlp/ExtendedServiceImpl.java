package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.resources.ResourceManager;
import com.sun.javaws.JnlpxArgs;
import java.io.File;
import java.io.IOException;
import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.ExtendedService;
import javax.jnlp.FileContents;

public final class ExtendedServiceImpl implements ExtendedService {
  private static ExtendedService _sharedInstance = null;
  
  static int DEFAULT_FILESIZE = Integer.MAX_VALUE;
  
  public static synchronized ExtendedService getInstance() {
    if (_sharedInstance == null)
      if (Platform.get().isNativeSandbox()) {
        _sharedInstance = new ExtendedServiceNSBImpl(new ExtendedServiceImpl());
      } else {
        _sharedInstance = new ExtendedServiceImpl();
      }  
    return _sharedInstance;
  }
  
  public FileContents openFile(File paramFile) throws IOException {
    if (paramFile == null)
      return null; 
    final File file = new File(paramFile.getPath());
    if (!CheckServicePermission.hasFileAccessPermissions(file.toString()) && !JnlpxArgs.getFileReadWriteList().contains(file.toString()) && !askUser(file.getPath(), false))
      return null; 
    FileContents fileContents = (FileContents)AccessController.doPrivileged(new PrivilegedAction() {
          public Object run() {
            try {
              return new FileContentsImpl(file, ExtendedServiceImpl.DEFAULT_FILESIZE);
            } catch (IOException null) {
              return null;
            } 
          }
        });
    if (fileContents instanceof IOException)
      throw (IOException)fileContents; 
    return fileContents;
  }
  
  boolean openFile(String paramString) { return (paramString == null) ? false : (!(!JnlpxArgs.getFileReadWriteList().contains(paramString) && !askUser(paramString, true))); }
  
  synchronized boolean askUser(String paramString, boolean paramBoolean) {
    if (!paramBoolean && CheckServicePermission.hasFileAccessPermissions())
      return true; 
    ApiDialog apiDialog = new ApiDialog();
    String str1 = ResourceManager.getString("api.extended.open.title");
    String str2 = ResourceManager.getString("api.extended.open.message");
    String str3 = ResourceManager.getString("api.extended.open.label");
    ApiDialog.DialogResult dialogResult = apiDialog.askUser(str1, str2, null, str3, paramString, false);
    return (dialogResult == ApiDialog.DialogResult.OK || dialogResult == ApiDialog.DialogResult.ALWAYS);
  }
  
  public FileContents[] openFiles(File[] paramArrayOfFile) throws IOException {
    if (paramArrayOfFile == null || paramArrayOfFile.length <= 0)
      return null; 
    final File[] files = new File[paramArrayOfFile.length];
    byte b1;
    for (b1 = 0; b1 < paramArrayOfFile.length; b1++)
      arrayOfFile[b1] = new File(paramArrayOfFile[b1].getPath()); 
    b1 = 1;
    for (byte b2 = 0; b2 < arrayOfFile.length; b2++) {
      if (!CheckServicePermission.hasFileAccessPermissions(arrayOfFile[b2].toString())) {
        b1 = 0;
        break;
      } 
    } 
    String str = "";
    for (byte b3 = 0; b3 < arrayOfFile.length; b3++)
      str = str + arrayOfFile[b3].getPath() + "\n"; 
    if (b1 == 0 && !askUser(str, false))
      return null; 
    Object[] arrayOfObject = AccessController.doPrivileged(new PrivilegedAction<Object[]>() {
          public Object[] run() {
            FileContents[] arrayOfFileContents = new FileContents[files.length];
            try {
              for (byte b = 0; b < files.length; b++)
                arrayOfFileContents[b] = new FileContentsImpl(files[b], ExtendedServiceImpl.DEFAULT_FILESIZE); 
            } catch (IOException iOException) {
              arrayOfFileContents[0] = (FileContents)iOException;
            } 
            return (Object[])arrayOfFileContents;
          }
        });
    if (arrayOfObject[0] instanceof IOException)
      throw (IOException)arrayOfObject[0]; 
    return (FileContents[])arrayOfObject;
  }
  
  boolean openFiles(String[] paramArrayOfString) {
    if (paramArrayOfString == null || paramArrayOfString.length <= 0)
      return false; 
    String str = "";
    for (byte b = 0; b < paramArrayOfString.length; b++)
      str = str + paramArrayOfString[b] + "\n"; 
    return askUser(str, true);
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/ExtendedServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */