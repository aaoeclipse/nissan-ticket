package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import javax.jnlp.FileContents;
import javax.jnlp.JNLPRandomAccessFile;

public final class FileContentsImpl implements FileContents {
  private String _name = null;
  
  private File _file = null;
  
  private long _limit = Long.MAX_VALUE;
  
  private URL _url = null;
  
  private JNLPRandomAccessFile _raf = null;
  
  private PersistenceServiceImpl _psCallback = null;
  
  FileContentsImpl(File paramFile, long paramLong) throws IOException {
    this._file = paramFile;
    this._limit = paramLong;
    this._name = this._file.getName();
  }
  
  FileContentsImpl(File paramFile, PersistenceServiceImpl paramPersistenceServiceImpl, URL paramURL, long paramLong) {
    this._file = paramFile;
    this._url = paramURL;
    this._psCallback = paramPersistenceServiceImpl;
    this._limit = paramLong;
    int i = paramURL.getFile().lastIndexOf('/');
    this._name = (i != -1) ? paramURL.getFile().substring(i + 1) : paramURL.getFile();
  }
  
  public String getName() { return this._name; }
  
  public long getLength() {
    Long long_ = AccessController.doPrivileged(new PrivilegedAction<Long>() {
          public Object run() { return new Long(FileContentsImpl.this._file.length()); }
        });
    return long_.longValue();
  }
  
  public InputStream getInputStream() throws IOException {
    try {
      return AccessController.doPrivileged(new PrivilegedExceptionAction<InputStream>() {
            public Object run() throws IOException { return new FileInputStream(FileContentsImpl.this._file); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw rethrowException(privilegedActionException);
    } 
  }
  
  public OutputStream getOutputStream(final boolean append) throws IOException {
    try {
      return AccessController.doPrivileged(new PrivilegedExceptionAction<OutputStream>() {
            public Object run() throws IOException { return Platform.get().isNativeSandbox() ? new MeteredFileOutputStreamNSB(FileContentsImpl.this._file, !append, FileContentsImpl.this) : new MeteredFileOutputStream(FileContentsImpl.this._file, !append, FileContentsImpl.this); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw rethrowException(privilegedActionException);
    } 
  }
  
  public boolean canRead() throws IOException {
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() { return new Boolean(FileContentsImpl.this._file.canRead()); }
        });
    return bool.booleanValue();
  }
  
  public boolean canWrite() throws IOException {
    Boolean bool = AccessController.doPrivileged(new PrivilegedAction<Boolean>() {
          public Object run() { return new Boolean(FileContentsImpl.this.canWriteFile(FileContentsImpl.this._file)); }
        });
    return bool.booleanValue();
  }
  
  private boolean canWriteFile(File paramFile) {
    if (paramFile.exists())
      return paramFile.canWrite(); 
    File file = paramFile.getParentFile();
    return (file != null && file.exists() && file.canWrite());
  }
  
  public JNLPRandomAccessFile getRandomAccessFile(final String mode) throws IOException {
    if (Platform.get().isNativeSandbox() && mode.equals("rw"))
      return new JNLPRandomAccessFileNSBImpl(this._file, mode, this); 
    try {
      return AccessController.doPrivileged(new PrivilegedExceptionAction<JNLPRandomAccessFile>() {
            public Object run() throws MalformedURLException, IOException { return new JNLPRandomAccessFileImpl(FileContentsImpl.this._file, mode, FileContentsImpl.this); }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw rethrowException(privilegedActionException);
    } 
  }
  
  public long getMaxLength() throws IOException { return this._limit; }
  
  public long setMaxLength(long paramLong) throws IOException {
    if (this._psCallback != null) {
      this._limit = this._psCallback.setMaxLength(this._url, paramLong);
      return this._limit;
    } 
    this._limit = paramLong;
    return this._limit;
  }
  
  private IOException rethrowException(PrivilegedActionException paramPrivilegedActionException) throws IOException {
    Exception exception = paramPrivilegedActionException.getException();
    if (exception instanceof IOException)
      throw new IOException("IOException from FileContents"); 
    if (exception instanceof RuntimeException)
      throw (RuntimeException)exception; 
    throw new IOException(exception.getMessage());
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/FileContentsImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */