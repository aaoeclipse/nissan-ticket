package com.sun.javaws;

import com.sun.deploy.Environment;
import com.sun.deploy.association.Association;
import com.sun.deploy.association.AssociationAlreadyRegisteredException;
import com.sun.deploy.association.AssociationNotRegisteredException;
import com.sun.deploy.association.AssociationService;
import com.sun.deploy.association.RegisterFailedException;
import com.sun.deploy.association.utility.AppUtility;
import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Platform;
import com.sun.deploy.config.WinPlatform;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.resources.ResourceManager;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.WinRegistry;
import com.sun.javaws.jnl.InformationDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.RContentDesc;
import com.sun.javaws.jnl.ShortcutDesc;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.StringTokenizer;

public class WinInstallHandler extends LocalInstallHandler {
  private static final String INSTALLED_DESKTOP_SHORTCUT_KEY = "installed.desktop";
  
  private static final String INSTALLED_START_MENU_KEY = "installed.menu";
  
  private static final String UNINSTALLED_START_MENU_KEY = "installed.uninstalled";
  
  private static final String RCONTENT_START_MENU_KEY = "installed.rc";
  
  public static final int TYPE_DESKTOP = 1;
  
  public static final int TYPE_START_MENU = 2;
  
  private static final String REG_SHORTCUT_PATH = "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders";
  
  private static final String REG_DESKTOP_PATH_KEY = "Desktop";
  
  private static final String REG_START_MENU_PATH_KEY = "Programs";
  
  private static final int MAX_PATH = 260;
  
  private static final String SHORTCUT_EXTENSION = ".lnk";
  
  private static final int MAX_SHORTCUT = 260 - ".lnk".length() + 1;
  
  private boolean _loadedPaths = false;
  
  private String _desktopPath;
  
  private String _startMenuPath;
  
  private static final boolean useSystem;
  
  private final String nameBadChars = "\"\\/|:?*<>";
  
  private final String dirBadChars = "\"|:?*<>";
  
  private static final char[] WHITESPACE_PAD;
  
  private static final String ELLIPSIS = "...";
  
  private static final int MAX_INSTALL_DESCRIPTION_LENGTH = 80;
  
  public boolean isShortcutExists(LocalApplicationProperties paramLocalApplicationProperties) {
    String str1 = paramLocalApplicationProperties.get("installed.desktop");
    String str2 = paramLocalApplicationProperties.get("installed.menu");
    boolean bool1 = false;
    boolean bool2 = false;
    if (str1 != null)
      bool1 = (new File(str1)).exists(); 
    if (str2 != null)
      bool2 = (new File(str2)).exists(); 
    return (str1 != null && str2 != null) ? ((bool1 && bool2)) : ((bool1 || bool2));
  }
  
  public boolean[] whichShortcutsExist(LocalApplicationProperties paramLocalApplicationProperties) {
    boolean[] arrayOfBoolean = new boolean[2];
    String str1 = paramLocalApplicationProperties.get("installed.desktop");
    arrayOfBoolean[0] = (str1 != null && (new File(str1)).exists());
    String str2 = paramLocalApplicationProperties.get("installed.menu");
    arrayOfBoolean[1] = (str2 != null && (new File(str2)).exists());
    return arrayOfBoolean;
  }
  
  public String getDefaultIconPath() { return Platform.get().getSystemJavawsPath(); }
  
  public String getAssociationOpenCommand(String paramString) { return "\"" + Platform.get().getSystemJavawsPath() + "\" \"-localfile\" \"-open\" \"%1\" \"" + paramString + "\""; }
  
  public String getAssociationPrintCommand(String paramString) { return "\"" + Platform.get().getSystemJavawsPath() + "\" \"-localfile\" \"-print\" \"%1\" \"" + paramString + "\""; }
  
  public void registerAssociationInternal(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Association paramAssociation) throws AssociationAlreadyRegisteredException, RegisterFailedException {
    AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
    if (Environment.isSystemCacheMode() || useSystem) {
      associationService.registerSystemAssociation(paramAssociation);
    } else {
      associationService.registerUserAssociation(paramAssociation);
    } 
  }
  
  public void unregisterAssociationInternal(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Association paramAssociation) throws AssociationNotRegisteredException, RegisterFailedException {
    AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
    if (Environment.isSystemCacheMode() || useSystem) {
      associationService.unregisterSystemAssociation(paramAssociation);
    } else {
      associationService.unregisterUserAssociation(paramAssociation);
    } 
  }
  
  public boolean hasAssociation(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, Association paramAssociation) {
    AssociationService associationService = new AssociationService(paramLocalApplicationProperties);
    return associationService.hasAssociation(paramAssociation);
  }
  
  public boolean isLocalInstallSupported() { return true; }
  
  public boolean isAssociationSupported() { return true; }
  
  protected boolean isAssociationFileExtSupported(String paramString) {
    if (paramString == null)
      return false; 
    String str = AppUtility.removeDotFromFileExtension(paramString.toLowerCase());
    return (!str.equals("exe") && !str.equals("com") && !str.equals("bat"));
  }
  
  public boolean removePathShortcut(String paramString) {
    File file = new File(paramString);
    return file.exists() ? file.delete() : false;
  }
  
  public boolean updateShortcutToLatestJRE(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) {
    WinPlatform winPlatform;
    if (Platform.get() instanceof WinPlatform) {
      winPlatform = (WinPlatform)Platform.get();
    } else {
      return false;
    } 
    String str2 = winPlatform.getSystemJavawsPath();
    if (str2 == null)
      return false; 
    String str1;
    if ((str1 = paramLocalApplicationProperties.get("installed.menu")) != null)
      winPlatform.updateShortcut(str1, str2); 
    if ((str1 = paramLocalApplicationProperties.get("installed.desktop")) != null)
      winPlatform.updateShortcut(str1, str2); 
    if (paramLocalApplicationProperties.isJnlpInstalled()) {
      removeFromInstallPanel(paramLaunchDesc, paramLocalApplicationProperties, false);
      registerWithInstallPanel(paramLaunchDesc, paramLocalApplicationProperties);
    } 
    return true;
  }
  
  private void deleteClonedShortcutIcon(LaunchDesc paramLaunchDesc, boolean paramBoolean) {
    String str = getIconPath(paramLaunchDesc, paramBoolean);
    File file = new File(getNewIconFilePath(str) + File.separator + getIconFileName(str));
    Cache.ensureFileDeleted(file);
  }
  
  protected boolean removeShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean) {
    if (paramLocalApplicationProperties == null) {
      Trace.println("No LAP for uninstall, bailing!", TraceLevel.TEMP);
      return false;
    } 
    String str2 = null;
    boolean bool = false;
    WinPlatform winPlatform = null;
    if (Platform.get() instanceof WinPlatform)
      winPlatform = (WinPlatform)Platform.get(); 
    String str1;
    if ((str1 = paramLocalApplicationProperties.get("installed.menu")) != null) {
      if (!deleteShortcut(str1)) {
        bool = true;
      } else {
        paramLocalApplicationProperties.put("installed.menu", null);
      } 
      str2 = str1;
      if (winPlatform != null && winPlatform.isPlatformWindows8orLater())
        deleteClonedShortcutIcon(paramLaunchDesc, false); 
    } 
    if ((str1 = paramLocalApplicationProperties.get("installed.uninstalled")) != null) {
      if (!deleteShortcut(str1)) {
        bool = true;
      } else {
        paramLocalApplicationProperties.put("installed.uninstalled", null);
      } 
      str2 = str1;
    } 
    String str3 = paramLocalApplicationProperties.get("installed.rc");
    if (str3 != null) {
      StringTokenizer stringTokenizer = new StringTokenizer(str3, File.pathSeparator);
      while (stringTokenizer.hasMoreElements()) {
        str1 = stringTokenizer.nextToken();
        if (str1 != null) {
          if (!deleteShortcut(str1))
            bool = true; 
          str2 = str1;
        } 
      } 
      paramLocalApplicationProperties.put("installed.rc", null);
    } 
    if (str2 != null)
      checkEmpty(str2); 
    if (paramBoolean) {
      if ((str1 = paramLocalApplicationProperties.get("installed.desktop")) != null)
        if (!deleteShortcut(str1)) {
          bool = true;
        } else {
          paramLocalApplicationProperties.put("installed.desktop", null);
        }  
      if (winPlatform != null && winPlatform.isPlatformWindows8orLater())
        deleteClonedShortcutIcon(paramLaunchDesc, true); 
    } 
    if (bool)
      Trace.println("uninstall shortcut failed", TraceLevel.TEMP); 
    paramLocalApplicationProperties.setShortcutInstalled(false);
    save(paramLocalApplicationProperties);
    return !bool;
  }
  
  private void checkEmpty(String paramString) {
    try {
      for (File file = (new File(paramString)).getParentFile(); file != null && file.isDirectory() && (file.list()).length == 0; file = file.getParentFile())
        file.delete(); 
    } catch (Exception exception) {}
  }
  
  private boolean hasValidTitle(LaunchDesc paramLaunchDesc) {
    if (paramLaunchDesc == null)
      return false; 
    InformationDesc informationDesc = paramLaunchDesc.getInformation();
    if (informationDesc == null || nameFilter(informationDesc.getTitle()) == null) {
      Trace.println("Invalid: No title!", TraceLevel.TEMP);
      return false;
    } 
    return true;
  }
  
  protected boolean createShortcuts(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean[] paramArrayOfboolean) {
    if (!hasValidTitle(paramLaunchDesc))
      return false; 
    if (isShortcutExists(paramLocalApplicationProperties) && !shouldInstallOverExisting(paramLaunchDesc))
      return false; 
    String str = null;
    File file = ResourceProvider.get().getCachedJNLPFile(paramLaunchDesc.getCanonicalHome(), null);
    if (file != null)
      str = file.getPath(); 
    if (str == null) {
      installFailed(paramLaunchDesc);
      return false;
    } 
    ShortcutDesc shortcutDesc = paramLaunchDesc.getInformation().getShortcut();
    boolean bool1 = (shortcutDesc == null) ? true : shortcutDesc.getDesktop();
    boolean bool2 = (shortcutDesc == null) ? true : shortcutDesc.getMenu();
    if (paramArrayOfboolean != null) {
      bool1 = (bool1 && paramArrayOfboolean[0]) ? true : false;
      bool2 = (bool2 && paramArrayOfboolean[1]) ? true : false;
    } 
    if (bool1 && !handleInstall(paramLaunchDesc, shortcutDesc, paramLocalApplicationProperties, str, 1)) {
      installFailed(paramLaunchDesc);
      return false;
    } 
    if (bool2 && !handleInstall(paramLaunchDesc, shortcutDesc, paramLocalApplicationProperties, str, 2)) {
      removeShortcuts(paramLaunchDesc, paramLocalApplicationProperties, bool1);
      installFailed(paramLaunchDesc);
      return false;
    } 
    if (bool2 || bool1) {
      paramLocalApplicationProperties.setShortcutInstalled(true);
      save(paramLocalApplicationProperties);
    } 
    return true;
  }
  
  protected void registerWithInstallPanel(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties) {
    InformationDesc informationDesc = paramLaunchDesc.getInformation();
    String str1 = Platform.get().toExecArg(paramLaunchDesc.getCanonicalHome().toString());
    String str2 = nameFilter(informationDesc.getTitle());
    if (str1 != null && str1.length() != 0 && str2 != null && str2.length() != 0) {
      String str3 = getIconPath(paramLaunchDesc, false);
      String str4 = informationDesc.getVendor();
      String str5 = getBestFitDescription(informationDesc);
      URL uRL = informationDesc.getHome();
      String str6 = null;
      boolean bool = Environment.isSystemCacheMode();
      if (uRL != null)
        str6 = informationDesc.getHome().toExternalForm(); 
      if (str4 == null)
        str4 = str6; 
      if (str4 == null && str5.trim().length() == 0) {
        str4 = null;
        str5 = null;
        str6 = null;
      } 
      paramLocalApplicationProperties.setRegisteredTitle(str2);
      Platform.get().addRemoveProgramsAdd(str1, str2, str3, str4, str5, str6, bool);
    } 
  }
  
  protected void removeFromInstallPanel(LaunchDesc paramLaunchDesc, LocalApplicationProperties paramLocalApplicationProperties, boolean paramBoolean) {
    boolean bool = Environment.isSystemCacheMode();
    String str = paramLocalApplicationProperties.getRegisteredTitle();
    if (paramBoolean && str == null)
      str = nameFilter(paramLaunchDesc.getInformation().getTitle()); 
    if (str != null && str.length() != 0)
      Platform.get().addRemoveProgramsRemove(str, bool); 
  }
  
  private String getBestFitDescription(InformationDesc paramInformationDesc) {
    String str = paramInformationDesc.getDescription(2);
    if (str == null) {
      str = paramInformationDesc.getDescription(0);
      if (str == null) {
        str = paramInformationDesc.getDescription(1);
        if (str == null)
          str = paramInformationDesc.getDescription(3); 
      } 
    } 
    if (str != null) {
      int i = str.length();
      if (i < WHITESPACE_PAD.length) {
        str = (new StringBuffer(str)).append(WHITESPACE_PAD, 0, WHITESPACE_PAD.length - i).toString();
      } else if (i > 80) {
        int j = "...".length();
        str = (new StringBuffer(str)).delete(80 - j, i).append("...").toString();
      } 
    } else {
      str = new String(WHITESPACE_PAD);
    } 
    return str;
  }
  
  private void installFailed(final LaunchDesc desc) {
    Runnable runnable = new Runnable() {
        public void run() {
          String str1 = ResourceManager.getString("common.ok_btn");
          String str2 = ResourceManager.getString("common.detail.button");
          ToolkitStore.getUI().showMessageDialog(null, null, 0, ResourceManager.getString("install.installFailedTitle"), ResourceManager.getString("install.installFailed", WinInstallHandler.this.getInstallName(desc)), null, null, str1, str2, null);
        }
      };
    invokeRunnable(runnable);
  }
  
  private void uninstallFailed(final LaunchDesc desc) {
    Runnable runnable = new Runnable() {
        public void run() {
          String str1 = ResourceManager.getString("common.ok_btn");
          String str2 = ResourceManager.getString("common.detail.button");
          ToolkitStore.getUI().showMessageDialog(null, null, 0, ResourceManager.getString("install.uninstallFailedTitle"), ResourceManager.getString("install.uninstallFailed", WinInstallHandler.this.getInstallName(desc)), null, null, str1, str2, null);
        }
      };
    invokeRunnable(runnable);
  }
  
  private String getIconFileName(String paramString) { return paramString.substring(paramString.lastIndexOf(File.separator) + 1); }
  
  private String getNewIconFilePath(String paramString) {
    int i = paramString.lastIndexOf(File.separator);
    if (i < 0)
      return paramString; 
    if (!(Platform.get() instanceof WinPlatform))
      return paramString; 
    WinPlatform winPlatform = (WinPlatform)Platform.get();
    String str = winPlatform.getPlatformUserHome().toLowerCase();
    if (paramString.toLowerCase().contains(str)) {
      int j = str.length();
      String str1 = winPlatform.getPlatformUserLocalDir();
      return (str1 != null) ? (str1 + paramString.substring(j, i)) : paramString;
    } 
    return paramString;
  }
  
  private String copyIconFileForWindows8(String paramString) {
    if (!(Platform.get() instanceof WinPlatform))
      return paramString; 
    String str1 = paramString;
    WinPlatform winPlatform = (WinPlatform)Platform.get();
    String str2 = winPlatform.getPlatformUserHome().toLowerCase();
    if (paramString.toLowerCase().contains(str2)) {
      str1 = getNewIconFilePath(paramString);
      String str = getIconFileName(paramString);
      try {
        File file = new File(str1);
        file.mkdirs();
        Cache.copyFile(new File(paramString), new File(file, str));
        str1 = str1 + File.separator + str;
      } catch (IOException iOException) {
        return paramString;
      } 
    } 
    return str1;
  }
  
  private boolean handleInstall(LaunchDesc paramLaunchDesc, ShortcutDesc paramShortcutDesc, LocalApplicationProperties paramLocalApplicationProperties, String paramString, int paramInt) {
    InformationDesc informationDesc = paramLaunchDesc.getInformation();
    String str1 = null;
    String str2 = getIconPath(paramLaunchDesc, true);
    String str3 = getIconPath(paramLaunchDesc, false);
    String str4 = Platform.get().getSystemJavawsPath();
    String str5 = informationDesc.getDescription(0);
    String str6 = informationDesc.getDescription(3);
    String str7 = (str6 == null) ? str5 : str6;
    boolean bool1 = true;
    String str8 = (paramLaunchDesc.getLocation() != null) ? paramLaunchDesc.getLocation().toString() : null;
    String str9 = (str8 == null || str8.endsWith(".jarjnlp")) ? "" : ("-J-Djnlp.application.href=" + str8 + " ");
    boolean bool2 = (!informationDesc.supportsOfflineOperation() || paramShortcutDesc == null || paramShortcutDesc.getOnline()) ? true : false;
    String str10 = bool2 ? "" : "-offline ";
    String str11 = "-localfile " + str10 + str9 + "\"" + paramString + "\"";
    if (str11.length() >= 255)
      str11 = "-localfile " + str10 + "\"" + paramString + "\""; 
    WinPlatform winPlatform = null;
    if (Platform.get() instanceof WinPlatform)
      winPlatform = (WinPlatform)Platform.get(); 
    if (paramInt == 1) {
      String str = getDesktopPath(paramLaunchDesc);
      str1 = getInstallName(paramLaunchDesc);
      if (winPlatform != null && winPlatform.isPlatformWindows8orLater())
        str2 = copyIconFileForWindows8(str2); 
      int i = installWrapper(str, str1, str7, str4, str11, null, str2);
      if (i == 0) {
        paramLocalApplicationProperties.put("installed.desktop", str);
        Trace.println("Installed desktop shortcut for: " + str1 + ".", TraceLevel.TEMP);
      } else {
        bool1 = false;
        Trace.println("Installed desktop shortcut for: " + str1 + " failed (" + i + ")!!!", TraceLevel.TEMP);
      } 
    } else {
      File file = new File(getSubMenuPath(paramLaunchDesc));
      if (file.exists() || file.mkdirs()) {
        String str12 = getStartMenuPath(paramLaunchDesc);
        str1 = getInstallName(paramLaunchDesc);
        if (winPlatform != null && winPlatform.isPlatformWindows8orLater())
          str3 = copyIconFileForWindows8(str3); 
        int i = installWrapper(str12, str1, str7, str4, str11, null, str3);
        if (i == 0) {
          paramLocalApplicationProperties.put("installed.menu", str12);
          Trace.println("Installed menu shortcut for: " + str1 + ".", TraceLevel.TEMP);
        } else {
          bool1 = false;
          Trace.println("Installed menu shortcut for: " + str1 + " failed (" + i + ")!!!", TraceLevel.TEMP);
        } 
        String str13 = getSubMenuDir(paramLaunchDesc);
        if ((str13 == null || !str13.equals("Startup")) && addUninstallShortcut()) {
          str11 = "-uninstall \"" + paramString + "\"";
          str12 = getUninstallPath(paramLaunchDesc);
          str1 = getUninstallMenuName(paramLaunchDesc);
          i = installWrapper(str12, str1, str7, str4, str11, null, str3);
          if (i == 0) {
            paramLocalApplicationProperties.put("installed.uninstalled", str12);
            Trace.println("Installed menu shortcut for: " + str1 + ".", TraceLevel.TEMP);
          } else {
            bool1 = false;
            Trace.println("Installed menu shortcut for: " + str1 + " failed (" + i + ")!!!", TraceLevel.TEMP);
          } 
        } 
        RContentDesc[] arrayOfRContentDesc = informationDesc.getRelatedContent();
        StringBuilder stringBuilder = new StringBuilder();
        if (arrayOfRContentDesc != null)
          for (RContentDesc rContentDesc : arrayOfRContentDesc) {
            str1 = nameFilter(rContentDesc.getTitle());
            URL uRL = rContentDesc.getHref();
            if (!uRL.toString().endsWith("jnlp")) {
              str7 = rContentDesc.getDescription();
              URL uRL1 = rContentDesc.getIcon();
              String str = null;
              if (uRL1 != null)
                str = IconUtil.getIconPath(uRL1, null); 
              if (str == null)
                str = str2; 
              str12 = getRCPath(paramLaunchDesc, str1);
              File file1 = CacheUtil.getCachedFileNative(uRL);
              str4 = (new WinBrowserSupport()).getDefaultHandler(uRL);
              if (file1 != null) {
                str11 = "\"file:" + file1.getAbsolutePath() + "\"";
                i = installWrapper(str12, str1, str7, str4, str11, null, str);
                if (i == 0) {
                  stringBuilder.append(str12);
                  stringBuilder.append(File.pathSeparator);
                  Trace.println("Installed menu shortcut for: " + str1 + ".", TraceLevel.TEMP);
                } else {
                  bool1 = false;
                  Trace.println("Installed menu shortcut for: " + str1 + " failed (" + i + ")!!!", TraceLevel.TEMP);
                } 
              } else {
                str11 = uRL.toString();
                i = installWrapper(str12, str1, str7, str4, str11, null, str);
                if (i == 0) {
                  stringBuilder.append(str12);
                  stringBuilder.append(File.pathSeparator);
                  Trace.println("Installed menu shortcut for: " + str1 + ".", TraceLevel.TEMP);
                } else {
                  bool1 = false;
                  Trace.println("Installed menu shortcut for: " + str1 + " failed (" + i + ")!!!", TraceLevel.TEMP);
                } 
              } 
            } 
          }  
        if (stringBuilder.length() > 0) {
          paramLocalApplicationProperties.put("installed.rc", stringBuilder.toString());
        } else {
          paramLocalApplicationProperties.put("installed.rc", null);
        } 
      } else {
        bool1 = false;
        Trace.println("Installed menu shortcut for: " + str1 + " failed (can't create directory \"" + file.getAbsolutePath() + "\")!!!", TraceLevel.TEMP);
      } 
    } 
    return bool1;
  }
  
  private String getInstallName(LaunchDesc paramLaunchDesc) { return nameFilter(paramLaunchDesc.getInformation().getTitle()); }
  
  private String getUninstallMenuName(LaunchDesc paramLaunchDesc) { return ResourceManager.getString("install.startMenuUninstallShortcutName", getInstallName(paramLaunchDesc)); }
  
  private String getDesktopPath(LaunchDesc paramLaunchDesc) { return getShortcutPath(getDesktopPath(), getInstallName(paramLaunchDesc)); }
  
  private String getStartMenuPath(LaunchDesc paramLaunchDesc) { return getShortcutPath(getSubMenuPath(paramLaunchDesc), getInstallName(paramLaunchDesc)); }
  
  private String getRCPath(LaunchDesc paramLaunchDesc, String paramString) { return getShortcutPath(getSubMenuPath(paramLaunchDesc), paramString); }
  
  private String getUninstallPath(LaunchDesc paramLaunchDesc) { return getShortcutPath(getSubMenuPath(paramLaunchDesc), getUninstallMenuName(paramLaunchDesc)); }
  
  private String getSubMenuPath(LaunchDesc paramLaunchDesc) {
    String str = getStartMenuPath();
    if (str != null) {
      String str1 = getSubMenuDir(paramLaunchDesc);
      if (str1 != null)
        str = str + str1 + File.separator; 
    } 
    return str;
  }
  
  private String getSubMenuDir(LaunchDesc paramLaunchDesc) {
    String str = getInstallName(paramLaunchDesc);
    ShortcutDesc shortcutDesc = paramLaunchDesc.getInformation().getShortcut();
    if (shortcutDesc != null) {
      String str1 = shortcutDesc.getSubmenu();
      if (str1 != null)
        str = dirFilter(str1); 
    } 
    if (str != null && str.equalsIgnoreCase("startup"))
      str = "Startup"; 
    return str;
  }
  
  private String getDesktopPath() {
    loadPathsIfNecessary();
    return this._desktopPath;
  }
  
  private String getStartMenuPath() {
    loadPathsIfNecessary();
    return this._startMenuPath;
  }
  
  private void loadPathsIfNecessary() {
    int i = -2147483647;
    String str = "";
    if (Environment.isSystemCacheMode()) {
      i = -2147483646;
      str = "Common ";
    } 
    if (!this._loadedPaths) {
      this._desktopPath = WinRegistry.getString(i, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", str + "Desktop");
      if (this._desktopPath != null && this._desktopPath.length() > 0 && this._desktopPath.charAt(this._desktopPath.length() - 1) != '\\')
        this._desktopPath += '\\'; 
      this._startMenuPath = WinRegistry.getString(i, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders", str + "Programs");
      if (this._startMenuPath != null && this._startMenuPath.length() > 0 && this._startMenuPath.charAt(this._startMenuPath.length() - 1) != '\\')
        this._startMenuPath += '\\'; 
      this._loadedPaths = true;
      Trace.println("Start path: " + this._startMenuPath + " desktop " + this._desktopPath, TraceLevel.TEMP);
    } 
  }
  
  private String nameFilter(String paramString) { return Filter(paramString, "\"\\/|:?*<>", '-'); }
  
  private String dirFilter(String paramString) {
    String str = Filter(paramString, "\"|:?*<>", '-');
    return Filter(str, "\\/", File.separatorChar);
  }
  
  private String Filter(String paramString1, String paramString2, char paramChar) {
    if (paramString1 == null)
      return null; 
    if (paramString1.equalsIgnoreCase("nul"))
      return "-nul-"; 
    paramString1 = paramString1.trim();
    return (paramString1.length() == 0) ? null : checkTitleString(paramString1, paramString2, paramChar);
  }
  
  private boolean deleteShortcut(String paramString) {
    File file = new File(paramString);
    if (file.exists()) {
      boolean bool = file.delete();
      try {
        Thread.sleep(1000L);
      } catch (InterruptedException interruptedException) {
        Trace.ignoredException(interruptedException);
      } 
      return bool;
    } 
    return true;
  }
  
  private String getIconPath(LaunchDesc paramLaunchDesc, boolean paramBoolean) {
    String str = getDefaultIconPath();
    if (paramLaunchDesc != null) {
      String str1 = IconUtil.getIconPath(paramLaunchDesc, paramBoolean);
      if (str1 != null)
        str = str1; 
    } 
    return str;
  }
  
  private String getShortcutPath(String paramString1, String paramString2) {
    String str = null;
    if (paramString1 != null && paramString1.length() < MAX_SHORTCUT - 1 && paramString2 != null) {
      StringBuilder stringBuilder = new StringBuilder(324);
      stringBuilder.append(paramString1).append(paramString2);
      if (stringBuilder.length() > MAX_SHORTCUT)
        stringBuilder.delete(MAX_SHORTCUT, stringBuilder.length()); 
      stringBuilder.append(".lnk");
      str = stringBuilder.toString();
    } 
    return str;
  }
  
  private int installWrapper(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
    Trace.println("installshortcut with args:", TraceLevel.TEMP);
    Trace.println("    path: " + paramString1, TraceLevel.TEMP);
    Trace.println("    name: " + paramString2, TraceLevel.TEMP);
    Trace.println("    desc: " + paramString3, TraceLevel.TEMP);
    Trace.println("    appP: " + paramString4, TraceLevel.TEMP);
    Trace.println("    args: " + paramString5, TraceLevel.TEMP);
    Trace.println("    dir : " + paramString6, TraceLevel.TEMP);
    Trace.println("    icon: " + paramString7, TraceLevel.TEMP);
    Trace.flush();
    return Platform.get().installShortcut(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7);
  }
  
  static  {
    String str = System.getProperty("os.name");
    useSystem = (!str.contains("2000") && !str.contains("XP") && !Platform.get().isPlatformWindowsVista());
    WHITESPACE_PAD = new char[] { 
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
        ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ' };
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/WinInstallHandler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */