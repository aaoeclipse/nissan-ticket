package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;
import com.sun.javaws.jnl.LaunchDesc;
import java.net.URL;

public class UnsignedAccessViolationException extends JNLPException {
  URL _url;
  
  boolean _initial;
  
  public UnsignedAccessViolationException(LaunchDesc paramLaunchDesc, URL paramURL, boolean paramBoolean) {
    super(ResourceManager.getString("launch.error.category.security"), paramLaunchDesc);
    this._url = paramURL;
    this._initial = paramBoolean;
  }
  
  public String getRealMessage() { return ResourceManager.getString("launch.error.unsignedAccessViolation") + "\n" + ResourceManager.getString("launch.error.unsignedResource", this._url.toString()); }
  
  public String getBriefMessage() { return this._initial ? null : ResourceManager.getString("launcherrordialog.brief.continue"); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/UnsignedAccessViolationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */