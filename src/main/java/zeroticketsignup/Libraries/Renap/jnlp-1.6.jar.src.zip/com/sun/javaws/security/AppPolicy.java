package com.sun.javaws.security;

import com.sun.applet2.preloader.Preloader;
import com.sun.deploy.config.Config;
import com.sun.deploy.model.LocalApplicationProperties;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.ref.AppRef;
import com.sun.deploy.ref.CodeInstance;
import com.sun.deploy.ref.CodeRef;
import com.sun.deploy.security.BadCertificateDialog;
import com.sun.deploy.security.BlockedDialog;
import com.sun.deploy.security.BlockedException;
import com.sun.deploy.security.CeilingPolicy;
import com.sun.deploy.security.DeployManifestChecker;
import com.sun.deploy.security.SandboxSecurity;
import com.sun.deploy.security.TrustDecider;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.util.PerfLogger;
import com.sun.javaws.Globals;
import com.sun.javaws.LocalInstallHandler;
import com.sun.javaws.Main;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.ShortcutDesc;
import com.sun.jnlp.JNLPClassLoaderIf;
import com.sun.jnlp.JNLPClassLoaderUtil;
import java.awt.AWTPermission;
import java.io.File;
import java.io.FilePermission;
import java.net.SocketPermission;
import java.net.URL;
import java.security.AccessControlException;
import java.security.AllPermission;
import java.security.CodeSource;
import java.security.PermissionCollection;
import java.security.Policy;
import java.util.Enumeration;
import java.util.Properties;
import java.util.PropertyPermission;

public class AppPolicy {
  private String _host = null;
  
  private File _extensionDir = null;
  
  private static AppPolicy _instance = null;
  
  public static AppPolicy getInstance() { return _instance; }
  
  public static AppPolicy createInstance(String paramString) {
    if (_instance == null)
      _instance = new AppPolicy(paramString); 
    return _instance;
  }
  
  private AppPolicy(String paramString) {
    this._host = paramString;
    this._extensionDir = new File(System.getProperty("java.home") + File.separator + "lib" + File.separator + "ext");
  }
  
  public boolean addPermissions(JNLPClassLoaderIf paramJNLPClassLoaderIf, PermissionCollection paramPermissionCollection, CodeSource paramCodeSource, boolean paramBoolean) throws ExitException {
    Trace.println("JAVAWS AppPolicy Permission requested for: " + paramCodeSource.getLocation(), TraceLevel.SECURITY);
    DeploymentRuleSet deploymentRuleSet = paramJNLPClassLoaderIf.getDeploymentRuleSet(paramCodeSource.getLocation());
    JARDesc jARDesc = paramJNLPClassLoaderIf.getJarDescFromURL(paramCodeSource.getLocation());
    LaunchDesc launchDesc = null;
    int i = 0;
    boolean bool = false;
    if (jARDesc != null && jARDesc.getParent() != null) {
      launchDesc = jARDesc.getParent().getParent();
      if (launchDesc != null)
        i = launchDesc.getSecurityModel(); 
    } else {
      launchDesc = paramJNLPClassLoaderIf.getLaunchDesc();
      if (paramCodeSource.getCertificates() == null) {
        i = 0;
      } else if (launchDesc != null) {
        i = launchDesc.getSecurityModel();
      } 
    } 
    if (paramBoolean)
      if (i == 0) {
        grantRestrictedAccess(launchDesc, deploymentRuleSet, paramCodeSource, paramJNLPClassLoaderIf.getPreloader());
      } else {
        grantUnrestrictedAccess(launchDesc, deploymentRuleSet, paramCodeSource, paramJNLPClassLoaderIf.getPreloader(), false);
        bool = true;
        if (i == 1) {
          CeilingPolicy.addTrustedPermissions(paramPermissionCollection);
        } else {
          addJ2EEApplicationClientPermissionsObject(paramPermissionCollection);
        } 
      }  
    if (!paramPermissionCollection.implies(new AllPermission()))
      addSandboxPermissionsObject(paramPermissionCollection, (launchDesc != null && launchDesc.getLaunchType() == 2)); 
    if (launchDesc != null && !launchDesc.arePropsSet()) {
      Properties properties = launchDesc.getResources().getResourceProperties();
      Enumeration<Object> enumeration = properties.keys();
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        String str2 = properties.getProperty(str1);
        if (Config.isSecureProperty(str1, str2) || launchDesc.isSigned()) {
          PropertyPermission propertyPermission = new PropertyPermission(str1, "write");
          PermissionCollection permissionCollection = Policy.getPolicy().getPermissions(paramCodeSource);
          if (paramPermissionCollection.implies(propertyPermission) || permissionCollection.implies(propertyPermission)) {
            System.setProperty(str1, str2);
            continue;
          } 
          Trace.ignoredException(new AccessControlException("access denied " + propertyPermission, propertyPermission));
        } 
      } 
      launchDesc.setPropsSet(true);
    } 
    return bool;
  }
  
  private boolean isSuspiciousProperty(String paramString) {
    if ("javaplugin.user.profile".equals(paramString)) {
      Trace.println("Property javaplugin.user.profile can not be set as trusted", TraceLevel.SECURITY);
      return true;
    } 
    return false;
  }
  
  private void setUnrestrictedProps(LaunchDesc paramLaunchDesc) {
    if (!paramLaunchDesc.arePropsSet()) {
      Properties properties = paramLaunchDesc.getResources().getResourceProperties();
      Enumeration<Object> enumeration = properties.keys();
      URL uRL = (paramLaunchDesc.getLocation() != null) ? paramLaunchDesc.getLocation() : paramLaunchDesc.getSourceURL();
      DeploymentRuleSet deploymentRuleSet = null;
      AppRef appRef = new AppRef(AppRef.Type.DOCBASE, null, uRL, null, (URL)null, paramLaunchDesc.getHash());
      deploymentRuleSet = DeploymentRuleSet.findDRS(new CodeInstance(appRef, new CodeRef(null, null, false, false)));
      while (enumeration.hasMoreElements()) {
        String str1 = (String)enumeration.nextElement();
        String str2 = properties.getProperty(str1);
        if (Config.isSecureProperty(str1, str2) || paramLaunchDesc.isSigned() || (deploymentRuleSet != null && deploymentRuleSet.allowInsecureProperties() && !Globals.isNoCodebaseMode())) {
          if (!isSuspiciousProperty(str1))
            System.setProperty(str1, str2); 
          continue;
        } 
        Trace.println("Insecure property: (" + str1 + ", " + str2 + ") specified in unsigned jnlp file will not be set.");
      } 
      paramLaunchDesc.setPropsSet(true);
    } 
  }
  
  public void grantRestrictedAccess(LaunchDesc paramLaunchDesc, DeploymentRuleSet paramDeploymentRuleSet, CodeSource paramCodeSource, Preloader paramPreloader) throws ExitException {
    if (paramLaunchDesc != null) {
      AppInfo appInfo = paramLaunchDesc.getAppInfo();
      try {
        SandboxSecurity.isPermissionGranted(paramCodeSource, appInfo, paramDeploymentRuleSet, paramPreloader);
      } catch (Exception exception) {
        throw new ExitException("Sandbox permissions not granted", exception, 0);
      } catch (Throwable throwable) {
        Trace.ignored(throwable);
        throw new ExitException("Problem granting sandbox permissions", null, 0);
      } 
    } 
  }
  
  public long grantUnrestrictedAccess(LaunchDesc paramLaunchDesc, DeploymentRuleSet paramDeploymentRuleSet, CodeSource paramCodeSource, Preloader paramPreloader, boolean paramBoolean) throws ExitException {
    PerfLogger.setTime("Security: Start grantUnrestrictedAccess in AppPolicy class");
    try {
      DeployManifestChecker.verify(paramDeploymentRuleSet, paramCodeSource.getLocation(), true, paramLaunchDesc.getAppInfo());
    } catch (SecurityException securityException) {
      Trace.ignored(securityException);
      BlockedDialog.show(paramLaunchDesc.getAppInfo(), null, null, securityException, paramCodeSource, paramDeploymentRuleSet);
    } 
    boolean bool = (paramLaunchDesc.isTrusted() || (Globals.isSecureMode() && paramLaunchDesc.isInstaller())) ? true : false;
    AppInfo appInfo = null;
    if (!bool) {
      appInfo = paramLaunchDesc.getAppInfo();
      boolean bool1 = false;
      if (paramLaunchDesc.getAppletDescriptor() != null || paramLaunchDesc.getApplicationDescriptor() != null) {
        LocalInstallHandler localInstallHandler = LocalInstallHandler.getInstance();
        if (localInstallHandler.isLocalInstallSupported()) {
          LocalApplicationProperties localApplicationProperties = ResourceProvider.get().getLocalApplicationProperties(paramLaunchDesc.getCanonicalHome(), null, true);
          if (localApplicationProperties != null && !localApplicationProperties.getAskedForInstall())
            bool1 = true; 
        } 
        if (bool1) {
          ShortcutDesc shortcutDesc = paramLaunchDesc.getInformation().getShortcut();
          switch (Config.getShortcutValue()) {
            case 3:
              if (shortcutDesc == null)
                break; 
            case 1:
            case 2:
            case 4:
              if (shortcutDesc != null) {
                appInfo.setDesktopHint(shortcutDesc.getDesktop());
                appInfo.setMenuHint(shortcutDesc.getMenu());
                appInfo.setSubmenu(shortcutDesc.getSubmenu());
                break;
              } 
              appInfo.setDesktopHint(true);
              appInfo.setMenuHint(true);
              break;
          } 
          if (localInstallHandler.isAssociationSupported() && Config.getAssociationValue() != 0)
            appInfo.setAssociations(paramLaunchDesc.getInformation().getAssociations()); 
        } 
      } 
    } 
    try {
      if (bool) {
        setUnrestrictedProps(paramLaunchDesc);
        return 0L;
      } 
      if (appInfo != null && paramBoolean)
        appInfo.setPermissionAttrOverride(); 
      long l = TrustDecider.isAllPermissionGranted(paramCodeSource, appInfo, paramDeploymentRuleSet, paramPreloader);
      if (l != 0L) {
        PerfLogger.setTime("Security: End grantUnrestrictedAccess in AppPolicy class");
        setUnrestrictedProps(paramLaunchDesc);
        if (l != 1L)
          return l; 
        return 0L;
      } 
      Trace.println("We were not granted permission, exiting", TraceLevel.SECURITY);
    } catch (Exception exception) {
      if (exception instanceof BlockedException)
        throw (BlockedException)exception; 
      BadCertificateDialog.showDialog(paramCodeSource, appInfo, exception);
    } finally {
      if (appInfo != null)
        appInfo.unsetPermissionAttrOverride(); 
    } 
    Main.systemExit(-1);
    return 0L;
  }
  
  private void addJ2EEApplicationClientPermissionsObject(PermissionCollection paramPermissionCollection) {
    Trace.println("Creating J2EE-application-client-permisisons object", TraceLevel.SECURITY);
    paramPermissionCollection.add(new AWTPermission("accessClipboard"));
    paramPermissionCollection.add(new AWTPermission("accessEventQueue"));
    paramPermissionCollection.add(new AWTPermission("showWindowWithoutWarningBanner"));
    paramPermissionCollection.add(new RuntimePermission("exitVM"));
    paramPermissionCollection.add(new RuntimePermission("loadLibrary"));
    paramPermissionCollection.add(new RuntimePermission("queuePrintJob"));
    paramPermissionCollection.add(new SocketPermission("*", "connect"));
    paramPermissionCollection.add(new SocketPermission("localhost:1024-", "accept,listen"));
    paramPermissionCollection.add(new FilePermission("*", "read,write"));
    paramPermissionCollection.add(new PropertyPermission("*", "read"));
  }
  
  private void addSandboxPermissionsObject(PermissionCollection paramPermissionCollection, boolean paramBoolean) {
    Trace.println("Add sandbox permissions", TraceLevel.SECURITY);
    paramPermissionCollection.add(new PropertyPermission("java.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vendor", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vendor.url", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.class.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("os.name", "read"));
    paramPermissionCollection.add(new PropertyPermission("os.arch", "read"));
    paramPermissionCollection.add(new PropertyPermission("os.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("file.separator", "read"));
    paramPermissionCollection.add(new PropertyPermission("path.separator", "read"));
    paramPermissionCollection.add(new PropertyPermission("line.separator", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.specification.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.specification.vendor", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.specification.name", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vm.specification.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vm.specification.vendor", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vm.specification.name", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vm.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vm.vendor", "read"));
    paramPermissionCollection.add(new PropertyPermission("java.vm.name", "read"));
    paramPermissionCollection.add(new PropertyPermission("mrj.version", "read"));
    paramPermissionCollection.add(new PropertyPermission("javawebstart.version", "read"));
    if (JNLPClassLoaderUtil.getInstance() instanceof com.sun.jnlp.JNLPClassLoader) {
      paramPermissionCollection.add(new RuntimePermission("exitVM"));
      paramPermissionCollection.add(new RuntimePermission("stopThread"));
    } 
    String str = "Java " + (paramBoolean ? "Applet" : "Application") + " Window";
    if (Config.getBooleanProperty("deployment.security.sandbox.awtwarningwindow")) {
      System.setProperty("awt.appletWarning", str);
    } else {
      paramPermissionCollection.add(new AWTPermission("showWindowWithoutWarningBanner"));
    } 
    paramPermissionCollection.add(new PropertyPermission("jnlp.*", "read,write"));
    paramPermissionCollection.add(new PropertyPermission("javaws.*", "read,write"));
    paramPermissionCollection.add(new PropertyPermission("javapi.*", "read,write"));
    String[] arrayOfString1 = Config.getSecureProperties();
    for (byte b = 0; b < arrayOfString1.length; b++)
      paramPermissionCollection.add(new PropertyPermission(arrayOfString1[b], "read,write")); 
    String[] arrayOfString2 = Globals.getApplicationArgs();
    if (arrayOfString2 != null && arrayOfString2.length == 2)
      if (arrayOfString2[0].equals("-open")) {
        paramPermissionCollection.add(new FilePermission(arrayOfString2[1], "read, write"));
      } else if (arrayOfString2[0].equals("-print")) {
        paramPermissionCollection.add(new FilePermission(arrayOfString2[1], "read, write"));
        paramPermissionCollection.add(new RuntimePermission("queuePrintJob"));
      }  
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/security/AppPolicy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */