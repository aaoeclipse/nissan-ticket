package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;
import java.net.URL;

public class BadVersionResponseException extends DownloadException {
  private String _responseVersionID;
  
  public BadVersionResponseException(URL paramURL, String paramString1, String paramString2) {
    super(paramURL, paramString1);
    this._responseVersionID = paramString2;
  }
  
  public String getRealMessage() { return ResourceManager.getString("launch.error.badversionresponse", getResourceString(), this._responseVersionID); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/BadVersionResponseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */