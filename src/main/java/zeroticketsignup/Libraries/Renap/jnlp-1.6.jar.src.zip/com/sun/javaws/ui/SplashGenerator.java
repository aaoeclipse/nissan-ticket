package com.sun.javaws.ui;

import com.sun.deploy.config.Config;
import com.sun.deploy.config.Platform;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.ui.ImageLoader;
import com.sun.deploy.ui.ImageLoaderCallback;
import com.sun.javaws.jnl.IconDesc;
import com.sun.javaws.jnl.InformationDesc;
import com.sun.javaws.jnl.LaunchDesc;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URL;
import java.util.Properties;

class SplashGenerator extends Thread implements ImageLoaderCallback {
  private File _index;
  
  private File _dir;
  
  private final String _key;
  
  private final LaunchDesc _ld;
  
  private Properties _props = new Properties();
  
  public SplashGenerator(LaunchDesc paramLaunchDesc) {
    this._ld = paramLaunchDesc;
    this._dir = new File(Config.getSplashDir());
    this._key = this._ld.getSplashCanonicalHome();
    String str = Config.getSplashIndex();
    this._index = new File(str);
    Config.setSplashCache();
    Config.get().storeIfNeeded();
    if (this._index.exists())
      try {
        FileInputStream fileInputStream = new FileInputStream(this._index);
        if (fileInputStream != null) {
          this._props.load(fileInputStream);
          fileInputStream.close();
        } 
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      }  
  }
  
  public boolean needsCustomSplash() { return (this._key != null) ? (!this._props.containsKey(this._key)) : false; }
  
  public void remove() { addSplashToCacheIndex(this._key, null); }
  
  public void run() {
    InformationDesc informationDesc = this._ld.getInformation();
    IconDesc[] arrayOfIconDesc = informationDesc.getIcons();
    if (!this._dir.getParentFile().canWrite() || (this._dir.exists() && !this._dir.canWrite()) || (this._index.exists() && !this._index.canWrite()))
      return; 
    try {
      this._dir.mkdirs();
    } catch (Throwable throwable) {
      splashError(throwable);
    } 
    if (!Platform.get().isNativeSandbox())
      try {
        this._index.createNewFile();
      } catch (Throwable throwable) {
        splashError(throwable);
      }  
    IconDesc iconDesc = informationDesc.getIconLocation(48, 4);
    if (iconDesc == null)
      return; 
    ImageLoader.getInstance().loadImage(iconDesc.getLocation(), iconDesc.getVersion(), this);
  }
  
  public void imageAvailable(URL paramURL, String paramString, Image paramImage, File paramFile) {}
  
  public void finalImageAvailable(URL paramURL, String paramString, Image paramImage, File paramFile) {
    try {
      create(paramImage, paramFile);
    } catch (Throwable throwable) {
      if (throwable instanceof OutOfMemoryError) {
        splashError(throwable);
      } else {
        Trace.ignored(throwable);
      } 
    } 
  }
  
  public void create(Image paramImage, File paramFile) {
    InformationDesc informationDesc = this._ld.getInformation();
    int j = paramImage.getHeight(null);
    int i = paramImage.getWidth(null);
    if (paramFile != null)
      try {
        String str = paramFile.getCanonicalPath();
        addSplashToCacheIndex(this._key, str);
      } catch (Throwable throwable) {
        Trace.ignored(throwable);
      }  
  }
  
  private void addSplashToCacheIndex(String paramString1, String paramString2) {
    if (paramString1 == null)
      return; 
    if (paramString2 != null) {
      this._props.setProperty(paramString1, paramString2);
    } else if (this._props.containsKey(paramString1)) {
      this._props.remove(paramString1);
    } 
    File[] arrayOfFile = this._dir.listFiles();
    if (arrayOfFile == null)
      return; 
    for (byte b = 0; b < arrayOfFile.length; b++) {
      if (!arrayOfFile[b].equals(this._index))
        try {
          String str = arrayOfFile[b].getCanonicalPath();
          if (!this._props.containsValue(str))
            arrayOfFile[b].delete(); 
        } catch (IOException iOException) {
          splashError(iOException);
        }  
    } 
    try {
      OutputStream outputStream = Platform.get().getNativeSandboxBroker().getOutputStream(this._index, true);
      this._props.store(outputStream, "");
      outputStream.flush();
      outputStream.close();
    } catch (IOException iOException) {
      splashError(iOException);
    } 
  }
  
  private void splashError(Throwable paramThrowable) {
    LaunchErrorDialog.show(null, paramThrowable, false);
    throw new Error(paramThrowable.toString());
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/SplashGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */