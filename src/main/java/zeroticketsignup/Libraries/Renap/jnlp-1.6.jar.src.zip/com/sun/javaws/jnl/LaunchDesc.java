package com.sun.javaws.jnl;

import com.sun.deploy.Environment;
import com.sun.deploy.config.JREInfo;
import com.sun.deploy.net.HttpUtils;
import com.sun.deploy.ref.AppModel;
import com.sun.deploy.ref.AppRef;
import com.sun.deploy.ref.CodeInstance;
import com.sun.deploy.ref.CodeRef;
import com.sun.deploy.security.CachedCertificatesHelper;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.ArrayUtil;
import com.sun.deploy.util.SystemUtils;
import com.sun.deploy.util.URLUtil;
import com.sun.deploy.util.VersionID;
import com.sun.deploy.util.VersionString;
import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import com.sun.deploy.xml.XMLable;
import com.sun.javaws.HtmlOptions;
import com.sun.javaws.exceptions.JNLPSigningException;
import java.io.File;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;

public class LaunchDesc implements XMLable {
  private final String _specVersion;
  
  private final String _version;
  
  private final URL _home;
  
  private final URL _codebase;
  
  private final InformationDesc _information;
  
  private final int _securityModel;
  
  private final UpdateDesc _update;
  
  private final ResourcesDesc _resources;
  
  private final ResourcesDesc _rawResources;
  
  private final int _launchType;
  
  private final ApplicationDesc _applicationDesc;
  
  private final AppletDesc _appletDesc;
  
  private final JavaFXAppDesc _jfxDesc;
  
  private final LibraryDesc _libraryDesc;
  
  private final InstallerDesc _installerDesc;
  
  private final String _internalCommand;
  
  private volatile String _source;
  
  private volatile boolean _propsSet;
  
  private volatile byte[] _bits;
  
  private volatile JREInfo _selectedJRE;
  
  private volatile boolean _signed;
  
  private volatile LDUpdater _updater;
  
  private final XMLNode _xmlNode;
  
  private final CachedCertificatesHelper[] _certificates;
  
  private volatile String _hashString;
  
  private volatile boolean _trusted;
  
  private Object lock = new Object();
  
  private Object jreMatcherLock = new Object();
  
  private volatile JARDesc _mainJar;
  
  private volatile DeploymentRuleSet _drs;
  
  private volatile JREMatcher _jreMatcher;
  
  private volatile boolean nestedResourcesProcessed;
  
  private volatile URL _originalURL;
  
  private volatile URL _parentURL;
  
  public static final int SANDBOX_SECURITY = 0;
  
  public static final int ALLPERMISSIONS_SECURITY = 1;
  
  public static final int J2EE_APP_CLIENT_SECURITY = 2;
  
  public static final int APPLICATION_DESC_TYPE = 1;
  
  public static final int APPLET_DESC_TYPE = 2;
  
  public static final int LIBRARY_DESC_TYPE = 3;
  
  public static final int INSTALLER_DESC_TYPE = 4;
  
  public static final int INTERNAL_TYPE = 5;
  
  public static final int FXAPP_TYPE = 6;
  
  public LaunchDesc(String paramString1, URL paramURL1, URL paramURL2, String paramString2, InformationDesc paramInformationDesc, int paramInt1, CachedCertificatesHelper[] paramArrayOfCachedCertificatesHelper, UpdateDesc paramUpdateDesc, ResourcesDesc paramResourcesDesc, int paramInt2, ApplicationDesc paramApplicationDesc, AppletDesc paramAppletDesc, JavaFXAppDesc paramJavaFXAppDesc, LibraryDesc paramLibraryDesc, InstallerDesc paramInstallerDesc, String paramString3, XMLNode paramXMLNode, String paramString4) { this(paramString1, paramURL1, paramURL2, paramString2, paramInformationDesc, paramInt1, paramArrayOfCachedCertificatesHelper, paramUpdateDesc, paramResourcesDesc, paramInt2, paramApplicationDesc, paramAppletDesc, paramJavaFXAppDesc, paramLibraryDesc, paramInstallerDesc, paramString3, paramXMLNode, paramString4, null); }
  
  public JARDesc getMainJar() {
    if (this._mainJar == null && this._resources != null) {
      addNestedResourcesForRunningJRE();
      this._mainJar = this._resources.getMainJar();
      if (this._mainJar != null)
        this._mainJar.setLazyDownload(false); 
      storeVersionsInAppContext();
    } 
    return this._mainJar;
  }
  
  private void addNestedResourcesForRunningJRE() {
    if (!this.nestedResourcesProcessed)
      synchronized (this.lock) {
        if (!this.nestedResourcesProcessed) {
          LaunchSelection.addNestedResourcesForRunningJRE(this);
          this.nestedResourcesProcessed = true;
        } 
      }  
  }
  
  public String getDownloadHost() {
    JARDesc jARDesc = getMainJar();
    if (jARDesc != null) {
      URL uRL = jARDesc.getLocation();
      if (uRL != null)
        return uRL.getHost(); 
    } 
    return (this._codebase != null) ? this._codebase.getHost() : null;
  }
  
  public LaunchDesc(String paramString1, URL paramURL1, URL paramURL2, String paramString2, InformationDesc paramInformationDesc, int paramInt1, CachedCertificatesHelper[] paramArrayOfCachedCertificatesHelper, UpdateDesc paramUpdateDesc, ResourcesDesc paramResourcesDesc, int paramInt2, ApplicationDesc paramApplicationDesc, AppletDesc paramAppletDesc, JavaFXAppDesc paramJavaFXAppDesc, LibraryDesc paramLibraryDesc, InstallerDesc paramInstallerDesc, String paramString3, XMLNode paramXMLNode, String paramString4, JREMatcher paramJREMatcher) {
    this._specVersion = paramString1;
    this._version = paramString2;
    this._codebase = paramURL1;
    this._home = paramURL2;
    this._information = paramInformationDesc;
    this._securityModel = paramInt1;
    this._update = paramUpdateDesc;
    this._resources = paramResourcesDesc;
    this._launchType = paramInt2;
    this._applicationDesc = paramApplicationDesc;
    this._appletDesc = paramAppletDesc;
    this._jfxDesc = paramJavaFXAppDesc;
    this._libraryDesc = paramLibraryDesc;
    this._installerDesc = paramInstallerDesc;
    this._internalCommand = paramString3;
    this._xmlNode = paramXMLNode;
    this._source = paramString4;
    this._signed = false;
    this._certificates = paramArrayOfCachedCertificatesHelper;
    if (this._resources != null) {
      this._resources.setParent(this);
      this._rawResources = this._resources.clone();
    } else {
      this._rawResources = null;
    } 
  }
  
  public CachedCertificatesHelper[] getCachedCertificates() { return this._certificates; }
  
  public URL getSourceURL() { return this._originalURL; }
  
  public void setSourceURL(URL paramURL) { this._originalURL = paramURL; }
  
  public void setParentURL(URL paramURL) { this._parentURL = paramURL; }
  
  public URL getParentURL() { return this._parentURL; }
  
  public JREInfo getHomeJRE() { return HomeJreInitializer.homeJRE; }
  
  public JREMatcher getJREMatcher() {
    JREMatcher jREMatcher = getMatchImpl();
    if (!jREMatcher.hasBeenRun())
      selectJRE(jREMatcher.getSecureOnly()); 
    return jREMatcher;
  }
  
  public JREInfo selectJRE(boolean paramBoolean) {
    getMatchImpl().setSecureOnly(paramBoolean);
    this._selectedJRE = LaunchSelection.selectJRE(this, getMatchImpl());
    Trace.println("LaunchDesc.selectJRE( returning selected jre: " + this._selectedJRE, TraceLevel.BASIC);
    return this._selectedJRE;
  }
  
  public String getSpecVersion() { return this._specVersion; }
  
  public URL getCodebase() { return this._codebase; }
  
  public URL getDocumentBase() {
    if (getLaunchType() == 2) {
      URL uRL = getAppletDescriptor().getDocumentBase();
      if (uRL != null)
        return uRL; 
    } 
    return getCodebase();
  }
  
  public byte[] getBytes() {
    if (this._bits == null)
      this._bits = getSource().getBytes(); 
    return this._bits;
  }
  
  public URL getLocation() { return this._home; }
  
  public URL getCanonicalHome() {
    if (this._home != null)
      return this._home; 
    if (this._originalURL != null && Environment.isJavaPlugin() && !Environment.isJavawsAppletLifecycle())
      return this._originalURL; 
    if (this._resources != null) {
      JARDesc jARDesc = getMainJar();
      try {
        if (jARDesc != null) {
          URL uRL = HttpUtils.removeQueryStringFromURL(jARDesc.getLocation());
          return new URL(uRL.toString() + "jnlp");
        } 
        ExtensionDesc[] arrayOfExtensionDesc = this._resources.getExtensionDescs();
        if (arrayOfExtensionDesc.length > 0) {
          URL uRL = HttpUtils.removeQueryStringFromURL(arrayOfExtensionDesc[0].getLocation());
          return new URL(uRL.toString() + ".jarjnlp");
        } 
      } catch (MalformedURLException malformedURLException) {
        Trace.ignoredException(malformedURLException);
      } 
    } 
    return null;
  }
  
  public final URL getRealLocation() { return (this._home == null) ? this._originalURL : this._home; }
  
  private URL getJNLPSrcForAppInfo() {
    URL uRL = getRealLocation();
    if (uRL == null)
      uRL = AppInfo.getJNLPFromUnknownSource(); 
    return uRL;
  }
  
  private URL getAppFromLocation() {
    URL uRL = null;
    if (this._resources != null) {
      JARDesc jARDesc = getMainJar();
      try {
        if (jARDesc != null) {
          URL uRL1 = HttpUtils.removeQueryStringFromURL(jARDesc.getLocation());
          uRL = new URL(uRL1.toString() + "jnlp");
        } else {
          uRL = getCodebase();
        } 
      } catch (MalformedURLException malformedURLException) {
        Trace.ignoredException(malformedURLException);
      } 
    } 
    if (uRL == null)
      uRL = (this._originalURL != null) ? this._originalURL : this._home; 
    return uRL;
  }
  
  public String getSplashCanonicalHome() {
    if (this._home == null) {
      if (this._resources == null)
        return null; 
      JARDesc jARDesc = getMainJar();
      return (jARDesc != null) ? (jARDesc.getLocation().toString() + "jnlp") : null;
    } 
    return this._home.toString();
  }
  
  public InformationDesc getInformation() { return this._information; }
  
  public String getInternalCommand() { return this._internalCommand; }
  
  public int getSecurityModel() { return this._securityModel; }
  
  public UpdateDesc getUpdate() { return this._update; }
  
  public boolean isSigned() { return this._signed; }
  
  public boolean hasIdenticalContent(LaunchDesc paramLaunchDesc) { return (this._xmlNode != null && paramLaunchDesc != null && this._xmlNode.equals(paramLaunchDesc._xmlNode)); }
  
  public boolean hasIdenticalContent(File paramFile) {
    try {
      byte[] arrayOfByte = SystemUtils.readBytes(new FileInputStream(paramFile), paramFile.length());
      XMLNode xMLNode = XMLFormat.parseBits(arrayOfByte);
      return this._xmlNode.equals(xMLNode);
    } catch (Exception exception) {
      return false;
    } 
  }
  
  public boolean equalsTemplate(XMLNode paramXMLNode) { return (this._xmlNode != null && !XMLFormat.isBlacklisted(paramXMLNode) && this._xmlNode.equalsTemplate(paramXMLNode)); }
  
  public boolean checkSigningTemplate(byte[] paramArrayOfbyte) throws JNLPSigningException {
    XMLNode xMLNode = null;
    try {
      xMLNode = XMLFormat.parseBits(paramArrayOfbyte);
      if (equalsTemplate(xMLNode)) {
        this._signed = true;
        return true;
      } 
    } catch (Exception exception) {
      Trace.ignored(exception);
    } 
    throw new JNLPSigningException(this, (xMLNode == null) ? new String(paramArrayOfbyte) : xMLNode.toString(true));
  }
  
  public void setTrusted() {
    Trace.println("Mark trusted: " + this._home, TraceLevel.SECURITY);
    this._trusted = true;
  }
  
  public boolean isTrusted() {
    Trace.println("Istrusted: " + this._home + " " + this._trusted, TraceLevel.SECURITY);
    return this._trusted;
  }
  
  public boolean isSecure() { return (0 == getSecurityModel()); }
  
  public boolean isSecureJVMArgs() { return getJREMatcher().getSelectedJVMParameters().isSecure(); }
  
  public ResourcesDesc getResources() { return this._resources; }
  
  public boolean arePropsSet() { return this._propsSet; }
  
  public void setPropsSet(boolean paramBoolean) { this._propsSet = paramBoolean; }
  
  public ResourcesDesc getRawResources() { return this._rawResources; }
  
  public JREInfo getSelectedJRE() {
    if (this._selectedJRE == null)
      selectJRE(getMatchImpl().getSecureOnly()); 
    return this._selectedJRE;
  }
  
  private JREMatcher getMatchImpl() {
    if (this._jreMatcher == null) {
      DeploymentRuleSet deploymentRuleSet = getMainDeploymentRuleSet();
      synchronized (this.jreMatcherLock) {
        if (this._jreMatcher == null) {
          this._jreMatcher = new JREMatcher();
          this._jreMatcher.setDRSVersion(deploymentRuleSet.getVersionString(), deploymentRuleSet.isVersionForced());
        } 
      } 
    } 
    return this._jreMatcher;
  }
  
  public int getLaunchType() { return this._launchType; }
  
  public ApplicationDesc getApplicationDescriptor() { return this._applicationDesc; }
  
  public AppletDesc getAppletDescriptor() { return this._appletDesc; }
  
  public JavaFXAppDesc getJavaFXAppDescriptor() { return this._jfxDesc; }
  
  public InstallerDesc getInstallerDescriptor() { return this._installerDesc; }
  
  public final boolean isApplication() { return (this._launchType == 1); }
  
  public final boolean isApplet() { return (this._launchType == 2); }
  
  public final boolean isLibrary() { return (this._launchType == 3); }
  
  public final boolean isInstaller() { return (this._launchType == 4); }
  
  public final boolean isFXAppOnly() { return (this._launchType == 6); }
  
  public final boolean isFXApp() { return (getJavaFXAppDescriptor() != null); }
  
  public final boolean needFX() { return (isFXApp() || null != getJavaFXRuntimeDescriptor()); }
  
  public final boolean isApplicationDescriptor() { return (isApplication() || isApplet() || isFXAppOnly()); }
  
  public String getMainClassName() {
    if (isFXApp())
      return getJavaFXAppDescriptor().getMainClass(); 
    switch (getLaunchType()) {
      case 1:
        return getApplicationDescriptor().getMainClass();
      case 4:
        return getInstallerDescriptor().getMainClass();
      case 2:
        return getAppletDescriptor().getAppletClass();
    } 
    return null;
  }
  
  public String getArgumentsString() {
    if (isFXApp())
      return ArrayUtil.propertiesToString(getJavaFXAppDescriptor().getParameters()); 
    switch (getLaunchType()) {
      case 1:
        return ArrayUtil.arrayToString(getApplicationDescriptor().getArguments());
      case 2:
        return ArrayUtil.propertiesToString(getAppletDescriptor().getParameters());
    } 
    return null;
  }
  
  public boolean isHttps() {
    if (this._codebase != null)
      return this._codebase.getProtocol().equals("https"); 
    getCanonicalHome();
    return (this._home != null) ? this._home.getProtocol().equals("https") : false;
  }
  
  public String getSource() {
    if (this._source == null)
      this._source = this._xmlNode.toString(); 
    return this._source;
  }
  
  public XMLNode getXmlNode() { return this._xmlNode; }
  
  public void checkSigning(LaunchDesc paramLaunchDesc) throws JNLPSigningException {
    if (paramLaunchDesc != null && paramLaunchDesc.getXmlNode().equals(getXmlNode())) {
      this._signed = true;
    } else {
      throw new JNLPSigningException(this, paramLaunchDesc.getXmlNode().toString(true));
    } 
  }
  
  public boolean isJRESpecified() {
    final boolean[] hasJre = new boolean[1];
    final boolean[] needJre = new boolean[1];
    if (getResources() != null)
      getResources().visit(new ResourceVisitor() {
            public void visitJARDesc(JARDesc param1JARDesc) { needJre[0] = true; }
            
            public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) { needJre[0] = true; }
            
            public void visitJREDesc(JREDesc param1JREDesc) { hasJre[0] = true; }
          }); 
    if (this._launchType == 1 || this._launchType == 2)
      arrayOfBoolean2[0] = true; 
    return (arrayOfBoolean1[0] || !arrayOfBoolean2[0]);
  }
  
  public AppInfo getAppInfo() {
    AppInfo appInfo = new AppInfo(getLaunchType(), this._information.getTitle(), this._information.getVendor(), getAppFromLocation(), getJNLPSrcForAppInfo(), null, null, false, false, null, null);
    appInfo.setSecurity(isSecure() ? 1 : 2);
    appInfo.setLapURL(getCanonicalHome());
    appInfo.setDocumentBase(this._parentURL);
    IconDesc iconDesc = this._information.getIconLocation(48, 0);
    if (iconDesc != null) {
      appInfo.setIconRef(iconDesc.getLocation());
      appInfo.setIconVersion(iconDesc.getVersion());
    } 
    appInfo.setSignedJNLPL(isSigned());
    JARDesc jARDesc = getMainJar();
    if (jARDesc != null) {
      appInfo.setEMURL(jARDesc.getLocation());
      appInfo.setEMVersion(jARDesc.getVersion());
    } 
    String str = getSource();
    if (HtmlOptions.get() != null) {
      String[] arrayOfString = HtmlOptions.get().getHtmlApplicationArgs();
      if (arrayOfString != null)
        for (byte b = 0; b < arrayOfString.length; b++)
          str = str + "," + arrayOfString[b];  
    } 
    appInfo.setAppArgs(str);
    appInfo.setAppModel(getAppModel());
    return appInfo;
  }
  
  public LDUpdater getUpdater() {
    if (this._updater == null)
      synchronized (this) {
        if (this._updater == null)
          this._updater = new LDUpdater(this); 
      }  
    return this._updater;
  }
  
  protected boolean isNestedResourcesProcessed() { return this.nestedResourcesProcessed; }
  
  protected void setNestedResourcesProcessed(boolean paramBoolean) { this.nestedResourcesProcessed = paramBoolean; }
  
  public String getProgressClassName() {
    String str = null;
    if (this._jfxDesc != null) {
      str = this._jfxDesc.getPreloaderClass();
    } else if (this._applicationDesc != null) {
      str = this._applicationDesc.getProgressClass();
    } else if (this._appletDesc != null) {
      str = this._appletDesc.getProgressClass();
    } else if (this._libraryDesc != null) {
      str = this._libraryDesc.getProgressClass();
    } else {
      str = null;
    } 
    if (str != null)
      return str; 
    final String[] results = new String[1];
    if (getResources() != null)
      getResources().visit(new ResourceVisitor() {
            public void visitExtensionDesc(ExtensionDesc param1ExtensionDesc) {
              LaunchDesc launchDesc = param1ExtensionDesc.getExtensionDesc();
              if (launchDesc != null && results[0] == null)
                results[0] = launchDesc.getProgressClassName(); 
            }
          }); 
    return arrayOfString[0];
  }
  
  public JavaFXRuntimeDesc getJavaFXRuntimeDescriptor() {
    final JavaFXRuntimeDesc[] jfxd = { null };
    if (getResources() != null)
      getResources().visit(new ResourceVisitor() {
            public void visitJFXDesc(JavaFXRuntimeDesc param1JavaFXRuntimeDesc) { jfxd[0] = param1JavaFXRuntimeDesc; }
          }); 
    return arrayOfJavaFXRuntimeDesc[0];
  }
  
  public boolean isValidSpecificationVersion() {
    VersionString versionString = new VersionString(getSpecVersion());
    return (versionString.contains(new VersionID("8.20")) || versionString.contains(new VersionID("7.0")) || versionString.contains(new VersionID("6.0.18")) || versionString.contains(new VersionID("6.0.10")) || versionString.contains(new VersionID("6.0")) || versionString.contains(new VersionID("1.5")) || versionString.contains(new VersionID("1.0")));
  }
  
  public URL getHtmlLocation() {
    if (getLaunchType() == 2) {
      URL uRL = getAppletDescriptor().getDocumentBase();
      if (uRL != null)
        return uRL; 
    } 
    return null;
  }
  
  public URL getMainJarURL() {
    JARDesc jARDesc = this._resources.getMainJar();
    if (jARDesc != null) {
      URL uRL = jARDesc.getLocation();
      return URLUtil.getBase(uRL);
    } 
    return null;
  }
  
  public URL getAnchorURL() {
    URL uRL = getRealLocation();
    if (uRL == null) {
      JARDesc jARDesc = getMainJar();
      if (jARDesc != null)
        uRL = jARDesc.getLocation(); 
    } 
    return uRL;
  }
  
  public static AppRef getJNLPAppRef(LaunchDesc paramLaunchDesc) {
    URL uRL1 = paramLaunchDesc.getRealLocation();
    URL uRL2 = (uRL1 != null) ? uRL1 : null;
    URL uRL3 = paramLaunchDesc.getHtmlLocation();
    return new AppRef(AppRef.Type.JNLP, paramLaunchDesc.getInformation().getTitle(), uRL3, uRL2, paramLaunchDesc.getAnchorURL(), paramLaunchDesc.getHash());
  }
  
  public String getHash() {
    if (this._hashString == null)
      this._hashString = SystemUtils.getChecksum(getBytes(), "SHA-256"); 
    return this._hashString;
  }
  
  public DeploymentRuleSet getMainDeploymentRuleSet() {
    if (this._drs == null) {
      JARDesc jARDesc = getMainJar();
      CodeRef codeRef = (jARDesc != null) ? jARDesc.getCodeRef() : new CodeRef(null, null, false, false);
      AppRef appRef = getJNLPAppRef(this);
      Trace.println("Jnlp based appRef: " + appRef, TraceLevel.RULESET);
      Trace.println("Jnlp based codeRef: " + codeRef, TraceLevel.RULESET);
      this._drs = DeploymentRuleSet.findDRS(new CodeInstance(appRef, codeRef));
    } 
    return this._drs;
  }
  
  public void storeVersionsInAppContext() {
    ResourcesDesc resourcesDesc = getResources();
    if (resourcesDesc == null)
      return; 
    JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(true);
    if (arrayOfJARDesc == null)
      return; 
    for (byte b = 0; b < arrayOfJARDesc.length; b++) {
      if (arrayOfJARDesc[b] != null) {
        String str = arrayOfJARDesc[b].getVersion();
        URL uRL = arrayOfJARDesc[b].getLocation();
        if (str != null) {
          ToolkitStore.get().getAppContext().put("deploy-" + uRL.toString(), str);
          if (arrayOfJARDesc[b].isPack200Enabled() || arrayOfJARDesc[b].isVersionEnabled()) {
            if (arrayOfJARDesc[b].isVersionEnabled())
              uRL = URLUtil.getEmbeddedVersionURL(uRL, str); 
            if (arrayOfJARDesc[b].isPack200Enabled())
              uRL = URLUtil.getPack200URL(uRL, false); 
            ToolkitStore.get().getAppContext().put("deploy-" + uRL.toString(), str);
          } 
        } 
      } 
    } 
  }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("spec", this._specVersion);
    xMLAttributeBuilder.add("codebase", this._codebase);
    xMLAttributeBuilder.add("version", this._version);
    xMLAttributeBuilder.add("href", this._home);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("jnlp", xMLAttributeBuilder.getAttributeList());
    xMLNodeBuilder.add(this._information);
    if (this._securityModel != 0) {
      XMLNode xMLNode = null;
      String str = "all-permissions";
      if (this._securityModel == 2)
        str = "j2ee-application-client-permissions"; 
      if (this._certificates != null) {
        XMLAttributeBuilder xMLAttributeBuilder1 = new XMLAttributeBuilder();
        xMLAttributeBuilder1.add("signedjnlp", this._certificates[0].isSignedJNLP());
        XMLNodeBuilder xMLNodeBuilder1 = new XMLNodeBuilder("security", null);
        XMLNodeBuilder xMLNodeBuilder2 = new XMLNodeBuilder("jfx:details", xMLAttributeBuilder1.getAttributeList());
        for (byte b = 0; b < this._certificates.length; b++) {
          XMLAttributeBuilder xMLAttributeBuilder2 = new XMLAttributeBuilder();
          if (this._certificates[b].getTimestamp() != null)
            xMLAttributeBuilder2.add("timestamp", "" + this._certificates[b].getTimestamp().getTime()); 
          XMLNodeBuilder xMLNodeBuilder3 = new XMLNodeBuilder("jfx:certificate-path", xMLAttributeBuilder2.getAttributeList());
          xMLNodeBuilder3.add(new XMLNode(this._certificates[b].exportCertificatesToBase64()));
          xMLNodeBuilder2.add(xMLNodeBuilder3.getNode());
        } 
        xMLNodeBuilder1.add(new XMLNode(str, null));
        xMLNodeBuilder1.add(xMLNodeBuilder2.getNode());
        xMLNode = xMLNodeBuilder1.getNode();
      } else {
        xMLNode = new XMLNode("security", null, new XMLNode(str, null), null);
      } 
      xMLNodeBuilder.add(xMLNode);
    } 
    xMLNodeBuilder.add(this._update);
    xMLNodeBuilder.add(this._resources);
    xMLNodeBuilder.add(this._applicationDesc);
    xMLNodeBuilder.add(this._appletDesc);
    xMLNodeBuilder.add(this._jfxDesc);
    xMLNodeBuilder.add(this._libraryDesc);
    xMLNodeBuilder.add(this._installerDesc);
    return xMLNodeBuilder.getNode();
  }
  
  public String toString() { return asXML().toString(); }
  
  public String getVersion() { return this._version; }
  
  private AppModel.SecurityMode getSecurityMode() {
    switch (getSecurityModel()) {
      case 0:
        return AppModel.SecurityMode.SANDBOX;
      case 1:
        return AppModel.SecurityMode.ALL_PERMISSIONS;
      case 2:
        return AppModel.SecurityMode.J2EE_APPLICATION_CLIENT_PERMISSIONS;
    } 
    return null;
  }
  
  public AppModel getAppModel() {
    AppModel appModel = new AppModel();
    appModel.setType(isApplication() ? AppModel.Type.APPLICATION : AppModel.Type.APPLET);
    appModel.setSecurityMode(getSecurityMode());
    appModel.setTitle(getInformation().getTitle());
    appModel.setVendor(getInformation().getVendor());
    appModel.setDescription(getInformation().getDescription(0));
    appModel.setLocation(getLocation());
    appModel.setCodebase(getCodebase());
    appModel.setMainClass(getMainClassName());
    if (getResources() != null) {
      for (JARDesc jARDesc : getResources().getLocalJarDescs())
        appModel.addJarResource(jARDesc.getLocation(), jARDesc.getVersion()); 
      for (ExtensionDesc extensionDesc : getResources().getExtensionDescs())
        appModel.addExtensionResource(extensionDesc.getLocation(), extensionDesc.getName()); 
    } 
    return appModel;
  }
  
  private static class HomeJreInitializer {
    static final JREInfo homeJRE = JREInfo.getHomeJRE();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/LaunchDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */