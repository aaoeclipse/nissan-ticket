package com.sun.javaws.jnl;

import com.sun.deploy.util.URLUtil;
import com.sun.javaws.exceptions.BadFieldException;
import java.net.MalformedURLException;
import java.net.URL;

public class EmbeddedJNLPValidation {
  private final LaunchDesc jnlp;
  
  private final URL codebase;
  
  public EmbeddedJNLPValidation(LaunchDesc paramLaunchDesc, URL paramURL) {
    if (paramURL == null || paramLaunchDesc == null)
      throw new IllegalArgumentException("Should have jnlp and derivedCodebase."); 
    if (paramURL.getProtocol().equals("http")) {
      String str = paramURL.getHost();
      if (str == null || str.length() == 0)
        throw new IllegalArgumentException("Bad derivedCodebase: " + paramURL); 
    } 
    this.jnlp = paramLaunchDesc;
    this.codebase = paramURL;
  }
  
  public void validate() throws BadFieldException {
    String str1 = getCodebase();
    if (str1 != null && str1.trim().length() > 0)
      throw new RuntimeException("Embbeded JNLP should not have non-empty codebase. Got: " + str1); 
    String str2 = getHref();
    if (str2 == null) {
      str2 = "";
    } else {
      str2 = str2.trim();
    } 
    try {
      URL uRL = new URL(str2);
      throw new RuntimeException("Absolute href not allowed with embbedded JNLP: " + str2);
    } catch (MalformedURLException malformedURLException) {
      try {
        URL uRL = new URL(this.codebase, str2);
        if (!URLUtil.sameBase(this.codebase, uRL))
          throw new RuntimeException("Invalid 'href' value in embedded JNLP: " + str2); 
      } catch (MalformedURLException malformedURLException1) {
        throw new RuntimeException("Invalid URL derived with href: " + str2, malformedURLException1);
      } 
      return;
    } 
  }
  
  private String getCodebase() throws BadFieldException { return XMLUtils.getAttribute(this.jnlp.getXmlNode(), "", "codebase"); }
  
  private String getHref() throws BadFieldException { return XMLUtils.getAttribute(this.jnlp.getXmlNode(), "", "href"); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/EmbeddedJNLPValidation.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */