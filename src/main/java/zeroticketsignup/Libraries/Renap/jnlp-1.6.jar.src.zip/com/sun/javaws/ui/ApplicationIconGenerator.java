package com.sun.javaws.ui;

import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.Config;
import com.sun.deploy.trace.Trace;
import com.sun.javaws.IconUtil;
import com.sun.javaws.jnl.LaunchDesc;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class ApplicationIconGenerator extends Thread {
  private File _index;
  
  private File _dir;
  
  private final String _key;
  
  private final LaunchDesc _ld;
  
  private Properties _props = new Properties();
  
  public static void generate(LaunchDesc paramLaunchDesc, boolean paramBoolean) {
    if (!Cache.isCacheEnabled())
      return; 
    if (paramLaunchDesc.isApplicationDescriptor()) {
      ApplicationIconGenerator applicationIconGenerator = new ApplicationIconGenerator(paramLaunchDesc);
      if (paramBoolean || applicationIconGenerator.needsCustomIcon())
        applicationIconGenerator.start(); 
    } 
  }
  
  public static void removeCustomIcon(LaunchDesc paramLaunchDesc) {
    if (paramLaunchDesc.isApplicationDescriptor()) {
      ApplicationIconGenerator applicationIconGenerator = new ApplicationIconGenerator(paramLaunchDesc);
      applicationIconGenerator.remove();
    } 
  }
  
  public ApplicationIconGenerator(LaunchDesc paramLaunchDesc) {
    this._ld = paramLaunchDesc;
    this._dir = new File(Config.getAppIconDir());
    this._key = this._ld.getSplashCanonicalHome();
    String str = Config.getAppIconIndex();
    this._index = new File(str);
    Config.setAppIconCache();
    Config.get().storeIfNeeded();
    if (this._index.exists())
      try {
        FileInputStream fileInputStream = new FileInputStream(this._index);
        if (fileInputStream != null) {
          this._props.load(fileInputStream);
          fileInputStream.close();
        } 
      } catch (IOException iOException) {
        Trace.ignoredException(iOException);
      }  
  }
  
  public boolean needsCustomIcon() { return (this._key != null) ? (!this._props.containsKey(this._key)) : false; }
  
  public void remove() { addAppIconToCacheIndex(this._key, null); }
  
  public void run() {
    if (!this._dir.getParentFile().canWrite() || (this._dir.exists() && !this._dir.canWrite()) || (this._index.exists() && !this._index.canWrite()))
      return; 
    try {
      this._dir.mkdirs();
    } catch (Throwable throwable) {
      appIconError(throwable);
    } 
    try {
      this._index.createNewFile();
    } catch (Throwable throwable) {
      appIconError(throwable);
    } 
    String str = IconUtil.getIconPath(this._ld);
    if (str == null)
      return; 
    try {
      addAppIconToCacheIndex(this._key, str);
    } catch (Throwable throwable) {
      Trace.ignored(throwable);
    } 
  }
  
  private void addAppIconToCacheIndex(String paramString1, String paramString2) {
    if (paramString1 == null)
      return; 
    if (paramString2 != null) {
      this._props.setProperty(paramString1, paramString2);
    } else if (this._props.containsKey(paramString1)) {
      this._props.remove(paramString1);
    } 
    File[] arrayOfFile = this._dir.listFiles();
    if (arrayOfFile == null)
      return; 
    for (byte b = 0; b < arrayOfFile.length; b++) {
      if (!arrayOfFile[b].equals(this._index))
        try {
          String str = arrayOfFile[b].getCanonicalPath();
          if (!this._props.containsValue(str))
            arrayOfFile[b].delete(); 
        } catch (IOException iOException) {
          appIconError(iOException);
        }  
    } 
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(this._index);
      this._props.store(fileOutputStream, "");
      fileOutputStream.flush();
      fileOutputStream.close();
    } catch (IOException iOException) {
      appIconError(iOException);
    } 
  }
  
  private void appIconError(Throwable paramThrowable) {
    LaunchErrorDialog.show(null, paramThrowable, false);
    throw new Error(paramThrowable.toString());
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/ApplicationIconGenerator.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */