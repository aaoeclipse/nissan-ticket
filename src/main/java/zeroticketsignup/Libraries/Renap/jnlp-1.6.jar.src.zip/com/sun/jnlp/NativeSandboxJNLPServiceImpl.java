package com.sun.jnlp;

import com.sun.deploy.nativesandbox.NativeSandboxJNLPService;
import com.sun.deploy.trace.Trace;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javax.jnlp.BasicService;
import javax.jnlp.IntegrationService;
import javax.jnlp.ServiceManager;
import javax.jnlp.UnavailableServiceException;

public class NativeSandboxJNLPServiceImpl implements NativeSandboxJNLPService {
  public String openFileDialog(String paramString, String[] paramArrayOfString) {
    try {
      FileOpenServiceImpl fileOpenServiceImpl = (FileOpenServiceImpl)ServiceManager.lookup("javax.jnlp.FileOpenService");
      return fileOpenServiceImpl.openFileDialogNSB(paramString, paramArrayOfString);
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
      return null;
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return null;
    } 
  }
  
  public String[] openMultiFileDialog(String paramString, String[] paramArrayOfString) {
    try {
      FileOpenServiceImpl fileOpenServiceImpl = (FileOpenServiceImpl)ServiceManager.lookup("javax.jnlp.FileOpenService");
      return fileOpenServiceImpl.openMultiFileDialogNSB(paramString, paramArrayOfString);
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
      return null;
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return null;
    } 
  }
  
  public String saveFile(String paramString1, String[] paramArrayOfString, String paramString2) {
    try {
      FileSaveServiceImpl fileSaveServiceImpl = (FileSaveServiceImpl)ServiceManager.lookup("javax.jnlp.FileSaveService");
      return fileSaveServiceImpl.saveFileDialogNSB(paramString1, paramArrayOfString, paramString2);
    } catch (IOException iOException) {
      Trace.ignoredException(iOException);
      return null;
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return null;
    } 
  }
  
  public boolean openFile(String paramString) {
    try {
      ExtendedServiceImpl extendedServiceImpl = (ExtendedServiceImpl)ServiceManager.lookup("javax.jnlp.ExtendedService");
      return extendedServiceImpl.openFile(paramString);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } 
  }
  
  public boolean openFiles(String[] paramArrayOfString) {
    try {
      ExtendedServiceImpl extendedServiceImpl = (ExtendedServiceImpl)ServiceManager.lookup("javax.jnlp.ExtendedService");
      return extendedServiceImpl.openFiles(paramArrayOfString);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } 
  }
  
  public boolean removeAssociation(String paramString, String[] paramArrayOfString) {
    try {
      IntegrationService integrationService = (IntegrationService)ServiceManager.lookup("javax.jnlp.IntegrationService");
      return integrationService.removeAssociation(paramString, paramArrayOfString);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } 
  }
  
  public boolean removeShortcuts() {
    try {
      IntegrationService integrationService = (IntegrationService)ServiceManager.lookup("javax.jnlp.IntegrationService");
      return integrationService.removeShortcuts();
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } 
  }
  
  public boolean requestAssociation(String paramString, String[] paramArrayOfString) {
    try {
      IntegrationService integrationService = (IntegrationService)ServiceManager.lookup("javax.jnlp.IntegrationService");
      return integrationService.requestAssociation(paramString, paramArrayOfString);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } 
  }
  
  public boolean requestShortcut(boolean paramBoolean1, boolean paramBoolean2, String paramString) {
    try {
      IntegrationService integrationService = (IntegrationService)ServiceManager.lookup("javax.jnlp.IntegrationService");
      return integrationService.requestShortcut(paramBoolean1, paramBoolean2, paramString);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } 
  }
  
  public long createMuffin(String paramString, long paramLong) throws IOException {
    try {
      PersistenceServiceImpl persistenceServiceImpl = (PersistenceServiceImpl)ServiceManager.lookup("javax.jnlp.PersistenceService");
      return persistenceServiceImpl.create(new URL(paramString), paramLong);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return -1L;
    } 
  }
  
  public void deleteMuffin(String paramString) throws IOException {
    try {
      PersistenceServiceImpl persistenceServiceImpl = (PersistenceServiceImpl)ServiceManager.lookup("javax.jnlp.PersistenceService");
      persistenceServiceImpl.delete(new URL(paramString));
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
    } 
  }
  
  public String getMuffin(String paramString) throws IOException {
    try {
      PersistenceServiceImpl persistenceServiceImpl = (PersistenceServiceImpl)ServiceManager.lookup("javax.jnlp.PersistenceService");
      return persistenceServiceImpl.get(paramString);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return null;
    } 
  }
  
  public void setMuffinTag(String paramString, int paramInt) throws IOException {
    try {
      PersistenceServiceImpl persistenceServiceImpl = (PersistenceServiceImpl)ServiceManager.lookup("javax.jnlp.PersistenceService");
      persistenceServiceImpl.setTag(new URL(paramString), paramInt);
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
    } 
  }
  
  public boolean showDocument(String paramString) {
    try {
      BasicService basicService = (BasicService)ServiceManager.lookup("javax.jnlp.BasicService");
      return basicService.showDocument(new URL(paramString));
    } catch (UnavailableServiceException unavailableServiceException) {
      Trace.ignoredException((Exception)unavailableServiceException);
      return false;
    } catch (MalformedURLException malformedURLException) {
      Trace.ignoredException(malformedURLException);
      return false;
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/NativeSandboxJNLPServiceImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */