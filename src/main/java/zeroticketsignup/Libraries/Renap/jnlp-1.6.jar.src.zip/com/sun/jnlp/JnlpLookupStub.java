package com.sun.jnlp;

import java.security.AccessController;
import java.security.PrivilegedAction;
import javax.jnlp.ServiceManagerStub;
import javax.jnlp.UnavailableServiceException;

public final class JnlpLookupStub implements ServiceManagerStub {
  public Object lookup(final String name) throws UnavailableServiceException {
    Object object = AccessController.doPrivileged(new PrivilegedAction<Object>() {
          public Object run() { return JnlpLookupStub.this.findService(name); }
        });
    if (object == null)
      throw new UnavailableServiceException(name); 
    return object;
  }
  
  private Object findService(String paramString) {
    if (paramString != null) {
      JNLPClassLoaderIf jNLPClassLoaderIf = JNLPClassLoaderUtil.getInstance();
      if (jNLPClassLoaderIf == null)
        return null; 
      if (paramString.equals("javax.jnlp.BasicService"))
        return jNLPClassLoaderIf.getBasicService(); 
      if (paramString.equals("javax.jnlp.FileOpenService"))
        return jNLPClassLoaderIf.getFileOpenService(); 
      if (paramString.equals("javax.jnlp.FileSaveService"))
        return jNLPClassLoaderIf.getFileSaveService(); 
      if (paramString.equals("javax.jnlp.ExtensionInstallerService"))
        return jNLPClassLoaderIf.getExtensionInstallerService(); 
      if (paramString.equals("javax.jnlp.DownloadService"))
        return jNLPClassLoaderIf.getDownloadService(); 
      if (paramString.equals("javax.jnlp.ClipboardService"))
        return jNLPClassLoaderIf.getClipboardService(); 
      if (paramString.equals("javax.jnlp.PrintService"))
        return jNLPClassLoaderIf.getPrintService(); 
      if (paramString.equals("javax.jnlp.PersistenceService"))
        return jNLPClassLoaderIf.getPersistenceService(); 
      if (paramString.equals("javax.jnlp.ExtendedService"))
        return jNLPClassLoaderIf.getExtendedService(); 
      if (paramString.equals("javax.jnlp.SingleInstanceService"))
        return jNLPClassLoaderIf.getSingleInstanceService(); 
      if (paramString.equals("javax.jnlp.IntegrationService"))
        return jNLPClassLoaderIf.getIntegrationService(); 
      if (paramString.equals("javax.jnlp.DownloadService2"))
        return jNLPClassLoaderIf.getDownloadService2(); 
    } 
    return null;
  }
  
  public String[] getServiceNames() { return (ExtensionInstallerServiceImpl.getInstance() != null) ? new String[] { 
        "javax.jnlp.BasicService", "javax.jnlp.FileOpenService", "javax.jnlp.FileSaveService", "javax.jnlp.ExtensionInstallerService", "javax.jnlp.DownloadService", "javax.jnlp.ClipboardService", "javax.jnlp.PersistenceService", "javax.jnlp.PrintService", "javax.jnlp.ExtendedService", "javax.jnlp.SingleInstanceService", 
        "com.sun.jnlp.IntegrationService" } : new String[] { "javax.jnlp.BasicService", "javax.jnlp.FileOpenService", "javax.jnlp.FileSaveService", "javax.jnlp.DownloadService", "javax.jnlp.ClipboardService", "javax.jnlp.PersistenceService", "javax.jnlp.PrintService", "javax.jnlp.ExtendedService", "javax.jnlp.SingleInstanceService" }; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/JnlpLookupStub.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */