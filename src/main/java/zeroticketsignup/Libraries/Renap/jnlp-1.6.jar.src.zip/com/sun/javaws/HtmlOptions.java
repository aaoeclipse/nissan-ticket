package com.sun.javaws;

import com.sun.deploy.config.Platform;
import com.sun.deploy.trace.Trace;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;

public class HtmlOptions {
  private static final String DOCBASE_KEY = "docbase";
  
  private static final String JNLPHREF_KEY = "jnlphref";
  
  private static final String EMBEDDED_KEY = "embedded";
  
  private static final String APPARG_KEY = "apparg";
  
  private static final String VMARG_KEY = "vmarg";
  
  private static final String PNAME_KEY = "name";
  
  private static final String PVALUE_KEY = "value";
  
  private String _embedded_jnlp = null;
  
  private String[] _htmlApplicationArgs = null;
  
  private String[] _htmlVmArgs = null;
  
  private Properties _htmlParameters;
  
  private URL _docbase = null;
  
  private String _jnlphref = null;
  
  private Properties rawProperties = null;
  
  static HtmlOptions theInstance = null;
  
  private HtmlOptions() {}
  
  private HtmlOptions(InputStream paramInputStream) throws MalformedURLException, IOException { importProperties(paramInputStream); }
  
  public static synchronized HtmlOptions get() { return theInstance; }
  
  public static synchronized HtmlOptions create(InputStream paramInputStream) throws MalformedURLException, IOException {
    theInstance = new HtmlOptions(paramInputStream);
    return theInstance;
  }
  
  public void export(OutputStream paramOutputStream) throws IOException {
    if (this.rawProperties != null) {
      OutputStreamWriter outputStreamWriter = new OutputStreamWriter(paramOutputStream);
      this.rawProperties.store(outputStreamWriter, null);
      outputStreamWriter.close();
    } 
  }
  
  public synchronized void init(String paramString) { theInstance = new HtmlOptions(); }
  
  private byte[] readFully(InputStream paramInputStream) throws IOException {
    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
    int i = 0;
    byte[] arrayOfByte = new byte[16384];
    while ((i = paramInputStream.read(arrayOfByte)) != -1)
      byteArrayOutputStream.write(arrayOfByte, 0, i); 
    paramInputStream.close();
    return byteArrayOutputStream.toByteArray();
  }
  
  private void importProperties(InputStream paramInputStream) throws MalformedURLException, IOException {
    byte[] arrayOfByte = readFully(paramInputStream);
    this.rawProperties = load(arrayOfByte, Platform.get().getPlatformNativeEncoding());
    if (this.rawProperties.getProperty("docbase") == null)
      this.rawProperties = load(arrayOfByte, "UTF-8"); 
    String str1 = this.rawProperties.getProperty("docbase");
    this._jnlphref = this.rawProperties.getProperty("jnlphref");
    String str2 = this.rawProperties.getProperty("embedded");
    this._htmlApplicationArgs = extractList("apparg");
    this._htmlVmArgs = extractList("vmarg");
    this._htmlParameters = extractParameters();
    if (str1 != null && str1.length() > 0)
      this._docbase = new URL(str1); 
    if (str2 != null && str2.length() > 0)
      this._embedded_jnlp = str2; 
  }
  
  private Properties extractParameters() {
    Properties properties = new Properties();
    byte b = 0;
    while (true) {
      String str = "name." + b;
      if (this.rawProperties.containsKey(str)) {
        String str1 = "value." + b;
        properties.setProperty(this.rawProperties.getProperty(str), this.rawProperties.getProperty(str1));
        b++;
        continue;
      } 
      break;
    } 
    return properties.isEmpty() ? null : properties;
  }
  
  String[] extractList(String paramString) {
    ArrayList<String> arrayList = new ArrayList();
    for (byte b = 0;; b++) {
      String str1 = paramString + "." + b;
      String str2 = this.rawProperties.getProperty(str1);
      if (str2 == null)
        break; 
      arrayList.add(str2);
    } 
    return (arrayList.isEmpty() && this.rawProperties.getProperty(paramString + ".length") == null) ? null : arrayList.toArray(new String[0]);
  }
  
  private Properties load(byte[] paramArrayOfbyte, String paramString) {
    ByteArrayInputStream byteArrayInputStream = null;
    InputStreamReader inputStreamReader = null;
    try {
      byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
      inputStreamReader = new InputStreamReader(byteArrayInputStream, paramString);
      Properties properties = new Properties();
      properties.load(inputStreamReader);
      return properties;
    } catch (Exception exception) {
      return new Properties();
    } finally {
      if (inputStreamReader != null) {
        try {
          inputStreamReader.close();
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        } 
      } else if (byteArrayInputStream != null) {
        try {
          byteArrayInputStream.close();
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        } 
      } 
    } 
  }
  
  public String getEmbedded() { return this._embedded_jnlp; }
  
  public String[] getHtmlApplicationArgs() { return this._htmlApplicationArgs; }
  
  public String[] getHtmlVmArgs() { return this._htmlVmArgs; }
  
  public Properties getParameters() { return this._htmlParameters; }
  
  public String getAbsoluteHref(URL paramURL) throws MalformedURLException {
    if (this._jnlphref != null && this._jnlphref.length() > 0)
      try {
        return (new URL(this._jnlphref)).toString();
      } catch (MalformedURLException malformedURLException) {
        if (paramURL != null) {
          boolean bool = paramURL.toString().endsWith("/");
          return (new URL(paramURL.toString() + (bool ? "" : "/") + this._jnlphref)).toString();
        } 
      }  
    return null;
  }
  
  public URL getDocBase() { return this._docbase; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/HtmlOptions.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */