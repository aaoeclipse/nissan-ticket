package com.sun.javaws.ui;

import com.sun.deploy.cache.Cache;
import com.sun.deploy.config.OSType;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.javaws.JnlpxArgs;
import com.sun.javaws.jnl.LaunchDesc;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import sun.awt.SunToolkit;

public class SplashScreen {
  private static boolean _alreadyHidden = false;
  
  private static final int HIDE_SPASH_SCREEN_TOKEN = 90;
  
  public static void hide() {
    hide(JnlpxArgs.getSplashPort());
    if (OSType.isMac()) {
      ToolkitStore.get();
      if (ToolkitStore.isUsingPreferredToolkitType(10))
        SunToolkit.closeSplashScreen(); 
    } 
  }
  
  private static void hide(int paramInt) {
    if (paramInt <= 0 || _alreadyHidden)
      return; 
    _alreadyHidden = true;
    Socket socket = null;
    try {
      socket = new Socket("127.0.0.1", paramInt);
      if (socket != null) {
        OutputStream outputStream = socket.getOutputStream();
        try {
          outputStream.write(90);
          outputStream.flush();
        } catch (IOException iOException) {}
        outputStream.close();
      } 
    } catch (IOException iOException) {
    
    } catch (Exception exception) {
      Trace.ignoredException(exception);
    } 
    if (socket != null)
      try {
        socket.close();
      } catch (IOException iOException) {
        Trace.println("exception closing socket: " + iOException, TraceLevel.BASIC);
      }  
  }
  
  public static void generateCustomSplash(LaunchDesc paramLaunchDesc, boolean paramBoolean) {
    if (!Cache.isCacheEnabled())
      return; 
    if (paramLaunchDesc.isApplicationDescriptor()) {
      SplashGenerator splashGenerator = new SplashGenerator(paramLaunchDesc);
      if (paramBoolean || splashGenerator.needsCustomSplash())
        splashGenerator.start(); 
    } 
  }
  
  public static void removeCustomSplash(LaunchDesc paramLaunchDesc) {
    if (paramLaunchDesc.isApplicationDescriptor()) {
      SplashGenerator splashGenerator = new SplashGenerator(paramLaunchDesc);
      splashGenerator.remove();
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/SplashScreen.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */