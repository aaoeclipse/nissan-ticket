package com.sun.javaws.progress;

import com.sun.applet2.preloader.CancelException;
import com.sun.applet2.preloader.Preloader;
import com.sun.applet2.preloader.event.AppletInitEvent;
import com.sun.applet2.preloader.event.ConfigEvent;
import com.sun.applet2.preloader.event.DownloadErrorEvent;
import com.sun.applet2.preloader.event.DownloadEvent;
import com.sun.applet2.preloader.event.ErrorEvent;
import com.sun.applet2.preloader.event.PreloaderEvent;
import com.sun.deploy.config.Config;
import com.sun.deploy.perf.DeployPerfUtil;
import com.sun.deploy.security.BlockedVersionException;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.uitoolkit.Applet2Adapter;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.uitoolkit.ui.ComponentRef;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.exceptions.JNLPException;
import com.sun.javaws.security.AppContextUtil;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import javax.jnlp.DownloadServiceListener;

public class PreloaderDelegate extends Preloader implements DownloadServiceListener {
  private Preloader _pl = null;
  
  protected ThreadGroup _appThreadGroup = null;
  
  private boolean isLoaded = true;
  
  private Exception loadingException = null;
  
  private boolean isReady = false;
  
  private boolean okToShutdown = true;
  
  private static ThreadLocal isUserDeclinedPreloader = new ThreadLocal();
  
  private final List pendingEvents = new LinkedList();
  
  private PreloaderPostEventListener _listener = null;
  
  private long lastPercentage = -1L;
  
  WeakReference hostAdapterRef = null;
  
  private String preloaderClassName = null;
  
  private boolean canStop = false;
  
  private final ArrayList queue = new ArrayList();
  
  private Thread progressThread = null;
  
  private ProgressQueueChecker checker = null;
  
  private boolean disposed = false;
  
  int rescaleBaseline = -1;
  
  private CancelException ce = null;
  
  private boolean seenUserDeclined = false;
  
  public void setPostEventListener(PreloaderPostEventListener paramPreloaderPostEventListener) { this._listener = paramPreloaderPostEventListener; }
  
  public PreloaderDelegate(Applet2Adapter paramApplet2Adapter) {
    Trace.println("Construct preloader delegate", TraceLevel.PRELOADER);
    if (paramApplet2Adapter != null) {
      Trace.println("Construct preloader delegate adapter=" + paramApplet2Adapter.getClass(), TraceLevel.PRELOADER);
      this.hostAdapterRef = new WeakReference<Applet2Adapter>(paramApplet2Adapter);
      paramApplet2Adapter.addCleanupAction(new Runnable() {
            public void run() { PreloaderDelegate.this.shutdown(); }
          });
    } 
  }
  
  private Applet2Adapter getHostAdapter() { return (null == this.hostAdapterRef) ? null : this.hostAdapterRef.get(); }
  
  public void setPreloaderClass(String paramString) { this.preloaderClassName = paramString; }
  
  public Preloader get() { return this._pl; }
  
  private synchronized void set(Preloader paramPreloader) { this._pl = paramPreloader; }
  
  public PreloaderDelegate(Preloader paramPreloader) {
    set(paramPreloader);
    this._appThreadGroup = Thread.currentThread().getThreadGroup();
    markLoaded(null);
    markReady();
  }
  
  public void initPreloader(final ClassLoader cl, ThreadGroup paramThreadGroup) {
    ToolkitStore.get().getAppContext().put("preloader_key", this);
    Runnable runnable = new Runnable() {
        public void run() {
          Thread.currentThread().setContextClassLoader(cl);
          AppContextUtil.createApplicationAppContext();
          PreloaderDelegate.this.doInitPreloader(cl);
        }
      };
    Thread thread = new Thread(paramThreadGroup, runnable, "preloaderMain");
    thread.setDaemon(true);
    thread.start();
    try {
      thread.join();
    } catch (InterruptedException interruptedException) {
    
    } finally {
      this._appThreadGroup = paramThreadGroup;
      markReady();
    } 
  }
  
  private Object createUsingDefaultConstructor(Class paramClass) throws Exception { return paramClass.getConstructor(new Class[0]).newInstance(new Object[0]); }
  
  private void doInitPreloader(ClassLoader paramClassLoader) {
    Throwable throwable = null;
    try {
      DeployPerfUtil.put("Preloader constructor started");
      Trace.println("Using preloader class: " + this.preloaderClassName + " " + getHostAdapter(), TraceLevel.PRELOADER);
      if (this.preloaderClassName != null) {
        Trace.println("Checking package name of preloader class: " + this.preloaderClassName, TraceLevel.PRELOADER);
        if (!Config.checkPackageAccess(this.preloaderClassName, Config.getNoPermissionACC()))
          throw new SecurityException("Bad package name of progress-class"); 
        isUserDeclinedPreloader.set(Boolean.FALSE);
        Class<?> clazz = Class.forName(this.preloaderClassName, false, paramClassLoader);
        ClassLoader classLoader = clazz.getClassLoader();
        if (classLoader == null || !(classLoader instanceof com.sun.deploy.security.DeployURLClassLoader))
          throw new SecurityException("Invalid preloader-class or progress-class - not using deploy class loader"); 
        if (isUserDeclinedPreloader.get() != Boolean.TRUE) {
          Trace.println("User accept signed preloader or preloader not signed", TraceLevel.PRELOADER);
          if (getHostAdapter() != null) {
            set(getHostAdapter().instantiatePreloader(clazz));
          } else if (Preloader.class.isAssignableFrom(clazz)) {
            Trace.println("Preloader class: " + this.preloaderClassName, TraceLevel.PRELOADER);
            set((Preloader)createUsingDefaultConstructor(clazz));
          } else if (DownloadServiceListener.class.isAssignableFrom(clazz)) {
            Trace.println("CustomProgress: " + this.preloaderClassName, TraceLevel.PRELOADER);
            DownloadServiceListener downloadServiceListener = (DownloadServiceListener)createUsingDefaultConstructor(clazz);
            set(new CustomProgress2PreloaderAdapter(downloadServiceListener));
          } else {
            throw new SecurityException("Invalid preloader-class or progress-class");
          } 
        } 
      } 
    } catch (BlockedVersionException blockedVersionException) {
      Trace.print("Skip initialization of custom preloader " + this.preloaderClassName, TraceLevel.PRELOADER);
      Trace.ignored((Throwable)blockedVersionException);
      setPreloaderClass(null);
    } catch (Exception exception) {
      Trace.println("Failure in initialization of custom preloader: " + this.preloaderClassName, TraceLevel.PRELOADER);
      Trace.ignored(exception);
      throwable = exception;
    } finally {
      if (get() == null) {
        installDefaultPreloader();
        if (throwable != null)
          try {
            handleEvent((PreloaderEvent)new ErrorEvent(null, "Failed to initialize custom preloader", throwable));
            filterPendingEventsOnError();
          } catch (CancelException cancelException) {} 
      } 
      isUserDeclinedPreloader.set(null);
    } 
  }
  
  private synchronized void installDefaultPreloader() {
    Trace.println("Using default preloader", TraceLevel.PRELOADER);
    if (getHostAdapter() != null) {
      set(getHostAdapter().instantiatePreloader(null));
    } else {
      set(ToolkitStore.get().getDefaultPreloader());
    } 
  }
  
  public ComponentRef getOwnerRef() { return new ComponentRef() {
        public Object get() { return PreloaderDelegate.this.getOwner(); }
      }; }
  
  public Object getOwner() { return (get() == null) ? null : get().getOwner(); }
  
  private boolean canStop() {
    synchronized (this.queue) {
      return this.canStop;
    } 
  }
  
  private void markCanStop(boolean paramBoolean) {
    synchronized (this.queue) {
      this.canStop = paramBoolean;
      this.queue.notifyAll();
    } 
  }
  
  private synchronized void startProcessingIfNeeded() {
    if (this.progressThread == null) {
      if (this.checker == null)
        this.checker = new ProgressQueueChecker(); 
      this.progressThread = new Thread(this._appThreadGroup, this.checker, "ProgressReporter");
      this.progressThread.setDaemon(true);
      this.progressThread.start();
    } 
    markCanStop(false);
  }
  
  private synchronized void markReady() {
    this.isReady = true;
    ListIterator<PreloaderEvent> listIterator = this.pendingEvents.listIterator();
    PreloaderEvent preloaderEvent = null;
    while (listIterator.hasNext()) {
      PreloaderEvent preloaderEvent1 = listIterator.next();
      if (preloaderEvent1 instanceof DownloadEvent)
        preloaderEvent = preloaderEvent1; 
    } 
    listIterator = this.pendingEvents.listIterator();
    byte b;
    for (b = 0; listIterator.hasNext(); b++) {
      PreloaderEvent preloaderEvent1 = listIterator.next();
      if (!(preloaderEvent1 instanceof DownloadEvent) || preloaderEvent1 == preloaderEvent)
        try {
          deliver(preloaderEvent1);
          continue;
        } catch (CancelException cancelException) {
          Trace.println("CancelException when preloader is being created. " + cancelException, TraceLevel.PRELOADER);
          continue;
        }  
    } 
    Trace.println("Skipped all (" + b + ") download events prior to " + preloaderEvent, TraceLevel.PRELOADER);
    this.pendingEvents.clear();
  }
  
  public synchronized void waitTillLoaded() throws IOException, JNLPException, ExitException {
    Trace.println("Enter wait for preloader jars to be loaded ", TraceLevel.PRELOADER);
    while (!this.isLoaded && this.loadingException == null) {
      try {
        wait();
      } catch (InterruptedException interruptedException) {
        if (!getHostAdapter().isAlive())
          return; 
      } 
    } 
    Trace.println("Done with loading of preloader jars. Error=" + this.loadingException, TraceLevel.PRELOADER);
    if (this.loadingException != null) {
      if (this.loadingException instanceof IOException)
        throw (IOException)this.loadingException; 
      if (this.loadingException instanceof JNLPException)
        throw (JNLPException)this.loadingException; 
      if (this.loadingException instanceof RuntimeException) {
        if (this.loadingException.getCause() instanceof IOException)
          throw (IOException)this.loadingException.getCause(); 
        if (this.loadingException.getCause() instanceof JNLPException)
          throw (JNLPException)this.loadingException.getCause(); 
        throw new RuntimeException(this.loadingException);
      } 
      if (this.loadingException instanceof ExitException)
        throw (ExitException)this.loadingException; 
      throw new RuntimeException(this.loadingException);
    } 
  }
  
  public synchronized void markLoadingStarted() { this.isLoaded = false; }
  
  public synchronized void markLoaded(Exception paramException) {
    Trace.println("Preloader jars loaded. Error state=" + paramException, TraceLevel.PRELOADER);
    this.isLoaded = true;
    this.loadingException = paramException;
    notifyAll();
  }
  
  public void upgradingArchive(URL paramURL, String paramString, int paramInt1, int paramInt2) {
    try {
      handleEvent((PreloaderEvent)new DownloadEvent(2, paramURL, paramString, null, paramInt1, paramInt2, paramInt2));
    } catch (CancelException cancelException) {
      throw new RuntimeException((Throwable)this.ce);
    } 
  }
  
  public void progress(URL paramURL, String paramString, long paramLong1, long paramLong2, int paramInt) {
    try {
      handleEvent((PreloaderEvent)new DownloadEvent(0, paramURL, paramString, null, paramLong1, paramLong2, paramInt));
    } catch (CancelException cancelException) {
      throw new RuntimeException((Throwable)this.ce);
    } 
  }
  
  public void validating(URL paramURL, String paramString, long paramLong1, long paramLong2, int paramInt) {
    try {
      handleEvent((PreloaderEvent)new DownloadEvent(1, paramURL, paramString, null, paramLong1, paramLong2, paramInt));
    } catch (CancelException cancelException) {
      throw new RuntimeException((Throwable)this.ce);
    } 
  }
  
  public void downloadFailed(URL paramURL, String paramString) {
    try {
      handleEvent((PreloaderEvent)new DownloadErrorEvent(paramURL, paramString));
    } catch (CancelException cancelException) {
      throw new RuntimeException((Throwable)this.ce);
    } 
  }
  
  public void extensionDownload(String paramString, int paramInt) {}
  
  public void jreDownload(String paramString, URL paramURL) {}
  
  public void setHeading(String paramString, boolean paramBoolean) {}
  
  public void setStatus(String paramString) {}
  
  public void setVisible(boolean paramBoolean) {}
  
  public void setProgressBarVisible(boolean paramBoolean) {}
  
  public void setProgressBarValue(int paramInt) {}
  
  public void forceFlushForTCK() {
    while (true) {
      synchronized (this.queue) {
        if (this.queue.isEmpty())
          return; 
        try {
          this.queue.wait(50L);
        } catch (InterruptedException interruptedException) {
          if (!getHostAdapter().isAlive())
            return; 
        } 
      } 
    } 
  }
  
  private synchronized boolean isOkToShutdown() { return this.okToShutdown; }
  
  private synchronized void markOkToShutdown() { this.okToShutdown = true; }
  
  private synchronized void shutdown() {
    if (!isOkToShutdown()) {
      Trace.println("Preloader not ok to shutdown", TraceLevel.PRELOADER);
      return;
    } 
    markCanStop(true);
    synchronized (this.queue) {
      this.queue.clear();
      this.queue.notifyAll();
    } 
    this.checker = null;
    this.progressThread = null;
    this.disposed = true;
    this._listener = null;
    this._pl = null;
  }
  
  private synchronized boolean isReady() { return this.isReady; }
  
  private void enQueue(Runnable paramRunnable) {
    synchronized (this.queue) {
      if (!this.disposed) {
        this.queue.add(paramRunnable);
        Trace.println("Enqueue: " + paramRunnable.toString(), TraceLevel.PRELOADER);
        this.queue.notifyAll();
      } 
    } 
  }
  
  synchronized void setPendingException(CancelException paramCancelException) { this.ce = paramCancelException; }
  
  private synchronized CancelException getPendingException() { return this.ce; }
  
  private void deliver(final PreloaderEvent pe) throws CancelException {
    if (this.disposed) {
      Trace.println("Preloader disposed, dropping: " + pe, TraceLevel.PRELOADER);
      return;
    } 
    CancelException cancelException = getPendingException();
    if (cancelException != null) {
      setPendingException(null);
      throw cancelException;
    } 
    final Preloader preloader = get();
    if (preloader != null) {
      startProcessingIfNeeded();
      if (pe instanceof DownloadEvent) {
        DownloadEvent downloadEvent = (DownloadEvent)pe;
        if (this.rescaleBaseline == -1)
          this.rescaleBaseline = downloadEvent.getOverallPercentage(); 
        if (!downloadEvent.isExplicit())
          downloadEvent.normalize(this.rescaleBaseline); 
      } 
      Trace.println("Delivering: " + pe, TraceLevel.PRELOADER);
      enQueue(new Runnable() {
            public void run() {
              if (pe instanceof com.sun.applet2.preloader.event.ApplicationExitEvent) {
                PreloaderDelegate.this.shutdown();
                return;
              } 
              if (pe instanceof com.sun.applet2.preloader.event.InitEvent && pe.getType() == 1)
                PreloaderDelegate.this.markOkToShutdown(); 
              boolean bool = true;
              try {
                try {
                  bool = preloader.handleEvent(pe);
                } catch (CancelException cancelException) {
                  PreloaderDelegate.this.setPendingException(cancelException);
                } 
                if (!bool)
                  PreloaderDelegate.this.doDefaultEventProcessing(pe); 
              } catch (Throwable throwable) {
                Trace.println("Preloader failed to handle " + pe, TraceLevel.PRELOADER);
                PreloaderDelegate.this.doDefaultEventProcessing((PreloaderEvent)new ErrorEvent(null, throwable));
              } 
              if (pe instanceof com.sun.applet2.preloader.event.UserDeclinedEvent)
                PreloaderDelegate.this.seenUserDeclined = true; 
              if (PreloaderDelegate.this._listener != null)
                PreloaderDelegate.this._listener.eventHandled(pe); 
              if (pe instanceof ErrorEvent) {
                PreloaderDelegate.this.shutdown();
                Trace.println("Preloader shutdown after ErrorEvent", TraceLevel.PRELOADER);
              } 
            }
          });
    } else {
      Trace.println("Dropping " + pe + " because preloader was not created", TraceLevel.PRELOADER);
    } 
  }
  
  private void doDefaultEventProcessing(PreloaderEvent paramPreloaderEvent) {
    if (getHostAdapter() != null) {
      if (paramPreloaderEvent instanceof ErrorEvent) {
        ErrorEvent errorEvent = (ErrorEvent)paramPreloaderEvent;
        getHostAdapter().doShowError(errorEvent.getValue(), errorEvent.getException(), this.seenUserDeclined);
      } 
      if (paramPreloaderEvent instanceof AppletInitEvent) {
        AppletInitEvent appletInitEvent = (AppletInitEvent)paramPreloaderEvent;
        if (appletInitEvent.getSubtype() == 3)
          getHostAdapter().doShowApplet(); 
      } 
    } 
  }
  
  private synchronized void filterPendingEventsOnError() {
    ListIterator<Object> listIterator = this.pendingEvents.listIterator();
    while (listIterator.hasNext()) {
      Object object = listIterator.next();
      if (object instanceof DownloadEvent)
        listIterator.remove(); 
    } 
  }
  
  public synchronized boolean handleEvent(PreloaderEvent paramPreloaderEvent) throws CancelException {
    if (paramPreloaderEvent instanceof DownloadEvent) {
      DownloadEvent downloadEvent = (DownloadEvent)paramPreloaderEvent;
      int i = downloadEvent.getOverallPercentage();
      if (i == this.lastPercentage && i != 100)
        return true; 
      this.lastPercentage = i;
    } else if (paramPreloaderEvent instanceof ConfigEvent) {
      ConfigEvent configEvent = (ConfigEvent)paramPreloaderEvent;
      if (configEvent.getAction() == 5)
        this.lastPercentage = -1L; 
    } 
    if (isReady() && get() != null) {
      deliver(paramPreloaderEvent);
    } else {
      this.pendingEvents.add(paramPreloaderEvent);
      Trace.println("Added pending event " + this.pendingEvents.size() + ": " + paramPreloaderEvent, TraceLevel.PRELOADER);
    } 
    return true;
  }
  
  public class ProgressQueueChecker implements Runnable {
    static final int WAIT_CYCLES = 10;
    
    private int waitCycles;
    
    public void run() {
      AppContextUtil.createApplicationAppContext();
      Trace.println("Start progressCheck thread", TraceLevel.PRELOADER);
      Runnable runnable = null;
      this.waitCycles = 10;
      boolean bool1 = true;
      while (bool1) {
        synchronized (PreloaderDelegate.this.queue) {
          if (PreloaderDelegate.this.queue.isEmpty()) {
            try {
              PreloaderDelegate.this.queue.wait(500L);
              this.waitCycles--;
            } catch (InterruptedException interruptedException) {
              if (!PreloaderDelegate.this.getHostAdapter().isAlive())
                return; 
            } 
          } else {
            try {
              runnable = PreloaderDelegate.this.queue.remove(0);
            } catch (ClassCastException classCastException) {
              classCastException.printStackTrace();
            } finally {
              PreloaderDelegate.this.queue.notifyAll();
            } 
          } 
        } 
        try {
          if (runnable != null) {
            runnable.run();
            this.waitCycles = 10;
            runnable = null;
          } 
        } catch (Exception exception) {
          System.err.println("Unexpected exception from progress handler: " + exception);
          exception.printStackTrace();
        } 
        synchronized (PreloaderDelegate.this.queue) {
          bool1 = ((!PreloaderDelegate.this.canStop() && this.waitCycles != 0) || !PreloaderDelegate.this.queue.isEmpty()) ? true : false;
        } 
      } 
      Trace.println("Stop progressCheck thread queue.size()=" + PreloaderDelegate.this.queue.size(), TraceLevel.PRELOADER);
      synchronized (PreloaderDelegate.this) {
        PreloaderDelegate.this.progressThread = null;
      } 
      boolean bool2 = false;
      synchronized (PreloaderDelegate.this.queue) {
        bool2 = !PreloaderDelegate.this.queue.isEmpty() ? true : false;
      } 
      if (bool2)
        PreloaderDelegate.this.startProcessingIfNeeded(); 
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/progress/PreloaderDelegate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */