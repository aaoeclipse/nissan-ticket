package com.sun.javaws.exceptions;

import com.sun.deploy.resources.ResourceManager;
import java.net.URL;

public class BadMimeTypeResponseException extends DownloadException {
  private String _mimeType;
  
  public BadMimeTypeResponseException(URL paramURL, String paramString1, String paramString2) {
    super(paramURL, paramString1);
    this._mimeType = paramString2;
  }
  
  public String getRealMessage() { return ResourceManager.getString("launch.error.badmimetyperesponse", getResourceString(), this._mimeType); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/exceptions/BadMimeTypeResponseException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */