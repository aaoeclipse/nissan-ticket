package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import javax.jnlp.IntegrationService;

public final class IntegrationServiceNSBImpl implements IntegrationService {
  private final IntegrationServiceImpl service;
  
  public IntegrationServiceNSBImpl(IntegrationServiceImpl paramIntegrationServiceImpl) { this.service = paramIntegrationServiceImpl; }
  
  public boolean requestShortcut(boolean paramBoolean1, boolean paramBoolean2, String paramString) { return Platform.get().getNativeSandboxBroker().requestShortcut(paramBoolean1, paramBoolean2, paramString); }
  
  public boolean removeShortcuts() { return Platform.get().getNativeSandboxBroker().removeShortcuts(); }
  
  public boolean requestAssociation(String paramString, String[] paramArrayOfString) { return Platform.get().getNativeSandboxBroker().requestAssociation(paramString, paramArrayOfString); }
  
  public boolean removeAssociation(String paramString, String[] paramArrayOfString) { return Platform.get().getNativeSandboxBroker().removeAssociation(paramString, paramArrayOfString); }
  
  public boolean hasDesktopShortcut() { return this.service.hasDesktopShortcut(); }
  
  public boolean hasMenuShortcut() { return this.service.hasMenuShortcut(); }
  
  public boolean hasAssociation(String paramString, String[] paramArrayOfString) { return this.service.hasAssociation(paramString, paramArrayOfString); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/IntegrationServiceNSBImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */