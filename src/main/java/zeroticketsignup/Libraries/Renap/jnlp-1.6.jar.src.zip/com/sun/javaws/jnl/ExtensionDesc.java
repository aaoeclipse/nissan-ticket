package com.sun.javaws.jnl;

import com.sun.deploy.config.JREInfo;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.URLUtil;
import com.sun.deploy.xml.XMLAttributeBuilder;
import com.sun.deploy.xml.XMLNode;
import com.sun.deploy.xml.XMLNodeBuilder;
import java.io.File;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

public class ExtensionDesc implements ResourceType {
  private String _name;
  
  private URL _location;
  
  private URL _codebase;
  
  private String _version;
  
  private ExtDownloadDesc[] _extDownloadDescs;
  
  private LaunchDesc _extensionLd;
  
  public ExtensionDesc(String paramString1, URL paramURL, String paramString2, ExtDownloadDesc[] paramArrayOfExtDownloadDesc) {
    this._name = paramString1;
    this._location = paramURL;
    this._codebase = URLUtil.asPathURL(URLUtil.getBase(paramURL));
    this._version = paramString2;
    if (paramArrayOfExtDownloadDesc == null)
      paramArrayOfExtDownloadDesc = new ExtDownloadDesc[0]; 
    this._extDownloadDescs = paramArrayOfExtDownloadDesc;
    this._extensionLd = null;
  }
  
  public boolean isInstaller() { return (getExtensionDesc() != null) ? this._extensionLd.isInstaller() : false; }
  
  public String getVersion() { return this._version; }
  
  public URL getLocation() { return this._location; }
  
  public URL getCodebase() { return this._codebase; }
  
  public String getName() { return this._name; }
  
  ExtDownloadDesc[] getExtDownloadDescs() { return this._extDownloadDescs; }
  
  public LaunchDesc getExtensionDesc() {
    if (this._extensionLd == null)
      try {
        boolean bool = true;
        if (ResourceProvider.get().isCached(getLocation(), getVersion()))
          bool = false; 
        Resource resource = ResourceProvider.get().getJreResource(getLocation(), getVersion(), bool, false, JREInfo.getKnownPlatforms());
        if (resource != null) {
          File file = resource.getDataFile();
          if (file != null)
            this._extensionLd = LaunchDescFactory.buildDescriptor(file, getCodebase(), getLocation(), getLocation()); 
        } 
      } catch (Exception exception) {
        Trace.ignoredException(exception);
      }  
    return this._extensionLd;
  }
  
  public void setExtensionDesc(LaunchDesc paramLaunchDesc) { this._extensionLd = paramLaunchDesc; }
  
  ResourcesDesc getExtensionResources() { return this._extensionLd.getResources(); }
  
  Set<String> getExtensionPackages(Set<String> paramSet, boolean paramBoolean) {
    HashSet<String> hashSet = new HashSet();
    for (ExtDownloadDesc extDownloadDesc : this._extDownloadDescs) {
      boolean bool = (paramBoolean && !extDownloadDesc.isLazy()) ? true : false;
      if (bool || (paramSet != null && paramSet.contains(extDownloadDesc.getPart())))
        hashSet.add(extDownloadDesc.getExtensionPart()); 
    } 
    return hashSet;
  }
  
  public void visit(ResourceVisitor paramResourceVisitor) { paramResourceVisitor.visitExtensionDesc(this); }
  
  public XMLNode asXML() {
    XMLAttributeBuilder xMLAttributeBuilder = new XMLAttributeBuilder();
    xMLAttributeBuilder.add("href", this._location);
    xMLAttributeBuilder.add("version", this._version);
    xMLAttributeBuilder.add("name", this._name);
    XMLNodeBuilder xMLNodeBuilder = new XMLNodeBuilder("extension", xMLAttributeBuilder.getAttributeList());
    for (byte b = 0; b < this._extDownloadDescs.length; b++)
      xMLNodeBuilder.add(this._extDownloadDescs[b]); 
    return xMLNodeBuilder.getNode();
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/jnl/ExtensionDesc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */