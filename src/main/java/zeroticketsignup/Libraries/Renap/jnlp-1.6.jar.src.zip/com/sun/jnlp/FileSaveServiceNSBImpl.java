package com.sun.jnlp;

import com.sun.deploy.config.Platform;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import com.sun.deploy.util.Waiter;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.jnlp.FileContents;
import javax.jnlp.FileSaveService;

public final class FileSaveServiceNSBImpl implements FileSaveService {
  private final FileSaveServiceImpl service;
  
  public FileSaveServiceNSBImpl(FileSaveServiceImpl paramFileSaveServiceImpl) { this.service = paramFileSaveServiceImpl; }
  
  public FileContents saveFileDialog(final String pathHint, final String[] extensions, final InputStream stream, final String filename) throws IOException {
    if (!this.service.askUser())
      return null; 
    Waiter.WaiterTask waiterTask = new Waiter.WaiterTask() {
        public Object run() throws Exception {
          Object object = DeploySysRun.executePrivileged(new DeploySysAction() {
                public Object execute() {
                  String str = Platform.get().getNativeSandboxBroker().saveFile(pathHint, extensions, filename);
                  if (str == null)
                    return null; 
                  File file = new File(str);
                  if (file != null)
                    try {
                      byte[] arrayOfByte = new byte[8192];
                      OutputStream outputStream = Platform.get().getNativeSandboxBroker().getOutputStream(file, true);
                      BufferedInputStream bufferedInputStream = new BufferedInputStream(stream);
                      int i;
                      for (i = bufferedInputStream.read(arrayOfByte); i != -1; i = bufferedInputStream.read(arrayOfByte))
                        outputStream.write(arrayOfByte, 0, i); 
                      outputStream.flush();
                      outputStream.close();
                      return new FileContentsImpl(file, FileSaveServiceImpl.computeMaxLength(file.length()));
                    } catch (IOException iOException) {} 
                  return null;
                }
              }null);
          if (object instanceof IOException)
            throw (IOException)object; 
          return object;
        }
      };
    try {
      return (FileContents)Waiter.runAndWait(waiterTask);
    } catch (Exception exception) {
      if (exception instanceof IOException)
        throw (IOException)exception; 
      Trace.ignored(exception);
      return null;
    } 
  }
  
  public FileContents saveAsFileDialog(String paramString, String[] paramArrayOfString, FileContents paramFileContents) throws IOException { return saveFileDialog(paramString, paramArrayOfString, paramFileContents.getInputStream(), paramFileContents.getName()); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/FileSaveServiceNSBImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */