package com.sun.javaws;

import com.sun.deploy.config.Platform;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.IconEncoder;
import com.sun.javaws.jnl.IconDesc;
import com.sun.javaws.jnl.LaunchDesc;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

public class IconUtil {
  public static String getIconPath(LaunchDesc paramLaunchDesc, boolean paramBoolean) { return getIconPath(paramLaunchDesc); }
  
  public static String getIconPath(LaunchDesc paramLaunchDesc) {
    ArrayList<Integer> arrayList = new ArrayList();
    int[] arrayOfInt1 = Platform.get().getIconSizes();
    Integer integer1 = new Integer(Platform.get().getSystemShortcutIconSize(true));
    Integer integer2 = new Integer(Platform.get().getSystemShortcutIconSize(false));
    int i;
    for (i = 0; i < arrayOfInt1.length; i++) {
      Integer integer = new Integer(arrayOfInt1[i]);
      if (!arrayList.contains(integer))
        arrayList.add(integer); 
    } 
    if (!arrayList.contains(integer1))
      arrayList.add(integer1); 
    if (!arrayList.contains(integer2))
      arrayList.add(integer2); 
    i = ((Integer)arrayList.get(0)).intValue();
    int j = i;
    int k = i;
    for (byte b1 = 0; b1 < arrayList.size(); b1++) {
      i = ((Integer)arrayList.get(b1)).intValue();
      if (i > k)
        k = i; 
      if (i < j)
        j = i; 
    } 
    Iterator<Integer> iterator = arrayList.iterator();
    IconDesc[] arrayOfIconDesc = new IconDesc[arrayList.size()];
    int[] arrayOfInt2 = new int[arrayList.size()];
    byte b2 = 0;
    while (iterator.hasNext()) {
      int m = ((Integer)iterator.next()).intValue();
      if (m < j)
        m = j; 
      if (m > k)
        m = k; 
      IconDesc iconDesc = paramLaunchDesc.getInformation().getIconLocation(m, 5);
      if (iconDesc == null)
        iconDesc = paramLaunchDesc.getInformation().getIconLocation(m, 0); 
      if (iconDesc != null) {
        boolean bool = false;
        int n;
        for (n = 0; n < b2 && !bool; n++) {
          if (iconDesc.equals(arrayOfIconDesc[n]))
            bool = true; 
        } 
        if (!bool) {
          arrayOfIconDesc[b2] = iconDesc;
          n = iconDesc.getWidth();
          int i1 = iconDesc.getHeight();
          if (n == i1 && n >= j && n <= k) {
            arrayOfInt2[b2] = n;
          } else {
            arrayOfInt2[b2] = m;
          } 
          b2++;
        } 
      } 
    } 
    String str = null;
    File[] arrayOfFile = new File[arrayList.size()];
    for (byte b3 = 0; b3 < b2; b3++) {
      String str1 = null;
      File file = null;
      try {
        Resource resource = ResourceProvider.get().getResource(arrayOfIconDesc[b3].getLocation(), arrayOfIconDesc[b3].getVersion());
        File file1 = (resource != null) ? resource.getDataFile() : null;
        if (file1 != null) {
          if (Platform.get().isPlatformIconType(arrayOfIconDesc[b3].getLocation().toString())) {
            str1 = file1.toString();
            file = file1;
          } else {
            String str2 = Platform.get().getPlatformIconType();
            str1 = file1.getPath() + "." + str2;
            file = new File(str1);
          } 
          if (file.exists())
            return str1; 
          if (str == null)
            str = str1; 
          arrayOfFile[b3] = file1;
        } 
      } catch (IOException iOException) {
        Trace.ignored(iOException);
      } 
    } 
    if (str != null && b2 > 0) {
      IconEncoder iconEncoder = Platform.get().getIconEncoder();
      iconEncoder.convert(arrayOfFile, arrayOfInt2, b2, str);
    } 
    return (str != null && (new File(str)).exists()) ? str : null;
  }
  
  public static String getIconPath(URL paramURL, String paramString) {
    String str = null;
    File file = null;
    try {
      Resource resource = ResourceProvider.get().getResource(paramURL, paramString);
      if (resource != null)
        file = resource.getDataFile(); 
      if (file != null) {
        File file1;
        if (Platform.get().isPlatformIconType(paramURL.toString())) {
          str = file.toString();
          file1 = file;
        } else {
          String str1 = Platform.get().getPlatformIconType();
          str = file.getPath() + "." + str1;
          file1 = new File(str);
        } 
        if (file1.exists())
          return str; 
      } 
    } catch (IOException iOException) {
      Trace.ignored(iOException);
    } 
    if (str != null) {
      File[] arrayOfFile = { file };
      int[] arrayOfInt = { 32 };
      boolean bool = true;
      IconEncoder iconEncoder = Platform.get().getIconEncoder();
      iconEncoder.convert(arrayOfFile, arrayOfInt, bool, str);
    } 
    return (str != null && (new File(str)).exists()) ? str : null;
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/IconUtil.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */