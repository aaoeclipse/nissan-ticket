package com.sun.jnlp;

import com.sun.applet2.preloader.Preloader;
import com.sun.deploy.config.OSType;
import com.sun.deploy.config.Platform;
import com.sun.deploy.model.Resource;
import com.sun.deploy.model.ResourceProvider;
import com.sun.deploy.net.DownloadEngine;
import com.sun.deploy.ref.AppRef;
import com.sun.deploy.ref.CodeInstance;
import com.sun.deploy.ref.CodeRef;
import com.sun.deploy.security.CPCallbackHandler;
import com.sun.deploy.security.DeployURLClassLoader;
import com.sun.deploy.security.DeployURLClassPath;
import com.sun.deploy.security.SandboxSecurity;
import com.sun.deploy.security.SecureCookiePermission;
import com.sun.deploy.security.SecureStaticVersioning;
import com.sun.deploy.security.ruleset.DeploymentRuleSet;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.trace.TraceLevel;
import com.sun.deploy.ui.AppInfo;
import com.sun.deploy.uitoolkit.ToolkitStore;
import com.sun.deploy.util.FXLoader;
import com.sun.deploy.util.URLUtil;
import com.sun.javaws.LaunchDownload;
import com.sun.javaws.exceptions.ExitException;
import com.sun.javaws.jnl.JARDesc;
import com.sun.javaws.jnl.LaunchDesc;
import com.sun.javaws.jnl.ResourceType;
import com.sun.javaws.jnl.ResourcesDesc;
import com.sun.javaws.progress.Progress;
import com.sun.javaws.security.AppPolicy;
import com.sun.javaws.util.JNLPUtils;
import java.awt.AWTPermission;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilePermission;
import java.io.IOException;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.AccessControlContext;
import java.security.AccessController;
import java.security.CodeSource;
import java.security.Permission;
import java.security.PermissionCollection;
import java.security.Permissions;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.jar.JarFile;
import javax.jnlp.BasicService;
import javax.jnlp.ClipboardService;
import javax.jnlp.DownloadService;
import javax.jnlp.DownloadService2;
import javax.jnlp.ExtendedService;
import javax.jnlp.ExtensionInstallerService;
import javax.jnlp.FileOpenService;
import javax.jnlp.FileSaveService;
import javax.jnlp.IntegrationService;
import javax.jnlp.PersistenceService;
import javax.jnlp.PrintService;
import javax.jnlp.SingleInstanceService;
import sun.misc.Resource;
import sun.misc.SharedSecrets;
import sun.misc.URLClassPath;

public final class JNLPClassLoader extends DeployURLClassLoader implements JNLPClassLoaderIf {
  private static JNLPClassLoader _instance = null;
  
  private LaunchDesc _launchDesc = null;
  
  private AppPolicy _appPolicy;
  
  private AccessControlContext _acc = null;
  
  private boolean _initialized = false;
  
  private Map _jarsInURLClassLoader = new HashMap<Object, Object>();
  
  private ArrayList _jarsNotInURLClassLoader = new ArrayList();
  
  private static Field ucpField = getUCPField("ucp");
  
  private List addedURLs = new ArrayList();
  
  private JNLPClassLoader _jclParent;
  
  private JNLPClassLoader(ClassLoader paramClassLoader) {
    super(new URL[0], paramClassLoader);
    SecurityManager securityManager = System.getSecurityManager();
    if (securityManager != null)
      securityManager.checkCreateClassLoader(); 
    if (paramClassLoader instanceof JNLPClassLoader)
      this._jclParent = (JNLPClassLoader)paramClassLoader; 
    setUCP(this, (URLClassPath)new DeployURLClassPath(new URL[0]));
  }
  
  protected Class loadClass(String paramString, boolean paramBoolean) throws ClassNotFoundException {
    checkPackageAccess(paramString);
    return super.loadClass(paramString, paramBoolean);
  }
  
  private void initialize(LaunchDesc paramLaunchDesc, AppPolicy paramAppPolicy) {
    this._launchDesc = paramLaunchDesc;
    this._acc = AccessController.getContext();
    this._appPolicy = paramAppPolicy;
    this._initialized = true;
    if (this._jclParent != null) {
      this._jclParent.initialize(paramLaunchDesc, paramAppPolicy);
      drainPendingURLs();
      return;
    } 
    if (paramLaunchDesc.needFX())
      try {
        FXLoader.loadFX();
      } catch (ClassNotFoundException classNotFoundException) {
        Trace.ignored(classNotFoundException);
      } catch (IllegalStateException illegalStateException) {
        Trace.ignored(illegalStateException);
      }  
    ResourcesDesc resourcesDesc = paramLaunchDesc.getResources();
    ArrayList<JARDesc> arrayList = new ArrayList();
    if (resourcesDesc != null) {
      JNLPUtils.sortResourcesForClasspath(resourcesDesc, arrayList, this._jarsNotInURLClassLoader);
      for (byte b = 0; b < arrayList.size(); b++) {
        JARDesc jARDesc = arrayList.get(b);
        this._jarsInURLClassLoader.put(URLUtil.toNormalizedString(jARDesc.getLocation()), jARDesc);
        addURL2(jARDesc.getLocation());
      } 
    } 
  }
  
  public Preloader getPreloader() { return (Preloader)Progress.get(null); }
  
  public static JNLPClassLoader createClassLoader() {
    if (_instance == null) {
      ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
      JNLPClassLoader jNLPClassLoader1 = new JNLPClassLoader(classLoader);
      JNLPClassLoader jNLPClassLoader2 = new JNLPClassLoader((ClassLoader)jNLPClassLoader1);
      if (!setDeployURLClassPathCallbacks(jNLPClassLoader1, jNLPClassLoader2)) {
        _instance = jNLPClassLoader1;
      } else {
        _instance = jNLPClassLoader2;
      } 
    } 
    return _instance;
  }
  
  public static JNLPClassLoader createClassLoader(LaunchDesc paramLaunchDesc, AppPolicy paramAppPolicy) {
    JNLPClassLoader jNLPClassLoader = createClassLoader();
    if (!jNLPClassLoader._initialized)
      jNLPClassLoader.initialize(paramLaunchDesc, paramAppPolicy); 
    return jNLPClassLoader;
  }
  
  public static JNLPClassLoaderIf getInstance() { return _instance; }
  
  public LaunchDesc getLaunchDesc() { return this._launchDesc; }
  
  public JARDesc getJarDescFromURL(URL paramURL) {
    if (this._jclParent != null)
      return this._jclParent.getJarDescFromURL(paramURL); 
    String str = URLUtil.toNormalizedString(paramURL);
    JARDesc jARDesc = (JARDesc)this._jarsInURLClassLoader.get(str);
    if (jARDesc != null)
      return jARDesc; 
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    for (String str1 : this._jarsInURLClassLoader.keySet()) {
      jARDesc = (JARDesc)this._jarsInURLClassLoader.get(str1);
      String str2 = URLUtil.toNormalizedString(DownloadEngine.getKnownRedirectFinalURL(jARDesc.getLocation()));
      if (!this._jarsInURLClassLoader.containsKey(str2)) {
        hashMap.put(str2, jARDesc);
        if (str.equals(str2)) {
          this._jarsInURLClassLoader.putAll(hashMap);
          return jARDesc;
        } 
      } 
    } 
    this._jarsInURLClassLoader.putAll(hashMap);
    return null;
  }
  
  public int getDefaultSecurityModel() { return this._launchDesc.getSecurityModel(); }
  
  public AppInfo getAppInfo(URL paramURL) {
    JARDesc jARDesc = getJarDescFromURL(paramURL);
    if (jARDesc != null && jARDesc.getParent() != null) {
      LaunchDesc launchDesc = jARDesc.getParent().getParent();
      if (launchDesc != null)
        return launchDesc.getAppInfo(); 
    } 
    return new AppInfo();
  }
  
  public URL getResource(String paramString) {
    URL uRL = null;
    for (byte b = 0; uRL == null && b < 3; b++)
      uRL = super.getResource(paramString); 
    return uRL;
  }
  
  private String findLibrary0(String paramString) {
    ResourcesDesc resourcesDesc = this._launchDesc.getResources();
    JARDesc[] arrayOfJARDesc = resourcesDesc.getEagerOrAllJarDescs(true);
    for (byte b = 0; b < arrayOfJARDesc.length; b++) {
      if (arrayOfJARDesc[b].isNativeLib())
        try {
          String str = ResourceProvider.get().getLibraryDirForJar(paramString, arrayOfJARDesc[b].getLocation(), arrayOfJARDesc[b].getVersion());
          if (str != null)
            return (new File(str, paramString)).getAbsolutePath(); 
        } catch (IOException iOException) {
          Trace.ignoredException(iOException);
        }  
    } 
    return null;
  }
  
  protected String findLibrary(String paramString) {
    if (this._jclParent != null)
      return this._jclParent.findLibrary(paramString); 
    if (!this._initialized)
      return super.findLibrary(paramString); 
    String str1 = System.mapLibraryName(paramString);
    Trace.println("JNLPClassLoader: Finding library " + str1);
    String str2 = findLibrary0(str1);
    if (str2 != null)
      return str2; 
    if (OSType.isMac()) {
      str1 = "lib" + paramString + ".jnilib";
      str2 = findLibrary0(str1);
      if (str2 != null)
        return str2; 
    } 
    Trace.println("JNLPClassLoader: Native library " + paramString + " not found", TraceLevel.NETWORK);
    return super.findLibrary(paramString);
  }
  
  protected Class findClass(String paramString) throws ClassNotFoundException {
    if (!this._initialized)
      return super.findClass(paramString); 
    try {
      return super.findClass(paramString);
    } catch (ClassNotFoundException classNotFoundException) {
      if (!(classNotFoundException.getCause() instanceof com.sun.deploy.net.JARSigningException) && checkPackageParts(paramString))
        return super.findClass(paramString); 
      throw classNotFoundException;
    } 
  }
  
  public Resource getResourceAsResource(String paramString) throws MalformedURLException, FileNotFoundException {
    if (this._jclParent != null)
      try {
        return this._jclParent.getResourceAsResource(paramString);
      } catch (FileNotFoundException fileNotFoundException) {} 
    URLClassPath uRLClassPath = SharedSecrets.getJavaNetAccess().getURLClassPath((URLClassLoader)this);
    Resource resource = uRLClassPath.getResource(paramString, false);
    if (resource != null)
      return resource; 
    throw new FileNotFoundException("Resource " + paramString + " not found");
  }
  
  public URL findResource(String paramString) {
    URL uRL = super.findResource(paramString);
    if (!this._initialized)
      return uRL; 
    if (uRL == null && checkPackageParts(paramString))
      uRL = super.findResource(paramString); 
    return uRL;
  }
  
  private boolean checkPackageParts(String paramString) {
    if (this._jclParent != null)
      return drainPendingURLs(); 
    boolean bool = false;
    ResourcesDesc.PackageInformation packageInformation = this._launchDesc.getResources().getPackageInformation(paramString);
    if (packageInformation != null) {
      JARDesc[] arrayOfJARDesc = packageInformation.getLaunchDesc().getResources().getPart(packageInformation.getPart());
      for (byte b = 0; b < arrayOfJARDesc.length; b++) {
        if (this._jarsNotInURLClassLoader.contains(arrayOfJARDesc[b])) {
          this._jarsNotInURLClassLoader.remove(arrayOfJARDesc[b]);
          addLoadedJarsEntry(arrayOfJARDesc[b]);
          addURL2(arrayOfJARDesc[b].getLocation());
          bool = true;
        } 
      } 
    } 
    return bool;
  }
  
  protected PermissionCollection getPermissions(CodeSource paramCodeSource) {
    Permissions permissions1 = null;
    String str = getLaunchDesc().getDownloadHost();
    if (str != null && str.length() > 0)
      if (!URLUtil.sameBase(getLaunchDesc().getCodebase(), paramCodeSource.getLocation())) {
        if (DownloadEngine.isKnownRedirectedHost(str, paramCodeSource.getLocation().getHost())) {
          permissions1 = new Permissions();
          SandboxSecurity.addConnectPermission(permissions1, paramCodeSource.getLocation());
          Trace.println("Grant connect perm for " + paramCodeSource.getLocation() + " : " + permissions1, TraceLevel.SECURITY);
        } else {
          Trace.println("Connect perm was not granted " + paramCodeSource.getLocation() + " : " + permissions1, TraceLevel.SECURITY);
        } 
      } else {
        permissions1 = new Permissions();
        SandboxSecurity.addConnectPermission(permissions1, paramCodeSource.getLocation());
        Trace.println("Grant connect perm for " + paramCodeSource.getLocation() + " : " + permissions1, TraceLevel.SECURITY);
      }  
    Permissions permissions2 = (permissions1 == null) ? new Permissions() : permissions1;
    URL uRL = paramCodeSource.getLocation();
    JARDesc jARDesc = getJarDescFromURL(uRL);
    SecureStaticVersioning.checkVersionAllowed(getDeploymentRuleSet(uRL));
    if (uRL != null && jARDesc != null) {
      ToolkitStore.get().getAppContext().put("deploy-" + uRL, jARDesc.getVersion());
      URL uRL1 = DownloadEngine.getKnownRedirectFinalURL(uRL);
      if (!URLUtil.sameURLs(uRL1, uRL))
        ToolkitStore.get().getAppContext().put("deploy-" + uRL1, jARDesc.getVersion()); 
    } 
    try {
      this._appPolicy.addPermissions(getInstance(), permissions2, paramCodeSource, true);
    } catch (ExitException exitException) {
      throw new RuntimeException((Throwable)exitException);
    } 
    if (jARDesc != null) {
      Resource resource = ResourceProvider.get().getCachedResource(jARDesc.getLocation(), jARDesc.getVersion());
      if (resource != null && resource.getDataFile() != null) {
        String str1 = resource.getDataFile().getPath();
        permissions2.add(new FilePermission(str1, "read"));
      } 
    } 
    if (!permissions2.implies(new AWTPermission("accessClipboard")))
      ToolkitStore.get().getAppContext().put("UNTRUSTED_URLClassLoader", Boolean.TRUE); 
    permissions2.add((Permission)new SecureCookiePermission(SecureCookiePermission.getURLOriginString(paramCodeSource.getLocation())));
    return permissions2;
  }
  
  public JarFile getJarFile(URL paramURL) throws IOException {
    final JARDesc jd = getJarDescFromURL(paramURL);
    if (jARDesc == null)
      return null; 
    final int contentType = LaunchDownload.getDownloadType(jARDesc);
    try {
      return AccessController.doPrivileged(new PrivilegedExceptionAction<JarFile>() {
            public Object run() throws IOException {
              int i = ResourceProvider.get().incrementInternalUse();
              try {
                JarFile jarFile = ResourceProvider.get().getCachedJarFile(jd.getLocation(), jd.getVersion());
                if (jarFile != null)
                  return jarFile; 
                return ResourceProvider.get().getJarFile(jd.getLocation(), jd.getVersion(), contentType);
              } finally {
                ResourceProvider.get().decrementInternalUse(i);
              } 
            }
          });
    } catch (PrivilegedActionException privilegedActionException) {
      throw (IOException)privilegedActionException.getException();
    } 
  }
  
  private void addLoadedJarsEntry(JARDesc paramJARDesc) {
    String str = paramJARDesc.getLocationString();
    if (!this._jarsInURLClassLoader.containsKey(str))
      this._jarsInURLClassLoader.put(str, paramJARDesc); 
  }
  
  public void addResource(URL paramURL, String paramString1, String paramString2) {
    if (this._jclParent != null) {
      this._jclParent.addResource(paramURL, paramString1, paramString2);
      drainPendingURLs();
      return;
    } 
    JARDesc jARDesc = new JARDesc(paramURL, paramString1, true, false, false, null, 0, null);
    String str = jARDesc.getLocationString();
    if (!this._jarsInURLClassLoader.containsKey(str)) {
      this._launchDesc.getResources().addResource((ResourceType)jARDesc);
      addLoadedJarsEntry(jARDesc);
      addURL2(paramURL);
    } 
  }
  
  static boolean setDeployURLClassPathCallbacks(JNLPClassLoader paramJNLPClassLoader1, JNLPClassLoader paramJNLPClassLoader2) {
    try {
      if (!ResourceProvider.get().hasEnhancedJarAccess()) {
        Trace.println("setDeployURLClassPathCallbacks: no enhanced access", TraceLevel.BASIC);
        return false;
      } 
      CPCallbackHandler cPCallbackHandler = new CPCallbackHandler(paramJNLPClassLoader1, paramJNLPClassLoader2);
      getDUCP(paramJNLPClassLoader1).setDeployURLClassPathCallback(cPCallbackHandler.getParentCallback());
      getDUCP(paramJNLPClassLoader2).setDeployURLClassPathCallback(cPCallbackHandler.getChildCallback());
    } catch (ThreadDeath threadDeath) {
      throw threadDeath;
    } catch (Exception exception) {
      Trace.ignored(exception, true);
      return false;
    } catch (Error error) {
      Trace.ignored(error, true);
      return false;
    } 
    return true;
  }
  
  private static DeployURLClassPath getDUCP(JNLPClassLoader paramJNLPClassLoader) { return (DeployURLClassPath)getUCP(paramJNLPClassLoader); }
  
  private static URLClassPath getUCP(JNLPClassLoader paramJNLPClassLoader) {
    URLClassPath uRLClassPath = null;
    try {
      uRLClassPath = (URLClassPath)ucpField.get(paramJNLPClassLoader);
    } catch (Exception exception) {}
    return uRLClassPath;
  }
  
  private static void setUCP(JNLPClassLoader paramJNLPClassLoader, URLClassPath paramURLClassPath) {
    try {
      ucpField.set(paramJNLPClassLoader, paramURLClassPath);
    } catch (Exception exception) {}
  }
  
  private static Field getUCPField(final String name) { return AccessController.doPrivileged(new PrivilegedAction<Field>() {
          public Object run() {
            try {
              Field field = URLClassLoader.class.getDeclaredField(name);
              field.setAccessible(true);
              return field;
            } catch (Exception exception) {
              return null;
            } 
          }
        }); }
  
  protected void addURL(URL paramURL) {
    if (this._jclParent != null)
      this._jclParent.addURL(paramURL); 
    super.addURL(paramURL);
  }
  
  void addURL2(URL paramURL) {
    if (this._jclParent != null) {
      drainPendingURLs();
    } else {
      putAddedURL(paramURL);
    } 
    super.addURL(paramURL);
  }
  
  boolean drainPendingURLs() {
    List<URL> list = this._jclParent.grabAddedURLs();
    byte b;
    for (b = 0; b < list.size(); b++)
      super.addURL(list.get(b)); 
    return (b != 0);
  }
  
  synchronized List grabAddedURLs() {
    List list = this.addedURLs;
    this.addedURLs = new ArrayList();
    return list;
  }
  
  synchronized void putAddedURL(URL paramURL) { this.addedURLs.add(paramURL); }
  
  public DeploymentRuleSet getDeploymentRuleSet(URL paramURL) {
    JARDesc jARDesc = getJarDescFromURL(paramURL);
    if (jARDesc != null && jARDesc.getParent() != null) {
      LaunchDesc launchDesc = jARDesc.getParent().getParent();
      if (launchDesc != null) {
        CodeRef codeRef1 = jARDesc.getCodeRef();
        AppRef appRef1 = LaunchDesc.getJNLPAppRef(launchDesc);
        return DeploymentRuleSet.findDRS(new CodeInstance(appRef1, codeRef1));
      } 
    } 
    URL uRL = (getLaunchDesc() == null) ? null : getLaunchDesc().getAnchorURL();
    boolean bool = (jARDesc != null) ? jARDesc.isPack200Enabled() : false;
    CodeRef codeRef = new CodeRef(paramURL, null, false, bool);
    AppRef appRef = new AppRef(AppRef.Type.JNLP, null, null, null, uRL);
    return DeploymentRuleSet.findDRS(new CodeInstance(appRef, codeRef));
  }
  
  public boolean wantsAllPerms(CodeSource paramCodeSource) {
    if (paramCodeSource != null) {
      JARDesc jARDesc = getJarDescFromURL(paramCodeSource.getLocation());
      if (jARDesc != null && jARDesc.getParent() != null) {
        LaunchDesc launchDesc = jARDesc.getParent().getParent();
        if (launchDesc != null && launchDesc.getSecurityModel() != 0)
          return true; 
      } else if (paramCodeSource.getCertificates() != null && this._launchDesc != null && this._launchDesc.getSecurityModel() != 0) {
        return true;
      } 
    } 
    return false;
  }
  
  public BasicService getBasicService() { return BasicServiceImpl.getInstance(); }
  
  public FileOpenService getFileOpenService() { return FileOpenServiceImpl.getInstance(); }
  
  public FileSaveService getFileSaveService() { return FileSaveServiceImpl.getInstance(); }
  
  public ExtensionInstallerService getExtensionInstallerService() { return ExtensionInstallerServiceImpl.getInstance(); }
  
  public DownloadService getDownloadService() { return DownloadServiceImpl.getInstance(); }
  
  public ClipboardService getClipboardService() { return ClipboardServiceImpl.getInstance(); }
  
  public PrintService getPrintService() { return PrintServiceImpl.getInstance(); }
  
  public PersistenceService getPersistenceService() { return PersistenceServiceImpl.getInstance(); }
  
  public ExtendedService getExtendedService() { return ExtendedServiceImpl.getInstance(); }
  
  public SingleInstanceService getSingleInstanceService() { return SingleInstanceServiceImpl.getInstance(); }
  
  public IntegrationService getIntegrationService() { return (IntegrationService)(Platform.get().isNativeSandbox() ? new IntegrationServiceNSBImpl(new IntegrationServiceImpl(this)) : new IntegrationServiceImpl(this)); }
  
  public DownloadService2 getDownloadService2() { return DownloadService2Impl.getInstance(); }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/jnlp/JNLPClassLoader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */