package com.sun.javaws.ui;

import com.sun.deploy.config.Config;
import com.sun.deploy.trace.Trace;
import com.sun.deploy.util.DeploySysAction;
import com.sun.deploy.util.DeploySysRun;
import com.sun.javaws.Main;
import com.sun.javaws.security.AppContextUtil;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.LinkedList;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import javax.swing.JDialog;
import javax.swing.SwingUtilities;

public final class JavawsSysRun extends DeploySysRun {
  private final SecureThread t = new SecureThread();
  
  private static final Executor executor = Executors.newSingleThreadExecutor();
  
  private void delegateFromEDT(final Job job) throws Exception {
    DummyDialog dummyDialog = new DummyDialog();
    job.setDialog(dummyDialog);
    if (Config.getOSName().equals("Windows")) {
      dummyDialog.setLocation(-200, -200);
    } else {
      Rectangle rectangle = new Rectangle(new Point(0, 0), Toolkit.getDefaultToolkit().getScreenSize());
      dummyDialog.setLocation(rectangle.x + rectangle.width / 2 - 50, rectangle.y + rectangle.height / 2);
    } 
    dummyDialog.setResizable(false);
    dummyDialog.toBack();
    dummyDialog.addWindowListener(new WindowAdapter() {
          public void windowOpened(WindowEvent param1WindowEvent) { executor.execute(new Runnable() {
                  public void run() {
                    synchronized (JavawsSysRun.this.t.mutex) {
                      JavawsSysRun.this.t.addJob(job);
                      JavawsSysRun.this.t.mutex.notifyAll();
                    } 
                  }
                }); }
        });
    dummyDialog.setVisible(true);
    dummyDialog.dispose();
  }
  
  public Object delegate(DeploySysAction paramDeploySysAction) throws Exception {
    if (Main.getSecurityThreadGroup() == null || Main.getSecurityThreadGroup().equals(Thread.currentThread().getThreadGroup()))
      return paramDeploySysAction.execute(); 
    Job job = new Job(paramDeploySysAction);
    if (AppContextUtil.isApplicationAppContext() && SwingUtilities.isEventDispatchThread()) {
      delegateFromEDT(job);
    } else {
      synchronized (this.t.mutex) {
        this.t.addJob(job);
        this.t.mutex.notifyAll();
        while (!job.done) {
          try {
            this.t.mutex.wait();
          } catch (InterruptedException interruptedException) {
            Trace.ignoredException(interruptedException);
          } 
        } 
        this.t.mutex.notifyAll();
      } 
    } 
    if (job.exception != null)
      throw job.exception; 
    return job.result;
  }
  
  static void invokeLater(final Runnable runner) {
    if (Main.getSecurityThreadGroup() == null || Main.getSecurityThreadGroup().equals(Thread.currentThread().getThreadGroup())) {
      SwingUtilities.invokeLater(runner);
      return;
    } 
    final Runnable invoker = new Runnable() {
        public void run() { SwingUtilities.invokeLater(runner); }
      };
    AccessController.doPrivileged(new PrivilegedAction() {
          public Object run() {
            Thread thread = new Thread(Main.getSecurityThreadGroup(), invoker);
            thread.setContextClassLoader(Main.getSecureContextClassLoader());
            thread.start();
            return null;
          }
        });
  }
  
  private class DummyDialog extends JDialog {
    private ThreadGroup _callingTG = Thread.currentThread().getThreadGroup();
    
    DummyDialog() { super((Frame)null, true); }
    
    public void secureHide() { (new Thread(this._callingTG, new Runnable() {
            public void run() { JavawsSysRun.DummyDialog.this.setVisible(false); }
          })).start(); }
  }
  
  class Job {
    final DeploySysAction action;
    
    JavawsSysRun.DummyDialog dialog;
    
    Object result;
    
    Exception exception;
    
    boolean done;
    
    Job(DeploySysAction param1DeploySysAction) {
      this.action = param1DeploySysAction;
      this.done = false;
    }
    
    void setDialog(JavawsSysRun.DummyDialog param1DummyDialog) { this.dialog = param1DummyDialog; }
  }
  
  class SecureThread extends Thread {
    Object mutex = new Object();
    
    LinkedList jobList = new LinkedList();
    
    SecureThread() {
      super(Main.getSecurityThreadGroup(), "Javaws Secure Thread");
      setDaemon(true);
      setContextClassLoader(Main.getSecureContextClassLoader());
      start();
    }
    
    void addJob(JavawsSysRun.Job param1Job) { this.jobList.add(param1Job); }
    
    private void doWork(JavawsSysRun.Job param1Job) {
      try {
        SwingUtilities.invokeLater(new Runnable() {
              public void run() { Thread.currentThread().setContextClassLoader(Main.getSecureContextClassLoader()); }
            });
        param1Job.result = param1Job.action.execute();
      } catch (Exception exception) {
        param1Job.exception = exception;
      } finally {
        param1Job.done = true;
        if (param1Job.dialog != null)
          param1Job.dialog.secureHide(); 
      } 
    }
    
    public void run() {
      synchronized (this.mutex) {
        while (true) {
          while (!this.jobList.isEmpty()) {
            JavawsSysRun.Job job = this.jobList.removeFirst();
            doWork(job);
          } 
          this.mutex.notifyAll();
          try {
            this.mutex.wait();
          } catch (InterruptedException interruptedException) {
            Trace.ignoredException(interruptedException);
          } 
        } 
      } 
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/com/sun/javaws/ui/JavawsSysRun.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */