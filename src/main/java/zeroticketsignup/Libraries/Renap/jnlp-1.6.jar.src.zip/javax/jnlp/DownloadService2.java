package javax.jnlp;

import com.sun.jnlp.DownloadService2Impl;
import java.io.IOException;

public interface DownloadService2 {
  public static final int ALL = 0;
  
  public static final int APPLICATION = 1;
  
  public static final int APPLET = 2;
  
  public static final int EXTENSION = 3;
  
  public static final int JAR = 4;
  
  public static final int IMAGE = 5;
  
  public static final int CLASS = 6;
  
  ResourceSpec[] getCachedResources(ResourceSpec paramResourceSpec);
  
  ResourceSpec[] getUpdateAvailableResources(ResourceSpec paramResourceSpec) throws IOException;
  
  public static class ResourceSpec {
    private String url;
    
    private String version;
    
    private int type;
    
    private long size;
    
    private long lastModified;
    
    private long expirationDate;
    
    public ResourceSpec(String param1String1, String param1String2, int param1Int) {
      this.url = param1String1;
      this.version = param1String2;
      this.type = param1Int;
      this.size = -1L;
    }
    
    public String getUrl() { return this.url; }
    
    public String getVersion() { return this.version; }
    
    public int getType() { return this.type; }
    
    public long getSize() { return this.size; }
    
    public long getLastModified() { return this.lastModified; }
    
    public long getExpirationDate() { return this.expirationDate; }
    
    static  {
      DownloadService2Impl.setResourceSpecAccess(new DownloadService2Impl.ResourceSpecAccess() {
            public void setSize(DownloadService2.ResourceSpec param2ResourceSpec, long param2Long) { param2ResourceSpec.size = param2Long; }
            
            public void setLastModified(DownloadService2.ResourceSpec param2ResourceSpec, long param2Long) { param2ResourceSpec.lastModified = param2Long; }
            
            public void setExpirationDate(DownloadService2.ResourceSpec param2ResourceSpec, long param2Long) { param2ResourceSpec.expirationDate = param2Long; }
          });
    }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/DownloadService2.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */