package javax.jnlp;

import java.io.File;
import java.io.IOException;

public interface ExtendedService {
  FileContents openFile(File paramFile) throws IOException;
  
  FileContents[] openFiles(File[] paramArrayOfFile) throws IOException;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/ExtendedService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */