package javax.jnlp;

public final class ServiceManager {
  private static ServiceManagerStub _stub = null;
  
  public static Object lookup(String paramString) throws UnavailableServiceException {
    if (_stub != null)
      return _stub.lookup(paramString); 
    throw new UnavailableServiceException("uninitialized");
  }
  
  public static String[] getServiceNames() { return (_stub != null) ? _stub.getServiceNames() : null; }
  
  public static synchronized void setServiceManagerStub(ServiceManagerStub paramServiceManagerStub) {
    if (_stub == null)
      _stub = paramServiceManagerStub; 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/ServiceManager.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */