package javax.jnlp;

import java.net.URL;

public interface BasicService {
  URL getCodeBase();
  
  boolean isOffline();
  
  boolean showDocument(URL paramURL);
  
  boolean isWebBrowserSupported();
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/BasicService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */