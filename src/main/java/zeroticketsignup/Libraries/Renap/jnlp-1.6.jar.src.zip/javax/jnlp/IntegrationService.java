package javax.jnlp;

public interface IntegrationService {
  boolean requestShortcut(boolean paramBoolean1, boolean paramBoolean2, String paramString);
  
  boolean hasDesktopShortcut();
  
  boolean hasMenuShortcut();
  
  boolean removeShortcuts();
  
  boolean requestAssociation(String paramString, String[] paramArrayOfString);
  
  boolean hasAssociation(String paramString, String[] paramArrayOfString);
  
  boolean removeAssociation(String paramString, String[] paramArrayOfString);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/IntegrationService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */