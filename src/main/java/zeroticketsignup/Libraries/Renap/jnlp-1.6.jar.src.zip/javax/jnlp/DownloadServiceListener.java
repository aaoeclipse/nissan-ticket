package javax.jnlp;

import java.net.URL;

public interface DownloadServiceListener {
  void progress(URL paramURL, String paramString, long paramLong1, long paramLong2, int paramInt);
  
  void validating(URL paramURL, String paramString, long paramLong1, long paramLong2, int paramInt);
  
  void upgradingArchive(URL paramURL, String paramString, int paramInt1, int paramInt2);
  
  void downloadFailed(URL paramURL, String paramString);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/DownloadServiceListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */