package javax.jnlp;

import java.io.IOException;
import java.io.InputStream;

public interface FileSaveService {
  FileContents saveFileDialog(String paramString1, String[] paramArrayOfString, InputStream paramInputStream, String paramString2) throws IOException;
  
  FileContents saveAsFileDialog(String paramString, String[] paramArrayOfString, FileContents paramFileContents) throws IOException;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/jnlp-1.6.jar!/javax/jnlp/FileSaveService.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.1
 */