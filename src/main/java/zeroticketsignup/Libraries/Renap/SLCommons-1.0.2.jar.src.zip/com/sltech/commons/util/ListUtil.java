package com.sltech.commons.util;

import com.sltech.commons.exception.SLException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ListUtil<T, O> {
  private String metodo = "";
  
  public ListUtil(String paramString) { this.metodo = paramString; }
  
  public void sortList(List<T> paramList) { Collections.sort(paramList, new Comparator<T>() {
          public int compare(Object param1Object1, Object param1Object2) {
            try {
              Object object1 = param1Object1;
              Object object2 = param1Object2;
              Method method = object1.getClass().getDeclaredMethod(ListUtil.this.metodo, (Class[])null);
              Object object3 = method.invoke(param1Object1, (Object[])null);
              method = object2.getClass().getDeclaredMethod(ListUtil.this.metodo, (Class[])null);
              Object object4 = method.invoke(param1Object2, (Object[])null);
              return (object3 != null && object4 != null) ? object3.toString().compareTo(object4.toString()) : ((object3 == null) ? -1 : 1);
            } catch (Exception exception) {
              exception.printStackTrace();
              return 0;
            } 
          }
        }); }
  
  public T searchItem(List<T> paramList, O paramO) throws SLException { // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_1
    //   3: invokeinterface iterator : ()Ljava/util/Iterator;
    //   8: astore #4
    //   10: aload #4
    //   12: invokeinterface hasNext : ()Z
    //   17: ifeq -> 128
    //   20: aload #4
    //   22: invokeinterface next : ()Ljava/lang/Object;
    //   27: astore #5
    //   29: aload #5
    //   31: invokevirtual getClass : ()Ljava/lang/Class;
    //   34: aload_0
    //   35: getfield metodo : Ljava/lang/String;
    //   38: aconst_null
    //   39: checkcast [Ljava/lang/Class;
    //   42: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    //   45: astore #6
    //   47: aload #6
    //   49: aload #5
    //   51: aconst_null
    //   52: checkcast [Ljava/lang/Object;
    //   55: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    //   58: astore #7
    //   60: aload #7
    //   62: aload_2
    //   63: invokevirtual equals : (Ljava/lang/Object;)Z
    //   66: ifeq -> 72
    //   69: aload #5
    //   71: astore_3
    //   72: goto -> 125
    //   75: astore #6
    //   77: new java/lang/StringBuilder
    //   80: dup
    //   81: invokespecial <init> : ()V
    //   84: ldc 'Error looking for element: '
    //   86: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: aload_2
    //   90: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   93: ldc ' on list '
    //   95: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   98: aload_1
    //   99: invokevirtual getClass : ()Ljava/lang/Class;
    //   102: invokevirtual getName : ()Ljava/lang/String;
    //   105: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   108: invokevirtual toString : ()Ljava/lang/String;
    //   111: astore #7
    //   113: new com/sltech/commons/exception/SLException
    //   116: dup
    //   117: aload #7
    //   119: aload #6
    //   121: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
    //   124: athrow
    //   125: goto -> 10
    //   128: aload_3
    //   129: areturn
    // Exception table:
    //   from	to	target	type
    //   29	72	75	java/lang/Exception }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/SLCommons-1.0.2.jar!/com/sltech/commons/util/ListUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */