package com.sltech.commons.exception;

public class SLException extends Exception {
  public SLException(Throwable paramThrowable) { super(paramThrowable); }
  
  public SLException(String paramString, Throwable paramThrowable) { super(paramString, paramThrowable); }
  
  public SLException(String paramString) { super(paramString); }
  
  public SLException() {}
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/SLCommons-1.0.2.jar!/com/sltech/commons/exception/SLException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */