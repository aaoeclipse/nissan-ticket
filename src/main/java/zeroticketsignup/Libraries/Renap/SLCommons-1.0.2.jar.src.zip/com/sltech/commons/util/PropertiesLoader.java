package com.sltech.commons.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesLoader {
  private static PropertiesLoader instance = null;
  
  private Properties properties = null;
  
  public static PropertiesLoader getInstance() {
    if (instance == null)
      instance = new PropertiesLoader(); 
    return instance;
  }
  
  private void overrideWithSystemProperty(String paramString, Properties paramProperties) {
    if (System.getProperty(paramString) != null)
      paramProperties.setProperty(paramString, System.getProperty(paramString)); 
  }
  
  public void loadProperties(String paramString) throws IOException {
    this.properties = new Properties();
    InputStream inputStream = PropertiesLoader.class.getResourceAsStream(paramString);
    if (inputStream == null)
      throw new IOException("Properties file " + paramString + " not found."); 
    this.properties.load(inputStream);
    for (String str2 : this.properties.keySet()) {
      String str1 = str2;
      overrideWithSystemProperty(str1, this.properties);
    } 
    inputStream.close();
  }
  
  public Properties getProperties() { return this.properties; }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/SLCommons-1.0.2.jar!/com/sltech/commons/util/PropertiesLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */