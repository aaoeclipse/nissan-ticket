package com.sltech.commons.gui.document;

import java.awt.Toolkit;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

public class JTextFieldNumericDocument extends PlainDocument {
  public static final short TYPE_NATURAL = 1;
  
  public static final short TYPE_INTEGER = 2;
  
  public static final short TYPE_REAL = 3;
  
  private int limit = 8;
  
  private short numericType = 3;
  
  public JTextFieldNumericDocument(short paramShort) { this.numericType = paramShort; }
  
  public JTextFieldNumericDocument(short paramShort, int paramInt) {
    this.limit = paramInt;
    this.numericType = paramShort;
  }
  
  public void insertString(int paramInt, String paramString, AttributeSet paramAttributeSet) throws BadLocationException {
    boolean bool;
    if (paramString == null)
      return; 
    switch (this.numericType) {
      case 1:
        bool = paramString.matches("[+]?\\d+");
        break;
      case 2:
        bool = paramString.matches("[+-]?\\d+");
        break;
      case 3:
        bool = paramString.matches("[-+]?\\d*\\.?\\d+");
        break;
      default:
        bool = false;
        break;
    } 
    if (getLength() + paramString.length() <= this.limit && bool) {
      super.insertString(paramInt, paramString, paramAttributeSet);
    } else {
      Toolkit.getDefaultToolkit().beep();
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/SLCommonsGUI-1.0.2.jar!/com/sltech/commons/gui/document/JTextFieldNumericDocument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */