package com.sltech.commons.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class AppHelper {
  public static final String newline = System.getProperty("line.separator");
  
  public static final int CHARS_IN_SENTENCE = 60;
  
  public static String fitMessage(String paramString, int paramInt) {
    String str = "";
    byte b1 = 0;
    for (byte b2 = 0; b2 < paramString.length(); b2++) {
      if (paramString.charAt(b2) == '\r' || paramString.charAt(b2) == '\n')
        b1 = 0; 
      if (paramString.charAt(b2) != ' ' || b1)
        str = str + paramString.charAt(b2); 
      if (++b1 > paramInt)
        switch (paramString.charAt(b2)) {
          case '\t':
          case ' ':
          case ',':
          case '.':
          case ':':
            str = str + newline;
            b1 = 0;
            break;
        }  
    } 
    return str;
  }
  
  public static String fitMessage(String paramString) { return fitMessage(paramString, 60); }
  
  public static void showErrorMessage(Component paramComponent, String paramString1, String paramString2, Exception paramException) { JOptionPane.showMessageDialog(paramComponent, fitMessage(paramString2 + newline + newline + paramException), paramString1, 0); }
  
  public static void showErrorMessage(Component paramComponent, String paramString1, String paramString2) { JOptionPane.showMessageDialog(paramComponent, fitMessage(paramString2), paramString1, 0); }
  
  public static void showInformationMessage(Component paramComponent, String paramString1, String paramString2) { JOptionPane.showMessageDialog(paramComponent, fitMessage(paramString2), paramString1, 1); }
  
  public static void setCancelOnEscape(JDialog paramJDialog, JButton paramJButton) {
    KeyStroke keyStroke = KeyStroke.getKeyStroke(27, 0);
    String str = "com.easymarketing.app.dispatch:WINDOW_CLOSING";
    InputMap inputMap = paramJDialog.getRootPane().getInputMap(2);
    if (inputMap.get(keyStroke) == null)
      inputMap.put(keyStroke, str); 
    if (paramJDialog.getRootPane().getActionMap().get("ESCAPE") != null)
      paramJDialog.getRootPane().getActionMap().remove("ESCAPE"); 
    final JButton cancelBtn = paramJButton;
    if (paramJButton != null) {
      AbstractAction abstractAction = new AbstractAction() {
          public void actionPerformed(ActionEvent param1ActionEvent) { cancelBtn.doClick(); }
        };
      paramJDialog.getRootPane().getActionMap().put(str, abstractAction);
    } 
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/SLCommonsGUI-1.0.2.jar!/com/sltech/commons/gui/AppHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */