package com.sltech.commons.gui.view;

import com.sltech.commons.gui.AppHelper;
import com.sltech.commons.util.ListUtil;
import java.awt.Frame;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import org.jdesktop.beansbinding.AutoBinding;
import org.jdesktop.beansbinding.Binding;
import org.jdesktop.beansbinding.BindingGroup;
import org.jdesktop.beansbinding.ELProperty;
import org.jdesktop.beansbinding.Property;
import org.jdesktop.layout.GroupLayout;
import org.jdesktop.observablecollections.ObservableCollections;
import org.jdesktop.swingbinding.JTableBinding;
import org.jdesktop.swingbinding.SwingBindings;

public class AppInfoView extends JDialog {
  private Properties properties;
  
  private BindingGroup bindingGroup;
  
  private JButton btnClose;
  
  private JPanel infoPanel;
  
  private JLabel labelHost;
  
  private JLabel labelIP;
  
  private JLabel labelOS;
  
  private JLabel labelUser;
  
  private JLabel labelVM;
  
  private JLabel labellMemory;
  
  private JLabel lblHost;
  
  private JLabel lblIP;
  
  private JLabel lblJVM;
  
  private JLabel lblMemory;
  
  private JLabel lblOS;
  
  private JLabel lblUser;
  
  private List<PropertyValueTO> propertiesList;
  
  private JScrollPane propertiesScrollPane;
  
  private JTable propertiesTable;
  
  public AppInfoView(Frame paramFrame, boolean paramBoolean, Properties paramProperties) {
    super(paramFrame, paramBoolean);
    initComponents();
    standarizeDialog();
    this.properties = paramProperties;
    initData();
  }
  
  private void standarizeDialog() {
    getRootPane().setDefaultButton(this.btnClose);
    AppHelper.setCancelOnEscape(this, this.btnClose);
  }
  
  private void initData() {
    String str = System.getProperty("os.name") + " " + System.getProperty("os.version") + " (" + System.getProperty("os.arch") + ")";
    this.labelOS.setText(str);
    str = System.getProperty("java.vm.vendor") + " " + System.getProperty("java.version");
    this.labelVM.setText(str);
    long l1 = Runtime.getRuntime().totalMemory() / 1024L;
    long l2 = Runtime.getRuntime().maxMemory() / 1024L;
    this.labellMemory.setText(l1 + " / " + l2 + " KB");
    try {
      InetAddress inetAddress = InetAddress.getLocalHost();
      str = inetAddress.getHostAddress();
      this.labelIP.setText(str);
      str = inetAddress.getHostName();
      this.labelHost.setText(str);
    } catch (UnknownHostException unknownHostException) {
      this.labelIP.setText("N/A");
      this.labelHost.setText("N/A");
    } 
    for (String str2 : this.properties.keySet()) {
      String str1 = str2;
      PropertyValueTO propertyValueTO = new PropertyValueTO();
      propertyValueTO.setKey(str1);
      propertyValueTO.setValue(this.properties.getProperty(str1));
      this.propertiesList.add(propertyValueTO);
    } 
    ListUtil listUtil = new ListUtil("getKey");
    listUtil.sortList(this.propertiesList);
    setUserName(System.getProperty("user.name"));
  }
  
  private void setUserName(String paramString) {
    if (paramString != null) {
      this.labelUser.setText(paramString);
    } else {
      this.labelUser.setText("N/A");
    } 
  }
  
  private void initPropertiesTable() {
    this.bindingGroup = new BindingGroup();
    JTableBinding jTableBinding = SwingBindings.createJTableBinding(AutoBinding.UpdateStrategy.READ_WRITE, this.propertiesList, this.propertiesTable);
    JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding((Property)ELProperty.create("${key}"));
    columnBinding.setColumnName("Key");
    columnBinding.setColumnClass(String.class);
    columnBinding.setEditable(false);
    columnBinding = jTableBinding.addColumnBinding((Property)ELProperty.create("${value}"));
    columnBinding.setColumnName("Value");
    columnBinding.setColumnClass(String.class);
    columnBinding.setEditable(false);
    this.bindingGroup.addBinding((Binding)jTableBinding);
    this.propertiesScrollPane.setViewportView(this.propertiesTable);
    this.bindingGroup.bind();
  }
  
  private void initComponents() {
    this.propertiesList = (List<PropertyValueTO>)ObservableCollections.observableList(new ArrayList());
    this.infoPanel = new JPanel();
    this.lblOS = new JLabel();
    this.lblJVM = new JLabel();
    this.lblMemory = new JLabel();
    this.lblHost = new JLabel();
    this.lblIP = new JLabel();
    this.lblUser = new JLabel();
    this.labelOS = new JLabel();
    this.labelVM = new JLabel();
    this.labellMemory = new JLabel();
    this.labelHost = new JLabel();
    this.labelIP = new JLabel();
    this.labelUser = new JLabel();
    this.propertiesScrollPane = new JScrollPane();
    this.propertiesTable = new JTable();
    initPropertiesTable();
    this.btnClose = new JButton();
    setDefaultCloseOperation(2);
    setTitle("Más Información");
    this.infoPanel.setBorder(BorderFactory.createTitledBorder("Información General"));
    this.lblOS.setText("Sistema Operativo:");
    this.lblJVM.setText("Java VM:");
    this.lblMemory.setText("Memoria:");
    this.lblHost.setText("Host:");
    this.lblIP.setText("IP Address:");
    this.lblUser.setText("Usuario:");
    this.labelOS.setText("jLabel5");
    this.labelVM.setText("jLabel6");
    this.labellMemory.setText("jLabel7");
    this.labelHost.setText("jLabel7");
    this.labelIP.setText("jLabel8");
    this.labelUser.setText("jLabel9");
    GroupLayout groupLayout1 = new GroupLayout(this.infoPanel);
    this.infoPanel.setLayout((LayoutManager)groupLayout1);
    groupLayout1.setHorizontalGroup((GroupLayout.Group)groupLayout1.createParallelGroup(1).add((GroupLayout.Group)groupLayout1.createSequentialGroup().add((GroupLayout.Group)groupLayout1.createParallelGroup(1).add((GroupLayout.Group)groupLayout1.createSequentialGroup().add((GroupLayout.Group)groupLayout1.createParallelGroup(1).add((GroupLayout.Group)groupLayout1.createParallelGroup(1, false).add(this.lblOS, -1, -1, 32767).add(this.lblJVM, -1, -1, 32767)).add((GroupLayout.Group)groupLayout1.createParallelGroup(1, false).add(this.lblIP, -1, -1, 32767).add(this.lblHost)).add(this.lblMemory)).add(18, 18, 18).add((GroupLayout.Group)groupLayout1.createParallelGroup(1).add(this.labelOS, -1, -1, 32767).add(this.labelVM, -1, -1, 32767).add(this.labellMemory, -1, -1, 32767).add(this.labelHost, -1, -1, 32767).add(this.labelIP, -1, -1, 32767).add(this.labelUser, -1, 286, 32767))).add((GroupLayout.Group)groupLayout1.createSequentialGroup().add(this.lblUser).add(0, 356, 32767))).addContainerGap()));
    groupLayout1.setVerticalGroup((GroupLayout.Group)groupLayout1.createParallelGroup(1).add((GroupLayout.Group)groupLayout1.createSequentialGroup().add((GroupLayout.Group)groupLayout1.createParallelGroup(3).add(this.lblOS).add(this.labelOS)).addPreferredGap(0).add((GroupLayout.Group)groupLayout1.createParallelGroup(1, false).add(this.lblJVM, -1, -1, 32767).add(this.labelVM, -1, -1, 32767)).addPreferredGap(0).add((GroupLayout.Group)groupLayout1.createParallelGroup(3).add(this.lblMemory).add(this.labellMemory)).addPreferredGap(0).add((GroupLayout.Group)groupLayout1.createParallelGroup(3).add(this.lblHost).add(this.labelHost)).addPreferredGap(0).add((GroupLayout.Group)groupLayout1.createParallelGroup(3).add(this.lblIP).add(this.labelIP)).addPreferredGap(0).add((GroupLayout.Group)groupLayout1.createParallelGroup(3).add(this.lblUser).add(this.labelUser)).addContainerGap(-1, 32767)));
    this.propertiesTable.setAutoCreateColumnsFromModel(false);
    this.propertiesScrollPane.setViewportView(this.propertiesTable);
    this.btnClose.setMnemonic('C');
    this.btnClose.setText("Cerrar");
    this.btnClose.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent param1ActionEvent) { AppInfoView.this.btnCloseActionPerformed(param1ActionEvent); }
        });
    GroupLayout groupLayout2 = new GroupLayout(getContentPane());
    getContentPane().setLayout((LayoutManager)groupLayout2);
    groupLayout2.setHorizontalGroup((GroupLayout.Group)groupLayout2.createParallelGroup(1).add((GroupLayout.Group)groupLayout2.createSequentialGroup().addContainerGap().add((GroupLayout.Group)groupLayout2.createParallelGroup(1).add(this.infoPanel, -1, -1, 32767).add(2, this.propertiesScrollPane, -1, 418, 32767).add(2, (GroupLayout.Group)groupLayout2.createSequentialGroup().add(0, 0, 32767).add(this.btnClose, -2, 90, -2))).addContainerGap()));
    groupLayout2.setVerticalGroup((GroupLayout.Group)groupLayout2.createParallelGroup(1).add((GroupLayout.Group)groupLayout2.createSequentialGroup().addContainerGap().add(this.infoPanel, -2, -1, -2).addPreferredGap(0).add(this.propertiesScrollPane, -1, 175, 32767).addPreferredGap(0).add(this.btnClose).addContainerGap()));
    pack();
  }
  
  private void btnCloseActionPerformed(ActionEvent paramActionEvent) {
    setVisible(false);
    dispose();
  }
  
  public Properties getProperties() { return this.properties; }
  
  public void setProperties(Properties paramProperties) { this.properties = paramProperties; }
  
  public class PropertyValueTO {
    private String key = null;
    
    private String value = null;
    
    public String getKey() { return this.key; }
    
    public void setKey(String param1String) { this.key = param1String; }
    
    public String getValue() { return this.value; }
    
    public void setValue(String param1String) { this.value = param1String; }
  }
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/SLCommonsGUI-1.0.2.jar!/com/sltech/commons/gui/view/AppInfoView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */