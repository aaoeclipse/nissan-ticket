package org.apache.log4j.spi;

public interface OptionHandler {
  void activateOptions();
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/log4j-1.2.17.jar!/org/apache/log4j/spi/OptionHandler.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.1
 */