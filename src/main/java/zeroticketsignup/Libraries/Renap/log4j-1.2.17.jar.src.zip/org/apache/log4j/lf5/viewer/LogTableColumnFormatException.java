/*    */ package org.apache.log4j.lf5.viewer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LogTableColumnFormatException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 6529165785030431653L;
/*    */   
/* 49 */   public LogTableColumnFormatException(String message) { super(message); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/log4j-1.2.17.jar!/org/apache/log4j/lf5/viewer/LogTableColumnFormatException.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.1
 */