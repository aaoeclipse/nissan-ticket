/*    */ package org.apache.log4j.spi;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DefaultRepositorySelector
/*    */   implements RepositorySelector
/*    */ {
/*    */   final LoggerRepository repository;
/*    */   
/* 29 */   public DefaultRepositorySelector(LoggerRepository repository) { this.repository = repository; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public LoggerRepository getLoggerRepository() { return this.repository; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/log4j-1.2.17.jar!/org/apache/log4j/spi/DefaultRepositorySelector.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.1
 */