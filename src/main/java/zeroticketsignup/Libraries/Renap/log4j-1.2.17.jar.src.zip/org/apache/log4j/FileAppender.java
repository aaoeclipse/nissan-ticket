/*     */ package org.apache.log4j;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import org.apache.log4j.helpers.LogLog;
/*     */ import org.apache.log4j.helpers.QuietWriter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileAppender
/*     */   extends WriterAppender
/*     */ {
/*     */   protected boolean fileAppend = true;
/*  58 */   protected String fileName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean bufferedIO = false;
/*     */ 
/*     */ 
/*     */   
/*  67 */   protected int bufferSize = 8192;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileAppender() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileAppender(Layout layout, String filename, boolean append, boolean bufferedIO, int bufferSize) throws IOException {
/*  93 */     this.layout = layout;
/*  94 */     setFile(filename, append, bufferedIO, bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FileAppender(Layout layout, String filename, boolean append) throws IOException {
/* 109 */     this.layout = layout;
/* 110 */     setFile(filename, append, false, this.bufferSize);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public FileAppender(Layout layout, String filename) throws IOException { this(layout, filename, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFile(String file) {
/* 136 */     String val = file.trim();
/* 137 */     this.fileName = val;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 145 */   public boolean getAppend() { return this.fileAppend; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 152 */   public String getFile() { return this.fileName; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void activateOptions() {
/* 163 */     if (this.fileName != null) {
/*     */       try {
/* 165 */         setFile(this.fileName, this.fileAppend, this.bufferedIO, this.bufferSize);
/*     */       }
/* 167 */       catch (IOException e) {
/* 168 */         this.errorHandler.error("setFile(" + this.fileName + "," + this.fileAppend + ") call failed.", e, 4);
/*     */       }
/*     */     
/*     */     } else {
/*     */       
/* 173 */       LogLog.warn("File option not set for appender [" + this.name + "].");
/* 174 */       LogLog.warn("Are you using FileAppender instead of ConsoleAppender?");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void closeFile() {
/* 183 */     if (this.qw != null) {
/*     */       try {
/* 185 */         this.qw.close();
/*     */       }
/* 187 */       catch (IOException e) {
/* 188 */         if (e instanceof java.io.InterruptedIOException) {
/* 189 */           Thread.currentThread().interrupt();
/*     */         }
/*     */ 
/*     */         
/* 193 */         LogLog.error("Could not close " + this.qw, e);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 207 */   public boolean getBufferedIO() { return this.bufferedIO; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 216 */   public int getBufferSize() { return this.bufferSize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 233 */   public void setAppend(boolean flag) { this.fileAppend = flag; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBufferedIO(boolean bufferedIO) {
/* 248 */     this.bufferedIO = bufferedIO;
/* 249 */     if (bufferedIO) {
/* 250 */       this.immediateFlush = false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 260 */   public void setBufferSize(int bufferSize) { this.bufferSize = bufferSize; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setFile(String fileName, boolean append, boolean bufferedIO, int bufferSize) throws IOException {
/* 281 */     LogLog.debug("setFile called: " + fileName + ", " + append);
/*     */ 
/*     */     
/* 284 */     if (bufferedIO) {
/* 285 */       setImmediateFlush(false);
/*     */     }
/*     */     
/* 288 */     reset();
/* 289 */     FileOutputStream ostream = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 294 */       ostream = new FileOutputStream(fileName, append);
/* 295 */     } catch (FileNotFoundException ex) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 301 */       String parentName = (new File(fileName)).getParent();
/* 302 */       if (parentName != null) {
/* 303 */         File parentDir = new File(parentName);
/* 304 */         if (!parentDir.exists() && parentDir.mkdirs()) {
/* 305 */           ostream = new FileOutputStream(fileName, append);
/*     */         } else {
/* 307 */           throw ex;
/*     */         } 
/*     */       } else {
/* 310 */         throw ex;
/*     */       } 
/*     */     } 
/* 313 */     Writer fw = createWriter(ostream);
/* 314 */     if (bufferedIO) {
/* 315 */       fw = new BufferedWriter(fw, bufferSize);
/*     */     }
/* 317 */     setQWForFiles(fw);
/* 318 */     this.fileName = fileName;
/* 319 */     this.fileAppend = append;
/* 320 */     this.bufferedIO = bufferedIO;
/* 321 */     this.bufferSize = bufferSize;
/* 322 */     writeHeader();
/* 323 */     LogLog.debug("setFile ended");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 334 */   protected void setQWForFiles(Writer writer) { this.qw = new QuietWriter(writer, this.errorHandler); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void reset() {
/* 343 */     closeFile();
/* 344 */     this.fileName = null;
/* 345 */     super.reset();
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/log4j-1.2.17.jar!/org/apache/log4j/FileAppender.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.1
 */