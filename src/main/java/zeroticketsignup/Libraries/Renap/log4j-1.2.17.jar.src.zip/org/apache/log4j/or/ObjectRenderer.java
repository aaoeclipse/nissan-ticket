package org.apache.log4j.or;

public interface ObjectRenderer {
  String doRender(Object paramObject);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/log4j-1.2.17.jar!/org/apache/log4j/or/ObjectRenderer.class
 * Java compiler version: 4 (48.0)
 * JD-Core Version:       1.1.1
 */