/*     */ package com.sltech.dpi.impl;
/*     */ 
/*     */ import com.n.h.i;
/*     */ import com.sltech.dpi.IDpiManager;
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import com.sltech.dpi.smartcard.DatosdpiTO;
/*     */ import com.sltech.dpi.smartcard.DpiDataTO;
/*     */ import com.sltech.dpi.smartcard.FingerType;
/*     */ import com.sltech.dpi.util.CardUtils;
/*     */ import com.sltech.dpi.util.DataUtils;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CommandAPDU;
/*     */ import javax.smartcardio.ResponseAPDU;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public abstract class DPIManager
/*     */   implements IDpiManager {
/*     */   protected static final byte[] a;
/*  21 */   private static final Logger j = LoggerFactory.getLogger(DPIManager.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte[] E;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte[] K;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static 
/*     */   {
/* 103 */     a = DataUtils.hexTextToByteArray(i.f("h[\037Yl[{;5\001\033YeV`SgVdT|N7\005"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     K = DataUtils.hexTextToByteArray(i.f("Yj1wDsh(g'\031[n]l_{H3\005oYa$dPbWb'~O4\001"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 197 */     E = DataUtils.hexTextToByteArray(i.f("jY\024R`Rg'`Q\t86\006"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static IDpiManager getInstance(ChipVersion a) {
/*     */     switch (null.K[a.ordinal()]) {
/*     */       case 1:
/*     */         return dpiV1Manager = new DpiV1Manager();
/*     */       case 2:
/*     */         while (true) {
/*     */           DpiV2Manager dpiV2Manager;
/* 228 */           return dpiV2Manager = new DpiV2Manager();
/*     */         } 
/*     */       case 3:
/*     */         while (true) {
/*     */           DpiV3Manager dpiV3Manager;
/*     */           return dpiV3Manager = new DpiV3Manager();
/*     */         } 
/*     */     } 
/*     */     DpiV1Manager dpiV1Manager;
/*     */     return dpiV1Manager = new DpiV1Manager();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static ChipVersion getImplementation(CardChannel a) throws DPIException {
/*     */     ChipVersion chipVersion = null;
/*     */     CommandAPDU commandAPDU = new CommandAPDU(E);
/*     */     try {
/*     */       ResponseAPDU responseAPDU;
/*     */       if (f(responseAPDU = a.transmit(commandAPDU))) {
/*     */         chipVersion = ChipVersion.v3;
/*     */         System.out.println(i.f("AgTzI|O}D"));
/*     */         return chipVersion;
/*     */       } 
/*     */       while (true) {
/*     */         commandAPDU = new CommandAPDU(K);
/*     */         if (f(responseAPDU = a.transmit(commandAPDU))) {
/*     */           chipVersion = ChipVersion.v2;
/*     */           return chipVersion;
/*     */         } 
/*     */         while (true) {
/*     */           return ChipVersion.v1;
/*     */         }
/*     */       } 
/*     */       while (true) {
/*     */         return ChipVersion.v1;
/*     */       }
/*     */     } catch (CardException cardException) {
/*     */       throw new DPIException(cardException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean check9000(byte[] a) { if (a[a.length - 2] == -112 && a[a.length - 1] == 0) {
/*     */       return true;
/*     */     }
/*     */     while (true) {
/*     */       return false;
/*     */     } }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static boolean f(ResponseAPDU a) {
/*     */     return check9000(a.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected static FingerType f(int a) {
/*     */     FingerType fingerType = null;
/*     */     switch (a) {
/*     */       case 5:
/*     */         do {
/*     */         
/*     */         } while (false);
/*     */         return fingerType = FingerType.RIGHT_THUMB;
/*     */       case 9:
/*     */         while (true) {
/*     */           return fingerType = FingerType.RIGHT_INDEX;
/*     */         }
/*     */       case 13:
/*     */         while (true) {
/*     */           return fingerType = FingerType.RIGHT_MIDDLE;
/*     */         }
/*     */       case 17:
/*     */         return fingerType = FingerType.RIGHT_RING;
/*     */       case 21:
/*     */         return fingerType = FingerType.RIGHT_LITTLE;
/*     */       case 6:
/*     */         return fingerType = FingerType.LEFT_THUMB;
/*     */       case 10:
/*     */         return fingerType = FingerType.LEFT_INDEX;
/*     */       case 14:
/*     */         return fingerType = FingerType.LEFT_MIDDLE;
/*     */       case 18:
/*     */         return fingerType = FingerType.LEFT_RING;
/*     */       case 22:
/*     */         fingerType = FingerType.LEFT_LITTLE;
/*     */         break;
/*     */     } 
/*     */     return fingerType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] f(CardChannel a, int a, int a, int a) throws DPIException {
/*     */     byte[] arrayOfByte;
/*     */     Object object = null;
/*     */     1;
/*     */     1[0] = false;
/*     */     1[1] = true;
/*     */     1[2] = a;
/*     */     1[3] = a;
/*     */     1[4] = a;
/*     */     a = 1;
/*     */     CommandAPDU commandAPDU = new CommandAPDU(a);
/*     */     ResponseAPDU responseAPDU;
/*     */     if (!f(responseAPDU = a.transmit(commandAPDU))) {
/*     */       throw new DPIException(i.f("\020\024eK\017n\004;\036'\025)<\004w\0014K=\0021\016%\0340B"));
/*     */     }
/*     */     true;
/*     */     boolean bool = true;
/*     */     System.arraycopy(arrayOfByte, 0, bool, 0, arrayOfByte.length - 2);
/*     */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected DatosdpiTO f(DpiDataTO a) { // Byte code:
/*     */     //   0: new com/sltech/dpi/smartcard/DatosdpiTO
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: dup
/*     */     //   8: astore_2
/*     */     //   9: dup
/*     */     //   10: dup2
/*     */     //   11: dup2
/*     */     //   12: dup2
/*     */     //   13: dup2
/*     */     //   14: dup2
/*     */     //   15: dup2
/*     */     //   16: dup2
/*     */     //   17: dup2
/*     */     //   18: dup2
/*     */     //   19: dup2
/*     */     //   20: dup2
/*     */     //   21: dup2
/*     */     //   22: aload_1
/*     */     //   23: aload_2
/*     */     //   24: dup_x2
/*     */     //   25: aload_1
/*     */     //   26: invokevirtual getCui : ()Ljava/lang/String;
/*     */     //   29: invokevirtual setCui : (Ljava/lang/String;)V
/*     */     //   32: invokevirtual getNombre1 : ()Ljava/lang/String;
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual getNombre2 : ()Ljava/lang/String;
/*     */     //   39: aload_1
/*     */     //   40: invokevirtual getNombre3 : ()Ljava/lang/String;
/*     */     //   43: invokestatic convertTwoLines : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   46: dup
/*     */     //   47: astore_3
/*     */     //   48: iconst_0
/*     */     //   49: aaload
/*     */     //   50: invokevirtual setNombre1 : (Ljava/lang/String;)V
/*     */     //   53: aload_3
/*     */     //   54: iconst_1
/*     */     //   55: aaload
/*     */     //   56: invokevirtual setNombre2 : (Ljava/lang/String;)V
/*     */     //   59: aload_1
/*     */     //   60: invokevirtual getApellido1 : ()Ljava/lang/String;
/*     */     //   63: invokevirtual setApellido1 : (Ljava/lang/String;)V
/*     */     //   66: aload_1
/*     */     //   67: invokevirtual getApellido2 : ()Ljava/lang/String;
/*     */     //   70: invokevirtual setApellido2 : (Ljava/lang/String;)V
/*     */     //   73: aload_1
/*     */     //   74: invokevirtual getApellidoDeCasada : ()Ljava/lang/String;
/*     */     //   77: invokevirtual setApellidoDeCasada : (Ljava/lang/String;)V
/*     */     //   80: aload_1
/*     */     //   81: invokevirtual getGenero : ()Ljava/lang/String;
/*     */     //   84: invokevirtual setGenero : (Ljava/lang/String;)V
/*     */     //   87: aload_1
/*     */     //   88: invokevirtual getNacimientoMunicipio : ()Ljava/lang/String;
/*     */     //   91: invokevirtual setNacimientoMunicipio : (Ljava/lang/String;)V
/*     */     //   94: aload_1
/*     */     //   95: invokevirtual getNacimientoDepartamento : ()Ljava/lang/String;
/*     */     //   98: invokevirtual setNacimientoDepartamento : (Ljava/lang/String;)V
/*     */     //   101: aload_1
/*     */     //   102: invokevirtual getNacimientoPais : ()Ljava/lang/String;
/*     */     //   105: invokevirtual setNacimientoPais : (Ljava/lang/String;)V
/*     */     //   108: aload_1
/*     */     //   109: invokevirtual getNacimientoFecha : ()Ljava/lang/String;
/*     */     //   112: invokevirtual setNacimientoFecha : (Ljava/lang/String;)V
/*     */     //   115: aload_1
/*     */     //   116: invokevirtual getFechaEmision : ()Ljava/lang/String;
/*     */     //   119: invokevirtual setFechaEmision : (Ljava/lang/String;)V
/*     */     //   122: aload_1
/*     */     //   123: invokevirtual getFechaVencimiento : ()Ljava/lang/String;
/*     */     //   126: invokevirtual setFechaVencimiento : (Ljava/lang/String;)V
/*     */     //   129: aload_1
/*     */     //   130: invokevirtual getEstadoCivil : ()Ljava/lang/String;
/*     */     //   133: invokevirtual setEstadoCivil : (Ljava/lang/String;)V
/*     */     //   136: aload_1
/*     */     //   137: invokevirtual getVecindadMunicipio : ()Ljava/lang/String;
/*     */     //   140: invokevirtual setVecindadMunicipio : (Ljava/lang/String;)V
/*     */     //   143: aload_1
/*     */     //   144: invokevirtual getVecindadDepartamento : ()Ljava/lang/String;
/*     */     //   147: invokevirtual setVecindadDepartamento : (Ljava/lang/String;)V
/*     */     //   150: aload_1
/*     */     //   151: invokevirtual getNacionalidad : ()Ljava/lang/String;
/*     */     //   154: invokevirtual setNacionalidad : (Ljava/lang/String;)V
/*     */     //   157: aload_1
/*     */     //   158: invokevirtual getSabeLeer : ()Ljava/lang/String;
/*     */     //   161: invokevirtual setSabeLeer : (Ljava/lang/String;)V
/*     */     //   164: aload_1
/*     */     //   165: invokevirtual getSabeEscribir : ()Ljava/lang/String;
/*     */     //   168: invokevirtual setSabeEscribir : (Ljava/lang/String;)V
/*     */     //   171: aload_1
/*     */     //   172: invokevirtual getProfesion : ()Ljava/lang/String;
/*     */     //   175: invokevirtual setProfesion : (Ljava/lang/String;)V
/*     */     //   178: aload_1
/*     */     //   179: invokevirtual getLimitacionesFisicas : ()Ljava/lang/String;
/*     */     //   182: invokevirtual setLimitacionesFisicas : (Ljava/lang/String;)V
/*     */     //   185: aload_1
/*     */     //   186: invokevirtual getLibro : ()Ljava/lang/String;
/*     */     //   189: invokevirtual setLibro : (Ljava/lang/String;)V
/*     */     //   192: aload_1
/*     */     //   193: invokevirtual getFolio : ()Ljava/lang/String;
/*     */     //   196: invokevirtual setFolio : (Ljava/lang/String;)V
/*     */     //   199: aload_1
/*     */     //   200: invokevirtual getPartida : ()Ljava/lang/String;
/*     */     //   203: invokevirtual setPartida : (Ljava/lang/String;)V
/*     */     //   206: aload_1
/*     */     //   207: invokevirtual getCedulaNumero : ()Ljava/lang/String;
/*     */     //   210: invokevirtual setCedulaNumero : (Ljava/lang/String;)V
/*     */     //   213: aload_1
/*     */     //   214: invokevirtual getCedulaMunicipio : ()Ljava/lang/String;
/*     */     //   217: invokevirtual setCedulaMunicipio : (Ljava/lang/String;)V
/*     */     //   220: aload_1
/*     */     //   221: invokevirtual getCedulaDepartamento : ()Ljava/lang/String;
/*     */     //   224: invokevirtual setCedulaDepartamento : (Ljava/lang/String;)V
/*     */     //   227: aload_1
/*     */     //   228: invokevirtual getOficialActivo : ()Ljava/lang/String;
/*     */     //   231: invokevirtual setOficialActivo : (Ljava/lang/String;)V
/*     */     //   234: aload_1
/*     */     //   235: invokevirtual getFoto : ()[B
/*     */     //   238: ifnull -> 255
/*     */     //   241: aload_2
/*     */     //   242: aload_1
/*     */     //   243: invokevirtual getFoto : ()[B
/*     */     //   246: invokevirtual clone : ()Ljava/lang/Object;
/*     */     //   249: checkcast [B
/*     */     //   252: invokevirtual setFoto : ([B)V
/*     */     //   255: aload_2
/*     */     //   256: dup
/*     */     //   257: aload_1
/*     */     //   258: dup_x1
/*     */     //   259: invokevirtual getMachineReadableZone : ()Ljava/lang/String;
/*     */     //   262: invokevirtual setMachineReadableZone : (Ljava/lang/String;)V
/*     */     //   265: invokevirtual getSerialNumber : ()Ljava/lang/String;
/*     */     //   268: invokevirtual setSerialNumber : (Ljava/lang/String;)V
/*     */     //   271: aload_1
/*     */     //   272: invokevirtual getFingerPrints : ()Ljava/util/List;
/*     */     //   275: ifnull -> 335
/*     */     //   278: new java/util/ArrayList
/*     */     //   281: dup
/*     */     //   282: invokespecial <init> : ()V
/*     */     //   285: astore_3
/*     */     //   286: aload_1
/*     */     //   287: invokevirtual getFingerPrints : ()Ljava/util/List;
/*     */     //   290: invokeinterface iterator : ()Ljava/util/Iterator;
/*     */     //   295: dup
/*     */     //   296: astore_1
/*     */     //   297: invokeinterface hasNext : ()Z
/*     */     //   302: ifeq -> 330
/*     */     //   305: aload_1
/*     */     //   306: invokeinterface next : ()Ljava/lang/Object;
/*     */     //   311: checkcast com/sltech/dpi/smartcard/FingerType
/*     */     //   314: astore #4
/*     */     //   316: aload_1
/*     */     //   317: aload_3
/*     */     //   318: aload #4
/*     */     //   320: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   325: pop
/*     */     //   326: goto -> 297
/*     */     //   329: pop
/*     */     //   330: aload_2
/*     */     //   331: aload_3
/*     */     //   332: invokevirtual setFingerPrints : (Ljava/util/List;)V
/*     */     //   335: aload_2
/*     */     //   336: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #377	-> 0
/*     */     //   #525	-> 9
/*     */     //   #269	-> 32
/*     */     //   #355	-> 48
/*     */     //   #444	-> 53
/*     */     //   #410	-> 59
/*     */     //   #380	-> 66
/*     */     //   #260	-> 73
/*     */     //   #234	-> 80
/*     */     //   #456	-> 87
/*     */     //   #244	-> 94
/*     */     //   #403	-> 101
/*     */     //   #455	-> 108
/*     */     //   #436	-> 115
/*     */     //   #538	-> 122
/*     */     //   #523	-> 129
/*     */     //   #305	-> 136
/*     */     //   #300	-> 143
/*     */     //   #281	-> 150
/*     */     //   #331	-> 157
/*     */     //   #446	-> 164
/*     */     //   #449	-> 171
/*     */     //   #486	-> 178
/*     */     //   #284	-> 185
/*     */     //   #273	-> 192
/*     */     //   #521	-> 199
/*     */     //   #262	-> 206
/*     */     //   #286	-> 213
/*     */     //   #506	-> 220
/*     */     //   #430	-> 227
/*     */     //   #498	-> 234
/*     */     //   #391	-> 241
/*     */     //   #531	-> 255
/*     */     //   #332	-> 265
/*     */     //   #536	-> 271
/*     */     //   #423	-> 278
/*     */     //   #301	-> 286
/*     */     //   #527	-> 317
/*     */     //   #326	-> 330
/*     */     //   #265	-> 335
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	337	0	a	Lcom/sltech/dpi/impl/DPIManager;
/*     */     //   0	337	1	a	Lcom/sltech/dpi/smartcard/DpiDataTO; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] f(CardChannel a, int a, int a, int a) throws DPIException {
/* 402 */     true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 469 */     bool2[0] = false; bool2[1] = true; bool2[2] = (byte)(a | 0xFFFFFF80); bool2[3] = a;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 491 */     byte[] arrayOfByte = CardUtils.intToByteArray(a);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     boolean bool2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     (bool2 = true)[4] = arrayOfByte[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     bool2[5] = arrayOfByte[2];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     (bool2 = true)[6] = arrayOfByte[3];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     String str = DataUtils.arrayToHexText(bool2 = true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     CommandAPDU commandAPDU = new CommandAPDU(bool2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ResponseAPDU responseAPDU;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 557 */     if (!f(responseAPDU = a.transmit(commandAPDU)))
/*     */       throw new DPIException(i.f("\020\024eK\017n\004;\036'\025)<\004w\0014K=\0021\016%\0340B")); 
/*     */     true;
/*     */     boolean bool1 = true;
/*     */     System.arraycopy(arrayOfByte, 0, bool1, 0, arrayOfByte.length - 2);
/*     */     return bool1;
/*     */   }
/*     */   
/*     */   protected byte[] f(CardChannel a, int a, int a) throws DPIException {
/*     */     true;
/*     */     boolean bool2 = true;
/*     */     byte[] arrayOfByte = CardUtils.intToByteArray(a);
/*     */     bool2[0] = false;
/*     */     bool2[1] = true;
/*     */     bool2[2] = arrayOfByte[2];
/*     */     bool2[3] = arrayOfByte[3];
/*     */     arrayOfByte = CardUtils.intToByteArray(a);
/*     */     bool2[4] = arrayOfByte[1];
/*     */     bool2[5] = arrayOfByte[2];
/*     */     bool2[6] = arrayOfByte[3];
/*     */     CommandAPDU commandAPDU = new CommandAPDU(bool2);
/*     */     ResponseAPDU responseAPDU;
/*     */     if (!f(responseAPDU = a.transmit(commandAPDU)))
/*     */       throw new DPIException(i.f("\020\024eK\017n\004;\036'\025)<\004w\0014K=\0021\016%\0340B")); 
/*     */     true;
/*     */     boolean bool1 = true;
/*     */     System.arraycopy(arrayOfByte, 0, bool1, 0, arrayOfByte.length - 2);
/*     */     return bool1;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/impl/DPIManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */