package com.sltech.util.smartcard;

public interface CardTerminalStateListener {
  void cardTerminalStateChanged(CardTerminalStateEvent paramCardTerminalStateEvent);
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/util/smartcard/CardTerminalStateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */