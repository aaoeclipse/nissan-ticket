package com.n.n;

public interface e {
  void f(String paramString, Object[] paramArrayOfObject);
  
  boolean f();
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/n/n/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */