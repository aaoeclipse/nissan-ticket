/*     */ package com.sltech.dpi.impl;
/*     */ 
/*     */ import com.n.h.i;
/*     */ import com.sltech.dpi.IDpiManager;
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import com.sltech.dpi.smartcard.DatosdpiTO;
/*     */ import com.sltech.dpi.smartcard.DpiDataTO;
/*     */ import com.sltech.dpi.smartcard.FingerType;
/*     */ import com.sltech.dpi.util.CardUtils;
/*     */ import com.sltech.dpi.util.DataUtils;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CommandAPDU;
/*     */ import javax.smartcardio.ResponseAPDU;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DpiV1Manager
/*     */   extends DPIManager
/*     */   implements IDpiManager
/*     */ {
/*     */   private static final byte[] A;
/*     */   private static final CommandAPDU g;
/*     */   private static final CommandAPDU B;
/*     */   private static final CommandAPDU f;
/*     */   private static final byte[] M;
/*     */   private static final byte[] d;
/*     */   private static final byte[] D;
/*     */   private static final CommandAPDU i;
/*     */   private static final CommandAPDU e;
/*     */   private static final CommandAPDU I;
/*  74 */   private static final byte[] H = DataUtils.hexTextToByteArray(CardUtils.f("[7>'V>\021\016W:#>O#S?\021}|\020O\"^9a\006\016js\036^2'<^2X4Z6M "));
/*     */ 
/*     */   
/*     */   private static final CommandAPDU J;
/*     */ 
/*     */   
/*     */   private static final CommandAPDU C;
/*     */ 
/*     */   
/*     */   private static final byte[] l;
/*     */ 
/*     */   
/*     */   private static final byte[] j;
/*     */ 
/*     */   
/*     */   private static final CommandAPDU E;
/*     */   
/*     */   private static final byte[] K;
/*     */ 
/*     */   
/*     */   public byte[] readPhoto(CardChannel a) throws DPIException { // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: newarray byte
/*     */     //   3: iconst_1
/*     */     //   4: dup
/*     */     //   5: pop2
/*     */     //   6: astore_3
/*     */     //   7: sipush #256
/*     */     //   10: istore #4
/*     */     //   12: bipush #104
/*     */     //   14: istore #5
/*     */     //   16: bipush #-126
/*     */     //   18: invokestatic valueOf : (B)Ljava/lang/Byte;
/*     */     //   21: astore #6
/*     */     //   23: iconst_0
/*     */     //   24: invokestatic valueOf : (B)Ljava/lang/Byte;
/*     */     //   27: astore #7
/*     */     //   29: aload_1
/*     */     //   30: getstatic com/sltech/dpi/impl/DpiV1Manager.J : Ljavax/smartcardio/CommandAPDU;
/*     */     //   33: invokevirtual transmit : (Ljavax/smartcardio/CommandAPDU;)Ljavax/smartcardio/ResponseAPDU;
/*     */     //   36: invokestatic f : (Ljavax/smartcardio/ResponseAPDU;)Z
/*     */     //   39: ifne -> 56
/*     */     //   42: new com/sltech/dpi/exception/DPIException
/*     */     //   45: dup
/*     */     //   46: ldc_w 'MI(*K:6?8 k'X? 5\\n3\\nz20=!'
/*     */     //   49: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   52: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   55: athrow
/*     */     //   56: aload_0
/*     */     //   57: aload_1
/*     */     //   58: aload #6
/*     */     //   60: invokevirtual byteValue : ()B
/*     */     //   63: aload #7
/*     */     //   65: invokevirtual byteValue : ()B
/*     */     //   68: iconst_0
/*     */     //   69: invokevirtual f : (Ljavax/smartcardio/CardChannel;BBB)[B
/*     */     //   72: astore_2
/*     */     //   73: iconst_1
/*     */     //   74: aload_3
/*     */     //   75: dup_x1
/*     */     //   76: dup_x2
/*     */     //   77: iconst_0
/*     */     //   78: aload_2
/*     */     //   79: iconst_2
/*     */     //   80: baload
/*     */     //   81: bastore
/*     */     //   82: aload_2
/*     */     //   83: iconst_3
/*     */     //   84: baload
/*     */     //   85: bastore
/*     */     //   86: invokestatic arrayToInteger : ([B)I
/*     */     //   89: iconst_4
/*     */     //   90: iadd
/*     */     //   91: dup
/*     */     //   92: istore #6
/*     */     //   94: iload #4
/*     */     //   96: irem
/*     */     //   97: istore #7
/*     */     //   99: iload #6
/*     */     //   101: newarray byte
/*     */     //   103: iconst_1
/*     */     //   104: dup
/*     */     //   105: pop2
/*     */     //   106: astore_3
/*     */     //   107: iload #6
/*     */     //   109: aload_2
/*     */     //   110: aload_3
/*     */     //   111: iconst_0
/*     */     //   112: dup_x1
/*     */     //   113: iload #4
/*     */     //   115: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   118: iload #4
/*     */     //   120: idiv
/*     */     //   121: istore #8
/*     */     //   123: iconst_1
/*     */     //   124: dup
/*     */     //   125: istore #9
/*     */     //   127: iload #8
/*     */     //   129: if_icmpge -> 165
/*     */     //   132: aload_0
/*     */     //   133: aload_1
/*     */     //   134: iload #9
/*     */     //   136: i2b
/*     */     //   137: iconst_0
/*     */     //   138: dup
/*     */     //   139: invokevirtual f : (Ljavax/smartcardio/CardChannel;BBB)[B
/*     */     //   142: dup
/*     */     //   143: astore_2
/*     */     //   144: iconst_0
/*     */     //   145: aload_3
/*     */     //   146: iload #9
/*     */     //   148: iload #4
/*     */     //   150: iinc #9, 1
/*     */     //   153: imul
/*     */     //   154: iload #4
/*     */     //   156: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   159: iload #9
/*     */     //   161: goto -> 127
/*     */     //   164: pop
/*     */     //   165: iload #7
/*     */     //   167: ifle -> 199
/*     */     //   170: aload_0
/*     */     //   171: aload_1
/*     */     //   172: iload #6
/*     */     //   174: iload #4
/*     */     //   176: idiv
/*     */     //   177: i2b
/*     */     //   178: iconst_0
/*     */     //   179: iload #7
/*     */     //   181: i2b
/*     */     //   182: invokevirtual f : (Ljavax/smartcardio/CardChannel;BBB)[B
/*     */     //   185: dup
/*     */     //   186: astore_2
/*     */     //   187: iconst_0
/*     */     //   188: aload_3
/*     */     //   189: iload #6
/*     */     //   191: iload #7
/*     */     //   193: isub
/*     */     //   194: iload #7
/*     */     //   196: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   199: iload #6
/*     */     //   201: iload #5
/*     */     //   203: isub
/*     */     //   204: newarray byte
/*     */     //   206: iconst_1
/*     */     //   207: dup
/*     */     //   208: pop2
/*     */     //   209: astore_1
/*     */     //   210: aload_3
/*     */     //   211: iload #5
/*     */     //   213: aload_1
/*     */     //   214: iconst_0
/*     */     //   215: iload #6
/*     */     //   217: iload #5
/*     */     //   219: isub
/*     */     //   220: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   223: aload_1
/*     */     //   224: areturn
/*     */     //   225: iconst_0
/*     */     //   226: astore #8
/*     */     //   228: new com/sltech/dpi/exception/DPIException
/*     */     //   231: dup
/*     */     //   232: aload #8
/*     */     //   234: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   237: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #95	-> 0
/*     */     //   #27	-> 7
/*     */     //   #139	-> 12
/*     */     //   #167	-> 16
/*     */     //   #44	-> 23
/*     */     //   #219	-> 29
/*     */     //   #138	-> 42
/*     */     //   #189	-> 56
/*     */     //   #213	-> 73
/*     */     //   #131	-> 82
/*     */     //   #207	-> 86
/*     */     //   #2	-> 94
/*     */     //   #128	-> 99
/*     */     //   #109	-> 109
/*     */     //   #174	-> 118
/*     */     //   #9	-> 123
/*     */     //   #110	-> 132
/*     */     //   #112	-> 144
/*     */     //   #9	-> 159
/*     */     //   #6	-> 165
/*     */     //   #49	-> 170
/*     */     //   #68	-> 187
/*     */     //   #215	-> 199
/*     */     //   #160	-> 210
/*     */     //   #30	-> 223
/*     */     //   #144	-> 226
/*     */     //   #113	-> 228
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	238	0	a	Lcom/sltech/dpi/impl/DpiV1Manager;
/*     */     //   0	238	1	a	Ljavax/smartcardio/CardChannel;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   29	224	226	javax/smartcardio/CardException }
/*     */ 
/*     */   
/*     */   public long readSerialNumber(CardChannel a) throws DPIException {
/*  98 */     byte b = 4;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     if (!f(a.transmit(C))) {
/*     */       throw new DPIException((new StringBuilder()).insert(0, i.f("*9\n$\n|\0029\0059\017\004=3O.\024p\0007\0064\b\023+l>\004#\0167\037\"\017V")).append(DataUtils.arrayToHex(A)).toString());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ResponseAPDU responseAPDU;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 228 */     if (!f(responseAPDU = a.transmit(g))) {
/*     */       throw new DPIException(CardUtils.f("#x\020a\r3\016nO)*C\0203\003fyVQ?#@\nmAL>F=[)K9?"));
/*     */     }
/*     */     byte[] arrayOfByte = responseAPDU.getBytes();
/*     */     true;
/*     */     boolean bool = true;
/*     */     System.arraycopy(arrayOfByte, 15, bool, 0, b);
/*     */     return DataUtils.convertSerialNumberToDecimal(DataUtils.arrayToHex(bool));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readMRZ(CardChannel a) throws DPIException { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: getstatic com/sltech/dpi/impl/DpiV1Manager.J : Ljavax/smartcardio/CommandAPDU;
/*     */     //   4: invokevirtual transmit : (Ljavax/smartcardio/CommandAPDU;)Ljavax/smartcardio/ResponseAPDU;
/*     */     //   7: invokestatic f : (Ljavax/smartcardio/ResponseAPDU;)Z
/*     */     //   10: ifne -> 27
/*     */     //   13: new com/sltech/dpi/exception/DPIException
/*     */     //   16: dup
/*     */     //   17: ldc_w '\\bx\\r|_~aE,%C3fyVQ?#@\\nmAL>F=[)K9?'
/*     */     //   20: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   23: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   26: athrow
/*     */     //   27: aload_0
/*     */     //   28: aload_1
/*     */     //   29: bipush #-127
/*     */     //   31: iconst_0
/*     */     //   32: bipush #93
/*     */     //   34: invokevirtual f : (Ljavax/smartcardio/CardChannel;BBB)[B
/*     */     //   37: astore_1
/*     */     //   38: new java/lang/StringBuilder
/*     */     //   41: dup
/*     */     //   42: invokespecial <init> : ()V
/*     */     //   45: astore_2
/*     */     //   46: iconst_5
/*     */     //   47: dup
/*     */     //   48: istore_3
/*     */     //   49: aload_1
/*     */     //   50: arraylength
/*     */     //   51: if_icmpge -> 75
/*     */     //   54: aload_2
/*     */     //   55: aload_1
/*     */     //   56: iload_3
/*     */     //   57: baload
/*     */     //   58: sipush #255
/*     */     //   61: iinc #3, 1
/*     */     //   64: iand
/*     */     //   65: i2c
/*     */     //   66: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   69: pop
/*     */     //   70: iload_3
/*     */     //   71: goto -> 49
/*     */     //   74: pop
/*     */     //   75: aload_2
/*     */     //   76: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   79: areturn
/*     */     //   80: iconst_0
/*     */     //   81: astore_1
/*     */     //   82: new com/sltech/dpi/exception/DPIException
/*     */     //   85: dup
/*     */     //   86: aload_1
/*     */     //   87: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   90: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #178	-> 0
/*     */     //   #133	-> 13
/*     */     //   #190	-> 27
/*     */     //   #75	-> 38
/*     */     //   #84	-> 46
/*     */     //   #209	-> 54
/*     */     //   #84	-> 69
/*     */     //   #106	-> 75
/*     */     //   #5	-> 81
/*     */     //   #31	-> 82
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	91	0	a	Lcom/sltech/dpi/impl/DpiV1Manager;
/*     */     //   0	91	1	a	Ljavax/smartcardio/CardChannel;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	79	81	javax/smartcardio/CardException }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DpiDataTO readGeneralData(CardChannel a) throws DPIException {
/*     */     try {
/*     */       if (!f(a.transmit(I))) {
/*     */         throw new DPIException(CardUtils.f("O\020|\020aCb@#/F\033|Fo5\025]=/O\000f\016-/R,Q5E0U"));
/*     */       }
/*     */       if (!f(a.transmit(i))) {
/*     */         throw new DPIException(i.f("*9\n$\n|\0029\0059\017\032\"|\n;D?\000&\0316\017:F<\036\034>\022=\025/"));
/*     */       }
/*     */       if (!f(a.transmit(B))) {
/*     */         throw new DPIException(CardUtils.f("O\020|\020aCb@#/F\033|Fo5\025]=/O\000f\016-/R,Q5E0U"));
/*     */       }
/*     */       ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*     */       byte[] arrayOfByte = f(a, (byte)0, (byte)0, (byte)-1);
/*     */       byteArrayOutputStream.write(DataUtils.rigthTrim(arrayOfByte));
/*     */       arrayOfByte = f(a, (byte)0, (byte)-1, (byte)-1);
/*     */       byteArrayOutputStream.write(DataUtils.rigthTrim(arrayOfByte));
/*     */       if (!f(a.transmit(e))) {
/*     */         throw new DPIException(i.f("*9\n$\n|\0029\0059\017\032\"|\n;D?\000&\0316\017:F<\036\034>\022=\025/"));
/*     */       }
/*     */       arrayOfByte = f(a, (byte)0, (byte)0, (byte)-1);
/*     */       byteArrayOutputStream.write(DataUtils.rigthTrim(arrayOfByte));
/*     */       arrayOfByte = f(a, (byte)0, (byte)-1, (byte)-1);
/*     */       byteArrayOutputStream.write(DataUtils.rigthTrim(arrayOfByte));
/*     */       return f(byteArrayOutputStream.toByteArray());
/*     */     } catch (CardException cardException) {
/*     */       while (true) {
/*     */         cardException = null;
/*     */         throw new DPIException(cardException);
/*     */       } 
/*     */     } catch (IOException iOException) {
/*     */       throw new DPIException(iOException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*     */     A = DataUtils.hexTextToByteArray(i.f("h[\037Yl[{H5\001\033YeV`SgUeR}N7\004"));
/*     */     D = DataUtils.hexTextToByteArray(CardUtils.f("[7>'V>\021}W:#>O#S?\021}|\020O\"V2i\005\016es\036^2'<^2X4Z5M!"));
/*     */     d = DataUtils.hexTextToByteArray(i.f("jY\024R`SgT`Q|N7\005"));
/*     */     j = DataUtils.hexTextToByteArray(CardUtils.f("r\036/6Q?^2X6Z7M "));
/*     */     l = DataUtils.hexTextToByteArray(i.f("jY\024R`QgT`Q}O7\006"));
/*     */     K = DataUtils.hexTextToByteArray(CardUtils.f("Y=-CQB]@OU"));
/*     */     M = DataUtils.hexTextToByteArray(i.f("5\006\031+f \026%gWe }OD\006"));
/*     */     J = new CommandAPDU(a);
/*     */     I = new CommandAPDU(H);
/*     */     C = new CommandAPDU(A);
/*     */     E = new CommandAPDU(D);
/*     */     i = new CommandAPDU(d);
/*     */     B = new CommandAPDU(j);
/*     */     e = new CommandAPDU(l);
/*     */     g = new CommandAPDU(K);
/*     */     f = new CommandAPDU(M);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readAllDataOld(CardChannel a) throws DPIException {
/* 403 */     return f(readAllData(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readGeneralDataOld(CardChannel a) throws DPIException {
/*     */     return f(readGeneralData(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<FingerType> readFingerPrintsEnrolled(CardChannel a) throws DPIException { // Byte code:
/*     */     //   0: new java/util/ArrayList
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore #4
/*     */     //   9: aload_1
/*     */     //   10: getstatic com/sltech/dpi/impl/DpiV1Manager.E : Ljavax/smartcardio/CommandAPDU;
/*     */     //   13: invokevirtual transmit : (Ljavax/smartcardio/CommandAPDU;)Ljavax/smartcardio/ResponseAPDU;
/*     */     //   16: invokestatic f : (Ljavax/smartcardio/ResponseAPDU;)Z
/*     */     //   19: ifne -> 36
/*     */     //   22: new com/sltech/dpi/exception/DPIException
/*     */     //   25: dup
/*     */     //   26: ldc_w '. 9X;%1\\r3m&Y :%9E63,*'
/*     */     //   29: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   32: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   35: athrow
/*     */     //   36: aload_1
/*     */     //   37: getstatic com/sltech/dpi/impl/DpiV1Manager.f : Ljavax/smartcardio/CommandAPDU;
/*     */     //   40: invokevirtual transmit : (Ljavax/smartcardio/CommandAPDU;)Ljavax/smartcardio/ResponseAPDU;
/*     */     //   43: dup
/*     */     //   44: astore_1
/*     */     //   45: invokestatic f : (Ljavax/smartcardio/ResponseAPDU;)Z
/*     */     //   48: ifne -> 65
/*     */     //   51: new com/sltech/dpi/exception/DPIException
/*     */     //   54: dup
/*     */     //   55: ldc_w 'O|aCb@#/F|Fo5]=/O f-/R,Q5E0U'
/*     */     //   58: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   61: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   64: athrow
/*     */     //   65: aload_1
/*     */     //   66: invokevirtual getBytes : ()[B
/*     */     //   69: dup
/*     */     //   70: astore_1
/*     */     //   71: arraylength
/*     */     //   72: iconst_1
/*     */     //   73: if_icmple -> 149
/*     */     //   76: aload_1
/*     */     //   77: dup
/*     */     //   78: iconst_1
/*     */     //   79: baload
/*     */     //   80: istore_2
/*     */     //   81: arraylength
/*     */     //   82: iload_2
/*     */     //   83: iconst_4
/*     */     //   84: iadd
/*     */     //   85: if_icmpne -> 135
/*     */     //   88: iconst_0
/*     */     //   89: dup
/*     */     //   90: istore #6
/*     */     //   92: iload_2
/*     */     //   93: if_icmpge -> 163
/*     */     //   96: aload_1
/*     */     //   97: iload #6
/*     */     //   99: iconst_2
/*     */     //   100: iadd
/*     */     //   101: baload
/*     */     //   102: dup
/*     */     //   103: istore #5
/*     */     //   105: invokestatic f : (B)Lcom/sltech/dpi/smartcard/FingerType;
/*     */     //   108: dup
/*     */     //   109: astore_3
/*     */     //   110: ifnull -> 122
/*     */     //   113: aload #4
/*     */     //   115: aload_3
/*     */     //   116: invokeinterface add : (Ljava/lang/Object;)Z
/*     */     //   121: pop
/*     */     //   122: iinc #6, 1
/*     */     //   125: iload #6
/*     */     //   127: goto -> 92
/*     */     //   130: pop
/*     */     //   131: goto -> 163
/*     */     //   134: iconst_0
/*     */     //   135: new com/sltech/dpi/exception/DPIException
/*     */     //   138: dup
/*     */     //   139: ldc_w '<K1+$w8M>?z9$%\\n(jo4-v:8=9@'
/*     */     //   142: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   145: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   148: athrow
/*     */     //   149: new com/sltech/dpi/exception/DPIException
/*     */     //   152: dup
/*     */     //   153: ldc_w '9v& e\\tlU%Kh3oR=\\tdk_anE$%@_ud>PL"0G v-lkc?'
/*     */     //   156: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   159: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   162: athrow
/*     */     //   163: aload #4
/*     */     //   165: areturn
/*     */     //   166: astore #5
/*     */     //   168: new com/sltech/dpi/exception/DPIException
/*     */     //   171: dup
/*     */     //   172: aload #5
/*     */     //   174: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   177: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #385	-> 0
/*     */     //   #428	-> 9
/*     */     //   #303	-> 22
/*     */     //   #386	-> 36
/*     */     //   #491	-> 45
/*     */     //   #388	-> 51
/*     */     //   #344	-> 65
/*     */     //   #325	-> 71
/*     */     //   #549	-> 76
/*     */     //   #394	-> 81
/*     */     //   #249	-> 88
/*     */     //   #557	-> 96
/*     */     //   #481	-> 105
/*     */     //   #426	-> 110
/*     */     //   #532	-> 113
/*     */     //   #249	-> 122
/*     */     //   #231	-> 135
/*     */     //   #480	-> 149
/*     */     //   #524	-> 163
/*     */     //   #310	-> 166
/*     */     //   #443	-> 168
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	178	0	a	Lcom/sltech/dpi/impl/DpiV1Manager;
/*     */     //   0	178	1	a	Ljavax/smartcardio/CardChannel;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   9	165	166	javax/smartcardio/CardException }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DpiDataTO readAllData(CardChannel a) throws DPIException {
/* 448 */     DpiDataTO dpiDataTO = readGeneralData(a);
/*     */     dpiDataTO.setMachineReadableZone(readMRZ(a));
/*     */     dpiDataTO.setFoto(readPhoto(a));
/*     */     dpiDataTO.setSerialNumber(String.valueOf(readSerialNumber(a)));
/*     */     dpiDataTO.setFingerPrints(readFingerPrintsEnrolled(a));
/*     */     return dpiDataTO;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/impl/DpiV1Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */