/*     */ package com.n.n;
/*     */ 
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import com.sltech.dpi.util.CardUtils;
/*     */ import com.sltech.dpi.util.CheckDigit;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public class I {
/*     */   public i f(byte[] a, int a, int a) {
/*  10 */     ArrayList<a> arrayList = new ArrayList();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     if (a == 0) {
/*     */       return new i(arrayList);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 127 */       int i = a;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       byte b;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 195 */       if ((b = 0) >= 100) {
/*     */         return new i(arrayList);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       for (;; b++, i = com/n/n/D.f(com/n/n/D)) {
/* 205 */         com/n/n/D com/n/n/D = f(0, a, i, a - i);
/*     */         arrayList.add(com/n/n/D.f(com/n/n/D));
/*     */         if (com/n/n/D.f(com/n/n/D) >= a + a) {
/*     */           return new i(arrayList);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final e E = new d();
/*     */ 
/*     */   
/*     */   private final e K;
/*     */ 
/*     */   
/*     */   public a f(byte[] a, int a, int a) {
/*     */     return com/n/n/D.f(f(0, a, a, a));
/*     */   }
/*     */ 
/*     */   
/* 227 */   public I() { this(E); }
/*     */   
/*     */   public i f(byte[] a) { return f(a, 0, a.length); }
/*     */   
/*     */   public I(e a) {
/*     */     this.K = a;
/*     */   }
/*     */   
/*     */   private static class com/n/n/D {
/*     */     private final int E;
/*     */     private final a K;
/*     */     
/*     */     public com/n/n/D(a a, int a) {
/*     */       this.K = a;
/*     */       this.E = a;
/*     */     }
/*     */     
/*     */     public String toString() { return (new StringBuilder()).insert(0, DPIException.f("m3M#\031AY \tH(\b`D")).append(this.K).append(DPIException.f("\\|Z5\017vbD")).append(this.E).append('}').toString(); }
/*     */   }
/*     */   
/*     */   public a f(byte[] a) { return f(a, 0, a.length); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/n/n/I.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */