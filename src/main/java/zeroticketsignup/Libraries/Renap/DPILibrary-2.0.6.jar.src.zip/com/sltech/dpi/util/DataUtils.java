/*     */ package com.sltech.dpi.util;
/*     */ public class DataUtils { private static final SimpleDateFormat j;
/*     */   private static final String[] E;
/*     */   private static final SimpleDateFormat K;
/*     */   
/*     */   public static String arrayToAscii(byte[] a) { // Byte code:
/*     */     //   0: new java/lang/StringBuilder
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_1
/*     */     //   8: iconst_0
/*     */     //   9: dup
/*     */     //   10: istore_2
/*     */     //   11: aload_0
/*     */     //   12: arraylength
/*     */     //   13: if_icmpge -> 37
/*     */     //   16: aload_1
/*     */     //   17: aload_0
/*     */     //   18: iload_2
/*     */     //   19: baload
/*     */     //   20: sipush #255
/*     */     //   23: iinc #2, 1
/*     */     //   26: iand
/*     */     //   27: i2c
/*     */     //   28: invokevirtual append : (C)Ljava/lang/StringBuilder;
/*     */     //   31: pop
/*     */     //   32: iload_2
/*     */     //   33: goto -> 11
/*     */     //   36: pop
/*     */     //   37: aload_1
/*     */     //   38: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   41: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #13	-> 0
/*     */     //   #8	-> 8
/*     */     //   #115	-> 16
/*     */     //   #8	-> 31
/*     */     //   #186	-> 37
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	42	0	a	[B }
/*     */   
/*     */   public static String arrayToHex(byte[] a) { // Byte code:
/*     */     //   0: new java/lang/StringBuilder
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_2
/*     */     //   8: iconst_0
/*     */     //   9: dup
/*     */     //   10: istore_3
/*     */     //   11: aload_0
/*     */     //   12: arraylength
/*     */     //   13: if_icmpge -> 66
/*     */     //   16: aload_0
/*     */     //   17: iload_3
/*     */     //   18: baload
/*     */     //   19: sipush #255
/*     */     //   22: iand
/*     */     //   23: invokestatic toHexString : (I)Ljava/lang/String;
/*     */     //   26: invokevirtual toUpperCase : ()Ljava/lang/String;
/*     */     //   29: dup
/*     */     //   30: astore_1
/*     */     //   31: invokevirtual length : ()I
/*     */     //   34: iconst_1
/*     */     //   35: if_icmpne -> 44
/*     */     //   38: aload_2
/*     */     //   39: iconst_0
/*     */     //   40: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   43: pop
/*     */     //   44: aload_2
/*     */     //   45: aload_1
/*     */     //   46: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   49: iinc #3, 1
/*     */     //   52: ldc 'R'
/*     */     //   54: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   60: pop
/*     */     //   61: iload_3
/*     */     //   62: goto -> 11
/*     */     //   65: pop
/*     */     //   66: aload_2
/*     */     //   67: iconst_0
/*     */     //   68: aload_2
/*     */     //   69: invokevirtual length : ()I
/*     */     //   72: iconst_1
/*     */     //   73: isub
/*     */     //   74: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   77: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #21	-> 0
/*     */     //   #79	-> 8
/*     */     //   #74	-> 16
/*     */     //   #227	-> 31
/*     */     //   #103	-> 38
/*     */     //   #225	-> 44
/*     */     //   #79	-> 60
/*     */     //   #163	-> 66
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	78	0	a	[B }
/*     */   
/*     */   public static String arrayToHexText(byte[] a) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ifnonnull -> 7
/*     */     //   4: aconst_null
/*     */     //   5: areturn
/*     */     //   6: pop
/*     */     //   7: new java/lang/StringBuilder
/*     */     //   10: dup
/*     */     //   11: invokespecial <init> : ()V
/*     */     //   14: astore_2
/*     */     //   15: iconst_0
/*     */     //   16: dup
/*     */     //   17: istore_3
/*     */     //   18: aload_0
/*     */     //   19: arraylength
/*     */     //   20: if_icmpge -> 83
/*     */     //   23: aload_0
/*     */     //   24: iload_3
/*     */     //   25: baload
/*     */     //   26: sipush #255
/*     */     //   29: iand
/*     */     //   30: invokestatic toHexString : (I)Ljava/lang/String;
/*     */     //   33: invokevirtual toUpperCase : ()Ljava/lang/String;
/*     */     //   36: dup
/*     */     //   37: astore_1
/*     */     //   38: invokevirtual length : ()I
/*     */     //   41: iconst_1
/*     */     //   42: if_icmpne -> 69
/*     */     //   45: aload_2
/*     */     //   46: ldc ' '
/*     */     //   48: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   51: sipush #21599
/*     */     //   54: sipush #9435
/*     */     //   57: sipush #763
/*     */     //   60: sipush #29151
/*     */     //   63: pop2
/*     */     //   64: pop2
/*     */     //   65: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   68: pop
/*     */     //   69: aload_2
/*     */     //   70: iinc #3, 1
/*     */     //   73: aload_1
/*     */     //   74: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   77: pop
/*     */     //   78: iload_3
/*     */     //   79: goto -> 18
/*     */     //   82: iconst_0
/*     */     //   83: aload_2
/*     */     //   84: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   87: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #32	-> 0
/*     */     //   #127	-> 4
/*     */     //   #195	-> 7
/*     */     //   #221	-> 15
/*     */     //   #205	-> 23
/*     */     //   #69	-> 38
/*     */     //   #11	-> 45
/*     */     //   #155	-> 69
/*     */     //   #221	-> 77
/*     */     //   #193	-> 83
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	88	0	a	[B }
/*     */   
/*     */   static  {
/*     */     true;
/*     */     true[0] = i.f(";Iq");
/*     */     true[1] = CardUtils.f("I9R");
/*     */     true[2] = i.f("3Ff");
/*     */     true[3] = CardUtils.f("N>B");
/*     */     true[4] = i.f("3Fm");
/*     */     true[5] = CardUtils.f("E)^");
/*     */     true[6] = i.f("4Rx");
/*     */     true[7] = CardUtils.f("N;_");
/*     */     true[8] = i.f("-Bd");
/*     */     true[9] = CardUtils.f("@?D");
/*     */     true[10] = i.f("0Hb");
/*     */     true[11] = CardUtils.f("K9S");
/*     */     E = true;
/*     */     K = new SimpleDateFormat(i.f("4\007x)\035L4\007~M"));
/*     */     j = new SimpleDateFormat(CardUtils.f("\037s.B\030t"));
/*     */   }
/*     */   
/*     */   public static String convertDpiDateForBAC(String a) throws DPIException { return convertDpiDateForBAC(convertDpiDate(a)); }
/*     */   
/*     */   public static String convertDpiDateForBAC(Date a) { return j.format(a); }
/*     */   
/*     */   public static int arrayToInteger(byte[] a) {
/*     */     String str;
/*     */     return Integer.valueOf(str = (str = arrayToHex(a)).replace(i.f("X"), ""), 16).intValue();
/*     */   }
/*     */   
/*  40 */   public static Date convertDpiDate(String a) throws DPIException { if (a == null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 171 */       return null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 228 */       if (a.length() == 9) {
/*     */         String str1 = a.substring(2, 5); int i = Arrays.asList(E).indexOf(str1) + 1; true; true[0] = Integer.valueOf(i);
/*     */         String str2 = i.f("hNn\013").append(String.format((String)new Object[1], true)).append(CardUtils.f("?")).append(a.substring(5, 9)).toString();
/*     */       } 
/*     */       continue;
/*     */       while (true) {
/*     */         String str;
/*     */         if (a.length() == 10) {
/*     */           str = a;
/*     */         } else {
/*     */           throw new DPIException((new StringBuilder()).insert(0, i.f("4 ?\033<\n\031n<\n9\033fO")).append(a).append(CardUtils.f("zY\0257\005b\nR0")).toString());
/*     */         } 
/*     */         try {
/*     */           return K.parse(str);
/*     */         } catch (ParseException parseException) {
/*     */           throw new DPIException((new StringBuilder()).insert(0, i.f("4 ?\033<\n\031n<\n9\033fO")).append(str).append(CardUtils.f("zY\0257\005b\nR0")).toString(), parseException);
/*     */         } 
/*     */       } 
/*     */       throw new DPIException((new StringBuilder()).insert(0, i.f("4 ?\033<\n\031n<\n9\033fO")).append(a).append(CardUtils.f("zY\0257\005b\nR0")).toString());
/*     */     } 
/*     */     continue; } public static byte[] hexTextToByteArray(String a) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: ifnonnull -> 7
/*     */     //   4: aconst_null
/*     */     //   5: areturn
/*     */     //   6: pop
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual length : ()I
/*     */     //   11: dup
/*     */     //   12: istore_1
/*     */     //   13: iconst_2
/*     */     //   14: idiv
/*     */     //   15: newarray byte
/*     */     //   17: iconst_1
/*     */     //   18: dup
/*     */     //   19: pop2
/*     */     //   20: astore_2
/*     */     //   21: iconst_0
/*     */     //   22: dup
/*     */     //   23: istore_3
/*     */     //   24: iload_1
/*     */     //   25: if_icmpge -> 67
/*     */     //   28: aload_2
/*     */     //   29: iload_3
/*     */     //   30: iconst_2
/*     */     //   31: idiv
/*     */     //   32: aload_0
/*     */     //   33: iload_3
/*     */     //   34: invokevirtual charAt : (I)C
/*     */     //   37: bipush #16
/*     */     //   39: invokestatic digit : (CI)I
/*     */     //   42: iconst_4
/*     */     //   43: ishl
/*     */     //   44: aload_0
/*     */     //   45: iload_3
/*     */     //   46: iconst_1
/*     */     //   47: iadd
/*     */     //   48: invokevirtual charAt : (I)C
/*     */     //   51: bipush #16
/*     */     //   53: invokestatic digit : (CI)I
/*     */     //   56: iadd
/*     */     //   57: i2b
/*     */     //   58: iinc #3, 2
/*     */     //   61: bastore
/*     */     //   62: iload_3
/*     */     //   63: goto -> 24
/*     */     //   66: iconst_0
/*     */     //   67: aload_2
/*     */     //   68: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #182	-> 0
/*     */     //   #153	-> 4
/*     */     //   #183	-> 7
/*     */     //   #28	-> 13
/*     */     //   #184	-> 21
/*     */     //   #202	-> 28
/*     */     //   #184	-> 62
/*     */     //   #214	-> 67
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/* 248 */     //   0	69	0	a	Ljava/lang/String; } public static String BCDToString(int a) { byte b1 = (byte)((b1 = (byte)((
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 304 */       b1 = (byte)(a & 0xF0)) >>> 4)) & 0xF);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     byte b2 = (byte)(a & 0xF);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     (new StringBuilder()).append(b1).append(b2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 508 */     return (new StringBuilder()).toString(); } public static Date adjustExpirationDate(String a, String a) throws DPIException { if (a == null)
/*     */       return null;  while (true) {
/*     */       if (a.equalsIgnoreCase(CardUtils.f("\023x?R C-F8_"))) {
/*     */         Date date1 = convertDpiDate(a); Calendar calendar = Calendar.getInstance(); calendar.setTime(date1); calendar.add(1, 10); calendar.add(5, -1); Date date2; return date2 = calendar.getTime();
/*     */       } 
/*     */       while (true) {
/*     */         Date date;
/*     */         return date = convertDpiDate(a);
/*     */       } 
/*     */     } 
/*     */     while (true) {
/*     */       Date date;
/*     */       return date = convertDpiDate(a);
/*     */     }  }
/* 522 */   public static int convertToInt(int a, int a) { return (a & 0xFF) << 8 | a & 0xFF; }
/*     */   
/*     */   public static long convertSerialNumberToDecimal(String a) { return Long.parseLong(a = a.replace(CardUtils.f("0"), ""), 16); }
/*     */   
/*     */   public static String BCDToStringDPIV2(byte[] a) { // Byte code:
/*     */     //   0: new java/lang/StringBuilder
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_1
/*     */     //   8: iconst_0
/*     */     //   9: dup
/*     */     //   10: istore_2
/*     */     //   11: aload_0
/*     */     //   12: arraylength
/*     */     //   13: if_icmpge -> 35
/*     */     //   16: aload_1
/*     */     //   17: aload_0
/*     */     //   18: iload_2
/*     */     //   19: iinc #2, 1
/*     */     //   22: baload
/*     */     //   23: invokestatic BCDToString : (B)Ljava/lang/String;
/*     */     //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   29: pop
/*     */     //   30: iload_2
/*     */     //   31: goto -> 11
/*     */     //   34: pop
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   39: iconst_0
/*     */     //   40: aload_1
/*     */     //   41: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   44: invokevirtual length : ()I
/*     */     //   47: iconst_1
/*     */     //   48: isub
/*     */     //   49: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   52: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #271	-> 0
/*     */     //   #372	-> 8
/*     */     //   #327	-> 16
/*     */     //   #372	-> 29
/*     */     //   #520	-> 35
/*     */     //   #367	-> 52
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	53	0	a	[B }
/*     */   
/*     */   public static String BCDToString(byte[] a) { // Byte code:
/*     */     //   0: new java/lang/StringBuilder
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_1
/*     */     //   8: iconst_0
/*     */     //   9: dup
/*     */     //   10: istore_2
/*     */     //   11: aload_0
/*     */     //   12: arraylength
/*     */     //   13: if_icmpge -> 35
/*     */     //   16: aload_1
/*     */     //   17: aload_0
/*     */     //   18: iload_2
/*     */     //   19: iinc #2, 1
/*     */     //   22: baload
/*     */     //   23: invokestatic BCDToString : (B)Ljava/lang/String;
/*     */     //   26: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   29: pop
/*     */     //   30: iload_2
/*     */     //   31: goto -> 11
/*     */     //   34: pop
/*     */     //   35: aload_1
/*     */     //   36: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   39: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #292	-> 0
/*     */     //   #500	-> 8
/*     */     //   #362	-> 16
/*     */     //   #500	-> 29
/*     */     //   #268	-> 35
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	40	0	a	[B }
/*     */   
/*     */   public static byte[] rigthTrim(byte[] a) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: arraylength
/*     */     //   2: iconst_1
/*     */     //   3: isub
/*     */     //   4: dup
/*     */     //   5: istore_1
/*     */     //   6: iflt -> 23
/*     */     //   9: aload_0
/*     */     //   10: iload_1
/*     */     //   11: baload
/*     */     //   12: ifne -> 23
/*     */     //   15: iinc #1, -1
/*     */     //   18: iload_1
/*     */     //   19: goto -> 6
/*     */     //   22: pop
/*     */     //   23: aload_0
/*     */     //   24: iload_1
/*     */     //   25: iconst_1
/*     */     //   26: iadd
/*     */     //   27: invokestatic copyOf : ([BI)[B
/*     */     //   30: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #301	-> 0
/*     */     //   #527	-> 6
/*     */     //   #467	-> 15
/*     */     //   #295	-> 23
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	31	0	a	[B }
/*     */   
/*     */   public static String[] splitNames(String a, String a) { // Byte code:
/*     */     //   0: iconst_3
/*     */     //   1: anewarray java/lang/String
/*     */     //   4: iconst_1
/*     */     //   5: dup
/*     */     //   6: pop2
/*     */     //   7: dup
/*     */     //   8: iconst_0
/*     */     //   9: ldc ''
/*     */     //   11: aastore
/*     */     //   12: dup
/*     */     //   13: iconst_1
/*     */     //   14: ldc ''
/*     */     //   16: aastore
/*     */     //   17: dup
/*     */     //   18: iconst_2
/*     */     //   19: ldc ''
/*     */     //   21: aastore
/*     */     //   22: astore_2
/*     */     //   23: new java/lang/StringBuilder
/*     */     //   26: dup
/*     */     //   27: invokespecial <init> : ()V
/*     */     //   30: iconst_0
/*     */     //   31: aload_0
/*     */     //   32: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   35: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   38: ldc 'Y'
/*     */     //   40: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   43: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   46: aload_1
/*     */     //   47: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   53: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   56: ldc '0'
/*     */     //   58: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   61: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
/*     */     //   64: dup
/*     */     //   65: astore_1
/*     */     //   66: arraylength
/*     */     //   67: ifle -> 76
/*     */     //   70: aload_2
/*     */     //   71: aload_1
/*     */     //   72: iconst_0
/*     */     //   73: dup_x1
/*     */     //   74: aaload
/*     */     //   75: aastore
/*     */     //   76: aload_1
/*     */     //   77: arraylength
/*     */     //   78: iconst_1
/*     */     //   79: if_icmple -> 88
/*     */     //   82: aload_2
/*     */     //   83: aload_1
/*     */     //   84: iconst_1
/*     */     //   85: dup_x1
/*     */     //   86: aaload
/*     */     //   87: aastore
/*     */     //   88: aload_1
/*     */     //   89: arraylength
/*     */     //   90: iconst_2
/*     */     //   91: if_icmple -> 153
/*     */     //   94: ldc ''
/*     */     //   96: astore_3
/*     */     //   97: iconst_2
/*     */     //   98: dup
/*     */     //   99: istore #4
/*     */     //   101: aload_1
/*     */     //   102: arraylength
/*     */     //   103: if_icmpge -> 146
/*     */     //   106: new java/lang/StringBuilder
/*     */     //   109: dup
/*     */     //   110: invokespecial <init> : ()V
/*     */     //   113: iconst_0
/*     */     //   114: aload_3
/*     */     //   115: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   118: aload_1
/*     */     //   119: iload #4
/*     */     //   121: aaload
/*     */     //   122: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   125: ldc 'Y'
/*     */     //   127: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   130: iinc #4, 1
/*     */     //   133: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   136: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   139: astore_3
/*     */     //   140: iload #4
/*     */     //   142: goto -> 101
/*     */     //   145: pop
/*     */     //   146: aload_2
/*     */     //   147: iconst_2
/*     */     //   148: aload_3
/*     */     //   149: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   152: aastore
/*     */     //   153: aload_2
/*     */     //   154: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #388	-> 0
/*     */     //   #289	-> 23
/*     */     //   #324	-> 56
/*     */     //   #325	-> 66
/*     */     //   #549	-> 70
/*     */     //   #484	-> 76
/*     */     //   #249	-> 82
/*     */     //   #481	-> 88
/*     */     //   #426	-> 94
/*     */     //   #532	-> 97
/*     */     //   #232	-> 106
/*     */     //   #532	-> 140
/*     */     //   #390	-> 146
/*     */     //   #320	-> 153
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	155	0	a	Ljava/lang/String;
/*     */     //   0	155	1	a	Ljava/lang/String; }
/*     */   
/*     */   public static String[] convertTwoLines(String a, String a, String a) { // Byte code:
/*     */     //   0: iconst_2
/*     */     //   1: anewarray java/lang/String
/*     */     //   4: iconst_1
/*     */     //   5: dup
/*     */     //   6: pop2
/*     */     //   7: astore_3
/*     */     //   8: aload_0
/*     */     //   9: ldc ''
/*     */     //   11: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   14: astore #4
/*     */     //   16: aload_1
/*     */     //   17: ldc ''
/*     */     //   19: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   22: astore_1
/*     */     //   23: aload_2
/*     */     //   24: ldc ''
/*     */     //   26: invokestatic f : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
/*     */     //   29: astore_2
/*     */     //   30: iconst_1
/*     */     //   31: aload_3
/*     */     //   32: dup_x1
/*     */     //   33: aload_3
/*     */     //   34: iconst_0
/*     */     //   35: aload #4
/*     */     //   37: aastore
/*     */     //   38: new java/lang/StringBuilder
/*     */     //   41: iconst_1
/*     */     //   42: dup_x1
/*     */     //   43: dup
/*     */     //   44: pop2
/*     */     //   45: dup
/*     */     //   46: invokespecial <init> : ()V
/*     */     //   49: aload_1
/*     */     //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   53: ldc 'Y'
/*     */     //   55: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   58: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   61: aload_2
/*     */     //   62: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   65: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   68: aastore
/*     */     //   69: aaload
/*     */     //   70: invokevirtual length : ()I
/*     */     //   73: bipush #25
/*     */     //   75: if_icmple -> 122
/*     */     //   78: aload_2
/*     */     //   79: ldc ''
/*     */     //   81: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   84: ifne -> 122
/*     */     //   87: iconst_1
/*     */     //   88: aload_3
/*     */     //   89: dup_x1
/*     */     //   90: new java/lang/StringBuilder
/*     */     //   93: dup
/*     */     //   94: invokespecial <init> : ()V
/*     */     //   97: iconst_0
/*     */     //   98: dup_x1
/*     */     //   99: aload #4
/*     */     //   101: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   104: ldc '0'
/*     */     //   106: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   112: aload_1
/*     */     //   113: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   116: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   119: aastore
/*     */     //   120: aload_2
/*     */     //   121: aastore
/*     */     //   122: aload_3
/*     */     //   123: iconst_1
/*     */     //   124: iconst_0
/*     */     //   125: aload_3
/*     */     //   126: dup_x1
/*     */     //   127: iconst_0
/*     */     //   128: aaload
/*     */     //   129: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   132: aastore
/*     */     //   133: aload_3
/*     */     //   134: dup_x1
/*     */     //   135: iconst_1
/*     */     //   136: aaload
/*     */     //   137: invokevirtual trim : ()Ljava/lang/String;
/*     */     //   140: aastore
/*     */     //   141: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #403	-> 0
/*     */     //   #538	-> 8
/*     */     //   #523	-> 16
/*     */     //   #305	-> 23
/*     */     //   #281	-> 30
/*     */     //   #331	-> 38
/*     */     //   #449	-> 69
/*     */     //   #486	-> 87
/*     */     //   #284	-> 120
/*     */     //   #262	-> 122
/*     */     //   #286	-> 133
/*     */     //   #430	-> 141
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	142	0	a	Ljava/lang/String;
/*     */     //   0	142	1	a	Ljava/lang/String;
/*     */     //   0	142	2	a	Ljava/lang/String; }
/*     */   
/*     */   public static String arrayToHexNoSpacin(byte[] a) { // Byte code:
/*     */     //   0: new java/lang/StringBuilder
/*     */     //   3: dup
/*     */     //   4: invokespecial <init> : ()V
/*     */     //   7: astore_2
/*     */     //   8: iconst_0
/*     */     //   9: dup
/*     */     //   10: istore_3
/*     */     //   11: aload_0
/*     */     //   12: arraylength
/*     */     //   13: if_icmpge -> 58
/*     */     //   16: aload_0
/*     */     //   17: iload_3
/*     */     //   18: baload
/*     */     //   19: sipush #255
/*     */     //   22: iand
/*     */     //   23: invokestatic toHexString : (I)Ljava/lang/String;
/*     */     //   26: invokevirtual toUpperCase : ()Ljava/lang/String;
/*     */     //   29: dup
/*     */     //   30: astore_1
/*     */     //   31: invokevirtual length : ()I
/*     */     //   34: iconst_1
/*     */     //   35: if_icmpne -> 44
/*     */     //   38: aload_2
/*     */     //   39: iconst_0
/*     */     //   40: invokevirtual append : (I)Ljava/lang/StringBuilder;
/*     */     //   43: pop
/*     */     //   44: aload_2
/*     */     //   45: iinc #3, 1
/*     */     //   48: aload_1
/*     */     //   49: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   52: pop
/*     */     //   53: iload_3
/*     */     //   54: goto -> 11
/*     */     //   57: pop
/*     */     //   58: aload_2
/*     */     //   59: iconst_0
/*     */     //   60: aload_2
/*     */     //   61: invokevirtual length : ()I
/*     */     //   64: iconst_1
/*     */     //   65: isub
/*     */     //   66: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   69: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #0	-> 0
/*     */     //   #150	-> 8
/*     */     //   #87	-> 16
/*     */     //   #67	-> 31
/*     */     //   #15	-> 38
/*     */     //   #101	-> 44
/*     */     //   #150	-> 52
/*     */     //   #154	-> 58
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	70	0	a	[B } }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/util/DataUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */