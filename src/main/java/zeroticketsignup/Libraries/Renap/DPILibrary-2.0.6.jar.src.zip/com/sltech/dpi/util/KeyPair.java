/*     */ package com.sltech.dpi.util;
/*     */ public class KeyPair {
/*     */   private byte[] a;
/*     */   private byte[] j;
/*     */   private byte[] E;
/*     */   private byte[] K;
/*     */   
/*   8 */   public void setEncKey(byte[] a) { this.j = a; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public KeyPair(String a, String a, String a) {
/*  15 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  64 */       .K = DataUtils.hexTextToByteArray(a);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     this.j = DataUtils.hexTextToByteArray(a);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 141 */     this.a = DataUtils.hexTextToByteArray(a);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object a) { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: ifnonnull -> 7
/*     */     //   4: iconst_0
/*     */     //   5: ireturn
/*     */     //   6: pop
/*     */     //   7: aload_0
/*     */     //   8: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   11: aload_1
/*     */     //   12: invokevirtual getClass : ()Ljava/lang/Class;
/*     */     //   15: if_acmpeq -> 21
/*     */     //   18: iconst_0
/*     */     //   19: ireturn
/*     */     //   20: iconst_0
/*     */     //   21: aload_1
/*     */     //   22: checkcast com/sltech/dpi/util/KeyPair
/*     */     //   25: astore_1
/*     */     //   26: aload_0
/*     */     //   27: getfield j : [B
/*     */     //   30: aload_1
/*     */     //   31: getfield j : [B
/*     */     //   34: invokestatic equals : ([B[B)Z
/*     */     //   37: ifne -> 42
/*     */     //   40: iconst_0
/*     */     //   41: ireturn
/*     */     //   42: aload_0
/*     */     //   43: getfield a : [B
/*     */     //   46: aload_1
/*     */     //   47: getfield a : [B
/*     */     //   50: invokestatic equals : ([B[B)Z
/*     */     //   53: ifne -> 58
/*     */     //   56: iconst_0
/*     */     //   57: ireturn
/*     */     //   58: aload_0
/*     */     //   59: getfield K : [B
/*     */     //   62: aload_1
/*     */     //   63: getfield K : [B
/*     */     //   66: invokestatic equals : ([B[B)Z
/*     */     //   69: ifne -> 74
/*     */     //   72: iconst_0
/*     */     //   73: ireturn
/*     */     //   74: aload_0
/*     */     //   75: getfield E : [B
/*     */     //   78: aload_1
/*     */     //   79: getfield E : [B
/*     */     //   82: invokestatic equals : ([B[B)Z
/*     */     //   85: ifne -> 90
/*     */     //   88: iconst_0
/*     */     //   89: ireturn
/*     */     //   90: iconst_1
/*     */     //   91: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #35	-> 0
/*     */     //   #200	-> 4
/*     */     //   #145	-> 7
/*     */     //   #122	-> 18
/*     */     //   #139	-> 21
/*     */     //   #97	-> 26
/*     */     //   #167	-> 40
/*     */     //   #58	-> 42
/*     */     //   #136	-> 56
/*     */     //   #23	-> 58
/*     */     //   #60	-> 72
/*     */     //   #138	-> 74
/*     */     //   #91	-> 88
/*     */     //   #189	-> 90
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	92	0	a	Lcom/sltech/dpi/util/KeyPair;
/*     */     //   0	92	1	a	Ljava/lang/Object; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/*     */     int i = 7;
/*     */     i = 11 * i + Arrays.hashCode(this.j);
/*     */     i = 11 * i + Arrays.hashCode(this.a);
/* 187 */     i = 11 * i + Arrays.hashCode(this.K);
/*     */     return i = 11 * i + Arrays.hashCode(this.E);
/*     */   }
/*     */   public byte[] getEncKey() { return this.j; }
/*     */   public KeyPair(String a, String a, String a, String a) {
/*     */     this.j = DataUtils.hexTextToByteArray(a);
/*     */     this.a = DataUtils.hexTextToByteArray(a);
/*     */     this.K = DataUtils.hexTextToByteArray(a);
/*     */     this.E = DataUtils.hexTextToByteArray(a);
/*     */   }
/*     */   
/*     */   public byte[] getSeed() { return this.K; }
/*     */   
/*     */   public byte[] getSsc() { return this.E; }
/*     */   
/*     */   public void setSeed(byte[] a) { -30843;
/*     */     -24650;
/*     */     this.K = (byte[])SYNTHETIC_LOCAL_VARIABLE_1; }
/*     */   
/*     */   public String toStringDebug() { StringBuilder stringBuilder = new StringBuilder();
/* 207 */     String str = System.getProperty(i.f(";\r0\bS=9\037:\032-\0131\037")); if (this.K != null) { stringBuilder.append(CheckDigit.f("bMC[\016\r")).append(DataUtils.arrayToHexText(this.K)).append(i.f("rM")); '◳'; -14164; }
/* 208 */      if (this.j != null)
/*     */       stringBuilder.append(CheckDigit.f("Kxl\021cCF\016\r")).append(DataUtils.arrayToHexText(this.j)).append(i.f("rM"));  if (this.a != null)
/*     */       stringBuilder.append(CheckDigit.f("Cwl\021cCF\016\r")).append(DataUtils.arrayToHexText(this.a)).append(i.f("rM")); 
/*     */     if (this.E != null)
/*     */       stringBuilder.append(CheckDigit.f("{u|\016\r")).append(DataUtils.arrayToHexText(this.E)); 
/*     */     return stringBuilder.toString(); } public KeyPair(byte[] a, byte[] a, byte[] a, byte[] a) { this.j = a;
/*     */     this.a = a;
/*     */     this.K = a;
/* 216 */     this.E = a; }
/*     */ 
/*     */   
/*     */   public void setMacKey(byte[] a) { this.a = a; }
/*     */   
/*     */   public void setSsc(byte[] a) { this.E = a; }
/*     */   
/*     */   public KeyPair(byte[] a, byte[] a, byte[] a) {
/*     */     this.K = a;
/*     */     this.j = a;
/*     */     this.a = a;
/*     */   }
/*     */   
/*     */   public byte[] getMacKey() { return this.a; }
/*     */   
/*     */   public KeyPair() {}
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/util/KeyPair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */