/*    */ package com.sltech.dpi.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckDigit
/*    */ {
/*    */   public static String f(String a) {
/*    */     1.0F;
/*    */     true;
/*    */     int i = new char[a.length()] - 1;
/*    */     boolean bool = true;
/*    */     int m = a.length();
/*    */     new char[a.length()] - 1;
/*    */     int j = 5 << 4 ^ 0x3;
/*    */     4 << 4 ^ 5 << 1;
/*    */     4;
/*    */     float f1 = 2.0F;
/*    */     float f2 = f1;
/*    */     int k = ((new CloneNotSupportedException()).getStackTrace()[1].getClassName() + (new CloneNotSupportedException()).getStackTrace()[1].getMethodName()).length() - 1;
/*    */   }
/*    */   
/*    */   public static int getCheckDigitICAO(String a) { // Byte code:
/*    */     //   0: iconst_3
/*    */     //   1: newarray int
/*    */     //   3: iconst_1
/*    */     //   4: dup
/*    */     //   5: pop2
/*    */     //   6: dup
/*    */     //   7: iconst_0
/*    */     //   8: bipush #7
/*    */     //   10: iastore
/*    */     //   11: dup
/*    */     //   12: iconst_1
/*    */     //   13: iconst_3
/*    */     //   14: iastore
/*    */     //   15: dup
/*    */     //   16: iconst_2
/*    */     //   17: iconst_1
/*    */     //   18: iastore
/*    */     //   19: astore_1
/*    */     //   20: iconst_0
/*    */     //   21: istore #4
/*    */     //   23: iconst_0
/*    */     //   24: dup
/*    */     //   25: istore #5
/*    */     //   27: aload_0
/*    */     //   28: invokevirtual length : ()I
/*    */     //   31: if_icmpge -> 110
/*    */     //   34: aload_0
/*    */     //   35: iload #5
/*    */     //   37: invokevirtual charAt : (I)C
/*    */     //   40: dup
/*    */     //   41: istore_2
/*    */     //   42: bipush #48
/*    */     //   44: if_icmplt -> 64
/*    */     //   47: iload_2
/*    */     //   48: bipush #57
/*    */     //   50: if_icmpgt -> 64
/*    */     //   53: iload_2
/*    */     //   54: bipush #48
/*    */     //   56: isub
/*    */     //   57: istore_3
/*    */     //   58: iload #4
/*    */     //   60: goto -> 91
/*    */     //   63: pop
/*    */     //   64: iload_2
/*    */     //   65: bipush #65
/*    */     //   67: if_icmplt -> 87
/*    */     //   70: iload_2
/*    */     //   71: bipush #90
/*    */     //   73: if_icmpgt -> 87
/*    */     //   76: iload_2
/*    */     //   77: bipush #55
/*    */     //   79: isub
/*    */     //   80: istore_3
/*    */     //   81: iload #4
/*    */     //   83: goto -> 91
/*    */     //   86: iconst_0
/*    */     //   87: iconst_0
/*    */     //   88: istore_3
/*    */     //   89: iload #4
/*    */     //   91: iload_3
/*    */     //   92: aload_1
/*    */     //   93: iload #5
/*    */     //   95: iconst_3
/*    */     //   96: irem
/*    */     //   97: iaload
/*    */     //   98: iinc #5, 1
/*    */     //   101: imul
/*    */     //   102: iadd
/*    */     //   103: istore #4
/*    */     //   105: iload #5
/*    */     //   107: goto -> 27
/*    */     //   110: iload #4
/*    */     //   112: bipush #10
/*    */     //   114: irem
/*    */     //   115: ireturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #41	-> 0
/*    */     //   #80	-> 20
/*    */     //   #222	-> 23
/*    */     //   #86	-> 34
/*    */     //   #4	-> 42
/*    */     //   #21	-> 53
/*    */     //   #79	-> 64
/*    */     //   #74	-> 76
/*    */     //   #103	-> 87
/*    */     //   #225	-> 89
/*    */     //   #222	-> 105
/*    */     //   #163	-> 110
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   0	116	0	a	Ljava/lang/String; }
/*    */   
/* 64 */   public static boolean verificateCheckDigitICAO(String a, int a) { -21586; 'Ⱇ'; if (getCheckDigitICAO((String)SYNTHETIC_LOCAL_VARIABLE_0) == SYNTHETIC_LOCAL_VARIABLE_1) return true;  while (true) return false;  }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/util/CheckDigit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */