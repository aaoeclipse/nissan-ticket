/*     */ package com.sltech.util.smartcard;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CardTerminal;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CardTerminalSource
/*     */   implements Runnable
/*     */ {
/*     */   private static final int H = 500;
/*     */   private boolean J;
/*     */   private Thread C;
/*     */   
/*     */   public CardTerminalSource(String a) throws CardException {
/*  32 */     this.j = CardTerminalState.NO_CARD_PRESENT;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     this; super(); (new ArrayList()).K = (List<CardTerminalStateListener>)this;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 227 */     null.C = (Thread)(null.E = (CardTerminal)this); true.J = 'Ǵ'.a = this; a.f('Ǵ', this); } public CardTerminalSource(String a, int a) throws CardException { this.j = CardTerminalState.NO_CARD_PRESENT; this; super(); (new ArrayList()).K = (List<CardTerminalStateListener>)this; null.C = (Thread)(null.E = (CardTerminal)this);
/*     */     true.J = 'Ǵ'.a = this;
/*     */     SYNTHETIC_LOCAL_VARIABLE_1.f((String)SYNTHETIC_LOCAL_VARIABLE_2, this); }
/*     */ 
/*     */   
/*     */   public CardTerminalState getCardTerminalState() { return this.j; }
/*     */   
/*     */   public synchronized void removeAllEventListener() { this.K.clear(); }
/*     */   
/*     */   private static final Logger l = LoggerFactory.getLogger(CardTerminalSource.class);
/*     */   private int a;
/*     */   private CardTerminalState j;
/*     */   private CardTerminal E;
/*     */   private List<CardTerminalStateListener> K;
/*     */   
/*     */   public CardTerminal getCardTerminal() { return this.E; }
/*     */   
/*     */   public void dispose() {
/*     */     this.J = false;
/*     */     this.K.clear();
/*     */   }
/*     */   
/*     */   public synchronized void addEventListener(CardTerminalStateListener a) { this.K.add(a); }
/*     */   
/*     */   public void run() {
/*     */     while (true) {
/*     */       if (this.J)
/*     */         continue; 
/*     */       break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public synchronized void removeEventListener(CardTerminalStateListener a) { this.K.remove(a); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/util/smartcard/CardTerminalSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */