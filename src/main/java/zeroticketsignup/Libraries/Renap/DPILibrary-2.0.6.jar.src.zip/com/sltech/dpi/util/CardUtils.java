/*     */ package com.sltech.dpi.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CardUtils
/*     */ {
/*     */   public static boolean checkATR(byte[] a) {
/*  32 */     true; boolean bool = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     System.arraycopy(a, 1, bool, 0, a.length - 2);
/*     */     if (xorSum(bool) == a[a.length - 1]) {
/*     */       return true;
/*     */     }
/*     */     while (true) {
/*     */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] xorArray(byte[] a, int a, byte[] a, int a, int a) { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: arraylength
/*     */     //   2: iload_1
/*     */     //   3: isub
/*     */     //   4: iload #4
/*     */     //   6: if_icmpge -> 12
/*     */     //   9: aconst_null
/*     */     //   10: areturn
/*     */     //   11: pop
/*     */     //   12: aload_2
/*     */     //   13: arraylength
/*     */     //   14: iload_3
/*     */     //   15: isub
/*     */     //   16: iload #4
/*     */     //   18: if_icmpge -> 24
/*     */     //   21: aconst_null
/*     */     //   22: areturn
/*     */     //   23: iconst_0
/*     */     //   24: iload #4
/*     */     //   26: newarray byte
/*     */     //   28: iconst_1
/*     */     //   29: dup
/*     */     //   30: pop2
/*     */     //   31: astore #5
/*     */     //   33: iconst_0
/*     */     //   34: dup
/*     */     //   35: istore #6
/*     */     //   37: iload #4
/*     */     //   39: if_icmpge -> 68
/*     */     //   42: aload #5
/*     */     //   44: aload_0
/*     */     //   45: iload_1
/*     */     //   46: iload #6
/*     */     //   48: dup_x2
/*     */     //   49: iadd
/*     */     //   50: baload
/*     */     //   51: aload_2
/*     */     //   52: iload_3
/*     */     //   53: iload #6
/*     */     //   55: iadd
/*     */     //   56: baload
/*     */     //   57: ixor
/*     */     //   58: i2b
/*     */     //   59: iinc #6, 1
/*     */     //   62: bastore
/*     */     //   63: iload #6
/*     */     //   65: goto -> 37
/*     */     //   68: aload #5
/*     */     //   70: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #80	-> 0
/*     */     //   #29	-> 9
/*     */     //   #86	-> 12
/*     */     //   #4	-> 21
/*     */     //   #74	-> 24
/*     */     //   #227	-> 33
/*     */     //   #103	-> 42
/*     */     //   #227	-> 63
/*     */     //   #225	-> 68
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	71	0	a	[B
/*     */     //   0	71	1	a	I
/*     */     //   0	71	2	a	[B
/*     */     //   0	71	3	a	I
/*     */     //   0	71	4	a	I }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte xorSum(byte[] a) { // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_1
/*     */     //   2: iconst_0
/*     */     //   3: dup
/*     */     //   4: istore_2
/*     */     //   5: aload_0
/*     */     //   6: arraylength
/*     */     //   7: if_icmpge -> 25
/*     */     //   10: iload_1
/*     */     //   11: aload_0
/*     */     //   12: iload_2
/*     */     //   13: baload
/*     */     //   14: iinc #2, 1
/*     */     //   17: ixor
/*     */     //   18: i2b
/*     */     //   19: istore_1
/*     */     //   20: iload_2
/*     */     //   21: goto -> 5
/*     */     //   24: pop
/*     */     //   25: iload_1
/*     */     //   26: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #87	-> 0
/*     */     //   #67	-> 2
/*     */     //   #15	-> 10
/*     */     //   #67	-> 20
/*     */     //   #101	-> 25
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	27	0	a	[B }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatByteToBinary(int a) { true;
/*     */     true[0] = Integer.toBinaryString(a & 0xFF);
/*     */     return String.format((String)new Object[1], true).replace(' ', '0'); }
/*     */ 
/*     */ 
/*     */   
/* 155 */   public static byte[] intToByteArray(int a) { true; true[0] = (byte)(a >>> 24); true[1] = (byte)(a >>> 16); true[2] = (byte)(a >>> 8); true[3] = (byte)a; return true; }
/*     */   
/*     */   public static boolean compareByteArraysSegment(byte[] a, int a, byte[] a, int a, int a) { // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: dup
/*     */     //   2: istore #5
/*     */     //   4: iload #4
/*     */     //   6: if_icmpge -> 36
/*     */     //   9: aload_0
/*     */     //   10: iload_1
/*     */     //   11: iload #5
/*     */     //   13: iadd
/*     */     //   14: baload
/*     */     //   15: aload_2
/*     */     //   16: iload_3
/*     */     //   17: iload #5
/*     */     //   19: iadd
/*     */     //   20: baload
/*     */     //   21: if_icmpeq -> 27
/*     */     //   24: iconst_0
/*     */     //   25: ireturn
/*     */     //   26: pop
/*     */     //   27: iinc #5, 1
/*     */     //   30: iload #5
/*     */     //   32: goto -> 4
/*     */     //   35: iconst_0
/*     */     //   36: iconst_1
/*     */     //   37: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #188	-> 0
/*     */     //   #118	-> 9
/*     */     //   #148	-> 24
/*     */     //   #188	-> 27
/*     */     //   #135	-> 36
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	38	0	a	[B
/*     */     //   0	38	1	a	I
/*     */     //   0	38	2	a	[B
/*     */     //   0	38	3	a	I
/*     */     //   0	38	4	a	I }
/*     */   
/*     */   public static String f(String a) {
/*     */     1.0F;
/*     */     true;
/*     */     int i = new char[a.length()] - 1;
/*     */     boolean bool = true;
/*     */     int n = a.length();
/*     */     new char[a.length()] - 1;
/*     */     int k = 1 << 3 ^ 0x2 ^ 0x5;
/*     */     new char[a.length()] - 1;
/*     */     int j = (0x3 ^ 0x5) << 4 ^ 0x3;
/*     */     int m = j;
/*     */     float f = 2.0F;
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/util/CardUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */