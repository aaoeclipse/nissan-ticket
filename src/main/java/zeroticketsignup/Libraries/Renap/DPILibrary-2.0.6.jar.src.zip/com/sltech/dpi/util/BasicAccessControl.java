/*     */ package com.sltech.dpi.util;
/*     */ 
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Arrays;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CommandAPDU;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BasicAccessControl
/*     */ {
/*  79 */   private static final byte[] K = DataUtils.hexTextToByteArray(CheckDigit.f("MT\026\016\027\f\n\020\017\022MQ!>\002\034\020\t\n\023\000\031\";\000\031\000\031\006\037\020\t\021\t!8\r\027\f\027\026\n\020\r\r\023\016\021^N\001\020\016g\013a\fg\013g\026{\\2"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static KeyPair calculateEncMacKeys(byte[] a) throws DPIException {
/*  90 */     true; boolean bool1 = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     true; boolean bool2 = true;
/*     */ 
/*     */     
/*     */     true;
/*     */ 
/*     */     
/*     */     boolean bool3 = true;
/*     */ 
/*     */     
/*     */     if (a.length < 16) {
/*     */       throw new DPIException(CardUtils.f("#h\nq\020y(\000\023i\004i[{\030\007x\013!"));
/*     */     }
/*     */     
/*     */     System.arraycopy(a, 0, bool3, 0, 16);
/*     */     
/*     */     MessageDigest messageDigest = MessageDigest.getInstance(CheckDigit.f("|br\r\b"));
/*     */     
/*     */     bool3[19] = true;
/*     */     
/*     */     System.arraycopy(messageDigest.digest(bool3), 0, bool1, 0, 16);
/*     */     
/*     */     bool3[19] = true;
/*     */     
/* 216 */     System.arraycopy(messageDigest.digest(bool3), 0, bool2, 0, 16);
/*     */     return new KeyPair(a, bool1, bool2);
/*     */   }
/*     */   
/*     */   public static byte[] encMacHash(byte[] a, byte[] a) throws DPIException { // Byte code:
/*     */     //   0: bipush #8
/*     */     //   2: newarray byte
/*     */     //   4: iconst_1
/*     */     //   5: dup
/*     */     //   6: pop2
/*     */     //   7: astore_2
/*     */     //   8: bipush #8
/*     */     //   10: aload_1
/*     */     //   11: dup_x1
/*     */     //   12: aload_2
/*     */     //   13: iconst_0
/*     */     //   14: dup_x1
/*     */     //   15: bipush #8
/*     */     //   17: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   20: newarray byte
/*     */     //   22: iconst_1
/*     */     //   23: dup
/*     */     //   24: pop2
/*     */     //   25: dup
/*     */     //   26: astore_1
/*     */     //   27: iconst_0
/*     */     //   28: bipush #8
/*     */     //   30: dup_x2
/*     */     //   31: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   34: new javax/crypto/spec/IvParameterSpec
/*     */     //   37: dup
/*     */     //   38: bipush #8
/*     */     //   40: newarray byte
/*     */     //   42: iconst_1
/*     */     //   43: dup
/*     */     //   44: pop2
/*     */     //   45: invokespecial <init> : ([B)V
/*     */     //   48: astore_3
/*     */     //   49: new javax/crypto/spec/SecretKeySpec
/*     */     //   52: dup
/*     */     //   53: aload_2
/*     */     //   54: ldc_w 'H&\'
/*     */     //   57: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   60: invokespecial <init> : ([BLjava/lang/String;)V
/*     */     //   63: astore_2
/*     */     //   64: new javax/crypto/spec/SecretKeySpec
/*     */     //   67: dup
/*     */     //   68: aload_1
/*     */     //   69: ldc_w '}~q'
/*     */     //   72: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   75: invokespecial <init> : ([BLjava/lang/String;)V
/*     */     //   78: astore_1
/*     */     //   79: ldc_w 'T9Ccc"ONCGue\\rh'
/*     */     //   82: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   85: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
/*     */     //   88: astore #4
/*     */     //   90: ldc_w '`uz1DphgtRSODPUE'
/*     */     //   93: aload #4
/*     */     //   95: dup_x1
/*     */     //   96: iconst_1
/*     */     //   97: aload_2
/*     */     //   98: aload_3
/*     */     //   99: invokevirtual init : (ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V
/*     */     //   102: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   105: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
/*     */     //   108: astore_2
/*     */     //   109: aload_0
/*     */     //   110: aload_2
/*     */     //   111: iconst_2
/*     */     //   112: aload_1
/*     */     //   113: aload_3
/*     */     //   114: invokevirtual init : (ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V
/*     */     //   117: invokestatic padData : ([B)[B
/*     */     //   120: dup
/*     */     //   121: astore_1
/*     */     //   122: iconst_0
/*     */     //   123: bipush #8
/*     */     //   125: invokestatic copyOfRange : ([BII)[B
/*     */     //   128: dup
/*     */     //   129: astore_3
/*     */     //   130: invokevirtual doFinal : ([B)[B
/*     */     //   133: astore #5
/*     */     //   135: aload_1
/*     */     //   136: arraylength
/*     */     //   137: iconst_3
/*     */     //   138: ishr
/*     */     //   139: istore #6
/*     */     //   141: iconst_1
/*     */     //   142: dup
/*     */     //   143: istore #7
/*     */     //   145: iload #6
/*     */     //   147: if_icmpge -> 208
/*     */     //   150: iconst_0
/*     */     //   151: dup
/*     */     //   152: istore #8
/*     */     //   154: bipush #8
/*     */     //   156: if_icmpge -> 188
/*     */     //   159: aload_3
/*     */     //   160: aload #5
/*     */     //   162: iload #8
/*     */     //   164: baload
/*     */     //   165: aload_1
/*     */     //   166: iload #8
/*     */     //   168: dup_x2
/*     */     //   169: iload #7
/*     */     //   171: bipush #8
/*     */     //   173: imul
/*     */     //   174: iadd
/*     */     //   175: baload
/*     */     //   176: ixor
/*     */     //   177: i2b
/*     */     //   178: iinc #8, 1
/*     */     //   181: bastore
/*     */     //   182: iload #8
/*     */     //   184: goto -> 154
/*     */     //   187: pop
/*     */     //   188: aload #4
/*     */     //   190: aload_3
/*     */     //   191: iconst_0
/*     */     //   192: iinc #7, 1
/*     */     //   195: bipush #8
/*     */     //   197: invokevirtual doFinal : ([BII)[B
/*     */     //   200: astore #5
/*     */     //   202: iload #7
/*     */     //   204: goto -> 145
/*     */     //   207: iconst_0
/*     */     //   208: aload_2
/*     */     //   209: aload #5
/*     */     //   211: iconst_0
/*     */     //   212: bipush #8
/*     */     //   214: invokevirtual doFinal : ([BII)[B
/*     */     //   217: astore #5
/*     */     //   219: aload #4
/*     */     //   221: aload #5
/*     */     //   223: iconst_0
/*     */     //   224: bipush #8
/*     */     //   226: invokevirtual doFinal : ([BII)[B
/*     */     //   229: astore #5
/*     */     //   231: aload #5
/*     */     //   233: areturn
/*     */     //   234: astore #4
/*     */     //   236: new com/sltech/dpi/exception/DPIException
/*     */     //   239: dup
/*     */     //   240: ldc_w 'Po h\us>YxA@t]Y!'
/*     */     //   243: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   246: aload #4
/*     */     //   248: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   251: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #125	-> 0
/*     */     //   #121	-> 8
/*     */     //   #157	-> 20
/*     */     //   #16	-> 27
/*     */     //   #89	-> 34
/*     */     //   #180	-> 49
/*     */     //   #176	-> 64
/*     */     //   #171	-> 79
/*     */     //   #201	-> 90
/*     */     //   #168	-> 102
/*     */     //   #99	-> 110
/*     */     //   #199	-> 117
/*     */     //   #224	-> 122
/*     */     //   #42	-> 130
/*     */     //   #187	-> 135
/*     */     //   #39	-> 141
/*     */     //   #17	-> 150
/*     */     //   #77	-> 159
/*     */     //   #17	-> 182
/*     */     //   #94	-> 188
/*     */     //   #39	-> 202
/*     */     //   #145	-> 208
/*     */     //   #122	-> 219
/*     */     //   #139	-> 231
/*     */     //   #97	-> 234
/*     */     //   #167	-> 236
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	252	0	a	[B
/*     */     //   0	252	1	a	[B
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   79	233	234	java/lang/Exception }
/*     */   
/*     */   public static KeyPair calculateEncMacKeys(String a, String a, String a) throws DPIException {
/*     */     byte[] arrayOfByte = (new StringBuilder()).insert(0, a).append(CheckDigit.getCheckDigitICAO(a)).append(a).append(CheckDigit.getCheckDigitICAO(a)).append(a).append(CheckDigit.getCheckDigitICAO(a)).toString().getBytes();
/*     */     arrayOfByte = MessageDigest.getInstance(CheckDigit.f("|br\r\b")).digest(arrayOfByte);
/*     */   }
/*     */   
/*     */   public static byte[] padData(byte[] a) throws IOException {
/*     */     int i;
/*     */     ByteArrayOutputStream byteArrayOutputStream;
/*     */     (byteArrayOutputStream = new ByteArrayOutputStream()).write(a, 0, a.length);
/*     */     byteArrayOutputStream.write(-128);
/*     */     while (true) {
/*     */       i++;
/*     */       if ((i = a.length + 1) % 8 != 0) {
/*     */         byteArrayOutputStream.write(0);
/*     */       }
/*     */       break;
/*     */     } 
/*     */     while (true) {
/*     */       return byteArrayOutputStream.toByteArray();
/*     */     }
/*     */   }
/*     */   
/*     */   public static byte[] encTDes(byte[] a, byte[] a) throws DPIException { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: arraylength
/*     */     //   2: bipush #16
/*     */     //   4: if_icmpne -> 38
/*     */     //   7: bipush #24
/*     */     //   9: newarray byte
/*     */     //   11: iconst_1
/*     */     //   12: dup
/*     */     //   13: pop2
/*     */     //   14: astore_2
/*     */     //   15: iconst_0
/*     */     //   16: aload_0
/*     */     //   17: dup_x1
/*     */     //   18: aload_2
/*     */     //   19: iconst_0
/*     */     //   20: dup_x1
/*     */     //   21: bipush #16
/*     */     //   23: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   26: aload_2
/*     */     //   27: bipush #16
/*     */     //   29: bipush #8
/*     */     //   31: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   34: goto -> 40
/*     */     //   37: pop
/*     */     //   38: aload_0
/*     */     //   39: astore_2
/*     */     //   40: new javax/crypto/spec/IvParameterSpec
/*     */     //   43: dup
/*     */     //   44: bipush #8
/*     */     //   46: newarray byte
/*     */     //   48: iconst_1
/*     */     //   49: dup
/*     */     //   50: pop2
/*     */     //   51: invokespecial <init> : ([B)V
/*     */     //   54: astore_3
/*     */     //   55: new javax/crypto/spec/SecretKeySpec
/*     */     //   58: dup
/*     */     //   59: aload_2
/*     */     //   60: ldc_w '9T3ij'
/*     */     //   63: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   66: invokespecial <init> : ([BLjava/lang/String;)V
/*     */     //   69: astore_2
/*     */     //   70: ldc_w 'e}o@[ClgghNvjRFN^'
/*     */     //   73: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   76: invokestatic getInstance : (Ljava/lang/String;)Ljavax/crypto/Cipher;
/*     */     //   79: astore #4
/*     */     //   81: aload_1
/*     */     //   82: aload #4
/*     */     //   84: dup_x1
/*     */     //   85: iconst_1
/*     */     //   86: aload_2
/*     */     //   87: aload_3
/*     */     //   88: invokevirtual init : (ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V
/*     */     //   91: invokevirtual doFinal : ([B)[B
/*     */     //   94: areturn
/*     */     //   95: iconst_0
/*     */     //   96: astore #4
/*     */     //   98: new com/sltech/dpi/exception/DPIException
/*     */     //   101: dup
/*     */     //   102: aload #4
/*     */     //   104: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   107: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #213	-> 0
/*     */     //   #131	-> 7
/*     */     //   #207	-> 15
/*     */     //   #2	-> 26
/*     */     //   #204	-> 38
/*     */     //   #174	-> 40
/*     */     //   #9	-> 55
/*     */     //   #112	-> 70
/*     */     //   #134	-> 81
/*     */     //   #166	-> 91
/*     */     //   #6	-> 96
/*     */     //   #49	-> 98
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	108	0	a	[B
/*     */     //   0	108	1	a	[B
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   70	94	96	java/lang/Exception }
/*     */   
/*     */   protected static byte[] I(KeyPair a, String a) throws DPIException
/*     */   {
/* 248 */     a = CheckDigit.f(" J~\025\r\024\027\016\031\b\f\025\017\026*3");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     String str = CardUtils.f("D&P=R=");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     a = a.concat(str);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     incrementSSC(a.getSsc());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 477 */     a = DataUtils.arrayToHexText(
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 553 */         encMacHash(DataUtils.hexTextToByteArray(DataUtils.arrayToHexText(a.getSsc()).concat(a).concat(CheckDigit.f("\037\016\021\b\f\025\017\026*3"))), a.getMacKey())); str = CardUtils.f("XIS7").concat(a); return DataUtils.hexTextToByteArray((new StringBuilder()).insert(0, CheckDigit.f("\020zb\t 9\f\021\r`\036\t\021\t\r\027\007c*;")).append(a).append(CardUtils.f("S?")).toString()); } public static byte[] prepareMutualAuth(byte[] a, KeyPair a) throws DPIException { byte[] arrayOfByte2 = (byte[])K.clone(); System.arraycopy(a, 0, arrayOfByte2, 8, 8);
/*     */     byte[] arrayOfByte3 = encMacHash(arrayOfByte2 = encTDes(a.getEncKey(), arrayOfByte2), a.getMacKey());
/*     */     byteArrayOutputStream.write(arrayOfByte2);
/*     */     ByteArrayOutputStream byteArrayOutputStream;
/* 557 */     (byteArrayOutputStream = new ByteArrayOutputStream()).write(arrayOfByte3); byte[] arrayOfByte1 = byteArrayOutputStream.toByteArray(); (byteArrayOutputStream = new ByteArrayOutputStream()).close();
/*     */     return arrayOfByte1; }
/*     */ 
/*     */   
/*     */   protected static String f(KeyPair a, String a) throws DPIException { return DataUtils.arrayToHexText(f(a, DataUtils.hexTextToByteArray(a))); }
/*     */   
/*     */   public static byte[] secureRead(CardChannel a, KeyPair a, String a) throws DPIException {
/*     */     null = I(a, a);
/*     */     CommandAPDU commandAPDU = new CommandAPDU(null);
/*     */     return f(a, a.transmit(commandAPDU).getBytes());
/*     */   }
/*     */   
/*     */   protected static byte[] J(KeyPair a, String a) throws DPIException { // Byte code:
/*     */     //   0: ldc ''
/*     */     //   2: astore_2
/*     */     //   3: ldc_w ' 7'
/*     */     //   6: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   9: astore_3
/*     */     //   10: aload_1
/*     */     //   11: invokevirtual length : ()I
/*     */     //   14: bipush #10
/*     */     //   16: if_icmple -> 80
/*     */     //   19: aload_1
/*     */     //   20: bipush #8
/*     */     //   22: bipush #10
/*     */     //   24: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   27: ldc_w 'S?'
/*     */     //   30: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   33: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   36: ifeq -> 116
/*     */     //   39: new java/lang/StringBuilder
/*     */     //   42: dup
/*     */     //   43: invokespecial <init> : ()V
/*     */     //   46: iconst_0
/*     */     //   47: aload_3
/*     */     //   48: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   51: ldc_w ')2'
/*     */     //   54: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   57: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   60: aload_1
/*     */     //   61: bipush #10
/*     */     //   63: bipush #14
/*     */     //   65: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   68: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   71: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   74: astore_3
/*     */     //   75: aload_0
/*     */     //   76: goto -> 117
/*     */     //   79: pop
/*     */     //   80: new java/lang/StringBuilder
/*     */     //   83: dup
/*     */     //   84: invokespecial <init> : ()V
/*     */     //   87: iconst_0
/*     */     //   88: aload_3
/*     */     //   89: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   92: ldc_w 'S>'
/*     */     //   95: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   98: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   101: aload_1
/*     */     //   102: bipush #8
/*     */     //   104: bipush #10
/*     */     //   106: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   112: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   115: astore_3
/*     */     //   116: aload_0
/*     */     //   117: invokevirtual getSsc : ()[B
/*     */     //   120: invokestatic incrementSSC : ([B)V
/*     */     //   123: new java/lang/StringBuilder
/*     */     //   126: dup
/*     */     //   127: invokespecial <init> : ()V
/*     */     //   130: iconst_0
/*     */     //   131: aload_0
/*     */     //   132: invokevirtual getSsc : ()[B
/*     */     //   135: invokestatic arrayToHexText : ([B)Ljava/lang/String;
/*     */     //   138: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   141: ldc_w ')C'
/*     */     //   144: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   147: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   150: aload_1
/*     */     //   151: iconst_2
/*     */     //   152: bipush #8
/*     */     //   154: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   157: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   160: ldc_w 'C'M!P<S?'
/*     */     //   163: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   166: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   169: aload_2
/*     */     //   170: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   173: aload_3
/*     */     //   174: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   177: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   180: invokestatic hexTextToByteArray : (Ljava/lang/String;)[B
/*     */     //   183: aload_0
/*     */     //   184: invokevirtual getMacKey : ()[B
/*     */     //   187: invokestatic encMacHash : ([B[B)[B
/*     */     //   190: invokestatic arrayToHexText : ([B)Ljava/lang/String;
/*     */     //   193: astore_2
/*     */     //   194: new java/lang/StringBuilder
/*     */     //   197: dup
/*     */     //   198: invokespecial <init> : ()V
/*     */     //   201: iconst_0
/*     */     //   202: ldc_w ')C'
/*     */     //   205: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   208: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   211: aload_1
/*     */     //   212: iconst_2
/*     */     //   213: bipush #8
/*     */     //   215: invokevirtual substring : (II)Ljava/lang/String;
/*     */     //   218: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   221: aload_3
/*     */     //   222: iconst_3
/*     */     //   223: invokevirtual charAt : (I)C
/*     */     //   226: bipush #49
/*     */     //   228: if_icmpeq -> 241
/*     */     //   231: ldc_w 'SJ'
/*     */     //   234: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   237: goto -> 247
/*     */     //   240: iconst_0
/*     */     //   241: ldc_w ')D'
/*     */     //   244: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   247: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   250: aload_3
/*     */     //   251: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   254: ldc_w 'XIS7'
/*     */     //   257: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   260: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   263: aload_2
/*     */     //   264: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   267: ldc_w ')0'
/*     */     //   270: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   273: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   276: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   279: invokestatic hexTextToByteArray : (Ljava/lang/String;)[B
/*     */     //   282: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #414	-> 0
/*     */     //   #545	-> 3
/*     */     //   #230	-> 10
/*     */     //   #522	-> 19
/*     */     //   #246	-> 39
/*     */     //   #290	-> 80
/*     */     //   #421	-> 116
/*     */     //   #346	-> 123
/*     */     //   #307	-> 190
/*     */     //   #270	-> 194
/*     */     //   #555	-> 279
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	283	0	a	Lcom/sltech/dpi/util/KeyPair;
/*     */     //   0	283	1	a	Ljava/lang/String; }
/*     */   
/*     */   protected static byte[] f(KeyPair a, byte[] a) throws DPIException { // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_2
/*     */     //   2: iconst_0
/*     */     //   3: istore_3
/*     */     //   4: aload_1
/*     */     //   5: iload_3
/*     */     //   6: baload
/*     */     //   7: bipush #-121
/*     */     //   9: if_icmpne -> 198
/*     */     //   12: iconst_0
/*     */     //   13: istore #4
/*     */     //   15: iconst_0
/*     */     //   16: istore #5
/*     */     //   18: aload_1
/*     */     //   19: iload_3
/*     */     //   20: iconst_1
/*     */     //   21: iadd
/*     */     //   22: baload
/*     */     //   23: sipush #255
/*     */     //   26: iand
/*     */     //   27: sipush #128
/*     */     //   30: if_icmple -> 95
/*     */     //   33: aload_1
/*     */     //   34: iload_3
/*     */     //   35: iconst_1
/*     */     //   36: iadd
/*     */     //   37: baload
/*     */     //   38: sipush #255
/*     */     //   41: iand
/*     */     //   42: sipush #129
/*     */     //   45: isub
/*     */     //   46: iconst_1
/*     */     //   47: iadd
/*     */     //   48: istore #5
/*     */     //   50: iload_3
/*     */     //   51: iconst_2
/*     */     //   52: iadd
/*     */     //   53: dup
/*     */     //   54: istore #6
/*     */     //   56: iload_3
/*     */     //   57: iload #5
/*     */     //   59: iadd
/*     */     //   60: iconst_2
/*     */     //   61: iadd
/*     */     //   62: if_icmpge -> 106
/*     */     //   65: iload #4
/*     */     //   67: sipush #256
/*     */     //   70: imul
/*     */     //   71: aload_1
/*     */     //   72: iload #6
/*     */     //   74: baload
/*     */     //   75: sipush #255
/*     */     //   78: iinc #6, 1
/*     */     //   81: iand
/*     */     //   82: iadd
/*     */     //   83: istore #4
/*     */     //   85: iload #6
/*     */     //   87: goto -> 56
/*     */     //   90: pop
/*     */     //   91: goto -> 106
/*     */     //   94: iconst_0
/*     */     //   95: aload_1
/*     */     //   96: iload_3
/*     */     //   97: iconst_1
/*     */     //   98: iadd
/*     */     //   99: baload
/*     */     //   100: sipush #255
/*     */     //   103: iand
/*     */     //   104: istore #4
/*     */     //   106: iinc #4, -1
/*     */     //   109: iload #4
/*     */     //   111: newarray byte
/*     */     //   113: iconst_1
/*     */     //   114: dup
/*     */     //   115: pop2
/*     */     //   116: astore #6
/*     */     //   118: aload_0
/*     */     //   119: aload_1
/*     */     //   120: iload_3
/*     */     //   121: dup_x1
/*     */     //   122: iconst_3
/*     */     //   123: iadd
/*     */     //   124: iload #5
/*     */     //   126: iadd
/*     */     //   127: aload #6
/*     */     //   129: iconst_0
/*     */     //   130: iload #4
/*     */     //   132: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   135: iload #4
/*     */     //   137: iconst_3
/*     */     //   138: iadd
/*     */     //   139: iload #5
/*     */     //   141: iadd
/*     */     //   142: iadd
/*     */     //   143: istore_3
/*     */     //   144: invokevirtual getEncKey : ()[B
/*     */     //   147: aload #6
/*     */     //   149: invokestatic f : ([B[B)[B
/*     */     //   152: dup
/*     */     //   153: astore #6
/*     */     //   155: arraylength
/*     */     //   156: iconst_1
/*     */     //   157: isub
/*     */     //   158: istore #4
/*     */     //   160: aload #6
/*     */     //   162: iload #4
/*     */     //   164: baload
/*     */     //   165: bipush #-128
/*     */     //   167: if_icmpeq -> 178
/*     */     //   170: aload #6
/*     */     //   172: iinc #4, -1
/*     */     //   175: goto -> 162
/*     */     //   178: iload #4
/*     */     //   180: iconst_2
/*     */     //   181: iadd
/*     */     //   182: newarray byte
/*     */     //   184: iconst_1
/*     */     //   185: dup
/*     */     //   186: pop2
/*     */     //   187: astore_2
/*     */     //   188: aload #6
/*     */     //   190: aload_2
/*     */     //   191: iconst_0
/*     */     //   192: dup_x1
/*     */     //   193: iload #4
/*     */     //   195: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   198: aload_1
/*     */     //   199: iload_3
/*     */     //   200: baload
/*     */     //   201: bipush #-103
/*     */     //   203: if_icmpne -> 233
/*     */     //   206: aload_2
/*     */     //   207: ifnonnull -> 217
/*     */     //   210: iconst_2
/*     */     //   211: newarray byte
/*     */     //   213: iconst_1
/*     */     //   214: dup
/*     */     //   215: pop2
/*     */     //   216: astore_2
/*     */     //   217: aload_1
/*     */     //   218: iload_3
/*     */     //   219: iconst_2
/*     */     //   220: iadd
/*     */     //   221: aload_2
/*     */     //   222: dup
/*     */     //   223: arraylength
/*     */     //   224: iconst_2
/*     */     //   225: iinc #3, 4
/*     */     //   228: isub
/*     */     //   229: iconst_2
/*     */     //   230: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   233: aload_1
/*     */     //   234: iload_3
/*     */     //   235: baload
/*     */     //   236: bipush #-114
/*     */     //   238: if_icmpeq -> 243
/*     */     //   241: aconst_null
/*     */     //   242: areturn
/*     */     //   243: aload_0
/*     */     //   244: invokevirtual getSsc : ()[B
/*     */     //   247: invokestatic incrementSSC : ([B)V
/*     */     //   250: aload_2
/*     */     //   251: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #433	-> 0
/*     */     //   #530	-> 2
/*     */     //   #513	-> 4
/*     */     //   #272	-> 12
/*     */     //   #519	-> 18
/*     */     //   #379	-> 33
/*     */     //   #376	-> 50
/*     */     //   #235	-> 65
/*     */     //   #376	-> 85
/*     */     //   #499	-> 95
/*     */     //   #503	-> 106
/*     */     //   #439	-> 109
/*     */     //   #283	-> 119
/*     */     //   #356	-> 135
/*     */     //   #541	-> 144
/*     */     //   #534	-> 155
/*     */     //   #361	-> 178
/*     */     //   #258	-> 188
/*     */     //   #261	-> 198
/*     */     //   #497	-> 206
/*     */     //   #460	-> 210
/*     */     //   #338	-> 217
/*     */     //   #458	-> 225
/*     */     //   #287	-> 233
/*     */     //   #378	-> 241
/*     */     //   #240	-> 243
/*     */     //   #257	-> 250
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	252	0	a	Lcom/sltech/dpi/util/KeyPair;
/*     */     //   0	252	1	a	[B }
/*     */   
/*     */   public static byte[] secureTransmit(CardChannel a, KeyPair a, String a) throws DPIException {
/*     */     null = J(a, a);
/*     */     CommandAPDU commandAPDU = new CommandAPDU(null);
/*     */     return f(a, a.transmit(commandAPDU).getBytes());
/*     */   }
/*     */   
/*     */   public static KeyPair finishMutualAuth(byte[] a, byte[] a, KeyPair a) throws DPIException {
/*     */     byte[] arrayOfByte1 = (byte[])K.clone();
/*     */     System.arraycopy(a, 0, arrayOfByte1, 8, 8);
/*     */     byte[] arrayOfByte2;
/*     */     if (!CardUtils.compareByteArraysSegment(encMacHash(arrayOfByte2 = Arrays.copyOfRange(a, 0, 32), a.getMacKey()), 0, a, 32, 8))
/*     */       throw new DPIException(CardUtils.f(">e=R\003n\037eJp\031b\025v%C\001x\bb\0257\030c\022c\021!")); 
/*     */     a = f(a.getEncKey(), arrayOfByte2);
/*     */     if (!CardUtils.compareByteArraysSegment(arrayOfByte1, 0, a, 8, 8))
/*     */       throw new DPIException(CheckDigit.f("xU\032@UEVOEW\\G>qCMNXO\\S_VI|+CMUQI\f")); 
/*     */     if (!CardUtils.compareByteArraysSegment(arrayOfByte1, 8, a, 0, 8))
/*     */       throw new DPIException(CardUtils.f("J\025cFi\004a\"N\tn\013eJp\031b\025v%C\001x\bb\0257\030c\022c\021!")); 
/*     */     true;
/*     */     boolean bool = true;
/*     */     System.arraycopy(a, 4, bool, 0, 4);
/*     */     System.arraycopy(arrayOfByte1, 4, bool, 4, 4);
/*     */     calculateEncMacKeys(CardUtils.xorArray(a, 16, arrayOfByte1, 16, 16)).setSsc(bool);
/*     */     return calculateEncMacKeys(CardUtils.xorArray(a, 16, arrayOfByte1, 16, 16));
/*     */   }
/*     */   
/*     */   protected static byte[] k(KeyPair a, String a) throws DPIException {
/*     */     incrementSSC(a.getSsc());
/*     */     a = DataUtils.arrayToHexText(a.getSsc());
/*     */     return DataUtils.hexTextToByteArray(CardUtils.f("L \r\024P>QNK%M QHS?"));
/*     */   }
/*     */   
/*     */   public static void incrementSSC(byte[] a) { // Byte code:
/*     */     //   0: bipush #7
/*     */     //   2: dup
/*     */     //   3: istore_1
/*     */     //   4: iflt -> 31
/*     */     //   7: iload_1
/*     */     //   8: aload_0
/*     */     //   9: dup_x1
/*     */     //   10: iload_1
/*     */     //   11: dup2
/*     */     //   12: baload
/*     */     //   13: iconst_1
/*     */     //   14: iadd
/*     */     //   15: i2b
/*     */     //   16: bastore
/*     */     //   17: baload
/*     */     //   18: ifeq -> 23
/*     */     //   21: return
/*     */     //   22: pop
/*     */     //   23: iinc #1, -1
/*     */     //   26: iload_1
/*     */     //   27: goto -> 4
/*     */     //   30: iconst_0
/*     */     //   31: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #498	-> 0
/*     */     //   #391	-> 7
/*     */     //   #276	-> 17
/*     */     //   #531	-> 21
/*     */     //   #498	-> 23
/*     */     //   #483	-> 31
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	32	0	a	[B }
/*     */   
/*     */   protected static byte[] f(KeyPair a, String a) throws DPIException {
/*     */     a = CardUtils.f("LS\016\020P<Q=C'M!P<S?");
/*     */     String str = CheckDigit.f("\005\022\017\027\007\034");
/*     */     a = (new StringBuilder()).insert(0, a).append(str).toString();
/*     */     incrementSSC(a.getSsc());
/*     */     str = DataUtils.arrayToHexText(a.getSsc());
/*     */     a = DataUtils.arrayToHexText(encMacHash(DataUtils.hexTextToByteArray((new StringBuilder()).insert(0, str).append(a).toString()), a.getMacKey()));
/*     */     str = (new StringBuilder()).insert(0, CardUtils.f("XIS7")).append(a).toString();
/*     */     return DataUtils.hexTextToByteArray((new StringBuilder()).insert(0, CheckDigit.f("\020zb\t 9\f\025\r`\036\t\021\t}\025\007c\005\024")).append(a).append(CardUtils.f("S?")).toString());
/*     */   }
/*     */   
/*     */   public static byte[] secureValidate(CardChannel a, KeyPair a, String a) throws DPIException {
/*     */     null = f(a, a);
/*     */     CommandAPDU commandAPDU = new CommandAPDU(null);
/*     */     return f(a, a.transmit(commandAPDU).getBytes());
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/util/BasicAccessControl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */