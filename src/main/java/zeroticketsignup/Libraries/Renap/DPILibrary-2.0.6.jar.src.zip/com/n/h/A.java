package com.n.h;

public class A {
  private byte[] l;
  
  private byte a;
  
  private byte[] j;
  
  private byte[] E;
  
  private byte K;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/n/h/A.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */