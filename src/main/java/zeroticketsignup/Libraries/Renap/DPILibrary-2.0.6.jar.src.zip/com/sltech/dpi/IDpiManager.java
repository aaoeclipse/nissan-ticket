package com.sltech.dpi;

import com.sltech.dpi.exception.DPIException;
import com.sltech.dpi.smartcard.DatosdpiTO;
import com.sltech.dpi.smartcard.DpiDataTO;
import com.sltech.dpi.smartcard.FingerType;
import java.util.List;
import javax.smartcardio.CardChannel;

public interface IDpiManager {
  String readMRZ(CardChannel paramCardChannel) throws DPIException;
  
  List<FingerType> readFingerPrintsEnrolled(CardChannel paramCardChannel) throws DPIException;
  
  DatosdpiTO readGeneralDataOld(CardChannel paramCardChannel) throws DPIException;
  
  long readSerialNumber(CardChannel paramCardChannel) throws DPIException;
  
  DpiDataTO readAllData(CardChannel paramCardChannel) throws DPIException;
  
  byte[] readPhoto(CardChannel paramCardChannel) throws DPIException;
  
  DpiDataTO readGeneralData(CardChannel paramCardChannel) throws DPIException;
  
  DatosdpiTO readAllDataOld(CardChannel paramCardChannel) throws DPIException;
}


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/IDpiManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */