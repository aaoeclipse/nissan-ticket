/*     */ package com.sltech.dpi.impl;
/*     */ import com.n.h.i;
/*     */ import com.n.n.H;
/*     */ import com.n.n.I;
/*     */ import com.n.n.a;
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import com.sltech.dpi.smartcard.DpiDataTO;
/*     */ import com.sltech.dpi.util.BasicAccessControl;
/*     */ import com.sltech.dpi.util.CardUtils;
/*     */ import com.sltech.dpi.util.DataUtils;
/*     */ import com.sltech.dpi.util.KeyPair;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.List;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CommandAPDU;
/*     */ 
/*     */ public class DpiV3Manager extends DPIManager implements IDpiManager {
/*     */   public DpiDataTO readAllData(CardChannel a) throws DPIException {
/*  19 */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     KeyPair keyPair = f(a, dpiDataTO);
/*     */     dpiDataTO.setMachineReadableZone(f(a, keyPair));
/*     */     dpiDataTO.setFoto(readPhoto(a, keyPair));
/*     */     return dpiDataTO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readPhoto(CardChannel a, KeyPair a) throws DPIException { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: new java/lang/StringBuilder
/*     */     //   4: aload_2
/*     */     //   5: dup_x1
/*     */     //   6: dup
/*     */     //   7: pop2
/*     */     //   8: dup
/*     */     //   9: invokespecial <init> : ()V
/*     */     //   12: ldc_w 'aRUuLfU'
/*     */     //   15: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   18: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   21: ldc_w 'O6OI'
/*     */     //   24: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   27: iconst_1
/*     */     //   28: anewarray java/lang/Object
/*     */     //   31: iconst_1
/*     */     //   32: dup
/*     */     //   33: pop2
/*     */     //   34: dup
/*     */     //   35: iconst_0
/*     */     //   36: dup
/*     */     //   37: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   40: aastore
/*     */     //   41: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   44: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   47: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   50: invokestatic secureTransmit : (Ljavax/smartcardio/CardChannel;Lcom/sltech/dpi/util/KeyPair;Ljava/lang/String;)[B
/*     */     //   53: dup
/*     */     //   54: astore_3
/*     */     //   55: invokestatic check9000 : ([B)Z
/*     */     //   58: ifne -> 75
/*     */     //   61: new com/sltech/dpi/exception/DPIException
/*     */     //   64: dup
/*     */     //   65: ldc_w 'OK(*K:6?8 k'X? 5\\n3\\nz5v$:K'
/*     */     //   68: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   71: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   74: athrow
/*     */     //   75: aload_3
/*     */     //   76: dup
/*     */     //   77: iconst_2
/*     */     //   78: baload
/*     */     //   79: aload_3
/*     */     //   80: dup_x1
/*     */     //   81: iconst_3
/*     */     //   82: baload
/*     */     //   83: invokestatic convertToInt : (BB)I
/*     */     //   86: istore #4
/*     */     //   88: iconst_2
/*     */     //   89: baload
/*     */     //   90: aload_3
/*     */     //   91: iconst_3
/*     */     //   92: baload
/*     */     //   93: invokestatic convertToInt : (BB)I
/*     */     //   96: istore #5
/*     */     //   98: iload #4
/*     */     //   100: iconst_4
/*     */     //   101: iadd
/*     */     //   102: newarray byte
/*     */     //   104: iconst_1
/*     */     //   105: dup
/*     */     //   106: pop2
/*     */     //   107: dup
/*     */     //   108: astore #4
/*     */     //   110: iconst_0
/*     */     //   111: dup_x1
/*     */     //   112: aload_3
/*     */     //   113: arraylength
/*     */     //   114: iconst_2
/*     */     //   115: isub
/*     */     //   116: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   119: sipush #231
/*     */     //   122: istore #6
/*     */     //   124: sipush #231
/*     */     //   127: istore #7
/*     */     //   129: iload #5
/*     */     //   131: iload #6
/*     */     //   133: idiv
/*     */     //   134: iconst_1
/*     */     //   135: isub
/*     */     //   136: istore #8
/*     */     //   138: iconst_0
/*     */     //   139: istore #9
/*     */     //   141: iconst_0
/*     */     //   142: istore #10
/*     */     //   144: iload #5
/*     */     //   146: iload #6
/*     */     //   148: irem
/*     */     //   149: ifle -> 159
/*     */     //   152: iload #5
/*     */     //   154: iload #6
/*     */     //   156: irem
/*     */     //   157: istore #9
/*     */     //   159: iconst_0
/*     */     //   160: dup
/*     */     //   161: istore #5
/*     */     //   163: iload #8
/*     */     //   165: if_icmpge -> 328
/*     */     //   168: aload_1
/*     */     //   169: aload_2
/*     */     //   170: new java/lang/StringBuilder
/*     */     //   173: dup
/*     */     //   174: invokespecial <init> : ()V
/*     */     //   177: iconst_0
/*     */     //   178: ldc_w 'Z6?!'
/*     */     //   181: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   184: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   187: ldc_w 'hNb='
/*     */     //   190: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   193: iconst_1
/*     */     //   194: anewarray java/lang/Object
/*     */     //   197: iconst_1
/*     */     //   198: dup
/*     */     //   199: pop2
/*     */     //   200: dup
/*     */     //   201: iconst_0
/*     */     //   202: iload #7
/*     */     //   204: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   207: aastore
/*     */     //   208: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   211: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   214: ldc_w 'X4[6M!'
/*     */     //   217: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   220: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   223: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   226: invokestatic secureTransmit : (Ljavax/smartcardio/CardChannel;Lcom/sltech/dpi/util/KeyPair;Ljava/lang/String;)[B
/*     */     //   229: dup
/*     */     //   230: astore_3
/*     */     //   231: arraylength
/*     */     //   232: iconst_2
/*     */     //   233: isub
/*     */     //   234: istore #10
/*     */     //   236: iload #7
/*     */     //   238: aload_3
/*     */     //   239: iconst_0
/*     */     //   240: aload #4
/*     */     //   242: iload #7
/*     */     //   244: iload #10
/*     */     //   246: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   249: iload #6
/*     */     //   251: iadd
/*     */     //   252: istore #7
/*     */     //   254: goto -> 319
/*     */     //   257: pop
/*     */     //   258: astore #11
/*     */     //   260: new com/sltech/dpi/exception/DPIException
/*     */     //   263: dup
/*     */     //   264: new java/lang/StringBuilder
/*     */     //   267: dup
/*     */     //   268: invokespecial <init> : ()V
/*     */     //   271: iconst_0
/*     */     //   272: ldc_w '*9\\n$\\n|=\\n9=q>\\n9lE'
/*     */     //   275: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   278: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   281: aload_3
/*     */     //   282: iload #10
/*     */     //   284: baload
/*     */     //   285: invokestatic valueOf : (I)Ljava/lang/String;
/*     */     //   288: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   291: ldc_w '+'
/*     */     //   294: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   297: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   300: aload_3
/*     */     //   301: iload #10
/*     */     //   303: iconst_1
/*     */     //   304: iadd
/*     */     //   305: baload
/*     */     //   306: invokestatic valueOf : (I)Ljava/lang/String;
/*     */     //   309: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   312: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   315: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   318: athrow
/*     */     //   319: iinc #5, 1
/*     */     //   322: iload #5
/*     */     //   324: goto -> 163
/*     */     //   327: iconst_0
/*     */     //   328: iload #9
/*     */     //   330: ifle -> 484
/*     */     //   333: aload_1
/*     */     //   334: aload_2
/*     */     //   335: new java/lang/StringBuilder
/*     */     //   338: dup
/*     */     //   339: invokespecial <init> : ()V
/*     */     //   342: iconst_0
/*     */     //   343: ldc_w '}NU'
/*     */     //   346: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   349: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   352: ldc_w 'O6II'
/*     */     //   355: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   358: iconst_1
/*     */     //   359: anewarray java/lang/Object
/*     */     //   362: iconst_1
/*     */     //   363: dup
/*     */     //   364: pop2
/*     */     //   365: dup
/*     */     //   366: iconst_0
/*     */     //   367: iload #7
/*     */     //   369: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   372: aastore
/*     */     //   373: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*     */     //   376: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   379: ldc_w 'fU|NfU'
/*     */     //   382: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   385: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   388: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   391: invokestatic secureTransmit : (Ljavax/smartcardio/CardChannel;Lcom/sltech/dpi/util/KeyPair;Ljava/lang/String;)[B
/*     */     //   394: dup
/*     */     //   395: astore_3
/*     */     //   396: arraylength
/*     */     //   397: iconst_2
/*     */     //   398: isub
/*     */     //   399: istore #10
/*     */     //   401: iload #7
/*     */     //   403: aload_3
/*     */     //   404: iconst_0
/*     */     //   405: aload #4
/*     */     //   407: iload #7
/*     */     //   409: iload #9
/*     */     //   411: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   414: iload #6
/*     */     //   416: iadd
/*     */     //   417: istore #7
/*     */     //   419: aload_0
/*     */     //   420: goto -> 485
/*     */     //   423: astore #5
/*     */     //   425: new com/sltech/dpi/exception/DPIException
/*     */     //   428: dup
/*     */     //   429: new java/lang/StringBuilder
/*     */     //   432: dup
/*     */     //   433: invokespecial <init> : ()V
/*     */     //   436: iconst_0
/*     */     //   437: ldc_w 'Vx6G"'O\\nkjNr kiG1'
/*     */     //   440: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   443: invokevirtual insert : (ILjava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   446: aload_3
/*     */     //   447: iload #10
/*     */     //   449: baload
/*     */     //   450: invokestatic valueOf : (I)Ljava/lang/String;
/*     */     //   453: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   456: ldc_w '_'
/*     */     //   459: invokestatic f : (Ljava/lang/String;)Ljava/lang/String;
/*     */     //   462: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   465: aload_3
/*     */     //   466: iload #10
/*     */     //   468: iconst_1
/*     */     //   469: iadd
/*     */     //   470: baload
/*     */     //   471: invokestatic valueOf : (I)Ljava/lang/String;
/*     */     //   474: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   477: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   480: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   483: athrow
/*     */     //   484: aload_0
/*     */     //   485: aload #4
/*     */     //   487: invokespecial f : ([B)[B
/*     */     //   490: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #31	-> 0
/*     */     //   #51	-> 55
/*     */     //   #125	-> 61
/*     */     //   #121	-> 75
/*     */     //   #7	-> 88
/*     */     //   #157	-> 98
/*     */     //   #16	-> 110
/*     */     //   #179	-> 119
/*     */     //   #98	-> 124
/*     */     //   #89	-> 129
/*     */     //   #180	-> 138
/*     */     //   #176	-> 141
/*     */     //   #40	-> 144
/*     */     //   #171	-> 152
/*     */     //   #201	-> 159
/*     */     //   #99	-> 168
/*     */     //   #199	-> 231
/*     */     //   #224	-> 238
/*     */     //   #42	-> 249
/*     */     //   #220	-> 254
/*     */     //   #1	-> 258
/*     */     //   #39	-> 260
/*     */     //   #201	-> 319
/*     */     //   #77	-> 328
/*     */     //   #35	-> 333
/*     */     //   #145	-> 396
/*     */     //   #122	-> 403
/*     */     //   #27	-> 414
/*     */     //   #58	-> 420
/*     */     //   #97	-> 423
/*     */     //   #44	-> 425
/*     */     //   #136	-> 484
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	491	0	a	Lcom/sltech/dpi/impl/DpiV3Manager;
/*     */     //   0	491	1	a	Ljavax/smartcardio/CardChannel;
/*     */     //   0	491	2	a	Lcom/sltech/dpi/util/KeyPair;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   168	254	258	java/lang/Exception
/*     */     //   333	419	423	java/lang/Exception }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readSerialNumber(CardChannel a) throws DPIException { return -1L; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readPhoto(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/* 194 */     KeyPair keyPair = f(a, dpiDataTO);
/*     */     return readPhoto(a, keyPair);
/*     */   } public List readFingerPrintsEnrolled(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     f(a, dpiDataTO);
/*     */     return dpiDataTO.getFingerPrints();
/*     */   } public DatosdpiTO readGeneralDataOld(CardChannel a) throws DPIException {
/*     */     return f(readGeneralData(a));
/*     */   }
/* 203 */   protected long f(byte[] a) { if (a == null) {
/*     */       long l1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 385 */       return l1 = -1L;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       long l1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 428 */       return l1 = Long.parseLong(DataUtils.BCDToStringDPIV2(Arrays.copyOf(a, 7)));
/*     */     }  }
/*     */    public String readSerialNumberNxp(CardChannel a) throws DPIException {
/*     */     byte[] arrayOfByte = null;
/*     */     String str = "";
/*     */     arrayOfByte = a.transmit(new CommandAPDU(C)).getBytes();
/*     */   } public DpiDataTO readGeneralData(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     f(a, dpiDataTO);
/*     */     return dpiDataTO;
/*     */   } static  {
/*     */     H = DataUtils.hexTextToByteArray(i.f("jY\024R`Qg'`Q|L7\005"));
/* 440 */     l = DataUtils.hexTextToByteArray(CardUtils.f("r\036/6Q?^AX6[4M#"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 512 */     j = DataUtils.hexTextToByteArray(i.f("`SoP`S}N7\f"));
/*     */     E = DataUtils.hexTextToByteArray(CardUtils.f("Q=V0X4Z6O)"));
/*     */     C = DataUtils.hexTextToByteArray(i.f("hSg\\`S}N7u"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String readMRZ(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     KeyPair keyPair = f(a, dpiDataTO);
/*     */     return f(a, keyPair);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readAllDataOld(CardChannel a) throws DPIException {
/*     */     return f(readAllData(a));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte[] K = DataUtils.hexTextToByteArray(CardUtils.f("r\036/6Q<^AX6.@L#"));
/*     */   
/*     */   private static final byte[] E;
/*     */   
/*     */   private static final byte[] j;
/*     */   
/*     */   private static final byte[] l;
/*     */   
/*     */   private static final byte[] C;
/*     */ 
/*     */   
/*     */   public void transformData(byte[] a, byte[] a, DpiDataTO a) { k(a, a);
/* 545 */     f(a, a); }
/*     */   
/*     */   public DatosdpiTO transformDataOld(byte[] a, byte[] a) {
/*     */     transformData(a, a, dpiDataTO);
/*     */     DpiDataTO dpiDataTO;
/*     */     return f(dpiDataTO = new DpiDataTO());
/*     */   }
/*     */   
/*     */   private static final Logger J = LoggerFactory.getLogger(DpiV3Manager.class);
/*     */   private static final byte[] H;
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/impl/DpiV3Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */