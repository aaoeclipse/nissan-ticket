/*     */ package com.sltech.dpi.smartcard;
/*     */ 
/*     */ import com.n.h.i;
/*     */ import com.sltech.dpi.util.CardUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public static enum FingerType
/*     */ {
/*     */   LEFT_LITTLE,
/*     */   LEFT_MIDDLE,
/*     */   LEFT_RING,
/*     */   RIGHT_MIDDLE,
/*     */   LEFT_INDEX,
/*     */   RIGHT_INDEX,
/*  34 */   LEFT_THUMB(1), RIGHT_THUMB(1), RIGHT_LITTLE(1), RIGHT_RING(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int E;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   FingerType(int a) {
/* 135 */     this.E = a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*     */     LEFT_INDEX = new FingerType(i.f("\034&\0210\017*\003:Bl"), 1, 2);
/*     */     LEFT_MIDDLE = new FingerType(CardUtils.f("J8W\017h;S;W&C"), 2, 3);
/*     */     LEFT_RING = new FingerType(i.f("/\022\"\004<\0377Is"), 3, 4);
/*     */     LEFT_LITTLE = new FingerType(CardUtils.f("J8W\017h:S+G&C"), 4, 5);
/* 188 */     RIGHT_THUMB = new FingerType(i.f("4\031$\0370\0177\005+Jv"), 5, 6); RIGHT_INDEX = new FingerType(CardUtils.f("T4V\023c)S1W/^"), 6, 7); RIGHT_MIDDLE = new FingerType(i.f("\007/\027+\003;\035*\t:Kq"), 7, 8); RIGHT_RING = new FingerType(CardUtils.f("/X\034\"E-Z$A"), 8, 9); RIGHT_LITTLE = new FingerType(i.f("\007/\027+\003;\034*\031*Kq"), 9, 10);
/*     */     true;
/*     */     true[0] = LEFT_THUMB;
/*     */     true[1] = LEFT_INDEX;
/*     */     true[2] = LEFT_MIDDLE;
/*     */     true[3] = LEFT_RING;
/*     */     true[4] = LEFT_LITTLE;
/*     */     true[5] = RIGHT_THUMB;
/*     */     true[6] = RIGHT_INDEX;
/*     */     true[7] = RIGHT_MIDDLE;
/*     */     true[8] = RIGHT_RING;
/*     */     true[9] = RIGHT_LITTLE;
/*     */     K = true;
/*     */   }
/*     */   
/*     */   public static FingerType getFingerCode(int a) { // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: invokestatic values : ()[Lcom/sltech/dpi/smartcard/FingerType;
/*     */     //   5: dup
/*     */     //   6: astore_2
/*     */     //   7: arraylength
/*     */     //   8: istore_3
/*     */     //   9: iconst_0
/*     */     //   10: dup
/*     */     //   11: istore #4
/*     */     //   13: iload_3
/*     */     //   14: if_icmpge -> 46
/*     */     //   17: aload_2
/*     */     //   18: iload #4
/*     */     //   20: aaload
/*     */     //   21: dup
/*     */     //   22: astore #5
/*     */     //   24: invokevirtual getFingerCode : ()I
/*     */     //   27: iload_0
/*     */     //   28: if_icmpne -> 37
/*     */     //   31: aload #5
/*     */     //   33: dup
/*     */     //   34: astore_1
/*     */     //   35: areturn
/*     */     //   36: pop
/*     */     //   37: iinc #4, 1
/*     */     //   40: iload #4
/*     */     //   42: goto -> 13
/*     */     //   45: iconst_0
/*     */     //   46: aload_1
/*     */     //   47: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #86	-> 0
/*     */     //   #4	-> 2
/*     */     //   #21	-> 24
/*     */     //   #79	-> 31
/*     */     //   #74	-> 35
/*     */     //   #4	-> 37
/*     */     //   #151	-> 46
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	48	0	a	I }
/*     */   
/*     */   public int getFingerCode() { return this.E; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/smartcard/FingerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */