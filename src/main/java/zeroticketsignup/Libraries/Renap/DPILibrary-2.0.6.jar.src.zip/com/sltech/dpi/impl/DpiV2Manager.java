/*     */ package com.sltech.dpi.impl;
/*     */ 
/*     */ import com.n.h.i;
/*     */ import com.sltech.dpi.IDpiManager;
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import com.sltech.dpi.smartcard.DatosdpiTO;
/*     */ import com.sltech.dpi.smartcard.DpiDataTO;
/*     */ import com.sltech.dpi.smartcard.FingerType;
/*     */ import com.sltech.dpi.util.BasicAccessControl;
/*     */ import com.sltech.dpi.util.DataUtils;
/*     */ import com.sltech.dpi.util.KeyPair;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CommandAPDU;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DpiV2Manager
/*     */   extends DPIManager
/*     */   implements IDpiManager
/*     */ {
/*     */   private static final byte[] l;
/*     */   
/*     */   public List<FingerType> readFingerPrintsEnrolled(CardChannel a) throws DPIException {
/*  36 */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 140 */     f(a, dpiDataTO);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     return dpiDataTO.getFingerPrints();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readSerialNumber(CardChannel a) throws DPIException { // Byte code:
/*     */     //   0: aload_1
/*     */     //   1: invokevirtual getCard : ()Ljavax/smartcardio/Card;
/*     */     //   4: invokevirtual getATR : ()Ljavax/smartcardio/ATR;
/*     */     //   7: invokevirtual getHistoricalBytes : ()[B
/*     */     //   10: astore_1
/*     */     //   11: aload_0
/*     */     //   12: sipush #11139
/*     */     //   15: sipush #-22728
/*     */     //   18: sipush #-8564
/*     */     //   21: sipush #23717
/*     */     //   24: pop2
/*     */     //   25: pop2
/*     */     //   26: aload_1
/*     */     //   27: invokevirtual f : ([B)J
/*     */     //   30: lreturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #38	-> 0
/*     */     //   #52	-> 11
/*     */     //   #181	-> 30
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	31	0	a	Lcom/sltech/dpi/impl/DpiV2Manager;
/*     */     //   0	31	1	a	Ljavax/smartcardio/CardChannel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readPhoto(CardChannel a, KeyPair a) throws DPIException {
/*     */     byte b2;
/*     */     int i;
/*     */     byte b1 = 78;
/*     */     super();
/*     */     true;
/*     */     true[0] = Integer.valueOf(b1);
/*     */     byte[] arrayOfByte;
/*     */     if (!check9000(arrayOfByte = BasicAccessControl.secureTransmit((CardChannel)new StringBuilder(), (KeyPair)a.append(DPIException.f("\003lwj\017j\020")), i.f("hNd=").append(String.format((String)new Object[1], true)).toString()))) {
/*     */       throw new DPIException(DPIException.f("~&M?PmS0\022ww\027F\"\0331hK\003`r\021]8SsW9\025\033g\034ua"));
/*     */     }
/*     */     true;
/*     */     boolean bool1 = true;
/* 228 */     boolean bool2 = false;
/*     */     while ((arrayOfByte[k] != 144) < i) {
/*     */       continue;
/*     */       true;
/*     */       true[0] = Integer.valueOf(b2);
/*     */       k = (arrayOfByte = BasicAccessControl.secureTransmit((CardChannel)a, (KeyPair)(new StringBuilder()).insert(0, i.f("}N\024U")), DPIException.f("\022h\024\027").append(String.format((String)new Object[1], true)).append(i.f("fU|NfU")).toString())).length - 2;
/*     */     } 
/*     */     return bool1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 248 */   public void transformData(byte[] a, byte[] a, DpiDataTO a) { f(a, a);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 434 */     k(a, a); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected long f(byte[] a) {
/*     */     if (a == null) {
/*     */       long l1;
/*     */       return l1 = -1L;
/*     */     } 
/*     */     while (true) {
/*     */       long l1;
/*     */       return l1 = Long.parseLong(DataUtils.BCDToStringDPIV2(Arrays.copyOf(a, 7)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readGeneralDataOld(CardChannel a) throws DPIException { // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: aload_1
/*     */     //   3: invokevirtual readGeneralData : (Ljavax/smartcardio/CardChannel;)Lcom/sltech/dpi/smartcard/DpiDataTO;
/*     */     //   6: sipush #-5276
/*     */     //   9: sipush #19741
/*     */     //   12: sipush #25969
/*     */     //   15: sipush #10326
/*     */     //   18: pop2
/*     */     //   19: pop2
/*     */     //   20: invokevirtual f : (Lcom/sltech/dpi/smartcard/DpiDataTO;)Lcom/sltech/dpi/smartcard/DatosdpiTO;
/*     */     //   23: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #72	-> 0
/*     */     //   #32	-> 20
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	24	0	a	Lcom/sltech/dpi/impl/DpiV2Manager;
/*     */     //   0	24	1	a	Ljavax/smartcardio/CardChannel; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readAllDataOld(CardChannel a) throws DPIException {
/*     */     return f(readAllData(a));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readPhoto(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     KeyPair keyPair = f(a, dpiDataTO);
/*     */     return readPhoto(a, keyPair);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DpiDataTO readGeneralData(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     f(a, dpiDataTO);
/*     */     return dpiDataTO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readMRZ(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     KeyPair keyPair = f(a, dpiDataTO);
/*     */     return f(a, keyPair);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static  {
/*     */     l = DataUtils.hexTextToByteArray(i.f("_lJ\fDsh(g'\031[n]l_{H3\005oYa$dPbWb'~O4\001"));
/*     */     E = DataUtils.hexTextToByteArray(DPIException.f("\fc\013h\005j\007h\020w"));
/*     */     K = DataUtils.hexTextToByteArray(i.f("`SoV`S}N5\f"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DpiDataTO readAllData(CardChannel a) throws DPIException {
/*     */     DpiDataTO dpiDataTO = new DpiDataTO();
/*     */     KeyPair keyPair = f(a, dpiDataTO);
/*     */     dpiDataTO.setSerialNumber(String.valueOf(readSerialNumber(a)));
/*     */     dpiDataTO.setMachineReadableZone(f(a, keyPair));
/*     */     dpiDataTO.setFoto(readPhoto(a, keyPair));
/*     */     return dpiDataTO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final Logger j = LoggerFactory.getLogger(DpiV2Manager.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte[] E;
/*     */ 
/*     */ 
/*     */   
/*     */   private static final byte[] K;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO transformDataOld(byte[] a, byte[] a) {
/*     */     transformData(a, a, dpiDataTO);
/*     */     DpiDataTO dpiDataTO;
/* 533 */     return f(dpiDataTO = new DpiDataTO());
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/impl/DpiV2Manager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */