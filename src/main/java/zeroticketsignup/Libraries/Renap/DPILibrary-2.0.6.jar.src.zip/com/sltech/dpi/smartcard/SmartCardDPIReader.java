/*     */ package com.sltech.dpi.smartcard;
/*     */ 
/*     */ import com.sltech.dpi.exception.DPIConnectException;
/*     */ import com.sltech.dpi.exception.DPIException;
/*     */ import com.sltech.dpi.impl.DPIManager;
/*     */ import com.sltech.dpi.util.DataUtils;
/*     */ import java.util.List;
/*     */ import javax.smartcardio.ATR;
/*     */ import javax.smartcardio.Card;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CardTerminal;
/*     */ import javax.smartcardio.ResponseAPDU;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SmartCardDPIReader
/*     */ {
/*     */   public SmartCardDPIReader(CardTerminal a) {
/*  43 */     this
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 103 */       .a = 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 227 */       (CardChannel)(this.E = null);
/*     */     this.K = (ATR)(this.j = null);
/*     */     this.E = a;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DpiDataTO readAllData() throws DPIConnectException, DPIException { // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: aload_0
/*     */     //   3: dup
/*     */     //   4: invokespecial k : ()V
/*     */     //   7: getfield E : Ljavax/smartcardio/CardTerminal;
/*     */     //   10: invokevirtual isCardPresent : ()Z
/*     */     //   13: ifeq -> 36
/*     */     //   16: aload_0
/*     */     //   17: getfield a : Ljavax/smartcardio/CardChannel;
/*     */     //   20: invokestatic getImplementation : (Ljavax/smartcardio/CardChannel;)Lcom/sltech/dpi/impl/ChipVersion;
/*     */     //   23: invokestatic getInstance : (Lcom/sltech/dpi/impl/ChipVersion;)Lcom/sltech/dpi/IDpiManager;
/*     */     //   26: aload_0
/*     */     //   27: getfield a : Ljavax/smartcardio/CardChannel;
/*     */     //   30: invokeinterface readAllData : (Ljavax/smartcardio/CardChannel;)Lcom/sltech/dpi/smartcard/DpiDataTO;
/*     */     //   35: astore_1
/*     */     //   36: aload_0
/*     */     //   37: invokespecial f : ()V
/*     */     //   40: aload_1
/*     */     //   41: areturn
/*     */     //   42: pop
/*     */     //   43: astore_2
/*     */     //   44: aload_2
/*     */     //   45: athrow
/*     */     //   46: astore_2
/*     */     //   47: new com/sltech/dpi/exception/DPIException
/*     */     //   50: dup
/*     */     //   51: aload_2
/*     */     //   52: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   55: athrow
/*     */     //   56: astore_2
/*     */     //   57: aload_2
/*     */     //   58: athrow
/*     */     //   59: astore_3
/*     */     //   60: aload_3
/*     */     //   61: aload_0
/*     */     //   62: invokespecial f : ()V
/*     */     //   65: athrow
/*     */     //   66: aload_1
/*     */     //   67: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #50	-> 0
/*     */     //   #153	-> 2
/*     */     //   #73	-> 7
/*     */     //   #126	-> 16
/*     */     //   #183	-> 23
/*     */     //   #28	-> 26
/*     */     //   #165	-> 36
/*     */     //   #62	-> 41
/*     */     //   #202	-> 43
/*     */     //   #216	-> 44
/*     */     //   #156	-> 46
/*     */     //   #214	-> 47
/*     */     //   #124	-> 56
/*     */     //   #108	-> 57
/*     */     //   #165	-> 59
/*     */     //   #38	-> 66
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	68	0	a	Lcom/sltech/dpi/smartcard/SmartCardDPIReader;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   2	36	43	com/sltech/dpi/exception/DPIConnectException
/*     */     //   2	36	46	javax/smartcardio/CardException
/*     */     //   2	36	56	com/sltech/dpi/exception/DPIException
/*     */     //   2	36	59	finally
/*     */     //   43	60	59	finally }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final Logger l = LoggerFactory.getLogger(SmartCardDPIReader.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CardChannel a;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Card j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CardTerminal E;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ATR K;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readAllDataOld() throws DPIConnectException, DPIException {
/*     */     DatosdpiTO datosdpiTO = null;
/*     */     try {
/*     */       k();
/*     */       if (this.E.isCardPresent()) {
/*     */         datosdpiTO = DPIManager.getInstance(DPIManager.getImplementation(this.a)).readAllDataOld(this.a);
/*     */       }
/*     */       return datosdpiTO;
/*     */     } catch (DPIConnectException dPIConnectException) {
/*     */       while (true) {
/*     */         dPIConnectException = null;
/*     */         throw dPIConnectException;
/*     */       } 
/*     */     } catch (DPIException dPIException) {
/*     */       throw dPIException;
/*     */     } catch (CardException cardException) {
/*     */       throw new DPIException(cardException);
/*     */     } finally {
/*     */       f();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String readMRZ() throws DPIConnectException, DPIException {
/*     */     String str = null;
/*     */     try {
/*     */       k();
/*     */       if (this.E.isCardPresent()) {
/*     */         str = DPIManager.getInstance(DPIManager.getImplementation(this.a)).readMRZ(this.a);
/*     */       }
/*     */       return str;
/*     */     } catch (DPIConnectException dPIConnectException) {
/*     */       while (true) {
/*     */         dPIConnectException = null;
/*     */         throw dPIConnectException;
/*     */       } 
/*     */     } catch (DPIException dPIException) {
/*     */       throw dPIException;
/*     */     } catch (CardException cardException) {
/*     */       throw new DPIException(cardException);
/*     */     } finally {
/*     */       f();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DatosdpiTO readCard() throws DPIConnectException, DPIException { // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: aconst_null
/*     */     //   3: astore_2
/*     */     //   4: aload_0
/*     */     //   5: dup
/*     */     //   6: invokespecial k : ()V
/*     */     //   9: getfield E : Ljavax/smartcardio/CardTerminal;
/*     */     //   12: invokevirtual isCardPresent : ()Z
/*     */     //   15: ifeq -> 51
/*     */     //   18: aload_2
/*     */     //   19: aload_0
/*     */     //   20: getfield a : Ljavax/smartcardio/CardChannel;
/*     */     //   23: invokeinterface readFingerPrintsEnrolled : (Ljavax/smartcardio/CardChannel;)Ljava/util/List;
/*     */     //   28: aload_0
/*     */     //   29: getfield a : Ljavax/smartcardio/CardChannel;
/*     */     //   32: invokestatic getImplementation : (Ljavax/smartcardio/CardChannel;)Lcom/sltech/dpi/impl/ChipVersion;
/*     */     //   35: invokestatic getInstance : (Lcom/sltech/dpi/impl/ChipVersion;)Lcom/sltech/dpi/IDpiManager;
/*     */     //   38: dup
/*     */     //   39: astore_2
/*     */     //   40: aload_0
/*     */     //   41: getfield a : Ljavax/smartcardio/CardChannel;
/*     */     //   44: invokeinterface readGeneralData : (Ljavax/smartcardio/CardChannel;)Lcom/sltech/dpi/smartcard/DpiDataTO;
/*     */     //   49: astore_1
/*     */     //   50: pop
/*     */     //   51: aload_0
/*     */     //   52: invokespecial f : ()V
/*     */     //   55: aload_1
/*     */     //   56: aload_0
/*     */     //   57: invokespecial f : ()V
/*     */     //   60: areturn
/*     */     //   61: pop
/*     */     //   62: astore_3
/*     */     //   63: aload_3
/*     */     //   64: athrow
/*     */     //   65: astore_3
/*     */     //   66: new com/sltech/dpi/exception/DPIException
/*     */     //   69: dup
/*     */     //   70: aload_3
/*     */     //   71: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   74: athrow
/*     */     //   75: astore_3
/*     */     //   76: new com/sltech/dpi/exception/DPIException
/*     */     //   79: dup
/*     */     //   80: aload_3
/*     */     //   81: invokespecial <init> : (Ljava/lang/Throwable;)V
/*     */     //   84: athrow
/*     */     //   85: astore_2
/*     */     //   86: aload_2
/*     */     //   87: aload_0
/*     */     //   88: invokespecial f : ()V
/*     */     //   91: athrow
/*     */     //   92: aload_1
/*     */     //   93: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #121	-> 0
/*     */     //   #157	-> 2
/*     */     //   #179	-> 4
/*     */     //   #98	-> 9
/*     */     //   #89	-> 18
/*     */     //   #180	-> 28
/*     */     //   #176	-> 35
/*     */     //   #40	-> 40
/*     */     //   #201	-> 51
/*     */     //   #42	-> 56
/*     */     //   #47	-> 60
/*     */     //   #228	-> 62
/*     */     //   #168	-> 63
/*     */     //   #99	-> 65
/*     */     //   #185	-> 66
/*     */     //   #164	-> 75
/*     */     //   #199	-> 76
/*     */     //   #42	-> 85
/*     */     //   #1	-> 92
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	94	0	a	Lcom/sltech/dpi/smartcard/SmartCardDPIReader;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	55	62	com/sltech/dpi/exception/DPIConnectException
/*     */     //   4	55	65	com/sltech/dpi/exception/DPIException
/*     */     //   4	55	75	javax/smartcardio/CardException
/*     */     //   4	55	85	finally
/*     */     //   62	86	85	finally }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] readPhoto() throws DPIConnectException, DPIException {
/*     */     null = null;
/*     */     try {
/*     */       k();
/*     */       if (this.E.isCardPresent()) {
/*     */         -109;
/*     */         '❅';
/*     */         null = -6772.readPhoto(this.a);
/*     */       } 
/*     */       return null;
/*     */     } catch (DPIConnectException dPIConnectException) {
/*     */       while (true) {
/*     */         dPIConnectException = null;
/*     */         throw dPIConnectException;
/*     */       } 
/*     */     } catch (DPIException dPIException) {
/*     */       throw dPIException;
/*     */     } catch (CardException cardException) {
/*     */       throw new DPIException(cardException);
/*     */     } finally {
/*     */       f();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long readSerialNumber() throws DPIConnectException, DPIException {
/*     */     long l1 = -1L;
/*     */     try {
/*     */       k();
/* 402 */       if (this.E.isCardPresent())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 469 */         l1 = DPIManager.getInstance(DPIManager.getImplementation(this.a)).readSerialNumber(this.a);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       return l1;
/*     */     } catch (DPIConnectException dPIConnectException) {
/*     */       while (true) {
/*     */         dPIConnectException = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         throw dPIConnectException;
/*     */       } 
/*     */     } catch (CardException cardException) {
/* 491 */       throw new DPIException(cardException);
/*     */     } finally {
/*     */       f();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean check9000(ResponseAPDU a) {
/*     */     byte[] arrayOfByte;
/*     */     if ((arrayOfByte = a.getBytes())[(arrayOfByte = a.getBytes()).length - 2] == -112 && arrayOfByte[arrayOfByte.length - 1] == 0) {
/*     */       return true;
/*     */     }
/*     */     while (true) {
/*     */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<FingerType> readFingerPrintsEnrolled() throws DPIConnectException, DPIException {
/* 532 */     List<FingerType> list = null;
/*     */     try {
/*     */       k();
/*     */       if (this.E.isCardPresent())
/*     */         list = DPIManager.getInstance(DPIManager.getImplementation(this.a)).readFingerPrintsEnrolled(this.a); 
/*     */       return list;
/*     */     } catch (DPIConnectException dPIConnectException) {
/*     */       while (true) {
/*     */         dPIConnectException = null;
/*     */         throw dPIConnectException;
/*     */       } 
/*     */     } catch (DPIException dPIException) {
/*     */       throw new DPIException((Throwable)dPIException);
/*     */     } catch (CardException cardException) {
/*     */       throw new DPIException(cardException);
/*     */     } finally {
/*     */       f();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/Renap/DPILibrary-2.0.6.jar!/com/sltech/dpi/smartcard/SmartCardDPIReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */