/*     */ package org.jdesktop.swingx.autocomplete;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.DefaultStyledDocument;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.Style;
/*     */ import javax.swing.text.StyledDocument;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoCompleteStyledDocument
/*     */   extends AutoCompleteDocument
/*     */   implements StyledDocument
/*     */ {
/*  48 */   public AutoCompleteStyledDocument(AbstractAutoCompleteAdaptor adaptor, boolean strictMatching, ObjectToStringConverter stringConverter, StyledDocument delegate) { super(adaptor, strictMatching, stringConverter, delegate); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  58 */   public AutoCompleteStyledDocument(AbstractAutoCompleteAdaptor adaptor, boolean strictMatching, ObjectToStringConverter stringConverter) { super(adaptor, strictMatching, stringConverter); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   public AutoCompleteStyledDocument(AbstractAutoCompleteAdaptor adaptor, boolean strictMatching) { super(adaptor, strictMatching); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   protected Document createDefaultDocument() { return new DefaultStyledDocument(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  82 */   public Style addStyle(String nm, Style parent) { return ((StyledDocument)this.delegate).addStyle(nm, parent); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   public Color getBackground(AttributeSet attr) { return ((StyledDocument)this.delegate).getBackground(attr); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   public Element getCharacterElement(int pos) { return ((StyledDocument)this.delegate).getCharacterElement(pos); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public Font getFont(AttributeSet attr) { return ((StyledDocument)this.delegate).getFont(attr); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public Color getForeground(AttributeSet attr) { return ((StyledDocument)this.delegate).getForeground(attr); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 117 */   public Style getLogicalStyle(int p) { return ((StyledDocument)this.delegate).getLogicalStyle(p); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   public Element getParagraphElement(int pos) { return ((StyledDocument)this.delegate).getParagraphElement(pos); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   public Style getStyle(String nm) { return ((StyledDocument)this.delegate).getStyle(nm); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   public void removeStyle(String nm) { ((StyledDocument)this.delegate).removeStyle(nm); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 146 */   public void setCharacterAttributes(int offset, int length, AttributeSet s, boolean replace) { ((StyledDocument)this.delegate).setCharacterAttributes(offset, length, s, replace); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   public void setLogicalStyle(int pos, Style s) { ((StyledDocument)this.delegate).setLogicalStyle(pos, s); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   public void setParagraphAttributes(int offset, int length, AttributeSet s, boolean replace) { ((StyledDocument)this.delegate).setParagraphAttributes(offset, length, s, replace); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/autocomplete/AutoCompleteStyledDocument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */