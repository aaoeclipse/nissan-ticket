/*    */ package org.jdesktop.swingx.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Contract
/*    */ {
/*    */   public static <T> T asNotNull(T input, String message) {
/* 56 */     if (input == null) {
/* 57 */       throw new NullPointerException(message);
/*    */     }
/* 59 */     if (input.getClass().isArray() && 
/* 60 */       !input.getClass().getComponentType().isPrimitive()) {
/* 61 */       T[] array = (T[])input;
/* 62 */       for (int i = 0; i < array.length; i++) {
/* 63 */         asNotNull(array[i], message);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 68 */     return input;
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/util/Contract.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */