/*     */ package org.jdesktop.swingx.autocomplete;
/*     */ 
/*     */ import javax.swing.JList;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListAdaptor
/*     */   extends AbstractAutoCompleteAdaptor
/*     */   implements ListSelectionListener
/*     */ {
/*     */   JList list;
/*     */   JTextComponent textComponent;
/*     */   ObjectToStringConverter stringConverter;
/*     */   
/*  50 */   public ListAdaptor(JList list, JTextComponent textComponent) { this(list, textComponent, ObjectToStringConverter.DEFAULT_IMPLEMENTATION); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListAdaptor(JList list, JTextComponent textComponent, ObjectToStringConverter stringConverter) {
/*  62 */     this.list = list;
/*  63 */     this.textComponent = textComponent;
/*  64 */     this.stringConverter = stringConverter;
/*     */     
/*  66 */     list.addListSelectionListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void valueChanged(ListSelectionEvent listSelectionEvent) {
/*  76 */     getTextComponent().setText(this.stringConverter.getPreferredStringForItem(this.list.getSelectedValue()));
/*     */     
/*  78 */     markEntireText();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public Object getSelectedItem() { return this.list.getSelectedValue(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  88 */   public int getItemCount() { return this.list.getModel().getSize(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public Object getItem(int index) { return this.list.getModel().getElementAt(index); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public void setSelectedItem(Object item) { this.list.setSelectedValue(item, true); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 103 */   public JTextComponent getTextComponent() { return this.textComponent; }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/autocomplete/ListAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */