/*     */ package org.jdesktop.swingx.autocomplete;
/*     */ 
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractAutoCompleteAdaptor
/*     */ {
/*     */   private String selectedItemAsString;
/*     */   
/*     */   public abstract Object getSelectedItem();
/*     */   
/*     */   public abstract void setSelectedItem(Object paramObject);
/*     */   
/*  60 */   public String getSelectedItemAsString() { return this.selectedItemAsString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public void setSelectedItemAsString(String itemAsString) { this.selectedItemAsString = itemAsString; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getItemCount();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract Object getItem(int paramInt);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean listContainsSelectedItem() {
/*  89 */     Object selectedItem = getSelectedItem();
/*  90 */     for (int i = 0, n = getItemCount(); i < n; i++) {
/*  91 */       if (getItem(i) == selectedItem) return true; 
/*     */     } 
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract JTextComponent getTextComponent();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 106 */   public void markEntireText() { markText(0); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void markText(int start) {
/* 115 */     getTextComponent().setCaretPosition(getTextComponent().getText().length());
/* 116 */     getTextComponent().moveCaretPosition(start);
/*     */   }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/autocomplete/AbstractAutoCompleteAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */