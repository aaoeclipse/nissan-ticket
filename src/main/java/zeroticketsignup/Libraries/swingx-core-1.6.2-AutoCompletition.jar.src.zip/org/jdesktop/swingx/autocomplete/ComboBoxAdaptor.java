/*     */ package org.jdesktop.swingx.autocomplete;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.accessibility.Accessible;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.plaf.basic.ComboPopup;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboBoxAdaptor
/*     */   extends AbstractAutoCompleteAdaptor
/*     */   implements ActionListener
/*     */ {
/*     */   private JComboBox comboBox;
/*     */   
/*     */   public ComboBoxAdaptor(JComboBox comboBox) {
/*  49 */     this.comboBox = comboBox;
/*     */     
/*  51 */     comboBox.addActionListener(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public void actionPerformed(ActionEvent actionEvent) { markEntireText(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  65 */   public int getItemCount() { return this.comboBox.getItemCount(); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public Object getItem(int index) { return this.comboBox.getItemAt(index); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedItem(Object item) {
/*  76 */     if (item == getSelectedItem()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     Accessible a = this.comboBox.getUI().getAccessibleChild(this.comboBox, 0);
/*     */     
/*  89 */     if (getItemCount() > 0 && a instanceof ComboPopup) {
/*  90 */       JList<Object> list = ((ComboPopup)a).getList();
/*  91 */       int lastIndex = list.getModel().getSize() - 1;
/*     */       
/*  93 */       Rectangle rect = list.getCellBounds(lastIndex, lastIndex);
/*     */       
/*  95 */       if (rect == null) {
/*  96 */         throw new IllegalStateException("attempting to access index " + lastIndex + " for " + this.comboBox);
/*     */       }
/*     */ 
/*     */       
/* 100 */       list.scrollRectToVisible(rect);
/*     */     } 
/*     */ 
/*     */     
/* 104 */     this.comboBox.setSelectedItem(item);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 109 */   public Object getSelectedItem() { return this.comboBox.getModel().getSelectedItem(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public JTextComponent getTextComponent() { return (JTextComponent)this.comboBox.getEditor().getEditorComponent(); }
/*     */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/autocomplete/ComboBoxAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */