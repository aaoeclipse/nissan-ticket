/*    */ package org.jdesktop.beans;
/*    */ 
/*    */ import java.beans.PropertyChangeListener;
/*    */ import java.beans.PropertyChangeSupport;
/*    */ import java.beans.VetoableChangeListener;
/*    */ import java.beans.VetoableChangeSupport;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractSerializableBean
/*    */   extends AbstractBean
/*    */   implements Serializable
/*    */ {
/*    */   protected AbstractSerializableBean() {}
/*    */   
/* 69 */   protected AbstractSerializableBean(PropertyChangeSupport pcs, VetoableChangeSupport vcs) { super(pcs, vcs); }
/*    */ 
/*    */   
/*    */   private void writeObject(ObjectOutputStream s) throws IOException {
/* 73 */     s.defaultWriteObject();
/*    */     
/* 75 */     for (PropertyChangeListener l : getPropertyChangeListeners()) {
/* 76 */       if (l instanceof Serializable) {
/* 77 */         s.writeObject(l);
/*    */       }
/*    */     } 
/*    */     
/* 81 */     for (VetoableChangeListener l : getVetoableChangeListeners()) {
/* 82 */       if (l instanceof Serializable) {
/* 83 */         s.writeObject(l);
/*    */       }
/*    */     } 
/*    */     
/* 87 */     s.writeObject(null);
/*    */   }
/*    */ 
/*    */   
/*    */   private void readObject(ObjectInputStream s) throws ClassNotFoundException, IOException {
/* 92 */     s.defaultReadObject();
/*    */     
/*    */     Object listenerOrNull;
/* 95 */     while (null != (listenerOrNull = s.readObject())) {
/* 96 */       if (listenerOrNull instanceof PropertyChangeListener) {
/* 97 */         addPropertyChangeListener((PropertyChangeListener)listenerOrNull); continue;
/* 98 */       }  if (listenerOrNull instanceof VetoableChangeListener)
/* 99 */         addVetoableChangeListener((VetoableChangeListener)listenerOrNull); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/beans/AbstractSerializableBean.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */