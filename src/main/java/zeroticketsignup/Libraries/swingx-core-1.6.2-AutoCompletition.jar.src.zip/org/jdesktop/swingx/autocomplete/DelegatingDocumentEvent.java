/*    */ package org.jdesktop.swingx.autocomplete;
/*    */ 
/*    */ import javax.swing.event.DocumentEvent;
/*    */ import javax.swing.text.Document;
/*    */ import javax.swing.text.Element;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class DelegatingDocumentEvent
/*    */   implements DocumentEvent
/*    */ {
/*    */   private final Document resourcedDocument;
/*    */   private final DocumentEvent sourceEvent;
/*    */   
/*    */   public DelegatingDocumentEvent(Document resourcedDocument, DocumentEvent sourceEvent) {
/* 19 */     this.resourcedDocument = resourcedDocument;
/* 20 */     this.sourceEvent = sourceEvent;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 27 */   public DocumentEvent.ElementChange getChange(Element elem) { return this.sourceEvent.getChange(elem); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public Document getDocument() { return this.resourcedDocument; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 41 */   public int getLength() { return this.sourceEvent.getLength(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public int getOffset() { return this.sourceEvent.getOffset(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public DocumentEvent.EventType getType() { return this.sourceEvent.getType(); }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/autocomplete/DelegatingDocumentEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */