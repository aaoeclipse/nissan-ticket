/*    */ package org.jdesktop.swingx.autocomplete;
/*    */ 
/*    */ import java.util.List;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TextComponentAdaptor
/*    */   extends AbstractAutoCompleteAdaptor
/*    */ {
/*    */   List<?> items;
/*    */   JTextComponent textComponent;
/*    */   Object selectedItem;
/*    */   
/*    */   public TextComponentAdaptor(JTextComponent textComponent, List<?> items) {
/* 53 */     this.items = items;
/* 54 */     this.textComponent = textComponent;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 59 */   public Object getSelectedItem() { return this.selectedItem; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 64 */   public int getItemCount() { return this.items.size(); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public Object getItem(int index) { return this.items.get(index); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 74 */   public void setSelectedItem(Object item) { this.selectedItem = item; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 79 */   public JTextComponent getTextComponent() { return this.textComponent; }
/*    */ }


/* Location:              /home/eclipse/Documents/Work/Nissan/ZERO INNOVATION/REGISTRO/ZeroTicketJustSignUp.jar!/zeroticketsignup/Libraries/swingx-core-1.6.2-AutoCompletition.jar!/org/jdesktop/swingx/autocomplete/TextComponentAdaptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.1
 */